function GetHeightValues()
{	
	%ChPMi = mAbs(mFloor($ChPx/$TerSS));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPxMf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPx+$TerSS)/$TerSS)));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPxbMf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor($ChPy/$TerSS)));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPyMf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPy+$TerSS)/$TerSS)));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPybMf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	////////////////////////////////////////

	%Posx = getSubStr($Sd,%ChPxMf,1);
	%Posxb = getSubStr($Sd,%ChPxbMf,1);
	%Posy = getSubStr($Sd,%ChPyMf,1);
	%Posyb = getSubStr($Sd,%ChPybMf,1);

	$BLCH = mAbs(%Posy - %Posx) * $TerHM;
	$TLCH = mAbs(%Posyb - %Posx) * $TerHM;
	$BRCH = mAbs(%Posy - %Posxb) * $TerHM;
	$TRCH = mAbs(%Posyb - %Posxb) * $TerHM;

	Slopes_SmoothingCo();
}
function GetHeightValues_BiomeA()
{
	%ChPMi = mAbs(mFloor($ChPx/$BioSS));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPxMBiof = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPx+$BioSS)/$BioSS)));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPxbMBiof = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor($ChPy/$BioSS)));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPyMBiof = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPy+$BioSS)/$BioSS)));
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPybMBiof = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	////////////////////////////////////////

	%PosxBio = getSubStr($Sd,%ChPxMBiof,1);
	%PosxbBio = getSubStr($Sd,%ChPxbMBiof,1);
	%PosyBio = getSubStr($Sd,%ChPyMBiof,1);
	%PosybBio = getSubStr($Sd,%ChPybMBiof,1);

	$BLCHBio = mAbs(%PosyBio - %PosxBio) * $TerHM;
	$TLCHBio = mAbs(%PosybBio - %PosxBio) * $TerHM;
	$BRCHBio = mAbs(%PosyBio - %PosxbBio) * $TerHM;
	$TRCHBio = mAbs(%PosybBio - %PosxbBio) * $TerHM;

	Slope_BiomeA();
}
function GetHeightValues_BiomeB()
{
	%ChPMi = mAbs((mFloor(($ChPx+$BioSS*$BioO)/$BioSS))*$BioSS);
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPxMBiobf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPx+$BioSS*($BioO+1))/$BioSS))*$BioSS);
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPxbMBiobf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPy+$BioSS*($BioO+1))/$BioSS))*$BioSS);
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPyMBiobf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	%ChPMi = mAbs((mFloor(($ChPy+$BioSS*($BioO+2))/$BioSS))*$BioSS);
	%ChPMf = 0;
	for(%c=0;%c<strLen(%ChPMi);%c++)
		%ChPMf = %ChPMf + getSubStr(%ChPMi,%c,1);
	%ChPybMBiobf = getSubStr(%ChPMf,strLen(%ChPMf)-1,1);

	////////////////////////////////////////

	%PosxBiob = getSubStr($Sd,%ChPxMBiobf,1);
	%PosxbBiob = getSubStr($Sd,%ChPxbMBiobf,1);
	%PosyBiob = getSubStr($Sd,%ChPyMBiobf,1);
	%PosybBiob = getSubStr($Sd,%ChPybMBiobf,1);

	$BLCHBiob = mAbs(%PosyBiob - %PosxBiob) * $TerHM;
	$TLCHBiob = mAbs(%PosybBiob - %PosxBiob) * $TerHM;
	$BRCHBiob = mAbs(%PosyBiob - %PosxbBiob) * $TerHM;
	$TRCHBiob = mAbs(%PosybBiob - %PosxbBiob) * $TerHM;

	Slope_BiomeB();	
}
function GetCustomHeightValues()
{	
	%ChPxMf = mAbs(mFloor($ChPx/$TerSS));
	%ChPxbMf = mAbs((mFloor(($ChPx+$TerSS)/$TerSS)));
	%ChPyMf = mAbs((mFloor($ChPy/$TerSS)));
	%ChPybMf = mAbs((mFloor(($ChPy+$TerSS)/$TerSS)));

	////////////////////////////////////////

	$BLCH = eval("HVx" @ %ChPxMf @ "y" @ %ChPyMf @ ".getValue();");
	$TLCH = eval("HVx" @ %ChPxMf @ "y" @ %ChPybMf @ ".getValue();");
	$BRCH = eval("HVx" @ %ChPxbMf @ "y" @ %ChPyMf @ ".getValue();");
	$TRCH = eval("HVx" @ %ChPxbMf @ "y" @ %ChPybMf @ ".getValue();");

	Slopes_SmoothingCo();
}