datablock fxDTSBrickData (brickFood_Apple_Data)
{
	brickFile = "./apple.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Apple";
	iconName = "Add-Ons/Brick_Food/apple";
};

datablock fxDTSBrickData (brickFood_Bacon_Data)
{
	brickFile = "./bacon.blb";
	category = "Food";
	subCategory = "Meat";
	uiName = "Bacon";
	iconName = "Add-Ons/Brick_Food/bacon";
};

datablock fxDTSBrickData (brickFood_Baguette_Data)
{
	brickFile = "./baguette.blb";
	category = "Food";
	subCategory = "Processed";
	uiName = "Baguette";
	iconName = "Add-Ons/Brick_Food/baguette";
};

datablock fxDTSBrickData (brickFood_Banana_Data)
{
	brickFile = "./banana.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Banana";
	iconName = "Add-Ons/Brick_Food/banana";
};

datablock fxDTSBrickData (brickFood_BananaBundle_Data)
{
	brickFile = "./bananabundle.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Banana Bundle";
	iconName = "Add-Ons/Brick_Food/bananabundle";
};

datablock fxDTSBrickData (brickFood_Bellpepper_Data)
{
	brickFile = "./bellpepper.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Bell Pepper";
	iconName = "Add-Ons/Brick_Food/bellpepper";
};

datablock fxDTSBrickData (brickFood_Berries_Data)
{
	brickFile = "./berries.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Berries";
	iconName = "Add-Ons/Brick_Food/berries";
};

datablock fxDTSBrickData (brickFood_Bread_Data)
{
	brickFile = "./bread.blb";
	category = "Food";
	subCategory = "Processed";
	uiName = "Bread";
	iconName = "Add-Ons/Brick_Food/bread";
};
datablock fxDTSBrickData (brickFood_Cabbage_Data)
{
	brickFile = "./cabbage.blb";
	category = "Food";
	subCategory = "Vegetable";
	uiName = "Cabbage";
	iconName = "Add-Ons/Brick_Food/cabbage";
};

datablock fxDTSBrickData (brickFood_CabbagePlant_Data)
{
	brickFile = "./cabbageplant.blb";
	category = "Food";
	subCategory = "Plants";
	uiName = "Cabbage Plant";
	iconName = "Add-Ons/Brick_Food/cabbageplant";
};

datablock fxDTSBrickData (brickFood_Carrot_Data)
{
	brickFile = "./carrot.blb";
	category = "Food";
	subCategory = "Vegetable";
	uiName = "Carrot";
	iconName = "Add-Ons/Brick_Food/carrot";
};

datablock fxDTSBrickData (brickFood_CarrotBundle_Data)
{
	brickFile = "./carrotbundle.blb";
	category = "Food";
	subCategory = "Vegetable";
	uiName = "Carrot Bundle";
	iconName = "Add-Ons/Brick_Food/carrotbundle";
};

datablock fxDTSBrickData (brickFood_CarrotBundlePlanted_Data)
{
	brickFile = "./carrotbundleplanted.blb";
	category = "Food";
	subCategory = "Plants";
	uiName = "Carrot Bundle Planted";
	iconName = "Add-Ons/Brick_Food/carrotbundleplanted";
};

datablock fxDTSBrickData (brickFood_CarrotPlanted_Data)
{
	brickFile = "./carrotplanted.blb";
	category = "Food";
	subCategory = "Plants";
	uiName = "Carrot Planted";
	iconName = "Add-Ons/Brick_Food/carrotplanted";
};

datablock fxDTSBrickData (brickFood_CheeseQuarter_Data)
{
	brickFile = "./cheesequarter.blb";
	category = "Food";
	subCategory = "Processed";
	uiName = "Cheese Quarter";
	iconName = "Add-Ons/Brick_Food/cheesequarter";
};

datablock fxDTSBrickData (brickFood_CheeseSlice_Data)
{
	brickFile = "./cheeseslice.blb";
	category = "Food";
	subCategory = "Processed";
	uiName = "Cheese Slice";
	iconName = "Add-Ons/Brick_Food/cheeseslice";
};

datablock fxDTSBrickData (brickFood_CheeseWheel_Data)
{
	brickFile = "./cheesewheel.blb";
	category = "Food";
	subCategory = "Processed";
	uiName = "Cheese Wheel";
	iconName = "Add-Ons/Brick_Food/cheesewheel";
};

datablock fxDTSBrickData (brickFood_Coconut_Data)
{
	brickFile = "./coconut.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Coconut";
	iconName = "Add-Ons/Brick_Food/coconut";
};

datablock fxDTSBrickData (brickFood_Corn_Data)
{
	brickFile = "./corn.blb";
	category = "Food";
	subCategory = "Other";
	uiName = "Corn";
	iconName = "Add-Ons/Brick_Food/corn";
};

datablock fxDTSBrickData (brickFood_CornPlant_Data)
{
	brickFile = "./cornplant.blb";
	category = "Food";
	subCategory = "Plants";
	uiName = "Corn Plant";
	iconName = "Add-Ons/Brick_Food/cornplant";
};

datablock fxDTSBrickData (brickFood_Drumbell_Data)
{
	brickFile = "./drumbell.blb";
	category = "Food";
	subCategory = "Meat";
	uiName = "Drumbell";
	iconName = "Add-Ons/Brick_Food/drumbell";
};

datablock fxDTSBrickData (brickFood_Lemon_Data)
{
	brickFile = "./lemon.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Lemon";
	iconName = "Add-Ons/Brick_Food/lemon";
};

datablock fxDTSBrickData (brickFood_Onion_Data)
{
	brickFile = "./onion.blb";
	category = "Food";
	subCategory = "Vegetable";
	uiName = "Onion";
	iconName = "Add-Ons/Brick_Food/onion";
};

datablock fxDTSBrickData (brickFood_Orange_Data)
{
	brickFile = "./orange.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Orange";
	iconName = "Add-Ons/Brick_Food/orange";
};

datablock fxDTSBrickData (brickFood_Pear_Data)
{
	brickFile = "./pear.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Pear";
	iconName = "Add-Ons/Brick_Food/pear";
};

datablock fxDTSBrickData (brickFood_Pineapple_Data)
{
	brickFile = "./pineapple.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Pineapple";
	iconName = "Add-Ons/Brick_Food/pineapple";
};

datablock fxDTSBrickData (brickFood_GenericPlant_Data)
{
	brickFile = "./plant.blb";
	category = "Food";
	subCategory = "Plants";
	uiName = "Generic Plant";
	iconName = "Add-Ons/Brick_Food/plant";
};

datablock fxDTSBrickData (brickFood_PotatoBundle_Data)
{
	brickFile = "./potatobundle.blb";
	category = "Food";
	subCategory = "Other";
	uiName = "Potatos";
	iconName = "Add-Ons/Brick_Food/potatobundle";
};

datablock fxDTSBrickData (brickFood_Ribs_Data)
{
	brickFile = "./ribs.blb";
	category = "Food";
	subCategory = "Meat";
	uiName = "Ribs";
	iconName = "Add-Ons/Brick_Food/ribs";
};

datablock fxDTSBrickData (brickFood_Steak_Data)
{
	brickFile = "./steak.blb";
	category = "Food";
	subCategory = "Meat";
	uiName = "Steak";
	iconName = "Add-Ons/Brick_Food/steak";
};

datablock fxDTSBrickData (brickFood_Tomato_Data)
{
	brickFile = "./tomato.blb";
	category = "Food";
	subCategory = "Fruit";
	uiName = "Tomato";
	iconName = "Add-Ons/Brick_Food/tomato";
};