//Gamemode_Slayer
//By Greek2me.

//The purpose of this module is to migrate users to the new update system.
//This includes downloading and installing Support_Updater.zip.

function doMigrateNotify()
{
	%message = "<linkcolor:ff0000><h2>Additional Download</h2>An add-on that you recently installed requires you to download <a:mods.greek2me.us/storage/Support_Updater/Support_Updater.zip>Support_Updater</a>."
		SPC "Support_Updater is designed to give you the latest features and fixes from your favorite add-ons."
		NL "\nClick YES to automatically download the new add-on now. If you would like to be prompted later, click NO."
		NL "\n<b>Downloading this file gives you continued access to important updates, <color:ff0000>including patches and security updates</color>."
		NL "\nClicking YES is HIGHLY recommended!\n\nDON'T KNOW WHAT TO DO? CLICK YES.</b>";
	%message = parseCustomTML(%message);
	messageBoxYesNo("", %message, "doMigrateDownload();");
}

function doMigrateDownload()
{
	//repurposing Slayer's old update GUI
	Slayer_Update_Main.setText("Downloading updater...");
	Slayer_Update_Main.getObject(0).setVisible(0);
	Slayer_Update_Main.getObject(3).setText("Downloading new update system.");
	Slayer_Update_CL_Text.setText("");
	canvas.pushDialog(Slayer_Update);
	Slayer_Update_DL.setActive(0);
	Slayer_Update_Later.setActive(1);
	Slayer_Update_newVersion.setText("");

	%server = "mods.greek2me.us";
	%directory = "/storage/Support_Updater.zip";
	%query = "";
	%downloadPath = "Add-Ons/Support_Updater.zip";
	%className = "updateMigrationTCP";

	TCPClientGET(%server, %directory, %query, %downloadPath, %className);
}

function updateMigrationTCP::setProgressBar(%this, %value)
{
	Slayer_Update_Progress.setValue(%value);
}

function updateMigrationTCP::onDone(%this, %error)
{
	if(%error)
	{
		messageBoxOK("", "Error occurred:" SPC %error
			NL "Migration will be attempted again at a later time."
			SPC "If the problem persists, contact greektume@gmail.com for assistance.", "canvas.popDialog(Slayer_Update);");
	}
	else
	{
		messageBoxOK("", "Migration Success\n\nThank you for your patience and your continued support of Slayer.   ~Greek2me", "canvas.popDialog(Slayer_Update);");
	}
}

if(!isFile("Add-Ons/Support_Updater.zip"))
	schedule(100, 0, "doMigrateNotify");