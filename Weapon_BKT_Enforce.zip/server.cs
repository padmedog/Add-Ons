%error = ForceRequiredAddOn("Weapon_BKT_ATAC");
if(%error == $Error::AddOn_Disabled)
{
	error("ERROR: Weapon_BKT_Enforce - required add-on Weapon_BKT_ATAC not found");
}
else
{
	exec("./Weapon_P90.cs");
	exec("./Weapon_SPAS.cs");
	exec("./Weapon_USP.cs");
	exec("./Weapon_MagpulPDR.cs");
//	exec("./Weapon_SuperRedhawk.cs");
}