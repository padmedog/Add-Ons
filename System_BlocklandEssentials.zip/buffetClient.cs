$buffetAddress = "syerjchep.org:80";

function startSave(%name,%events,%ownership)	//the origional save command, tries to figure out if the server has BE
{
	if($BEsaving)
	{
		MessageBoxOK("Resubmission","You already clicked submit recently, you may have accidently double clicked.");
		return;
	}

	if(!isValidFileName(%name) || %name $= " " || trim(%name) $= "" || trim(%name) $= " ")
	{
		MessageBoxOK("Could not upload save.","The filename you choose was invalid, please try again.");
		return;
	}

	%name = strreplace(%name," ","");
		
	$beSaveStartTime = getsimtime();
	$BEsaveName = %name;
	$BEsaveEvents = %events;
	$BEsaveOwnership = %ownership;
	$aBEserver = 0;
	$BEsaving = 1;
	$beparttwo = 0;
	$bepacketsleft = 0;
	$beretrys = 0;
	commandtoserver('systemse');
	schedule(2500,0,notBEserverCheck);
}

function notBEserverCheck()	//if the client hasn't received a responce by now, save normally
{
	if(!$aBEserver)
		BEsaveBLS($BEsaveName,$BEsaveEvents,$BEsaveOwnership);
}

function clientcmdyesse()	//responce from the server confirming it has the add-on
{
	//BEsaveBVS($BEsaveName,$BEsaveEvents,$BEsaveOwnership);	//soon
	BEsaveBLS($BEsaveName,$BEsaveEvents,$BEsaveOwnership);
}

function BEsaveBLS(%name,%events,%ownership)	//the function for saving in BLS file format
{
	echo("Saving" SPC %name SPC %events SPC %ownership SPC "in bls");
	if(isFile("saves/BE_TEMP.bls"))
		fileDelete("saves/BE_TEMP.bls");
	if(isFile("saves/BE_TEMP.jpg"))
		fileDelete("saves/BE_TEMP.jpg");
	SaveBricks_FileName.setValue("BE_TEMP");
	SaveBricks_ExtendedInfo.setValue(%events);
	SaveBricks_Ownership.setValue(%ownership);
	SaveBricks_Save();
}

function BEtempTCP::onConnected(%this)
{
	//echo("Connected" SPC $beparttwo);

	if($beparttwo == 2)
		BEtempTCP.send("ENDBLS" SPC $becode @ " .");
	else if($beparttwo == 1)
	{
		BEtempTCP.send($bepacket[$bepacketssent]);
		$bepacketssent++;
	}
	else if($beparttwo == 0)
		BEtempTCP.send("XBLSX" SPC strReplace($pref::Player::netname," ","_") SPC $BEsaveName SPC $BEsaveEvents SPC $BEsaveOwnership @ "\n");
}

function BEtempTCP::onConnectFailed(%this)
{
	echo("Failed!");
	MessageBoxOK("Could not upload save file.","Could not connect, the server must be down!");
}

function BEtempTCP::onDisconnect(%this)
{
	echo("Disconnect!");
	if($beparttwo == 1)
	{
		echo("Disconnect while uploading!");
		$beretrys++;
		$bepacketssent--;
		BEtempTCP.delete();
		schedule(50,0,beNextPacket);
	}
}

function beNextPacket()
{
	new TCPObject(BEtempTCP);
	BEtempTCP.connect($buffetAddress);
}

function BEtempTCP::onLine(%this,%line)
{
	if(getword(%line,0) $= "CODE")
	{
		$beparttwo = 1;
		$becode = getword(%line,1);

		$tempFile = new FileObject();
		$tempfile.openForRead("saves/BE_TEMP.bls");
		$bigpacket = "|BLS|" SPC $becode @ " .";
		while(!$tempfile.isEOF())
		{
			%line = $tempfile.readLine();
			$bigpacket = $bigpacket @ %line @ "\n";
			if(strlen($bigpacket) > 25000)
			{
				$bepacket[$bepacketsleft] = $bigpacket;
				$bigpacket = "|BLS|" SPC $becode @ " .";
				$bepacketsleft++;
			}
		}
		$bepacket[$bepacketsleft] = $bigpacket;
		$bepacketsleft++;
		$bepacketssent = 0;

		$tempfile.delete();
		fileDelete("saves/BE_TEMP.bls");
		
		canvas.pushDialog(progressGui);
		Progress_Text.setText("Uploading file...");
		Progress_Bar.setValue(0);

		%this.delete();
		new TCPObject(BEtempTCP);
		BEtempTCP.connect($buffetAddress);
	}
	else if(%line $= "SAVE LINES RECEIVED")
	{
		if($bepacketssent >= $bepacketsleft)
		{
			$beparttwo = 2;
			%this.delete();
			new TCPObject(BEtempTCP);
			BEtempTCP.connect($buffetAddress);
		}
		else
		{
			Progress_Bar.setValue($bepacketssent/$bepacketsleft);
			%this.delete();
			schedule(50,0,beNextPacket);
		}
	}
	else if(getword(%line,0) $= "Concluded")
	{
		canvas.popDialog(progressGui);
		echo("Finished! Took " @ (getSimTime()-$beSaveStartTime)/1000 @ " seconds");
	}
}

function BEprocessSave()
{
	$BEsaving = 0;
	new TCPObject(BEtempTCP);
	BEtempTCP.connect($buffetAddress);
}

package buffetSaving
{
	function savinggui::save(%a,%b,%c)
	{
		parent::save(%a,%b,%c);
		if($BEsaving)
			schedule(2500,0,BEprocessSave);
	}
};
activatepackage(buffetSaving);

function BEsaveBVS(%name,%events,%ownership)	//the function for saving in BVS file format
{
	echo("Saving" SPC %name SPC %events SPC %ownership SPC "in bvs");

}

if(!isObject($uploadSavebutton))
{
	$uploadSaveButton = new GuiBitmapbuttonCtrl()
	{
		position = "118 432";
		extent = "89 36";
		mColor = "200 200 255 255";
		text = "Upload";
		bitmap = "base/client/ui/button2";
		profile = "blockbuttonprofile";
		horizSizing = "right";
		vertSizing = "bottom";
		enabled = 1;
		visible = 1;
		clipToParent = 1;
		command = "startsave(SaveBricks_FileName.getValue(),SaveBricks_ExtendedInfo.getValue(),0);";
	};
	SaveBricks_Window.add($uploadSaveButton);
}

if(!isObject($beHomeTab))
{
	$beHomeTab = new GuiBitmapbuttonCtrl()
	{
		position = "15 52";
		extent = "48 17";
		mColor = "255 255 255 255";
		text = "Home";
		bitmap = "base/client/ui/tab1";
		profile = "GuiButtonProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		enabled = 1;
		visible = 1;
		clipToParent = 1;
		command = "showHomeList();";
	};
	LoadBricks_Window.add($beHomeTab);
}

if(!isObject($beCloudTab))
{
	$beCloudTab = new GuiBitmapbuttonCtrl()
	{
		position = "64 52";
		extent = "48 17";
		mColor = "255 255 255 255";
		text = "Cloud";
		bitmap = "base/client/ui/tab1";
		profile = "GuiButtonProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		enabled = 1;
		visible = 1;
		clipToParent = 1;
		command = "showCloudList();";
	};
	LoadBricks_Window.add($beCloudTab);
}

function beModifyLoadBricksWindow()
{
	LoadBricks_Window.getObject(3).position = "22 30";
	LoadBricks_Window.getObject(4).position = "15 69";
	LoadBricks_Window.getObject(5).position = "208 30";
}

beModifyLoadBricksWindow();

function cloudSaveObject::onLine(%this,%line)
{
	$cloudList.addRow(0,getWord(%line,0) TAB getword(%line,1));
}

function cloudSaveObject::onDisconnect(%this)
{
	%this.delete();
}

function cloudBrickDownloader::onLine(%this,%line)
{
	if(strpos(%line,"not found on") != -1)
		echo("The file was not found! Perhaps the title wasn't alphanumeric?");
	else if(%line !$= "" && %line !$= " ")
		$beTempDownloadSave.writeLine(%line);
}

function bePrepareLoad()
{
	commandtoserver('InitUploadHandshake');
	schedule(100,0,LoadBricks_ClientServerCheck,"saves/tempDownload.bls");
}

function cloudBrickDownloader::onDisconnect(%this)
{
	$beTempDownloadSave.close();
	$beTempDownloadSave.delete();
	%this.delete();
	schedule(2000,0,bePrepareLoad);
}

function loadFromCloud()
{
	if($serversystemversion >= 1.29)
	{
		echo("Server has BE version 1.3 or higher, remotly loading!");
		commandtoserver('buffetload',getField($cloudList.getValue(),0));
	}
	else
	{
		echo("Server does not have a recent version of Blockland Essentials, loading normally!");
		%file = getField($cloudList.getValue(),0);
		%path = "/saves/" @ %file @ ".bls";
		$beTempDownloadSave = new FileObject();
		$beTempDownloadSave.openForWrite("saves/tempDownload.bls");
		new HTTPObject(cloudBrickDownloader);
		cloudBrickDownloader.get("syerjchep.org:80",%path);
	}
}

function showCloudList()
{
	LoadBricks_LoadButton.command = "loadFromCloud();";
	LoadBricks_FileScroll.visible = 0;
	$cloudScroll.visible = 1;
	$cloudList.clear();
	new HTTPObject(cloudSaveObject);
	cloudSaveObject.get("syerjchep.org:80","/saveindex.html");
}

function showHomeList()
{
	LoadBricks_LoadButton.command = "LoadBricks_ClickLoadButton();";
	LoadBricks_FileScroll.visible = 1;
	$cloudScroll.visible = 0;
}

if(!isObject($cloudScroll))
{
	$cloudScroll = new GuiScrollCtrl()
	{
		profile = "GuiScrollProfile";
		horizSizing = "width";
		vertSizing = "height";
		position = "15 69";
		extent = "310 404";
		enabled = 1;
		visible = 0;
		clipToParent = 1;
		hScrollBar = "alwaysOff";
		vScrollBar = "alwaysOn";
		childMargin = "0 0";
		rowHeight = "80";
		columnWidth = "30";
	};
	LoadBricks_Window.add($cloudscroll);

	$cloudList = new GuiTextListCtrl()
	{
		position = "1 1";
		extent = "293 2";
		enabled = 1;
		visible = 1;
		clipToParent = 1;
		command = "cloudBricks_click();";
		resizeCell = true;
		columns = "0 170";
		fitParentWidth = true;
		profile = "BlockListProfile";
		horizSizing = "right";
		vertSizing = "bottom";
	};
	$cloudscroll.add($cloudList);
}

function cloudBricks_click()
{
	
}
