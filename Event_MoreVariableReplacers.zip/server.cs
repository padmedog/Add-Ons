function Player::getYawB(%this)
{
	%fv = %this.getForwardVector();
	%pi = 3.1415926535897932384626433;
	%x = mASin(getWord(%fv,0)) * 180 / %pi;
	return 180 - mFloatLength(%x / mAbs(%x),0) * (180 - (mACos(getWord(%fv,1)) * 180 / %pi));
}
function Player::getPitchB(%this)
{
	%fv = %this.getEyeVector();
	%pi = 3.1415926535897932384626433;
	return mASin(getWord(%fv,2)) * 180 / %pi;
}
package InitVars
{
	function VCE_initServer()
	{
		Parent::VCE_initServer();
		registerSpecialVar(Player,"yaw","%this.getYawB()");
		registerSpecialVar(Player,"pitch","%this.getPitchB()");
	}
};
activatePackage(InitVars);