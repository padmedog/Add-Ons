//////////
// Blue //
//////////


datablock ParticleData(StormSniperBlueExplosionParticle)
{
	dragCoefficient		= 1;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 250;
	lifetimeVarianceMS	= 100;
	textureName			 = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]	  = "0.157 0.44 1 0.9";
	colors[1]	  = "0.157 0.44 1 0.8";
	colors[2]	  = "0.057 0.34 1 0.6";
	colors[3]	  = "0.057 0.34 1 0.4";

	sizes[0]		= 0.1;
	sizes[1]		= 0.2;
	sizes[2]		= 0.25;
	sizes[3]		= 0.3;

	times[0] = 0.0;
	times[1] = 0.3;
	times[2] = 0.6;
	times[3] = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(StormSniperBlueExplosionEmitter)
{
	ejectionPeriodMS = 10;
	periodVarianceMS = 0;
	ejectionVelocity = 20;
	velocityVariance = 0.0;
	ejectionOffset	= 0.0;
	thetaMin			= 40;
	thetaMax			= 100;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "StormSniperBlueExplosionParticle";

	uiName = "Storm Sniper Explosion - Blue";
};

datablock ExplosionData(StormSniperBlueExplosion)
{
	explosionShape = "";
	soundProfile = StormHitSound;

	lifeTimeMS = 100; //400

	particleEmitter = StormSniperBlueExplosionEmitter;
	particleDensity = 200;
	particleRadius = 0.1;

	emitter[0] = StormSniperBlueExplosionEmitter;

	//subExplosion[0] = "";
	//subExplosion[1] = StormSniperBlueSubExplosion1;

	faceViewer	  = true;
	explosionScale = "0.1 0.1 0.1";

	shakeCamera = false;
	camShakeFreq = "1.0 11.0 10.0";
	camShakeAmp = "3.0 10.0 3.0";
	camShakeDuration = 0.5;
	camShakeRadius = 20.0;

	// Dynamic light
	lightStartRadius = 10;
	lightEndRadius = 20;
	lightStartColor = "0.157 0.44 1 1";
	lightEndColor = "0.157 0.44 1 0";

	damageRadius = 0;
	radiusDamage = 0;

	impulseRadius = 2;
	impulseForce = 1000;

	playerBurnTime = 0;
};

datablock ParticleData(StormSniperBlueTrailParticle)
{
	dragCoefficient		= 0.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 300;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	  = "0.157 0.44 1 1";
	colors[1]	  = "0.157 0.44 1 1";
	colors[2]	  = "0.057 0.34 1 1";
	colors[3]	  = "0.075 0.212 0.4667 1";

	sizes[0]	= 0.15;
	sizes[1]	= 0.1;
	sizes[2]	= 0.05;
	sizes[3]	= 0.0;

	times[0]	= 0.2;
	times[1]	= 0.4;
	times[2]	= 0.5;
	times[3]	= 0.8;
};

datablock ParticleEmitterData(StormSniperBlueTrailEmitter)
{
	ejectionPeriodMS = 1;
	periodVarianceMS = 0;

	ejectionVelocity = 0; //0.25;
	velocityVariance = 0; //0.10;

	ejectionOffset = 0;

	thetaMin			= 0.0;
	thetaMax			= 90.0;  

	particles = StormSniperBlueTrailParticle;

	useEmitterColors = true;
	uiName = "Storm Sniper Trail - Blue";
};

datablock ProjectileData(StormSniperBlueProjectile)
{
	projectileShapeName = "";
	directDamage		  = 50;
	directDamageType	 = $DamageType::StormSniper;
	radiusDamageType	 = $DamageType::StormSniper;
	impactImpulse		 	= 800;
	verticalImpulse	  	= 800;
	explosion			 	  = StormSniperBlueExplosion;
	particleEmitter	 	  = StormSniperBlueTrailEmitter;

	brickExplosionRadius = 2;
	brickExplosionImpact = false;			 //destroy a brick if we hit it directly?
	brickExplosionForce  = 10;
	brickExplosionMaxVolume = 10;			 //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground  

	muzzleVelocity		= 200;
	velInheritFactor	 = 1;

	armingDelay			= 0;
	lifetime				= 4000;
	fadeDelay			  = 6000;
	bounceElasticity	 = 0.5;
	bounceFriction		= 0.20;
	isBallistic			= true;
	gravityMod = 0;
	ProjectileScale = "1 1 1";

	hasLight	 = true;
	lightRadius = 20;
	lightColor  = "0.157 0.44 1 1";
	
	uiName = "Storm Sniper - Blue";
};

//////////
// item //
//////////

datablock ItemData(StormSniperBlueItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./StormSniper.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Storm Sniper - Blue";
	iconName = "./icon_StormSniper";

	doColorShift = true;

	colorShiftColor = "0.157 0.44 1 1";

	 // Dynamic properties defined by the scripts
	image = StormSniperBlueImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormSniperBlueImage)
{
	// Basic Item properties
	shapeFile = "./StormSniper.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	// When firing from a point offset from the eye, muzzle correction
	// will adjust the muzzle vector to point to the eye LOS point.
	// Since this weapon doesn't actually fire from the muzzle point,
	// we need to turn this off.  
	correctMuzzleVector = true;

	// Add the WeaponImage namespace as a parent, WeaponImage namespace
	// provides some hooks into the inventory system.
	className = "WeaponImage";

	// Projectile && Ammo.
	item = StormSniperBlueItem;
	ammo = " ";
	projectile = StormSniperBlueProjectile;
	projectileType = Projectile;

	//casing = StormSniperBlueShellDebris;
	//shellExitDir		  = "1.0 -1.3 1.0";
	//shellExitOffset	  = "0 0 0";
	//shellExitVariance	= 15.0;	
	//shellVelocity		 = 7.0;

	//melee particles shoot from eye node for consistancy
	melee = false;
	//raise your arm up or not
	armReady = true;
	minShotTime = 200;
	doColorShift = true;
	colorShiftColor = StormSniperBlueItem.colorShiftColor;

	//casing = "";

	// Images have a state system which controls how the animations
	// are run, which sounds are played, script callbacks, etc. This
	// state system is downloaded to the client so that clients can
	// predict state changes and animate accordingly.  The following
	// system supports basic ready->fire->reload transitions as
	// well as a no-ammo->dryfire idle state.

	// Initial start up state
	stateName[0]					 = "Activate";
	stateTimeoutValue[0]			 = 2;
	stateTransitionOnTimeout[0]		 = "Ready";
	stateSound[0] 					 = StormEquipSound;

	stateName[1]					 = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]		 = true;
	stateSequence[1]				 = "Ready";

	stateName[2]					 = "Fire";
	stateTransitionOnTimeout[2]	     = "Smoke";
	stateTimeoutValue[2]			 = 0.14;
	stateFire[2]					 = true;
	stateAllowImageChange[2]		 = false;
	stateSequence[2]				 = "Fire";
	stateScript[2]					 = "onFire";
	stateWaitForTimeout[2]			 = true;
	stateEmitterTime[2]				 = 0.05;
	stateEmitterNode[2]				 = "muzzleNode";
	stateSound[2]					 = StormSniperShotSound;
	stateEjectShell[2]			 	 = false;

	stateName[3] = "Smoke";
	stateEmitterTime[3]				 = 0.2;
	stateEmitterNode[3]				 = "muzzleNode";
	stateTimeoutValue[3]			 = 2;
	stateTransitionOnTimeout[3]	     = "Ready";

	stateName[4]					 = "Reload";
	stateSequence[4]				 = "Reload";
	stateTransitionOnTriggerUp[4]	 = "Ready";
	stateSequence[4]				 = "Ready";
};



/////////
// Red //
/////////


datablock ParticleData(StormSniperRedExplosionParticle : StormSniperBlueExplosionParticle)
{
	colors[0]	  = "1 0.25 0.25 0.9";
	colors[1]	  = "1 0.0 0.0 0.8";
	colors[2]	  = "1 0 0 0.6";
	colors[3]	  = "1 0 0 0.4";
};

datablock ParticleEmitterData(StormSniperRedExplosionEmitter : StormSniperBlueExplosionEmitter)
{
	particles = "StormSniperRedExplosionParticle";
	uiName = "Storm Sniper Explosion - Red";
};

datablock ExplosionData(StormSniperRedExplosion : StormSniperBlueExplosion)
{
	particleEmitter = StormSniperRedExplosionEmitter;
	emitter[0] = StormSniperRedExplosionEmitter;

	lightStartColor = "1 0 0 1";
	lightEndColor = "1 0 0 0";
};

datablock ParticleData(StormSniperRedTrailParticle : StormSniperBlueTrailParticle)
{
	colors[0]	  = "1 0.25 0.25 1";
	colors[1]	  = "1 0.1 0.1 1";
	colors[2]	  = "1 0 0 1";
	colors[3]	  = "0.3 0.1 0.1 1";
};

datablock ParticleEmitterData(StormSniperRedTrailEmitter : StormSniperBlueTrailEmitter)
{
	particles = StormSniperRedTrailParticle;
	useEmitterColors = true;
	uiName = "Storm Sniper Trail - Red";
};

datablock ProjectileData(StormSniperRedProjectile : StormSniperBlueProjectile)
{
	projectileShapeName = "";
	explosion			 	  = StormSniperRedExplosion;
	particleEmitter	 	  = StormSniperRedTrailEmitter;

	hasLight	 = true;
	lightColor  = "1 0 0 1";

	uiName = "Storm Sniper - Red";
};

//////////
// item //
//////////

datablock ItemData(StormSniperRedItem : StormSniperBlueItem)
{
	uiName = "Storm Sniper - Red";
	iconName = "./icon_StormSniper";

	doColorShift = true;

	colorShiftColor = "1 0 0 1";
	image = StormSniperRedImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormSniperRedImage : StormSniperBlueImage)
{
	item = StormSniperRedItem;
	projectile = StormSniperRedProjectile;

	doColorShift = true;
	colorShiftColor = StormSniperRedItem.colorShiftColor;
};



////////////
// Yellow //
////////////


datablock ParticleData(StormSniperYellowExplosionParticle : StormSniperBlueExplosionParticle)
{
	colors[0]	  = "1 0.733333 0.25 0.9";
	colors[1]	  = "1 0.733333 0.1 0.8";
	colors[2]	  = "1 0.733333 0 0.6";
	colors[3]	  = "1 0.733333 0 0.4";
};

datablock ParticleEmitterData(StormSniperYellowExplosionEmitter : StormSniperBlueExplosionEmitter)
{
	particles = "StormSniperYellowExplosionParticle";
	uiName = "Storm Sniper Explosion - Yellow";
};

datablock ExplosionData(StormSniperYellowExplosion : StormSniperBlueExplosion)
{
	particleEmitter = StormSniperYellowExplosionEmitter;
	emitter[0] = StormSniperYellowExplosionEmitter;

	lightStartColor = "1 0.733333 0 1";
	lightEndColor = "1 0.733333 0 0";
};

datablock ParticleData(StormSniperYellowTrailParticle : StormSniperBlueTrailParticle)
{
	colors[0]	  = "1 0.733333 0.25 1";
	colors[1]	  = "1 0.733333 0.1 1";
	colors[2]	  = "1 0.733333 0 1";
	colors[3]	  = "1 0.733333 0 1";
};

datablock ParticleEmitterData(StormSniperYellowTrailEmitter : StormSniperBlueTrailEmitter)
{
	particles = StormSniperYellowTrailParticle;
	useEmitterColors = true;
	uiName = "Storm Sniper Trail - Yellow";
};

datablock ProjectileData(StormSniperYellowProjectile : StormSniperBlueProjectile)
{
	projectileShapeName = "";
	explosion			 	  = StormSniperYellowExplosion;
	particleEmitter	 	  = StormSniperYellowTrailEmitter;

	hasLight	 = true;
	lightColor  = "1 0.733333 0 1";

	uiName = "Storm Sniper - Yellow";
};

//////////
// item //
//////////

datablock ItemData(StormSniperYellowItem : StormSniperBlueItem)
{
	uiName = "Storm Sniper - Yellow";
	iconName = "./icon_StormSniper";

	doColorShift = true;

	colorShiftColor = "1 0.733333 0 1";
	image = StormSniperYellowImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormSniperYellowImage : StormSniperBlueImage)
{
	item = StormSniperYellowItem;
	projectile = StormSniperYellowProjectile;

	doColorShift = true;
	colorShiftColor = StormSniperYellowItem.colorShiftColor;
};



///////////
// Green //
///////////


datablock ParticleData(StormSniperGreenExplosionParticle : StormSniperBlueExplosionParticle)
{
	colors[0]	  = "0.25 1 0.129412 0.9";
	colors[1]	  = "0.1 1 0.129412 0.8";
	colors[2]	  = "0 1 0.129412 0.6";
	colors[3]	  = "0 1 0.129412 0.4";
};

datablock ParticleEmitterData(StormSniperGreenExplosionEmitter : StormSniperBlueExplosionEmitter)
{
	particles = "StormSniperGreenExplosionParticle";
	uiName = "Storm Sniper Explosion - Green";
};

datablock ExplosionData(StormSniperGreenExplosion : StormSniperBlueExplosion)
{
	particleEmitter = StormSniperGreenExplosionEmitter;
	emitter[0] = StormSniperGreenExplosionEmitter;

	lightStartColor = "0 1 0.129412 1";
	lightEndColor = "0 1 0.129412 0";
};

datablock ParticleData(StormSniperGreenTrailParticle : StormSniperBlueTrailParticle)
{
	colors[0]	  = "0.25 1 0.129412 1";
	colors[1]	  = "0.1 1 0.129412 1";
	colors[2]	  = "0 1 0.129412 1";
	colors[3]	  = "0 1 0.129412 1";
};

datablock ParticleEmitterData(StormSniperGreenTrailEmitter : StormSniperBlueTrailEmitter)
{
	particles = StormSniperGreenTrailParticle;
	useEmitterColors = true;
	uiName = "Storm Sniper Trail - Green";
};

datablock ProjectileData(StormSniperGreenProjectile : StormSniperBlueProjectile)
{
	projectileShapeName = "";
	explosion			 	  = StormSniperGreenExplosion;
	particleEmitter	 	  = StormSniperGreenTrailEmitter;

	hasLight	 = true;
	lightColor  = "0 1 0.129412 1";
	uiName = "Storm Sniper - Green";
};

//////////
// item //
//////////
datablock ItemData(StormSniperGreenItem : StormSniperBlueItem)
{
	uiName = "Storm Sniper - Green";
	iconName = "./icon_StormSniper";

	doColorShift = true;

	colorShiftColor = "0 1 0.129412 1";
	image = StormSniperGreenImage;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(StormSniperGreenImage : StormSniperBlueImage)
{
	item = StormSniperGreenItem;
	projectile = StormSniperGreenProjectile;

	doColorShift = true;
	colorShiftColor = StormSniperGreenItem.colorShiftColor;
};