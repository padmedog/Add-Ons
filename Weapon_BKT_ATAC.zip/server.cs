exec("./Support_AmmoGuns.cs");
exec("./Ammo.cs");
exec("./Sounds.cs");
exec("./Effects.cs");
exec("./Weapon_Mk14EBR.cs");
exec("./Weapon_G18.cs");
exec("./Weapon_L86.cs");
exec("./Weapon_AWM.cs");
exec("./Weapon_M4A1.cs");
exec("./Weapon_M1911.cs");
$BKT::HS 	= 1;
$BKT::DH 	= 1;
$BKT::CH 	= 1;
$BKT::Flash = 1;
$BKT::Recoil= 1;
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
//Features
	RTB_registerPref("Allow muzzleflash lights","Blockombat Features","BKT::Flash","bool","Weapon_M1911",1,0,0);
	RTB_registerPref("Allow headshots","Blockombat Features","BKT::HS","bool","Weapon_M1911",1,0,0);
	RTB_registerPref("Display info/ammo HUD","Blockombat Features","BKT::DH","bool","Weapon_M1911",1,0,0);
	RTB_registerPref("Disable ADS crosshairs","Blockombat Features","BKT::CH","bool","Weapon_M1911",1,0,0);
//Ammo
	RTB_registerPref("Starting .45 ACP Rounds","Blockombat Ammo","$BKT::fortyacpAmmo","int 0 999","Ammo",21,0,1);
	RTB_registerPref("Starting .44 Magnum Rounds","Blockombat Ammo","$BKT::fourfourAmmo","int 0 999","Ammo",18,0,1);
	RTB_registerPref("Starting 9mm Para. Rounds","Blockombat Ammo","$BKT::nineAmmo","int 0 999","Ammo",96,0,1);
	RTB_registerPref("Starting 5.7x28 Rounds","Blockombat Ammo","$BKT::fivesevenAmmo","int 0 999","Ammo",100,0,1);
	RTB_registerPref("Starting 5.56x45 Rounds","Blockombat Ammo","$BKT::fiftysixAmmo","int 0 999","Ammo",90,0,1);
	RTB_registerPref("Starting 7.62x39 Rounds","Blockombat Ammo","$BKT::akfoursevenAmmo","int 0 999","Ammo",90,0,1);
	RTB_registerPref("Starting 7.62x54 Rounds","Blockombat Ammo","$BKT::sixtytwoAmmo","int 0 999","Ammo",60,0,1);
	RTB_registerPref("Starting .338 Lapua Rounds","Blockombat Ammo","$BKT::lapuaAmmo","int 0 999","Ammo",15,0,1);
	RTB_registerPref("Starting .50 BMG Rounds","Blockombat Ammo","$BKT::fiftyAmmo","int 0 999","Ammo",10,0,1);
	RTB_registerPref("Starting 12 Gauge Rounds","Blockombat Ammo","$BKT::twelveGAmmo","int 0 999","Ammo",20,0,1);
}
package BKTnotifier
{
   function GameConnection::AutoAdminCheck(%this)
   {
		messageClient(%this, '', "<color:FFFF00>Server is running <color:ff0000>Blockombat ATAC <color:FF00FF>Version 3<color:FFFF00>.");
		return Parent::AutoAdminCheck(%this);
   }
};
activatePackage(BKTNotifier);
function BKTAmmoOnSpawn(%this,%obj)
{
	%obj.client.quantity["9MMrounds"]		= $BKT::nineAmmo;
	%obj.client.quantity["45caliber"]		= $BKT::fortyacpAmmo;
	%obj.client.quantity["500rounds"]		= $BKT::fiftyswAmmo;
	%obj.client.quantity["shotgunrounds"]	= $BKT::twelveGAmmo;
	%obj.client.quantity["556rounds"]		= $BKT::fiftysixAmmo;
	%obj.client.quantity["762mmrounds"]		= $BKT::sixtytwoAmmo;
	%obj.client.quantity["338rounds"]		= $BKT::lapuaAmmo;
	%obj.client.quantity["50calrounds"]		= $BKT::fiftyAmmo;
	%obj.client.quantity["57rounds"]		= $BKT::fivesevenAmmo;
	%obj.client.quantity["akrounds"]		= $BKT::akfoursevenAmmo;
	%obj.client.quantity["762mmrounds"]		= $BKT::sixtytwoAmmo;
	%obj.client.quantity["44Prounds"]		= $BKT::fourfourAmmo;
}
package BKTAmmoOnSpawn
{
	function armor::onadd(%this,%obj)
	{
		Parent::onadd(%this,%obj);
		BKTAmmoOnSpawn(%this,%obj);
	}
};
activatePackage(BKTAmmoOnSpawn);