// NARG Escape Overlay
//      v1.0 Full
//    By Nexus 4833
//=====================

$neo_version = "1.0 Full";
$neo_debug = false;

//load modules
exec("./modules/getName/getName.cs");
exec("./modules/zoomImage/zoomImage.cs");
exec("./modules/getFile/getFile.cs");
exec("./modules/getColor/getColor.cs");
exec("./modules/contextMenu/contextMenu.cs");

function neo_debug(%text)
{
	if($neo_debug)
		echo(%text);
}

function neo_defaults()
{
	$neo::defaultpref::fadein = $neo::pref::fadein = true;
	$neo::defaultpref::animate = $neo::pref::animate = true;
	$neo::defaultpref::imageScaling = $neo::pref::imageScaling = true;
	$neo::defaultpref::animationticks = $neo::pref::animationticks = 16;
	$neo::defaultpref::versioncheck = $neo::pref::versioncheck = true;
	$neo::defaultpref::mainmenuescape = $neo::pref::mainmenuescape = true;
	$neo::defaultpref::backgroundColor = $neo::pref::backgroundColor = "0 0 0 192";
	$neo::defaultpref::buttonsize = $neo::pref::buttonsize = 96;
	$neo::defaultpref::buttonColorIdle = $neo::pref::buttonColorIdle = "0 0 0 0";
	$neo::defaultpref::buttonColorHighlight = $neo::pref::buttonColorHighlight = "230 230 230 100";
	$neo::defaultpref::buttonColorPress = $neo::pref::buttonColorPress = "255 255 255 128";
	$neo::defaultpref::buttonColorContext = $neo::pref::buttonColorContext = "170 170 230 128";
	$neo::defaultpref::buttonColorSelect = $neo::pref::buttonColorSelect = "170 230 170 128";
	$neo::defaultpref::buttonColorDrag = $neo::pref::buttonColorDrag = "230 170 170 128";
	$neo::defaultpref::datapath = $neo::pref::datapath = "config/client/NARG Escape Overlay/data.cs";
	$neo::defaultpref::prefpath = $neo::pref::prefpath = "config/client/NARG Escape Overlay/pref.cs";
	$neo::defaultpref::defaulticon = $neo::pref::defaulticon = "add-ons/client_neo/ui/unknown.png";
	$neo::defaultpref::dragThreshold = $neo::pref::dragThreshold = 500;
}

function neo_initialize()
{
	if(isfile($neo::defaultpref::prefpath))
	{
		exec($neo::defaultpref::prefpath);

		if($neo::pref::prefpath !$= $neo::defaultpref::prefpath && isfile($neo::pref::prefpath))
		{
			exec($neo::pref::prefpath);
		}
	}

	//load profiles
	//these are default, but apparently badspot decided that they don't get loaded until used by a gui
	exec("./profiles/IBBP.cs");
	exec("./profiles/IFBP.cs");
	exec("./profiles/ITP.cs");

	//load the actual everything
	exec("./neomain.cs");
	exec("./overlay.cs");
	exec("./button.cs");
	exec("./addbutton.cs");
	exec("./context.cs");
	exec("./tutorial.cs");
	exec("./options.cs");

	//filter preferences through the options menu to make sure they are valid.
	neo_options.loadvalues();
	neo_options.clickapply();

	while(isobject(neo_keysink))
		neo_keysink.delete();

	if($neo::pref::mainmenuescape)
	{
		%gui = new GuiButtonCtrl(neo_keysink)
		{
			profile = "GuiButtonProfile";
			horizSizing = "left";
			vertSizing = "top";
			position = "-1 -1";
			extent = "1 1";
			minExtent = "1 1";
			enabled = "1";
			visible = "0";
			clipToParent = "1";
			command = "canvas.pushdialog(EscapeMenu);";
			accelerator = "escape";
			text = " ";
			groupNum = "-1";
			buttonType = "PushButton";
		};
		MainMenuButtonsGui.add(%gui);
	}

	if(isfile($neo::pref::datapath))
	{
		exec($neo::pref::datapath);
	}
	else if(isfile($neo::defaultpref::datapath))
	{
		exec($neo::defaultpref::datapath);
	}
	else
	{
		%firstload = true;
	}

	if(isobject(neomain))
		neomain.delete();

	while(isobject(neocommand))
		neocommand.delete();

	%obj = new scriptobject(neomain)
	{
		commandCount = 0;
		modified = true;
		firstload = %firstload;
		lastLoaded = "";
	};

	//$neoCount should not be initialized to zero, but people might do it anyway
	if($neoName0 !$= "")
		%obj.lastLoaded = 0;
	%obj.loaddefaults();
	%obj.loadcustoms();
	%obj.maintain();
}
neo_defaults();
neo_initialize();

