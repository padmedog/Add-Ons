
//Okay, im sure you're asking, wtf is this? Why am i creating datablocks on the client?
//Well, it turns out theres a bug in TGE where you cant send all the sequence data
//for TSShapeConstructors sometimes due to the packet length. Chances are badspot also
//had this problem, and he solved it by having the player shapes name be really short,
//hence "m.dts" and the other files. I tried to do something similar, but due to the
//file structure i needed, i couldnt get a name which was short enough. However,
//creating the datablocks on the client seems to work perfectly. You just gotta remember
//to create them every time the player joins a BRPG server, since datablocks are deleted
//every time you quit a server, and we dont want them for every single server.


new TSShapeConstructor(nDts) {
	baseShape  = "Add-Ons/Client_BoodRPG/PShape/n/n.dts";
	sequence0  = "Add-Ons/Client_BoodRPG/PShape/n/n_root.dsq root";

	sequence1  = "Add-Ons/Client_BoodRPG/PShape/n/n_run.dsq run";
	sequence2  = "Add-Ons/Client_BoodRPG/PShape/n/n_run.dsq walk";
	sequence3  = "Add-Ons/Client_BoodRPG/PShape/n/n_back.dsq back";
	sequence4  = "Add-Ons/Client_BoodRPG/PShape/n/n_side.dsq side";

	sequence5  = "Add-Ons/Client_BoodRPG/PShape/n/n_root.dsq crouch";
	sequence6  = "Add-Ons/Client_BoodRPG/PShape/n/n_run.dsq crouchRun";
	sequence7  = "Add-Ons/Client_BoodRPG/PShape/n/n_back.dsq crouchBack";
	sequence8  = "Add-Ons/Client_BoodRPG/PShape/n/n_side.dsq crouchSide";

	sequence9  = "Add-Ons/Client_BoodRPG/PShape/n/n_look.dsq look";
	sequence10 = "Add-Ons/Client_BoodRPG/PShape/n/n_headside.dsq headside";
	sequence11 = "Add-Ons/Client_BoodRPG/PShape/n/n_headUp.dsq headUp";

	sequence12 = "Add-Ons/Client_BoodRPG/PShape/n/n_standjump.dsq jump";
	sequence13 = "Add-Ons/Client_BoodRPG/PShape/n/n_standjump.dsq standjump";
	sequence14 = "Add-Ons/Client_BoodRPG/PShape/n/n_crouch.dsq fall";
	sequence15 = "Add-Ons/Client_BoodRPG/PShape/n/n_crouch.dsq land";

	sequence16 = "Add-Ons/Client_BoodRPG/PShape/n/n_armAttack.dsq armAttack";
	sequence17 = "Add-Ons/Client_BoodRPG/PShape/n/n_armReadyLeft.dsq armReadyLeft";
	sequence18 = "Add-Ons/Client_BoodRPG/PShape/n/n_armReadyRight.dsq armReadyRight";
	sequence19 = "Add-Ons/Client_BoodRPG/PShape/n/n_armReadyBoth.dsq armReadyBoth";
	sequence20 = "Add-Ons/Client_BoodRPG/PShape/n/n_spearready.dsq spearready";
	sequence21 = "Add-Ons/Client_BoodRPG/PShape/n/n_spearThrow.dsq spearThrow";

	sequence22 = "Add-Ons/Client_BoodRPG/PShape/n/n_talk.dsq talk";

	sequence23 = "Add-Ons/Client_BoodRPG/PShape/n/n_death1.dsq death1";

	sequence24 = "Add-Ons/Client_BoodRPG/PShape/n/n_shiftUp.dsq shiftUp";
	sequence25 = "Add-Ons/Client_BoodRPG/PShape/n/n_shiftDown.dsq shiftDown";
	sequence26 = "Add-Ons/Client_BoodRPG/PShape/n/n_shiftAway.dsq shiftAway";
	sequence27 = "Add-Ons/Client_BoodRPG/PShape/n/n_shiftTo.dsq shiftTo";
	sequence28 = "Add-Ons/Client_BoodRPG/PShape/n/n_shiftLeft.dsq shiftLeft";
	sequence29 = "Add-Ons/Client_BoodRPG/PShape/n/n_shiftRight.dsq shiftRight";
	sequence30 = "Add-Ons/Client_BoodRPG/PShape/n/n_rotCW.dsq rotCW";
	sequence31 = "Add-Ons/Client_BoodRPG/PShape/n/n_rotCCW.dsq rotCCW";

	sequence32 = "Add-Ons/Client_BoodRPG/PShape/n/n_undo.dsq undo";
	sequence33 = "Add-Ons/Client_BoodRPG/PShape/n/n_plant.dsq plant";

	sequence34 = "Add-Ons/Client_BoodRPG/PShape/n/n_root.dsq sit";

	sequence35 = "Add-Ons/Client_BoodRPG/PShape/n/n_wrench.dsq wrench";

	sequence36 = "Add-Ons/Client_BoodRPG/PShape/n/n_activate.dsq activate";
	sequence37 = "Add-Ons/Client_BoodRPG/PShape/n/n_activate2.dsq activate2";

	sequence38 = "Add-Ons/Client_BoodRPG/PShape/n/n_leftrecoil.dsq leftrecoil";
};

//This kinda works, gonna have to lock crouch(1) on client side, else when still, it plays root
//Changing root to crouch does weird shit, dont do it, doesnt look good.
new TSShapeConstructor(cDts) {
	baseShape  = "Add-Ons/Client_BoodRPG/PShape/c/c.dts";
	sequence0  = "Add-Ons/Client_BoodRPG/PShape/c/c_root.dsq root";

	sequence1  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchRun.dsq run";
	sequence2  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchRun.dsq walk";
	sequence3  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchBack.dsq back";
	sequence4  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchSide.dsq side";

	sequence5  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouch.dsq crouch";
	sequence6  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchRun.dsq crouchRun";
	sequence7  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchBack.dsq crouchBack";
	sequence8  = "Add-Ons/Client_BoodRPG/PShape/c/c_crouchSide.dsq crouchSide";

	sequence9  = "Add-Ons/Client_BoodRPG/PShape/c/c_look.dsq look";
	sequence10 = "Add-Ons/Client_BoodRPG/PShape/c/c_headside.dsq headside";
	sequence11 = "Add-Ons/Client_BoodRPG/PShape/c/c_headUp.dsq headUp";

	sequence12 = "Add-Ons/Client_BoodRPG/PShape/c/c_standjump.dsq jump";
	sequence13 = "Add-Ons/Client_BoodRPG/PShape/c/c_standjump.dsq standjump";
	sequence14 = "Add-Ons/Client_BoodRPG/PShape/c/c_crouch.dsq fall";
	sequence15 = "Add-Ons/Client_BoodRPG/PShape/c/c_crouch.dsq land";

	sequence16 = "Add-Ons/Client_BoodRPG/PShape/c/c_armAttack.dsq armAttack";
	sequence17 = "Add-Ons/Client_BoodRPG/PShape/c/c_armReadyLeft.dsq armReadyLeft";
	sequence18 = "Add-Ons/Client_BoodRPG/PShape/c/c_armReadyRight.dsq armReadyRight";
	sequence19 = "Add-Ons/Client_BoodRPG/PShape/c/c_armReadyBoth.dsq armReadyBoth";
	sequence20 = "Add-Ons/Client_BoodRPG/PShape/c/c_spearready.dsq spearready";
	sequence21 = "Add-Ons/Client_BoodRPG/PShape/c/c_spearThrow.dsq spearThrow";

	sequence22 = "Add-Ons/Client_BoodRPG/PShape/c/c_talk.dsq talk";

	sequence23 = "Add-Ons/Client_BoodRPG/PShape/c/c_death1.dsq death1";

	sequence24 = "Add-Ons/Client_BoodRPG/PShape/c/c_shiftUp.dsq shiftUp";
	sequence25 = "Add-Ons/Client_BoodRPG/PShape/c/c_shiftDown.dsq shiftDown";
	sequence26 = "Add-Ons/Client_BoodRPG/PShape/c/c_shiftAway.dsq shiftAway";
	sequence27 = "Add-Ons/Client_BoodRPG/PShape/c/c_shiftTo.dsq shiftTo";
	sequence28 = "Add-Ons/Client_BoodRPG/PShape/c/c_shiftLeft.dsq shiftLeft";
	sequence29 = "Add-Ons/Client_BoodRPG/PShape/c/c_shiftRight.dsq shiftRight";
	sequence30 = "Add-Ons/Client_BoodRPG/PShape/c/c_rotCW.dsq rotCW";
	sequence31 = "Add-Ons/Client_BoodRPG/PShape/c/c_rotCCW.dsq rotCCW";

	sequence32 = "Add-Ons/Client_BoodRPG/PShape/c/c_undo.dsq undo";
	sequence33 = "Add-Ons/Client_BoodRPG/PShape/c/c_plant.dsq plant";

	sequence34 = "Add-Ons/Client_BoodRPG/PShape/c/c_crouch.dsq sit";

	sequence35 = "Add-Ons/Client_BoodRPG/PShape/c/c_wrench.dsq wrench";

	sequence36 = "Add-Ons/Client_BoodRPG/PShape/c/c_activate.dsq activate";
	sequence37 = "Add-Ons/Client_BoodRPG/PShape/c/c_activate2.dsq activate2";

	sequence38 = "Add-Ons/Client_BoodRPG/PShape/c/c_leftrecoil.dsq leftrecoil";
};