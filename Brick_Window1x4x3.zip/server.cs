//server.cs -- for Brick_Doors, execute all things in here

// test door thing
// datablock fxDTSBrickData ( brickDoorTestData )
// {
	// brickFile = "./dev/testDoor.blb";
	// category = "special";
	// subCategory = "misc";
	// uiName = "Door Test";
	// iconName = "./placeholder";
	// orientationFix = 1;
// };

%error = ForceRequiredAddOn( "Support_Doors" );

if( %error == $Error::AddOn_NotFound )
{
	error("Brick Window1x4x3: Support_Doors is missing somehow, what did you do?");
}
else
{
	exec( "./bricks/window_1x4x3.cs" );
}