// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

if(!$Slayer::Server::Dependencies::Gamemodes)
	exec("Add-ons/Gamemode_Slayer/Dependencies/Gamemodes.cs");
Slayer.Gamemodes.addMode("Team Territory","TT",1,1);

if(!$Slayer::Server::Dependencies::Preferences)
	exec("Add-ons/Gamemode_Slayer/Dependencies/Preferences.cs");
Slayer.Prefs.addPref("Territory","Mode","%mini.TT_mode","list" TAB "0 Standard" TAB "1 Domination",0,1,1,-1,"Rules TT Mode");
Slayer.Prefs.addPref("Territory","Required CP Amount","%mini.TT_winPercent","list" TAB "0 All" TAB "1 3/4" TAB "2 2/3" TAB "3 1/2" TAB "4 1/3" TAB "5 1/4",1,0,1,-1,"Rules TT Mode");
Slayer.Prefs.addPref("Territory","Required Hold Time","%mini.TT_holdTime","int 0 10",1,0,1,-1,"Rules TT Mode");
Slayer.Prefs.addPref("Territory","Domination: Max CP Score","%mini.TT_cpHoldScoreWin","int 5 5000",1000,0,1,-1,"Rules TT Mode");
Slayer.Prefs.addPref("Territory","Domination: Tick Time","%mini.TT_cpHoldTickTime","int 200 5000",500,0,1,0,"Rules TT Mode");

function Slayer_TT_onRules(%mini,%client)
{
	if(%mini.TT_mode == 1)
	{
		messageClient(%client,'',"\c5 + \c3Domination");
	}
	else
	{
		%pref = Slayer.Prefs.getPrefSO("Territory","Required CP Amount");
		%value = %mini.TT_winPercent;
		for(%i=1; %i < getFieldCount(%pref.type); %i++)
		{
			%f = getField(%pref.type,%i);
			if(firstWord(%f) $= %value)
			{
				%val = restWords(%f);
				break;
			}
		}

		messageClient(%client,'',"\c5 +\c3" SPC %val SPC "\c5of the capture points must be controlled in order to win.");
	}
}

function Slayer_TT_onCPCapture(%mini,%brick,%color,%old_color,%client)
{
	if(!%mini.TT_mode)
	{
		%victoryCheck = Slayer_TT_victoryCheck_CPs(%mini,%color);
		%win = getField(%victoryCheck,0);
		%controlled = getField(%victoryCheck,1);
		%required = getField(%victoryCheck,2);
		%teamList = %mini.Teams.getTeamsFromColor(%color,"COM",1);

		%old_victoryCheck = Slayer_TT_victoryCheck_CPs(%mini,%old_color);
		%old_win = getField(%old_victoryCheck,0);
		%old_controlled = getField(%old_victoryCheck,1);
		%old_required = getField(%old_victoryCheck,2);
		%old_teamList = %mini.Teams.getTeamsFromColor(%old_color,"COM",1);

		//CONTROL BROKEN
		if(!%old_win)
		{
			if(%mini.TT_timer[%old_color] !$= "")
			{
				if(%old_teamList !$= "")
				{
					%mini.messageAll('',"<color:ff00ff>" @ %teamList SPC "has broken" SPC %old_teamList @ "\'s hold on\c3" SPC %old_controlled+1 SPC "\c5capture" SPC (%old_controlled+1 == 1 ? "point" : "points") @ ".");
				}
			}

			cancel(%mini.TT_timer[%old_color]);
			%mini.TT_timer[%old_color] = "";
		}

		//CONTROL TAKEN
		if(%win && %mini.TT_timer[%color] $= "")
		{
			%mini.TT_timer[%color] = Slayer_TT_winTick(%mini,%color,0);

			%time = %mini.TT_holdTime;
			if(%time > 0)
				%mini.messageAll('',"<color:ff00ff>" @ %teamList SPC "has control of \c3" @ %controlled SPC "\c5capture" SPC (%controlled == 1 ? "point" : "points") @ ". They will win in \c3" @ %time SPC (%time == 1 ? "\c5minute" : "\c5minutes") SPC "if they can maintain control.");
		}
	}
}

function Slayer_TT_postVictory(%mini,%winner,%nameList)
{
	Slayer_TT_cleanUp(%mini);

	if(!%mini.TT_mode)
	{
		%CPs = Slayer.capturePoints;
		%numCPs = %CPs.getCount();

		switch(%mini.TT_winPercent)
		{
			case 0:
				%val = 1;
			case 1:
				%val = 3/4;
			case 2:
				%val = 2/3;
			case 3:
				%val = 1/2;
			case 4:
				%val = 1/3;
			case 5:
				%val = 1/4;
		}

		for(%i=0; %i < getFieldCount(%winner); %i++)
		{
			%w = getField(%winner,%i);
			if(%w.class !$= "Slayer_TeamSO")
				continue;	

			%count = 0;
			for(%c=0; %c < %numCPs; %c++)
			{
				%cp = %CPs.getObject(%c);
				if(!minigameCanUse(%mini,%c))
					continue;

				if(%cp.getColorID() == %w.color)
					%count ++;
			}

			%mini.messageAll('',"\c5 +" SPC %w.getColoredName() SPC "\c5captured\c3" SPC %count SPC "\c5of the required\c3" SPC mCeil(%val*%numCPs) SPC "\c5capture points.");
		}
	}
}

function Slayer_TT_postReset(%mini,%client)
{
	Slayer_TT_cleanUp(%mini);

	if(%mini.TT_mode)
		Slayer_TT_cpHoldTick(%mini,0);
}

function Slayer_TT_onModeEnd(%mini)
{
	Slayer_TT_cleanUp(%mini,1);
}

function Slayer_TT_winTick(%mini,%color,%ticks)
{
	cancel(%mini.TT_timer[%color]);

	if(%mini.TT_mode)
		return;

	%time = %mini.TT_holdTime;
	%remain = %time - %ticks;

	%victoryCheck = Slayer_TT_victoryCheck_CPs(%mini,%color);
	%win = getField(%victoryCheck,0);
	%controlled = getField(%victoryCheck,1);
	%required = getField(%victoryCheck,2);

	Slayer_Support::Debug(2, "Slayer_TT_winTick", %ticks @ "/" @ %time);

	//end the round?
	if(%ticks >= %time)
	{
		%mini.TT_timer[%color] = "";

		if(%win)
		{
			%teams = %mini.Teams.getTeamsFromColor(%color,"TAB");
			%mini.endRound(%teams);
		}
		return;
	}
	//announce how much time is left
	else if(%ticks > 0)
	{
		if(%remain <= 5)
			%announce = 1;
		if(%remain % 10 == 0) //check if it's a multiple of 10
			%announce = 1;

		if(%announce)
		{
			%teamList = %mini.Teams.getTeamsFromColor(%color,"COM",1);
			%mini.messageAll('',"<color:ff00ff>" @ %teamList SPC "will win in\c3" SPC %remain SPC (%remain == 1 ? "\c5minute" : "\c5minutes") SPC "if they can maintain control of\c3" SPC %required SPC (%required == 1 ? "\c5capture point" : "\c5capture points") @ ".");
		}
	}

	%mini.TT_timer[%color] = schedule(60000,0,Slayer_TT_winTick,%mini,%color,%ticks++);
}

function Slayer_TT_cpHoldTick(%mini,%ticks)
{
	if(!%mini.TT_mode)
		return;

	cancel(%mini.TT_timer[0]); //we simply reuse the old timer vars

	for(%i=0; %i < Slayer.capturePoints.getCount(); %i++)
	{
		%cp = Slayer.capturePoints.getObject(%i);
		if(!minigameCanUse(%mini,%cp))
			continue;

		%color = %cp.getColorID();
		%teams = %mini.Teams.getTeamsFromColor(%color,"TAB");
// echo("COLOR:" SPC %color SPC "TEAMLIST:" SPC %teams);
		for(%e=0; %e < getFieldCount(%teams); %e++)
		{
			%t = getField(%teams,%e);

			%t.TT_cpHoldScore ++;
// echo("TEAM:" SPC %t SPC "SCORE:" SPC %t.TT_cpHoldScore);
			if(%t.TT_cpHoldScore >= %mini.TT_cpHoldScoreWin && !Slayer_Support::isItemInList(%winners,%t))
			{
				%winners = setField(%winners,getFieldCount(%winners),%t);
// echo("WIN:" SPC %t);
			}
		}
	}

	if(%winners !$= "")
	{
// echo("WINNERS:" SPC %winners);
		%mini.endRound(%winners);
		return;
	}

	if(%ticks % 25 == 0)
	{
		%cnt = %mini.Teams.getCount();
		if(%cnt > 0)
		{
			if(%mini.TT_currentDisplayTeam $= "")
				%mini.TT_currentDisplayTeam = 0;
			else
			{
				if(%cnt > %mini.TT_currentDisplayTeam + 1)
					%mini.TT_currentDisplayTeam ++;
				else
					%mini.TT_currentDisplayTeam = 0;
			}
			%team = %mini.Teams.getObject(%mini.TT_currentDisplayTeam);
			%mini.centerPrintAll("<just:right>" @ %team.getColoredName() @ "\c5:" NL "\c3" @ %team.TT_cpHoldScore @ "\c5/\c3" @ %mini.TT_cpHoldScoreWin);
		}
	}

	%mini.TT_timer[0] = schedule(%mini.TT_cpHoldTickTime,0,Slayer_TT_cpHoldTick,%mini,%ticks++);
}

function Slayer_TT_victoryCheck_CPs(%mini,%color)
{
	if(%mini.TT_mode)
		return;

	%CPs = Slayer.capturePoints;
	%numCPs = %CPs.getCount();

	%count = 0;
	for(%i=0; %i < %numCPs; %i++)
	{
		%c = %CPs.getObject(%i);
		if(!minigameCanUse(%mini,%c))
			continue;

		if(%c.getColorID() == %color)
			%count ++;
	}

	switch(%mini.TT_winPercent)
	{
		case 0:
			%val = 1;
		case 1:
			%val = 3/4;
		case 2:
			%val = 2/3;
		case 3:
			%val = 1/2;
		case 4:
			%val = 1/3;
		case 5:
			%val = 1/4;
	}

	%required = mCeil(%val*%numCPs);

	return (%count >= %required) TAB %count TAB %required;
}

function Slayer_TT_cleanUp(%mini,%end)
{
	for(%i=0; %i < 64; %i++)
	{
		cancel(%mini.TT_timer[%i]);
		%mini.TT_timer[%i] = "";
	}

	for(%i=0; %i < %mini.Teams.getCount(); %i++)
	{
		%team = %mini.Teams.getObject(%i);
		if(%end)
			%team.TT_cpHoldScore = "";
		else
			%team.TT_cpHoldScore = 0;
	}
}