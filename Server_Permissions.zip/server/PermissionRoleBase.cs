if (!isObject(PermissionRoleBase))
    new ScriptObject(PermissionRoleBase);

function PermissionRoleBase::hasPermission(%this, %permission, %recurse) {
    if (%recurse $= "")
        %recurse = true;
    %this.permission[%permission] += 0;
    %has = %this.permission[%permission];
    if (%has == 0 && %recurse && isObject(%this.parent)) {
        %has = %this.parent.hasPermission(%permission);
    }
    return %has;
}

function PermissionRoleBase::setPermission(%this, %permission, %value) {
    %this.permission[%permission] = %value;
}
