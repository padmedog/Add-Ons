//Made by: Lordician

//Ping-Pong is from the compass mod. All credits go to the original creator for this.
//This is a safe and good way to check if the server has the mod and if the client has the clientside.
function clientcmdHC_client_ping(%x)
{
	commandtoserver('HC_client_pong',%x);
	$HCServer = 1;
}

package supportheightcontrol
{
	function crouch(%val)
	{
		if($HCServer)
		{
			if(%val==1)
				commandtoserver('hoverDescend');
			else
				commandtoserver('hoverStop');
		}
		Parent::crouch(%val);
	}
	function jump(%val)
	{
		if($HCServer)
		{
			if(%val==1)
				commandtoserver('hoverAscend');
			else
				commandtoserver('hoverStop');
		}
		Parent::jump(%val);
	}
	function disconnect(%a)
	{
		if($HCServer)
		{
			commandtoserver('hoverStop');
			$HCServer = 0;
		}
		Parent::disconnect(%a);
	}
};
activatePackage(supportheightcontrol);