function modNewPlayerListGui()
{
	if($moddedPlayerList)
		return;
	$moddedPlayerList = true;

	if(!isFile("add-ons/client_mute/client.cs"))
	{

	NPL_Window.extent = "600 332";
	NPL_Scroll.extent = "480 267";
	NPL_List.extent = "480 20";
	NPL_ScrollBG.extent = "470 267";

	NPL_Window.getObject(0).position = "505 70"; //build
	NPL_Window.getObject(1).position = "505 93"; //full
	NPL_Window.getObject(5).position = "68 33"; //name button
	NPL_Window.getObject(6).position = "167 33"; //score
	NPL_Window.getObject(7).position = "233 33"; //blid
	NPL_Window.getObject(8).position = "297 33"; //trust
	NPL_Trust2Button.position = "495 283"; //object 9
	NPL_Window.getObject(10).position = "515 51"; //"trust invite"
	NPL_Window.getObject(11).position = "515 115"; //"trust demote"
	NPL_Window.getObject(12).position = "505 134"; //no trust
	NPL_Window.getObject(13).position = "505 157"; //build
	NPL_TrustInviteBuildBlocker.position = "489 69"; //object 14
	NPL_TrustInviteFullBlocker.position = "489 91"; //15
	NPL_TrustRemoveBuildBlocker.position = "489 132"; //16
	NPL_TrustRemoveFullBlocker.position = "489 156"; //object 17
	NPL_Window.getObject(18).position = "515 178"; //"mini-game"
	NPL_Window.getObject(19).position = "505 197"; //invite
	NPL_Window.getObject(20).position = "505 220"; //remove
	NPL_MiniGameInviteBlocker.position = "489 195"; //21
	NPL_MiniGameRemoveBlocker.position = "489 219"; //object 22
	NPL_Window.getObject(23).position = "505 260"; //un-ignore
	NPL_UnIgnoreBlocker.position = "489 259"; //object 24

	NPL_List.columns = "0 50 170 225 290 355 425";

      new GuiBitmapButtonCtrl(StatOneButton) {
         profile = "BlockButtonProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "357 33";
         extent = "54 19";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         command = "NewPlayerListGui.sortList(5);";
         text = "One";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "base/client/ui/button1";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "1";
         mColor = "255 255 255 255";
            wrap = "0";
      };
      new GuiBitmapButtonCtrl(StatTwoButton) {
         profile = "BlockButtonProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "421 33";
         extent = "54 19";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         command = "NewPlayerListGui.sortList(6);";
         text = "Two";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "base/client/ui/button1";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "1";
         mColor = "255 255 255 255";
            wrap = "0";
      };

	NPL_Window.add(StatOneButton);
	NPL_Window.add(StatTwoButton);

	}
	else
	{
		NPL_Window.extent = "600 385";
		NPL_Scroll.extent = "480 320";
		NPL_List.extent = "480 20";
		NPL_ScrollBG.extent = "470 320";
		
		NPL_Window.getObject(0).position = "507 70"; //build
		NPL_Window.getObject(1).position = "507 93"; //full
		NPL_Window.getObject(5).position = "68 33"; //name button
		NPL_Window.getObject(6).position = "167 33"; //score
		NPL_Window.getObject(7).position = "233 33"; //blid
		NPL_Window.getObject(8).position = "297 33"; //trust
		NPL_Trust2Button.position = "495 336"; //object 9
		NPL_Window.getObject(10).position = "517 51"; //"trust invite"
		NPL_Window.getObject(11).position = "517 115"; //"trust demote"
		NPL_Window.getObject(12).position = "507 134"; //no trust
		NPL_Window.getObject(13).position = "507 157"; //build
		NPL_TrustInviteBuildBlocker.position = "489 69"; //object 14
		NPL_TrustInviteFullBlocker.position = "489 91"; //15
		NPL_TrustRemoveBuildBlocker.position = "489 132"; //16
		NPL_TrustRemoveFullBlocker.position = "489 156"; //object 17
		NPL_Window.getObject(18).position = "517 178"; //"mini-game"
		NPL_Window.getObject(19).position = "507 197"; //invite
		NPL_Window.getObject(20).position = "507 220"; //remove
		NPL_MiniGameInviteBlocker.position = "489 195"; //21
		NPL_MiniGameRemoveBlocker.position = "489 219"; //object 22
		NPL_Window.getObject(23).position = "507 244"; //un-ignore
		NPL_UnIgnoreBlocker.position = "489 244"; //object 24
		
		NPL_Window.getObject(25).position = "507 305";
		NPL_Window.getObject(26).position = "517 263";
		NPL_Window.getObject(27).position = "507 282";
		NPL_UnMuteBlocker.position = "491 304";
		NPL_MuteBlocker.position = "491 281";

	NPL_List.columns = "0 50 170 225 290 355 425";

      new GuiBitmapButtonCtrl(StatOneButton) {
         profile = "BlockButtonProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "357 33";
         extent = "54 19";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         command = "NewPlayerListGui.sortList(5);";
         text = "One";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "base/client/ui/button1";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "1";
         mColor = "255 255 255 255";
            wrap = "0";
      };
      new GuiBitmapButtonCtrl(StatTwoButton) {
         profile = "BlockButtonProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "421 33";
         extent = "54 19";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         command = "NewPlayerListGui.sortList(6);";
         text = "Two";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "base/client/ui/button1";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "1";
         mColor = "255 255 255 255";
            wrap = "0";
      };

	NPL_Window.add(StatOneButton);
	NPL_Window.add(StatTwoButton);
	}
}

function restoreNewPlayerListGui()
{
	if(!$moddedPlayerList)
		return;

	$moddedPlayerList = false;

	if(isObject(StatOneButton))
		StatOneButton.delete();
	if(isObject(StatTwoButton))
		StatTwoButton.delete();

	NPL_Window.extent = "489 332";
	NPL_Scroll.extent = "369 267";
	NPL_List.extent = "353 2";
	NPL_ScrollBG.extent = "369 267";

	NPL_Window.getObject(0).position = "405 70"; //build
	NPL_Window.getObject(1).position = "405 93"; //full
	NPL_Window.getObject(5).position = "75 33"; //name button
	NPL_Window.getObject(6).position = "181 33"; //score
	NPL_Window.getObject(7).position = "252 33"; //blid
	NPL_Window.getObject(8).position = "312 33"; //trust
	NPL_Trust2Button.position = "385 283"; //object 9
	NPL_Window.getObject(10).position = "385 51"; //"trust invite"
	NPL_Window.getObject(11).position = "385 115"; //"trust demote"
	NPL_Window.getObject(12).position = "405 134"; //no trust
	NPL_Window.getObject(13).position = "405 157"; //build
	NPL_TrustInviteBuildBlocker.position = "389 69"; //object 14
	NPL_TrustInviteFullBlocker.position = "389 91"; //15
	NPL_TrustRemoveBuildBlocker.position = "389 132"; //16
	NPL_TrustRemoveFullBlocker.position = "389 156"; //object 17
	NPL_Window.getObject(18).position = "385 178"; //"mini-game"
	NPL_Window.getObject(19).position = "405 197"; //invite
	NPL_Window.getObject(20).position = "405 220"; //remove
	NPL_MiniGameInviteBlocker.position = "389 195"; //21
	NPL_MiniGameRemoveBlocker.position = "389 219"; //object 22
	NPL_Window.getObject(23).position = "405 260"; //un-ignore
	NPL_UnIgnoreBlocker.position = "389 259"; //object 24
}

function clientcmdstatOneName(%name,%number)
{
	modNewPlayerListGui();
	StatOneButton.text = %name;
	if(%number == 1)
		StatOneButton.command = "NewPlayerListGui.sortList(5);";
	else
		StatOneButton.command = "NewPlayerListGui.sortNumList(5);";
}

function clientcmdstatTwoName(%name,%number)
{
	modNewPlayerListGui();
	StatTwoButton.text = %name;
	if(%number == 1)
		StatTwoButton.command = "NewPlayerListGui.sortList(6);";
	else
		StatTwoButton.command = "NewPlayerListGui.sortNumList(6);";
}


function clientcmdsetStatOne(%client,%value)
{
	modNewPlayerListGui();
	$statOne[%client] = %value;
}

function clientcmdsetStatTwo(%client,%value)
{
	modNewPlayerListGui();
	$statTwo[%client] = %value;
}

function getPlayerStatOne(%client)
{
	return $statOne[%client];
}

function getPlayerStatTwo(%client)
{
	return $statTwo[%client];
}

package playerStats
{
	function disconnectedCleanup(%bool)
	{
		deleteVariables("$statOne*");
		deleteVariables("$statTwo*");
		restoreNewPlayerListGui();
		parent::disconnectedCleanup(%bool);
	}

	function NPL_List::addRow(%this,%client,%text,%index)
	{
		if($moddedPlayerList)
		{
			if(NPL_List.columns !$= "0 50 170 225 290 355 425")
				NPL_List.columns = "0 50 170 225 290 355 425";
			%text = getField(%text,0) TAB getField(%text,1) TAB getField(%text,2) TAB getField(%text,3) TAB  getPlayerStatOne(%client) TAB getPlayerStatTwo(%client);
		}
		return Parent::addRow(%this,%client,%text,%index);
	}

	function NPL_List::setRowByID(%this,%client,%text)
	{
		if($moddedPlayerList)
		{
			if(NPL_List.columns !$= "0 50 170 225 290 355 425")
				NPL_List.columns = "0 50 170 225 290 355 425";
			%text = getField(%text,0) TAB getField(%text,1) TAB getField(%text,2) TAB getField(%text,3) TAB  getField(%text,4) TAB getPlayerStatOne(%client) TAB getPlayerStatTwo(%client);
		}
		Parent::setRowByID(%this,%client,%text);
	}
};
activatepackage(playerStats);
