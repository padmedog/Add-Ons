//########## Firebomb

//### Effects

datablock ParticleData(gc_FirebombExplosionParticle)
{
  dragCoefficient = 2;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 500;
  lifetimeVarianceMS = 250;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 1 1 1";
  colors[1] = "1 0.5 0 1";
  colors[2] = "1 0 0 0";
  sizes[0] = 4;
  sizes[1] = 6;
  sizes[2] = 8;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FirebombExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 10;
  ejectionOffset = 4;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FirebombExplosionParticle";
};

datablock ParticleData(gc_FirebombSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 10;
  sizes[1] = 20;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_FirebombSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 6;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 1;
  ejectionOffset = 4;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FirebombSmokeParticle";
};

datablock ExplosionData(gc_FirebombExplosion)
{
  lifeTimeMS = 200;
  emitter[0] = gc_FirebombExplosionEmitter;
  emitter[1] = gc_FirebombSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 6;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 8;
  radiusDamage = 50;
  impulseRadius = 12;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 16;
};

//### Projectile

AddDamageType("gc_Firebomb",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_firebomb> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_firebomb> %1',0.2,1);

datablock ProjectileData(gc_FirebombProjectile)
{
  uiName = "";
  projectileShapeName = "./firebomb_projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_Firebomb;
  radiusDamageType = $DamageType::gc_Firebomb;
  brickExplosionRadius = 6;
  brickExplosionImpact = false;
  brickExplosionForce = 20;
  brickExplosionMaxVolume = 50;
  brickExplosionMaxVolumeFloating = 50;
  impactImpulse = 0;
  explosion = gc_FireBombExplosion;
  particleEmitter = gc_FLBombTrailEmitter;
  muzzleVelocity = 30;
  verInheritFactor = 0;
  armingDelay = 3000;
  lifetime = 3000;
  fadeDelay = 3000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = true;
  explodeOnPlayerImpact = true;
  sound = gc_FuzeSound;
};

//### Item

datablock ItemData(gc_FirebombItem)
{
  uiName = "Fire Bomb";
  iconName = "./icon_firebomb";
  image = gc_FirebombImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./firebomb.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
  canPickupMultiple = true;
};

//### Item Image

datablock shapeBaseImageData(gc_FirebombImage)
{
  shapeFile = "./firebomb.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_FirebombItem;
  ammo = "";
  projectile = gc_FirebombProjectile;
  projectileType = Projectile;
  casing = "";
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Charge";
  stateAllowImageChange[1] = true;

  stateName[2] = "Charge";
  stateTransitionOnTimeout[2] = "Armed";
  stateTimeoutValue[2] = 0.2;
  stateWaitForTimeout[2] = false;
  stateTransitionOnTriggerUp[2] = "AbortCharge";
  stateScript[2] = "onCharge";
  stateAllowImageChange[2] = false;
  stateSound[2] = gc_FuzeSound;
  stateEmitter[2] = gc_FuzeImageEmitter;
  stateEmitterTime[2] = 0.2;
  stateEmitterNode[2] = "upPoint";

  stateName[3] = "AbortCharge";
  stateTransitionOnTimeout[3] = "Ready";
  stateTimeoutValue[3] = 0.3;
  stateWaitForTimeout[3] = true;
  stateScript[3] = "onAbortCharge";
  stateAllowImageChange[3] = false;

  stateName[4] = "Armed";
  stateTransitionOnTriggerUp[4] = "Fire";
  stateAllowImageChange[4] = false;
  stateSound[4] = gc_FuzeSound;
  stateEmitter[4] = gc_FuzeImageEmitter;
  stateEmitterTime[4] = 1;
  stateEmitterNode[4] = "upPoint";
  stateTransitionOnTimeout[4] = "Armed";
  stateTimeoutValue[4] = 1;
  stateWaitForTimeout[4] = false;

  stateName[5] = "Fire";
  stateTransitionOnTimeout[5] = "Ready";
  stateTimeoutValue[5] = 0.2;
  stateFire[5] = true;
  stateSequence[5] = "Fire";
  stateScript[5] = "onFire";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = false;
};

function gc_FirebombImage::onCharge(%this,%obj,%slot)
{
  %obj.playThread(2,shiftLeft);
  %obj.lastGrenadeSlot = %obj.currTool;
  %obj.CookingTastyGrenades = schedule(3000,0,gc_CookedFirebomb,%obj);
  %obj.CookingTime = getSimTime();
}

function gc_FirebombImage::onAbortCharge(%this,%obj,%slot) {
  %obj.playthread(2,root);
  cancel(%obj.CookingTastyGrenades); }
function gc_FirebombImage::onUnMount(%this,%obj,%slot) {
  cancel(%obj.CookingTastyGrenades);
  parent::onUnMount(%this,%obj,%slot); }

function gc_FirebombImage::onFire(%this,%obj,%slot)
{
  %obj.playthread(2,activate);
  cancel(%obj.CookingTastyGrenades);
  if((getSimTime()-%obj.CookingTime) >= 2900) return;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity);
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  %p.schedule(3000-(getSimTime()-%obj.CookingTime),Explode);
  MissionCleanup.add(%p);
  %currSlot = %obj.lastGrenadeSlot;
  %obj.tool[%currSlot] = 0;
  %obj.weaponCount--;
  messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
  serverCmdUnUseTool(%obj.client);
}

function gc_CookedFirebomb(%obj)
{
  %currSlot = %obj.lastGrenadeSlot;
  %obj.tool[%currSlot] = 0;
  %obj.weaponCount--;
  messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
  serverCmdUnUseTool(%obj.client);
  %p = new Projectile()
  {
    dataBlock = gc_FirebombProjectile;
    initialVelocity = 0;
    initialPosition = %obj.getPosition();
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  %p.schedule(50,Explode);
  MissionCleanup.add(%p);
}

function gc_FirebombProjectile::onExplode(%this,%obj,%pos,%a)
{
  InitContainerRadiusSearch(%obj.getPosition(),7,$TypeMasks::PlayerObjectType);
  while((%target = containerSearchNext()) != 0) {
    if(miniGameCanDamage(%obj,%target) && getMiniGameFromObject(%target) != -1) gc_burning(%target,20,%obj); }
  parent::onExplode(%this,%obj,%pos,%a);
}
