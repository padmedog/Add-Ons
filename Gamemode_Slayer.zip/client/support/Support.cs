// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

$Slayer::Client::Support::Main = 1;

// +-------------------------+
// | Stuff for finding stuff |
// +-------------------------+
function SlayerClient_Support::getIDFromUiName(%uiName,%className)
{
	if(serverConnection.isLocal())
		%group = datablockGroup;
	else
		%group = serverConnection;

	%count = %group.getCount();
	for(%i=0; %i < %count; %i++)
	{
		%obj = %group.getObject(%i);
		%cn = %obj.getClassName();
		%ui = %obj.uiName;
		if(%ui $= "")
			continue;
		if(%cn $= "MissionArea")
			break;
		if(%ui $= %uiName)
		{
			if(%className $= "" || %cn $= %className)
			{
				return %obj;
			}
		}
	}
	return 0;
}

// +-----+
// | GUI |
// +-----+
function SlayerClient_Support::addKeyBind(%div,%name,%cmd,%device,%action,%overWrite)
{
	%divIndex = -1;
	for(%i = 0; %i < $RemapCount; %i ++)
	{
		if($RemapDivision[%i] $= %div)
		{
			for(%e = %i; %e < $RemapCount; %e ++)
			{
				if($RemapDivision[%e] !$= $RemapDivision[%i] && $RemapDivision[%e] !$= "")
				{
					break;
				}

				if($RemapName[%e] $= %name)
				{
					return;
				}
			}
			%divIndex = %i;
			break;
		}
	}

	if(%divIndex >= 0)
	{
		for(%i=$RemapCount-1; %i > %divIndex; %i--)
		{
			$RemapDivision[%i+1] = $RemapDivision[%i];
			$RemapName[%i+1] = $RemapName[%i];
			$RemapCmd[%i+1] = $RemapCmd[%i];
		}

		$RemapDivision[%divIndex+1] = "";
		$RemapName[%divIndex+1] = %name;
		$RemapCmd[%divIndex+1] = %cmd;
		$RemapCount ++;
	}
	else
	{
		$RemapDivision[$RemapCount] = %div;
		$RemapName[$RemapCount] = %name;
		$RemapCmd[$RemapCount] = %cmd;
		$RemapCount ++;
	}

	if(%device !$= "" && %action !$= "")
	{
		if(moveMap.getCommand(%device,%action) $= "" || %overWrite)
			moveMap.bind(%device,%action,%cmd);
	}
}

function SlayerClient_Support::removeKeyBind(%div,%name,%cmd)
{
	%binding = moveMap.getBinding(%cmd);
	%device = getField(%binding,0);
	%action = getField(%binding,1);

	if(%device !$= "" && %action !$= "")
		moveMap.unBind(%device,%action);

	for(%i=0; %i < $RemapCount; %i++)
	{
		%d = $RemapDivision[%i];
		%n = $RemapName[%i];
		%c = $RemapCmd[%i];

		%start = 0;

		if(%n $= %name && %c $= %cmd && (%d $= %div || %lastDiv $= %div))
		{
			%start = %i + 1;
			break;
		}

		if(%d !$= "")
			%lastDiv = %d;
	}

	if(%start > 0)
	{
		for(%i=%start; %i < $RemapCount; %i++)
		{
			$RemapDivision[%i-1] = $RemapDivision[%i];
			$RemapName[%i-1] = $RemapName[%i];
			$RemapCmd[%i-1] = $RemapCmd[%i];
		}

		%d = $RemapDivision[%start-1];
		if(%d $= "")
			$RemapDivision[%start-1] = %div;

		$RemapDivision[$RemapCount-1] = "";
		$RemapName[$RemapCount-1] = "";
		$RemapCmd[$RemapCount-1] = "";

		$RemapCount --;
	}
}

// +-------+
// | Debug |
// +-------+
function SlayerClient_Support::Debug(%level,%title,%value)
{
	if($Slayer::Client::Debug == -1)
		return;

	if(%value $= "")
		%val = %title;
	else
		%val = %title @ ":" SPC %value; 

	if(%level <= $Slayer::Client::Debug)
		echo("\c4Slayer (Client):" SPC %val);

	%path = $Slayer::Client::ConfigDir @ "/debug_client.log";
	if(isWriteableFileName(%path))
	{
		if(!isObject(SlayerClient.DebugFO))
		{
			SlayerClient.debugFO = new fileObject();
			SlayerClient.add(SlayerClient.debugFO);

			SlayerClient.debugFO.openForWrite(%path);
			SlayerClient.debugFO.writeLine("//Slayer Version" SPC $Slayer::Client::Version SPC "-----" SPC getDateTime());
			SlayerClient.debugFO.writeLine("//By Greek2me, Blockland ID 11902");
		}

		SlayerClient.debugFO.writeLine(%val);
	}
}

function SlayerClient_Support::Error(%title,%value)
{
	if(%value $= "")
		%val = %title;
	else
		%val = %title @ ":" SPC %value; 

	error("Slayer Error (Client):" SPC %val);

	%path = $Slayer::Client::ConfigDir @ "/debug_client.log";
	if(isWriteableFileName(%path))
	{
		if(!isObject(SlayerClient.debugFO))
		{
			SlayerClient.debugFO = new fileObject();
			SlayerClient.add(SlayerClient.debugFO);

			SlayerClient.debugFO.openForWrite(%path);
			SlayerClient.debugFO.writeLine("//Slayer Version" SPC $Slayer::Client::Version SPC "-----" SPC getDateTime());
			SlayerClient.debugFO.writeLine("//By Greek2me, Blockland ID 11902");
		}

		SlayerClient.debugFO.writeLine("ERROR:" SPC %val);
	}
}