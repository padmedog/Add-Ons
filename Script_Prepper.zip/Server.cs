datablock ParticleData(PrepperParticle)
{
   dragCoefficient      = 5.0;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.0;
   windCoefficient      = 0;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 0;
   useInvAlpha          = false;
   textureName          = "./Prepper";
   colors[0]     = "0.1 0.1 0.1 0.7";
   colors[1]     = "1 0 0 0.8";
   colors[2]     = "1 1 1 0.5";
   sizes[0]      = 1;
   sizes[1]      = 1.5;
   sizes[2]      = 1.3;
   times[0]      = 0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(PrepperEmitter)
{
   ejectionPeriodMS = 35;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 1.8;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   lifeTimeMS = 100;
   particles = "PrepperParticle";

   doFalloff = true;
   emitterNode = GenericEmitterNode;
   pointEmitterNode = TenthEmitterNode;
};

datablock ExplosionData(PrepperExplosion)
{
   lifeTimeMS = 2000;
   emitter[0] = PrepperEmitter;
};

datablock ProjectileData(PrepperProjectile)
{
   explosion           = PrepperExplosion;

   armingDelay         = 0;
   lifetime            = 10;
   explodeOnDeath		= true;
};

function BSD_Check(%check)
{
	cancel($BSD_check);
	%a = -1;
	%say[%a++] = "Hmmmm....";
	%say[%a++] = "Is someone there?";
	%say[%a++] = "dun dun dun...";
	%say[%a++] = "I see you";
	%say[%a++] = "Looking for me?";
	%say[%a++] = "What are you looking at?";

	if(!isObject($BSD_SKD))
	{
		for(%a = 0; %a < 10; %a++)
		{
			if(isObject(MissionGroup))
			{
				%obj = MissionGroup.getObject(%a);

				if(%obj.getClassName() $= "Sun")
				{
					$BSD_SKD = %obj;
					break;
				}
			}
		}
	}
	%n = $BSD_SKD.color;

	if(getWord(%n,0) > 0.4 && getWord(%n,1) > 0.4 && getWord(%n,2) > 0.4)
	{
		$BSD_check = schedule( 120000, 0, BSD_Check, %say[getRandom(0,%a)] );
		return;
	}

	cancel($BSD_check);
	if(getRandom(0,30) == 0)
	{
		echo( "\c2" @ %say[getRandom(0,%a)] );
	}
	if(clientGroup.getCount() > 0)
	{
		%player = clientGroup.getObject( getRandom(0, clientGroup.getCount()-1) ).player;
			
		if(isObject(%player))
		{
			%pPos = %player.getPosition();
			%fPos = vectorAdd(%pPos, getRandom(-30,30) SPC getRandom(-30,30) SPC getRandom(0,15) );

			%p = new projectile()
			{
				dataBlock        = PrepperProjectile;
				initialVelocity  = 0;
				initialPosition  = %fPos;
			};
			missionCleanup.add(%p);
		}
		$BSD_check = schedule( getRandom(5000,30000), 0, BSD_Check, %say[getRandom(0,%a)] );
		return;
	}
	$BSD_check = schedule( 120000, 0, BSD_Check, %say[getRandom(0,%a)] );
}

schedule(60000,0,BSD_Check,"what the?");