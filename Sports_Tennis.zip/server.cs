// tennis racquet
// by Carbon Zypher and Filipe1020
datablock AudioDescription(AudioLongTennis3D : AudioClose3d) 
{
	volume = 0.85;
	referenceDistance = 200;
	maxDistance = 400;
};

datablock AudioProfile(tennisRacquetHitSound)
{
	filename	 = "./sound/tennisracquet_hit1.wav";
	description = AudioLongTennis3D;
	preload = true;
};

datablock AudioProfile(tennisRacquetSwingSound)
{
	filename	 = "./sound/tennisracquet_swing1.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(tennisBallBounceSound1)
{
	filename	 = "./sound/tennisball_bounce1.wav";
	description = AudioLongTennis3D;
	preload = true;
};

datablock AudioProfile(tennisBallBounceSound2)
{
	filename	 = "./sound/tennisball_bounce2.wav";
	description = AudioLongTennis3D;
	preload = true;
};

datablock AudioProfile(tennisBallBounceSound3)
{
	filename	 = "./sound/tennisball_bounce3.wav";
	description = AudioLongTennis3D;
	preload = true;
};

datablock ParticleData(tennisRacquetTrailParticle)
{
	dragCoefficient		= 8;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	constantAcceleration = 0.0;
	lifetimeMS			  = 225;
	lifetimeVarianceMS	= 0;
	textureName			 = "base/data/particles/cloud";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]	  = "0.9 0.9 0.9 0.3";
	colors[1]	  = "0.7 0.9 0.7 0.0";
	sizes[0]		= 0.40;
	sizes[1]		= 0.0;
};

datablock ParticleEmitterData(tennisRacquetTrailEmitter)
{
	ejectionPeriodMS = 20;
	periodVarianceMS = 0;
	ejectionVelocity = 0;
	velocityVariance = 0;
	ejectionOffset	= 0;
	thetaMin			= 0;
	thetaMax			= 90;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "tennisRacquetTrailParticle";
};

datablock ParticleData(tennisRacquetExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.3;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]	  = "0.9 0.9 0.9 0.3";
	colors[1]	  = "0.7 0.9 0.7 0.0";
	sizes[0]      = 0.45;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(tennisRacquetExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "tennisRacquetExplosionParticle";
};

datablock ExplosionData(tennisRacquetExplosion)
{
	lifeTimeMS = 150;
	particleEmitter = tennisRacquetExplosionEmitter;
	particleDensity = 5;
	particleRadius = 0.2;
	faceViewer	  = true;
	explosionScale = "1 1 1";
	shakeCamera = false;
};

datablock ProjectileData(tennisRacquetProjectile)
{
	projectileShapeName = "./shapes/tennisball.dts";
	directDamage		  = 0;

	brickExplosionRadius = 0;
	brickExplosionImpact = false;
	brickExplosionForce  = 0;
	brickExplosionMaxVolume = 0;
	brickExplosionMaxVolumeFloating = 0;  

	impactImpulse		  = 0;
	verticalImpulse	  = 0;
	explosion			  = tennisRacquetExplosion;
	particleEmitter	  = tennisRacquetTrailEmitter;

	muzzleVelocity		= 34;
	velInheritFactor	 = 0;
	ballRadius          = 0.35;

	armingDelay			= 5000;
	lifetime				= 5000;
	fadeDelay			  = 3500;
	bounceElasticity	 = 0.90;
	bounceFriction		= 0.10;
	isBallistic			= true;
	gravityMod = 1;
	
	explodeOnDeath = true;
	
	uiName = "Tennis Ball";
};

//item 
datablock ItemData(tennisRacquetItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./shapes/TennisRacketRed.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "Tennis Racquet R";
	iconName = "./shapes/icon_tennis";
	doColorShift = false;
	//colorShiftColor = "0.85 0.00 0.00 1.00";

	image = tennisRacquetImage;
	canDrop = true;
};

//weapon image
datablock ShapeBaseImageData(tennisRacquetImage)
{
	shapeFile = "./shapes/TennisRacketRed.dts";
	emap = true;
	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0; 
	correctMuzzleVector = false;	
	doColorShift = false;
	//colorShiftColor = tennisRacquetItem.colorShiftColor;
	className = "WeaponImage";
	item = BowItem;
	ammo = " ";
	projectile = tennisRacquetProjectile;
	projectileType = Projectile;	
	melee = false;
	armReady = true;
	minShotTime = 500;

	stateName[0]							= "Activate";
	stateTimeoutValue[0]				 = 0.15;
	stateTransitionOnTimeout[0]		 = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]							= "Ready";
	stateTransitionOnTriggerDown[1]  = "serveReady";
	stateAllowImageChange[1]			= true;
	
	stateName[3]							= "serveReady";
	stateTransitionOnTriggerDown[3]  = "Fire";
	stateAllowImageChange[3]			= true;
	
	stateName[4]							= "hitReady";
	stateTransitionOnTriggerDown[4]  = "return";
	stateAllowImageChange[4]			= true;
	
	stateName[5]                    = "Fire";
	stateTransitionOnTimeout[5]     = "hitReady";
	stateTimeoutValue[5]            = 0.14;
	stateFire[5]                    = true;
	stateAllowImageChange[5]        = false;
	stateScript[5]                  = "onFire";
	stateWaitForTimeout[5]			= true;
	stateSound[5]					= tennisRacquetHitSound;
	
	stateName[6]                    = "return";
	stateSound[6]					= tennisRacquetSwingSound;
	stateTransitionOnTimeout[6]     = "wait";
	stateTimeoutValue[6]            = 0.14;
	stateAllowImageChange[6]        = false;
	stateScript[6]                  = "onTRReturn";
	stateWaitForTimeout[6]			= true;
	
	stateName[7] = "wait";
	stateTransitionOnTriggerUp[7] = "hitReady";
};

function tennisRacquetProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{	
	%sound = "tennisBallBounceSound" @ getRandom(1,3);
	serverPlay3D(%sound,%pos);
	
	Parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
}

function tennisRacquetImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
	{
		%obj.playThread(2, shiftTo);
		%obj.playThread(0, shiftTo); 
	}
	
	if(%obj.getMountedImage(1).getName() $= "tennisBallLeftHandImage") 
	{ 
		%obj.unMountImage(1); 
	}
	
	%pos = %obj.getMuzzlePoint(0);
	
	%initVelocity = vectorScale(%obj.getMuzzleVector(%slot), %this.projectile.muzzleVelocity);
	%initVelocity = vectorAdd(%initVelocity, 0 SPC 0 SPC 6);
			
	%p = new Projectile()
	{
		dataBlock = "tennisRacquetProjectile";
		initialPosition = %pos;
		initialVelocity = %initVelocity;
		sourceObject = %obj;
		client = %obj.client;
		sourceSlot = 0;
		originPoint = %pos;
	};
			
	MissionCleanup.add(%p);
}

function tennisRacquetImage::onTRReturn(%this, %obj, %slot)
{
	%obj.playThread(2, shiftTo);  
		
	%fvec = %obj.getForwardVector();
	%fX = getWord(%fvec,0);
	%fY = getWord(%fvec,1);
		
	%evec = %obj.getEyeVector();
	%eX = getWord(%evec,0);
	%eY = getWord(%evec,1);
	%eZ = getWord(%evec,2);
		
	%eXY = mSqrt(%eX*%eX+%eY*%eY);
		
	%aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
		
	initContainerRadiusSearch(%obj.getMuzzlePoint(0),getWord(%obj.getScale(),2)*2.5,$TypeMasks::ProjectileObjectType);
		
	while(isObject(firstWord(%searchObj = containerSearchNext())))
	{
		
		if(vectorLen(%searchObj.getVelocity()) == 0 || %searchObj.dataBlock.lifeTime <= 0)
			continue;
		
		%vel = vectorNormalize(%searchObj.getVelocity());
		if(vectorDot(%aimVec,%vel) > 0.30)
			continue;
		
		if(%searchObj.sourceObject == %obj && %searchObj.reflectTime > 0 && (getSimTime() - %searchObj.reflectTime) < 1000)
			continue;
			
		if(!%searchObj.dataBlock.uiName $= "Tennis Ball")
			continue;

		%pos = %obj.getMuzzlePoint(0);
		//%vec = vectorScale(%obj.getMuzzleVector(0),vectorLen(%searchObj.getVelocity()));
		//%vel = vectorAdd(%vec,vectorScale(%obj.getVelocity(),%searchObj.dataBlock.velInheritFactor));
		
		%projectile = %searchObj.dataBlock;
		
		%initVelocity = vectorScale(%obj.getMuzzleVector(%slot), %projectile.muzzleVelocity);
		%initVelocity = vectorAdd(%initVelocity, 0 SPC 0 SPC 6);
			
		%p = new Projectile()
		{
			dataBlock = %searchObj.dataBlock;
			initialPosition = %pos;
			initialVelocity = %initVelocity;
			sourceObject = %obj;
			client = %obj.client;
			sourceSlot = 0;
			originPoint = %pos;
			reflectTime = getSimTime();
		};
			
		serverPlay3D(tennisRacquetHitSound,%searchObj.getTransform());
			
		MissionCleanup.add(%p);
						
		%searchObj.delete();
	}
}

datablock ShapeBaseImageData(tennisBallLeftHandImage)
{
	shapeFile = "./shapes/tennisball.dts";
	armReady = false;
	emap = true;
	mountPoint = 1;
	offset = "0.02 0.0 0.02";
	eyeOffset = "-0.55 1 -0.35";
	doColorShift = false;
};

function tennisRacquetImage::onMount(%this,%obj,%slot)
{
	parent::onMount(%this,%obj,%slot);
	%obj.playThread(0, armReadyBoth);
	%obj.unMountImage(1);
	%obj.mountImage(tennisBallLeftHandImage,1);
}

function tennisRacquetImage::onUnMount(%this,%obj,%slot)
{
	parent::onUnMount(%this,%obj,%slot);
	%obj.playThread(0, root);
	%obj.unMountImage(1); 
}

datablock itemData(tennisRacquetBlueItem : tennisRacquetItem)
{
	shapeFile = "./shapes/TennisRacketBlue.dts";
	uiName = "Tennis Racquet B";
	//colorShiftColor = "0.00 0.00 0.85 1.00";
	image = tennisRacquetBlueImage;
};

datablock shapeBaseImageData(tennisRacquetBlueImage : tennisRacquetImage)
{
	shapeFile = "./shapes/TennisRacketBlue.dts";
	item = tennisRacquetBlueItem;
	//colorShiftColor = tennisRacquetBlueItem.colorShiftColor;
};

function tennisRacquetBlueImage::onFire(%this,%obj,%slot)
{
	tennisRacquetImage::onFire(%this,%obj,%slot);
}

function tennisRacquetBlueImage::onTRReturn(%this, %obj, %slot)
{
	tennisRacquetImage::onTRReturn(%this, %obj, %slot);
}

function tennisRacquetBlueImage::onMount(%this,%obj,%slot)
{
	parent::onMount(%this,%obj,%slot);
	%obj.playThread(0, armReadyBoth);
	%obj.unMountImage(1);
	%obj.mountImage(tennisBallLeftHandImage,1);
}

function tennisRacquetBlueImage::onUnMount(%this,%obj,%slot)
{
	parent::onUnMount(%this,%obj,%slot);
	%obj.playThread(0, root);
	%obj.unMountImage(1); 
}
