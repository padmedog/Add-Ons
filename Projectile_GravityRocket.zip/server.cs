//Projectile_GravityRocket.cs



//if we don't have the rocket explosion, make our own
if(!isObject(rocketExplosion))
{
   datablock AudioProfile(rocketExplodeSound)
   {
      filename    = "./tntExplode.wav";
      description = AudioDefault3d;
      preload = true;
   };
}


datablock ParticleData(gravityRocketExplosionParticle)
{
   dragCoefficient      = 8;
   gravityCoefficient   = -5;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 700;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/cloud";
   spinSpeed		= 10.0;
   spinRandomMin		= -50.0;
   spinRandomMax		= 50.0;
   colors[0]     = "0.9 0.5 0.0 0.9";
   colors[1]     = "0.0 0.0 0.0 0.9";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 8.0;
   sizes[1]      = 15.0;
   sizes[2]      = 12.0;

   times[0] = 0.0;
   times[1] = 0.4;
   times[2] = 1.0;

   useInvAlpha = true;
};
datablock ParticleEmitterData(gravityRocketExplosionEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 15;
   velocityVariance = 1.0;
   ejectionOffset   = 3.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "gravityRocketExplosionParticle";
};

datablock ParticleData(gravityRocketExplosionRingParticle)
{
   dragCoefficient      = 8;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 40;
   lifetimeVarianceMS   = 10;
   textureName          = "base/data/particles/star1";
   spinSpeed		= 10.0;
   spinRandomMin		= -500.0;
   spinRandomMax		= 500.0;
   colors[0]     = "1 0.5 0.0 0.5";
   colors[1]     = "0.9 0.0 0.0 0.0";
   sizes[0]      = 8;
   sizes[1]      = 13;

   useInvAlpha = false;
};
datablock ParticleEmitterData(gravityRocketExplosionRingEmitter)
{
   lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 0.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "gravityRocketExplosionRingParticle";
};


datablock ParticleData(gravityRocketExplosionChunkParticle)
{
   dragCoefficient      = 0;
   gravityCoefficient   = 3;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 1400;
   lifetimeVarianceMS   = 1300;
   textureName          = "base/data/particles/chunk";
   spinSpeed		= 10.0;
   spinRandomMin		= -500.0;
   spinRandomMax		= 500.0;
   colors[0]     = "0.1 0.1 0.1 0.5";
   colors[1]     = "0.0 0.0 0.0 0.5";
   sizes[0]      = 0.7;
   sizes[1]      = 0;

   useInvAlpha = true;
};
datablock ParticleEmitterData(gravityRocketExplosionChunkEmitter)
{
   lifeTimeMS = 25;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 25;
   velocityVariance = 0.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "gravityRocketExplosionChunkParticle";
};


datablock ExplosionData(gravityRocketExplosion)
{
   explosionShape = "";
   soundProfile = rocketExplodeSound;

   lifeTimeMS = 150;

   particleEmitter = gravityRocketExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = gravityRocketExplosionRingEmitter;
   emitter[1] = gravityRocketExplosionChunkEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 20;
   lightStartColor = "1 1 0 1";
   lightEndColor = "1 0 0 0";

   damageRadius = 7;
   radiusDamage = 150;

   impulseRadius = 6;
   impulseForce = 4000;

   playerBurnTime = 5000;
};

/////////////////
//  Projectile //
/////////////////

//if we don't have the rocket trail, make our own
if(!isObject(rocketTrailEmitter))
{
   datablock ParticleData(rocketTrailParticle)
   {
      dragCoefficient      = 3;
      gravityCoefficient   = -0.0;
      inheritedVelFactor   = 0.15;
      constantAcceleration = 0.0;
      lifetimeMS           = 1000;
      lifetimeVarianceMS   = 805;
      textureName          = "base/data/particles/cloud";
      spinSpeed		= 10.0;
      spinRandomMin		= -150.0;
      spinRandomMax		= 150.0;
      colors[0]     = "1.0 1.0 0.0 0.4";
      colors[1]     = "1.0 0.2 0.0 0.5";
      colors[2]     = "0.20 0.20 0.20 0.3";
      colors[3]     = "0.0 0.0 0.0 0.0";

      sizes[0]      = 0.25;
      sizes[1]      = 0.85;
      sizes[2]      = 0.35;
      sizes[3]      = 0.05;

      times[0] = 0.0;
      times[1] = 0.05;
      times[2] = 0.3;
      times[3] = 1.0;

      useInvAlpha = false;
   };
   datablock ParticleEmitterData(rocketTrailEmitter)
   {
      ejectionPeriodMS = 5;
      periodVarianceMS = 1;
      ejectionVelocity = 0.25;
      velocityVariance = 0.0;
      ejectionOffset   = 0.0;
      thetaMin         = 0;
      thetaMax         = 90;
      phiReferenceVel  = 0;
      phiVariance      = 360;
      overrideAdvance = false;
      particles = "rocketTrailParticle";
   };
}

if(!isObject(rocketLoopSound))
{
   datablock AudioProfile(rocketLoopSound)
   {
      filename    = "./sound/rocketLoop.wav";
      description = AudioCloseLooping3d;
      preload = true;
   };
}
if(!$DamageType::RocketDirect)
   AddDamageType("RocketDirect",   '<bitmap:add-ons/Projectile_GravityRocket/rocket> %1',    '%2 <bitmap:add-ons/Projectile_GravityRocket/rocket> %1',1,1);
if(!$DamageType::RocketRadius)
   AddDamageType("RocketRadius",   '<bitmap:add-ons/Projectile_GravityRocket/rocketRadius> %1',    '%2 <bitmap:add-ons/Projectile_GravityRocket/rocketRadius> %1',1,0);
datablock ProjectileData(gravityRocketProjectile)
{
   projectileShapeName = "./RocketGravityProjectile.dts";
   directDamage        = 30;
   directDamageType = $DamageType::RocketDirect;
   radiusDamageType = $DamageType::RocketRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = gravityRocketExplosion;
   particleEmitter     = rocketTrailEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = rocketLoopSound;

   muzzleVelocity      = 65;
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 12000;
   fadeDelay           = 11500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "Rocket, Gravity"; //naming it this way so it's next to the rocket in the alphabetized list
};

