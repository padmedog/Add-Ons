// Renderman AI //

// OUTLINE
// >Rendermen start by finding a "target". #
// >They stalk the targeted player. #
// >Sometimes their target will change #
// >Up to five rendermen can be on the map at the time #
// >Rendermen sometimes try to teleport closer to the target, but can't teleport in front of them. #
// >Upon getting very close to the target (Right behind them) they will make a sound. #
// >Looking at a renderman that is very close kills the player #
// >Looking at one that is far away will kill over time #
// >If a renderman loses it's target it ceases to exist. #
// >Suddenly catching sight of a close up renderman will play a jumpscare sound. #
// >Rendermen can't move when they're being observed by players. #
// >Rendermen not visible to the player indoors will play ambient sounds. #

// first, checks
function AIPlayer::rendermanCanSeeObject(%player,%object) // this time, %player is renderman & %object is it's target
{
	if(!isObject(%object))
	{
		//announce("Object doesn't exist!");
		return 0;
	}


	//The eye point is the position of the players camera
	%eye = %player.getEyePoint();
	//The position of the object
	//%to = posFromTransform(%object.getTransform());
	%to = %object.getEyePoint();
	// if(vectorDist(%eye,%to) < %range)
	// 	return 0;

	//Cast a raycast to try and collide with the object
	%ray = containerRaycast(%eye,%to,$TypeMasks::StaticShapeObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType,%player);
	%col = getWord(%ray,0);
	//announce(%col);
	if(isObject(%col) && %col == %object)
	{
		//The position of the collision
		%pos = posFromRaycast(%ray);

		//Super Maths C skills go B)
		%resultant = vectorSub(%pos,%eye);
		%normal = vectorNormalize(%resultant);

		//Find the yaw from the resultant
		%resultRadians = mAtan(getWord(%normal,1),getWord(%normal,0));
		
		//Find the yaw from the eye vector
		%eyeVec = %player.getEyeVector();
		%eyeRadians = mAtan(getWord(%eyeVec,1),getWord(%eyeVec,0));

		//Convert both of them to degrees for easier understanding
		%resultDegrees = mRadToDeg(%resultRadians);
		%eyeDegrees = mRadToDeg(%eyeRadians);

		//Now the tricky part. In order for the object to be in sight, lets say that the object needs to be within 90 degrees of the players view
		//Change 90 to something smaller if you don't like how wide the view is
		if(%resultDegrees >= %eyeDegrees - 50 && %resultDegrees <= %eyeDegrees + 50)
			//announce("Should be returning 1 right here!");
			return 1;
	}
	//No object hit, or not the target object, return 0/false
	//announce("No object hit, or not the target object, return 0/false");
	return 0;
}

function AIPlayer::ShrineCheck(%this)
{
	InitContainerRadiusSearch(%this.getPosition(),20,$TypeMasks::FxBrickObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.getDatablock().getName() $= "brickRenderSafe") {
            return 1;
        }
    }
    return 0;
}

function AIPlayer::getPosInFrontOfRenderman(%this,%dist)
{
    return vectorAdd(%this.getEyePoint(),vectorScale(%this.getEyeVector(),%dist));
}

function Player::getPosInFrontOfPlayer(%this,%dist)
{
    return vectorAdd(%this.getEyePoint(),vectorScale(%this.getEyeVector(),%dist));
}

function AIPlayer::getRendermanTarget(%this) { // this is how rendermen find a "target".
    %pos = %this.getPosition();
    
    InitContainerRadiusSearch(%pos,1200,$TypeMasks::PlayerObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(isObject(%targetObject.client)) { // That IS a player, right? This isn't the time for chasing your friends about.
            return %targetObject; // Set the found player as the target
        }
    }
    return 0;
}   

function AIPlayer::rendermanLoop(%this) {
    // Should we still be around?
    if(%this.RendermanLifetime <= 0 || $Pref::Rendermen::Enabled == 0) {
        %this.selfdestruct = 1; // we're not going to be around for much longer but we can't just vanish in front of someone
    } else {
        %this.RendermanLifetime = %this.RendermanLifetime-1;
    }
    
    if($rendermancleanup == 1) { //clean up?
        removeRenderman(%this);
    }
    // Do we have a target? If not get one
    if(%this.RendermanTarget == 0) {
        %this.RendermanTarget = %this.getRendermanTarget();
        
        //find anything?
        if(%this.RendermanTarget == 0) {
            removeRenderman(%this); // can't find a target so despawns
            return "NOTARG";
        }
    }
    // now that we have a target...
    // do we see him?
    if(%this.rendermanCanSeeObject(%this.RendermanTarget) == 1)  {
        %targinplainview = 1;
    } else {
        %targinplainview = 0;
    }
    // is he alive/still about?
    if(!isObject(%this.RendermanTarget) || %this.RendermanTarget.safe == 1) {
        serverPlay3D(BotVanish,%this.getPosition());
        removeRenderman(%this); // target is lost so renderman despawns
        return "TLOST";
    }
    
    if(%this.shrineCheck()) { // rendermen cannot go within 20 TUs of a shrine without dying
        serverPlay3D(BotVanish,%this.getPosition());
        removeRenderman(%this);
        return "SHRINE";
    }
        
    %this.setAimObject(%this.RendermanTarget); // face him
    // can anyone see us?
    %pos = %this.getPosition();
    InitContainerRadiusSearch(%pos,9999,$TypeMasks::PlayerObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(isObject(%targetObject.client)) {
            if(getWord(%targetObject.canSeeRender,0) $= %this || getWord(%targetObject.canSeeRender,1) $= %this || getWord(%targetObject.canSeeRender,2) $= %this || getWord(%targetObject.canSeeRender,3) $= %this || getWord(%targetObject.canSeeRender,4) $= %this || getWord(%targetObject.canSeeRender,5) $= %this) { // this line is rather long, isn't it?
                // this means they can
                %this.schedule(100,rendermanLoop); // so we wait,
                %this.setAimObject(%targetObject); // and face him
                if(getrandom(1,30) == 3) { //possibly change him to your target for this (If he already is this won't matter)
                    %this.RendermanTarget = %targetObject;
                } // woo unnecisary brackets
                return "INVIEW";
            }
        }
    }
    // nobody sees us.
    // SELF DESTRUCT (If appropriate)
    if(%this.selfdestruct == 1) {
        serverPlay3D(BotVanish,%this.getPosition());
        removeRenderman(%this);
        return "SELFDESTRUCT";
    }
    // time to chase the target.
    
    // are we close enough?
    if(VectorDist(%this.getPosition(),%this.RendermanTarget.getPosition()) <= 7) {
        %this.schedule(200,rendermanLoop);
        if(%this.growled == 0 && %this.RendermanTarget.frozen == 0 && %targinplainview == 1) {
            serverPlay3D(RenGrowl,%this.getPosition());
            %this.RendermanTarget.prevDatablock = %this.RendermanTarget.getDatablock();
            %this.RendermanTarget.setDatablock(PlayerRenderFrozenArmor); // freeze the target
            %this.RendermanTarget.frozen = 1; // tell their loopcode they froze
            if(!$Pref::Rendermen::Speed <= 100) { // with agro lower than "demonic", this state is easily escapable.
                schedule(13000,0,removeRenderman,%this);
            }
            // show me your war face.
            if($Pref::Rendermen::Faces == 1) {
                %this.setfacename("rendermanAngry");
            } else {
                %this.setfacename("asciiTerror");
            }
            %this.RendermanTarget.detector = 5; // make their detector go haywire - that'll scare em'
            %creep = getRandom(1,8);
            if(%creep == 1) {
                echo("FoUNd YOu");
            }
            if(%creep == 2) {
                echo("CAn'T RuN");
            }
            if(%creep == 3) {
                echo("CLoSE YOuR EYEs");
                echo("aND TUrN WiTh Me");
            }
            if(%creep == 4) {
                echo("fORgIVE mE");
                echo("I'M SO VeRy SoRRy");
            }
            if(%creep == 5) {
                echo("LoOK aT ME,",strUpr(%this.RendermanTarget.client.name));
            }
        }
        %this.growled = 1;
        //if(%targinplainview == 1) {
         //   %this.RendermanTarget.client.play2D(QuietCaptureSound);
        //}
        
        return "CLSENOUGH";
    }
    
    %mf = %this.getPosInFrontOfRenderman(1); // the bot support in BL is terrible, so we'll slowly tp the bot towards the player instead
    %mf = vectorSub(%mf,"0 0 2.880"); // compensate for render trying to be dolan
    
    if(%this.justteleported == 1) { // did we do teleporty?
        if(getWord(%this.RendermanTarget.canSeeRender,0) $= %this || getWord(%this.RendermanTarget.canSeeRender,1) $= %this || getWord(%this.RendermanTarget.canSeeRender,2) $= %this || getWord(%this.RendermanTarget.canSeeRender,3) $= %this || getWord(%this.RendermanTarget.canSeeRender,4) $= %this || getWord(%this.RendermanTarget.canSeeRender,5) $= %this) { // this line is rather long, isn't it?
            // if we teleported somewhere that can be seen by the target,
            %this.RendermanTeleport(); // try again - we'll have a specific function for jumpscaring later on
        }
    }
    
    %this.justteleported = 0;
    %this.setTransform(%mf);
    
    if(getRandom(1,56) == 5) { // do teleporty?
        %this.RendermanTeleport();
        %this.justteleported = 1;
    }
    
    if(getRandom(1,126) == 5) { // teleport right behind the player?
        %this.RendermanSneak();
        %this.justteleported = 1;
    }
    // finally, rerun the AI code
    if(%this.type $= "T") {
       %this.schedule($Pref::Rendermen::Speed / 2,rendermanLoop);  // Type T moves twice as fast no matter what
    } else {
        if(%this.RendermanTarget.detlure == 1 || %this.RendermanTarget.lightlure == 1) {
            %this.schedule($Pref::Rendermen::Speed,rendermanLoop); // normal renderman speed
        } else { // if the player isn't attracting attention (by holding a detector, having a light etc...)
            %this.schedule($Pref::Rendermen::Speed * 1.6,rendermanLoop); // slow renderman down slightly
        }
    }
    return "SUCCESS";
}

function AIPlayer::RendermanTeleport(%this) { // teleport a renderman randomly
    %pPos = %this.RendermanTarget.getPosition();
    %tPos = vectorAdd(%pPos, getRandom(-80,80) SPC getRandom(-80,80) SPC 0 );
    %this.setTransform(%tPos);
    serverPlay3D(BotVanish,%tPos);
}

function AIPlayer::RendermanSneak(%this) { // another teleport, but appears right behind the player
    %pPos = %this.RendermanTarget.getPosition();
    %tPos = %this.getPosInFrontOfPlayer(-3); // using a minus number like this gives me a space directly BEHIND the player
    %this.setTransform(%tPos);
    // no sound
}

function FxDTSBrick::RenderHordeRestoreLight(%this) { // bricks with lights will break when the Horde event happens.
    %this.setLight(%this.PrevLight);
}

// brick light check
function FxDTSBrick::RenderCheck(%this)
{
	InitContainerRadiusSearch(%this.getPosition(),70,$TypeMasks::PlayerObjectType);
    %seen = 0;
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.isRenderman == 1) {
            if(%seen == 0) {
                %seen = %targetObject;
            }
        }
    }
    return %seen;
}

function servercmdclearrendermen(%cl) {
    if(%cl.isAdmin || %cl.isSuperAdmin) {
        $rendermancleanup = 1;
        announce(%cl.name SPC "cleared all Rendermen!");
        $rendermeninmap = 0; // this command can be used to fix stupid fucks who killed the rendermen "by mistake" using hacks
        ServerPlay2D(BotVanish);
        schedule(1000,0,endrendermancleanup);
    }
}

function endrendermancleanup() {
    $rendermancleanup = 0;
}
// special returns are for debugging with the trace function - type trace(1); in console to see all renderman AI output