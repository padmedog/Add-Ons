datablock TSShapeConstructor(RotZTankDts)
{
	baseShape  = "./tank/zTank.dts";
	sequence0  = "./tank/zTankRoot.dsq root";

	sequence1  = "./tank/zTankRun.dsq run";
	sequence2  = "./tank/zTankRun.dsq walk";
	sequence3  = "./tank/zTankRoot.dsq back";
	sequence4  = "./tank/zTankRoot.dsq side";

	sequence5  = "./tank/zTankCrouch.dsq crouch";
	sequence6  = "./tank/zTankCrouchRun.dsq crouchRun";
	sequence7  = "./tank/zTankRoot.dsq crouchBack";
	sequence8  = "./tank/zTankRoot.dsq crouchSide";

	sequence9  = "./tank/zTankRoot.dsq look";
	sequence10 = "./tank/zTankRoot.dsq headside";
	sequence11 = "./tank/zTankRoot.dsq headUp";

	sequence12 = "./tank/zTankJump.dsq jump";
	sequence13 = "./tank/zTankRoot.dsq standjump";
	sequence14 = "./tank/zTankRoot.dsq fall";
	sequence15 = "./tank/zTankRoot.dsq land";

	sequence16 = "./tank/zTankRoot.dsq armAttack";
	sequence17 = "./tank/zTankRoot.dsq armReadyLeft";
	sequence18 = "./tank/zTankRoot.dsq armReadyRight";
	sequence19 = "./tank/zTankRoot.dsq armReadyBoth";
	sequence20 = "./tank/zTankRoot.dsq spearready";  
	sequence21 = "./tank/zTankRoot.dsq spearThrow";

	sequence22 = "./tank/zTankRoot.dsq talk";  

	sequence23 = "./tank/zTankDie.dsq death1"; 
	
	sequence24 = "./tank/zTankRoot.dsq shiftUp";
	sequence25 = "./tank/zTankRoot.dsq shiftDown";
	sequence26 = "./tank/zTankRoot.dsq shiftAway";
	sequence27 = "./tank/zTankRoot.dsq shiftTo";
	sequence28 = "./tank/zTankRoot.dsq shiftLeft";
	sequence29 = "./tank/zTankRoot.dsq shiftRight";
	sequence30 = "./tank/zTankRoot.dsq rotCW";
	sequence31 = "./tank/zTankRoot.dsq rotCCW";

	sequence32 = "./tank/zTankRoot.dsq undo";
	sequence33 = "./tank/zTankRoot.dsq plant";

	sequence34 = "./tank/zTankRoot.dsq sit";

	sequence35 = "./tank/zTankRoot.dsq wrench";

   sequence36 = "./tank/zTankRoot.dsq activate";
   sequence37 = "./tank/zTankActivate2.dsq activate2";

   sequence38 = "./tank/zTankRoot.dsq leftrecoil";
};    

datablock PlayerData(RotTankZombie : PlayerStandardArmor)
{
	shapeFile = "./tank/zTank.dts";
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;
	runforce = 1000 * 90;
	drag = 0;
	maxForwardSpeed = 10;
	maxBackwardSpeed = 10;
	maxSideSpeed = 13;
	attackpower = 30;
	jumpForce = 100 * 100; //8.3 * 90;
	jumpsound = "ZombieJumpSound";

	//boundingbox = "4 4 8";

	mass = 1000;
	maxDamage = 1500;
	
	BrickDestroyMaxVolume = 1000;
	BrickMaxJumpHeight = 20;
	uiName = "Zombie Tank";
	rideable = true;
	canRide = true;
	BrickKillRadius = 8;
	skinColor = "0.133 0.271 0.271 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
	SpecialAttack = 1;
	zDeathSound = "ZTankDiesound";
	ignorePipeBombs = 1;
};
function RotTankZombie::SpecialAttack(%this,%onshot)
{
	if(isobject(%this) && %this.lastspecial+5000 < getsimtime())
	{
		//%this.playaudio(2,"WitchAttack" @ getrandom(1,2) @ "Sound");
		%this.playaudio(2,"TankYellSound");
		%this.lastspecial = getsimtime();
	}
}
function RotTankZombie::ondisabled(%this,%obj)
{
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotTankZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
	if(IsInMinigame(%obj) && IsInSameMinigame(%col,%obj) && %obj.getstate() !$= "Dead" && %obj.spawnbrick.getgroup().client.minigame.EnableZombies == 1 && %col.isdowned != 1)
	{
		%col.applyimpulse(%col.getposition(),vectoradd(vectorscale(%obj.getforwardvector(),2000),"0 0 500"));
		%obj.playaudio(3,ZTankPunchsound);
	}
	if(IsInMinigame(%obj) && MinigameIncludesPlayerBricks(%col) && %col.iszombie && %obj.getstate() !$= "Dead")
	{
		%col.applyimpulse(%col.getposition(),vectoradd(vectorscale(%obj.getforwardvector(),2000),"0 0 500"));
		%obj.playthread(2,activate2);
	}
}
function RotTankZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotTankZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotTankZombie::onAdd(%this,%obj)
{
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
	//%obj.maxyawspeed = 80;
	//%obj.maxpitchspeed = 80;
	//%obj.setname(fred);
	//%obj.setscale("1.25 1.25 1.25");
	schedule(20,0,TankIdleLoop,%obj);
}
function TankIdleLoop(%obj)
{
	%obj.name = "Tank";
	cancel(%obj.IdleLoop);
	if(isobject(%obj) && %obj.isfollowing == 0 && isobject(%obj.minigame))
	{
		%obj.playaudio(2,"TankIdle" @ getrandom(1,4) @ "Sound");
		%obj.IdleLoop = schedule(4000,%obj,TankIdleLoop,%obj);
	}
}