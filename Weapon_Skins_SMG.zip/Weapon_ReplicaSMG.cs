AddDamageType("ClassicSubmachinegun",   '<bitmap:add-ons/Weapon_Skins_SMG/CI_Classic_smg> %1',    '%2 <bitmap:add-ons/Weapon_Skins_SMG/CI_Classic_smg> %1',0.75,1);
datablock ProjectileData(ClassicSubmachinegunProjectile1 : SubmachineGunProjectile1)
{
   directDamageType    = $DamageType::ClassicSubmachineGun;
   directDamage        = 8+4;
};

//////////
// item //
//////////
datablock ItemData(ClassicSMGItem : Submachinegunimage)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./classic_SMG.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Classic SMG";
	iconName = "./Classicsmg";
	doColorShift = true;
	colorShiftColor = "0.51 0.43 0.36 1.000";

	 // Dynamic properties defined by the scripts
	image = ClassicSMGImage;
	canDrop = true;

	maxAmmo = 35;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ClassicSMGImage : Submachinegunimage)
{
   // Basic Item properties
	shapeFile = "./classic_SMG.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ClassicSMGItem;
   ammo = " ";
   projectile = ClassicSubmachinegunProjectile1;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ClassicSMGItem.colorShiftColor;

	stateTimeoutValue[3]            = 0.01;
};

function classicSMGImage::onFire(%this,%obj,%slot)
{
	%projectile = %this.projectile;
	%spread = 0.0025;
	%shellcount = 1;

	%obj.playThread(2, plant);
	%shellcount = 1;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function classicSMGImage::onReloadStart(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, wrench);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function classicSMGImage::onReloadWait(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
            serverPlay3D(magazineOutSound,%obj.getPosition());
            //serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
            //serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
            //serverPlay3D(Block_changeBrick_Sound,%obj.getPosition());
	%obj.playThread(2, activate);
	}
}

function classicSMGImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.client.quantity["9MMrounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick6Sound,%obj.getPosition());

        if(%obj.client.quantity["9MMrounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["9MMrounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["9MMrounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["9MMrounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["9MMrounds"] = 0;

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}
	}
}


function classicsubmachinegunProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.setVelocity(getWord(%col.getVelocity(),0)/1.1 SPC getWord(%col.getVelocity(),1)/1.1 SPC getWord(%col.getVelocity(),1.1));
   }
parent::damage(%this,%obj,%col,%fade,%pos,%normal);
}

function classicSMGImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
}

function classicSMGImage::onUnMount(%this,%obj,%slot)
{
	%obj.playThread(2, root);
}