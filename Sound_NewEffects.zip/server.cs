exec("./script_footstep.cs");

function addNewSounds()
{
	if(isFile("./SOUNDS/jump.wav"))
		jumpSound.fileName = "./SOUNDS/sn_jump.wav";

	if(isFile("./SOUNDS/lightOn.wav"))
		lightOnSound.fileName = "./SOUNDS/lightOn.wav";

	if(isFile("./SOUNDS/lightOff.wav"))
		lightOffSound.fileName = "./SOUNDS/lightOff.wav";
}

addnewSounds();

	
package newSounds
{
	function JumpSound::onAdd(%this)
	{
		parent::onAdd(%this);

		if(isFile("./SOUNDS/sn_jump.wav"))
			%this.fileName = "./SOUNDS/sn_jump.wav";
	}

	function lightOnSound::onAdd(%this)
	{
		parent::onAdd(%this);

		if(isFile("./SOUNDS/lighton.wav"))
			%this.fileName = "./SOUNDS/lighton.wav";
	}

	function lightOffSound::onAdd(%this)
	{
		parent::onAdd(%this);

		if(isFile("./SOUNDS/lightOff.wav"))
			%this.fileName = "./SOUNDS/lightOff.wav";
	}
};
activatePackage(newSounds);