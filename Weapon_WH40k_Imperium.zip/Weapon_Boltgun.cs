AddDamageType("Boltgun",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Boltgun> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Boltgun> %1',0.75,1);
datablock ProjectileData(BoltgunProjectile)
{
   projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 35;
   directDamageType    = $DamageType::Boltgun;
   radiusDamageType    = $DamageType::Boltgun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 14;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 22;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 120;
   verticalImpulse	  = 40;
   explosion           = BoltpistolExplosion;
   particleEmitter     = BoltpistolTrailEmitter;

   muzzleVelocity      = 180;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 8000;
   fadeDelay           = 7200;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "1 0.5 0";
   
   sound = rocketLoopSound;
   
   uiName = "Bolter Round";
};

//////////
// item //
//////////
datablock ItemData(BoltgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Boltgun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Boltgun";
	iconName = "./Boltgun";
	doColorShift = false;
	colorShiftColor = "0.7 0.7 0.72 1.000";

	 // Dynamic properties defined by the scripts
	image = BoltgunImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 20;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(BoltgunImage)
{

   // Basic Item properties
   shapeFile = "./Boltgun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BoltgunItem;
   ammo = " ";
   projectile = BoltgunProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = BoltgunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.35;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= BoltgunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= BoltpistolFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.15;
	stateTransitionOnTimeout[4]	= "Ready";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
};

function BoltgunImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, plant);

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0004;
	}
	else
	{
		%spread = 0.0012;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}
function BoltgunImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
}

