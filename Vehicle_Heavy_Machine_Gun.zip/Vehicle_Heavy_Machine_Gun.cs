// Heavy Machine Gun
// Solely made by Jaydee, no other else
// Everything is done by me

datablock TSShapeConstructor(hvymgTurretDts)
{
	baseShape  = "./mg3.dts";
	sequence0  = "./t_root.dsq root";

	sequence1  = "./t_root.dsq run";
	sequence2  = "./t_root.dsq walk";
	sequence3  = "./t_root.dsq back";
	sequence4  = "./t_root.dsq side";

	sequence5  = "./t_root.dsq crouch";
	sequence6  = "./t_root.dsq crouchRun";
	sequence7  = "./t_root.dsq crouchBack";
	sequence8  = "./t_root.dsq crouchSide";

	sequence9  = "./t_look.dsq look";
	sequence10 = "./t_root.dsq headside";
	sequence11 = "./t_root.dsq headUp";

	sequence12 = "./t_root.dsq jump";
	sequence13 = "./t_root.dsq standjump";
	sequence14 = "./t_root.dsq fall";
	sequence15 = "./t_root.dsq land";

	sequence16 = "./t_root.dsq armAttack";
	sequence17 = "./t_root.dsq armReadyLeft";
	sequence18 = "./t_root.dsq armReadyRight";
	sequence19 = "./t_root.dsq armReadyBoth";
	sequence20 = "./t_root.dsq spearready";  
	sequence21 = "./t_root.dsq spearThrow";

	sequence22 = "./t_root.dsq talk";  

	sequence23 = "./t_root.dsq death1"; 
	
	sequence24 = "./t_root.dsq shiftUp";
	sequence25 = "./t_root.dsq shiftDown";
	sequence26 = "./t_root.dsq shiftAway";
	sequence27 = "./t_root.dsq shiftTo";
	sequence28 = "./t_root.dsq shiftLeft";
	sequence29 = "./t_root.dsq shiftRight";
	sequence30 = "./t_root.dsq rotCW";
	sequence31 = "./t_root.dsq rotCCW";

	sequence32 = "./t_root.dsq undo";
	sequence33 = "./t_root.dsq plant";

	sequence34 = "./t_root.dsq sit";

	sequence35 = "./t_root.dsq wrench";
};    

datablock PlayerData(hvymgTurretPlayer)
{
   renderFirstPerson = true;
   emap = false;
   
   className = Armor;
   shapeFile = "./mg3.dts";
   cameraMaxDist = 8;
   cameraTilt = 0.261;
   cameraVerticalOffset = 2.3;
   computeCRC = false;
  
   canObserve = true;
   cmdCategory = "Clients";

   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;
   
   //debrisShapeName = "~/data/player/debris_player.dts";
   //debris = horseDebris;

   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 1.5708;
   maxFreelookAngle = 3.0;

   mass = 99999;
   drag = 0.1;
   maxdrag = 0.52;
   density = 0.7;
   maxDamage = 250;
   maxEnergy =  10;
   repairRate = 0.33;
   energyPerDamagePoint = 75.0;

   rechargeRate = 0.4;

   runForce = 0 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;

   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 0;
   maxBackwardWalkSpeed = 0;
   maxSideWalkSpeed = 0;

   maxUnderwaterForwardSpeed = 0;
   maxUnderwaterBackwardSpeed = 0;
   maxUnderwaterSideSpeed = 0;

   jumpForce = 0; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

   minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

   recoverDelay = 0;
   recoverRunForceScale = 1.2;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("2.5 2.5 1.7", 4); 
   crouchBoundingBox	= vectorScale("2.5 2.5 1.7", 4); 
   proneBoundingBox	= vectorScale("2.5 2.5 1.7", 4); 

   pickupRadius = 0.75;
   
   // Damage location details
   boxNormalHeadPercentage       = 0.83;
   boxNormalTorsoPercentage      = 0.49;
   boxHeadLeftPercentage         = 0;
   boxHeadRightPercentage        = 1;
   boxHeadBackPercentage         = 0;
   boxHeadFrontPercentage        = 1;

   // Foot Prints
   //decalData   = HorseFootprint;
   //decalOffset = 0.25;
	
   jetEmitter = playerJetEmitter;
   jetGroundEmitter = playerJetGroundEmitter;
   jetGroundDistance = 4;
  
   //footPuffEmitter = LightPuffEmitter;
   footPuffNumParts = 10;
   footPuffRadius = 0.25;

   //dustEmitter = LiftoffDustEmitter;

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 85;
   jumpSurfaceAngle = 86;

   minJumpSpeed = 0;
   maxJumpSpeed = 0;

   horizMaxSpeed = 0;
   horizResistSpeed = 0;
   horizResistFactor = 0;

   upMaxSpeed = 0;
   upResistSpeed = 0;
   upResistFactor = 0;
   
   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   JumpSound			= HorseJumpSound;

   // Footstep Sounds
   //FootSoftSound        = HorseFootFallSound;
   //FootHardSound        = HorseFootFallSound;
   //FootMetalSound       = HorseFootFallSound;
   //FootSnowSound        = HorseFootFallSound;
   //FootShallowSound     = HorseFootFallSound;
   //FootWadingSound      = HorseFootFallSound;
   //FootUnderwaterSound  = HorseFootFallSound;
   //FootBubblesSound     = FootLightBubblesSound;
   //movingBubblesSound   = ArmorMoveBubblesSound;
   //waterBreathSound     = WaterBreathMaleSound;

   //impactSoftSound      = ImpactLightSoftSound;
   //impactHardSound      = ImpactLightHardSound;
   //impactMetalSound     = ImpactLightMetalSound;
   //impactSnowSound      = ImpactLightSnowSound;
   
   //impactWaterEasy      = ImpactLightWaterEasySound;
   //impactWaterMedium    = ImpactLightWaterMediumSound;
   //impactWaterHard      = ImpactLightWaterHardSound;
   
   groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;
   
   observeParameters = "0.5 4.5 4.5";

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "Heavy Machine Gun";
	rideable = true;
   lookUpLimit = 0.6;
   lookDownLimit = 0.4;

	canRide = false;
	showEnergyBar = false;
	paintable = true;

	brickImage = horseBrickImage;	//the imageData to use for brick deployment

   numMountPoints = 1;
   mountThread[0] = "root";

   //protection for passengers
   protectPassengersBurn   = true;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = false; //protect passengers from direct damage (bullets) ?
};

datablock ShapeBaseImageData(hvymgSmokeImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 1;

	stateName[0]                  = "Ready";
	stateTransitionOnTimeout[0]   = "FireA";
	stateTimeoutValue[0]          = 0.01;

	stateName[1]                  = "FireA";
	stateTransitionOnTimeout[1]   = "FireB";
	stateWaitForTimeout[1]        = True;
	stateTimeoutValue[1]          = 0.03;
	stateEmitter[1]               = gunFlashEmitter;
	stateEmitterTime[1]           = 0.03;

	stateName[2]                  = "FireB";
	stateTransitionOnTimeout[2]   = "FireC";
	stateWaitForTimeout[2]        = True;
	stateTimeoutValue[2]          = 0.03;
	stateEmitter[2]               = genericrifleFlashEmitter; 
	stateEmitterTime[2]           = 0.03;

	stateName[3]                  = "FireC";
	stateTransitionOnTimeout[3]   = "Done";
	stateWaitForTimeout[3]        = True;
	stateTimeoutValue[3]          = 0.03;
	stateEmitter[3]               = gunSmokeEmitter;
	stateEmitterTime[3]           = 0.03;

	stateName[4]                  = "Done";
	stateScript[4]                = "onDone";
};
function hvymgSmokeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

package hvymgPackage
{
   function Player::burn(%obj,%time)
   {
      if(%obj.dataBlock $= hvymgTurretPlayer)
         return;
      else
         Parent::burn(%obj,%time);
   }
   
   function Player::emote(%obj,%emote)
   {
      if(%obj.dataBlock $= hvymgTurretPlayer)
	      return;
      Parent::emote(%obj,%emote);
   }

	function Player::HvyFire(%obj,%slot,%val)
	{
	  if(!%val) {cancel(%obj.reshoot);return;}
      %mount = %obj.getObjectMount();
      %datablock = gunProjectile;
      %spread = 0.0015;
      
      if(!%mount.hasFired)
      {
		%mount.hasFired = 1;
		%mount.ammo = $HMG::Maxammo;
		%mount.firable = 1;
      }
      
      if(isObject(%mount) && %mount.firable = 1 && %mount.reloading != 1)
      {
         if(%mount.getDataBlock() == hvymgTurretPlayer.getId() && %slot == 0 && %val)
         {
            %client = %obj.client;
            if(isObject(%client))
            {
               ServerCmdUnUseTool(%client);
               %client.player.playThread(2, wrench);
               %client.player.playThread(1, armreadyboth);
            }

            if(getSimTime() - %mount.lastShotTime < 100)
               return;
            
            %mount.ammo -= 1;
			%mount.maxammo = $HMG::Maxammo;
			
			if(%mount.ammo <= 0)
			{
				%mount.firable = 0;
				%mount.reloading = 1;
				bottomprint(%obj.client, "<just:center><font:impact:30><color:FF0000>Reloading!", 5);
				schedule(5000, 0, resumeFire, %mount);
			}
			else
			{
				bottomprint(%client, "<just:center><color:FF0000>Ammo <color:FFFFFF>: <font:impact:30><color:FFFF00>" @ %mount.Ammo, 1, 1);
			}
            
            %vector = %mount.getEyeVector();
			%objectVelocity = %mount.getVelocity();
			%vector1 = VectorScale(%vector, %datablock.muzzleVelocity);
			%vector2 = VectorScale(%objectVelocity, %datablock.velInheritFactor);
			%velocity = VectorAdd(%vector1,%vector2);
			%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
			%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
			%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
			%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
			%velocity = MatrixMulVector(%mat, %velocity);
            
            %scaleFactor = getWord(%mount.getScale(), 2);
            %p = new Projectile()
            {
               dataBlock = %datablock;
               initialPosition = vectorAdd(%mount.getEyeTransform(),vectorScale(%mount.getEyeVector(),3));
               initialVelocity = %velocity;
               sourceObject = %obj;
               client = %obj.client;
               sourceSlot = 0;
               originPoint = vectorAdd(%mount.getEyeTransform(),vectorScale(%mount.getEyeVector(),3));
            };
            MissionCleanup.add(%p);
            %p.setScale("1 1 1");

            %mount.mountImage(hvymgSmokeImage,1);

            serverPlay3D(gunshot1Sound,%obj.getPosition());

            //%theVector = %mount.getEyeVector();
            //%theVector = vectorAdd(%theVector,"0 0 1");
            //%theVector = vectorScale(%theVector,%mount.getObjectMount().dataBlock.mass*5);
            //%theVector = vectorSub(%theVector,vectorScale(%thevector,2));
            //%mount.getObjectMount().applyImpulse(getWords(%mount.getEyeTransform(),0,2),%theVector);	
            
            //%obj.playThread(0,activate);
            %obj.lastShotTime = getSimTime();
            %obj.reshoot = %obj.schedule(33,HvyFire, %slot, %val);
            
            return;
         }
      }
    }

   function armor::onTrigger(%this, %obj, %triggerNum, %val)
   {
	  %obj.HvyFire(%triggerNum, %val);
      Parent::onTrigger(%this,%obj,%triggerNum,%val);
   }
};
activatepackage(hvymgPackage);

function resumeFire(%obj)
{
	%obj.firable = 1;
	%obj.ammo = $HMG::Maxammo;
	%obj.reloading = 0;
}

datablock DebrisData(hvyturretDebris)
{
   emitters = "jeepDebrisTrailEmitter";

	shapeFile = "./mg3.dts";
	lifetime = 3.0;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ExplosionData(hvymgTurretExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleExplosionEmitter;
   emitter[1] = vehicleExplosionEmitter2;

   debris = hvyturretDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 20;
   debrisVelocity = 18;
   debrisVelocityVariance = 3;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(hvymgTurretExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = hvymgTurretExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};