$remapDivision[$remapCount]	= "Rapid Fire";
$remapName[$remapCount]		= "Hold to use";
$remapCmd[$remapCount]		= "toggleSpam";
$remapCount++;
function toggleSpam(%value)
{
   if(%value)
   {
      lol();
   }
   else
   {
      cancel($Lol::Schedule);
   }
}

function lol()
{
  scrollTools(1);
  scrollTools(-1);
  $Lol::Schedule = schedule(33,0,lol);
}