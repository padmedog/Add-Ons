//dodgeball.cs contains all functions related to the dodgeball
//Utilities

function dodgeballCatchTestFoo(%obj)
{
	%type = $TypeMasks::ProjectileObjectType;
	%vec = vectorScale(%obj.getEyeVector(),2);
	%pos = vectorAdd( %obj.getEyePoint(), %vec);
	%radius = 1;

	initContainerRadiusSearch(%pos,%radius,%type);
	while((%target = containerSearchNext()) != 0)
	{
		%target = %target.getID();
		if(%target.getDataBlock().isSportBall)
		{
			%target.delete();
			%obj.mountImage(dodgeballImage,0);
		}
	}
}
//Datablocks
//Item only for testing will be removed later
datablock ItemData(dodgeballItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./dodgeball.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Ball Dodgeball";
	// iconName = "./icon_gun";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	isSportBall = 1;
	image = dodgeballImage;
	canDrop = true;
};

//Item onuse
function dodgeballItem::onUse(%this,%obj, %a)
{
	%obj.mountImage(dodgeballImage,0);
}

//Basketball bounce sound
datablock AudioProfile(dodgeballBounceSound)
{
   filename    = "./ballDodgeBounce.wav";
   description = AudioClosest3d;
   preload = true;
};

//Dodgeball projectile
datablock ProjectileData(dodgeballProjectile)
{
	sportBallImage = "dodgeballImage";
	projectileShapeName = "./dodgeball.dts";
	explosion           = "";
	bounceExplosion     = "";
	particleEmitter     = ballTrailEmitter;
	explodeOnDeath = true;

	brickExplosionRadius = 0;
	brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
	brickExplosionForce  = 0;             
	brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

	sound = "";

	muzzleVelocity      = 15;
	velInheritFactor    = 1.0;

	armingDelay         = 10000;
	lifetime            = 10000;
	fadeDelay           = 9500;
	bounceElasticity    = 0.85;//0.85;
	bounceFriction      = 0.2;//0.2;
	isBallistic         = true;
	gravityMod          = 1;
   ballRadius          = 0.3;

	hasLight    = false;

	uiName = "Ball Dodgeball"; 
};

//Projectile on collision
function dodgeballProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	//Play bounce sound and check that we haven't played it too recently
	%obj.playSportBallSound( dodgeballBounceSound );
	
	// do onBallHit event, only call this on bricks obviously
	if( %col.getType() & $TypeMasks::FxBrickObjectType )
		%col.onBallHit( %obj.sourceObject, %obj );
		
	//Kill check
	if(!%obj.hasBounced && %col.getType() & $TypeMasks::PlayerObjectType && minigameCanDamage(%obj.sourceObject, %col) == 1)
	{
		//do minigame checks then kill player use the cannon death image
		//%col.kill();
		%col.damage(%obj, %col.getposition(), 50000, $DamageType::CannonBallDirect);
	}
	
	// %speed = vectorLen( %obj.getVelocity() );

	//Pass check
	if( %obj.hasBounced &&  passBallCheck(%obj,%col) )
		return;
	
	%obj.hasBounced = 1;
	parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
}

//The image used for shooting, can't move while this is equiped
datablock ShapeBaseImageData(dodgeballImage)
{
	isSportBall = 1;
	// Basic Item properties
	shapeFile = "./dodgeball.dts";
	emap = true;

	mountPoint = 0;
	offset = "-0.5 0 -0";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	correctMuzzleVector = true;

	className = "WeaponImage";

	// Projectile && Ammo.
	// balls need to know about their item in image, for certain methods
	item = dodgeballItem;
	ammo = " ";
	projectile = dodgeballProjectile;
	projectileType = Projectile;

	//melee particles shoot from eye node for consistancy
	melee = false;
	//raise your arm up or not
	armReady = true;

	doColorShift = false;
	colorShiftColor = gunItem.colorShiftColor;//"0.400 0.196 0 1.000";

	//casing = " ";

	// Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "root";
	// stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	//stateScript[1]                  = "onCharge";
	stateAllowImageChange[1]	= true;

	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.1;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "Fire";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;

	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "Ready";
	stateTimeoutValue[3]		= 0.3;
	stateWaitForTimeout[3]		= true;
	stateScript[3]			= "onAbortCharge";
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateAllowImageChange[4]	= false;

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.1;
	stateFire[5]			= true;
	stateSequence[5]		= "fire";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;
	//stateSound[5]				= spearFireSound;
};

//Image states for shooting 
function dodgeballImage::onMount(%this,%obj)
{	
	%obj.hasSportBall = 1;
	%obj.playThread(3,root);
	%obj.playThread(1,armReadyBoth);
	parent::onMount(%this,%obj);
}

function dodgeballImage::onUnMount(%this,%obj)
{
	%obj.hasSportBall = 0;
	%obj.playThread(2,root);
}
function dodgeballImage::onCharge(%this,%obj,%slot)
{
	%obj.sportBallCharge = getSimTime();
}
function dodgeballImage::onFire(%this,%obj,%slot)
{
	// check if we just picked this up by clicking
	if( %obj.sbPickupTrigger )
		return;
	
	if(%obj.spawnTime+1000 > getSimTime())
		return;

	%power = 30;
	%zAdd = 4;

	%playerVel = %obj.getVelocity();
	%fVel =  vectorAdd( vectorScale(%obj.getMuzzleVector(0),%power) , "0 0" SPC %zAdd);

	%vel = vectorAdd( %fVel, %playerVel );
	
	%dataBlock = dodgeballProjectile;
	
	%p = %obj.spawnBall( %dataBlock, %vel );

	%p.isDodgeball = 1;

	%obj.unMountImage(0);

	%obj.playThread(2,root);
	%obj.playThread(1,root);
	%obj.playThread(3,activate2);
}
function dodgeballImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	//maybe we should make it so you have to click to bounce other dodgeballs off you?
}
