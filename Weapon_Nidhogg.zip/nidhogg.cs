//########## Nidhogg

//### Sounds

datablock AudioProfile(gc_NidhoggFireSound)
{
  filename = "./nidhogg.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_NidhoggExplosionSound)
{
  filename = "./explosion.wav";
  description = AudioDefault3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_NidhoggFlashParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 1400;
  lifetimeVarianceMS = 200;
  textureName = "base/data/particles/cloud";
  spinSpeed = 20;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "0.6 0.6 0.8 1";
  colors[1] = "0.4 0.4 0.4 0.3";
  colors[2] = "0.2 0.2 0.2 0";
  sizes[0] = 0.5;
  sizes[1] = 0.6;
  sizes[2] = 5;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_NidhoggFlashEmitter)
{
  uiName = "";
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 9;
  velocityVariance = 8;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 30;
  phiReferenceVel = 0;
  phiVariance = 360;
  particles = "gc_NidhoggFlashParticle";
};

datablock ParticleData(gc_NidhoggTrailParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 200;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.8 0.8 0.8 0.2";
  colors[1] = "0.2 0.2 0.2 0";
  sizes[0] = 0.5;
  sizes[1] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_NidhoggTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 2;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  particles = "gc_NidhoggTrailParticle";
};

datablock ParticleData(gc_NidhoggArchParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 2;
  lifetimeMS = 250;
  lifetimeVarianceMS = 0;
  textureName = "./arch";
  spinSpeed = 50;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "0.6 0.8 1 1";
  colors[1] = "0 0.2 1 1";
  colors[2] = "0 0.2 1 0";
  sizes[0] = 10;
  sizes[1] = 10;
  sizes[2] = 10;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_NidhoggArchEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 2;
  velocityVariance = 0;
  ejectionOffset = 4;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  orientParticles = true;
  particles = "gc_NidhoggArchParticle";
};

datablock ParticleData(gc_NidhoggSmokeParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1500;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -5;
  spinRandomMax = 5;
  colors[0] = "0.2 1 0.6 1";
  colors[1] = "0.2 0.3 0.3 1";
  colors[2] = "0.2 0.2 0.2 0";
  sizes[0] = 5;
  sizes[1] = 10;
  sizes[2] = 15;
  times[0] = 0;
  times[1] = 0.05;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_NidhoggSmokeEmitter)
{
  uiName = "";
  lifetimeMS = 100;
  ejectionPeriodMS = 10;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 2;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  particles = "gc_NidhoggSmokeParticle";
};

datablock ExplosionData(gc_NidhoggExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_NidhoggArchEmitter;
  emitter[1] = gc_NidhoggSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 10;
  lightEndRadius = 0;
  lightStartColor = "0 0.6 1";
  lightEndColor = "0 0 0";
  damageRadius = 10;
  radiusDamage = 100;
  impulseRadius = 15;
  impulseForce = 200;
  soundProfile = gc_NidhoggExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 10;
};

//### Projectile

AddDamageType("gc_Nidhogg",'<bitmap:Add-ons/Weapon_Nidhogg/CI_nidhogg> %1','%2 <bitmap:Add-ons/Weapon_Nidhogg/CI_nidhogg> %1',0.2,1);

datablock ProjectileData(gc_NidhoggProjectile)
{
  uiName = "";
  projectileShapeName = "Add-ons/Weapon_Nidhogg/grenade.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_Nidhogg;
  radiusDamageType = $DamageType::gc_Nidhogg;
  brickExplosionRadius = 2;
  brickExplosionImpact = true;
  brickExplosionForce = 25;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 1000;
  verticalImpulse = 500;
  explosion = gc_NidhoggExplosion;
  particleEmitter = gc_NidhoggTrailEmitter;
  muzzleVelocity = 50;
  verInheritFactor = 1;
  lifetime = 5000;
  fadeDelay = 2500;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  explodeOnDeath = true;
};

//### Item

datablock ItemData(gc_NidhoggItem)
{
  uiName = "Nidhogg";
  iconName = "./icon_nidhogg";
  image = gc_NidhoggImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./nidhogg.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_NidhoggImage)
{
  shapeFile = "./nidhogg.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_NidhoggItem;
  ammo = "";
  projectile = gc_NidhoggProjectile;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "Ready";

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Reload";
  stateTimeoutValue[2] = "0.8";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_NidhoggFlashEmitter;
  stateEmitterTime[2] = 0.05;
  stateEmitterNode[2] = "muzzlePoint";
  stateSound[2] = gc_NidhoggFireSound;
  stateScript[2] = "onFire";
  stateEjectShell[2] = true;
  stateSequence[2] = "Fire";

  stateName[3] = "Reload";
  stateTransitionOnTriggerUp[3] = "Ready";
};

function gc_NidhoggImage::onFire(%this,%obj,%slot)
{
  %spread = 0.001;
  if(vectorLen(%obj.getVelocity()) >= 5 && !isObject(%obj.getObjectMount())) %spread += 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
}
