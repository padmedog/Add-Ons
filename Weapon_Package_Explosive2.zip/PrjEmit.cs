package PrjEmit_Pack
{
	function Projectile::onAdd(%obj)
	{
		%prj=%obj.getdatablock();
		
		if(%prj.PrjEmit_Enabled)
		{
			%obj.PrjEmit_Tick=%obj.schedule(%prj.PrjEmit_TickTime,PrjEmit_Tick);
		}
		
		Parent::onAdd(%prj,%obj);
	}
};ActivatePackage(PrjEmit_Pack);

function Projectile::PrjEmit_Tick(%prj)
{
	for(%i=0;%i<%prj.getDatablock().PrjEmit_Ammount;%i++)
	{
		%a=getRandom(0,360)/360*2*$pi;
		%b=getRandom(0,360)/360*2*$pi;
		
		%vec=mcos(%a) SPC msin(%a) SPC mcos(%b);
		
		%p=new Projectile()
		{
			datablock=%prj.getDatablock().PrjEmit_Projectile;
			
			initialVelocity=vectorScale(%vec,%prj.getDatablock().PrjEmit_Velocity);
			initialPosition=%prj.getPosition();
			
			client = %prj.client;
			sourceObject=%prj.sourceobject;
			sourceSlot=%prj.sourceslot;
		};
	}
	%prj.emits++;
	
	if(%prj.emits >= %prj.getDatablock().PrjEmit_MaxEmits && %prj.getDatablock().PrjEmit_maxEmits!=-1)
	{
		if(%prj.getDatablock().PrjEmit_KillAfterLimit)
		{
			%prj.delete();
		}
		return;
	}
	
	%prj.PrjEmit_Tick=%prj.schedule(%prj.getDatablock().PrjEmit_TickTime,PrjEmit_Tick);
}