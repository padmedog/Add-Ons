function fxDTSbrick::setProperties(%brick,%colliding,%raycasting,%rendering)
{
	%brick.setColliding(%colliding);
	%brick.setRaycasting(%raycasting);
	%brick.setRendering(%rendering);
}
registerOutputEvent(fxDTSbrick,"setProperties","bool\tbool\tbool",0);
