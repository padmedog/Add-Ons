datablock AudioProfile(l4bMacheteHitSoundA)
{
	filename    = "./machete_impact_flesh1.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(l4bMacheteHitSoundB)
{
	filename    = "./machete_impact_flesh2.wav";
	description = AudioClose3d;
	preload = true;
};

//////////
// item //
//////////
datablock ItemData(l4bMacheteItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./machete.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Machete";
	iconName = "./icon_machete";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.75 1.000";

	 // Dynamic properties defined by the scripts
	image = l4bMacheteImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////

AddDamageType("L4BGuitar",   '<bitmap:Add-Ons/Weapon_Melee_Extended/ci_machete> %1',    '%2 <bitmap:Add-Ons/Weapon_Melee_Extended/ci_machete> %1',0.75,1);

AddDamageType("L4BMachete",%suicide,%kill,0.75,1);

datablock ShapeBaseImageData(l4bMacheteImage)
{
   shapeFile = "./machete.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 -0.1 0.0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "TF2MeleeWeaponImage";

   // Projectile && Ammo.
   item = l4bMacheteItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = l4bMacheteItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = l4bMacheteHitSoundA;
   raycastExplosionPlayerSound = l4bMacheteHitSoundB;
   raycastDirectDamage = 10;
   raycastDirectDamageType = $DamageType::L4BMachete;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateSequence[0]                 = "Activate";
	stateTransitionOnTimeout[0]      = "Ready";
	stateScript[0]                  = "onActivate";
	stateSound[0]                    = weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "FireA";
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateTimeoutValue[3]            = 0.80;
	stateAllowImageChange[3]        = false;
	stateSound[3]			= tf2MeleeSwingSound;
	stateScript[3]                  = "onMultiFire";
	stateSequence[3]                = "Activate";
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "PreFire";
	
	stateName[6]                    = "StopFire";
	stateTransitionOnTimeout[6]     = "Ready";
	stateTimeoutValue[6]            = 0.2;
	stateAllowImageChange[6]        = false;
	stateWaitForTimeout[6]		= true;
	stateSequence[6]                = "StopFire";
	stateScript[6]                  = "onStopFire";
};

function L4BMacheteImage::onMultiFire(%this, %obj, %slot)
{
	%obj.playthread(3, wrench);
	%obj.playthread(4, shiftLeft);
	%obj.playthread(2, shiftLeft);
	%obj.playthread(5, shiftLeft);
	%obj.playthread(6, shiftLeft);
	%obj.playthread(7, shiftLeft);
	%this.onFire(%obj,%slot);
	%this.schedule(100,onFire,%obj,0);
	%this.schedule(200,onFire,%obj,1);
	%this.schedule(300,onFire,%obj,2);
	%this.schedule(400,onFire,%obj,3);
}


function L4BMacheteImage::onFire(%this, %obj, %slot)
{
	if(!isObject(%obj) || %obj.getState() $= "Dead")
		return;
	
	%im = %obj.getMountedImage(0);
	if(!isObject(%im) || %im.getID() != %this.getID())
		return;
	
	if(getRandom(0,1))
	{
		%this.raycastExplosionBrickSound = L4BMacheteHitSoundA;
		%this.raycastExplosionPlayerSound = L4BMacheteHitSoundB;
	}
	else
	{
		%this.raycastExplosionBrickSound = L4BMacheteHitSoundB;
		%this.raycastExplosionPlayerSound = L4BMacheteHitSoundB;
	}
	
	if(%slot == 0)
	{
		%this.raycastExplosionProjectile = hammerProjectile;
	}
	else
	{
		%this.raycastExplosionProjectile = "";
		%this.raycastExplosionBrickSound = "";
	}

	WeaponImage::onFire(%this, %obj, %slot);
}

function l4bMacheteImage::onFireB(%this, %obj, %slot)
{
	//%obj.playthread(2, shiftaway);
}

function l4bMacheteImage::onActivate(%this, %obj, %slot)
{
	%obj.playthread(2, plant);
}
