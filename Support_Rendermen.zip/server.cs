// Init RTB (Required mod)
$Pref::Rendermen::Faces = 0;

RTB_registerPref("Enabled", "Rendermen", "Pref::Rendermen::Enabled", "bool", "Support_Rendermen", 1, 0, 0); // implamented
RTB_registerPref("Kick Players?", "Rendermen", "Pref::Rendermen::Kick", "bool", "Support_Rendermen", 1, 0, 0); // implamented
RTB_registerPref("Renderman Lights?", "Rendermen", "Pref::Rendermen::OwnLights", "bool", "Support_Rendermen", 1, 0, 0); // implamented
RTB_registerPref("Renderman Agro", "Rendermen", "Pref::Rendermen::Speed","list Paranormal 250 Evil 150 Demonic 100 Insane 75 Nightmare 25","Support_Rendermen", 150, 0, 0); // implamented
RTB_registerPref("Renderman Spawnrate", "Rendermen", "Pref::Rendermen::Spawnrate","list Don't 1337 Unsafe 30 Dangerous 23 Frightening 19 Insane 13 Nightmare 7","Support_Rendermen", 19, 0, 0); // implamented
RTB_registerPref("Renderman Limit", "Rendermen", "Pref::Rendermen::Limit","int 1 5","Support_Rendermen", 5, 0, 0); // implamented 
RTB_registerPref("Affect Map", "Rendermen", "Pref::Rendermen::Lights", "bool", "Support_Rendermen", 0, 0, 0); // buggy but implamented
//RTB_registerPref("Change Faces?", "Rendermen", "Pref::Rendermen::Faces", "bool", "Support_Rendermen", 1, 0, 0); // again buggy

// define main vars
$rendermeninmap = 0;
$Pref::Rendermen::Faces = 0;
$rendermancleanup = 0;
registerSpecialVar("GLOBAL","rendermen","$rendermeninmap"); // VCE: Use the replacer <var:global:rendermen> to access!

// load code
exec("./Support_AdminEvents.cs");
exec("./Functions.cs");
exec("./Datablocks.cs");
exec("./AI.cs");

// annoying preload announcement
//package RMOD_Preview_Inform
//{
//	function GameConnection::onClientEnterGame(%client)
//	{
//	messageClient(%client,'',"This server is running the Renderman Mod v3 preview 2. Please inform Chrisbot6 of bugs in the Modification Discussion topic!");
//	Parent::onClientEnterGame(%client);
//	}
//};
//activatepackage(RMOD_Preview_Inform);