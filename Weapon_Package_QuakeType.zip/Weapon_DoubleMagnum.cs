//doubleMagnums.cs

datablock AudioProfile(doubleMagnumSound)
{
   filename    = "./sawnoff.wav";
   description = AudioClose3d;
   preload = true;
};

//////////
// item //
//////////
datablock ItemData(doubleMagnumsItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./magnum.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Twin Magnums";
	iconName = "./twinmagnums";
	doColorShift = true;
	colorShiftColor = "0.6 0.6 0.61 1.000";

	 // Dynamic properties defined by the scripts
	image = doubleMagnumsImage;
	canDrop = true;
};

AddDamageType("doubleMagnums",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_twinmagnums> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_twinmagnums> %1',0.2,1);
////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(doubleMagnumsImage)
{
   // Basic Item properties
	shapeFile = "./magnum.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = doubleMagnumsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 100; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 20; //10
   raycastDirectDamageType = $DamageType::doubleMagnums;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "FireAkimbo";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.05;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = doubleMagnumSound;
   stateEmitter[2]					=  sniperRifleFireEmitter;
	stateEmitterTime[2]				= 0.09;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.6;
	stateTransitionOnTimeout[3]     = "Ready";
	stateEmitter[3]					= sniperrifleSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTimeout[4] = "FireAkimbo";
	stateSequence[4] = "ready";

	stateName[5] = "FireAkimbo";
	stateTimeoutValue[5] = 0.01;
	stateScript[5] = "onFireAkimbo";
	stateTransitionOnTimeOut[5] = "Smoke";
};


function doubleMagnumsImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}


datablock ShapeBaseImageData(LeftHandeddoubleMagnumImage)
{
   // Basic Item properties
	shapeFile = "./magnum.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = doubleMagnumsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 100; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 20; //10
   raycastDirectDamageType = $DamageType::doubleMagnums;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";
   stateSound[0]		= weaponSwitchSound;

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.05;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = doubleMagnumSound;
   stateEmitter[2]					=  sniperRifleFireEmitter;
	stateEmitterTime[2]				= 0.09;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.6;
	stateTransitionOnTimeout[3]     = "Reload";
	stateEmitter[3]					= sniperrifleSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "Ready";
	stateSequence[4] = "ready";
};

function LeftHandeddoubleMagnumImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-3")));
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	Parent::onFire(%this,%obj,%slot);

	%obj.playThread(2, leftrecoil);

	////////////////////////////////////////////////////
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylineSniperrifle(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylineSniperrifle(%start, %end);
	}
	%line.schedule(50, delete);
}

function LeftHandeddoubleMagnumImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}

function doubleMagnumsImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-3")));
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	Parent::onFire(%this,%obj,%slot);

	%obj.playThread(0, shiftAway);

	////////////////////////////////////////////////////
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylineSniperrifle(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylineSniperrifle(%start, %end);
	}
	%line.schedule(50, delete);
}

function doubleMagnumsImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}

function doubleMagnumsImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftHandeddoubleMagnumImage, 1);
   //%obj.playThread(0, armreadyboth);
}
function doubleMagnumsImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount lefthanded gun
   %obj.unMountImage(1);
   //%obj.playThread(0, root);
}


function LeftHandeddoubleMagnumImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function LeftHandeddoubleMagnumImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
}
