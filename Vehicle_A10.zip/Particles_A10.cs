datablock ParticleData(A10tracerTrailParticle)
{
dragCoefficient      = 0;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 300.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

	colors[0]     = "0.9 0.9 0 0.3";
	colors[1]     = "1 0.5 0.2 0.5";
	colors[2]     = "1 0.5 0.2 0.0";

	sizes[0]      = 0.05;
   sizes[1]      = 0.15;
	sizes[2]      = 0.05;

   times[0] = 0.1;
   times[1] = 0.2;
   times[2] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(A10tracerTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "A10tracerTrailParticle";
};
datablock ParticleData(A10MissileABParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = -0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 20;
	lifetimeVarianceMS   = 10;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

	colors[0]     = "0.9 0.9 0 0.3";
	colors[1]     = "1 0.5 0.2 0.5";
	colors[2]     = "1 0.5 0.2 0.0";

	sizes[0]      = 0.55;
   sizes[1]      = 0.44;
	sizes[2]      = 0.22;

   times[0] = 0.1;
   times[1] = 0.5;
   times[2] = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(A10MissileABEmitter)
{
  ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 48.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "A10MissileABParticle";
};
datablock ParticleData(A10Flareparticle)
{
	textureName          = "base/data/particles/chunk";
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 2000;
	lifetimeVarianceMS   = 300;
	
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "1 1 1 1";
	colors[1]     = "1 1 1 0";
	sizes[0]      = 0.5;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(A10FlareEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = A10Flareparticle;   
   
   useEmitterColors = true;
};
datablock ParticleData(A10DamageParticle)
{

  textureName = "base/data/particles/cloud";
	dragCoefficient      = 5;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 2000;
	lifetimeVarianceMS   = 300;
	
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.1 0.1 0.1 0.1";
	colors[1]     = "0.1 0.1 0.1 0.4";
	colors[1]     = "0.1 0.1 0.1 0.4";
	
	sizes[0]      = 3.5;
	sizes[1]      = 2.5;
	sizes[2]      = 1.5;
useInvAlpha = true;
};

datablock ParticleEmitterData(A10DamageEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = A10DamageParticle;   
};
datablock ParticleData(A10CannonParticle)
{
	textureName          = "base/data/particles/cloud";
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 000;

	colors[0]	= ".7 .7 .7 0.0";
	colors[1]	= "1 1 1 0.5";
	colors[2]	= ".7 .7 .7 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 1.0;
	sizes[2]	= 0.6;
	
   times[0] = 0.1;
   times[1] = 0.5;
   times[2] = 1.0;

};

datablock ParticleEmitterData(A10CannonEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = A10CannonParticle;   
   
   useEmitterColors = true;


};