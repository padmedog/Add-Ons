datablock fxDTSBrickData(brick1x1F_TileData)
{
	brickFile = "./1x1F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x1F Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x1F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x2F_TileData)
{
	brickFile = "./1x2F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x2F Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x2F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x3F_TileData)
{
	brickFile = "./1x3F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x3F Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x3F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x4F_TileData)
{
	brickFile = "./1x4F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x4F Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x4F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x6F_TileData)
{
	brickFile = "./1x6F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x6F Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x6F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x8F_TileData)
{
	brickFile = "./1x8F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x8F Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x8F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x2F_TileData)
{
	brickFile = "./2x2F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "2x2F Tile";
	iconName = "Add-Ons/Brick_TilePlates/2x2F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x3F_TileData)
{
	brickFile = "./2x3F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "2x3F Tile";
	iconName = "Add-Ons/Brick_TilePlates/2x3F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x4F_TileData)
{
	brickFile = "./2x4F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "2x4F Tile";
	iconName = "Add-Ons/Brick_TilePlates/2x4F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x6F_TileData)
{
	brickFile = "./2x6F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "2x6F Tile";
	iconName = "Add-Ons/Brick_TilePlates/2x6F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x8F_TileData)
{
	brickFile = "./2x8F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "2x8F Tile";
	iconName = "Add-Ons/Brick_TilePlates/2x8F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick3x3F_TileData)
{
	brickFile = "./3x3F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "3x3F Tile";
	iconName = "Add-Ons/Brick_TilePlates/3x3F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick4x4F_TileData)
{
	brickFile = "./4x4F_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "4x4F Tile";
	iconName = "Add-Ons/Brick_TilePlates/4x4F_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x1Corner_TileData)
{
	brickFile = "./1x1Corner_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "1x1F Corner Tile";
	iconName = "Add-Ons/Brick_TilePlates/1x1Corner_Tile";

	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x2Corner_TileData)
{
	brickFile = "./2x2Corner_Tile.blb";
	category = "Plates";
	subCategory = "Tile Plates";
	uiName = "2x2F Corner Tile";
	iconName = "Add-Ons/Brick_TilePlates/2x2Corner_Tile";

	orientationFix = 1;
};