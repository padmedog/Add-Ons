//Slayer_Main
exec("./Slayer_Main/Slayer_Main.gui");
exec("./Slayer_Main/scripts.cs");
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Slayer_Main/Tabs/Slayer_General/*");
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Slayer_Main/Tabs/Slayer_Teams/*");
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Slayer_Main/Tabs/Slayer_Advanced/*");
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Slayer_Main/Tabs/Slayer_Help/*");

//Slayer_Options
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Slayer_Options/*");

//Slayer_CtrDisplay
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Slayer_CtrDisplay/*");

//Other
Slayer_Support::LoadFiles($Slayer::Client::Path @ "/GUI/Other/*");