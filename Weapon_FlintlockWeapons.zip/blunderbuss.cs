//########## Blunderbuss

//### Projectile

AddDamageType("gc_Blunderbuss",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_blunderbuss> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_blunderbuss> %1',0.2,1);

datablock ProjectileData(gc_BlunderbussProjectile)
{
  uiName = "";
  projectileShapeName = "Add-Ons/Weapon_FlintlockWeapons/lead.dts";
  directDamage = 8;
  directDamageType = $DamageType::gc_Blunderbuss;
  radiusDamageType = $DamageType::gc_Blunderbuss;
  brickExplosionRadius = 0;
  brickExplosionImpact = false;
  impactImpulse = 500;
  verticalImpulse = 0;
  particleEmitter = "";
  explosion = gunExplosion;
  particleEmitter = gc_GrenadeTrailEmitter;
  muzzleVelocity = 150;
  lifetime = 1000;
  fadeDelay = 1000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
};

//### Item

datablock ItemData(gc_BlunderbussItem)
{
  uiName = "Blunderbuss";
  iconName = "./icon_blunderbuss";
  image = gc_BlunderbussImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./blunderbuss.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_BlunderbussImage)
{
  shapeFile = "./blunderbuss.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_BlunderbussItem;
  ammo = "";
  projectile = gc_BlunderbussProjectile;
  projectilespread = 0.0035;
  projectilecount = 13;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Smoke";
  stateTimeoutValue[2] = "0.05";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_MusketMuzzleEmitter;
  stateEmitterTime[2] = 0.1;
  stateEmitterNode[2] = "muzzlePoint";
  stateSound[2] = gc_MusketFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Fire";

  stateName[3] = "Smoke";
  stateTransitionOnTimeout[3] = "AmmoCheck";
  stateTimeoutValue[3] = "0.15";
  stateAllowImageChange[3] = false;
  stateWaitForTimeout[3] = true;
  stateEmitter[3] = gc_MusketMuzzleEmitter;
  stateEmitterTime[3] = 0.02;
  stateEmitterNode[3] = "lockPoint";

  stateName[4] = "AmmoCheck";
  stateTransitionOnTimeout[4] = "Ready";
  stateAllowImageChange[4] = true;
  stateScript[4] = "onAmmoCheck";

  stateName[5] = "Reload";
  stateTimeoutValue[5] = 1.5;
  stateTransitionOnTimeout[5] = "Done";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReloadStart";
  stateSequence[5] = "Reload";

  stateName[6] = "Done";
  stateTransitionOnTimeout[6] = "Ready";
  stateTimeoutValue[6] = 0.1;
  stateAllowImageChange[6] = true;
  stateScript[6] = "onReload";
};

//### Functions

function gc_BlunderbussImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %obj.spawnExplosion(gc_weaponRecoil,"1 1 1");
  %spread = %this.projectilespread;
  for(%shell=0;%shell<%this.projectilecount;%shell++) {
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  }; }
  MissionCleanup.add(%p);
}
function gc_BlunderbussImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_BlunderbussImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,shiftRight); serverPlay3D(gc_FLReloadStartSound,%obj.getPosition()); }
function gc_BlunderbussImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(0,1); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }

function gc_BlunderbussProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(miniGameCanDamage(%obj,%col) && getMiniGameFromObject(%col) != -1) {
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
  if(%col.isCrouched() != 1) {
  %colscale = getWord(%col.getScale(),2);
  if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale)
  { %col.damage(%obj,%pos,%this.directDamage/2,%this.directDamageType); } } }
  if(%col.getType() & $TypeMasks::VehicleObjectType)
  { %col.damage(%obj,%pos,0.5,%this.directDamageType); return 1; } }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}
