//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier2");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Skins_RifleT2- required add-on Weapon_Package_Tier2 not found");
}
else
{
   //exec("./Weapon_AutomaticRifle.cs"); 
   exec("./Weapon_CombatRifle.cs"); 
   exec("./Weapon_ClassicAR.cs"); 
   //exec("./Weapon_ScoutAR.cs"); 
   exec("./Weapon_ClassicBR.cs"); 
   //exec("./Weapon_SemiBR.cs"); 
}
