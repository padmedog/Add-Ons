datablock fxDTSBrickData ( brickDoor_ShojiDouble2_OpenCWData )
{
	brickFile = "./ShojiDouble2_openCW.blb";
	uiName = "Shoji Double Door 2";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_ShojiDouble2_ClosedCWData";
	openCW = "brickDoor_ShojiDouble2_OpenCWData";
	
	closedCCW = "brickDoor_ShojiDouble2_ClosedCWData";
	openCCW = "brickDoor_ShojiDouble2_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_ShojiDouble2_OpenCCWData : brickDoor_ShojiDouble2_OpenCWData )
{
	brickFile = "./ShojiDouble2_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_ShojiDouble2_ClosedCWData : brickDoor_ShojiDouble2_OpenCWData )
{
	brickFile = "./ShojiDouble2_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Eastern/bricks/ShojiDouble2";

	isOpen = 0;
};