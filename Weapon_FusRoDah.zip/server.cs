datablock AudioProfile(FusSound)
{
   filename    = "./Sounds/UnrelentingForceHigh.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(FusAfterSound)
{
   filename    = "./Sounds/UnrelentingForceAfter.wav";
   description = AudioClosest3d;
   preload = true;
};


//effects
datablock ParticleData(FusExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/chunk";
   colors[0]     = "0.7 0.7 0.9 0.9";
   colors[1]     = "0.9 0.9 0.9 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};

datablock ParticleData(FusTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/thinRing";
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	colors[0]     = "0.0 0.0 1.0 1.0";
	colors[1]     = "0.0 0.0 1.0 1.";
   colors[2]     = "0.0 0.0 1.0 1.0";
   colors[3]     = "0.0 0.0 1.0 1.0";

	sizes[0]      = 4;
	sizes[1]      = 4;
   sizes[2]      = 4;
 	sizes[3]      = 4;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.3;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(FusTrailEmitter)
{
   ejectionPeriodMS = 0.1;
   periodVarianceMS = 0.1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.1;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "FusTrailParticle";

   uiName = "Unrelenting Force Trail";
};

datablock ParticleEmitterData(FusExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "FusExplosionParticle";

   uiName = "FusRoDah Hit";
};

datablock ExplosionData(FusExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 500;

   //soundProfile = swordHitSound;

   particleEmitter = swordExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "5.0 5.0 5.0";
   camShakeDuration = 0.2;
   camShakeRadius = 10.0;
   
   damageRadius = 10;
   radiusDamage = 0.001;
   
   impulseRadius = 6;
   impulseForce = 0;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 0;
   lightStartColor = "00.0 0.2 0.6";
   lightEndColor = "0 0 0";
};


//projectile
AddDamageType("FusRoDah",   '<bitmap:add-ons/Weapon_Sword/CI_sword> %1',    '%2 <bitmap:add-ons/Weapon_Sword/CI_sword> %1',0.75,1);
datablock ProjectileData(FusProjectile)
{
   directDamage        = 0.0001;
   directDamageType  = $DamageType::Fus;
   radiusDamageType  = $DamageType::Fus;
   explosion           = FusExplosion;
   particleEmitter     = FusTrailEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)
   
   muzzleVelocity      = 150;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "0 0 1";
   
   scale = "15 15 15";

   uiName = "FusRoDah";
};


//////////
// item //
//////////
datablock ItemData(FusItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./empty.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "FusRoDah";
	iconName = "";
	doColorShift = true;
	colorShiftColor = "0 0 0 1.000";

	 // Dynamic properties defined by the scripts
	image = FusImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(FusImage)
{
   // Basic Item properties
   shapeFile = "./empty.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = "0.7 1.2 -0.25";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = FusItem;
   ammo = " ";
   projectile = FusProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = false;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0 0 0 0";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";
	
	stateName[2]					= "PreFire";
	stateTransitionOnTimeout[2]		= "Fire";
	stateTimeoutValue[2]			= 0.95;
	stateAllowImageChange[2]        = false;
	stateSequence[2]				= "PreFire";
	stateScript[2]					= "OnPreFire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Smoke";
	stateTimeoutValue[3]            = 0.1;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]			= true;
	stateSound[3]					= FusAfterSound;

	stateName[4] = "Smoke";
	stateTimeoutValue[4]            = 4;
	stateTransitionOnTimeout[4]     = "Reload";

	stateName[5]			= "Reload";
	stateSequence[5]                = "Reload";
	stateTransitionOnTriggerUp[5]     = "Ready";
	stateSequence[5]	= "Ready";


};

function FusImage::onPreFire(%this,%obj,%slot)
{
	%obj.playaudio(1, FusSound);
}

function FusProjectile::Damage(%this,%obj,%col,%fade,%pos,%normal)
{
   %target = containerRayCast(%obj.client.player.getEyePoint(), vectorAdd(vectorScale(vectorNormalize(%obj.client.player.getEyeVector()), 2), %obj.client.player.getEyePoint()), $typeMasks::playerObjectType);
   %col.setVelocity(vectorAdd(%target.getVelocity(),vectorScale(%obj.client.player.getEyeVector(),"25")));
   tumble(%col, 7000);
}

//function FusExplosion::Damage(%this,%obj,%col,%fade,%pos,%normal)
//{
//   %col.setVelocity(vectorAdd(%target.getVelocity(),vectorScale(%this.client.player.getEyeVector(),"18")));
//   tumble(%col, 7000);
//}