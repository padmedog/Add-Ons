//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier2");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Skins_Sniper - this is enabled but Weapon_Package_Tier2 isn't here, forcing anyway...");
	exec("add-ons/weapon_package_tier2/server.cs");

   exec("./Weapon_MagnifiedSniper.cs"); 
   exec("./Weapon_ClassicSniper.cs"); 
   exec("./Weapon_RetroSniper.cs"); 
}
else
{
   exec("./Weapon_MagnifiedSniper.cs"); 
   exec("./Weapon_ClassicSniper.cs"); 
   exec("./Weapon_RetroSniper.cs"); 
}
