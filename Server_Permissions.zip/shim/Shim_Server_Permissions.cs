package PermissionsShimV1 {
    function getPermissionManager() {
        if (!isObject(PermissionManager)) {
            new ScriptObject(PermissionManager) {
                knownClientCount = 0;
            };
        }
        return PermissionManager;
    }

    function PermissionManager::validatePermName(%this, %name) {
        %nameLen = strLen(%name);
        if (%nameLen <= 0)
            return false;
        for (%i = 0;%i < %nameLen;%i++) {
            if (strIPos($Permissions::ValidPermNameChars, getSubStr(%name, %i, 1)) == -1)
                    return false;
        }
        return true;
    }

    function PermissionManager::registerPermission(%this, %friendlyName, %name, %default) {
        if (%default $= "") {
            %default = %name;
            %name = %friendlyName;
            %friendlyName = "";
        }
        %default = mClamp(%default, 0, 4);
        if (%this.validatePermName(%name)) {
            %id = $Permissions::PermissionByName[%name];
            if (%id $= "") {
                %id = $Permissions::PermissionCount + 0;
                $Permissions::PermissionCount++;
                $Permissions::PermissionByName[%name] = %id;
            }
            $Permissions::PermissionFriendlyName[%id] = %friendlyName;
            $Permissions::PermissionName[%id] = %name;
            $Permissions::PermissionDefaultAdminLevel[%id] = %default;
            for(%i = 0; %i < ClientGroup.getCount(); %i++)
            {
                %c = ClientGroup.getObject(%i);
                if(%c.bl_id == getNumKeyId() || %c.hasPermission("permissions.modify"))
                {
                    commandtoclient(%c, '', "PERM", %name);
                }
            }
        } else {
            error("Invalid permission name \"" @ %name @ "\".");
        }
    }

    function GameConnection::getAdminLevel(%this) {
        if (%this.getName() $= "localclientconnection" || %this.bl_id == getNumKeyID())
            return 3;
        if (%this.isSuperAdmin)
            return 2;
        if (%this.isAdmin)
            return 1;
        return 0;
    }

    function GameConnection::hasPermission(%this, %permission) {
        %permID = $Permissions::PermissionByName[%permission];
        return %permID !$= "" && %this.getAdminLevel() >= $Permissions::PermissionDefaultAdminLevel[%permID];
    }
};

if ($Permissions::ValidPermNameChars $= "")
    $Permissions::ValidPermNameChars = "abcdefghijklmnopqrstuvwxyz1234567890.-";

if (1 > $Permissions::Shim::Version) {
    if ($Permissions::Shim::Version !$= "")
        deactivatePackage("PermissionsShimV" @ $Permissions::Shim::Version);

    $Permissions::Shim::Version = 1;
    activatePackage("PermissionsShimV" @ $Permissions::Shim::Version);
}