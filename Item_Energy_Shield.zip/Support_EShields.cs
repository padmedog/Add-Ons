
datablock AudioProfile(shieldLHitSound)
{
   filename    = "./shield_deflect1.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(shieldLHitAltSound)
{
   filename    = "./shield_deflect2.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(shieldLrechargeSound)
{
   filename    = "./shield_regen.wav";
   description = AudioClosest3d;
   preload = true;
};
datablock AudioProfile(shieldLfinishSound)
{
   filename    = "./shield_capoff.wav";
   description = AudioClosest3d;
   preload = true;
};

//////////////////////////////////////////////////////////////////
//use these variables in a ___Item (e.g. BowItem)

//%item.is_dmshield;				//is the item a shield?
//%item.dmshield_amount;			//max shield energy
//%item.dmshield_rechargeincrement;		//amount that is recharged
//%item.dmshield_damageleak;			//percent of damage that carries through to hp
//%item.dmshield_maxdamage;			//most damage that can be done per hit
//%item.dmshield_carryover;			//any damage done over capacity is carried over at this percentage
//%item.dmshield_rechargerate;			//ms between recharges
//%item.dmshield_hurtrechargerate;		//ms after damage before recharge begins
//%item.dmshield_explosiontype;			//type of explosion (MUST BE A PROJECTILE DATABLOCK)

//[DISCONTINUED]				%item.dmshield_damagepercent;			//percent done to shield
//[DISCONTINUED]				%item.dmshield_soundcount;			//number of shield hit sounds (should be +1 of the highest sounds[#] you specify; 
//							if you go up to sounds[4], this should be 5, sounds[0] makes this 1, no sound makes this 0)
//[DISCONTINUED]				%item.dmshield_sounds[#];			//specifies sound datas for hits (ex. %item.dmshield_sounds[0]="WeaponSwitchSound";)
//[DISCONTINUED]				%item.dmshield_rc_soundcount;			//number of recharge sounds (see above soundcount for elaboration)
//[DISCONTINUED]				%item.dmshield_rc_sounds[#];			//specifies sound datas for recharging (ex. %item.dmshield_rc_sounds[0]="WeaponSwitchSound";)
//[DISCONTINUED]				%item.dmshield_rcfin_soundcount;			//number of recharge finishing sounds (see above soundcount for elaboration)
//[DISCONTINUED]				%item.dmshield_rcfin_sounds[#];			//specifies sound datas for finishing a recharge (ex. %item.dmshield_rcfin_sounds[0]="WeaponSwitchSound";)
//[DISCONTINUED]				%item.dmshield_rcstr_soundcount;			//number of recharge starting sounds (see above soundcount for elaboration)
//[DISCONTINUED]				%item.dmshield_rcstr_sounds[#];			//specifies sound datas for start of recharging (ex. %item.dmshield_rcstr_sounds[0]="WeaponSwitchSound";)


//$DamageType::yourdamagetypehere;
//$dmshield_piercing[ $DamageType::yourdamagetypehere ] = 1; // does the damagetype ignore shields? (ex is yes)
//$dmshield_haspercent[ $DamageType::yourdamagetypehere ] = 1; // does the damgetype have a percent modification? NECESSARY TO USE THE NEXT ATTRIBUTE (ex is yes)
//$dmshield_percent[ $DamageType::yourdamagetypehere ] = 1.5; // what percent damage does this damagetype do to shields? (ex is 150%)

//ex:
//AddDamageType("RIGLDirect",   '%1 \c1Got caught in his own explosion',    '%2 \c1impacted \c0%1 \c1into oblivion',1,1);
//$dmshield_piercing[ $DamageType::RIGLDirect ] = 1;




registerOutputEvent("Player", "setShield", "int 0 10000 0", 0);

function Player::Setdmshield(%p,%id2){
	%p.dmshield=%id2;
}

registerOutputEvent("Player", "addShield", "int -10000 10000 -10000", 0);

function Player::Adddmshield(%p,%id2){
	%p.dmshield+=%id2;
	if(%p.dmshield>%p.dmshield_max){
		%p.dmshield=%p.dmshield_max;
	}
}

package DMShieldSystem
{
function Armor::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
{
	if (%obj.getState() $= "Dead" || !isObject(%obj)){
		return;
	}

	//echo("DT" SPC %damageType);

	for(%i=0;%i<%this.maxTools;%i++)
	{
		%item = %obj.tool[%i];
		if(%item.is_dmshield)
		{
			//echo(%item.is_dmshield SPC "_" SPC %item.dmshield_amount);
			%hasShield = 1;
			%s_amnt=%item.dmshield_amount;//max shield energy
			%s_rinc=%item.dmshield_rechargeincrement;//amount that is recharged
			%s_perc=%item.dmshield_damagepercent;//percent done to shield
			%s_leak=%item.dmshield_damageleak;//percent of damage that carries through to hp
			%s_maxd=%item.dmshield_maxdamage;//percent of damage that carries through to hp
			%s_over=%item.dmshield_carryover;//percent of damage that carries through to hp
			%s_rate=%item.dmshield_rechargerate;//ms between recharges
			%s_drte=%item.dmshield_hurtrechargerate;//ms after damage before recharge begins
			%s_expl=%item.dmshield_explosiontype;//type of explosion
			break;
		}
	}

	if(%s_maxd<=0){
		%s_maxd=1000000;
	}

	%dts_piercing = $dmshield_piercing[%damageType];
	%dts_haspercent = $dmshield_haspercent[%damageType];
	%dts_percent = $dmshield_percent[%damageType];

	if(%hasShield)
	{
		//ARMOR STUFFS HERE
		if(!%dts_piercing){
			if(!%obj.dmshieldinit){
				%obj.dmshieldinit=1; // one time shield set
				%obj.dmshield=%s_amnt;
			}
			%obj.dmshield_max=%s_amnt; // shield max adjusts to whatever shield you're using
			if(%obj.dmshield>0){
				//%damage *= %s_perc;
				if(%dts_haspercent){
					%damage*=%dts_percent;
				}

				%obj.spawnExplosion(%s_expl,"1.1 1.1 1.1"); 
				//echo("TYPE" SPC %s_expl);

				serverPlay3D(shieldLHitSound,%obj.getPosition());
				%obj.setNodeColor("ALL","1 1 1 1");

				schedule(180, 0, dmshield_return, %obj);

				%oldshield=%obj.dmshield;
				%olddamage=%damage;

				if(%damage>%s_maxd){
					%damage=%s_maxd;
				}
				%obj.dmshield-=%damage;
				if(%obj.dmshield<0){
					%obj.dmshield=0;
				}
				if(!%obj.dmshield_recharge){
				}else{
					cancel(%obj.dmshield_recharge);
				}
				%obj.dmshield_recharge=schedule(%s_drte,0,"dmshield_recharge",%this,%obj,%s_rate,%s_rinc,0);
		centerprint(%obj.client,"<font:impact:24><color:ffffff>Shield at <color:fff000>" @ %obj.dmshield @ " / " @ %obj.dmshield_max @ " capacity.",2);
				%damage=%olddamage;
				if(%obj_dmshield<=0){
					%damage-=%oldshield;
					%damage *= %s_over;
				}else{
					%damage *= %s_leak; // if damageleak is 0, then shield blocks hp damage
				}
			}
		}else{
			
		}

	//END OF ARMOR STUFFS
	}

	
	parent::damage(%this,%obj,%sourceObject,%position,%damage,%damageType);
}
};
ActivatePackage("DMShieldSystem");

function dmshield_recharge(%this,%obj,%rate,%amn,%start){
	if(!isobject(%obj)){
		return;
	}

	for(%i=0;%i<%this.maxTools;%i++)
	{
		%item = %obj.tool[%i];
		if(%item.is_dmshield)
		{
			//echo(%item.is_dmshield SPC "_" SPC %item.dmshield_amount);
			%hasShield = 1;
			%s_amnt=%item.dmshield_amount;//max shield energy
			%s_rinc=%item.dmshield_rechargeincrement;//amount that is recharged
			%s_perc=%item.dmshield_damagepercent;//percent done to shield
			%s_leak=%item.dmshield_damageleak;//percent of damage that carries through to hp
			%s_maxd=%item.dmshield_maxdamage;//percent of damage that carries through to hp
			%s_over=%item.dmshield_carryover;//percent of damage that carries through to hp
			%s_rate=%item.dmshield_rechargerate;//ms between recharges
			%s_drte=%item.dmshield_hurtrechargerate;//ms after damage before recharge begins
			%s_expl=%item.dmshield_explosiontype;//type of explosion
			%s_rcstr=%item.dmshield_startsound;//sound recoup start
			%s_rcfin=%item.dmshield_endsound;//sound end start
			%s_rc=%item.dmshield_sound;//sound while regenerating
			break;
		}
	}

	if(!%start){
		if(%obj.getDamagePercent() < 1.0)
		{
			//serverPlay3D(%s_rcstr,%obj.getPosition());
			serverPlay3D(shieldLrechargesound,%obj.getPosition());
			%obj.spawnExplosion(%s_expl,"1.7 1.7 1.7"); 
			%start=1;

			%obj.setNodeColor("ALL","1 1 0.5 1");

			schedule(180, 0, dmshield_return, %obj);
		}
	}
	
	%obj.dmshield+=%amn;
	if(%obj.dmshield>%obj.dmshield_max){
			%obj.dmshield=%obj.dmshield_max;
			centerprint(%obj.client,"<font:impact:24><color:ffffff>Shield at full <color:fff000>(" @ %obj.dmshield_max @ ") capacity.",3);
			//serverPlay3D(%s_rcfin,%obj.getPosition());
			serverPlay3D(shieldLfinishsound,%obj.getPosition());
			%obj.spawnExplosion(%s_expl,"0.75 0.75 0.75"); 

			%obj.setNodeColor("ALL","1 1 0.5 1");

			schedule(180, 0, dmshield_return, %obj);
			return;
	}else{
		centerprint(%obj.client,"<font:impact:24><color:ffffff>Shield at <color:fff000>" @ %obj.dmshield @ " / " @ %obj.dmshield_max @ " capacity.",2);
		//serverPlay3D(%s_rc,%obj.getPosition());
			%obj.spawnExplosion(%s_expl,"0.5 0.5 0.5"); 
	}
	
	%obj.dmshield_recharge=schedule(%rate,0,"dmshield_recharge",%this,%obj,%rate,%amn,%start);
	
}

function dmshield_return(%obj)
{
	%obj.client.applybodyparts();
	%obj.client.applyBodyColors();
}