//ThrowingDagger.cs
//ThrowingDagger and ThrowingKnife weapon stuff

datablock AudioProfile(ThrowingKnifeHitSound)
{
   filename    = "./WeaponHit.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ThrowingDaggerFireSound)
{
   filename    = "./WeaponDraw.wav";
   description = AudioClosest3d;
   preload = true;
};


//ThrowingKnife trail
datablock ParticleData(ThrowingKnifeTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 200;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/ring";
	//animTexName		= "~/data/particles/ring";

	// Interpolation variables
   	colors[0]     = "0.7 0.7 0.0 0.9";
  	colors[1]     = "0.5 0.5 0.0 0.0";
	sizes[0]	= 0.5;
	sizes[1]	= 0.1;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(ThrowingKnifeTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 1; //0.25;
   velocityVariance = 1; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = ThrowingKnifeTrailParticle;

   useEmitterColors = true;
   uiName = "ThrowingKnife Trail";
};

//effects
datablock ParticleData(ThrowingKnifeStickExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 300;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.7 0.7 0.0 0.9";
	colors[1]     = "0.5 0.5 0.0 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.0;
};
datablock ParticleEmitterData(ThrowingKnifeStickExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 80;
   thetaMax         = 80;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ThrowingKnifeStickExplosionParticle";

   useEmitterColors = true;
   uiName = "ThrowingKnife Stick";
};
datablock ExplosionData(ThrowingKnifeStickExplosion)
{
   //explosionShape = "";
	soundProfile = ThrowingKnifeHitSound;

   lifeTimeMS = 150;

   particleEmitter = ThrowingKnifeStickExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = "";

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 1;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};



datablock ParticleData(ThrowingKnifeExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.3;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 300;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
   	colors[0]     = "0.7 0.7 0.0 0.9";
   	colors[1]     = "0.5 0.5 0.0 0.0";
	sizes[0]      = 0.45;
	sizes[1]      = 0.0;

   useInvAlpha = true;
};
datablock ParticleEmitterData(ThrowingKnifeExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ThrowingKnifeExplosionParticle";

   useEmitterColors = true;
   uiName = "ThrowingKnife Vanish";
};
datablock ExplosionData(ThrowingKnifeExplosion)
{
   //explosionShape = "";
	soundProfile = "";

   lifeTimeMS = 50;

   emitter[0] = ThrowingKnifeExplosionEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 1;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};


//projectile
AddDamageType("ThrowingKnifeDirect",  'Riddled %1 With Daggers',    '%2 Riddled %1 with Daggers!',1,1);

datablock ProjectileData(ThrowingKnifeProjectile)
{
   projectileShapeName = "./ThrowingDaggerProjectile.dts";

   directDamage        = 40;
   directDamageType    = $DamageType::ThrowingKnifeDirect;

   radiusDamage        = 0;
   damageRadius        = 0;
   radiusDamageType    = $DamageType::ThrowingKnifeDirect;

   explosion             = ThrowingKnifeExplosion;
   stickExplosion        = ThrowingKnifeStickExplosion;
   bloodExplosion        = ThrowingKnifeStickExplosion;
   particleEmitter       = ThrowingKnifeTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = true;  

   armingDelay         = 4000;
   lifetime            = 4000;
   fadeDelay           = 4000;

   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   muzzleVelocity      = 55;
   velInheritFactor    = 1;

   uiName = "ThrowingKnife";
};


//////////
// item //
//////////
datablock ItemData(ThrowingDaggerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./ThrowingDagger.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Throwing Daggers";
	iconName = "./icon_ThrowingDagger";
	doColorShift = true;
	colorShiftColor = "0.400 0.196 0 1.000";

	 // Dynamic properties defined by the scripts
	image = ThrowingDaggerImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ThrowingDaggerImage)
{
   // Basic Item properties
   shapeFile = "./ThrowingDagger.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 10" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ThrowingDaggerItem;
   ammo = " ";
   projectile = ThrowingKnifeProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ThrowingDaggerItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.6;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.7;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= ThrowingDaggerFireSound;

	stateName[3]			= "Reload";
	stateSequence[3]                = "Reload";
	stateAllowImageChange[3]        = false;
	stateTimeoutValue[3]            = 0.6;
	stateWaitForTimeout[3]		= true;
	stateTransitionOnTimeout[3]     = "Check";

	stateName[4]			= "Check";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "Fire";

	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	//stateSequence[5]                = "Reload";
	stateScript[5]                  = "onStopFire";


};

function ThrowingDaggerImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, SpearThrow);
	Parent::onFire(%this,%obj,%slot);	
}
