//glowstick.cs

datablock AudioProfile(glowstickThrowSound)
{
   filename    = "./glowstickThrow.wav";
   description = AudioClose3d;
   preload = true;
};

datablock DebrisData(glowstickCapDebris)
{
	shapeFile = "./glowstickCap.dts";
	lifetime = 3.5;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ParticleData(glowstickExplosionParticle)
{
	dragCoefficient		= 0.1;
	windCoefficient		= 0.0;
	gravityCoefficient	= 2.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 1000;
	lifetimeVarianceMS	= 500;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/chunk";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.0 1.0 0.0 1.0";
	colors[1]	= "0.0 1.0 0.0 0.0";
	sizes[0]	= 0.4;
	sizes[1]	= 0.3;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(glowstickExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   lifetimeMS       = 7;
   ejectionVelocity = 5;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "glowstickExplosionParticle";

   useEmitterColors = true;
};

datablock ExplosionData(glowstickExplosion)
{
   lifeTimeMS = 150;

   emitter[0] = glowstickExplosionEmitter;
   //particleDensity = 30;
   //particleRadius = 1.0;

   lightStartRadius = 13;
   lightEndRadius = 0;
   lightStartColor = "0 1 0";
   lightEndColor = "0 0 0";
};

datablock ProjectileData(glowstickProjectile)
{
   projectileShapeName = "./glowstickProjectile.dts";
   explodeOnDeath = true;

   muzzleVelocity      = 30;
   velInheritFactor    = 1.0;
   explosion = glowstickExplosion;

   armingDelay         = 10000;
   lifetime            = 10000;
   fadeDelay           = 10000;
   bounceElasticity    = 0.35;
   bounceFriction      = 0.00;
   isBallistic         = true;
   gravityMod          = 1.0;

   hasLight    = true;

   lightRadius = 13.0;
   lightColor  = "0 1 0";
};


//////////
// item //
//////////
datablock ItemData(glowstickItem)
{
	category = "Item";  // Mission editor category

	 // Basic Item Properties
	shapeFile = "./glowstick.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Glowstick";
	iconName = "./icon_glowstick";
	doColorShift = false;
	colorShiftColor = "0.400 0.196 0 1.000";

	 // Dynamic properties defined by the scripts
	image = glowstickImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(glowstickImage)
{
   // Basic Item properties
   shapeFile = "./glowstick.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile & Ammo.
   item = glowstickItem;
   ammo = " ";
   projectile = glowstickProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

	casing = glowstickCapDebris;
	shellExitDir        = "0 -0.5 0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 0;	
	shellVelocity       = 5;

   hasLight    = false;

   doColorShift = false;
   colorShiftColor = "0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]	= true;
	
	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.7;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "AbortCharge";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;
	
	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "Ready";
	stateTimeoutValue[3]		= 0.3;
	stateWaitForTimeout[3]		= true;
	stateScript[3]			= "onAbortCharge";
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateAllowImageChange[4]	= false;

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.5;
	stateFire[5]			= true;
	stateSequence[5]		= "fire";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;
	stateEjectShell[5]              = true;
	stateEmitter[5]			= glowstickExplosionEmitter;
	stateEmitterTime[5]		= 0.09;
	stateSound[5]			= glowstickThrowSound;
};

function glowstickImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
}

function glowstickImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function glowstickImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, spearThrow);
	Parent::onFire(%this, %obj, %slot);
}