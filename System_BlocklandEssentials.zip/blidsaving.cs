//This isn't even a thing anymore
//I will take this out soon, it's not executed

function saveBricksByBLID(%blid)
{
	$savingByBLID = true;
	$blidToSave = %blid;
	$bricksSavedByBLID = 0;
	$bricksIgnoredByBLID = 0;
	
	SaveBricks_Save();
	
	echo($bricksSavedByBLID SPC "bricks saved.");
	echo($bricksIgnoredByBLID SPC "bricks ignored.");
	$savingByBLID = false;
}

package blidSaver
{
	function SaveBricks_WriteSingleBrick(%arg1,%brick)
	{
		echo(%arg1 SPC %brick);
		if($savingByBLID)
		{
			if(%brick.bl_id == $blidToSave)
			{
				$bricksSavedByBLID++;
				return parent::savebricks_writesinglebrick(%art1,%brick);
			}
			else
				$bricksIgnoredByBLID++;
		}
		else
			return parent::savebricks_writesinglebrick(%art1,%brick);
	}
};
activatepackage(blidSaver);
