datablock ParticleData(homingRocketTrailParticle : rocketTrailParticle)
{
   colors[0]     = "1 0 1 0.4";
   colors[1]     = "0.2 0 1 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";
   lifetimeMS = 2000;
};
datablock ParticleEmitterData(homingRocketTrailEmitterB : rocketTrailEmitter)
{
   particles = "homingRocketTrailParticle";
};

datablock ProjectileData(homingRocketLauncherProjectile)
{
   projectileShapeName = "Add-Ons/Projectile_GravityRocket/RocketGravityProjectile.dts";
   directDamage        = 30;
   directDamageType = $DamageType::RocketDirect;
   radiusDamageType = $DamageType::RocketRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = rocketExplosion;
   particleEmitter     = homingRocketTrailEmitterB;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = errorSound;

   muzzleVelocity      = 40;
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "0 0.1 0.6";

   uiName = "Rocket, Homing";
};

package HomingRocket
{
	function Projectile::onAdd(%obj,%a,%b)
	{
		Parent::onAdd(%obj,%a,%b);
		if(%obj.dataBlock.getID() == homingRocketLauncherProjectile.getID())
		{
			if(!%obj.doneHomingDelay)
				%obj.schedule(300,spawnHomingRocket);
			else
				%obj.schedule(75,spawnHomingRocket);
		}
	}
};activatePackage(HomingRocket);

function Projectile::spawnHomingRocket(%this)
{
	if(!isObject(%this.client))
		return;
	
	if(!isObject(%this) || vectorLen(%this.getVelocity()) == 0)
		return;
		
	%client = %this.client;
	%muzzle = vectorLen(%this.getVelocity());
	
	if(!isObject(%this.target) || %this.target.getState() $= "Dead" || %this.target.getMountedImage(0) == adminWandImage.getID() || vectorDist(%this.getPosition(),%this.target.getHackPosition()) > 30)
	{
		%pos = %this.getPosition();
		%radius = 100;
		%searchMasks = $TypeMasks::PlayerObjectType;
		InitContainerRadiusSearch(%pos, %radius, %searchMasks);
		%minDist = 1000;
		while ((%searchObj = containerSearchNext()) != 0 )
		{
			if((miniGameCanDamage(%client,%searchObj)) == 1)
			{
				if(%searchObj.getState() $= "Dead")
					continue;
				
				//if(%client == %searchObj.client)
				if(%this.sourceObject == %searchObj)
					continue;
				
				if(isTeamFriendly(%this,%searchObj) != 0)
					continue;
				
				if(%searchObj.getMountedImage(0) == adminWandImage.getID())
					continue;
				
				if(%searchObj.isCloaked)
					continue;
				
				%d = vectorDist(%pos,%searchObj.getPosition());
				if(%d < %minDist)
				{
					%minDist = %d;
					%found = %searchObj;
				}
			}
		}
		
		if(isObject(%found))
			%this.target = %found;
		else
		{
			%this.schedule(300,spawnHomingRocket);
			return;
		}
	}
	
	%found = %this.target;
	
	%pos = %this.getPosition();
	%start = %pos;
	%end = %found.getHackPosition();
	%enemypos = %end;
	%vec = vectorNormalize(vectorSub(%end,%start));
	for(%i=0;%i<5;%i++)
	{
		%t = vectorDist(%start,%end) / vectorLen(vectorScale(getWord(%vec,0) SPC getWord(%vec,1),%muzzle));
		%velaccl = vectorScale(%accl,%t);
		
		%x = getword(%velaccl,0);
		%y = getword(%velaccl,1);
		%z = getWord(%velaccl,2);
		
		%x = (%x < 0 ? 0 : %x);
		%y = (%y < 0 ? 0 : %y);
		%z = (%z < 0 ? 0 : %z);
		
		%vel = vectorAdd(vectorScale(%found.getVelocity(),%t),%x SPC %y SPC %z);
		%end = vectorAdd(%enemypos,%vel);
		%vec = vectorNormalize(vectorSub(%end,%start));
	}
	
	%addVec = vectorAdd(%this.getVelocity(),vectorScale(%vec,180/vectorDist(%pos,%end)*(%muzzle/40)));
	%vec = vectorNormalize(%addVec);
	
	%p = new Projectile()
	{
		dataBlock = %this.dataBlock;
		initialPosition = %pos;
		initialVelocity = vectorScale(%vec,%muzzle);
		sourceObject = %this.sourceObject;
		client = %this.client;
		sourceSlot = 0;
		originPoint = %this.originPoint;
		doneHomingDelay = 1;
		target = %this.target;
		reflectTime = %this.reflectTime;
	};
	
	if(isObject(%p))
	{
		MissionCleanup.add(%p);
		%p.setScale(%this.getScale());
		%this.delete();
	}
}

function isTeamFriendly(%obj1,%obj2)
{
	// 0 = enemy
	// 1 = allied
	//-1 = neutral
	%mini1 = getMinigameFromObject(%obj1);
	%mini2 = getMinigameFromObject(%obj2);
	if(%mini1 != %mini2)
		return -1;
	
	if(!isObject(%mini1))
		return -1;
	
	if(%obj1 == %obj2)
		return 1;
	
	//With Team Deathmatch, players on different TDM teams are enemies, as well as those in team -1 (neutral)
	%usingTDM = (isObject(GameModeStorerSO) && GameModeStorerSO.modeUsesTeams[%mini1.gamemode]);
	
	//With either zombie mod, players that are on a zombies team and players that aren't are enemies (handily both are "player.isZombie")
	
	//Iban's zombies will never run with Team Deathmatch
	%usingIbanZombies = ($ZAPT::Version > 0 && miniGameUsingTDMGameMode(%mini1) && %mini1.ZAPT_enabled);
	
	//Rotondo's zombies can - if enabled, players on a neutral TDM team are allied.
	%usingRotZombies = ($pref::Server::ZombiesEnabled && %mini1.EnableZombies);
	
	switch$(%obj1.getClassName())
	{
		case "Player":
			%cl1 = %obj1.client;
			%zombie1 = (%usingIbanZombies && %obj1.isZombie);
		case "AIPlayer":
			%zombie1 = %obj1.isZombie;
			if(isObject(%obj1.client))
				%cl1 = %obj1.client;
			else if(isObject(%obj1.spawnBrick) && %usingTDM)
				%team1 = %obj1.spawnBrick.tdmAlliedTeam-1;
		case "Projectile":
			%zombie1 = (isObject(%obj1.sourceObject) && (%obj1.sourceObject.getType() & $TypeMasks::PlayerObjectType) && %obj1.sourceObject.isZombie);
			%cl1 = %obj1.client;
		case "GameConnection":
			%zombie1 = (%obj1.player.isZombie);
			%cl1 = %obj1;
		case "AIConnection":
			%zombie1 = (%obj1.player.isZombie);
			%cl1 = %obj1;
		default:
			return -1;
	}
	
	if(%usingTDM && %tdmTeam1 $= "" && isObject(%cl1))
		%team1 = %cl1.tdmTeam;
	
	switch$(%obj2.getClassName())
	{
		case "Player":
			%cl2 = %obj2.client;
			%zombie2 = (%usingIbanZombies && %obj2.isZombie);
		case "AIPlayer":
			%zombie2 = %obj2.isZombie;
			if(isObject(%obj2.client))
				%cl2 = %obj2.client;
			else if(isObject(%obj2.spawnBrick) && %usingTDM)
				%team2 = %obj2.spawnBrick.tdmAlliedTeam-1;
		case "Projectile":
			%zombie2 = (isObject(%obj2.sourceObject) && (%obj2.sourceObject.getType() & $TypeMasks::PlayerObjectType) && %obj2.sourceObject.isZombie);
			%cl2 = %obj2.client;
		case "GameConnection":
			%zombie2 = (%obj2.player.isZombie);
			%cl2 = %obj2;
		case "AIConnection":
			%zombie2 = (%obj2.player.isZombie);
			%cl2 = %obj2;
		default:
			return -1;
	}
	
	if(%usingTDM && %tdmTeam2 $= "" && isObject(%cl2))
		%team2 = %cl2.tdmTeam;
	
	//echo(%team1 SPC %team2);
	
	if(%usingTDM && %team1 == %team2)
	{
		if(%team1 == -1)
			return %usingRotZombies;
		
		return 1;
	}
	
	if(%usingIbanZombies || %usingRotZombies)
		return (%zombie1 == %zombie2);
	
	return 0;
}

//////////
// item //
//////////
datablock ItemData(homingRocketLauncherItem : rocketLauncherItem)
{
	uiName = "Homing Rocket";
	doColorShift = true;
	colorShiftColor = "0.2 0 1";
	
	image = homingRocketLauncherImage;
};

datablock ShapeBaseImageData(homingRocketLauncherImage : rocketLauncherImage)
{
	projectile = homingRocketLauncherProjectile;
	colorShiftColor = homingRocketLauncherItem.colorShiftColor;
};


function homingRocketLauncherImage::onFire(%this,%obj,%slot)
{
	if((%obj.lastFireTime+%this.minShotTime) > getSimTime())
		return;
	%obj.lastFireTime = getSimTime();

	%projectile = %this.projectile;
	%spread = 0.002;
	%shellcount = 3;
	%scaleFactor = getWord(%obj.getScale(),2)/2;
	
	%client = %obj.client;
	%pos = %obj.getHackPosition();

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
		%p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
	}
	return %p;
}