if(!($bvss::numvars > 0) && !($bvss::numvars < 0))
	$bvss::numvars = 0;

function BVSS_isVar(%name)
{
	for(%a=0;%a<$bvss::numvars;%a++)
		if($bvss::brickvar[%a] $= %name)
			return true;
	return false;
}

function BVSS_addVar(%name,%condition)
{
	if(BVSS_isVar(%name))
	{
		echo("BVSS Error - Brick variable already registered.");
		return;
	}

	if(strpos(%name,";") != -1 || strpos(%condition,";") != -1)
	{
		echo("BVSS Error - Variables cannot contain semicolons.");
		return;
	}

	if($bvss::numvars < 1)
		$bvss::numvars = 0;

	$bvss::brickvar[$bvss::numvars] = %name;
	$bvss::brickcond[$bvss::numvars] = %condition;
	$bvss::numvars++;

	echo("BVSS Notice - Brick variable " @ %name @ " [" @ $bvss::numvars-1 @ "] registered.");
}

function BVSS_getCondition(%brick,%var)
{
	if(!isObject(%brick))
		return false;

	%index = 0;
	for(%a=0;%a<$bvss::numvars;%a++)
		if($bvss::brickvar[%a] $= %var)
			%index = %a;
	%cond = $bvss::brickcond[%index];
	if(%cond $= "" || %cond $= " ")
		return true;

	%istrue = false;
	eval("%istrue = " @ %brick @ "." @ %cond @ ";");

	if(!%istrue)
		return false;
	else
		return true;
}

function BVSS_getVar(%brick,%var)
{
	if(!isObject(%brick))
		return 0;
	%that = 0;
	eval("%that = " @ %brick @ "." @ %var @ ";");
	return %that;
}

function BVSS_printName(%brick)
{
	if(!isObject(%brick))
		return "";
	if(!%brick.getDataBlock().hasPrint)
		return "";
	%path = filePath(getPrintTexture(%brick.getPrintID()));
	%p = strPos(%path,"_");
	return getSubStr(%path,%p,strPos(%path,"_",14)-14) @ "/" @ fileBase(getPrintTexture(%brick.getPrintID()));
}

function BVSS_printFix(%printname)
{
	if(%printname $= "" || %printname $= " ")
		return 0;
	%end = getSubStr(%printname,strpos(%printname,"/"),strlen(%printname)-strpos(%printname,"/"));
	return $printNameTableLetters[%end];
}

function BVSS_rotation(%angleID)
{
	if(%angleID == 0)
		return "1 0 0 0";
	if(%angleID == 1)
		return "0 0 1 90";
	if(%angleID == 2)
		return "0 0 1 180";
	if(%angleID == 3)
		return "0 0 -1 90";
	
}

function BVSS_saveBricks(%filelocation,%noownership,%description)
{
	%savefile = new FileObject();
	%savefile.openForWrite(%filelocation);
	%savefile.writeLine("This is a Blockland save file, you probably shouldn't modify it.");
	%savefile.writeLine("This has been saved with DrenDran\'s Server_BrickValues and cannot be loaded without it.");
	%savefile.writeLine(%description);
	%savefile.writeLine("2");
	if(%noownership)
		%savefile.writeLine("1");
	else
		%savefile.writeLine("0");

	for(%a=0;%a<mainBrickGroup.getCount();%a++)
	{
		%brickGroup = mainBrickGroup.getObject(%a);
		if(isObject(%brickGroup))
		{
			for(%b=0;%b<%brickGroup.getCount();%b++)
			{
				%brick = %brickGroup.getObject(%b);
				if(isObject(%brick))
				{
					%datablock = %brick.dataBlock.getName();
					if(getSubStr(%datablock,0,5) $= "brick" && getSubStr(%datablock,strlen(%datablock)-4,4) $= "Data")
						%datablock = getSubStr(%datablock,5,strlen(%datablock)-9);
					else
						%datablock = "|" @ %datablock;

					%line = %datablock;
					%line = %line TAB %brick.position;
					%line = %line TAB %brick.angleID;
					if(!%noownership)
						%line = %line TAB %brickGroup.bl_id;
					%line = %line TAB %brick.colorID;

					if(%brick.colorFxID == 0 && %brick.shapeFxID == 0 && %brick.isColliding() && %brick.isRendering() && %brick.isRayCasting() && !(strlen(%brick.getName()) > 1) && !(strlen(BVSS_printName(%brick)) > 0) && !isObject(%brick.emitter) && !isObject(%brick.item) && !(%brick.getLightID() > 0) && !isObject(%brick.audioEmitter) && !isObject(%brick.vehicleDatablock))
					{

					}
					else
					{

					%line = %line TAB %brick.colorFxID;
					%line = %line TAB %brick.shapeFxID;

					if(%brick.isColliding() && %brick.isRendering() && %brick.isRayCasting() && !(strlen(%brick.getName()) > 1) && !(strlen(BVSS_printName(%brick)) > 0) && !isObject(%brick.emitter) && !isObject(%brick.item) && !(%brick.getLightID() > 0) && !isObject(%brick.audioEmitter) && !isObject(%brick.vehicleDatablock))
					{

					}
					else
					{

						%line = %line TAB !%brick.isColliding();
						%line = %line TAB !%brick.isRendering();
						%line = %line TAB !%brick.isRayCasting();

						if( !(strlen(%brick.getName()) > 1) && !(strlen(BVSS_printName(%brick)) > 0) && !isObject(%brick.emitter) && !isObject(%brick.item) && !(%brick.getLightID() > 0) && !isObject(%brick.audioEmitter) && !isObject(%brick.vehicleDatablock))
						{
						
						}
						else
						{
							if(strlen(%brick.getName()) > 1)
								%line = %line TAB getSubStr(%brick.getName(),1,strlen(%brick.getName())-1);
							else
								%line = %line TAB "";
							%line = %line TAB BVSS_printName(%brick);

							if(!isObject(%brick.emitter) && !isObject(%brick.item) && !(%brick.getLightID() > 0) && !isObject(%brick.audioEmitter) && !isObject(%brick.vehicleDatablock))
							{

							}
							else
							{

							if(isObject(%brick.emitter))
								%line = %line TAB %brick.emitter.emitter.getName() SPC %brick.emitterDirection;
							else
								%line = %line TAB "!";
							if(%brick.getLightID() >= 0)
								%line = %line TAB %brick.getLightID().getDataBlock().getName();
							else
								%line = %line TAB "!";
							if(isObject(%brick.item))
								%line = %line TAB %brick.item.getDataBlock().getName() SPC %brick.itemPosition SPC %brick.itemDirection SPC %brick.itemRespawnTime;
							else
								%line = %line TAB "!";
							if(isObject(%brick.audioEmitter))
								%line = %line TAB $uiNameTable_Music[%brick.audioEmitter.getProfileID().uiname].getName();
							else
								%line = %line TAB "!";
							if(isObject(%brick.vehicleDatablock))
								%line = %line TAB %brick.vehicleDatablock.getName();
							else
								%line = %line TAB "!";

							}
						}

					}

					}

					%saveFile.writeLine(%line);

					for(%c=0;%c<%brick.numEvents;%c++)
					{
						%line = "e";
						%line = %line TAB %c;
						%line = %line TAB %brick.eventEnabled[%c];
						%line = %line TAB %brick.eventInput[%c];
						%line = %line TAB %brick.eventDelay[%c];
						%line = %line TAB %brick.eventTarget[%c];
						%line = %line TAB %brick.eventNT[%c];
						%line = %line TAB %brick.eventOutput[%c];
						for(%d=0;strlen(%brick.eventOutputParameter[%c, %d + 1]) > 0; %d++)
							%line = %line TAB %brick.eventOutputParameter[%c, %d + 1];
						%saveFile.writeLine(%line);
					}

					for(%v=0;%v<$bvss::numvars;%v++)
						if(BVSS_getcondition(%brick,$bvss::brickvar[%v]))
							%saveFile.writeLine("v" TAB $bvss::brickvar[%v] TAB BVSS_getVar(%brick,$bvss::brickvar[%v]));
				}
			}
		}
	}
	%saveFile.close();
	%saveFile.delete();
}

function BVSS_loadBricks(%filelocation,%client)
{
	deleteVariables("$bvss::loadedPosition*");
	$notLoadedDueToPosition = 0;
	$notLoadedDueToDatablock = 0;
	$bvssLoadedBricks = 0;

	%loadFile = new FileObject();
	%loadFile.openForRead(%filelocation);
	%loadFile.readLine();
	%loadFile.readLine();
	%loadFile.readLine();
	%version = %loadFile.readLine();
	%noownership = %loadFile.readLine();
	
	echo("Save file version: " @ %version);

	if(%version == 2)
	{

	while(!%loadFile.isEOF())
	{
		%line = %loadFile.readLine();

		if(getWord(%line,0) $= "event" || getField(%line,0) $= "event" || getWord(%line,0) $= "e" || getField(%line,0) $= "e")
		{
			if(isObject($lastloadedbrick) && isObject($lastloadedbrick.dataBlock))
			{
			%number = getField(%line,1);
			%enabled = getField(%line,2);
			%input = getField(%line,3);
			%delay = getField(%line,4);
			%target = getField(%line,5);
			%nt = getField(%line,6);
			%output = getField(%line,7);

			$lastloadedbrick.addEvent(%enabled,%delay,%input,%target,%output);

			$lastloadedbrick.eventEnabled[%number] = %enabled;
			$lastloadedbrick.eventInput[%number] = %input;
			$lastloadedbrick.eventDelay[%number] = %delay;
			$lastloadedbrick.eventTarget[%number] = %target;
			$lastloadedbrick.eventNT[%number] = %nt;
			$lastloadedbrick.eventOutput[%number] = %output;

			for(%a = 8; (getField(%line,%a) !$= "end" && strlen(getField(%line,%a)) > 0); %a++)
				$lastloadedbrick.eventOutputParameter[%number,%a-7] = getField(%line,%a);
			}
		}
		else if(getWord(%line,0) $= "v" || getField(%line,0) $= "v" || getWord(%line,0) $= "var" || getField(%line,0) $= "var")
		{
			if(isObject($lastloadedbrick))
			{
				if(getField(%line,2) !$= "" && getField(%line,2) !$= " ")
					eval($lastloadedbrick @ "." @ getField(%line,1) @ " = " @ getField(%line,2) @ ";");
			}
		}
		else
		{

			%dataBlock = getField(%line,0);
			if(getSubStr(%dataBlock,0,1) !$= "|")
				%dataBlock = "brick" @ %dataBlock @ "Data";
			else
				%dataBlock = getSubStr(%dataBlock,1,strlen(%dataBlock)-1);

			if(isObject(%dataBlock))
			{

			%position = getField(%line,1);

			if(!$bvss::loadedPosition[%position])
			{
			$bvssLoadedBricks++;
			$bvss::loadedPosition[%position] = true;
			%angle = getField(%line,2);
			if(%noownership == "1")
			{
				%owner = 888888;
				if(!isObject(%client))
					%owner = 888888;
				else
					%owner = %client.bl_id;
				%color = getField(%line,3);
				%colorFX = getField(%line,4);
				%shapeFX = getField(%line,5);
				%colliding = getField(%line,6);
				%rendering = getField(%line,7);
				%raycasting = getField(%line,8);
				%name = getField(%line,9);
				%printName = getField(%line,10);
				%emitter = getField(%line,11);
				%light = getField(%line,12);
				%item = getField(%line,13);
				%audio = getField(%line,14);
				%vehicle = getField(%line,15);
			}
			else
			{
				%owner = getField(%line,3);
				%color = getField(%line,4);
				%colorFX = getField(%line,5);
				%shapeFX = getField(%line,6);
				%colliding = getField(%line,7);
				%rendering = getField(%line,8);
				%raycasting = getField(%line,9);
				%name = getField(%line,10);
				%printName = getField(%line,11);
				%emitter = getField(%line,12);
				%light = getField(%line,13);
				%item = getField(%line,14);
				%audio = getField(%line,15);
				%vehicle = getField(%line,16);
			}

			$lastloadedbrick = new fxDTSBrick()
			{
				client = findclientbybl_id(%owner);
				stackBL_ID = %owner;
				datablock = %dataBlock;
				position = %position;
				angleID = %angle;
				colorID = %color;
				rotation = BVSS_rotation(%angle);
				isPlanted = 1;
				colorFxID = %colorfx;
				shapeFxID = %shapefx;
			};

			$lastloadedbrick.plant();
			$lastloadedbrick.setTrusted(1);
			$lastloadedbrick.dataBlock.onTrustCheckFinished($lastloadedbrick);
			$brickgroup = -1;
			eval("$brickgroup = BrickGroup_" @ %owner @ ";");
			if(isObject($brickGroup))
				$brickgroup.add($lastloadedbrick);
			else
				BrickGroup_888888.add($lastLoadedBrick);
			$lastloadedbrick.setRayCasting(!%raycasting);
			$lastloadedbrick.setRendering(!%rendering);
			$lastloadedbrick.setColliding(!%colliding);
			if($lastloadedbrick.dataBlock.hasPrint)
				$lastloadedbrick.setPrint(BVSS_printFix(%printName));

			if(%light !$= "!" && %light !$= "" && %light !$= " ")
				$lastloadedbrick.setLight(%light);
			if(%emitter !$= "!" && %emitter !$= "" && %emitter !$= " ")
			{
				$lastloadedbrick.setEmitter(getWord(%emitter,0));
				$lastloadedbrick.setEmitterDirection(getWord(%emitter,1));
			}
			if(%vehicle !$= "!" && %vehicle !$= "" && %vehicle !$= " ")
				$lastloadedbrick.setVehicle(%vehicle.getID());
			if(%audio !$= "!" && %audio !$= "" && %audio !$= " ")
				$lastloadedbrick.setMusic(%audio);
			if(%item !$= "!" && %item !$= " " && %item !$= "")
			{
				$lastloadedbrick.setItem(getWord(%item,0));
				$lastloadedbrick.setItemPosition(getWord(%item,1));
				$lastloadedbrick.setItemDirection(getWord(%item,2));
				$lastloadedbrick.setItemRespawnTime(getWord(%item,3));
			}
			if(strlen(%name) > 0)
				$lastloadedbrick.setNTObjectName(%name);

			}
			else
			{
				$notLoadedDueToPosition++;
			}
			}
			else
			{
				$notLoadedDueToDatablock++;
			}
		}
	}

		talk("Bricks loaded: " @ $bvssLoadedBricks);
		talk("Bricks omitted due to overlapping positions: " @ $notLoadedDueToPosition);
		talk("Bricks omitted due to nonexistant datablock: " @ $notLoadedDueToDatablock);
		echo("Bricks loaded: " @ $bvssLoadedBricks);
		echo("Bricks omitted due to overlapping positions: " @ $notLoadedDueToPosition);
		echo("Bricks omitted due to nonexistant datablock: " @ $notLoadedDueToDatablock);

	}
	else
	{
		talk("Invalid save version: " @ %version);
		echo("Invalid save version: " @ %version);
	}
			

	%loadFile.close();
	%loadFile.delete();
}

















