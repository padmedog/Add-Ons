//gun.cs

datablock AudioProfile(fireballRifleFireSound)
{
   filename    = "./rifleFireball.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("fireballRifle",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_fireballrifle> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_fireballrifle> %1',0.2,1);
datablock ProjectileData(fireballRifleProjectile : gunProjectile)
{
   projectileShapeName = "./quake_grenade.dts";
   directDamage        = 60;
   directDamageType    = $DamageType::fireballRifle;
   radiusDamageType    = $DamageType::fireballRifle;

   impactImpulse	     = 400;
   verticalImpulse	  = 100;
   explosion           = quakeShotgunExplosion;
   particleEmitter     = fireballMissileEmitter; //bulletTrailEmitter;

   muzzleVelocity      = 190;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 6000;
   fadeDelay           = 5500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.25;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(fireballRifleItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./fireball_rifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Fireball Rifle";
	iconName = "./fireballrifle";
	doColorShift = true;
	colorShiftColor = "0.75 0.75 0.75 1.000";

	 // Dynamic properties defined by the scripts
	image = fireballRifleImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(fireballRifleImage)
{
   // Basic Item properties
	shapeFile = "./fireball_rifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = fireballRifleProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = fireballRifleItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakeShotgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= fireballRifleFireSound;
	stateEjectShell[2]       = true;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[3]				= 0.11;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.13;
	stateTransitionOnTimeout[3]     = "Ready";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

};

function fireballRifleImage::onFire(%this,%obj,%slot)
{
	%projectile = fireballRifleProjectile;
	%spread = 0.0015;
	%shellcount = 1;

	%obj.playThread(2, plant);
	%shellcount = 1;
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function fireballRifleProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 10;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {     
      %col.damage(%obj, %pos, %directDamage, %damageType);
	%col.mountImage(afterburnImage, 2);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}
