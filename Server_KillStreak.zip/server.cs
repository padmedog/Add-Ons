//----------------------------------------
// Killstreaks
//
// Revision: 3
//
// Created by TomTom BL_ID:3694
//
// Name: Server.cs
//
// Voices all by me :D
//
//	Licence (Cuz i can :D): Script_Killstreak, and voices are by Thomas Gambs is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License. for more information
//	see http://creativecommons.org/licenses/by-nc/3.0/
//
// tl-dr credit me if u want to redisribute it
//
// If you find any bugs in the script or just need to contact me please email
// admin@forumit.co.uk thanks
//----------------------------------------

exec("./main.cs");
//Datablocks for my epic voice ;D

	datablock AudioProfile(HolyShit)
	{
		filename    = "./HolyShit.wav";
		description = Audio2d;
	};

	datablock AudioProfile(KillingSpree)
	{
		filename    = "./KillingSpree.wav";
		description = Audio2d;
	};

	datablock AudioProfile(TripleKill)
	{
		filename    = "./TripleKill.wav";
		description = Audio2d;
	};

	datablock AudioProfile(ThisAintHappening)
	{
		filename    = "./ThisAintHappening.wav";
		description = Audio2d;
	};

	datablock AudioProfile(HowTheFuck)
	{
		filename    = "./Howthefuck.wav";
		description = Audio2d;
	};

	datablock AudioProfile(GodLike)
	{
		filename    = "./GodLike.wav";
		description = Audio2d;
	};
	
	datablock AudioProfile(Revenge)
	{
		filename    = "./Revenge.wav";
		description = Audio2d;
	};
	datablock AudioProfile(Domination)
	{
		filename    = "./Domination.wav";
		description = Audio2d;
	};

//Datablocks End
$KillstreakMod::SlayerModeEnabled=0;