//Grenader.cs;

datablock AudioProfile(GrenaderFireSound)
{
   filename    = "./grenade_launcher.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock ParticleData(GrenadeSmokeParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1200;
	lifetimeVarianceMS   = 350;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "0.5 0.5 0.5 0.0";
	colors[1]     = "0.5 0.5 0.5 0.1";
	colors[2]     = "0.5 0.5 0.5 0.0";

	sizes[0]      = 1.55;
   sizes[1]      = 0.3;
	sizes[2]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.38;
   times[2] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(GrenadeSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 2.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "GrenadeSmokeParticle";
};

datablock ExplosionData(GrenaderExplosion : RPGExplosion)
{
   //explosionShape = "";

   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";

   damageRadius = 15;
   radiusDamage = 60;

   impulseRadius = 16;
   impulseForce = 3000;
};

AddDamageType("GrenaderDirect",   '<bitmap:add-ons/Weapon_Package_Explosive2/CI_Grenade_launcher> %1',    '%2 <bitmap:add-ons/Weapon_Package_Explosive2/CI_Grenade_launcher> %1',1,1);
datablock ProjectileData(GrenaderProjectile)
{
   projectileShapeName = "./grenade_projectile.2.dts";
   directDamage        = 100;
   directDamageType = $DamageType::GrenaderDirect;
   radiusDamageType = $DamageType::GrenaderDirect;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = GrenaderExplosion;
   particleEmitter     = GrenadeSmokeEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;             
   brickExplosionMaxVolume = 76;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 98;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 95;
   velInheritFactor    = 0.0;

   armingDelay         = 0;
   lifetime            = 3500;
   fadeDelay           = 3500;
   bounceElasticity    = 0.7;
   bounceFriction      = 0.40;
   isBallistic         = true;
   gravityMod = 1;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "GL Grenade";
};

//////////
// item //
//////////
datablock ItemData(GrenaderItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
   shapeFile = "./M79.DTS";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Grenade Launcher";
	iconName = "./grenadelauncher";
	doColorShift = false;
	colorShiftColor = "0.40 0.40 0.42 1.000";

	 // Dynamic properties defined by the scripts
	image = GrenaderImage;
	canDrop = true;

	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(GrenaderImage)
{
   // Basic Item properties
   shapeFile = "./M79.DTS";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = GrenaderItem;
   ammo = " ";
   projectile = GrenaderProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 700;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = true;
   colorShiftColor = GrenaderItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.35;
	stateScript[0]                  = "onActivate";
	stateSequence[0]                = "Reload";
	stateSound[0]					= weaponSwitchSound;
	stateTransitionOnTimeout[0]       = "FireLoadCheckA";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnNoAmmo[1]		= "ReloadStart";
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Delay";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateEmitter[2]			  = shotgunExplosionRingEmitter;
	stateEmitterTime[2]		  = 0.03;
	stateSequence[2]                  = "Fire";
	stateScript[2]                  = "onFire";
	stateSound[2]					= GrenaderFireSound;
	stateWaitForTimeout[2]			= true;

	stateName[3]			= "Delay";
	stateTransitionOnTimeout[3]     = "ReloadStart";
	stateTimeoutValue[3]            = 0.1;
	stateSequence[3]                  = "Reload";
	stateEmitterTime[3]				= 0.03;
	stateEmitterNode[3]				= "muzzleNode";
	
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 1.2;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.4;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadStart";
	
	stateName[10] 				= "Smoke";
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Halt";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
	
	stateName[12]				= "Reloaded";
	stateTimeoutValue[12]			= 0.1;
	stateScript[12]				= "onReloaded";
	stateTransitionOnTimeout[12]		= "Activate";

	stateName[13]			= "Halt";
	stateTransitionOnTimeout[13]     = "Ready";
	stateTimeoutValue[13]            = 0.9;
	stateEmitterTime[13]				= 0.48;
	stateEmitterNode[13]				= "muzzleNode";
	stateScript[13]                  = "onHalt";

	stateName[14]                     = "ReloadStart";
	stateTransitionOnTimeout[14]  = "ReloadStartB";
	stateTimeoutValue[14]            = 0.1;
	stateAllowImageChange[14]         = false;

	stateName[15]                     = "ReloadStartB";
	stateTransitionOnTimeout[15]  = "LoadCheckA";
	stateAllowImageChange[15]         = true;
};

function GrenaderImage::onFire(%this,%obj,%slot)
{
	Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
	}
	%obj.toolAmmo[%obj.currTool]--;

	%obj.playThread(2, plant);
}

function GrenaderImage::onReloadStart(%this,%obj,%slot)
{
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
	
	%obj.playThread(2, shiftdown);
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
	}
}

function GrenaderImage::onHalt(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
	}
}

function GrenaderImage::onActivate(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
	}
}

function GrenaderImage::onReady(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
	}
}

function GrenaderImage::onReloadWait(%this,%obj,%slot)
{
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
		%obj.playThread(2,plant);
            		serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
	}
}

function GrenaderImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
		%obj.client.quantity["bombrounds"]--;
	}
		%obj.toolAmmo[%obj.currTool]++;
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
}