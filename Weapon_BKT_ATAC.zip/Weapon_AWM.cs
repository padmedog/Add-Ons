datablock AudioProfile(AIAWMFireSound)
{
   filename    = "./AIAWMFire.wav";
   description = LongRange3d;
   preload = true;
};
datablock ProjectileData(AIAWMProjectile)
{
	directDamage		= 85;
	gravityMod			= 1;
	muzzleVelocity		= 1;//it's really 650 I swear
	brickExplosionForce	= 10;
	impactImpulse		= 400;
	verticalImpulse		= 325;
	lifetime			= 10000;
	fadeDelay			= 8000;
//	particleEmitter		= "ShortVaporTrailEmitter";

	radiusDamage		= 0;
	damageRadius		= 0;
	projectileShapeName	= "base/data/shapes/empty.dts";
//	projectileShapeName	= "add-ons/weapon_gun/bullet.dts";
	directDamageType	= $DamageType::UniversalHeadshot;
	radiusDamageType	= $DamageType::UniversalHeadshot;
	brickExplosionRadius			= 0;
	brickExplosionImpact			= true;
	brickExplosionMaxVolume			= 3;
	brickExplosionMaxVolumeFloating	= 10;
	explosion			= GBImpact2Explosion;
	sound				= BulletWhizzingSound;
	velInheritFactor	= 0;
	armingDelay			= 10;
	bounceElasticity	= 0.5;
	bounceFriction		= 0.1;
	isBallistic			= true;
	hasLight			= false;
	lightRadius			= 3.0;
	lightColor			= "0 0 0";
};
function AIAWMProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	%damageType = $DamageType::Direct;
	if(%this.DirectDamageType)
	{
		%damageType = %this.DirectDamageType;
	}
	%scale = getWord(%obj.getScale(), 2);
	%directDamage = 85*5;
	%damage = %directDamage;
	%sobj = %obj.sourceObject;
	if(%col.getType() & $TypeMasks::PlayerObjectType)
	{
		%directDamage = 85;
		%colscale = getWord(%col.getScale(),2);
		if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale && $BKT::HS)
		{
			%directDamage = 1000;
			%damageType = $DamageType::UniversalHeadshot;
		}
		%col.damage(%obj, %pos, %directDamage, %damageType);
	}
	else
	{
		%col.damage(%obj,%pos,%directDamage,%damageType);
	}
}
package AIAWMpsm
{
	function Projectile::onAdd(%obj,%a,%b)
	{
		if(%obj.dataBlock.getID() == AIAWMProjectile.getID())
		{
			%obj.initialvelocity=vectorscale(vectorNormalize(%obj.initialvelocity),650);//<--see 650
		}
		Parent::onAdd(%obj,%a,%b);
	}
};
activatePackage(AIAWMpsm);
datablock ItemData(AIAWMItem)
{
	shapeFile	= "./AIAWM.dts";
	iconName	= "./icon_AIAWM";
	image		= AIAWMImage;
	uiName			= "Bolt Sniper";
	maxAmmo			= 5;

	category		= "Weapon";
	className		= "Weapon";
	rotate			= false;
	mass			= 1;
	density			= 1.5;
	elasticity		= 0.2;
	friction		= 0.75;
	emap			= true;
	doColorShift	= true;
	colorShiftColor	= "0.57 0.58 0.57 1.000";
	canDrop			= true;
	canReload		= 1;
};
datablock ShapeBaseImageData(AIAWMImage)
{
	shapeFile	= "./AIAWM.dts";
	item		= AIAWMItem;
	projectile	= AIAWMProjectile;
	shellVelocity	= 6.0;
	shellExitDir	= "1.0 -0.0 0.5";
	minShotTime		= 1100;
	eyeOffset		= "0 0 0";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= AIAWMItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.5;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.1;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.1;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.1;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= AIAWMFireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateSequence[3]			= "reload1";
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "BoltOut";
	stateTimeoutValue[3]		= 0.15;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.1;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateAllowImageChange[6]	= true;
	stateTimeoutValue[6]		= 1.5;
	stateScript[6]				= "OnReload";
	stateTransitionOnTimeout[6]	= "Reloaded";
	stateWaitForTimeout[6]		= true;
	
	stateName[7]				= "Reloaded";
	stateAllowImageChange[7]	= false;
	stateTimeoutValue[7]		= 0.5;
	stateScript[7]				= "onReloaded";
	stateTransitionOnTimeout[7]	= "FireLoadCheckA";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.5;
	stateTransitionOnTimeout[9]	= "Reload";

	stateName[10] 				= "FireLoadCheckA";
	stateScript[10]				= "onLoadCheck";
	stateAllowImageChange[10]	= false;
	stateTimeoutValue[10]		= 0.1;
	stateTransitionOnTimeout[10]	= "FireLoadCheckB";

	stateName[11]				= "FireLoadCheckB";
	stateAllowImageChange[11]	= false;
	stateTransitionOnAmmo[11]	= "BoltIn";
	stateTransitionOnNoAmmo[11]	= "ReloadWait";

	stateName[12]					= "TriggerCheck";
	stateTransitionOnTriggerUp[12]	= "FireLoadCheckA";

	stateName[13]					= "BoltIn";
	stateSequence[13]				= "reload2";
	stateTransitionOnTimeout[13]	= "Ready";
	stateTimeoutValue[13]			= 0.15;
	stateSound[13]					= BoltInSound;

	stateName[14]					= "BoltOut";
	stateAllowImageChange[14]		= false;
	stateTimeoutValue[14]			= 0.4;
	stateTransitionOnTimeout[14]	= "TriggerCheck";
	stateScript[14]					= "Bolt";
	stateSound[14]					= BoltOutSound;
};
function AIAWMImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
}
function AIAWMADSImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::CH)
	{
		crossHair.setBitmap("add-ons/weapon_blockombat/empty.png");
	}
}
function AIAWMImage::onFire(%this,%obj,%slot)
{
	AIAWMFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function AIAWMImage::onWeaponLoop(%this,%obj,%slot)
{
	if(%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function AIAWMFire(%this,%obj,%slot,%val)
{
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%obj.client.player.getEyeVector(),"-3")));
	%projectile = AIAWMProjectile;
	if(%obj.heat >= 2)
	{
		%obj.playThread(3, plant);
	}
	if(%obj.isImageMounted(AIAWMImage))
	{
		if(vectorLen(%obj.getVelocity()) < 4)
		{
			%spread = 0.0035;
		}
		else
		{
			%spread = 0.004;
		}
	}
	else if(%obj.isImageMounted(AIAWMADSImage))
	{
		if(vectorLen(%obj.getVelocity()) < 4)
		{
			%spread = 0.0 + (%obj.heat * 0.0004);
		}
		else
		{
			%spread = 0.0003 + (%obj.heat * 0.0004);
		}
	}
	%obj.maxHeat = 6;
	if(%obj.heat < %obj.maxHeat)
		%obj.heat += 2;
	%shellcount = 1;
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	if($BKT::Flash)
	{
		%projectile = "ATACFlashProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function AIAWMImage::onReload(%this,%obj,%slot)
{
	%obj.client.quantity["45caliber"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;%obj.heat = 0;%obj.heat = 0;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
	if(%obj.client.quantity["45caliber"] >= 1)
	{
		%obj.playThread(2, shiftright);
		serverPlay3D(rifleheavymagOutSound,%obj.getPosition()); 
	}
}
function AIAWMImage::onReloaded(%this,%obj,%slot)
{
	if(%obj.client.quantity["45caliber"] >= 1)
	{
		if(%obj.client.quantity["45caliber"] > %this.item.maxAmmo)
		{
			%obj.client.quantity["45caliber"] -= %this.item.maxAmmo;
			%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
			%obj.setImageAmmo(%slot,1);
			%obj.playThread(2, plant);
			serverPlay3D(rifleheavymagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
		}
		else if(%obj.client.quantity["45caliber"] <= %this.item.maxAmmo)
		{
			%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["45caliber"];
			%obj.setImageAmmo(%slot,1);
			%obj.client.quantity["45caliber"] = 0;	
			%obj.playThread(2, plant);
			serverPlay3D(rifleheavymagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
			return;
		}
	}
}
datablock ShapeBaseImageData(AIAWMADSImage)
{
	shapeFile	= "./AIAWM.dts";
	item		= AIAWMItem;
	projectile	= AIAWMProjectile;
	shellVelocity	= 12.0;
	shellExitDir	= "1.0 -0.0 0.5";
	minShotTime		= 1100;
	eyeOffset		= "0.00425 1.1 -0.8734";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= AIAWMItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.5;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.1;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.1;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.1;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= AIAWMFireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateSequence[3]			= "reload1";
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "BoltOut";
	stateTimeoutValue[3]		= 0.15;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.1;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateScript[6]				= "OnReload";
	
	stateName[7]				= "Reloaded";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.5;
	stateTransitionOnTimeout[9]	= "Reload";

	stateName[10] 				= "FireLoadCheckA";
	stateScript[10]				= "onLoadCheck";
	stateAllowImageChange[10]	= false;
	stateTimeoutValue[10]		= 0.1;
	stateTransitionOnTimeout[10]	= "FireLoadCheckB";

	stateName[11]				= "FireLoadCheckB";
	stateAllowImageChange[11]	= false;
	stateTransitionOnAmmo[11]	= "BoltIn";
	stateTransitionOnNoAmmo[11]	= "ReloadWait";

	stateName[12]					= "TriggerCheck";
	stateTransitionOnTriggerUp[12]	= "FireLoadCheckA";

	stateName[13]					= "BoltIn";
	stateSequence[13]				= "reload2";
	stateTransitionOnTimeout[13]	= "Ready";
	stateTimeoutValue[13]			= 0.15;
	stateSound[13]					= BoltInSound;

	stateName[14]					= "BoltOut";
	stateAllowImageChange[14]		= false;
	stateTimeoutValue[14]			= 0.4;
	stateTransitionOnTimeout[14]	= "TriggerCheck";
	stateScript[14]					= "Bolt";
	stateSound[14]					= BoltOutSound;
};
function AIAWMADSImage::onWeaponLoop(%this,%obj,%slot)
{
	if (%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function AIAWMADSImage::Bolt(%this,%obj,%slot)
{
	if($BKT::Recoil)
	{
		%projectile = "scopeBoltProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
		return %p;
	}
}
function AIAWMADSImage::onFire(%this,%obj,%slot)
{
	AIAWMFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function AIAWMADSImage::onReload(%this,%obj,%slot)
{
	%obj.mountImage(AIAWMImage,0);
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>.338 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["45caliber"]+0 @ "", 4, 2, 3, 4);}
}
package AIAWMSights
{
	function armor::onTrigger(%this,%obj,%triggerNum,%val)
	{
		%client = %obj.client;		
		if(%obj.getMountedImage(0) $= AIAWMImage.getID() && %triggerNum == 4 && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(AIAWMADSImage, 0);
			%client.setControlCameraFov(40);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		else if(%triggerNum == 4 && %obj.getMountedImage(0) $= AIAWMADSImage.getID() && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(AIAWMImage, 0);
			%client.setControlCameraFov(90);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		Parent::onTrigger(%this,%obj,%triggerNum,%val);
	}
	function servercmdDropTool(%client,%slot)
	{
		if(%client.player.getMountedImage(0) $= AIAWMADSImage.getID())
		{
		 	%client.player.unmountImage(0);
			%client.setControlCameraFov(90);
			if($BKT::CH)
			{
				crossHair.setBitmap("base/client/ui/crosshair.png");
			}
		}
		return Parent::servercmdDropTool(%client,%slot);
	}
};
activatePackage(AIAWMSights);
function AIAWMADSImage::onUnMount(%this,%obj,%slot)
{
	%obj.client.setControlCameraFov(90);
	if($BKT::CH)
	{
		crossHair.setBitmap("base/client/ui/crosshair.png");
	}
}