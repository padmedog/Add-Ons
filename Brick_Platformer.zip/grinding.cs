//GLOBALS
$Platformer::Grind::JumpVel = "10 0 5"; //Velocity upon detaching.
$Platformer::Grind::ExitVel = "12.5"; //Scale of velocity upon exiting rail.
$Platformer::Grind::RailSpeed = 35; //Speed at which the rail tick repeats.
$Platformer::Grind::MaxAngleDiff = 180; //Maximum degrees a player can look away from the rail direction. Setting it to 180+ disables this feature. Does not work well with turns.
$Platformer::Grind::AddZ = 0.25; //Amount of units above the grind rail the player snaps to.
$Platformer::Grind::MaxSwitchDist = (0.5 * 5); //Maximum distance away a rail can be to switch.


//DATABLOCKS
datablock AudioProfile(RailGrindSound)
{
	description = "AudioClosestLooping3D";
	fileName = "./resources/grind.wav";
	preload = true;
};

datablock AudioProfile(RailContactSound)
{
	description = "AudioClosest3D";
	fileName = "./resources/contact.wav";
	preload = true;
};

datablock fxDTSBrickData(BrickGrindRailData : Brick1x1FData)
{
	brickFile = "./resources/1x1F Rail.blb";

	category = "Special";
	subCategory = "Platformer - Rails";
	uiName = "Grind Rail";

	canGrind = true; //Flag for grind rails
	grindDir = "1 0 0"; //Direction of the raycast search for the next rail.
	grindOffset = "0 0 0"; //Offset of start for rail search.
	grindDirInv = "1 0 0"; //Direction of rail search when player is going in the reverse direction.
	grindOffsetInv = "0 0 0"; //Offset of rail search when player is going in the reverse direction.

	grindDetach = false; //Flag to automatically detach the player upon reaching this type of rail.
	grindCanJump = true; //If the player can exit when on this rail.
	grindAddJumpVel = ""; //Additional velocity addded to the player's speed when exiting. (Use angular velocity; empty string defaults to 0 0 0)
	grindAutoJump = false; //If the player automatically exits when on this rail.
	grindJumpVel = ""; //Scale of the auto-jump. (One float; empty string defaults to $Platformer::Grind::ExitVel)
	grindReverseOffset = false; //If the player's reversal flag is toggled upon reaching this rail.
};

datablock fxDTSBrickData(BrickGrindRailDownData : BrickGrindRailData)
{
	uiName = "Grind Rail Down";

	canGrind = true;
	grindDir = "0 0 -1";
	grindOffset = "0.5 0 0";
	grindDirInv = "1 0 0";
	grindOffsetInv = "0 0 0.2";

	grindCanJump = false;
};

datablock fxDTSBrickData(BrickGrindRailUpData : BrickGrindRailData)
{
	uiName = "Grind Rail Up";

	canGrind = true;
	grindDir = "1 0 0";
	grindOffset = "0 0 0.2";
	grindDirInv = "0 0 -1";
	grindOffsetInv = "0.5 0 0";

	grindCanJump = false;
};

datablock fxDTSBrickData(BrickGrindRailLeftData : BrickGrindRailData)
{
	uiName = "Grind Rail Left";

	canGrind = true;
	grindDir = "0 1 0";
	grindOffset = "0.5 0 0";
	grindDirInv = "0 1 0";
	grindOffsetInv = "0.5 0 0";
};

datablock fxDTSBrickData(BrickGrindRailRightData : BrickGrindRailData)
{
	uiName = "Grind Rail Right";

	canGrind = true;
	grindDir = "0 -1 0";
	grindOffset = "0.5 0 0";
	grindDirInv = "0 -1 0";
	grindOffsetInv = "0.5 0 0";
};

datablock fxDTSBrickData(BrickGrindJumpData : BrickGrindRailData)
{
	uiName = "Auto-Jump Grind Rail";

	grindDir = "0 0 0";
	grindOffset = "0 0 0";
	grindDirInv = "0 0 0";
	grindOffsetInv = "0 0 0";

	grindCanJump = false;
	grindAutoJump = true;
};

datablock fxDTSBrickData(BrickGrindDetachData : BrickGrindRailData)
{
	uiName = "Detaching Grind Rail";

	grindDir = "0 0 0";
	grindOffset = "0 0 0";
	grindDirInv = "0 0 0";
	grindOffsetInv = "0 0 0";

	grindDetach = true;
	grindCanJump = false;
};

datablock fxDTSBrickData(BrickGrindSuperJumpData : BrickGrindRailData)
{
	uiName = "Superjump Grind Rail";

	grindAddJumpVel = VectorAdd($Platformer::Grind::JumpVel, "0 0 5");
};

datablock fxDTSBrickData(BrickGrindReversalData : BrickGrindRailData)
{
	uiName = "Reversal Grind Rail";

	grindDir = "-1 0 0";
	grindOffset = "0 0 0";
	grindDirInv = "-1 0 0";
	grindOffsetInv = "0 0 0";

	grindCanJump = false;
	grindReverseOffset = true;
};

datablock fxDTSBrickData(BrickGrindRailLeftTurnData : BrickGrindRailData)
{
	uiName = "Grind Rail Left Turn";

	canGrind = true;
	grindDir = "0 1 0";
	grindOffset = "0.5 0 0";
	grindDirInv = "0 -1 0";
	grindOffsetInv = "0.5 0 0";
};

datablock fxDTSBrickData(BrickGrindRailRightTurnData : BrickGrindRailData)
{
	uiName = "Grind Rail Right Turn";

	canGrind = true;
	grindDir = "0 -1 0";
	grindOffset = "0.5 0 0";
	grindDirInv = "0 1 0";
	grindOffsetInv = "0.5 0 0";
};

datablock ParticleData(GrindSparkParticle)
{
	textureName          	= "base/data/particles/star1";
	dragCoefficient      	= 1;
	gravityCoefficient   	= 1.5;
	inheritedVelFactor   	= 0.2;
	constantAcceleration 	= 0.0;
	lifetimeMS           	= 1500;
	lifetimeVarianceMS   	= 150;
	spinSpeed				= 10.0;
	spinRandomMin			= -500.0;
	spinRandomMax			= 500.0;
	colors[0]     			= "0.9 0.4 0.0 0.9";
	colors[1]     			= "0.9 0.5 0.0 0.0";
	sizes[0]      			= 0.2;
	sizes[1]      			= 0.0;

	useInvAlpha 			= false;
};

datablock ParticleEmitterData(GrindSparkEmitter)
{
	particles				= "GrindSparkParticle";
	lifetimeMS				= 0;
	ejectionPeriodMS		= 20;
	periodVarianceMS		= 0;
	ejectionVelocity		= 5;
	thetaMin 				= 15;
	thetaMax 				= 90;
	phiReferenceVel 		= 0;
	phiVariance 			= 360;
	overrideAdvance 		= false;
	useEmitterColors 		= false;
	orientParticles 		= false;

	uiName = "Grind Spark";
};


//DEPENDENCY FUNCTIONS
function angleIDOpposite(%ang1, %ang2) //Returns if the two given angle IDs are opposite directions.
{
	%angC = %ang2 + 2;
	if(%angC > 3)
		%angC -= 4;
	if(%ang1 == %angC)
		return true;
	else
	{
		%angC = %ang2 - 2;
		if(%angC < 0)
			%angC += 4;
		if(%ang1 == %angC)
			return true;
	}
	return false;
}

function compareWords(%str1, %str2) //Returns a string whose words are booleans indicating if the words of both strings at that index are the same. (case-insensitive)
{
	%ct1 = getWordCount(%str1);
	%ct2 = getWordCount(%str2);
	%ct = (%ct1 < %ct2 ? %ct1 : %ct2);
	for(%i = 0; %i < %ct; %i++)
	{
		%w1 = getWord(%str1, %i);
		%w2 = getWord(%str2, %i);
		%str = %str @ (%w1 $= %w2) @ " ";
	}
	return trim(%str);
}

function vectorFloatLength(%vec, %len) //Does mFloatLength on each axis of a vector.
{
	for(%i = 0; %i < 3; %i++)
	{
		%w = getWord(%vec, %i);
		%vec = setWord(%vec, %i, mFloatLength(%w, %len));
	}
	return %vec;
}

function vectorFloor(%vec) //Does mFloor on each axis of a vector.
{
	for(%i = 0; %i < 3; %i++)
	{
		%w = getWord(%vec, %i);
		%vec = setWord(%vec, %i, mFloor(%w));
	}
	return %vec;
}

function GrindFixVector(%vec) //Modifies vectors so that each axis is either 1 or 0.
{
	for(%i = 0; %i < 3; %i++)
	{
		%w = getWord(%vec, %i);
		switch(%i)
		{
			case 0: %vec1 = VectorNormalize(%w SPC "0 0");
			case 1: %vec2 = VectorNormalize("0" SPC %w SPC "0");
			case 3: %vec3 = VectorNormalize("0 0" SPC %w);
		}
	}
	%vec = VectorAdd(%vec3, VectorAdd(%vec1, %vec2));
	return %vec;
}

function findFirstOddWord(%str) //Finds the first word in a string that is unlike the preceding ones.
{
	%ct = getWordCount(%str);
	if(%ct < 2)
		return 0;
	%lastWord = getWord(%str, 0);
	for(%i = 1; %i < %ct; %i++)
	{
		%w = getWord(%str, %i);
		if(%w !$= %lastWord)
			return %i;
		%lastWord = %w;
	}
	return 0;
}

function angleToRot(%id) //Converts angleID to rotation.
{
	switch(%id)
	{
		case 0: %rotation = "1 0 0 0";
		case 1: %rotation = "0 0 1 90";
		case 2: %rotation = "0 0 1 180";
		case 3: %rotation = "0 0 -1 90";
		default: %rotation = "1 0 0 0";
	}
	return %rotation;
}

function mRound(%float) //Rounds floats.
{
	return mFloor(%float + 0.5);
}

function eulerToAxis(%euler)
{
	%euler = VectorScale(%euler,$pi / 180);
	%matrix = MatrixCreateFromEuler(%euler);
	return getWords(%matrix,3,6);
}

function axisToEuler(%axis)
{
	%angleOver2 = getWord(%axis,3) * 0.5;
	%angleOver2 = -%angleOver2;
	%sinThetaOver2 = mSin(%angleOver2);
	%cosThetaOver2 = mCos(%angleOver2);
	%q0 = %cosThetaOver2;
	%q1 = getWord(%axis,0) * %sinThetaOver2;
	%q2 = getWord(%axis,1) * %sinThetaOver2;
	%q3 = getWord(%axis,2) * %sinThetaOver2;
	%q0q0 = %q0 * %q0;
	%q1q2 = %q1 * %q2;
	%q0q3 = %q0 * %q3;
	%q1q3 = %q1 * %q3;
	%q0q2 = %q0 * %q2;
	%q2q2 = %q2 * %q2;
	%q2q3 = %q2 * %q3;
	%q0q1 = %q0 * %q1;
	%q3q3 = %q3 * %q3;
	%m13 = 2.0 * (%q1q3 - %q0q2);
	%m21 = 2.0 * (%q1q2 - %q0q3);
	%m22 = 2.0 * %q0q0 - 1.0 + 2.0 * %q2q2;
	%m23 = 2.0 * (%q2q3 + %q0q1);
	%m33 = 2.0 * %q0q0 - 1.0 + 2.0 * %q3q3;
	return mRadToDeg(mAsin(%m23)) SPC mRadToDeg(mAtan(-%m13, %m33)) SPC mRadToDeg(mAtan(-%m21, %m22));
}

function rotateVector(%vector, %axis, %val) //Rotates a vector around the axis by an angleID.
{
	if(%val < 0)
		%val += 4;
	if(%val > 3)
		%val -= 4;
	switch(%val)
	{
		case 1:
			%nX = getWord(%axis, 0) + (getWord(%vector, 1) - getWord(%axis, 1));
			%nY = getWord(%axis, 1) - (getWord(%vector, 0) - getWord(%axis, 0));
			%new = %nX SPC %nY SPC getWord(%vector, 2);
		case 2:
			%nX = getWord(%axis, 0) - (getWord(%vector, 0) - getWord(%axis, 0));
			%nY = getWord(%axis, 1) - (getWord(%vector, 1) - getWord(%axis, 1));
			%new = %nX SPC %nY SPC getWord(%vector, 2);
		case 3:
			%nX = getWord(%axis, 0) - (getWord(%vector, 1) - getWord(%axis, 1));
			%nY = getWord(%axis, 1) + (getWord(%vector, 0) - getWord(%axis, 0));
			%new = %nx SPC %nY SPC getWord(%vector, 2);
		default: %new = vectorAdd(%vector, %axis);
	}
	return %new;
}

function GrindDirCompare(%bDir, %pVel) //Figures out if directions of a brick and a player's velocity are opposite, the same, or unmatching. Expects GrindFixVector to be used on player velocity.
{
	if(getWord(%bDir, 0) == 0)
	{
		%yB = getWord(%bDir, 1);
		%yP = getWord(%pVel, 1);
		if(%yB == 0)
			return -1;
		else if(%yP == 0)
			return -1;
		else if(%yB == %yP)
			return 1;
		else if(%yB == %yP * -1)
			return 0;
	}
	else
	{
		%xB = getWord(%bDir, 0);
		%xP = getWord(%pVel, 0);
		if(%xB == 0)
			return -1;
		else if(%xP == 0)
			return -1;
		else if(%xB == %xP)
			return 1;
		else if(%xB == %xP * -1)
			return 0;
	}
	return -1;
}

function GrindAngtoID(%ang) //Converts 0-360° angles to angleIDs.
{
	%id = mRound(%ang / 90); //Round to the nearest ninety degrees.
	switch(%id)
	{
		case 1: return 0; //90
		case 2: return 3; //180
		case 3: return 2; //270
		default: return 1; //360 or 0
	}
}

function AngleCompare(%a1, %a2) //Gets the difference between two angles.
{
	%diff = mAbs(%a1 - %a2);
	%r1 = mAbs(%diff - 180);
	%r2 = 180 - %r1;
	return %r2;
}

function RelayCheck(%start, %angle, %len, %xyz) //Essentially allows for more dynamic relay-like events with bricks.
{
	if(%angle < 0)
		%angle += 4;
	if(%angle > 3)
		%angle -= 4;

	if(%len $= "")
		%len = 0.5; //one stud
	if(getWordCount(%xyz) == 3)
		%vect = VectorScale(%xyz, %len);
	else
		%vect = %len SPC "0 0";

	%end = rotateVector(%vect, "0 0 0", %angle);
	%end = VectorAdd(%end, %start);
	// echo(%end);
	%cast = containerRaycast(%start, %end, $TypeMasks::FxBrickObjectType);
	// echo(%cast);
	%obj = firstWord(%cast);
	if(isObject(%obj) && %obj.getClassName() $= "fxDTSBrick")
		return %obj;
	return -1;
}


//CLASS FUNCTIONS
function fxDTSBrick::getGrindNext(%obj, %player) //Returns the next rail that the given player would be grinding on.
{
	if(%obj.getDatablock().grindReverseOffset)
		%player.grindOffset = !%player.grindOffset;

	if(%obj.getDatablock().grindDetach)
		return 0;

	%ang = %obj.getGrindAngle(%player);
	%goff = (%player.grindOffset ? %obj.getDatablock().grindOffsetInv : %obj.getDatablock().grindOffset);
	//echo(%goff);
	%off = rotateVector(%goff, "0 0 0", %ang);
	//echo(%off);
	%start = VectorAdd(%obj.getPosition(), %off);
	%next = RelayCheck(%start, %ang, 0.5, (%player.grindOffset ? %obj.getDatablock().grindDirInv : %obj.getDatablock().grindDir));
	if(!isObject(%next))
		%next = RelayCheck(%obj.getPosition(), %ang, 0.5, "1 0 0");
	else if(isObject(%next) && !%next.getDatablock().canGrind)
		%next = RelayCheck(%obj.getPosition(), %ang, 0.5, "1 0 0");
	if(!isObject(%next))
		return 0;
	if(!%next.getDatablock().canGrind)
		return 0;
	return %next;
}

function fxDTSBrick::getGrindAngle(%this, %player) //This is used to determine the rotation of rail searches by including the player's reversal flag.
{
	%angle = %this.getAngleID();

	if(%player.grindOffset)
		%angle += 2;

	if(%angle < 0)
		%angle += 4;
	if(%angle > 3)
		%angle -= 4;

	return %angle;
}

function fxDTSBrick::Grind(%obj, %player, %isNew) //The function that handles grinding.
{
	if(!isObject(%player))
		return;
	if(isEventPending(%player.grindSchedule))
		cancel(%player.grindSchedule);
	if(isObject(%player.grindEmitter)) //Since emitter nodes don't seem to be movable, we have to re-create them every tick. I'm at least 60% sure this is bad, but we gotta go fast.
		%player.grindEmitter.delete();

	if(%isNew) //Does stuff for effect if the player's just starting to grind. I guarantee that if you remove this, you remove at least three-fourths of the fun.
	{
		ServerPlay3D(RailContactSound, %obj.getPosition());
		%player.playAudio(3, RailGrindSound);
	}

	if(!isObject(%player.lastGrind)) //This bit determines if the player should have their reverse flag set.
	{								 //It works by comparing the player's velocity to the brick's direction.
		%dir = rotateVector("1 0 0", "0 0 0", %obj.getAngleID());
		%vel = GrindFixVector(vectorFloor(%player.getVelocity()));
		%comp = GrindDirCompare(%dir, %vel);
		//echo(%comp TAB %dir TAB %vel);
		if(%comp == 0)
			%player.grindOffset = true;
	}

	if(%obj.getDatablock().grindAutoJump) //Handles the auto-jump flag.
	{
		%vel = %obj.getDatablock().grindJumpVel;
		if(%vel $= "")
			%vel = $Platformer::Grind::ExitVel;
		%vel = VectorAdd(VectorScale(%player.getForwardVector(), %vel), "0 0" SPC %vel);
		%player.setVelocity(%vel);
		%player.stopAudio(3);
		%player.lastGoodAngle = "";
		%player.lastGrind = "";
		%player.grindOffset = false;
		%player.isGrinding = false;
		return;
	}

	%nextRail = %obj.getGrindNext(%player);
	%player.nextRail = "";

	// if(!isObject(%nextRail) && !%player.grindOffset && !isObject(%player.lastGrind))
	// {
	// 	%player.grindOffset = true;
	// 	%nextRail = %obj.getGrindNext(%player);
	// 	if(!isObject(%nextRail))
	// 		%player.grindOffset = false;
	// }

	if(!isObject(%nextRail) || !%nextRail.getDatablock().canGrind) //Detaches if no next rail is found.
	{
		%player.setVelocity(rotateVector($Platformer::Grind::JumpVel, "0 0 0", %obj.getGrindAngle(%player)));
		%player.stopAudio(3);
		%player.lastGoodAngle = "";
		%player.lastGrind = "";
		%player.grindOffset = false;
		%player.isGrinding = false;

		return;
	}

	%player.setVelocity("0 0 0");
	%player.position = VectorAdd(%obj.getPosition(), "0 0" SPC $Platformer::Grind::AddZ);


	if($Platformer::Grind::MaxAngleDiff < 180) //This bit handles the camera restriction, which doesn't work too well, so it's off by default.
	{
		%playerAngle = %player.Grind_getAngle();
		%brickAngle = %obj.Grind_getAngle(%player);
		%diff = AngleCompare(%playerAngle, %brickAngle);
		if(%diff > $Platformer::Grind::MaxAngleDiff)
		{
			if(%player.lastGoodAngle !$= "")
				%euler = "0 0" SPC %player.lastGoodAngle;
			else
			{
				// %rot = getWords(%obj.getTransform(), 3, 6);
				%rot = angleToRot(%obj.getGrindAngle(%player));
				%z = getWord(axisToEuler(%rot), 2);
				%player.lastGoodAngle = %z;
				%euler = "0 0" SPC %z;
			}
			%rotation = eulerToAxis(%euler);
			%player.setTransform(%player.getPosition() SPC %rotation);
		}
		else
		{
			%rot = getWords(%player.getTransform(), 3, 6);
			%euler = axisToEuler(%rot);
			%z = getWord(%euler, 2);
			%player.lastGoodAngle = %z;
		}
	}

	%player.isGrinding = true;
	%player.lastGrind = %obj;
	%player.lastGrindTime = getSimTime();
	%player.nextRail = %nextRail;
	%player.addGrindEmitter(angleToRot(%obj.getGrindAngle(%player)));
	//echo(%obj.getGrindAngle(%player) SPC angleToRot(%obj.getGrindAngle(%player)));
	// %player.grindEmitter.rotation = angleToRot(%obj.getGrindAngle(%player));
	%obj.onGrind(%player);
	%player.grindSchedule = %nextRail.schedule($Platformer::Grind::RailSpeed, Grind, %player);
}

function fxDTSBrick::Grind_getAngle(%this, %player) //Gets the 0-360° angle of a brick.
{
	if(!isObject(%player))
		%rot = getWords(%this.getTransform(), 3, 6);
	else
		%rot = angleToRot(%this.getGrindAngle(%player));
	%euler = axisToEuler(%rot);
	%z = mAbs(90 - (getWord(%euler, 2) + 180));
	return mFloatLength(%z, 0);
}

function Player::Grind_getAngle(%this) //Gets the 0-360° angle of a player.
{
	%rot = getWords(%this.getTransform(), 3, 6);
	%euler = axisToEuler(%rot);
	%z = mAbs(getWord(%euler, 2) + 180);
	return mFloatLength(%z, 0);
}

function Player::SetGrindAng(%this, %angle) //Sets a player's rotation to a 0-360° angle.
{
	%euler = "0 0" SPC %angle - 180;
	%rot = eulerToAxis(%euler);
	%pos = getWords(%this.getTransform(), 0, 2);
	%this.setTransform(%pos SPC %rot);
	return %rot;
}

function Player::addGrindEmitter(%this, %rot) //Adds a player's grind spark emitter.
{
	if(isObject(%this.grindEmitter))
		%this.grindEmitter.delete();
	%this.grindEmitter = new ParticleEmitterNode()
	{
		datablock = GenericEmitterNode;
		emitter = GrindSparkEmitter;
		pointPlacement = 0;
		position = %this.getPosition();
		rotation = %rot;
		scale = "0.05 0.05 0.05";
		spherePlacement = 0;
		velocity = 1;
		player = %this;
	};
	//echo(%this.grindEmitter.rotation);
	%this.grindEmitter.schedule($Platformer::Grind::RailSpeed + 1, delete);
	return %this.grindEmitter;
}

function fxDTSBrick::onGrind(%this, %player) //input event
{
	$InputTarget_["Self"] = %this;
	$InputTarget_["Player"] = %player;
	$InputTarget_["Client"] = %player.client;

	%clientMini = getMinigameFromObject(%player.client);
	%selfMini = getMinigameFromObject(%this);
	if($Server::Lan)
		$InputTarget_["MiniGame"] = %clientMini;
	else
	{
		if(%clientMini == %selfMini)
			$InputTarget["MiniGame"] = %selfMini;
		else
			$InputTarget["MiniGame"] = 0;
	}
	%this.processInputEvent("onGrind", %player.client);
}


//PACKAGE
package Platformer_Grinding
{
	function Armor::onTrigger(%this, %obj, %slot, %val)
	{
		parent::onTrigger(%this, %obj, %slot, %val);

		if(!%obj.isGrinding || !isObject(%obj.lastGrind))
			return;
		if(%slot $= 2 && %val && %obj.lastGrind.getDatablock().grindCanJump)
		{
			if(isEventPending(%obj.grindSchedule))
				cancel(%obj.grindSchedule);
			%vel = VectorAdd(vectorScale(%obj.getForwardVector(), $Platformer::Grind::ExitVel), "0 0" SPC $Platformer::Grind::ExitVel);
			%addvel = %obj.lastGrind.getDatablock().grindAddJumpVel;
			if(%addVel $= "")
				%addVel = "0 0 0";
			%addvel = rotateVector(%addVel, "0 0 0", %obj.lastGrind.getGrindAngle(%player));
			%obj.setVelocity(VectorAdd(%vel, %addVel));
			%obj.stopAudio(3);
			%obj.lastGoodAngle = "";
			%obj.lastGrind = "";
			%obj.isGrinding = false;
			%obj.grindOffset = false;
			%obj.grindEmitter.delete();
			%obj.grindEmitter = 0;
		}

		if(%slot $= 0 && %val)
		{
			%angleID = %obj.lastGrind.getGrindAngle(%obj) - 1;
			%rail = RelayCheck(%obj.lastGrind.getPosition(), %angleID, $Platformer::Grind::MaxSwitchDist);
			//echo(%rail);
			if(!isObject(%rail))
				return;
			if(!%rail.getDatablock().canGrind)
				return;
			%obj.nextRail = %rail;
			if(isEventPending(%obj.grindSchedule))
			{
				%time = getTimeRemaining(%obj.grindSchedule);
				cancel(%obj.grindSchedule);
			}
			else
				%time = $Platformer::Grind::RailSpeed;

			if(angleIDOpposite(%rail.getAngleID(), %obj.lastGrind.getAngleID()))
				%obj.grindOffset = !%obj.grindOffset;
			
			%obj.grindSchedule = %rail.schedule(%time, Grind, %obj, true);
		}

		if(%slot $= 4 && %val)
		{
			%angleID = %obj.lastGrind.getGrindAngle(%obj) + 1;
			%rail = RelayCheck(%obj.lastGrind.getPosition(), %angleID, $Platformer::Grind::MaxSwitchDist);
			//echo(%rail);
			if(!isObject(%rail))
				return;
			if(!%rail.getDatablock().canGrind)
				return;
			%obj.nextRail = %rail;
			if(isEventPending(%obj.grindSchedule))
			{
				%time = getTimeRemaining(%obj.grindSchedule);
				cancel(%obj.grindSchedule);
			}
			else
				%time = $Platformer::Grind::RailSpeed;

			if(angleIDOpposite(%rail.getAngleID(), %obj.lastGrind.getAngleID()))
				%obj.grindOffset = !%obj.grindOffset;

			%obj.grindSchedule = %rail.schedule(%time, Grind, %obj, true);
		}
	}

	function GameConnection::onDeath(%this, %obj, %killer, %damageType, %damageLoc)
	{
		if(isObject(%this.player.grindEmitter))
		{
			if(isEventPending(%this.player.grindSchedule))
				cancel(%this.player.grindSchedule);
			%this.player.grindEmitter.delete();
		}
		parent::onDeath(%this, %obj, %killer, %damageType, %damageLoc);
	}

	function fxDTSBrickData::onPlant(%this, %obj)
	{
		parent::onPlant(%this, %obj);

		if(%this.canGrind)
			%obj.enableTouch = true;
	}

	function fxDTSBrickData::onLoadPlant(%this, %obj)
	{
		parent::onLoadPlant(%this, %obj);

		if(%this.canGrind)
			%obj.enableTouch = true;
	}

	function fxDTSBrickData::onPlayerTouch(%this, %obj, %player)
	{
		parent::onPlayerTouch(%this, %obj, %player);

		if(!%this.canGrind)
			return;

		%last = %player.lastGrind;
		if(isObject(%last))
		{
			if(%obj == %last || %last.getGrindNext(%obj) == %obj)
				return;
		}
		if(getSimTime() - %player.lastGrindTime < $Platformer::Grind::RailSpeed)
			return;

		%obj.Grind(%player, true);
	}
};
activatePackage(Platformer_Grinding);

//EVENT REGISTRATION
registerInputEvent(fxDTSBrick, "onGrind", "Self fxDTSBrick\tPlayer Player\tClient GameConnection\tMiniGame MiniGame");