AddDamageType("ClassicLMG",   '<bitmap:add-ons/Weapon_Skins_LMG/CI_drumLMG> %1',    '%2 <bitmap:add-ons/Weapon_Skins_LMG/CI_drumLMG> %1',0.75,1);
datablock ProjectileData(ClassicLMGProjectile1 : lightMachineGunProjectile1)
{
   directDamage        = 10;
   directDamageType    = $DamageType::ClassicLMG;
};

datablock ItemData(ClassicLMGItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./drum_lmg.1.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Drum LMG";
	iconName = "./drumlmg";
	doColorShift = true;
	colorShiftColor = "0.5 0.5 0.45 1.000";

	 // Dynamic properties defined by the scripts
	image = ClassicLMGImage;
	canDrop = true;
	
	maxAmmo = 70;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ClassicLMGImage : lightMachineGunImage)
{
	shapeFile = "./drum_lmg.1.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
   correctMuzzleVector = true;
   className = "WeaponImage";
   item = ClassicLMGItem;
   ammo = " ";
   projectile = ClassicLMGProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ClassicLMGItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
};

function ClassicLMGImage::onFire(%this,%obj,%slot)
{ 
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	
	%obj.lastShotTime = getSimTime();
	%shellcount = 1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 1000)
	{
		%spread = 0.0002;
	}
	else
	{
		%spread = 0.0015;
	}

	%projectile = ClassicLMGProjectile1;
	
	%obj.playThread(2, plant);
	%shellcount = 1;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function ClassicLMGImage::onFire2(%this,%obj,%slot)
{ 
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	
	%obj.lastShotTime = getSimTime();
	%shellcount = 1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 1000)
	{
		%spread = 0.0002;
	}
	else
	{
		%spread = 0.0004;
	}

	%projectile = LightMachinegunProjectile1;
	
	%obj.playThread(2, plant);
	%shellcount = 1;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}



function ClassicLMGImage::onReloadStart(%this,%obj,%slot)
{           		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, shiftRight);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
	%obj.popDatablock(LMGArmor.getID());
}

function ClassicLMGImage::onReloadWait(%this,%obj,%slot)
{commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, plant);
            serverPlay3D(magazineOutSound,%obj.getPosition());
	}
}

function ClassicLMGImage::onClick(%this,%obj,%slot)
{
	%obj.pushDatablock(LMGArmor.getID());
}

function ClassicLMGImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.client.quantity["556rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["556rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["556rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["556rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["556rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["556rounds"] = 0;

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

function ClassicLMGImage::onHalt(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
   %obj.popDatablock(LMGArmor.getID());
}

function ClassicLMGImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
}

function ClassicLMGImage::onUnMount(%this,%obj,%slot)
{
   Parent::onUnMount(%this,%obj,%slot);
   
   %obj.popDatablock(LMGArmor.getID());
}

function ClassicLMGProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.setVelocity(getWord(%col.getVelocity(),0)/1.2 SPC getWord(%col.getVelocity(),1)/1.2 SPC getWord(%col.getVelocity(),1.2));
   }
parent::damage(%this,%obj,%col,%fade,%pos,%normal);
}