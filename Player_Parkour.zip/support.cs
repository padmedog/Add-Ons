//~~Support stuff~~\\

function player::wallCheck( %this, %start, %beam, %stop )
{
	%ray = containerRayCast(
		%start, %stop,
		$TypeMasks::FxBrickObjectType, %this
	);
	 
	if ( isObject( firstWord( %ray ) ) )
	{
		%pos = getWords( %ray, 1, 3 );
	}
	else
	{
		%pos = %stop;
	}

	initContainerRadiusSearch(
		%pos, 0.75,
		$TypeMasks::FxBrickObjectType
	);
	 
	while ( isObject( %col = containerSearchNext() ) )
	{
		%dist = vectorDist( %pos, %col.getWorldBoxCenter() );
	 
		if ( !strLen( %best ) || %dist < %best )
		{
			%best = %dist;
			%targ = %col;
		}
	}

	//%this.debugLine( %start, %end, %ray );

	%targ.endPos = %pos;
	if( isObject( %targ ) )
	{
		return %targ;
	}
	return false;
}

function player::brickAboveCheck( %this, %col, %endpos )
{
	if( !isObject( %this ) || %this.getState() $= "Dead" )
	{
		return;
	}

	%fail = false;

	%pos1 = GetWords( %col.getWorldBox(), 0, 2 );
	%pos2 = GetWords( %col.getWorldBox(), 3, 5 );

	%xpos1 = GetWord( %pos1, 0 );
	%ypos1 = GetWord( %pos1, 1 );
	%zpos1 = GetWord( %pos1, 2 );

	%xpos2 = GetWord( %pos2, 0 );
	%ypos2 = GetWord( %pos2, 1 );
	%zpos2 = GetWord( %pos2, 2 );

	%x = getWord( %endpos, 0 );
	%y = getWord( %endpos, 1 );
	%z = getWord( %endpos, 2 );

	%plzpos = getWord( %this.getHackPosition(), 2 );
	
	if( %zpos2 > %plzpos + 0.5 )
	{
		%fail = true;
	}

	if( %zpos2 < %plzpos - 0.9 )
	{
		%fail = true;
	}

	if( %x < %xpos1 + 0.05 )
	{
		%x = %xpos1 + 0.05;
	}
	if( %x > %xpos2 - 0.05 )
	{
		%x = %xpos2 - 0.05;
	}

	if( %y < %ypos1 + 0.05 )
	{
		%y = %ypos1 + 0.05;
	}
	if( %y > %ypos2 - 0.05 )
	{
		%y = %ypos2 - 0.05;
	}

	%raypos = %x SPC %y SPC %zpos2;

	%start = getWords( %raypos, 0, 1 ) SPC %zpos2 - 0.05;
	%stop = getWords( %start, 0, 1 ) SPC %zpos2 + 0.5;

	%ray = containerRayCast( %start, %stop, $TypeMasks::FxBrickObjectType, %wallcheck2 );

	if( $PlayerParkour::Debug )
	{
		if( %this.lastACheckLine > 0.5 )
		{
			%this.lastACheckLine = $Sim::Time;
			%this.ACheckLine = createLine( %start, %stop, 0.05, ( isObject( %ray ) ? "0" : "1" ) SPC ( isObject( %ray ) ? "1" : "0" ) SPC "0 1" );

			if( isObject( %this.ACheckLine ) )
			{
				%this.ACheckLine.schedule( 500, "removeLine" );
			}
		}
	}

	if( %fail )
	{
		return "fail";
	}
	if( isObject( %ray ) )
	{
		return %ray;
	}
	return false;
}

function player::isOnGround( %this )
{
	%offset[ 0 ] = "0 0";
	%offset[ 1 ] = "0.5 0";
	%offset[ 2 ] = "-0.5 0";
	%offset[ 3 ] = "0 0.5";
	%offset[ 4 ] = "0 -0.5";

	for ( %i = 0 ; %i < 5 ; %i++ )
	{
		if ( %this._isOnGround( %offset[ %i ] ) )
		{
			return true;
		}
	}
	return false;
}

function player::_isOnGround( %this, %offset )
{
	%start = vectorAdd( %this.position, %offset SPC "0.4" );
	%stop = vectorSub( %this.position, %offset SPC "0.4" );
	%raycast = containerRayCast( %start, %stop, $TypeMasks::FxBrickObjectType | $TypeMasks::TerrainObjectType, %this );

	//if( $PlayerParkour::Debug )
	//{
	//	%this.debugLine = createLine( %start, %stop, 0.05, ( isObject( %raycast ) ? "0" : "1" ) SPC ( isObject( %raycast ) ? "1" : "0" ) SPC "0 1" );
//
	//	if( isObject( %this.debugLine ) )
	//	{
	//		%this.debugLine.schedule( 100, "removeLine" );
	//	}
	//}

	return isObject( firstWord( %raycast ) );
}

function createLine( %a, %b, %size, %color )
{
	if ( !strLen( %size ) )
	{
		%size = 0.05;
	}

	if ( !strLen( %color ) )
	{
		%color = "1 1 1 1";
	}

	%offset = vectorSub( %a, %b );
	%normal = vectorNormalize( %offset );

	%xyz = vectorNormalize( vectorCross( "1 0 0", %normal ) );
	%pow = mRadToDeg( mACos( vectorDot( "1 0 0", %normal ) ) ) * -1;

	%obj = new staticShape()
	{
		a = %a;
		b = %b;

		datablock = cubeShapeData;
		scale = vectorLen( %offset ) SPC %size SPC %size;

		position = vectorScale( vectorAdd( %a, %b ), 0.5 );
		rotation = %xyz SPC %pow;
	};

	missionCleanup.add( %obj );
	%obj.setNodeColor( "ALL", %color );

	return %obj;
}

function createCube( %a, %scale, %color )
{
	if ( !strLen( %scale ) )
	{
		%scale = "0.05 0.05 0.05";
	}

	if ( !strLen( %color ) )
	{
		%color = "1 1 1 1";
	}

	%obj = new staticShape()
	{
		datablock = cubeShapeData;
		position = %a;
		scale = %scale;
	};

	missionCleanup.add( %obj );
	%obj.setNodeColor( "ALL", %color );

	return %obj;
}

function staticShape::removeLine( %this )
{
	%this.delete();
	%this = "";
}

function Player::debugLine( %this, %start, %stop, %ray )
{
	if( $PlayerParkour::Debug )
	{
		%this.debugLine = createLine( %start, %stop, 0.05, ( isObject( %ray ) ? "0" : "1" ) SPC ( isObject( %ray ) ? "1" : "0" ) SPC "0 1" );

		if( isObject( %this.debugLine ) )
		{
			%this.debugLine.schedule( 31, "removeLine" );
		}
	}
}

//Edge Detection and Rotation
// function Player::BoundaryCheck(%obj)
// {
// 	if(%obj.isHanging || %obj.isClimbing)
// 	{
// 	//	talk("Boundary Check loop");
// 	//	centerPrint(%obj.client,"<font:impact:24><br><br><br><br><color:FFF200><just:right>Boundary Check Loop ",0.1);
// 		if(!%obj.isLeaping)
// 		{
// 			%obj.grabchk2 = %obj.schedule(5,GrabCheck);
// 		//	talk("Secondary Grab Check");
// 		//	bottomPrint(%obj.client,"<font:impact:24><br><br><br><br><color:FFF200><just:right>Secondary Grab Check scheduled ",0.1);
// 		}
// 		cancel(%obj.bcheck);
// 		%obj.bcheck = %obj.schedule(10,BoundaryCheck);
// 		if(%obj.isHanging)
// 		{
// 			cancel(%obj.dirfix);
// 			%obj.dirfix = %obj.schedule(5,DirectionalFix);
// 		}
// 		%vec = %obj.getForwardVector();
// 		%vel = %obj.getVelocity();
// 		%pos = %obj.getPosition();
// 		%rv = relativevelocity(%vec,%vel);
// 		%lvec = %obj.getLeftVector();
// 		%rvec = %obj.getRightVector();
// 		%x = getWord(%rv,0);
// 		%y = getWord(%rv,1);
// 		%z = getWord(%vel,2);
// 		%up = getWord(%pos,2);
// 		%fwdX = getWord(%vec,0);
// 		%fwdY = getWord(%vec,1);
// 		if(%x > 5)
// 		{
// 			%obj.setVelocity(vectorScale(%dv,0.25) SPC %upv);
// 		}
// 		if(%x < -5)
// 		{
// 			%obj.setVelocity(vectorScale(%dv,0.25) SPC %upv);
// 		}
// 		if(%x > 0.1)
// 		{
// 			%xAdd = 0.2;
// 			%xAdd2 = 1;
// 			%xSub = -0.1;
// 			%sv = %lvec;
// 		}
// 		else if(%x < -0.1)
// 		{
// 			%xAdd = -0.2;
// 			%xAdd2 = -1;
// 			%xSub = 0.1;
// 			%sv = %rvec;
// 		}
// 		%ap = (%xAdd * %fwdY + %yAdd * %fwdX) SPC (%yAdd * %fwdY + %xAdd * -%fwdX) SPC %zAdd;
// 		%ap2 = (%xAdd2 * %fwdY + %yAdd2 * %fwdX) SPC (%yAdd2 * %fwdY + %xAdd2 * -%fwdX) SPC %zAdd2;
// 		%sp = (%xSub * %fwdY + %ySub * %fwdX) SPC (%ySub * %fwdY + %xSub * -%fwdX) SPC %zSub;
// 		%ledgePos = vectorAdd(%obj.getHackPosition(),"0 0 0.15");
// 		%startA = vectorAdd(%ledgePos,%ap);
// 		%beam = vectorScale(%vec,1);
// 		%endA = vectorAdd(%startA, %beam);
// 		%rayA = containerRayCast(%startA, %endA, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 		%spacePos = vectorAdd(%obj.getEyePoint(),"0 0 -0.55");
// 		%startB = vectorAdd(%spacePos,%ap);
// 		%endB = vectorAdd(%startB, %beam);
// 		%rayB = containerRayCast(%startB, %endB, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 		%ledgePos = vectorAdd(%obj.getHackPosition(),"0 0 0.15");

// 		%endC = vectorAdd(%ledgePos, %beam);
// 		%rayC = containerRayCast(%ledgePos, %endC, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 		%endD = vectorAdd(%spacePos, %beam);
// 		%rayD = containerRayCast(%spacePos, %endD, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 		if(!%obj.isClimbing && %obj.isHanging)
// 		{
// 			%startA2 = %ledgePos;
// 			%beam2 = vectorScale(%sv,1);
// 			%endA2 = vectorAdd(%startA2, %beam2);
// 			%rayA2 = containerRayCast(%startA2, %endA2, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 			%startB2 = %spacePos;
// 			%endB2 = vectorAdd(%startB2, %beam2);
// 			%rayB2 = containerRayCast(%startB2, %endB2, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 			if(isObject(%colA2 = firstWord(%rayA2)) && !isObject(%colB2 = firstWord(%rayB2)) && !%obj.isRotated)
// 			{
// 				if(%x < 5 && %x > 0)
// 				{
// 					%sideRotation = "0 0 -90";
// 				}
// 				if(%x > -5 && %x < 0)
// 				{
// 					%sideRotation = "0 0 90";
// 				}
// 				%obj.sideRotation = %sideRotation;
// 				%obj.Rotate90();
// 				return;
// 			}
// 			%new3 = vectorAdd(VectorScale(%ap,1),vectorScale(%vec,1));
// 			%startA3 = vectorAdd(%ledgePos,%new3);
// 			%beam3 = vectorScale(%sv,-0.5);
// 			%endA3 = vectorAdd(%startA3, %beam3);
// 			%rayA3 = containerRayCast(%startA3, %endA3, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 			%startB3 = vectorAdd(%spacePos,%new3);
// 			%endB3 = vectorAdd(%startB3, %beam3);
// 			%rayB3 = containerRayCast(%startB3, %endB3, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %obj);
// 			if(isObject(%colA3 = firstWord(%rayA3)) && !isObject(%colB3 = firstWord(%rayB3)))
// 			{
// 				if(!isObject(%colA = firstWord(%rayA)) || isObject(%colB = firstWord(%rayB)))
// 				{
// 					%newVector = vectorAdd(vectorScale(%ap2,0.8),vectorScale(%vec,1));
// 					%start = vectorAdd(%obj.getHackPosition(),%newVector);
// 					initContainerBoxSearch(%start, "1.3 1.3 1.6", $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType);
// 					%colD = containerSearchNext();
// 					if(!isObject(%colD) && !%obj.isRotated)
// 					{
// 						if(%x < 5 && %x > 0)
// 						{
// 							%sideRotation = "0 0 90";
// 						}
// 						if(%x > -5 && %x < 0)
// 						{
// 							%sideRotation = "0 0 -90";
// 						}
// 						%add = vectorAdd(%pos,"0 0 0.0");
// 						%obj.setVelocity("0 0 0");
// 						%obj.setTransform(vectorAdd(%add,%newVector));
// 						%obj.sideRotation = %sideRotation;
// 						%obj.Rotate90();
// 						return;
// 					}
// 				}
// 			}
// 		}
// 		if(!isObject(%colA = firstWord(%rayA)) || isObject(%colB = firstWord(%rayB)))
// 		{
// 			if(isObject(%colC = firstWord(%rayC)) && !isObject(%colC = firstWord(%rayD)))
// 			{
// 				if(!%obj.isRotated)
// 				{
// 					%obj.setTransform(vectorAdd(%pos,%sp));
// 				}
// 			}
// 		}
// 	}
// }

package MiscFunctions
{
//Rotate 180°
	function Player::TurnAround(%obj)
	{
		%eulerRotation = axisToEuler(getWords((%transform = %obj.getTransform()),3,6));
		%eulerXY = getWords(%eulerRotation,0,1);
		%eulerZ = getWord(%eulerRotation,2);
		if(%eulerZ <= 0)
		{
			%eulerZ += 180;
		}
		else
		{
			%eulerZ -= 180;
		}
		%oppositeEulerRot = %eulerXY SPC %eulerZ;
		%obj.setTransform(getWords(%transform,0,2) SPC eulerToAxis(%oppositeEulerRot));
	}
//Rotational Code
	function eulerToAxis(%euler)
	{
		%euler = VectorScale(%euler,$pi / 180);
		%matrix = MatrixCreateFromEuler(%euler);
		return getWords(%matrix,3,6);
	}
	function axisToEuler(%axis)
	{
		%angleOver2 = getWord(%axis,3) * 0.5;
		%angleOver2 = -%angleOver2;
		%sinThetaOver2 = mSin(%angleOver2);
		%cosThetaOver2 = mCos(%angleOver2);
		%q0 = %cosThetaOver2;
		%q1 = getWord(%axis,0) * %sinThetaOver2;
		%q2 = getWord(%axis,1) * %sinThetaOver2;
		%q3 = getWord(%axis,2) * %sinThetaOver2;
		%q0q0 = %q0 * %q0;
		%q1q2 = %q1 * %q2;
		%q0q3 = %q0 * %q3;
		%q1q3 = %q1 * %q3;
		%q0q2 = %q0 * %q2;
		%q2q2 = %q2 * %q2;
		%q2q3 = %q2 * %q3;
		%q0q1 = %q0 * %q1;
		%q3q3 = %q3 * %q3;
		%m13 = 2.0 * (%q1q3 - %q0q2);
		%m21 = 2.0 * (%q1q2 - %q0q3);
		%m22 = 2.0 * %q0q0 - 1.0 + 2.0 * %q2q2;
		%m23 = 2.0 * (%q2q3 + %q0q1);
		%m33 = 2.0 * %q0q0 - 1.0 + 2.0 * %q3q3;
		return mRadToDeg(mAsin(%m23)) SPC mRadToDeg(mAtan(-%m13, %m33)) SPC mRadToDeg(mAtan(-%m21, %m22));
	}
//Relative Velocity
	function relativeVelocity(%dirVec, %velVec)
	{
		%pi = 4 * mAtan(1, 1);
		%horMag = VectorLen(getWords(%velVec, 0, 1) SPC 0);
		%dirAng = mATan(getWord(%dirVec, 1), getWord(%dirVec, 0));
		%velAng = mATan(getWord(%velVec, 1), getWord(%velVec, 0));
		%relAng = %velAng - %dirAng + %pi/2;
		%relVec = VectorAdd(VectorScale(mCos(%relAng) SPC mSin(%relAng) SPC 0, %horMag), "0 0" SPC getWord(%velVec, 2));
	}
//Relative Vector
	function Player::getLeftVector(%obj)
	{
		return vectorCross(%obj.getEyeVector(),%obj.getUpVector());
	}
	function Player::getRightVector(%obj)
	{
		return vectorScale(%obj.getLeftVector(%obj),-1);
	}
};activatePackage(MiscFunctions);


function relativeVelocity(%dirVec, %velVec)
{
	%pi = 4 * mAtan(1, 1);
	%horMag = VectorLen(getWords(%velVec, 0, 1) SPC 0);
	%dirAng = mATan(getWord(%dirVec, 1), getWord(%dirVec, 0));
	%velAng = mATan(getWord(%velVec, 1), getWord(%velVec, 0));
	%relAng = %velAng - %dirAng + %pi/2;
	%relVec = VectorAdd(VectorScale(mCos(%relAng) SPC mSin(%relAng) SPC 0, %horMag), "0 0" SPC getWord(%velVec, 2));
}

function player::detectEdge(%this)
{
	%vec = %this.getForwardVector();
	%vel = %this.getVelocity();
	%pos = %this.getPosition();

	%rv = relativevelocity(%vec,%vel);    //refers to the relVel function I gave you and is used to get relative vectors

	%dv = getWords(%vel,0,1);    //horizontal velocity x and y
	%upv = getWord(%vel,2);    //vertical velocity z

	%x = getWord(%rv,0);    //Left | Right getVector
	%y = getWord(%rv,1);    //Forward | Back getVector

	%dp = getWords(%pos,0,1);    //Position X and Y
	%up = getWord(%pos,2);    //Position Z

	%fwdX = getWord(%vec,0);    //nonRelative X relative to your forward vector
	%fwdY = getWord(%vec,1);    //nonRelative Y relative to your forward vector

	if(%x > 0.1)
	{
		%xAdd = 0.2;    //if player's right velocity is intentional, then is a left position.
		%xSub = -0.1;    //if player's right velocity is intentional, this is a right position.
		%xVel = 1;    //setVelocity in the other direction
	}
	else if(%x < -0.1)
	{
		%xAdd = -0.2;    //if player's left velocity is intentional, then this is a right position.
		%xSub = 0.1;    //if player's left velocity is intentional, then this is a left position.
		%xVel = -1;    //setVelocity in the other direction
	}

	%ap = (%xAdd * %fwdY + %yAdd * %fwdX) SPC (%yAdd * %fwdY + %xAdd * -%fwdX) SPC %zAdd;
	%sp = (%xSub * %fwdY + %ySub * %fwdX) SPC (%ySub * %fwdY + %xSub * -%fwdX) SPC %zSub;
	%av = (%xVel * %fwdY + %yVel * %fwdX) SPC (%yVel * %fwdY + %xVel * -%fwdX) SPC %upv;
	%ledgePos = vectorAdd(%this.getHackPosition(),"0 0 0.15");
	%startA = vectorAdd(%ledgePos,%ap);
	%beamA = vectorScale(%vec,1);
	%endA = vectorAdd(%startA, %beamA);
	%rayA = containerRayCast(%startA, %endA, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %this);
	%spacePos = vectorAdd(%this.getEyePoint(),"0 0 -0.55");
	%startB = vectorAdd(%spacePos,%ap);
	%beamB = vectorScale(%vec,1);
	%endB = vectorAdd(%startB, %beamB);
	%rayB = containerRayCast(%startB, %endB, $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType | $Typemasks::VehicleObjectType, %this);
	if(!isObject(%colA = firstWord(%rayA)) || isObject(%colB = firstWord(%rayB)))
	{
	//	%this.setVelocity(%av);
	//	talk("edge detected");
		return vectorAdd( %pos,%sp );
	}
	return false;
}

function Player::ledgeGrabCheck(%this)
{
	//        talk("Grab called");
	%start = vectorAdd( %this.getHackPosition(), "0 0 0.15" );
	%beam = vectorScale( %this.getForwardVector(), 1 );
	%end = vectorAdd( %start, %beam );
	%ray = containerRayCast( %start, %end, $TypeMasks::fxBrickObjectType, %this);
	%this.debugLine( %start, %end, %ray );
	if( isObject( %col = firstWord( %ray ) ) )
	{
		////        talk("player is infront of wall at right distance");
		//%start = vectorAdd( %this.getEyePoint(), "0 0 -0.55" );//%this.getEyePoint();
		//%beam = vectorScale( %this.getForwardVector(), 1 );
		//%end = vectorAdd( %start, %beam );
		%check = %this.brickAboveCheck(%ray, %end);//%ray = containerRayCast( %start, %end, $TypeMasks::fxBrickObjectType, %this );
		if( %check !$= "Fail" && %check == 0 )//!isObject( %col = firstWord( %ray ) ) )
		{
			return %col;
		}
	}
	return false;
}
