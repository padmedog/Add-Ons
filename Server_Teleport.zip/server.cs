function serverCmdteleport(%cl, %t1, %t2, %t3, %t4, %t5, %t6) {
	if(!%cl.isAdmin)
		return;

	if(%t1 $= "ALL") 
		for(%i=0; %i < clientGroup.getCount(); %i++) {
			if(clientGroup.getObject(%i).name $= %cl.name)
				continue;
			%targets = %targets SPC clientGroup.getObject(%i).name;
		}
	else 
		%targets = %t1 SPC %t2 SPC %t3 SPC %t4 SPC %t5 SPC %t6;
	
	%targets = trim(%targets);
	
	%player = %cl.player;
	%start = %player.getEyePoint();
	%vector = VectorScale(%player.getEyeVector(), "1000");
	%end = VectorAdd(%start, %vector);
	%scanTarg = containerRayCast(%start, %end, $TypeMasks::All, %player);
	%position = getWords(%scanTarg, "1", "3");
	
	for(%i=0; %i < getWordCount(%targets); %i++) {
		%targets[%i] = findClientByName(getWord(%targets, %i));
		if(!isObject(%targets[%i])) 
			continue;
		if(!isObject(%targets[%i].player))
			%targets[%i].instantRespawn();
		%targets[%i].player.setVelocity("0 0 0");
		%targets[%i].player.setTransform(%position);
		%targets[%i].player.teleportEffect();
	}
}

function serverCmdtele(%cl, %t1, %t2, %t3, %t4, %t5, %t6) {
	serverCmdteleport(%cl, %t1, %t2, %t3, %t4, %t5, %t6);
}