 datablock PlayerData(RotHunterZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	aircontrol = 0.4;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;

	maxDamage = 80;
	runforce = 60 * 90;
	maxForwardSpeed = 6;
	maxBackwardSpeed = 6;
	maxSideSpeed = 6;
	attackpower = 15;
	jumpsound = "ZombieJumpSound";
	
	SearchRadius = 50;
	jumpForce = 10 * 90; //8.3 * 90;
	BrickDestroyMaxVolume = 150;
	BrickMaxJumpHeight = 40;
	uiName = "Zombie Hunter";
	rideable = true;
	canRide = true;
	BrickKillRadius = 3;
	skinColor = "1 0.818 0 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
	SpecialAttack = 1;
	ZNoJump = 1;
	minimpactspeed = 30;
	ignorePipeBombs = 1;
};

function RotHunterZombie::SpecialAttack(%this,%onshot)
{
	if(getsimtime() >= %this.lastpounce+2500 && %this.getstate() !$= "Dead")
	{
		if(Isonground(%this) || Isonwall(%this))
		{
			%target = %this.isfollowingid;

			%thisz = getword(%this.getposition(),2);
			%targetz = getword(%target.getposition(),2);
			
			%DiffZ = %targetz-%thisz;
			%fz = 0.1*%diffz;
			%dis = VectorSub(%target.getposition(),%this.getposition());
			%normVec = VectorNormalize(vectoradd(%dis,"0 0" SPC 0.15*vectordist(%target.getposition(),%this.getposition())));
			if(%onshot == 1)
			{
				//%normVec = VectorNormalize(vectoradd(%dis,"0 0" SPC 0.05*vectordist(%target.getposition(),%this.getposition())));
			}
			%this.playthread(2,crouch);
			%this.playaudio(1,Zombiejumpsound);
			//%eye = vectoradd(%this.getforwardvector(),"0 0 0.2");
			%eye = vectorscale(%normVec,2);
			%mp = 30;
			%final = vectorscale(%eye,%mp);
			//%this.setvelocity(vectorscale(%final,%fz));
			%this.setvelocity(%final);
			%this.lastpounce = getsimtime();
			//%this.schedule(1000,setimagetrigger,3,0);
			//%this.schedule(10,zResetAnimation,%this,3);
			schedule(1000,0,zResetAnimation,%this,2);
		}
	}
}
function zResetAnimation(%player,%slot)
{
	if(%player.getstate() !$= "dead")
	{
		%player.playthread(%slot,root);
	}
}
function RotHunterZombie::onImpact(%this,%obj,%col,%norm,%speed)
{
	%speed = 0;
	armor::onImpact(%this,%obj,%col,%norm,%speed);
}
function RotHunterZombie::ondisabled(%this,%obj)
{
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotHunterZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotHunterZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotHunterZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotHunterZombie::onAdd(%this,%obj)
{
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
	%obj.setscale("1 1 1.1");
}

function RotHunterZombie::onTrigger(%this,%obj,%slot,%state)
{
	//echo("slot : " @ %a SPC "state : " @ %b);
	if(%slot == 3)
	{
		if(%state == 1)
		{
			%obj.pounceready = 1;
		}
		if(%state == 0)
		{
			%obj.pounceready = 0;
		}
	}
	//if(%slot == 0 && %state == 1 && %obj.pounceready == 1 && getword(%obj.geteyevector(),2) >= 0)
	if(%slot == 0 && %state == 1 && %obj.pounceready == 1)
	{
		if(Isonground(%obj) || Isonwall(%obj))
		{
			if(Isonwall(%obj) == 0 && getword(%obj.geteyevector(),2) <= 0)
			{
				return;
			}
			%obj.playaudio(1,Zombiejumpsound);
			%eye = %obj.geteyevector();
			%mp = 30;
			%final = vectorscale(%eye,%mp);
			%obj.setvelocity(%final);
		}
	}
}
function Isonground(%this)
{
	%eyeVec = "0 0 -1";

	%startPos = %this.getposition();
	%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,1));

	%mask = $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType;
	%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
	if(%target)
	{
		return 1;
	}
	return 0;
}
function Isonwall(%this)
{
	%eyeVec = vectorsub(%this.getforwardvector(),vectorscale(%this.getforwardvector(),2));

	%startPos = %this.getposition();
	%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,1));

	%mask = $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType;
	%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
	if(%target)
	{
		return 1;
	}
	return 0;
}