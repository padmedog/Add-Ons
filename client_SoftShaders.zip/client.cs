if($Shader::CurrentShader $= "")
{
	$Shader::CurrentShader = 0;
}

if(!$Shader::Binded)
{
	$remapDivision[$remapCount] = "Soft Shaders";
	$remapName[$remapCount] = "Normal";
	$remapCmd[$remapCount] = "setShaderNormal";
	$remapCount++;

	$remapName[$remapCount] = "Soft";
	$remapCmd[$remapCount] = "setShaderSoft";
	$remapCount++;

	$remapName[$remapCount] = "Ultra";
	$remapCmd[$remapCount] = "setShaderUltra";
	$remapCount++;

	$remapName[$remapCount] = "Performance";
	$remapCmd[$remapCount] = "setShaderPerformance";
	$remapCount++;

	$Shader::Binded = true;
}

function setShaderNormal(%i)
{
	if(%i || $Shader::CurrentShader == 0)
		return;
	if(getShaderQuality() > 1)
	{
		$Shader::ShaderName = "renderCsm";
		initializeShaderAssets();
		regenerateShadowMapFBOs();
		flushVBOCache();
	}
	$Shader::CurrentShader = 0;

	clientCmdBottomPrint("\c6Set shaders to \c3Normal\c6.", 3, 1);
}

function setShaderSoft(%i)
{
	if(%i || $Shader::CurrentShader == 1)
		return;
	if(getShaderQuality() > 1)
	{
		$Shader::ShaderName = "soft";
		initializeShaderAssets();
		regenerateShadowMapFBOs();
		flushVBOCache();
	}
	$Shader::CurrentShader = 1;

	clientCmdBottomPrint("\c6Set shaders to \c3Soft\c6.", 3, 1);
}

function setShaderUltra(%i)
{
	if(%i || $Shader::CurrentShader == 2)
		return;
	if(getShaderQuality() > 1)
	{
		$Shader::ShaderName = "ultra";
		initializeShaderAssets();
		regenerateShadowMapFBOs();
		flushVBOCache();
	}
	$Shader::CurrentShader = 2;

	clientCmdBottomPrint("\c6Set shaders to \c3Ultra\c6.", 3, 1);
}

function setShaderPerformance(%i)
{
	if(%i || $Shader::CurrentShader == 3)
		return;
	echo(getShaderQuality());
	if(getShaderQuality() > 1)
	{
		$Shader::ShaderName = "performance";
		initializeShaderAssets();
		regenerateShadowMapFBOs();
		flushVBOCache();
	}
	$Shader::CurrentShader = 3;

	clientCmdBottomPrint("\c6Set shaders to \c3Performance\c6.", 3, 1);
}

if(isPackage(SoftShaders))
{
	deactivatePackage(SoftShaders);
}

package SoftShaders
{
	function OptionsDlg::setShaderQuality(%this, %quality)
	{
		%shader = $Shader::CurrentShader;

		Parent::setShaderQuality(%this, %quality);

		$Shader::Quality = %quality;

		$Shader::CurrentShader = -1;

		switch(%shader)
		{
			case 1:
				setShaderSoft();
			case 2:
				setShaderUltra();
			case 3:
				setShaderPerformance();
			default:
				setShaderNormal();
		}
	}
};

activatePackage(SoftShaders);

function getShaderQuality()
{
	if($Shader::Quality !$= "")
	{
		return $Shader::Quality;
	}

	for(%a = 0; %a < 7; %a++)
	{
		%obj = "OPT_ShaderQuality" @ %a;

		if(isObject(%obj) && %obj.getValue())
		{
			return %a;
		}
	}

	return 0;
}