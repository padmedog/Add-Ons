datablock AudioProfile(GasmaskUseSound)
{
  filename = "base/data/sound/playermount.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock ItemData(GasmaskItem)
{
  uiName = "Gasmask";
  iconName = "./icon_gasmask";
  image = GasmaskHImage;
  category = "Tools";
  className = "Weapon";
  shapeFile = "./gasmaskitem.dts";
  mass = 0.5;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};


datablock ShapeBaseImageData(GasmaskHImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = true;
  mountPoint = 0;
  offset = "0 0 0";
  eyeOffset = "0 0 0.0";
  rotation = eulerToMatrix("0 0 0");
  className = "WeaponImage";
  item = GasmaskItem;
  melee = false;
  doReaction = false;
  armReady = false;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTimeOut[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

function GasmaskHImage::onFire(%this,%obj,%slot)
{
  %client = %obj.client;
  %player = %obj;
  if(isObject(%player))
  {
    if(%player.getMountedImage(2) $= nametoID(GasmaskMaskImage))
    {
      %player.unmountImage(2);
      serverPlay3D(GasmaskuseSound,%obj.getTransform());
    }
    else
    {
      %player.unmountImage(2);
      %player.mountImage(GasmaskMaskImage,2);
      serverPlay3D(GasmaskuseSound,%obj.getTransform());
    }
  }
}

package GasmaskPackage
{
  function servercmdDropTool(%this,%slot)
  {
    if(isobject(%this.player.tool[%slot]) && %this.player.tool[%slot].getname() $= "GasmaskItem")
    {
      parent::servercmdDropTool(%this,%slot);
      if(isobject(%this.player.getmountedimage(2)) && %this.player.getmountedimage(2).getname() $= "GasmaskMaskImage") { %this.player.schedule(5,unmountimage,2); }
      return;
    }
    parent::servercmdDropTool(%this,%slot);
  }
};
activatepackage(GasmaskPackage);


datablock ShapeBaseImageData(GasmaskMaskImage)
{
  shapeFile = "./Gasmask.dts";
  emap = true;
  mountPoint = $HeadSlot;
  offset = "0 0 0";
  eyeOffset = "0 0 -0.05";
  rotation = eulerToMatrix("0 0 0");
  eyeRotation = eulerToMatrix("0 0 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = false;
  colorShiftColor = "1 1 1 1";
  hasLight = false;
   doRetraction = false;

};

function GasmaskMaskImage::OnMount(%this,%obj,%slot,%client)
{
	Parent::OnMount(%this,%obj,%slot,%client);
	%obj.client.Gasmask = 1;
	%obj.unMountImage(3);

}

function GasmaskMaskImage::onUnMount(%this,%obj,%slot,%client)
{
	Parent::onUnMount(%this,%obj,%slot,%client);
	%obj.client.Gasmask = 0;
}