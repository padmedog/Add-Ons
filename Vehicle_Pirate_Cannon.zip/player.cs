//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

datablock TSShapeConstructor(PlayerDts)
{
   baseShape = "./cannon.dts";
   sequence0 = "./cannon_look.dsq look";
};         
