//ALL OF THIS WAS MADE BY SPACE GUY


if(isFile("Add-Ons/Weapon_Kitchen/description.txt"))
   %path = "Add-Ons/Weapon_Kitchen/";
else
   %path = "./";

datablock AudioProfile(KitchenMeleeHitBrickSoundA)
{
   filename    = %path @ "KitchenMeleeClangA.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(KitchenMeleeHitBrickSoundB)
{
   filename    = %path @ "KitchenMeleeClangB.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(KitchenMeleeHitPlayerSound)
{
   filename    = %path @ "KitchenMeleeHit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(KitchenMeleeSwingSound)
{
   filename    = %path @ "KitchenMeleeSwing.wav";
   description = AudioClosest3d;
   preload = true;
};

function KitchenMeleeWeaponImage::onMount(%this, %obj, %slot)
{
	WeaponImage::onMount(%this, %obj, %slot);
}

function KitchenMeleeWeaponImage::onUnMount(%this, %obj, %slot)
{
	WeaponImage::onUnMount(%this, %obj, %slot);
	%obj.playThread(2,root);
}

function KitchenMeleeWeaponImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, shiftAway);
}

function KitchenMeleeWeaponImage::onFire(%this, %obj, %slot)
{
	WeaponImage::onFire(%this, %obj, %slot);
	%obj.playthread(2, wrench);
}

function KitchenMeleeWeaponImage::onStopFire(%this, %obj, %slot)
{	
	//%obj.playthread(2, root);
}

function KitchenMeleeWeaponImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   WeaponImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit);
}

function KitchenMeleeWeaponImage::onRaycastDamage(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   WeaponImage::onRaycastDamage(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit);
}

function KitchenMeleeWeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit)
{
   if(isObject(%obj) && (%obj.getType() & $TypeMasks::PlayerObjectType) && %col.iszombie)
   {
       return 1;
   }
   return WeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit);
}
