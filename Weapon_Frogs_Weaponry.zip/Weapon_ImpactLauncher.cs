
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ExplosionData(ImpactGrenadeExplosion)
{
   explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
   lifeTimeMS = 150;

   soundProfile = ImpactGrenadeExplosionSound;
   
   emitter[0] = ImpactGrenadeExplosionRingEmitter;
   emitter[1] = ImpactGrenadeExplosionEmitter;
   emitter[2] = ImpactGrenadeExplosionRing2Emitter;
   //emitter[1] = "";
   //emitter[2] = "";
   //emitter[0] = "";


   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 3;
   impulseForce = 100;

   damageRadius = 4;
   radiusDamage = 100;

//	uiName = "Impact Grenade Explosion";
};

AddDamageType("ImpactLauncher",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactLauncher> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactLauncher> %1',0.75,1);
AddDamageType("ImpactLauncherRadius",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactLauncherRadius> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactLauncherRadius> %1',0.75,1);
datablock ProjectileData(ImpactLauncherProjectile)
{
   projectileShapeName = "./ImpactGrenadeThrown.dts";
   directDamage        = 25;
   directDamageType = $DamageType::ImpactLauncherDirect;
   radiusDamageType = $DamageType::ImpactLauncherRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = ImpactGrenadeExplosion;
   particleEmitter     = ImpactGrenadeTrailEmitter;
   
   brickExplosionRadius = 2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 5;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 20;  //max volume of bricks that we can destroy if they aren't connected to the ground

//   impactImpulse	     = 20;
   verticalImpulse     = 10;
   explosion           = ImpactGrenadeExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1;

   hasLight    = true;
   lightRadius = 2.0;
   lightColor  = "1 0 0";
};



//////////
// item //
//////////
datablock ItemData(ImpactLauncherItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./ImpactLauncher.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Impact Launcher";
	iconName = "./icon_ImpactLauncher";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = ImpactLauncherImage;
	canDrop = true;
	
	maxAmmo = 4;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ImpactLauncherImage)
{
   // Basic Item properties
   shapeFile = "./ImpactLauncher.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ImpactLauncherItem;
   ammo = " ";
   projectile = ImpactLauncherProjectile;
   projectileType = Projectile;

     shellExitDir        = "-1.0 1.0 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ImpactLauncherItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.25;	
	stateTransitionOnTimeout[0]     = "SightUp";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= ImpactLauncherFireSound;

	stateName[3] 			= "Smoke";
	stateSequence[3]                = "BarrelSpin";
	stateTimeoutValue[3]            = "0.5";
        stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.05;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTimeout[3] = "Wait";

	stateName[4]			= "Wait";
        stateTimeoutValue[4]		= 0.1;
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "TriggerUp";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 2.0;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.3;
	stateScript[9]				= "onReloaded";
        stateTransitionOnTimeout[9]		= "Ready";
		
    stateName[10]               = "SightUp";
	stateTimeoutValue[10]       = 0.1;
	stateScript[10]             = "OnSightUp";
	stateSequence[10]           = "Sightup";
	stateTransitionOnTimeout[10]= "LoadCheckA";
	
	stateName[11]               = "TriggerUp";
	stateTransitionOnTriggerUp[11]= "Ready";
	stateTransitionOnTimeout[11] = "TriggerUp";
	};

function ImpactLauncherImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Impact Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["ImpactGrenade"] @ "", 1, 2, 3, 4); 
}

function ImpactLauncherImage::onFire(%this,%obj,%slot)
{
	%projectile = ImpactLauncherProjectile;
	
	if(vectorLen(%obj.getVelocity()) < 0.1)
	{
		%spread = 0.0001;
	}
	else
	{
		%spread = 0.0002;
	}
	
	%shellcount = 1;

	%obj.playThread(2, jump);
	%shellcount = 1;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Impact Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["ImpactGrenade"] @ "", 4, 2, 3, 4); 

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function ImpactLauncherImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Impact Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["ImpactGrenade"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["ImpactGrenade"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function ImpactLauncherImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["ImpactGrenade"] >= 1)
	{

	%obj.playThread(2, plant);
        if(%obj.client.quantity["ImpactGrenade"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["ImpactGrenade"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
            serverPlay3D(FWReload1Sound,%obj.getPosition());
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Impact Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["ImpactGrenade"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["ImpactGrenade"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["ImpactGrenade"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
            serverPlay3D(FWReload1Sound,%obj.getPosition());
		%obj.client.quantity["ImpactGrenade"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Impact Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["ImpactGrenade"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}

function ImpactLauncherImage::onSightUp(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
}

//statescript onBounce