//button.cs

function neobutton::onmouseenter(%this, %key, %pos, %count)
{
	neo_debug("Enter: " @ %this SPC "[" @ %pos @ "]");

	if(!%this.dragctrl)
	{
		if($neo_dragging)
		{
			neo_debug("mouseenter while dragging, this should not happen");
			return;
		}
		%this.getgroup().setcolor($neo::pref::buttonColorHighlight);
	}
}

function neobutton::onmouseleave(%this, %key, %pos, %count)
{
	neo_debug("Leave: " @ %this SPC "[" @ %pos @ "]");

	if(%this.dragctrl)
	{
		if($neo_dragging)
		{
			neo_debug("mouse somehow leaving dragctrl, might as well disable");
			%this.disableDrag();
		}
		return;
	}

	if($neo_dragging)
	{
		//we are transitioning to/from the dragctrl
		return;
	}

	if(iseventpending(%this.dragsched))
	{
		%dragtried = true;
		cancel(%this.dragsched);
	}

	if(%this.mdown)
	{
		if(%this.commandObj.addbutton)
		{
			%this.mdown = false;
		}
		else if(%dragtried)
		{
			//i guess maybe idk
			%this.enableDrag();
			return;
		}
		else //probably a context menu going up
		{
			%this.mdown = false;
			return;
		}
	}
	%this.getgroup().setcolor($neo::pref::buttonColorIdle);
}

function neobutton::onmousedown(%this, %key, %pos, %count)
{
	neo_debug("Down: " @ %this SPC "[" @ %pos @ "]");

	if(%this.dragCtrl)
	{
		neo_debug("Drag Control Clicked, this should not happen.");
		%this.setVisible(0);
		return;
	}

	if($neo_dragging)
	{
		neo_debug("mousedown while dragging, this should not happen");
		return;
	}
	%this.getgroup().setcolor($neo::pref::buttonColorPress);
	%this.mdown = true;

	%this.dragsched = %this.schedule($neo::pref::dragThreshold, "enableDrag");
}

function neobutton::onmousedragged(%this, %key, %pos, %count)
{
	neo_debug("Drag: " @ %this SPC "[" @ %pos @ "]");

	if(%this.dragctrl)
	{
		neo_debug("accessing dragctrl.target: " @ %this @ "." @ %this.target);
		%this.target.dragUpdate(%pos);
	}
}

function neobutton::onmouseup(%this, %key, %pos, %count)
{
	neo_debug("Up: " @ %this SPC "[" @ %pos @ "]");

	if(%this.dragCtrl)
	{
		%command = %this.target.commandObj;
		%oldid = neomain.commandLookup[%command.name, %command.cmd];

		if(%oldid $= "")
		{
			neo_debug("command does not seem to exist, this should not happen.");
		}
		//to do
		//convert screen to id
		%listpos = EscapeOverlay_List.nfm_getscreenpos();
		%position = vectorsub(%pos, %listpos);
		%column = mfloor((getword(%position, 0) - 4)/($neo::pref::buttonsize + 8));
		%row = mfloor((getword(%position, 1) - 4)/($neo::pref::buttonsize + 8));
		%maxcolumn = mfloor((getword(EscapeOverlay_List.getextent(), 0) - ($neo::pref::buttonsize + 12))/($neo::pref::buttonsize + 8));

		if(%column < 0)
			%column = 0;

		if(%row < 0)
			%row = 0;

		if(%column > %maxcolumn)
			%column = %maxcolumn;
		%id = %row * (%maxcolumn + 1) + %column;

		if(%id > neomain.commandCount - 2)
			%id = neomain.commandCount - 2;

		if(%id > %oldid)
		{
			for(%i = %oldid; %i < %id; %i++)
			{
				neomain.swapCommands(%i, %i+1);
			}
		}
		else
		{
			for(%i = %oldid; %i > %id; %i--)
			{
				neomain.swapCommands(%i, %i-1);
			}
		}
		neomain.savedata();
		neomain.maintain();
		%this.disableDrag();
		return;
	}

	if($neo_dragging)
	{
		neo_debug("mouse up while dragging, this should not happen.");
		return;
	}

	if(iseventpending(%this.dragsched))
		cancel(%this.dragsched);

	%this.getgroup().setcolor($neo::pref::buttonColorHighlight);

	if(!%this.mdown)
	{
		neo_debug("mouseup without mousedown: " @ %this);
		return;
	}
	%this.mdown = false;
	neomain.useCommand(%this.commandObj);
}

function neobutton::onrightmousedown(%this, %key, %pos, %count)
{
	if(iseventpending(%this.dragsched))
		cancel(%this.dragsched);

	if(!%this.dragctrl)
	{
		%this.getgroup().setcolor($neo::pref::buttonColorContext);
	}
}

function neobutton::onrightmouseup(%this, %key, %pos, %count)
{
	if(iseventpending(%this.dragsched))
		cancel(%this.dragsched);

	if(!%this.dragctrl)
	{
		neomain.showContext(%pos, %this);
	}
}

function neobutton::onrightmousedragged(%this, %key, %pos, %count)
{
	//nothing yet
}

function neobutton::dragUpdate(%this, %pos)
{
	neo_debug("drag update: " @ %pos);
	%newpos = vectorsub(%pos, $neo::pref::buttonsize/2 SPC $neo::pref::buttonsize/2);
	%ext = %this.getGroup().getExtent();
	%this.getGroup().resize(getword(%newpos, 0), getword(%newpos, 1), getword(%ext, 0), getword(%ext, 1));
}

function neobutton::enableDrag(%this)
{
	neo_debug("enable drag");

	if(iseventpending(%this.dragsched))
		cancel(%this.dragsched);

	if(%this.commandObj.addbutton)
	{
		neo_debug("Moving the add button is not allowed, this should never happen.");
		return;
	}

	if(%this.dragctrl)
	{
		neo_debug("Drag control initiating drag, this should not happen");
		return;
	}
	$neo_dragging = true;

	neo_debug("setting dragctrl.target: " @ NARGEscapeOverlay.dragCtrl @ "." @ %this);
	NARGEscapeOverlay.dragCtrl.target = %this;
	%this.mdown = false;
	%this.getgroup().setcolor($neo::pref::buttonColorDrag);

	neo_dragdisplay.add(%this.getgroup());
	%this.dragUpdate(canvas.getcursorpos());
	NARGEscapeOverlay.dragCtrl.setVisible(1);
	neo_dragdisplay.setVisible(1);
}

function neobutton::disableDrag(%this)
{
	if(!%this.dragctrl)
	{
		neo_debug("Drag control not disabling drag, this should not happen");
		return;
	}
	neo_debug("accessing dragctrl.target: " @ %this @ "." @ %this.target);
	%this.target.getgroup().setcolor($neo::pref::buttonColorIdle);
	neo_debug("disabling drag");
	%this.target = "";
	%this.setVisible(0);
	neo_dragdisplay.clear();
	neo_dragdisplay.setvisible(0);
	neomain.forcedraw();
	$neo_dragging = false;
}

