datablock fxDTSBrickData (brick1x2LadderData)
{
	brickFile = "./1x2Ladder.blb";
	canCover = true;
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2F Ladder";
	iconName = "Add-Ons/Brick_MiscellaneousPack/1x2Ladder";
};

datablock fxDTSBrickData (brick1x2HandleTileData)
{
	brickFile = "./1x2HandleTile.blb";
	collisionShapeName = "./1x2HandleTile.dts";
	canCover = true;
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2F Tile Handle";
	iconName = "Add-Ons/Brick_MiscellaneousPack/1x2HandleTile";
};

datablock fxDTSBrickData (brick1x2HandleType1Data)
{
	brickFile = "./1x2HandleType1.blb";
	collisionShapeName = "./1x2Handle.dts";
	canCover = true;
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2F Handle Type 1";
	iconName = "Add-Ons/Brick_MiscellaneousPack/1x2HandleType1";
};

datablock fxDTSBrickData (brick1x2HandleType2Data)
{
	brickFile = "./1x2HandleType2.blb";
	collisionShapeName = "./1x2Handle.dts";
	canCover = true;
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2F Handle Type 2";
	iconName = "Add-Ons/Brick_MiscellaneousPack/1x2HandleType2";
};

datablock fxDTSBrickData (brick1x2OverhangData)
{
	brickFile = "./1x2Overhang.blb";
	canCover = true;
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2F Overhang";
	iconName = "Add-Ons/Brick_MiscellaneousPack/1x2Overhang";
};

datablock fxDTSBrickData (brick1x1HandleVertData)
{
	brickFile = "./1x1HandleVert.blb";
	canCover = true;
	category = "Special";
	subCategory = "Misc";
	uiName = "1x1 Vert Handle";
	iconName = "Add-Ons/Brick_MiscellaneousPack/1x1HandleVert";
};
