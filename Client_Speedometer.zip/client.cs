  
   $spm = new GuiBitmapCtrl(Speedometer_main) {
      profile = "GuiDefaultProfile";
      horizSizing = "right";
      vertSizing = "bottom";
      position = "44 359";
      extent = "100 100";
      minExtent = "8 2";
      enabled = "1";
      visible = "1";
      clipToParent = "1";
      bitmap = "./base.png";
      wrap = "0";
      lockAspectRatio = "0";
      alignLeft = "0";
      alignTop = "0";
      overflowImage = "0";
      keepCached = "0";
      mColor = "255 255 255 255";
      mMultiply = "0";

      new GuiBitmapCtrl(Speedometer_needle) {
         profile = "GuiDefaultProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "12 27";
         extent = "1 24";
         minExtent = "1 24";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         bitmap = "./needle.png";
         wrap = "1";
         lockAspectRatio = "1";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "1";
         keepCached = "0";
         mColor = "255 0 0 255";
         mMultiply = "0";
      };
      new GuiSwatchCtrl(Speedometer_S) {
         profile = "GuiDefaultProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "23 61";
         extent = "50 12";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         color = "255 255 255 255";

         new GuiTextCtrl(Speedometer_Text) {
            profile = "GuiTextProfile";
            horizSizing = "right";
            vertSizing = "bottom";
            position = "10 -3";
            extent = "32 18";
            minExtent = "8 2";
            enabled = "1";
            visible = "1";
            clipToParent = "1";
            text = "15 m/s";
            maxLength = "255";
         };
      };
   };

	PlayGui.add($spm);

function updateneedleoffset(%offset)
{
	if(%offset > 40)
		Speedometer_S.color = "255 100 100 255";
	else
		Speedometer_S.color = "255 255 255 255";
	Speedometer_text.setValue(%offset SPC "S/s");
	if(%offset > 75)
		%offset = 75;
	if(%offset < 0)
		%offset = 0;
	Speedometer_needle.position = 12+%offset SPC 27;
}

function updatespeedometer()
{
	if(isObject(serverconnection))
	{
		%speed = getcontrolobjectspeed();
		updateneedleoffset(%speed);
	}

	schedule(250,0,updatespeedometer);
}
updatespeedometer();

function togglespeedometer(%d)
{
	if(%d)
	{
		echo("Hi.");
		Speedometer_main.visible = !Speedometer_main.visible;
	}
}

$remapDivision[$remapCount] = "Compass";
$remapName[$remapCount] = "Toggle Speedometer";
$remapCmd[$remapCount] = "togglespeedometer";
$remapCount++;

