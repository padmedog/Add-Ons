//BearTrap

$JVS::Content::Type::animationLengthStart = 400;
$JVS::Content::Type::animationLengthStop = 800;
$JVS::Content::Type::animationNameStartCCW = "close";
$JVS::Content::Type::animationNameStartCW = "close";
$JVS::Content::Type::animationNameStopCCW = "open";
$JVS::Content::Type::animationNameStopCW = "open";
$JVS::Content::Type::brickFile = "Add-Ons/content_phydeouxTraps/bricks/3_3_1.blb";
$JVS::Content::Type::brickSearches = 0;
$JVS::Content::Type::brickSize = 3 TAB 3 TAB 1;
$JVS::Content::Type::brickSubcategory = "PhyTraps";
$JVS::Content::Type::datablockBrick = "contentBrickBearTrap";
$JVS::Content::Type::datablockDebris = "contentDebrisBearTrap";
$JVS::Content::Type::datablockExplosion = "contentExplosionBearTrap";
$JVS::Content::Type::datablockProjectile = "contentProjectileBearTrap";
$JVS::Content::Type::datablockShape = "contentShapeBearTrap";
$JVS::Content::Type::datablockShapeColliding = "contentShapeBearTrap";
$JVS::Content::Type::datablockSoundStart = "BearTrapStart";
$JVS::Content::Type::datablockSoundStop = "BearTrapStop";
$JVS::Content::Type::eventCount = 17;

$JVS::Content::Type::eventEnabled[0] = 1;
$JVS::Content::Type::eventDelay[0] = 0;
$JVS::Content::Type::eventInput[0] = "\"onActivate\"";
$JVS::Content::Type::eventTarget[0] = "\"Self\"";
$JVS::Content::Type::eventOutput[0] = "\"contentStart\"";
$JVS::Content::Type::eventParameterCount[0] = 2;
$JVS::Content::Type::eventParameter[0 @ "_" @ 0] = 0;
$JVS::Content::Type::eventParameter[0 @ "_" @ 1] = 0;

$JVS::Content::Type::eventEnabled[1] = 1;
$JVS::Content::Type::eventDelay[1] = "ContentTypesSO.getSoundDelayStartFromID(%contentTypeID)";
$JVS::Content::Type::eventInput[1] = "\"onContentStart\"";
$JVS::Content::Type::eventTarget[1] = "\"Self\"";
$JVS::Content::Type::eventOutput[1] = "\"playSound\"";
$JVS::Content::Type::eventParameterCount[1] = 1;
$JVS::Content::Type::eventParameter[1 @ "_" @ 0] = "ContentTypesSO.getDatablockSoundStartFromID(%contentTypeID)";

$JVS::Content::Type::eventEnabled[2] = 1;
$JVS::Content::Type::eventDelay[2] = 0;
$JVS::Content::Type::eventInput[2] = "\"onPlayerTouch\"";
$JVS::Content::Type::eventTarget[2] = "\"Self\"";
$JVS::Content::Type::eventOutput[2] = "\"ContentStart\"";
$JVS::Content::Type::eventParameterCount[2] = 2;
$JVS::Content::Type::eventParameter[2 @ "_" @ 0] = 0;
$JVS::Content::Type::eventParameter[2 @ "_" @ 1] = 0;

$JVS::Content::Type::eventEnabled[3] = 0;
$JVS::Content::Type::eventDelay[3] = 0;
$JVS::Content::Type::eventInput[3] = "\"onActivate\"";
$JVS::Content::Type::eventTarget[3] = "\"Self\"";
$JVS::Content::Type::eventOutput[3] = "\"contentStop\"";
$JVS::Content::Type::eventParameterCount[3] = 1;
$JVS::Content::Type::eventParameter[3 @ "_" @ 0] = 0;

$JVS::Content::Type::eventEnabled[4] = 1;
$JVS::Content::Type::eventDelay[4] = "ContentTypesSO.getSoundDelayStopFromID(%contentTypeID)";
$JVS::Content::Type::eventInput[4] = "\"onContentStop\"";
$JVS::Content::Type::eventTarget[4] = "\"Self\"";
$JVS::Content::Type::eventOutput[4] = "\"playSound\"";
$JVS::Content::Type::eventParameterCount[4] = 1;
$JVS::Content::Type::eventParameter[4 @ "_" @ 0] = "ContentTypesSO.getDatablockSoundStopFromID(%contentTypeID)";

$JVS::Content::Type::eventEnabled[5] = 1;
$JVS::Content::Type::eventDelay[5] = 0;
$JVS::Content::Type::eventInput[5] = "\"onContentStopped\"";
$JVS::Content::Type::eventTarget[5] = "\"Client\"";
$JVS::Content::Type::eventOutput[5] = "\"CenterPrint\"";
$JVS::Content::Type::eventParameterCount[5] = 2;
$JVS::Content::Type::eventParameter[5 @ "_" @ 0] = "\"You reset the trap.\"";
$JVS::Content::Type::eventParameter[5 @ "_" @ 1] = 2;

$JVS::Content::Type::eventEnabled[6] = 1;
$JVS::Content::Type::eventDelay[6] = 0;
$JVS::Content::Type::eventInput[6] = "\"onContentStart\"";
$JVS::Content::Type::eventTarget[6] = "\"Self\"";
$JVS::Content::Type::eventOutput[6] = "\"toggleEventEnabled\"";
$JVS::Content::Type::eventParameterCount[6] = 1;
$JVS::Content::Type::eventParameter[6 @ "_" @ 0] = "\"0 3 13 14 15\"";

$JVS::Content::Type::eventEnabled[7] = 1;
$JVS::Content::Type::eventDelay[7] = 0;
$JVS::Content::Type::eventInput[7] = "\"onContentStopped\"";
$JVS::Content::Type::eventTarget[7] = "\"Self\"";
$JVS::Content::Type::eventOutput[7] = "\"toggleEventEnabled\"";
$JVS::Content::Type::eventParameterCount[7] = 1;
$JVS::Content::Type::eventParameter[7 @ "_" @ 0] = "\"0 3 13 14 15\"";

$JVS::Content::Type::eventEnabled[8] = 1;
$JVS::Content::Type::eventDelay[8] = 0;
$JVS::Content::Type::eventInput[8] = "\"onContentRestricted\"";
$JVS::Content::Type::eventTarget[8] = "\"Client\"";
$JVS::Content::Type::eventOutput[8] = "\"CenterPrint\"";
$JVS::Content::Type::eventParameterCount[8] = 2;
$JVS::Content::Type::eventParameter[8 @ "_" @ 0] = "\"You are not permitted to operate this trap.\"";
$JVS::Content::Type::eventParameter[8 @ "_" @ 1] = 2;

$JVS::Content::Type::eventEnabled[9] = 1;
$JVS::Content::Type::eventDelay[9] = 0;
$JVS::Content::Type::eventInput[9] = "\"onContentRestricted\"";
$JVS::Content::Type::eventTarget[9] = "\"Self\"";
$JVS::Content::Type::eventOutput[9] = "\"playSound\"";
$JVS::Content::Type::eventParameterCount[9] = 1;
$JVS::Content::Type::eventParameter[9 @ "_" @ 0] = "\"contentError\"";

$JVS::Content::Type::eventEnabled[10] = 1;
$JVS::Content::Type::eventDelay[10] = 0;
$JVS::Content::Type::eventInput[10] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[10] = "\"Self\"";
$JVS::Content::Type::eventOutput[10] = "\"setColliding\"";
$JVS::Content::Type::eventParameterCount[10] = 1;
$JVS::Content::Type::eventParameter[10 @ "_" @ 0] = 1;

$JVS::Content::Type::eventEnabled[11] = 1;
$JVS::Content::Type::eventDelay[11] = 0;
$JVS::Content::Type::eventInput[11] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[11] = "\"Self\"";
$JVS::Content::Type::eventOutput[11] = "\"setRaycasting\"";
$JVS::Content::Type::eventParameterCount[11] = 1;
$JVS::Content::Type::eventParameter[11 @ "_" @ 0] = 1;

$JVS::Content::Type::eventEnabled[12] = 1;
$JVS::Content::Type::eventDelay[12] = 0;
$JVS::Content::Type::eventInput[12] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[12] = "\"Self\"";
$JVS::Content::Type::eventOutput[12] = "\"setRendering\"";
$JVS::Content::Type::eventParameterCount[12] = 1;
$JVS::Content::Type::eventParameter[12 @ "_" @ 0] = 0;

$JVS::Content::Type::eventEnabled[13] = 0;
$JVS::Content::Type::eventDelay[13] = 33;
$JVS::Content::Type::eventInput[13] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[13] = "\"Self\"";
$JVS::Content::Type::eventOutput[13] = "\"contentStart\"";
$JVS::Content::Type::eventParameterCount[13] = 2;
$JVS::Content::Type::eventParameter[13 @ "_" @ 0] = 0;
$JVS::Content::Type::eventParameter[13 @ "_" @ 1] = 0;

$JVS::Content::Type::eventEnabled[14] = 1;
$JVS::Content::Type::eventDelay[14] = 0;
$JVS::Content::Type::eventInput[14] = "\"onPlayerTouch\"";
$JVS::Content::Type::eventTarget[14] = "\"Player\"";
$JVS::Content::Type::eventOutput[14] = "\"Addhealth\"";
$JVS::Content::Type::eventParameterCount[14] = 1;
$JVS::Content::Type::eventParameter[14 @ "_" @ 0] = -25;

$JVS::Content::Type::eventEnabled[15] = 0;
$JVS::Content::Type::eventDelay[15] = 0;
$JVS::Content::Type::eventInput[15] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[15] = "\"Self\"";
$JVS::Content::Type::eventOutput[15] = "\"toggleEventEnabled\"";
$JVS::Content::Type::eventParameterCount[15] = 1;
$JVS::Content::Type::eventParameter[15 @ "_" @ 0] = "\"0 3 13 14 15\"";

$JVS::Content::Type::eventEnabled[16] = 1;
$JVS::Content::Type::eventDelay[16] = 0;
$JVS::Content::Type::eventInput[16] = "\"onProjectileHit\"";
$JVS::Content::Type::eventTarget[16] = "\"Self\"";
$JVS::Content::Type::eventOutput[16] = "\"ContentStart\"";
$JVS::Content::Type::eventParameterCount[16] = 2;
$JVS::Content::Type::eventParameter[16 @ "_" @ 0] = 0;
$JVS::Content::Type::eventParameter[16 @ "_" @ 1] = 0;

$JVS::Content::Type::nodeCount = 4;
$JVS::Content::Type::nodeColor0 = color;
$JVS::Content::Type::nodeColor1 = "black25";
$JVS::Content::Type::nodeColor2 = "color";
$JVS::Content::Type::nodeColor3 = "color";
$JVS::Content::Type::nodeName0 = "trigger";
$JVS::Content::Type::nodeName1 = "spikes";
$JVS::Content::Type::nodeName2 = "clamps";
$JVS::Content::Type::nodeName3 = "frame";
$JVS::Content::Type::soundDelayStart = 0;
$JVS::Content::Type::soundDelayStop = 0;
$JVS::Content::Type::uiName = "Bear Trap";
