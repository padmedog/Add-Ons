//Mute - Made by Clay Hanson BLID 15144
//Variables
$MuteAddon::MuteTime = 60000; //Default 60000 (60 seconds)
//Scripts
function TLActionTogMute() {
	if(!isObject(TLSL_CurrentClient())) {
		TL_Error("TLActionMute :: Select a client first.");
		return 0;
	}
	%cl = TLSL_CurrentClient();
	if($MuteAddon::ClientMuted[%cl.bl_id] != 0) {
		$MuteAddon::ClientMuted[%cl.bl_id] = 1;
		schedule($MuteAddon::MuteTime,0,TLActionUnMute,%cl);
		messageclient(%cl,'',"\c6You have been muted for \c0"@$MuteAddon::MuteTime@"\c6ms.");
		messageboxok("Success","You have muted "@%cl.name@".");
		TL_echo("Muted "@%cl.name@" (ID "@%cl.bl_id@") for "@$MuteAddon::MuteTime@"ms.");
	} else {
		messageclient(%cl,'',"\c6You were unmuted.");
		messageboxok("Success","You have unmuted "@%cl.name@".");
		TLActionUnMute(%cl);
		TL_echo("Un-muted "@%cl.name@" (ID "@%cl.bl_id@").");
	}
}
function TLActionUnMute(%cl) {
	if(!isObject(%cl)) {
		TL_Error("TLActionUnMute :: The client provided does not exist.");
		return 0;
	}
	if($MuteAddon::ClientMuted[%cl.bl_id] == 1) {
		$MuteAddon::ClientMuted[%cl.bl_id] = 0;
		messageclient(%cl,'',"\c6You are no longer muted.");
	}
}
package MuteAddon {
	function gameConnection::AutoAdminCheck(%client) {
		if($MuteAddon::ClientMuted[%client.bl_id] == 1) {
			messageall('MsgAdminForce',"\c3"@%client.name@"\c2 (ID "@%client.bl_id@") was permanently muted for attempting to avoid a mute!");
		}
		return parent::AutoAdminCheck(%client);
	}
	function servercmdmessagesent(%cl,%msg) {
		if($MuteAddon::ClientMuted[%cl.bl_id] == 1) {
			messageclient(%cl,'',"\c6You are currently muted.");
		} else {
			return parent::servercmdmessagesent(%cl,%msg);
		}
	}
	function servercmdteammessagesent(%cl,%msg) {
		if($MuteAddon::ClientMuted[%cl.bl_id] == 1) {
			messageclient(%cl,'',"\c6You are currently muted.");
		} else {
			return parent::servercmdmessagesent(%cl,%msg);
		}
	}
};
activatepackage(MuteAddon);
//Add to server actions
TLS_AddServerAction("Tog Mute","TLActionTogMute");
//END SCRIPT