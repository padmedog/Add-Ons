%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_DoorsPack0: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/Content_PackerDoors/types/CastleGate.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_PackerDoors/types/SpaceHangarTop.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_PackerDoors/types/SpaceHangarBottom.cs");
}