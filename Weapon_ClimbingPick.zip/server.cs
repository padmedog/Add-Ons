//Climbing Pick
//Lets you climb and jump off things.

ForceRequiredAddon("Weapon_Sword");
//I'm not including that copy-pasted if-statement clusterfuck.
//There's no reason they shouldn't have the sword, and the hack for hiding it if they disabled it is painful to look at.

datablock AudioProfile(ClimbingPickHitSound)
{
	filename    = "./blade_cut.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(ClimbingPickPullSound)
{
	filename    = "./blade_in.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock ExplosionData(ClimbingPickMissExplosion : swordExplosion)
{
	soundProfile	= swordHitSound;
	
	particleEmitter	= swordExplosionEmitter;
	particleDensity	= 6;
	particleRadius	= 0.2;
	
	lightStartColor	= "0 0 0"; //No idea why the sword emits blue light.
};

datablock ProjectileData(ClimbingPickMissProjectile)
{
	directDamage		= 55;
	directDamageType	= $DamageType::Sword;
	radiusDamageType	= $DamageType::Sword;
	explosion			= ClimbingPickMissExplosion;
	
	muzzleVelocity		= 50;
	velInheritFactor	= 0;
	
	armingDelay			= 0;
	lifetime			= 130;
	fadeDelay			= 70;
	bounceElasticity	= 0;
	bounceFriction		= 0;
	isBallistic			= false;
	gravityMod			= 0.0;
	
	hasLight	= false;
	lightRadius	= 3.0;
	lightColor	= "0 0 0.5";
};

datablock ExplosionData(ClimbingPickHitExplosion : swordExplosion)
{
	soundProfile	= ClimbingPickHitSound;
	
	particleEmitter	= swordExplosionEmitter;
	particleDensity	= 12;
	particleRadius	= 0.2;
	
	lightStartColor	= "0 0 0";
};

datablock ProjectileData(ClimbingPickHitProjectile)
{
	directDamage		= 0;
	directDamageType	= $DamageType::Sword;
	radiusDamageType	= $DamageType::Sword;
	explosion			= ClimbingPickHitExplosion;
	explodeOnDeath		= true;
	
	muzzleVelocity		= 0;
	velInheritFactor	= 0;
	
	armingDelay			= 0;
	lifetime			= 1;
	fadeDelay			= 0;
	bounceElasticity	= 0;
	bounceFriction		= 0;
	isBallistic			= false;
	gravityMod			= 0.0;
	
	hasLight	= false;
	lightRadius	= 3.0;
	lightColor	= "0 0 0.5";
};

datablock ItemData(ClimbingPickItem)
{
	category	= "Weapon";
	className	= "Weapon";

	shapeFile	= "./ClimbingPick.dts";
	mass		= 1;
	density		= 0.2;
	elasticity	= 0.2;
	friction	= 0.6;
	emap		= true;

	uiName			= "Climbing Pick";
	iconName		= "./Icon_ClimbingPick";
	doColorShift	= false;
	colorShiftColor	= "0.7 0.7 0.0 1.000";
	image			= ClimbingPickImage;
	canDrop			= true;
};

datablock ShapeBaseImageData(ClimbingPickImage)
{
	shapeFile	= "./ClimbingPick.dts";
	emap		= true;
	
	mountPoint			= 0;
	offset				= "0 0 0";
	eyeOffset			= 0;
	rotation			= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	
	className	= "WeaponImage";
	
	item			= ClimbingPickItem;
	ammo			= " ";
	projectile		= ClimbingPickMissProjectile;
	projectileType	= Projectile;
	
	melee		= true;
	armReady	= true;
	
	doColorShift	= false;
	colorShiftColor	= ClimbingPickItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.15;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSound[0]				= weaponSwitchSound;

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Wait";
	stateTimeoutValue[2]		= 0.14;
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "Fire";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;

	stateName[3]				= "Wait";
	stateTransitionOnTimeout[3]	= "Reload";
	stateTimeoutValue[3]		= 0.05;
	stateTransitionOnAmmo[3]	= "Wait";
	stateWaitForTimeout[3]		= true;
	stateScript[3]				= "onWait";
	
	stateName[4]				= "Reload";
	stateTransitionOnTimeout[4]	= "Ready";
	stateTimeoutValue[4]		= 0.3;
};


function ClimbingPickImage::onFire(%this, %obj, %slot)
{
	//First, we perform a raycast to determine if they're looking at something climbable.
	%start = %obj.getEyePoint();
	%masks = $TypeMasks::FxBrickObjectType | $TypeMasks::GameBaseObjectType | $TypeMasks::TerrainObjectType; //Types of objects we can hit: Bricks, terrain (the ground plane), and GameBase objects (superclass of vehicles, players, other important stuff)
	%scale = getWord(%obj.getScale(), 2); 
	%dir = %obj.getEyeVector();
	%rayCast = containerRayCast(%start, vectorAdd(%start, vectorScale(%dir, 6 * %scale)), %masks, %obj);
	
	%col = firstWord(%rayCast);
	%pos = posFromRaycast(%rayCast);
	%norm = normalFromRaycast(%rayCast);
	if(getSimTime() < %obj.climbPickWait //If they've used the pick recently...
	 || !isObject(%col) //Or if they hit nothing...
	 || !(%col.getType() & $TypeMasks::FxBrickObjectType) //Or if they haven't struck a brick...
	 || $ClimbingPick::Challenge && %col.getColorID() == $ClimbingPick::NoClimbColorID //Or if they hit an unclimbable wall in challenge mode...
	 || getWord(%pos, 2) < getWord(%obj.getPosition(), 2) && %norm !$= "0 0 1" && getWord(%obj.getVelocity(), 2) == 0) //Or if they hit something below them, other than a floor when not moving vertically...
	{
		%obj.playThread(2, shiftTo);
		%obj.setImageAmmo(%slot, false);
		if(isObject(%col) && getSimTime() >= %obj.climbPickWait) //Prevents rare case where raycast misses but projectile hits, resulting in more yelling at me.
			return Parent::onFire(%this, %obj, %slot); //Swing normally and fire a standard projectile.
		return;
	}
	
	if(%norm $= "0 0 1" && %col.isColliding()) //If they hit a floor...
	{
		if(vectorLen(getWords(%obj.getVelocity(), 0, 1)) <= 15)  //And they're not moving fast horizontally...
		{
			%obj.playThread(2, shiftTo);
			%obj.setImageAmmo(%slot, false);
			return Parent::onFire(%this, %obj, %slot); //Leave the function normally.
		}
		else if(getWord(%pos, 2) < getWord(%obj.getPosition(), 2)) //Otherwise... (as long as the floor is below them - if it's not then they're probably just trying to grab a ledge)
		{
			%obj.setVelocity("0 0" SPC (getWord(%obj.getVelocity(), 2))); //Stop their horizontal velocity. They can use this to save themselves from impact damage.
			%projectile = new projectile() //Act as if it hit, though don't actually attach them.
			{
				dataBlock       = ClimbingPickHitProjectile;
				initialVelocity = "0 0 0";
				initialPosition = %pos;
				sourceObject    = %obj;
				sourceSlot      = %slot;
				client          = %client;
			};
			%projectile.setScale(%scale SPC %scale SPC %scale);
			%obj.playThread(2, shiftTo);
			%obj.setImageAmmo(%slot, false);
			return;
		}
	}
	
	%obj.playThread(2, shiftAway);
	%obj.schedule(200, playThread, 2, shiftTo); //Use both animations scheduled in sequence to get a more powerful looking swing for embedding into walls.
	%obj.setImageAmmo(%slot, true); //The image uses ammo to determine whether we're attached or not.
	
	%vel = vectorScale(vectorSub(%pos, %obj.getPosition()), 5); //Nudge them before connecting them to keep them from floating in mid-air. (Disclaimer: May still float in mid-air)
	if(getWord(%vel, 2) > 0)
		%vel = setWord(%vel, 2, getWord(%vel, 2) * 0.66); //Dampen vertical impulse to prevent people flinging themselves up a wall.
	%obj.setVelocity(%vel);
	%this.schedule(200, onHook, %obj, %slot, %col, %pos, %norm);
}

function ClimbingPickImage::onHook(%this, %obj, %slot, %col, %pos, %norm)
{
	if(%obj.isDisabled()) //In case they died between swinging and attaching.
		return;
	%client = %obj.client;
	%scale = getWord(%obj.getScale(), 2);
	%projectile = new projectile()
	{
		dataBlock       = ClimbingPickHitProjectile;
		initialVelocity = "0 0 0";
		initialPosition = %pos;
		sourceObject    = %obj;
		sourceSlot      = %slot;
		client          = %client;
	};
	%projectile.setScale(%scale SPC %scale SPC %scale);
	
	if(isObject(%obj.climbPickZone)) //Improbable case. Don't want to risk having a stray no-movement zone around, though.
	{
		%obj.climbPickZone.setTransform(vectorAdd(%obj.getTransform(), "0 0 0.5"));
		return;
	}
	
	if($ClimbingPick::Challenge && %col.getColorFXID() == $ClimbingPick::AutoSwingFXID) //For the climbing challenge: Automatically launch players if they hit a brick with this effect.
	{
		%data = %obj.getDatablock(); //This stuff is copied from the jump in onTrigger. Read up on it there.
		%scale = getWord(%obj.getScale(), 2);
		%scaleTime = (%data.jumpForce / playerStandardArmor.jumpForce) * %scale;
		
		%angle = %obj.getEyeVector();
		%vel = vectorScale(%angle, %data.jumpForce * 1.5 * %scale  / %data.mass);

		%obj.schedule(0, setVelocity, %vel);
		
		%obj.setImageAmmo(%imgSlot, false);
		
		%obj.playAudio(0, WrenchMissSound);
		return;
	}
	
	%obj.setVelocity("0 0 0");
	%leapVector = vectorNormalize(setWord(%norm, 2, 0.001)); //Allow for horizontal leaping off the wall. Last bit prevents odd behavior when hooked to a floor or ceiling.
	if(!%col.isColliding() || %leapVector $= "0 0 1") //Allow swinging off noncolliding objects or ceilings.
		%leapVector = 2; //Understood later as any direction.
	%zonePos = %obj.getWorldBoxCenter();
	%zonePos = vectorAdd(%zonePos, "0 0" SPC (getWord(%obj.getObjectBox(), 5) / -2 - 0.09)); //PhysicalZones only recognise when their edge is very close to another object's edge, so we position the thing just under the player's feet.
	%obj.climbPickZone = new PhysicalZone() //A physicalzone is employed to prevent movement. It is kept small to hopefully prevent any other players intersecting it, but I can't confirm this will work for all sizes.
	{
		position = %zonePos;
		scale = "0.1 0.1 0.1";
		velocityMod = 0;
		gravityMod = 0;
		extraDrag = 31; //Prevents almost all player movement for the default datablock.
		polyhedron = "0 0 0 1 0 0 0 -1 0 0 0 1";
		imageSlot = %slot; //For detaching later.
		leapVector = %leapVector;
		targetBrick = %col;
		soundPos = %pos; //For playing the disconnect sound.
	};
	%obj.climbPickZone.activate(); //Doubt this does anything. Can't hurt, though.
	
	%col.onPickAttach(%obj); //Call the input event function.
}

function ClimbingPickImage::detach(%this, %obj, %slot) //This is used only when detaching normally. Teleporting away, dying, ect., will not call this.
{
	%obj.playThread(2, shiftAway);
	serverPlay3d(ClimbingPickPullSound, %obj.climbPickZone.soundPos);
	if(isObject(%obj.climbPickZone))
	{
		if(isObject(%obj.climbPickZone.targetBrick))
			%obj.climbPickZone.targetBrick.onPickDetach(%obj);
		%obj.climbPickZone.delete();
	}
}

function ClimbingPickImage::onWait(%this, %obj, %slot) //Called repeatedly by the image while attached.
{
	if(isObject(%obj.climbPickZone))
	{
		if(vectorDist(%obj.getPosition(), %obj.climbPickZone.getPosition()) > 5) //If we've somehow moved away from the zone, delete it.
		{
			%obj.setImageAmmo(%slot, false);
			%obj.climbPickZone.delete();
			return;
		}
		%brick = %obj.climbPickZone.targetBrick;
		if(!isObject(%brick) || !%brick.isRaycasting() || %brick.isFakeDead()) //If the brick they attached to no longer raycasts, detach them.
		{
			%obj.setImageAmmo(%slot, false);
			%obj.climbPickZone.delete();
			return;
		}
	}
}

function ClimbingPickImage::onUnmount(%this, %obj, %slot)
{
	if(isObject(%obj.climbPickZone))
		%this.detach(%obj, %slot); //Disconnect the hook when it's put away.
	if(%obj.climbPickWait < getSimTime() + 700)
		%obj.climbPickWait = getSimTime() + 700; //Prevents Q-Q spamming. Using an if statement because the delay is longer when jumping.
}

package ClimbingPick
{
	function Player::applyImpulse(%this, %force, %pos)
	{
		if(isObject(%this.climbPickZone)) //Used to keep stuff like explosions from knocking players out of the physicalzone.
			return;
		parent::ApplyImpulse(%this, %force, %pos);
	}
	
	function armor::onRemove(%this, %obj)
	{
		if(isObject(%obj.climbPickZone)) //If they leave the server or something while hanging.
			%obj.climbPickZone.delete();
		parent::onRemove(%this, %obj);
	}
	
	function armor::onDisabled(%this, %obj, %lastState)
	{
		parent::onDisabled(%this, %obj, %lastState);
		if(isObject(%obj.climbPickZone)) //If they died while hooked.
			%obj.climbPickZone.delete();
	}
	
	function armor::onTrigger(%this, %obj, %slot, %val)
	{
		if(!isObject(%obj.climbPickZone) || %val == 0)
			return Parent::onTrigger(%this, %obj, %slot, %val);
		%obj.pickDetach(%slot == 2); //Slot 2 is the jump trigger.
	}
};
activatePackage(ClimbingPick);

//Event stuff.
function fxDTSBrick::onPickAttach(%this, %player)
{
	$InputTarget_["Self"]		= %this;
	$InputTarget_["Player"]		= %player;
	$InputTarget_["Client"]		= %player.client;
	$InputTarget_["MiniGame"]	= getMiniGameFromObject(%player);
	%this.processInputEvent("onPickAttach", %player.client);
}

function fxDTSBrick::onPickDetach(%this, %player)
{
	$InputTarget_["Self"]		= %this;
	$InputTarget_["Player"]		= %player;
	$InputTarget_["Client"]		= %player.client;
	$InputTarget_["MiniGame"]	= getMiniGameFromObject(%player);
	%this.processInputEvent("onPickDetach", %player.client);
}

function fxDTSBrick::onPickLeap(%this, %player)
{
	$InputTarget_["Self"]		= %this;
	$InputTarget_["Player"]		= %player;
	$InputTarget_["Client"]		= %player.client;
	$InputTarget_["MiniGame"]	= getMiniGameFromObject(%player);
	%this.processInputEvent("onPickLeap", %player.client);
}

function Player::pickDetach(%this, %jump)
{
	if(!isObject(%this.climbPickZone))
		return;
	%imgSlot = %this.climbPickZone.imageSlot; //Honestly most people never even consider mounting images in other slots in Blockland, hardcoding everything. I'd prefer to leave some groundwork in in case someone wants to make something cool with it.
	%leapVector = %this.climbPickZone.leapVector;
	%brick = %this.climbPickZone.targetBrick; //Retrieve the values stored earlier.
	ClimbingPickImage.detach(%this, %imgSlot);
	if(%jump)
	{
		%data = %this.getDatablock();
		%scale = getWord(%this.getScale(), 2);
		%scaleTime = (%data.jumpForce / playerStandardArmor.jumpForce) * %scale; //Scale the cooldown so players with high jump height still function similarly.
		
		%lookVector = %this.getEyeVector();
		%lookVectorXY = vectorNormalize(getWords(%lookVector, 0, 1)); //Only concerned with the horizontal look vector.
		if(%leapVector == 2 || vectorDot(%lookVectorXY, %leapVector) > 0.707) //If they're looking away from their leap vector...
			%angle = %lookVector; //Jump in the direction they're looking.
		else
			%angle = "0 0 1"; //Otherwise jump up like normal.
		%vel = vectorScale(%angle, %data.jumpForce * 1.5 * %scale  / %data.mass); //Apply our magnitude to the force, calculated in the second parameter.
		if($ClimbingPick::Challenge && %brick.getColorFXID() == $ClimbingPick::SuperFlingFXID) //For the climbing challenge - launches the player further if attached to a brick with this fx.
		{
			%vel = vectorScale(%vel, 2);
			%this.playAudio(0, RocketFireSound);
		}
		else //Apparently torque doesn't like playing two sounds like this at once, so we just if/else it.
			%this.playAudio(0, %data.JumpSound);
		%this.schedule(0, setVelocity, %vel); //Needs to happen after the physicalZone has been properly cleaned up, so we schedule it.
		
		if(getWord(%angle, 2) > 0.8 && %leapvector != 2) //If they're primarily moving up
		{
			%this.schedule(1700 * %scaleTime, setImageAmmo, %imgSlot, false); //Extend the time until they can use it again.
			if(%this.climbPickWait < getSimTime() + 1700 * %scaleTime)
				%this.climbPickWait = getSimTime() + 1700 * %scaleTime;
		}
		else //Otherwise they can use it again immediately.
			%this.setImageAmmo(%imgSlot, false);
		
		%brick.onPickLeap(%this); //Call the event.
		
		if(%leapVector != 2)
			%this.playThread(2, activate2); //Little climbing animation if they're not on an omnidirectional jumping brick.
	}
	else
	{
		%data = %this.getDatablock();
		%scale = getWord(%this.getScale(), 2);
		%scaleTime = (%data.jumpForce / playerStandardArmor.jumpForce) * %scale;
		
		%this.schedule(600 * %scaleTime, setImageAmmo, %imgSlot, false);
		if(%this.climbPickWait < getSimTime() + 600 * %scaleTime)
			%this.climbPickWait = getSimTime() + 600 * %scaleTime;
	}
}

registerInputEvent("fxDTSBrick", "onPickAttach", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerInputEvent("fxDTSBrick", "onPickDetach", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerInputEvent("fxDTSBrick", "onPickLeap", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerOutputEvent(Player, "pickDetach", "bool");
 
//Preferences for the climbing pick challenge. Use however you like.
//These have been moved to Gamemode_Climbing_Challenge. They can be uncommented here to apply without a gamemode, however, loading the gamemode as a custom add-on will also apply them with these values.
//$ClimbingPick::Challenge = true;
//$ClimbingPick::NoClimbColorID = 36; //Could set these to -1 to disable.
//$ClimbingPick::SuperFlingFXID = 5; //Bricks using this color FX will fling players super far if they jump off them.
//$ClimbingPick::AutoSwingFXID = 4; //Bricks using this color FX will swing players off them as soon as they attach to it.