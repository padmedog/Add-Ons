//gun.cs

datablock AudioProfile(quakeRailgunFireSound)
{
   filename    = "./railgun.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(quakeRailgunFireParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 290;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/star1";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "1 1 1 0.02";
    colors[1]     = "1 0 0 0.07";
    colors[2]     = "1 0 0 0.05";
    colors[3]     = "1 0 0 0.0";

    sizes[0]      = 0.25;
   sizes[1]      = 2.25;
    sizes[2]      = 0.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(quakeRailgunFireEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 94.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "quakeRailgunFireParticle";
};

datablock ExplosionData(quakeRailgunExplosion : quakeRocketExplosion)
{
   //explosionShape = "";

   damageRadius = 5;
   radiusDamage = 20;

   impulseRadius = 6;
   impulseForce = 2500;
};
AddDamageType("quakeRailgun",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_railgun> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_railgun> %1',0.2,1);

datablock ProjectileData(RaycastModelLaserProjectile : gunProjectile)
{
   projectileShapeName = "./getter_beam.dts";
   explosion           = quakeRailgunExplosion;
};


function drawRaylinequakeRailgun(%pos1, %pos2)
{
	//should be the dimensions of the model in torque units
	%modelwidth = 0.08 -getRandom(1,10)*0.001;
	%modeldepth = 0.08 -getRandom(1,10)*0.001;
	%modelheight = 1.6 -getRandom(1,10)*0.01;
	
	if(isObject($lastShape))
		$lastShape.delete();

	//find the point halfway between the two points, this will be our position
	%point = vectorAdd(vectorScale(vectorSub(%pos2, %pos1), 0.5), %pos1);
	
	//rotation
	%xRot = 0;
	
	//mAtan(z/len(x and y))
	%yRot = 90 - mRadToDeg(mAtan(getWord(%pos2, 2) - getWord(%pos1, 2), vectorLen(vectorSub(getWords(%pos2, 0, 1), getWords(%pos1, 0, 1)))));
	//%yRot = 90;
	
	//mAtan(x/y)
	%zRot = mRadToDeg(mAtan(getWord(%pos2, 1) - getWord(%pos1, 1), getWord(%pos2, 0) - getWord(%pos1, 0)));
	
	%rot = eulerToAxis(%xRot SPC %yRot SPC %zRot);
	
	//scaling
	%width = 0.3 / %modelWidth;
	%depth = 0.3 / %modeldepth;
	%height = vectorLen(vectorSub(%pos2, %pos1)) / %modelheight;
	
	
	//create it
	%shape = new TSStatic() {
		shapeName = "add-ons/weapon_package_quaketype/getter_beam.dts";
	};
	
	%shape.setTransform(%point SPC %rot);
	%shape.setScale(%width SPC %depth SPC %height);
	
	$lastShape = %shape;
	
	return %shape;
}


function drawRaylinequakeRailgun2(%pos1, %pos2)
{
	//should be the dimensions of the model in torque units
	%modelwidth = 0.5;
	%modeldepth = 0.5;
	%modelheight = 1.6 +getRandom(1,10)*0.01;
	
	if(isObject($lastShape))
		$lastShape.delete();

	//find the point halfway between the two points, this will be our position
	%point = vectorAdd(vectorScale(vectorSub(%pos2, %pos1), 0.5), %pos1);
	
	//rotation
	%xRot = 0;
	
	//mAtan(z/len(x and y))
	%yRot = 90 - mRadToDeg(mAtan(getWord(%pos2, 2) - getWord(%pos1, 2), vectorLen(vectorSub(getWords(%pos2, 0, 1), getWords(%pos1, 0, 1)))));
	//%yRot = 90;
	
	//mAtan(x/y)
	%zRot = mRadToDeg(mAtan(getWord(%pos2, 1) - getWord(%pos1, 1), getWord(%pos2, 0) - getWord(%pos1, 0)));
	
	%rot = eulerToAxis(%xRot SPC %yRot SPC %zRot);
	
	//scaling
	%width = 0.3 / %modelWidth;
	%depth = 0.3 / %modeldepth;
	%height = vectorLen(vectorSub(%pos2, %pos1)) / %modelheight;
	
	
	//create it
	%shape = new TSStatic() {
		shapeName = "add-ons/weapon_package_quaketype/getter_beam.dts";
	};
	
	%shape.setTransform(%point SPC %rot);
	%shape.setScale(%width SPC %depth SPC %height);
	
	$lastShape = %shape;
	
	return %shape;
}


//////////
// item //
//////////
datablock ItemData(quakeRailgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./quake_railgun_alternate.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Railgun";
	iconName = "./railgun";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.75 1.000";

	 // Dynamic properties defined by the scripts
	image = quakeRailgunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(quakeRailgunImage)
{
   // Basic Item properties
	shapeFile = "./quake_railgun_alternate.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = quakeRailgunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 100; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = RaycastModelLaserProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 60; //10
   raycastDirectDamageType = $DamageType::quakeRailgun;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.7;
	stateScript[0]                  = "onActivate";
	stateTransitionOnTimeout[0]       = "Ready";
	stateSequence[0]	= "Forward";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Prefire";
	stateAllowImageChange[1]         = true;
	stateWaitForTimeout[1]			= false;
	stateTransitionOnTimeout[1]     = "Ready";
	stateTimeoutValue[1]            = 0.9;
	stateSequence[1]	= "idle";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "AfterbeamA";
	stateTimeoutValue[2]            = 0.02;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Backward";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakeRailgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= quakeRailgunFireSound;

	stateName[3] = "AfterbeamA";
	stateEmitter[3]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[3]				= 0.02;
	stateSequence[3]                = "Backward";
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateScript[3]                  = "onAfterbeam";
	stateTransitionOnTimeout[3]     = "AfterbeamB";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Forward";
	stateTimeoutValue[4]            = 1.4;
	stateScript[4]                  = "onReload";
	stateTransitionOnTimeout[4]     = "Ready";

	stateName[5] = "Prefire";
	stateSequence[5]	= "Forward";
	stateTimeoutValue[5]            = 0.02;
	stateScript[5]                  = "onBoltback";
	stateTransitionOnTimeout[5]     = "Fire";
	stateTransitionOnTriggerUp[5]     = "Ready";

	stateName[6] = "AfterbeamB";
	stateEmitter[6]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[6]				= 0.02;
	stateSequence[6]                = "Backward";
	stateEmitterNode[6]				= "muzzleNode";
	stateScript[6]                  = "onAfterbeam2";
	stateTimeoutValue[6]            = 0.02;
	stateTransitionOnTimeout[6]     = "Reload";
};

function quakeRailgunImage::onActivate(%this,%obj,%slot)
{
	%obj.playThread(2, shiftright);	
}

function quakeRailgunImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;	
	%obj.playThread(2, shiftLeft);
	%obj.playThread(0, shiftRight);
	
	Parent::onFire(%this,%obj,%slot);

	////////////////////////////////////////////////////
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylinequakeRailgun(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylinequakeRailgun(%start, %end);
	}
	%line.schedule(90, delete);
}

function quakeRailgunImage::onAfterbeam(%this,%obj,%slot)
{
	%obj.playThread(0, plant);	
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylinequakeRailgun(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylinequakeRailgun(%start, %end);
	}
	%line.schedule(90, delete);
}

function quakeRailgunImage::onAfterbeam2(%this,%obj,%slot)
{
	%obj.playThread(0, plant);	
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylinequakeRailgun2(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylinequakeRailgun2(%start, %end);
	}
	%line.schedule(90, delete);
}
