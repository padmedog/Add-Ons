%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_PlungerSwitch: JVS_Content is missing and is required for this Add-On to work.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_PlungerSwitch/types/VerticalPlunger.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_PlungerSwitch/types/HorizontalPlunger.cs");
}
