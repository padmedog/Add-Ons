datablock AudioProfile(JNG90FireSound)
{
   filename    = "./JNG90Fire.wav";
   description = LongRange3d;
   preload = true;
};
datablock ProjectileData(JNG90Projectile)
{
	directDamage		= 45;
	gravityMod			= 0.9;
	muzzleVelocity		= 1;
	brickExplosionForce	= 10;
	impactImpulse		= 300;
	verticalImpulse		= 200;
	lifetime			= 10000;
	fadeDelay			= 8000;

	radiusDamage		= 0;
	damageRadius		= 0;
	projectileShapeName	= "base/data/shapes/empty.dts";
	directDamageType	= $DamageType::UniversalHeadshot;
	radiusDamageType	= $DamageType::UniversalHeadshot;
	brickExplosionRadius			= 0;
	brickExplosionImpact			= true;
	brickExplosionMaxVolume			= 3;
	brickExplosionMaxVolumeFloating	= 10;
	explosion			= GBImpact2Explosion;
	sound				= BulletWhizzingSound;
	velInheritFactor	= 0;
	armingDelay			= 10;
	bounceElasticity	= 0.5;
	bounceFriction		= 0.1;
	isBallistic			= true;
	hasLight			= false;
	lightRadius			= 3.0;
	lightColor			= "0 0 0";
};
function JNG90Projectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	%damageType = $DamageType::Direct;
	if(%this.DirectDamageType)
	{
		%damageType = %this.DirectDamageType;
	}
	%scale = getWord(%obj.getScale(), 2);
	%directDamage = 40*5;
	%damage = %directDamage;
	%sobj = %obj.sourceObject;
	if(%col.getType() & $TypeMasks::PlayerObjectType)
	{
		%directDamage = 45;
		%colscale = getWord(%col.getScale(),2);
		if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale && $BKT::HS)
		{
			%directDamage = 250;
			%damageType = $DamageType::UniversalHeadshot;
		}
		%col.damage(%obj, %pos, %directDamage, %damageType);
	}
	else
	{
		%col.damage(%obj,%pos,%directDamage,%damageType);
	}
}
package JNG90psm
{
	function Projectile::onAdd(%obj,%a,%b)
	{
		if(%obj.dataBlock.getID() == JNG90Projectile.getID())
		{
			%obj.initialvelocity=vectorscale(vectorNormalize(%obj.initialvelocity),450);
		}
		Parent::onAdd(%obj,%a,%b);
	}
};
activatePackage(JNG90psm);
datablock ItemData(JNG90Item)
{
	shapeFile	= "./JNG90.dts";
	iconName	= "./icon_JNG90";
	image		= JNG90Image;
	uiName			= "Combat Sniper";
	maxAmmo			= 10;

	category		= "Weapon";
	className		= "Weapon";
	rotate			= false;
	mass			= 1;
	density			= 1.5;
	elasticity		= 0.2;
	friction		= 0.75;
	emap			= true;
	doColorShift	= true;
	colorShiftColor	= "0.2 0.2 0.21 1.000";
	canDrop			= true;
	canReload		= 1;
};
datablock ShapeBaseImageData(JNG90Image)
{
	shapeFile	= "./JNG90.dts";
	item		= JNG90Item;
	projectile	= JNG90Projectile;
	shellVelocity	= 8.0;
	shellExitDir	= "1.0 -0.0 0.5";
	minShotTime		= 850;
	eyeOffset		= "0 0 0";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= JNG90Item.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.35;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.1;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.1;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.1;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= JNG90FireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateSequence[3]			= "reload1";
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "BoltOut";
	stateTimeoutValue[3]		= 0.1;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.1;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateAllowImageChange[6]	= true;
	stateTimeoutValue[6]		= 1.4;
	stateScript[6]				= "OnReload";
	stateTransitionOnTimeout[6]	= "Reloaded";
	stateWaitForTimeout[6]		= true;
	
	stateName[7]				= "Reloaded";
	stateAllowImageChange[7]	= false;
	stateTimeoutValue[7]		= 0.4;
	stateScript[7]				= "onReloaded";
	stateTransitionOnTimeout[7]	= "FireLoadCheckA";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.4;
	stateTransitionOnTimeout[9]	= "Reload";

	stateName[10] 				= "FireLoadCheckA";
	stateScript[10]				= "onLoadCheck";
	stateAllowImageChange[10]	= false;
	stateTimeoutValue[10]		= 0.1;
	stateTransitionOnTimeout[10]	= "FireLoadCheckB";

	stateName[11]				= "FireLoadCheckB";
	stateAllowImageChange[11]	= false;
	stateTransitionOnAmmo[11]	= "BoltIn";
	stateTransitionOnNoAmmo[11]	= "ReloadWait";

	stateName[12]					= "TriggerCheck";
	stateTransitionOnTriggerUp[12]	= "FireLoadCheckA";

	stateName[13]					= "BoltIn";
	stateSequence[13]				= "reload2";
	stateTransitionOnTimeout[13]	= "Ready";
	stateTimeoutValue[13]			= 0.15;
	stateSound[13]					= BoltInSound;

	stateName[14]					= "BoltOut";
	stateAllowImageChange[14]		= false;
	stateTimeoutValue[14]			= 0.3;
	stateTransitionOnTimeout[14]	= "TriggerCheck";
	stateScript[14]					= "Bolt";
	stateSound[14]					= BoltOutSound;
};
function JNG90Image::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
}
function JNG90ADSImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::CH)
	{
		crossHair.setBitmap("add-ons/weapon_blockombat/empty.png");
	}
}
function JNG90Image::onFire(%this,%obj,%slot)
{
	JNG90Fire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function JNG90Image::onWeaponLoop(%this,%obj,%slot)
{
	if(%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function JNG90Fire(%this,%obj,%slot,%val)
{
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%obj.client.player.getEyeVector(),"-3")));
	%projectile = JNG90Projectile;
	if(%obj.heat >= 2)
	{
		%obj.playThread(3, plant);
	}
	if(%obj.isImageMounted(JNG90Image))
	{
		if(vectorLen(%obj.getVelocity()) < 4)
		{
			%spread = 0.0029;
		}
		else
		{
			%spread = 0.00335;
		}
	}
	else if(%obj.isImageMounted(JNG90ADSImage))
	{
		if(vectorLen(%obj.getVelocity()) < 4)
		{
			%spread = 0.0000075 + (%obj.heat * 0.0002);
		}
		else
		{
			%spread = 0.00035 + (%obj.heat * 0.0002);
		}
	}
	%obj.maxHeat = 10;
	if(%obj.heat < %obj.maxHeat)
		%obj.heat += 2;
	%shellcount = 1;
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	if($BKT::Flash)
	{
		%projectile = "ATACFlashProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function JNG90Image::onReload(%this,%obj,%slot)
{
	%obj.client.quantity["762mmrounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;%obj.heat = 0;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
	if(%obj.client.quantity["762mmrounds"] >= 1)
	{
		%obj.playThread(2, shiftright);
		serverPlay3D(rifleheavymagOutSound,%obj.getPosition()); 
	}
}
function JNG90Image::onReloaded(%this,%obj,%slot)
{
	if(%obj.client.quantity["762mmrounds"] >= 1)
	{
		if(%obj.client.quantity["762mmrounds"] > %this.item.maxAmmo)
		{
			%obj.client.quantity["762mmrounds"] -= %this.item.maxAmmo;
			%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
			%obj.setImageAmmo(%slot,1);
			%obj.playThread(2, plant);
			serverPlay3D(rifleheavymagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
		}
		else if(%obj.client.quantity["762mmrounds"] <= %this.item.maxAmmo)
		{
			%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["762mmrounds"];
			%obj.setImageAmmo(%slot,1);
			%obj.client.quantity["762mmrounds"] = 0;	
			%obj.playThread(2, plant);
			serverPlay3D(rifleheavymagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
			return;
		}
	}
}
datablock ShapeBaseImageData(JNG90ADSImage)
{
	shapeFile	= "./JNG90.dts";
	item		= JNG90Item;
	projectile	= JNG90Projectile;
	shellVelocity	= 8.0;
	shellExitDir	= "1.0 -0.0 0.5";
	minShotTime		= 850;
	eyeOffset		= "0.0008 1 -1.0145";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= JNG90Item.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.2;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.1;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.1;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.1;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= JNG90FireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateSequence[3]			= "reload1";
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "BoltOut";
	stateTimeoutValue[3]		= 0.1;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.1;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateScript[6]				= "OnReload";
	
	stateName[7]				= "Reloaded";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.4;
	stateTransitionOnTimeout[9]	= "Reload";

	stateName[10] 				= "FireLoadCheckA";
	stateScript[10]				= "onLoadCheck";
	stateAllowImageChange[10]	= false;
	stateTimeoutValue[10]		= 0.1;
	stateTransitionOnTimeout[10]	= "FireLoadCheckB";

	stateName[11]				= "FireLoadCheckB";
	stateAllowImageChange[11]	= false;
	stateTransitionOnAmmo[11]	= "BoltIn";
	stateTransitionOnNoAmmo[11]	= "ReloadWait";

	stateName[12]					= "TriggerCheck";
	stateTransitionOnTriggerUp[12]	= "FireLoadCheckA";

	stateName[13]					= "BoltIn";
	stateSequence[13]				= "reload2";
	stateTransitionOnTimeout[13]	= "Ready";
	stateTimeoutValue[13]			= 0.15;
	stateSound[13]					= BoltInSound;

	stateName[14]					= "BoltOut";
	stateAllowImageChange[14]		= false;
	stateTimeoutValue[14]			= 0.3;
	stateTransitionOnTimeout[14]	= "TriggerCheck";
	stateScript[14]					= "Bolt";
	stateSound[14]					= BoltOutSound;
};
function JNG90ADSImage::onWeaponLoop(%this,%obj,%slot)
{
	if (%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function JNG90ADSImage::Bolt(%this,%obj,%slot)
{
	if($BKT::Recoil)
	{
		%projectile = "scopeBoltProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
		return %p;
	}
}
function JNG90ADSImage::onFire(%this,%obj,%slot)
{
	JNG90Fire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function JNG90ADSImage::onReload(%this,%obj,%slot)
{
	%obj.mountImage(JNG90Image,0);
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>7.62x51 Sniper  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["762mmrounds"]+0 @ "", 4, 2, 3, 4);}
}
package JNG90Sights
{
	function armor::onTrigger(%this,%obj,%triggerNum,%val)
	{
		%client = %obj.client;		
		if(%obj.getMountedImage(0) $= JNG90Image.getID() && %triggerNum == 4 && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(JNG90ADSImage, 0);
			%client.setControlCameraFov(50);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		else if(%triggerNum == 4 && %obj.getMountedImage(0) $= JNG90ADSImage.getID() && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(JNG90Image, 0);
			%client.setControlCameraFov(90);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		Parent::onTrigger(%this,%obj,%triggerNum,%val);
	}
	function servercmdDropTool(%client,%slot)
	{
		if(%client.player.getMountedImage(0) $= JNG90ADSImage.getID())
		{
		 	%client.player.unmountImage(0);
			%client.setControlCameraFov(90);
			if($BKT::CH)
			{
				crossHair.setBitmap("base/client/ui/crosshair.png");
			}
		}
		return Parent::servercmdDropTool(%client,%slot);
	}
};
activatePackage(JNG90Sights);
function JNG90ADSImage::onUnMount(%this,%obj,%slot)
{
	%obj.client.setControlCameraFov(90);
	if($BKT::CH)
	{
		crossHair.setBitmap("base/client/ui/crosshair.png");
	}
}