$syj::keybindlimit = 5;		//max key binds we can have
$syj::currentlybinding = 0;	//the next one to be bound

movemap.unbind(getfield(movemap.getbinding("syj_acc_a"),0),getfield(movemap.getbinding("syj_acc_a"),1));
movemap.unbind(getfield(movemap.getbinding("syj_acc_b"),0),getfield(movemap.getbinding("syj_acc_b"),1));
movemap.unbind(getfield(movemap.getbinding("syj_acc_c"),0),getfield(movemap.getbinding("syj_acc_c"),1));
movemap.unbind(getfield(movemap.getbinding("syj_acc_d"),0),getfield(movemap.getbinding("syj_acc_d"),1));
movemap.unbind(getfield(movemap.getbinding("syj_acc_e"),0),getfield(movemap.getbinding("syj_acc_e"),1));
	
function syj_acc_a(%toggle){if(%toggle)commandtoserver('syjacca');} //commands for the five
function syj_acc_b(%toggle){if(%toggle)commandtoserver('syjaccb');} //possible binds stored here
function syj_acc_c(%toggle){if(%toggle)commandtoserver('syjaccc');} //they can only do
function syj_acc_d(%toggle){if(%toggle)commandtoserver('syjaccd');} //server commands
function syj_acc_e(%toggle){if(%toggle)commandtoserver('syjacce');} //and are disposed

function syjinput::onInputEvent(%a,%b,%c)
{
	if(%b !$= "keyboard")				//let's not allow mouse action to be screwed up
		return;

	if(movemap.getcommand("keyboard",%c) !$= "")	//no overwriting
	{
		if(!(getSubStr(movemap.getcommand("keyboard",%c),0,8) $= "syj_acc_"))	//unless it's another disposable command
			return;
	}

	if($syj::currentlybinding==0)			//just figured this was the easy
		movemap.bind(%b,%c,"syj_acc_a");	//way to choose something to bind
	if($syj::currentlybinding==1)
		movemap.bind(%b,%c,"syj_acc_b");
	if($syj::currentlybinding==2)
		movemap.bind(%b,%c,"syj_acc_c");
	if($syj::currentlybinding==3)
		movemap.bind(%b,%c,"syj_acc_d");
	if($syj::currentlybinding==4)
		movemap.bind(%b,%c,"syj_acc_e");

	if($syj::currentlybinding>$syj::keybindlimit-1)		//to many bindings error
		syj_error($syj::error::zvb);

	$syj::currentlybinding++;
	canvas.popdialog(Syj_ServerBind);		//pop dialog

	commandtoserver('keyjustbound');		//let server know
}

function clientcmdrequestkeybind(%uiname)		//how the server requests a keybind
{
	canvas.pushdialog(Syj_ServerBind);		//open dialog
	syjkeybindrequestuiname.settext(%uiname);	//allow server to describe what's being bound
}

function clientcmdcheckbinds()				//function to check how many keys the server requested
{
	commandtoserver('currentbinds',$syj::currentlybinding);
}

package syj_removekeybinds				//package to reset keybinds count
{							//key binds should just overlap next server
	function disconnect(%a,%b,%c,%d,%e,%f)
	{
		Parent::disconnect(%a,%b,%c,%d,%e,%f);
		$syj::currentlybinding = 0;			//reset our count
		movemap.unbind(getfield(movemap.getbinding("syj_acc_a"),0),getfield(movemap.getbinding("syj_acc_a"),1));
		movemap.unbind(getfield(movemap.getbinding("syj_acc_b"),0),getfield(movemap.getbinding("syj_acc_b"),1));
		movemap.unbind(getfield(movemap.getbinding("syj_acc_c"),0),getfield(movemap.getbinding("syj_acc_c"),1));
		movemap.unbind(getfield(movemap.getbinding("syj_acc_d"),0),getfield(movemap.getbinding("syj_acc_d"),1));
		movemap.unbind(getfield(movemap.getbinding("syj_acc_e"),0),getfield(movemap.getbinding("syj_acc_e"),1));
	}
}; 
activatepackage(syj_removekeybinds);
