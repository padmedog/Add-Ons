// ================
// Various List Classes Pack
// ================
// Author: McTwist
// Version: 1.0
// Description: Several ways of handling lists
// Currently classes: Stack, Queue, List
// License: Free to use
// ================

// ================
// Stack
// First comes in, last comes out.
// ================

// Push on top
function Stack::push(%this, %value)
{
	if (%this.data $= "")
		%this.data = %value;
	else
		%this.data = %value NL %this.data;
}

// Get from top
function Stack::top(%this)
{
	return getRecord(%this.data, 0);
}

// Pop from top and return it
function Stack::pop(%this)
{
	%value = %this.top();
	%this.data = removeRecord(%this.data, 0);
	return %value;
}

// Get amount in stack
function Stack::getCount(%this)
{
	return getRecordCount(%this.data);
}

// ================
// Queue
// First comes in, first comes out.
// ================

// Push on back
function Queue::push(%this, %value)
{
	if (%this.data $= "")
		%this.data = %value;
	else
		%this.data = %this.data NL %value;
}

// Get from front
function Queue::front(%this)
{
	return getRecord(%this.data, 0);
}

// Pop from front and return it
function Queue::pop(%this)
{
	%value = %this.front();
	%this.data = removeRecord(%this.data, 0);
	return %value;
}

// Get amount in stack
function Queue::getCount(%this)
{
	return getRecordCount(%this.data);
}

// ================
// List
// Simple way of handling a list
// ================

// Push on back
function List::pushBack(%this, %value)
{
	if (%value $= "")
		return;
	if (%this.data $= "")
		%this.data = %value;
	else
		%this.data = %this.data NL %value;
}

// Push on front
function List::pushFront(%this, %value)
{
	if (%value $= "")
		return;
	if (%this.data $= "")
		%this.data = %value;
	else
		%this.data = %value NL %this.data;
}

// Get from front
function List::front(%this)
{
	return getRecord(%this.data, 0);
}

// Get from back
function List::back(%this)
{
	return getRecord(%this.data, %this.getCount() - 1);
}

// Remove from the list
function List::remove(%this, %pos)
{
	if (%pos < 0 || %pos >= %this.getCount())
		return;
	%this.data = removeRecord(%this.data, %pos);
}

// Pop from back and return it
function List::popBack(%this)
{
	%value = %this.front();
	%this.data = removeRecord(%this.data, 0);
	return %value;
}

// Pop from front and return it
function List::popFront(%this)
{
	%value = %this.front();
	%this.data = removeRecord(%this.data, %this.getCount() - 1);
	return %value;
}

// Assign an already existing list to an another one
function List::assign(%this, %list)
{
	%this.pushBack(%list.data);
}

// Get at position
function List::at(%this, %pos)
{
	if (%pos < 0 || %pos >= %this.getCount())
		return "";
	return getRecord(%this.data, %pos);
}

// Get amount in stack
function List::getCount(%this)
{
	return getRecordCount(%this.data);
}

// Sorting algorithm
function List::sort(%this, %func)
{
	%this.data = QuickSortRecord(%this.data, %func, 0, %this.getCount());
}

// Quick sort implementation
function QuickSortRecord(%list, %func, %left, %right)
{
	// Standard function
	if (!isFunction(%func))
		%func = compareNumber;
	// Avoid crash
	%size = getRecordCount(%list);
	%right = mClamp(%right, 0, %size - 1);
	%left = mClamp(%left, 0, %size - 1);
	
	// Nothing to compare
	if (%right <= %left)
		return %list;
	// There could be a implementation of median-of-three,
	// but it is hard due of how TorqueScript is built up.
	%pivotIndex = mFloor((%left + %right) / 2);
	%pivotNextIndex = %left;
	
	// Partition
	%pivotValue = getRecord(%list, %pivotIndex);
	%list = swapRecord(%list, %pivotIndex, %right);

	%storeIndex = %left;
	for (%i = %left; %i < %right; %i++)
	{
		%a = Call(%func, getRecord(%list, %i), %pivotValue);
		if (%a < 0)
		{
			%list = swapRecord(%list, %i, %pivotNextIndex);
			%pivotNextIndex++;
		}
	}
	%list = swapRecord(%list, %pivotNextIndex, %right);
	
	// Continue on next
	%list = QuickSortRecord(%list, %func, %left, %pivotNextIndex - 1);
	%list = QuickSortRecord(%list, %func, %pivotNextIndex + 1, %right);
	return %list;
}

// Swap data in record list
function swapRecord(%list, %first, %second)
{
	// Avoid crash
	%size = getRecordCount(%list);
	%first = mClamp(%first, 0, %size - 1);
	%second = mClamp(%second, 0, %size - 1);
	
	%a = getRecord(%list, %first);
	%b = getRecord(%list, %second);
	%list = setRecord(%list, %first, %b);
	%list = setRecord(%list, %second, %a);
	return %list;
}

// Which number is bigger?
function compareNumber(%a, %b)
{
	return %a - %b;
}