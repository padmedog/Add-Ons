exec("./NutritionMods/Hunger.cs");
exec("./NutritionMods/Thirst.cs");
exec("./HeatMod/HeatMod.cs");
exec("./HeatMod/OverWrites.cs");
exec("./TacticalPlayer/TacticalLoader.cs");
exec("./ParalyzedPlayer/Player_Paralyzed.cs");
exec("./Core/core.cs");
exec("./CountryDetector/countryDetector.cs");