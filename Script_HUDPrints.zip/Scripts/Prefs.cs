// Title: Prefs.cs
// Author: Boom (9740)
// Configures Preferences for this Add-On

// RTB Prefs
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");

	RTB_registerPref("Enable", "HUD Prints", "$Pref::HUDPrints::Enabled", "bool", "Script_HUDPrints", true, false, true);
	RTB_registerPref("Enable Formatting", "HUD Prints", "$Pref::HUDPrints::Formatting", "bool", "Script_HUDPrints", true, false, true);
	RTB_registerPref("Chat Message", "HUD Prints", "$Pref::HUDPrints::ChatMessage", "string 255", "Script_HUDPrints", "", false, true);
	RTB_registerPref("Bottom Print", "HUD Prints", "$Pref::HUDPrints::BottomPrint", "string 255", "Script_HUDPrints", "", false, true);
	RTB_registerPref("Center Print", "HUD Prints", "$Pref::HUDPrints::CenterPrint", "string 255", "Script_HUDPrints", "", false, true);
	RTB_registerPref("Chat Loop Time (min)", "HUD Prints", "$Pref::HUDPrints::ChatDelay", "int 0 99999", "Script_HUDPrints", 15, false, true);
	RTB_registerPref("Print Loop Time (ms)", "HUD Prints", "$Pref::HUDPrints::PrintDelay", "int 0 99999", "Script_HUDPrints", 100, false, true);
}
else
{
	//Default Values
	$Pref::HUDPrints::Enabled = true;
	$Pref::HUDPrints::Formatting = true;
	$Pref::HUDPrints::ChatMessage = "";
	$Pref::HUDPrints::BottomPrint = "";
	$Pref::HUDPrints::CenterPrint = "";
	$Pref::HUDPrints::ChatDelay = 15;
	$Pref::HUDPrints::PrintDelay = 100;
}

// Formatting Prefs

// Color - Use with %cX
$Pref::HUDPrints::Color[0] = "FF0040"; //Red
$Pref::HUDPrints::Color[1] = "4040FF"; //Blue
$Pref::HUDPrints::Color[2] = "00FF00"; //Green
$Pref::HUDPrints::Color[3] = "FFFF00"; //Yellow
$Pref::HUDPrints::Color[4] = "00FFFF"; //Cyan
$Pref::HUDPrints::Color[5] = "FF00FF"; //Magenta
$Pref::HUDPrints::Color[6] = "FFFFFF"; //White
$Pref::HUDPrints::Color[7] = "606060"; //Gray
$Pref::HUDPrints::Color[8] = "000000"; //Black
$Pref::HUDPrints::Color[9] = "FF8800"; //Orange
$Pref::HUDPrints::DefaultColor = 0;

// Font - Use with %fX, %fXb, %fXi, or %fXbi
$Pref::HUDPrints::Font[0] = "palatino linotype"; //Default
$Pref::HUDPrints::Font[1] = "arial";
$Pref::HUDPrints::Font[2] = "impact";
$Pref::HUDPrints::Font[3] = "verdana";
$Pref::HUDPrints::Font[4] = "calibri";
$Pref::HUDPrints::Font[5] = "comic sans ms";
$Pref::HUDPrints::Font[6] = "courier new";
$Pref::HUDPrints::Font[7] = "lucida console";
$Pref::HUDPrints::Font[8] = "times new roman";
$Pref::HUDPrints::Font[9] = "symbol";
$Pref::HUDPrints::DefaultFont = 0;

// Size - Use with %fXsX, works with Font Modifiers
$Pref::HUDPrints::Size[0] = "10";
$Pref::HUDPrints::Size[1] = "12";
$Pref::HUDPrints::Size[2] = "14";
$Pref::HUDPrints::Size[3] = "16";
$Pref::HUDPrints::Size[4] = "20";
$Pref::HUDPrints::Size[5] = "24"; //Default
$Pref::HUDPrints::Size[6] = "28";
$Pref::HUDPrints::Size[7] = "32";
$Pref::HUDPrints::Size[8] = "36";
$Pref::HUDPrints::Size[9] = "40";
$Pref::HUDPrints::DefaultSize = 5; //Default Index