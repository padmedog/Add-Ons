//@param	string url
//@param	UpdaterRepoSO
function UpdaterRepoHandlerSG::getObjectByURL(%this, %url)
{
	%components = urlGetComponents(%url);
	for(%i = %this.getCount() - 1; %i >= 0; %i --)
	{
		%r = %this.getObject(%i);
		if(%components $= urlGetComponents(%r.url))
		{
			return %r;
		}
	}
	return 0;
}