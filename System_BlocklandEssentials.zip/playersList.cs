function blrs_playersList::onSelect(%this,%id,%text)
{
	
}
