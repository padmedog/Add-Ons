exec("./previewGUI.GUI");
function ServerPreviewTCP::online(%this,%line)
{
	if(%this.getnext)
	{
		%this.setBinary(true);
		return;
	}
	if(%line $= "")
		%this.getnext = true;
}
function ServerPreviewTCP::onBinChunk(%this,%bin)
{
	cancel(%this.timeout);
	%this.timeout = %this.schedule(500,savePreview);
}
function ServerPreviewTCP::savePreview(%this)
{
	%this.saved = true;
	%this.saveBufferToFile("config/ServerPreview.jpg");
	PreviewImage.bitmap = "config/ServerPreview.jpg";
	if(ServerPreviewGUI.isAwake())
	{
		canvas.popDialog(ServerPreviewGUI);
		canvas.pushDialog(ServerPreviewGUI);
	}
}
function ServerPreviewTCP::onConnected(%this)
{
	%this.getPreview(%this.ip,%this.port);
}
function ServerPreviewTCP::getPreview(%this,%ip,%port,%blid)
{
	%uri = strreplace(%ip,".","-") @ "_" @ %port;
	%data = "q=" @ %uri;
	%length = strLen(%data);
	%path = %this.path @ "?" @ %data @ " HTTP/1.1\r\n";
	%host = "Host: " @ %this.host @ "\r\n";
	%userAgent = "User-Agent: Torque/1.0\r\n";
	%type = "Content-Type: text/html\r\n";
	%length = "Content-Length:" @ %length @ "\r\n\r\n";
	%headers = %host @ %userAgent @ %type @ %length;
	%this.send("GET" SPC %path @ %headers @ %data);
	%this.binaryMode = 0;
	%this.ip = strreplace(%ip,".","-");
	%this.port = %port;
}
function ServerPreviewTCP::onDisconnect(%this)
{
	if(!%this.saved)
		warn("Could not fetch server preview for [IP:" @ %this.ip @ "]");
	%this.delete();
}
function JoinServerGUI::requestServerPreview()
{
	%SO = ServerInfoGroup.getObject(JS_ServerList.getSelectedID());
	%IP = getSubStr(%SO.ip,0,strPos(%SO.ip,":"));
	%PORT = getSubStr(%SO.ip,strPos(%SO.ip,":")+1,strLen(%SO.ip));
	if(!%ip || !%port)
		return;
	
	%obj = new TCPObject(ServerPreviewTCP);
	%obj.host = "image.blockland.us";
	%obj.path = "/detail.php";
	%obj.connect(%obj.host @ ":80");
	%obj.ip = %ip;
	%obj.port = %port;
	canvas.pushDialog(ServerPreviewGUI);
	PreviewServerMap.setText(%SO.map);
	PreviewServerPlayers.setText(%SO.currPlayers @ "/" @ %SO.maxPlayers);
	PreviewServerBricks.setText(%SO.brickCount);
	PreviewServerMap.setText(%SO.map);
	ServerPreviewGUI.getObject(0).setText(%SO.name @ " - Server preview");
	PreviewImage.bitmap = "./noImage.png";
	%pos1 = vectorScale(getRes(),0.5);
	%size1 = vectorScale(ServerPreviewGUI.getObject(0).getExtent(),0.5);
	%pos = vectorSub(%pos1,%size1);
	ServerPreviewGUI.position = "0 0";
	schedule(40,0,eval,"ServerPreviewGUI.getObject(0).position = \"" @ %pos @ "\";");
}
//Edit the serverGUI
package ServerPreview
{
	function JoinServerGUI::onWake(%this)
	{
		Parent::onWake(%this);
		if(isObject(PreviewBtn))
			return;
		%window = %this.getObject(0);
		//Get the button container
		for(%i=0;%i<%window.getCount();%i++)
		{
			%control = %window.getObject(%i);
			if(%control.getClassName() $= "GuiControl" && %control != JS_QueryStatus.getID())
				%container = %control;
			if(isObject(%container))
				break;
		}
		//Move the buttons over
		%btnWidth = getWord(%container.getObject(0).extent,0);
		%total = %btnWidth * %container.getCount();
		%spacing = (%total - %width) / (%container.getCount());
		%remove = 15;
		for(%i=0;%i<%container.getCount();%i++)
		{
			%btn = %container.getObject(%i);
			%btnWidth = getWord(%container.getObject(%i).extent,0);
			%btn.extent = setWord(%btn.extent,0,%btnWidth-%remove);
			if(%i != 0)
			{
				%x = getWord(%btn.position,0);
				%btn.position = setWord(%btn.position,0,%x-(%remove*%i));
			}
		}
		//Now that we moved the buttons, add one!
		%copy = %container.getObject(%i--);
		%name = %copy.getName();
		%copy.setName("buttonCopy");
		%previewBtn = new GUIBitmapButtonCtrl(PreviewBtn : buttonCopy){};
		buttonCopy.setName(%name);
		%previewBtn.text = "Preview";
		%x = getWord(%previewBtn.position,0);
		%x += %spacing-10;
		%previewBtn.position = setWord(%previewBtn.position,0,%x);
		%previewBtn.command = "JoinServerGUI.requestServerPreview();";
		%container.add(%previewBtn);
		%container.extent = VectorAdd(%container.getExtent(),"30 0");
	}
};
ActivatePackage(ServerPreview);