registerOutputEvent(fxDTSBrick, "setPlayerCamera", "list Free 0 North 1 East 2 South 3 West 4 Up 5 Down 6 Observe 7",1);

datablock PathCameraData(EventCam)
{
	cameraMaxDist = 0;
	cameraMinDist = 0;
	cameraDefaultFov = 90;
	cameraMinFov = 10;
	cameraMaxFov = 150;
};

function fxDTSBrick::setPlayerCamera(%this,%opt,%client)
{
	if(%client.player.getState() $= "Dead" || !isobject(%client.player))
	{
		%client.eventCamType = "None";
		return;
	}
	if(%client.eventcamtype $= "Static" && isobject(%client.eventcam))
	{
		if(isobject(%client.player))
			%client.setControlObject(%client.player);
		else
			%client.setControlObject(%client.camera);
			//incase a slip happens, somehow
		%client.eventcam.delete();
	}
	else if(%client.eventcamtype $= "Observer")
	{
		%client.camera.setFlyMode();
	}
	%client.eventcamtype = "None";
	updateCamList(%client.camBrick,%client);
	switch (%opt)
	{
		case 0:	messageclient(%client,'',"\c2Camera in Free Mode. \c6-Use Light key to exit camera mode.");
		case 1:	%rot = "1 0 0 0";
		case 2:	%rot = "0 0 1 90";
		case 3:	%rot = "0 0 1 180";
		case 4:	%rot = "0 0 -1 90";
		case 5:	%rot = "1 0 0 90";
		case 6:	%rot = "-1 0 0 90";
		case 7: messageclient(%client,'',"\c2Camera in Observe Mode. \c6-Use Light key to exit camera mode.");
	}	
	if(%opt == 0 || %opt == 7)
	{
		%cam = %client.camera;
		%cam.setwhiteout(0.5);
		%client.eventcam = %cam;
		%client.eventcamtype = "Observer";
		%temp = new StaticShape()
		{
			position = %this.position;
			scale = "0.001 0.001 0.001";
			dataBlock = LCD;
		};
		missioncleanup.add(%temp);
		//We can't setOrbitMode on
		//a brick for some reason,
		//make an 'invisible' StaticShape.
		if(%opt == 0)
			%cam.setOrbitMode(%temp,%this.getTransform(),0,0,0,0);
		else
			%cam.setOrbitMode(%temp,%this.getTransform(),0.5,4.5,4.5,0);		
		%temp.delete();
	}
	else
	{
		messageclient(%client,'',"\c2Camera in Static Mode. \c6-Use Light key to exit camera mode.");
		%cam = new PathCamera()
		{
			dataBlock = EventCam;
			position = %this.position;
			rotation = %rot;
		};
		//A camera that cannot be moved or turned
		//by a client.
		missioncleanup.add(%cam);
		%client.eventcam = %cam;
		%client.eventcamtype = "Static";
		%cam.schedule(1500,setwhiteout,0.75);
	}
	%client.setcontrolobject(%cam);
	updateCamList(%this,%client);
}

function updateCamList(%brick,%client)
{
	for(%x=1;%x<%brick.camCount+1;%x++)
	{
		if(%brick.camClient[%x] == %client)
		{
			%brick.camClient[%x] = "";
			for(%y=%x;%y<%brick.camCount+1;%y++)
				%brick.camClient[%y-1] = %brick.camClient[%y];
			%brick.camCount--;
			if(%client.eventCamType !$= "None")
			{
				%brick.camClient[%brick.camCount++] = %client;
				%client.camBrick = %brick;
			}
			return;
		}
	}
	if(%client.eventCamType !$= "None")
	{
		%brick.camClient[%brick.camCount++] = %client;
		%client.camBrick = %brick;
	}
}

//Functions that will stop camera views.
package EventCam
{
	//Brick death
	function fxDTSBrick::onDeath(%obj)
	{
		for(%x=1;%x<%obj.camCount+1;%x++)
		{
			%cClient = %obj.camClient[%x];
			%cClient.setControlObject(%cClient.player);
			if(%cClient.eventCamType $= "Static")
				%cClient.eventCam.delete();
			else if(%cClient.eventCamType $= "Observer")
				%cClient.eventCam.setFlyMode();
			%cClient.eventCamType = "None";
		}
		Parent::onDeath(%obj);
	}
	//Player death
	function armor::onDisabled(%this,%obj,%state)
	{
		%client = %obj.client;
		%client.setControlObject(%client.player);
		if(%client.eventCamType $= "Static")
			%client.eventCam.delete();
		else if(%client.eventCamType $= "Observer")
			%client.eventCam.setFlyMode();
		%client.eventCamType = "None";
		updateCamList(%client.camBrick,%client);
		Parent::onDisabled(%this,%obj,%state);
	}
	//Client disconnection
	function GameConnection::onClientLeaveGame(%client)
	{
		if(%client.eventCamType $= "Static")
			%client.eventCam.delete();
		%client.eventCamType = "None";
		updateCamList(%client.camBrick,%client);
		Parent::onClientLeaveGame(%client);
	}
	//Light
	function serverCmdLight(%client)
	{
		if(%client.eventCamType !$= "None")
		{
			%client.setControlObject(%client.player);
			if(%client.eventCamType $= "Static")
				%client.eventCam.delete();
			else if(%client.eventCamType $= "Observer")
				%client.eventCam.setFlyMode();
			%client.eventCamType = "None";
			updateCamList(%client.camBrick,%client);
			return;
		}
		Parent::serverCmdLight(%client);
	}
	//Loss of control
	function GameConnection::setControlObject(%this,%obj)
	{
		if(%this.getControlObject() == %this.eventCam)
		{
			if(%this.eventCamType $= "Static")
				%this.eventCam.delete();
			else if(%this.eventCamType $= "Observer")
				%this.eventCam.setFlyMode();
			%this.eventCamType = "None";
			updateCamList(%this.camBrick,%this);
		}
		Parent::setControlObject(%this,%obj);
	}
};
activatePackage(EventCam);