//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Item_Skis");

if(%error == $Error::AddOn_Disabled)
{
   //A bit of a hack:
   //  we just forced the gun to load, but the user had it disabled
   //  so lets make it so they can't select it
   SkiItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Item_Jetpack - required add-on Item_Skis not found");
}
else
{
   exec("./Item_Jetpack.cs"); 
}