//Creates a new UpdaterAddOnSO object.
//@param	string name
//@param	string version
//@param	string channel
//@param	UpdaterRepoSO repository
//@param	string id	An identifier to be used by add-on hosting services.
//@return	UpdaterAddOnSO The newly created object.
function UpdaterAddOnSO(%name, %version, %channel, %repository, %id)
{
	return new ScriptObject()
	{
		class = UpdaterAddOnSO;
		name = %name;
		version = %version;
		channel = %channel;
		repository = %repository;
		id = %id;
	};
}