Put photos in this folder so you can set anyone on your Trusted List's avatar!
Make sure the file name is "<name>_avatar.png"
For example, if you were to make an avatar for me, Clay Hanson, You would put:
Clay Hanson_avatar.png
SUPPORTED FILE TYPES: .jpg   .png