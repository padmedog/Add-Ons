datablock ProjectileData(ModernMPTracerProjectile : MachstilTracerProjectile)
{
   directDamage        = 7;
   directDamageType    = $DamageType::L4ModernMP;
   radiusDamageType    = $DamageType::L4ModernMP;
   impactImpulse	     = 400;
   verticalImpulse	  = 350;
//explosion           = gunExplosion;
   particleEmitter     = "MachstilTracerEmitter";
};

//////////
// item //
//////////
datablock ItemData(ModernMPItem : MachstilItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./glock.mp.dts";
	uiName = "Modern MP";
	iconName = "./modernMP";
	doColorShift = true;
	colorShiftColor = "0.3 0.3 0.3 1.000";
	image = ModernMPImage;
	canDrop = true;

	maxAmmo = 32;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
AddDamageType("ModernMP",   '<bitmap:add-ons/Weapon_Package_Tier2a/machinepistol_ci> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2a/machinepistol_ci> %1',0.75,1);
datablock ShapeBaseImageData(ModernMPImage : MachstilImage)
{
   // Basic Item properties
	shapeFile = "./glock.mp.dts";
   emap = true;
   // Projectile && Ammo.
   item = ModernMPItem;
   ammo = " ";
   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   offset = "0 0 0";
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ModernMPItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 200; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 7; //10
   raycastDirectDamageType = $DamageType::ModernMP;
   raycastSpreadAmt = 0.0006; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = MachstilTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
};

function ModernMPImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0024;
		%this.raycastWeaponRange = 45;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0013;
		%this.raycastWeaponRange = 100;
	}
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	
	%obj.playThread(2, plant);	
}

function ModernMPImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, shiftRight);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function ModernMPImage::onReady(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
}

function ModernMPImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.client.quantity["9MMrounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick6Sound,%obj.getPosition());


        if(%obj.client.quantity["9MMrounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["9MMrounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["9MMrounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["9MMrounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["9MMrounds"] = 0;

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}
	}
}