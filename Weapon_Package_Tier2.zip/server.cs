//we need the tier 1 package for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier1");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Package_Tier2 - required add-on Weapon_Package_Tier1 not found");
}

else
{
   exec("./Support_AltDatablock.cs");  
   exec("./Weapon_Assault Rifle.cs");  
   exec("./Weapon_Battle Rifle.cs");
   exec("./Weapon_Combat Shotgun.cs");
   exec("./Weapon_Military Sniper.cs");
   exec("./Weapon_Magnum.cs");
   exec("./Weapon_LMG.cs");  
}
