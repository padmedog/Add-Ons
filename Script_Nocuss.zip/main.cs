package NocussClientEnterGame
{
   function GameConnection::AutoAdminCheck(%this)
   {
		%this.canStatus = 1;
		messageClient(%this, '', "<color:1589F0>This server runs NXTMASTER's No-cuss mod. No cursing aloud!");
		return Parent::AutoAdminCheck(%this);
   }
};
activatepackage(NocussClientEnterGame);

function serverCmdMessageSent(%client, %fuck)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %shit)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %ass)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %asshole)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %jackass)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %bitch)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %helluva)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %piss)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %porn)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %dick)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %fucking)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %fuc)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %fuk)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %fuu)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %dic)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %dik)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %heluva)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %beitch)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %jakas)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %jakass)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %jackas)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %jacas)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %jacass)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %pis)
{
findclientbyname(%client).delete("No cursing");
}

function serverCmdMessageSent(%client, %shi)
{
findclientbyname(%client).delete("No cursing");
}

