//////////////////////////////////////////////////////////////////////
// First, add this support script in the add-on zipfile				//
// Then add this to server.cs:										//
//  exec("./support_HandsOnVehicle.cs");							//
// And add this to the datablock of the vehicle you want hands on: 	//
//  handsOnVehicle = 1;												//
//////////////////////////////////////////////////////////////////////

if ($Server::HandsOnVehicleSupportVersion > 2)
   return;

$Server::HandsOnVehicleSupportVersion = 2;

if (isPackage(HandsOnVehicleSupport))
{
	deactivatePackage(HandsOnVehicleSupport);	//De-activates package with the same name if there is any. Safety measure.
}

package HandsOnVehicleSupport
{
	function FlyingVehicleData::onAdd(%this, %obj)
	{
		if (%this.handsOnVehicle)
		{
			%obj.hideNode(lhand);
			%obj.hideNode(rhand);
			%obj.hideNode(lhook);
			%obj.hideNode(rhook);
		}
	}
	function WheeledVehicleData::onAdd(%this, %obj)
	{
		Parent::onAdd(%this, %obj);
		if (%this.handsOnVehicle)
		{
			%obj.hideNode(lhand);
			%obj.hideNode(rhand);
			%obj.hideNode(lhook);
			%obj.hideNode(rhook);
		}
	}
	function Armor::onAdd(%this, %obj)
	{
		Parent::onAdd(%this, %obj);
		if (%this.handsOnVehicle)
		{
			%obj.hideNode(lhand);
			%obj.hideNode(rhand);
			%obj.hideNode(lhook);
			%obj.hideNode(rhook);
		}
	}
	
	function armor::onUnMount(%this, %obj, %col, %slot)
	{
		Parent::onUnMount(%this, %obj, %col, %slot);
		
		if (!isObject(%col) || %obj.getMountNode() != 0)
			return;
		
		if (%col.getDatablock().handsOnVehicle)
		{
			%obj.playThread(2, root);
			%obj.playThread(0, root);
			
			//Hand things
			%col.hideNode(lhand);
			%col.hideNode(rhand);
			%col.hideNode(lhook);
			%col.hideNode(rhook);
			
			%obj.client.applyBodyParts();
		}
	}
	function armor::onMount(%this, %obj, %col, %slot)
	{
		Parent::onMount(%this, %obj, %col, %slot);
		
		if (%obj.getMountNode() != 0)
			return;
		
		if(%col.getDatablock().handsOnVehicle)
		{
			%obj.playThread(2, armReadyBoth);
			
			if (%obj.getDatablock().shapeFile $= "base/data/shapes/player/m.dts")
			{
				%t = %obj.activeThread[1];
				if (!(%t $= "armReadyRight" || %t $= "armReadyBoth"))
				{
					%col.unhideNode($rhand[%obj.client.rhand]);
					%col.setNodeColor($rhand[%obj.client.rhand], %obj.client.rhandcolor);
					%obj.hideNode("rhand");
					%obj.hideNode("rhook");
				}
				if (!(%t $= "armReadyLeft" || %t $= "armReadyBoth"))
				{
					%col.unhideNode($lhand[%obj.client.lhand]);
					%col.setNodeColor($lhand[%obj.client.lhand], %obj.client.lhandcolor);
					%obj.hideNode("lhand");
					%obj.hideNode("lhook");
				}
			}
		}
	}
	
	function GameConnection::applyBodyParts(%this)
	{
		Parent::applyBodyParts(%this);
		
		%player = %this.player;
		if (!isObject(%player))
			return;
		
		%veh = %player.getObjectMount();
		if (!isObject(%veh))
			return;
		
		if (%veh.getDatablock().handsOnVehicle  && %player.getMountNode() == 0)
		{
			%veh.hideNode("lhand");
			%veh.hideNode("rhand");
			%veh.hideNode("lhook");
			%veh.hideNode("rhook");
			
			if (%player.getDatablock().shapeFile $= "base/data/shapes/player/m.dts")
			{
				%player.hideNode("lhand");
				%player.hideNode("rhand");
				%player.hideNode("lhook");
				%player.hideNode("rhook");
				%veh.unhideNode($lhand[%this.lhand]);
				%veh.unhideNode($rhand[%this.rhand]);
				%veh.setNodeColor($lhand[%this.lhand], %this.lhandColor);
				%veh.setNodeColor($rhand[%this.rhand], %this.rhandColor);
			}
		}
	}
	
	function Player::playThread(%player, %slot, %thread)
	{
		Parent::playThread(%player, %slot, %thread);
		%veh = %player.getObjectMount();
		%player.activeThread[%slot] = %thread;
		
		if (!isObject(%veh) || %player.getMountNode() != 0)
			return;
		
		if (%veh.getDatablock().handsOnVehicle)
		{
			if (%slot == 1)
			{
				if (%thread $= "armReadyRight")
				{
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					if (%player.getDatablock().shapeFile $= "base/data/shapes/player/m.dts")
					{
						%player.unHideNode($rhand[%player.client.rhand]);
						%veh.unhideNode($lhand[%player.client.lhand]);
						%veh.setNodeColor($lhand[%player.client.lhand], %player.client.lhandColor);
						%player.hideNode("lhand");
						%player.hideNode("lhook");
					}
				}
				else if (%thread $= "armReadyLeft")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					if (%player.getDatablock().shapeFile $= "base/data/shapes/player/m.dts")
					{
						%player.unHideNode($lhand[%player.client.lhand]);
						%veh.unhideNode($rhand[%player.client.rhand]);
						%veh.setNodeColor($rhand[%player.client.rhand], %player.client.rhandColor);
						%player.hideNode("rhand");
						%player.hideNode("rhook");
					}
				}
				else if (%thread $= "armReadyBoth")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					if (%player.getDatablock().shapeFile $= "base/data/shapes/player/m.dts")
					{
						%player.unHideNode($lhand[%player.client.lhand]);
						%veh.hideNode("rhand");
						%veh.hideNode("rhook");
						%player.unHideNode($rhand[%player.client.rhand]);
					}
				}
				else if (%thread $= "root" && %player.getDatablock().shapeFile $= "base/data/shapes/player/m.dts")
				{
					%player.hideNode("lhand");
					%player.hideNode("rhand");
					%player.hideNode("lhook");
					%player.hideNode("rhook");
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($lhand[%player.client.lhand], %player.client.lhandColor);
					%veh.setNodeColor($rhand[%player.client.rhand], %player.client.rhandColor);
				}
			}
		}
	}
};
activatePackage(HandsOnVehicleSupport);