datablock AudioProfile(IGGrenadeLauncherFireSound)
{
   filename    = "./Grenadelauncher_fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(IGGrenadeLauncherExplosionSound)
{
   filename    = "./Grenade_Explosion.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(IGGrenadeLauncherExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 10;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "1 1 1 0";
	colors[1]     = "1 0.25 0 0.9";

	sizes[0]      = 5;
   sizes[1]      = 10;

   times[0] = 0.0;
   times[1] = 0.025;


	useInvAlpha = false;
};

datablock ParticleEmitterData(IGGrenadeLauncherExplosionEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "IGGrenadeLauncherExplosionParticle";
};

datablock ParticleData(IGGrenadeLauncherSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -1.25;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 750;
	lifetimeVarianceMS   = 350;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -20.0;
	spinRandomMax		= 20.0;

   colors[0]     = "1 0.5 0.0 1.0";
	colors[1]     = "0.6 0.4 0.4 0.25";
	colors[2]     = "0.25 0.25 0.25 0.0";

	sizes[0]      = 15;
   sizes[1]      = 17.5;
	sizes[2]      = 20;

   times[0] = 0.0;
   times[1] = 0.25;
   times[2] = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(IGGrenadeLauncherSmokeEmitter)
{
   ejectionPeriodMS = 25;
   periodVarianceMS = 0;
   ejectionVelocity = 2.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "IGGrenadeLauncherSmokeParticle";
};

datablock ParticleData(IGGrenadeTrailParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 100;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "0.5 0.5 0.5 1.0";
	colors[1]     = "0.5 0.5 0.5 0.1";
	colors[2]     = "0.5 0.5 0.5 0.0";

	sizes[0]      = 0.25;
   sizes[1]      = 0.3;
	sizes[2]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.25;
   times[2] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(IGGrenadeTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 2.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "IGGrenadeTrailParticle";
};

datablock ExplosionData(IGGrenadeLauncherExplosion)
{
   //explosionShape = "";
   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";
	soundProfile = IGGrenadeLauncherExplosionSound;

   lifeTimeMS = 150;

   particleEmitter = IGGrenadeLauncherExplosionEmitter;
   particleDensity = 60;
   particleRadius = 0.2;

   emitter[0] = IGGrenadeLauncherSmokeEmitter;
   emitter[1] = IGGrenadeLauncherExplosionEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 20;
   lightStartColor = "1 0.85 0.8 1";
   lightEndColor = "0 0 0 0";

   damageRadius = 9;
   radiusDamage = 50;

   impulseRadius = 4;
   impulseForce = 500;
};

AddDamageType("IGGrenadeLauncherDirect",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Grenadelauncher> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Grenadelauncher> %1',1,1);
datablock ProjectileData(IGGrenadeLauncherProjectile)
{
   projectileShapeName = "./grenade_projectile.dts";
   directDamage        = 50;
   directDamageType = $DamageType::IGGrenadeLauncherDirect;
   radiusDamageType = $DamageType::IGGrenadeLauncherDirect;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = IGGrenadeLauncherExplosion;
   particleEmitter     = IGGrenadeTrailEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;             
   brickExplosionMaxVolume = 76;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 98;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 50;
   velInheritFactor    = 0.0;

   armingDelay         = 2000;
   lifetime            = 3500;
   fadeDelay           = 3500;
   bounceElasticity    = 0.25;
   bounceFriction      = 0.80;
   isBallistic         = true;
   gravityMod = 1;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "IG Grenade";
};

//////////
// item //
//////////
datablock ItemData(IGGrenadeLauncherItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
   shapeFile = "./grenadelauncher.DTS";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Grenade Launcher (Imperial Guard)";
	iconName = "./Grenadelauncher";
	doColorShift = false;
	colorShiftColor = "0.40 0.40 0.42 1.000";
	l4ditemtype = "grenade";

	 // Dynamic properties defined by the scripts
	image = IGGrenadeLauncherImage;
	canDrop = true;

	maxAmmo = 6;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(IGGrenadeLauncherImage)
{
   // Basic Item properties
   shapeFile = "./grenadelauncher.DTS";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = IGGrenadeLauncherItem;
   ammo = " ";
   projectile = IGGrenadeLauncherProjectile;
   projectileType = Projectile;

	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 700;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = false;
   colorShiftColor = IGGrenadeLauncherItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.5;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= IGGrenadeLauncherFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 1.2;
	stateTransitionOnTimeout[4]	= "Ready";
};

function IGGrenadeLauncherImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, plant);

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0002;
	}
	else
	{
		%spread = 0.0000;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}
function IGGrenadeLauncherImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
}


