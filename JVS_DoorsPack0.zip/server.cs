%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_DoorsPack0: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/CabinDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/CellDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/FrontDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/GarageDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/GlassDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/GlassPanelDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/HalfGlassDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/Hatch.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/SaloonDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/SecurityDoor.cs");
}