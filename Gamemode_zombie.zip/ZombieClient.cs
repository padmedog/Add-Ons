if($pref::zombies::ActivatedOnceV2 != 1)
{
	$Minigame::zombies::EnableZombies = 1;

	$Minigame::Zombies::PointsZombie = 1;
	$Minigame::Zombies::PointsDown = 1;
	
	$Minigame::Zombies::EnableDowned = 0;
	$Minigame::Zombies::EnableAmmo = 0;
	$Minigame::Zombies::PlayerCanRespawn = 0;

	$Minigame::Zombies::BrickDamage = 0;
	$Minigame::Zombies::BreakLargePlates = 0;
	$Minigame::Zombies::BreakBrickTerrain = 0;
	$Minigame::Zombies::CanJump = 1;
	$Minigame::Zombies::CanRideVehicles = 1;
	$Minigame::Zombies::AlwaysFindPLayer = 0;
	$Minigame::Zombies::MaxZombies = 10;
	$Minigame::Zombies::MaxHordeSize = 6;
	$Minigame::Zombies::MinHordeSize = 2;
	$Minigame::Zombies::EnableMelee = 1;
	$Minigame::Zombies::CanCrouch = 1;

	$Minigame::Zombies::GoodGuyFollow = 1;
	$Minigame::Zombies::ReturnToSpawn = 0;

	$Minigame::Zombies::RadiusSearch = -1;
	$Minigame::Zombies::ChanceOverride = -1;
	
	//director
	$Minigame::Zombies::DirectorEnabled = 0;

	$Minigame::Zombies::DisableLOSChecks = 0;
	$Minigame::Zombies::FriendlyFire = 0;
	$Minigame::Zombies::Difficulty = "Normal";
	
	//$Minigame::Zombies::FaceName = "asciiterror";

	$Minigame::zombies::ActivatedOnceV2 = 1;
}
function clientcmdSendZombieMinigamePrefs()
{
	echo("Sending zombie prefs");
	commandtoserver('ServerZombiePrefs',$Minigame::Zombies::EnableZombies,$Minigame::Zombies::PointsZombie,$Minigame::Zombies::PointsDown,$Minigame::Zombies::EnableDowned,$Minigame::Zombies::EnableAmmo,$Minigame::zombies::PlayerCanRespawn,$Minigame::Zombies::BrickDamage,$Minigame::zombies::BreakLargePlates,$Minigame::zombies::BreakBrickTerrain,$Minigame::Zombies::CanJump,$Minigame::Zombies::CanRideVehicles,$Minigame::Zombies::AlwaysFindPLayer,$Minigame::Zombies::MaxZombies,$Minigame::Zombies::MaxHordeSize,$Minigame::Zombies::MinHordeSize,$Minigame::Zombies::EnableMelee
		,$Minigame::Zombies::CanCrouch,$Minigame::Zombies::GoodGuyFollow);
	commandtoserver('ServerZombiePrefs2',$Minigame::Zombies::ReturnToSpawn,$Minigame::Zombies::RadiusSearch,$Minigame::Zombies::ChanceOverride,$Minigame::Zombies::DirectorEnabled,$Minigame::Zombies::DisableLOSChecks,$Minigame::Zombies::FriendlyFire,$Minigame::Zombies::Difficulty);
	//echo($Minigame::Zombies::EnableZombies TAB $Minigame::Zombies::PointsZombie TAB $Minigame::Zombies::PointsDown TAB $Minigame::Zombies::EnableDowned TAB $Minigame::Zombies::EnableAmmo TAB $Minigame::zombies::PlayerCanRespawn TAB $Minigame::Zombies::BrickDamage TAB $Minigame::zombies::BreakLargePlates TAB $Minigame::zombies::BreakBrickTerrain TAB $Minigame::Zombies::CanJump TAB $Minigame::Zombies::CanRideVehicles);
	//return	$Minigame::Zombies::EnableZombies TAB $Minigame::Zombies::PointsZombie TAB $Minigame::Zombies::PointsDown TAB $Minigame::Zombies::EnableDowned TAB $Minigame::Zombies::EnableAmmo TAB $Minigame::zombies::PlayerCanRespawn TAB $Minigame::Zombies::BrickDamage TAB $Minigame::zombies::BreakLargePlates TAB $Minigame::zombies::BreakBrickTerrain TAB $Minigame::Zombies::CanJump TAB $Minigame::Zombies::CanRideVehicles;
}

//$remapDivision[$remapCount] = "Left4Block";
//$remapName[$remapCount] = "Zombies Gui";
//$remapCmd[$remapCount] = pushl4bgui;
//$remapCmd[$remapKey] = "ctrl ;";
//$remapCount++;

function pushl4bgui()
{
	//canvas.pushdialog(zombieminigamegui);
}
function guiupdatezombieprefs()
{
	//canvas.popDialog(ZombieMiniGameGui);
	clientcmdSendZombieMinigamePrefs();
}

function zombiesShowBasic()
{
	BasicZombieControls.setvisible(1);
	AdvancedZombieControls.setvisible(0);
}
function zombiesShowAdvanced()
{
	BasicZombieControls.setvisible(0);
	AdvancedZombieControls.setvisible(1);
}