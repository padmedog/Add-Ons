// Water waves, by TristanBomb.
$wavesFreq = 10;
$wavesAmp = 1;
$wavesBase = 1;
$wavesEnabled = false;

function servercmdwaves(%client,%func,%val)
{
	if(%client.isadmin)
	{
		switch$(%func)
		{
		case "freq":
			$wavesFreq = mFloatLength(%val,1);
			messageclient(%client,'',"\c3Wave period set to \c6"@$wavesFreq@"\c3.");
		case "amp":
			$wavesAmp = %val;
			messageclient(%client,'',"\c3Wave amplitude set to \c6"@$wavesAmp@"\c3.");
		case "base":
			if(%val $= "") $wavesBase = $EnvGuiServer::WaterHeight;
			else $wavesBase = %val;
			messageclient(%client,'',"\c3Wave height set to \c6"@$wavesBase@"\c3.");
		case "set":
			if($wavesEnabled == 0)
			{	
				$wavesEnabled = 1;
				wavecycle(%client, 0);
				messageclient(%client,'',"\c3Waves \c2enabled\c3.");
			}
			else
			{
				$wavesEnabled = 0;
				messageclient(%client,'',"\c3Waves \c0disabled\c3.");
			}
		default:
			messageclient(%client,'',"\c2Usage:");
			messageclient(%client,'',"\c3  /waves freq #\c6: Sets the wave period to #, in seconds.");
			messageclient(%client,'',"\c3  /waves amp #\c6: Sets the wave amplitude to #.");
			messageclient(%client,'',"\c3  /waves base #\c6: Sets the normal water height to #.");
			messageclient(%client,'',"\c3  /waves base\c6: Sets the normal water height to the current height.");
			messageclient(%client,'',"\c3  /waves set\c6: Enables or disables waves.");
		}
	}
		else
		{
		messageclient(%client,'',"<color:FF0000>You must be an admin to use this command.");
	}
}

function wavecycle(%client, %t)
{
	serverCmdEnvGui_SetVar(%client, WaterHeight, ($wavesAmp*mSin(%t/($wavesFreq/(2*$pi)))+$wavesBase));
	%t += 0.01;
	%t = mFloatLength(%t,2);
	if(%t >= $wavesFreq) %t = 0;
	if($wavesEnabled == true) schedule(10, 0, wavecycle, %client, %t);
}

//serverCmdEnvGui_SetVar(%client, WaterHeight, %set);

