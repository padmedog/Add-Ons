//=========================================================================
// GUI Modification
//=========================================================================
filtersGui.getObject(0).extent = "186 265";
filtersGui.getObject(0).accelerator = "escape";
filtersGui.getObject(0).command = "canvas.popDialog(filtersGui);";
filtersGui.getObject(0).getObject(3).position = "48 210";
filtersGui.getObject(0).getObject(3).command = "canvas.popDialog(filtersGui);FiltersGui_Close();";

new GuiMLTextCtrl(Filter_SomeText)
{
	profile = "GuiMLTextProfile";
	horizSizing = "right";
	vertSizing = "bottom";
	position = "44 157";
	extent = "99 16";
	minExtent = "8 2";
	visible = "1";
	lineSpacing = "1";
	allowColorChars = "1";
	maxChars = "-1";
	text = "<font:impact:15>Server Name Filter:";
	maxBitmapHeight = "-1";
	selectable = "0";
};

new GuiTextEditCtrl(Filter_ServerNames)
{
	profile = "GuiTextEditProfile";
	horizSizing = "right";
	vertSizing = "bottom";
	position = "9 176";
	extent = "168 18";
	minExtent = "8 2";
	visible = "1";
	maxLength = "255";
	historySize = "0";
	password = "0";
	tabComplete = "0";
	sinkAllKeyEvents = "0";
};

filtersGui.getObject(0).add(Filter_SomeText);
filtersGui.getObject(0).add(Filter_ServerNames);
//=========================================================================
// Functions
//=========================================================================
function FiltersGui_Close()
{
	$Pref::Client::AdvancedServerListFilter = Filter_ServerNames.getValue();
}

function yoFilterBadServers()
{
	for(%i = 0; %i < JS_serverList.rowCount(); %i++)
	{
		for(%o = 0; %o < getWordCount(JS_serverList.getRowTextByID(%i)); %o++)
		{
			for(%k = 0; %k < getWordCount($Pref::Client::AdvancedServerListFilter); %k++)
			{
				if(getWord(JS_serverList.getRowTextByID(%i), %o) $= getWord($Pref::Client::AdvancedServerListFilter, %k))
				{
					JS_serverList.removeRowByID(%i);
				}
			}
		}
	}
}
//=========================================================================
// Package
//=========================================================================
package AdvancedServerListFilter
{
	function ServerSO::serialize(%so)
	{
		if(trim($Pref::Client::AdvancedServerListFilter) !$= "")
		{
			yoFilterBadServers();
		}

		return parent::serialize(%so);
	}

	function filtersGui::onWake(%this)
	{
		Filter_ServerNames.setText($Pref::Client::AdvancedServerListFilter);

		parent::onWake(%this);
	}
};
activatePackage(AdvancedServerListFilter);