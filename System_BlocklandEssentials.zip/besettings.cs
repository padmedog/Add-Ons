function BEsettings_hideAll()
{
	BEguiTab.visible = 0;
	BEserverTab.visible = 0;
	BEotherTab.visible = 0;
}

function BEsettingstab_other()
{
	BEsettings_hideAll();
	BEotherTab.visible = 1;
}

function BEsettingstab_server()
{
	BEsettings_hideAll();
	BEserverTab.visible = 1;
}

function BEsettingstab_gui()
{
	BEsettings_hideAll();
	BEguiTab.visible = 1;
}

if(!isObject(BE_VersionProfile))
{
new GuiControlProfile(BE_VersionProfile)
{
	autoSizeHeight = 0;
	autoSizeWidth = 0;
	bitmap = "base/client/ui/BlockWindow";
	border = "0";
	borderColor = "0 0 0 255";
	borderColorHL = "128 128 128 255";
	borderColorNA = "64 64 64 255";
	borderThickness = "1";
	canKeyFocus = 0;
	cursorColor = "0 0 0 255";
	dofontOutline = "1";
	fillColor = "200 200 200 255";
	fillColorHL = "200 200 200 255";
	fillColorNA = "200 200 200 255";
	fontColors[0] = "0 0 0 255";
	fontColors[1] = "0 0 0 255";
	fontColors[2] = "255 255 255 255";
	fontColors[3] = "255 255 255 255";
	fontColors[4] = "255 255 255 255";
	fontColors[5] = "255 255 255 255";
	fontColors[6] = "255 255 255 255";
	fontColors[7] = "255 255 255 255";
	fontColors[8] = "255 255 255 255";
	fontColors[9] = "255 255 255 255";
	fontColorSEL = "200 200 200 255";
	fontOutlineColor = "24 255 24 255";
	fontSize = "14";
	fontType = "Arial";
	justify = "right";
	modal = "1";
	mouseOverSelected = "0";
	numbersOnly = "0";
	opaque = "0";
	tab = 0;
	textOffset = "0 0";
};
}

if(!isObject(BE_openButton))
{

               new GuiBitmapButtonCtrl(BE_openButton) {
                  profile = "GuiButtonProfile";
                  horizSizing = "left";
                  vertSizing = "top";
                  position = "605 445";
                  extent = "30 30";
                  minExtent = "12 12";
                  enabled = "1";
                  visible = "1";
                  clipToParent = "1";
                  command = "canvas.pushDialog(BEsettings);";
                  text = "BE";
                  groupNum = "-1";
                  buttonType = "PushButton";
                  bitmap = "base/client/ui/button1";
                  lockAspectRatio = "0";
                  alignLeft = "0";
                  alignTop = "0";
                  overflowImage = "0";
                  mKeepCached = "0";
                  mColor = "0 255 0 255";
               };
		MainMenuButtonsGUI.add(BE_openButton);
}

if(!isObject(BEversion))
{
      new GuiTextCtrl(BEversion) 
	{
         profile = "BE_VersionProfile";
         horizSizing = "left";
         vertSizing = "bottom";
         position = "469 14";
         extent = "165 16";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         text = "BE Version: 1";
         maxLength = "255";
	};

	MainMenuButtonsGUI.add(BEversion);

}

function be_requireRestart()
{
	BErestartText.visible = true;
}

function disableHostNames(%a)
{
	$pref::be::dontseparateHosts = 1;
	hostNamesButton.command = "enableHostNames();";
	hostNamesButton.mColor = "255 0 0 255";
	hostNamesButton.text = "Disabled";
	if(!%a)
		be_requireRestart();
}

function enableHostNames(%a)
{
	$pref::be::dontseparateHosts = 0;
	hostNamesButton.command = "disableHostNames();";
	hostNamesButton.mColor = "0 255 0 255";
	hostNamesButton.text = "Enabled";
	if(!%a)
		be_requireRestart();
}

if($pref::be::dontseparateHosts)
	disableHostNames(1);

function disableHighlight()
{
	$pref::be::highlight = 0;
	highlightButton.command = "enableHighlight();";
	highlightButton.mColor = "255 0 0 255";
	highlightButton.text = "Disabled";
	deactivatepackage(highlightBE);
}

function enableHighlight()
{
	$pref::be::highlight = 1;
	highlightButton.command = "disableHighlight();";
	highlightButton.mColor = "0 255 0 255";
	highlightButton.text = "Enabled";
	activatepackage(highlightBE);
}

if($pref::be::highlight)
	enableHighlight();
else
	disableHighlight();
