//########## Greek Fire

//### Effects

datablock ExplosionData(gc_GreekFireExplosion)
{
  lifeTimeMS = 200;
  emitter[0] = gc_FirebombExplosionEmitter;
  emitter[1] = gc_FirebombSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 6;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 8;
  radiusDamage = 50;
  impulseRadius = 12;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 16;
};

//### Projectile

AddDamageType("gc_GreekFire",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_greekfire> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_greekfire> %1',0.2,1);

datablock ProjectileData(gc_GreekFireProjectile)
{
  uiName = "";
  projectileShapeName = "./greekfire_projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_GreekFire;
  radiusDamageType = $DamageType::gc_GreekFire;
  brickExplosionRadius = 6;
  brickExplosionImpact = false;
  brickExplosionForce = 20;
  brickExplosionMaxVolume = 50;
  brickExplosionMaxVolumeFloating = 50;
  impactImpulse = 0;
  explosion = gc_GreekFireExplosion;
  particleEmitter = gc_FLBombTrailEmitter;
  muzzleVelocity = 30;
  verInheritFactor = 0;
  armingDelay = 3000;
  lifetime = 3000;
  fadeDelay = 3000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = true;
  explodeOnPlayerImpact = true;
  sound = gc_FuzeSound;
};

//### Item

datablock ItemData(gc_GreekFireItem)
{
  uiName = "Greek Fire";
  iconName = "./icon_greekfire";
  image = gc_GreekFireImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./greekfire.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
  canPickupMultiple = true;
};

//### Item Image

datablock shapeBaseImageData(gc_GreekFireImage)
{
  shapeFile = "./greekfire.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_GreekFireItem;
  ammo = "";
  projectile = gc_GreekFireProjectile;
  projectileType = Projectile;
  casing = "";
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Charge";
  stateAllowImageChange[1] = true;

  stateName[2] = "Charge";
  stateTransitionOnTimeout[2] = "Armed";
  stateTimeoutValue[2] = 0.2;
  stateWaitForTimeout[2] = false;
  stateTransitionOnTriggerUp[2] = "AbortCharge";
  stateScript[2] = "onCharge";
  stateAllowImageChange[2] = false;
  stateSound[2] = gc_FuzeSound;
  stateEmitter[2] = gc_FuzeImageEmitter;
  stateEmitterTime[2] = 0.2;
  stateEmitterNode[2] = "upPoint";

  stateName[3] = "AbortCharge";
  stateTransitionOnTimeout[3] = "Ready";
  stateTimeoutValue[3] = 0.3;
  stateWaitForTimeout[3] = true;
  stateScript[3] = "onAbortCharge";
  stateAllowImageChange[3] = false;

  stateName[4] = "Armed";
  stateTransitionOnTriggerUp[4] = "Fire";
  stateAllowImageChange[4] = false;
  stateSound[4] = gc_FuzeSound;
  stateEmitter[4] = gc_FuzeImageEmitter;
  stateEmitterTime[4] = 1;
  stateEmitterNode[4] = "upPoint";
  stateTransitionOnTimeout[4] = "Armed";
  stateTimeoutValue[4] = 1;
  stateWaitForTimeout[4] = false;

  stateName[5] = "Fire";
  stateTransitionOnTimeout[5] = "Ready";
  stateTimeoutValue[5] = 0.2;
  stateFire[5] = true;
  stateSequence[5] = "Fire";
  stateScript[5] = "onFire";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = false;
};

function gc_GreekFireImage::onCharge(%this,%obj,%slot)
{
  %obj.playthread(2,shiftLeft);
  %obj.lastGrenadeSlot = %obj.currTool;
  %obj.CookingTastyGrenades = schedule(3000,0,gc_CookedGreekFire,%obj);
  %obj.CookingTime = getSimTime();
}

function gc_GreekFireImage::onAbortCharge(%this,%obj,%slot) {
  %obj.playthread(2,root);
  cancel(%obj.CookingTastyGrenades); }
function gc_GreekFireImage::onUnMount(%this,%obj,%slot) {
  cancel(%obj.CookingTastyGrenades);
  parent::onUnMount(%this,%obj,%slot); }

function gc_GreekFireImage::onFire(%this,%obj,%slot)
{
  %obj.playthread(2,activate);
  cancel(%obj.CookingTastyGrenades);
  if((getSimTime()-%obj.CookingTime) >= 2900) return;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity);
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  %p.schedule(3000-(getSimTime()-%obj.CookingTime),Explode);
  MissionCleanup.add(%p);
  %currSlot = %obj.lastGrenadeSlot;
  %obj.tool[%currSlot] = 0;
  %obj.weaponCount--;
  messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
  serverCmdUnUseTool(%obj.client);
}

function gc_CookedGreekFire(%obj)
{
  %currSlot = %obj.lastGrenadeSlot;
  %obj.tool[%currSlot] = 0;
  %obj.weaponCount--;
  messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
  serverCmdUnUseTool(%obj.client);
  %p = new Projectile()
  {
    dataBlock = gc_GreekFireProjectile;
    initialVelocity = 0;
    initialPosition = %obj.getPosition();
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  %p.schedule(50,Explode);
  MissionCleanup.add(%p);
}

function gc_GreekFireProjectile::onExplode(%this,%obj,%pos,%a)
{
  InitContainerRadiusSearch(%obj.getPosition(),7,$TypeMasks::PlayerObjectType);
  while((%target = containerSearchNext()) != 0) {
    if(miniGameCanDamage(%obj,%target) && getMiniGameFromObject(%target) != -1) gc_burning(%target,20,%obj,1); }
  parent::onExplode(%this,%obj,%pos,%a);
}
