// segway_spring.cs

datablock WheeledVehicleSpring(segwaySpring)
{
   // Wheel suspension properties
   length = 0.2;			 // Suspension travel
   force = 5000; //3000;		 // Spring force
   damping = 1000; //600;		 // Spring damping
   antiSwayForce = 80; //3;		 // Lateral anti-sway force
};


