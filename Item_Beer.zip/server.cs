%error = ForceRequiredAddOn("Item_Skis");

if(%error = $Error::AddOn_Disabled)
{
	tumbleImpactAProjectile.uiName = "";
	skiImpactAProjectile.uiName = "";
	SkiItem.uiName = "";
}

exec("./Emote_Heal.cs");
exec("./Emote_Hurt.cs");
exec("./Support_Alcohol.cs");

exec("./Beer_Drinkable.cs");
exec("./Beer_Weapon.cs");

package Item_Beer
{
	function armor::onTrigger(%data, %player, %slot, %bool)
	{
		parent::onTrigger(%data, %player, %slot, %bool);

		if(%slot != 4 || !%bool)
		{
			return;
		}

		if(!isObject(%mount = %player.getMountedImage(0)))
		{
			return;
		}

		if(%mount.getName() $= "Beer_DrinkableImage")
		{
			%player.playThread(0, rotCW);

			%player.tool[%player.currTool] = Beer_WeaponItem.getID();
			messageClient(%player.client, 'MsgItemPickup', '', %player.currTool, Beer_WeaponItem.getID(), 1);
		}

		else if(%mount.getName() $= "Beer_WeaponImage")
		{
			%player.playThread(0, rotCCW);

			%player.tool[%player.currTool] = Beer_DrinkableItem.getID();
			messageClient(%player.client, 'MsgItemPickup', '', %player.currTool, Beer_DrinkableItem.getID(), 1);
		}
	}
};
activatePackage(Item_Beer);