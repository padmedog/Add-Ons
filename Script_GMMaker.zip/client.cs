//+=========================================================================================================+\\
//|			Made by..																						|\\
//|		   ____   ____  _ 				 __ 		 _ 														|\\
//|		  |_  _| |_  _|(_)              [  |        / |														|\\
//|		    \ \   / /  __   .--.   .--.  | |  ,--. `| |-' .--.   _ .--.										|\\
//|			 \ \ / /  [  | ( (`\]/ .'`\ \| | `'_\ : | | / .'`\ \[ `/'`\]									|\\
//|			  \ ' /    | |  `'.'.| \__. || | // | |,| |,| \__. | | |										|\\
//|			   \_/    [___][\__) )'.__.'[___]\'-;__/\__/ '.__.' [___]										|\\
//|								BL_ID: 20490																|\\
//|				Forum Profile: http://forum.blockland.us/index.php?action=profile;u=40877;                  |\\
//|																											|\\
//+=========================================================================================================+\\

if(!isObject(GameModeMakerGui))
	exec("./GameModeMakerGui.gui");
$ScriptEditor::Debug = true;
$GameModeMakerGui::FirstWake = false;
GMM_List.clear();
GMM_ModeList.clear();
GMM_Prev.setText(" ");
GMM_MiniExtent.extent = "182 22";
GMM_EnvExtent.extent = "302 126";

function GameModeMakerGui::onWake(%this)
{
	//Reset the save title and description
	GMM_SaveTitle.setValue("Gamemode_New");
	GMM_Desc.schedule.setValue("Title: New<br>Author: " @ $Pref::Player::NetName @ " (ID: " @ getNumKeyID() @ ")<br>Description: <wat>");
	GMM_List.clear();
	commandToServer('GMM_RequestFiles');
}

function clientCmdOpenGMM()
{
	canvas.pushDialog(GameModeMakerGui);
}

function clientCmdGMM_addModeFile(%file)
{
	if(GMM_ModeList.findTextIndex(%file) == -1)
	{
		GMM_ModeList.addRow(GMM_ModeList.rowCount(), %file);
		GMM_ModeList.sort(0);
		GMM_SetPrev();
	}
}

function clientCmdGMM_addFile(%file)
{
	if(GMM_List.findTextIndex(%file) == -1)
	{
		GMM_List.addRow(GMM_List.rowCount(), %file);
		GMM_List.sort(0);
	}
}

function GMM_Add()
{
	%select = GMM_List.getSelectedID();
	%text = GMM_List.getRowTextByID(%select);
	if(%text $= "")
		return;
	GMM_ModeList.addRow(GMM_ModeList.rowCount(), %text);
	GMM_SetPrev();
	GMM_ModeList.sort(0);
}

function GMM_Remove()
{
	%select = GMM_ModeList.getSelectedID();
	%text = GMM_ModeList.getRowTextByID(%select);
	if(%text $= "")
		return;
	GMM_ModeList.removeRowByID(%select);
	GMM_SetPrev();
	GMM_ModeList.sort(0);
}

function GMM_SetPrev()
{
	$GMM::Prev = "";
	$GMM::Prev = "//GamemodeMaker made by Visolator ID 20490";
	for(%i=0;%i<GMM_ModeList.rowCount();%i++)
	{
		if(GMM_Backwards.getValue())
		{
			if(%i == 0)
				$GMM::Prev = "//GamemodeMaker made by Visolator ID 20490";
			else
				$GMM::Prev = "ADDON " @ GMM_ModeList.getRowText(%i) NL $GMM::Prev;
		}
		else
			$GMM::Prev = $GMM::Prev NL "ADDON " @ GMM_ModeList.getRowText(%i);
	}

	$GMM::Prev = $GMM::Prev NL "ADDON " @ GMM_SaveTitle.getValue();

	if(GMM_Mini.getValue())
	{
		GMM_MiniExtent.extent = "182 680";
		$GMM::Prev = $GMM::Prev NL "";
		$GMM::Prev = $GMM::Prev NL "$Minigame::Enabled 1";
		$GMM::Prev = $GMM::Prev NL "$MiniGame::InviteOnly " @ GMM_Mini_Invite.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::IncludeAllPlayersBricks " @ GMM_Mini_IncludePl.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::PlayersUseOwnBricks " @ GMM_Mini_UseBricks.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::UseSpawnBricks " @ GMM_Mini_UseSpawn.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::FallingDamage " @ GMM_Mini_Fall.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::WeaponDamage " @ GMM_Mini_Weapon.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::SelfDamage " @ GMM_Mini_Self.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::VehicleDamage " @ GMM_Mini_Vehicle.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::BrickDamage " @ GMM_Mini_BrickDmg.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::EnableWand " @ GMM_Mini_Wand.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::EnableBuilding " @ GMM_Mini_Build.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::EnablePainting " @ GMM_Mini_Paint.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::PlayerDatablockName " @ GMM_Mini_Datablock.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::StartEquipName0 " @ GMM_Mini_Wep0.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::StartEquipName1 " @ GMM_Mini_Wep1.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::StartEquipName2 " @ GMM_Mini_Wep2.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::StartEquipName3 " @ GMM_Mini_Wep3.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::StartEquipName4 " @ GMM_Mini_Wep4.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::GameColor " @ GMM_Mini_GameC.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::Points_BreakBrick " @ GMM_Mini_BreakB.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::Points_PlantBrick " @ GMM_Mini_PlantB.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::Points_KillPlayer " @ GMM_Mini_KillP.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::Points_KillBot " @ GMM_Mini_KillB.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::Points_KillSelf " @ GMM_Mini_KillS.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::Points_Die " @ GMM_Mini_Die.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::RespawnTime " @ GMM_Mini_RespawnT.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::VehicleRespawnTime " @ GMM_Mini_VRespawnT.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::BrickRespawnTime " @ GMM_Mini_BrickRespawnT.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::BotRespawnTime " @ GMM_Mini_BotRespawnT.getValue();
		$GMM::Prev = $GMM::Prev NL "$MiniGame::TimeLimit " @ GMM_Mini_Time.getValue();
	}
	else
	{
		GMM_MiniExtent.extent = "182 22";
		$GMM::Prev = $GMM::Prev NL "";
		$GMM::Prev = $GMM::Prev NL "$Minigame::Enabled 0";
	}

	if(GMM_Env.getValue())
	{
		GMM_EnvExtent.extent = "302 126";
		$GMM::Prev = $GMM::Prev NL "";
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SimpleMode 1";
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SkyFile " @ GMM_Env_Sky.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::WaterFile " @ GMM_Env_Water.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::GroundFile " @ GMM_Env_Ground.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SunFlareTopTexture " @ GMM_Env_SFTF.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SunFlareBottomTexture " @ GMM_Env_SFBT.getValue();
	}
	else
	{
		//GMM_EnvExtent.extent = "302 126";
		$GMM::Prev = $GMM::Prev NL "";
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SimpleMode 1";
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SkyFile " @ GMM_Env_Sky.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::WaterFile " @ GMM_Env_Water.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::GroundFile " @ GMM_Env_Ground.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SunFlareTopTexture " @ GMM_Env_SFTF.getValue();
		$GMM::Prev = $GMM::Prev NL "$EnvGuiServer::SunFlareBottomTexture " @ GMM_Env_SFBT.getValue();
	}

	//$GMM::Prev = trim($GMM:Prev);
	GMM_Prev.setText($GMM::Prev);
	$GMM::Desc = GMM_Desc.getValue();
	$GMM::Desc = strReplace($GMM::Desc, "<br>", "" NL "");
}

function GMM_Save()
{
	commandToServer('GMM_ResetLines');
	
	for(%i=0;%i<getLineCount($GMM::Desc);%i++)
		commandToServer('GMM_AddLine', getLine($GMM::Desc, %i), "Description");

	for(%a=0;%a<getLineCount($GMM::Prev);%a++)
		commandToServer('GMM_AddLine', getLine($GMM::Prev, %a), "Gamemode");

	commandToServer('GMM_CreateGamemode', GMM_SaveTitle.getValue());
}

function GMM_LoadAddOnList()
{
	GMM_ModeList.clear();
	commandToServer('GMM_SetToAddOnList');
}