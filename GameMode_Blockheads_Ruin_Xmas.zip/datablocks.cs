$presentColor0 = "1 0.1 0.3 1";
$presentColor1 = "1 0.9 0.1 1";
$presentColor2 = "0.1 1 0.3 1";
$presentColor3 = "0.1 0.3 1 1";
$presentColor4 = "0.5 0.1 1 1";
$presentColors = 5;

datablock AudioProfile(snowballHitSound)
{
   filename = "Add-Ons/Weapon_Push_Broom/pushBroomHit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(incidentalMusic_Stress_)
{
   filename = "Add-Ons/Music/Stress_.ogg";
   description = "AudioClosest3d";
   preload = 1;
};

datablock AudioProfile(incidentalMusic_Piano_Bass)
{
   filename = "Add-Ons/Music/Piano_Bass.ogg";
   description = "AudioClosest3d";
   preload = 1;
};


AddDamageType("Fire",'<bitmap:add-ons/Gamemode_Blockheads_Ruin_Xmas/ci_fire> %1','%2 <bitmap:add-ons/Gamemode_Blockheads_Ruin_Xmas/ci_fire> %1',0.5,1);


//effects
datablock ParticleData(CannonSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.6;
	constantAcceleration = 0.0;
	lifetimeMS           = 1200;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.2";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 1.0;
	sizes[1]      = 1.2;

	useInvAlpha = true;
};

datablock ParticleEmitterData(CannonSmokeEmitter)
{
   ejectionPeriodMS = 40;
   periodVarianceMS = 4;
   ejectionVelocity = 3;
   velocityVariance = 2;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 50;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "CannonSmokeParticle";

   uiName = "Cannon Smoke";
};


datablock ParticleData(snowballSparkParticle)
{
   dragCoefficient      = 4;
   gravityCoefficient   = 1;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/chunk";
	
	useInvAlpha = false;
	spinSpeed		= 150.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;

   colors[0]     = "0.0 0.10 0.30 0.0";
   colors[1]     = "0.0 0.10 0.30 0.5";
   colors[2]     = "0.0 0.10 0.30 0.0";
   sizes[0]      = 0.15;
   sizes[1]      = 0.15;
   sizes[2]      = 0.15;

   times[0]	= 0.1;
   times[1] = 0.5;
   times[2] = 1.0;

   useInvAlpha = true;
};

datablock ParticleEmitterData(snowballSparkEmitter)
{
	lifeTimeMS = 10;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 3.0;
   ejectionOffset   = 1.50;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = snowballSparkParticle;

   uiName = "Snowball Chunk";
};

datablock ParticleData(snowballExplosionParticle)
{
   dragCoefficient      = 6;
   gravityCoefficient   = -0.15;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 500;
   textureName          = "base/data/particles/cloud";

	spinSpeed		= 50.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "0.9 0.9 1.0 0.5";
   colors[1]     = "0.0 0.0 0.0 0.0";
   sizes[0]      = 0.4;
   sizes[1]      = 0.8;

   useInvAlpha = true;
};

datablock ParticleEmitterData(snowballExplosionEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = snowballExplosionParticle;

   uiName = "Snowball Dust";
   emitterNode = HalfEmitterNode;
};

datablock ExplosionData(snowballExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 400;
   
   //emitter[0] = snowballExplosionEmitter;
   emitter[0] = snowballSparkEmitter;
   particleEmitter = snowballExplosionEmitter;
   particleDensity = 30;
	particleRadius = 1.0;
   
   faceViewer     = true;
   explosionScale = "1 1 1";

   soundProfile = snowballHitSound;

   
   shakeCamera = 0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.0 0.0 0.0";
   lightEndColor = "0 0 0";
};

datablock ParticleData(SnowballTrailParticle)
{
   dragCoefficient = "2.99998";
   windCoefficient = "0";
   gravityCoefficient = "0";
   inheritedVelFactor = "0";
   constantAcceleration = "0";
   lifetimeMS = "250";
   lifetimeVarianceMS = "0";
   spinSpeed = "10";
   spinRandomMin = "-50";
   spinRandomMax = "50";
   useInvAlpha = "1";
   animateTexture = "0";
   framesPerSec = "1";
   textureName = "base/data/particles/dot";
   animTexName[0] = "base/data/particles/dot";
   colors[0] = "0.900000 0.900000 0.900000 0.066667";
   colors[1] = "0.900000 0.900000 0.900000 0.000000";
   colors[2] = "0.600000 1.000000 1.000000 1.000000";
   colors[3] = "0.600000 1.000000 1.000000 1.000000";
   sizes[0] = "0.799609";
   sizes[1] = "0";
   sizes[2] = "1";
   sizes[3] = "1";
   times[0] = "0";
   times[1] = "1";
   times[2] = "2";
   times[3] = "2";
};

datablock ParticleEmitterData(SnowballTrailEmitter)
{
   className = "ParticleEmitterData";
   ejectionPeriodMS = "5";
   periodVarianceMS = "0";
   ejectionVelocity = "0";
   velocityVariance = "0";
   ejectionOffset = "0";
   thetaMin = "0";
   thetaMax = "90";
   phiReferenceVel = "0";
   phiVariance = "360";
   overrideAdvance = "0";
   orientParticles = "0";
   orientOnVelocity = "1";
   particles = "SnowballTrailParticle";
   lifetimeMS = "0";
   lifetimeVarianceMS = "0";
   useEmitterSizes = "0";
   useEmitterColors = "1";
   uiName = "Snowball Trail";
   doFalloff = "1";
   doDetail = "1";
};

datablock ProjectileData(SnowballProjectile) 
{
   className = "ProjectileData";
   particleEmitter = "SnowballTrailEmitter";
   projectileShapeName = "./snowball.dts";
   scale = "1 1 1";
   sound = "";
   Explosion = "snowballExplosion";
   hasLight = "0";
   lightRadius = "5";
   lightColor = "6.000000 1.000000 1.000000 1.000000";
   hasWaterLight = "0";
   waterLightColor = "1.000000 1.000000 1.000000 1.000000";
   isBallistic = "1";
   collideWithPlayers = "1";
   velInheritFactor = "1";
   muzzleVelocity = "40";
   restVelocity = "1";
   lifetime = "8000";
   armingDelay = "0";
   fadeDelay = "8000";
   explodeOnDeath = "1";
   explodeOnPlayerImpact = "0";
   bounceAngle = "0";
   minStickVelocity = "0";
   uiName = "Snowball";
   bounceElasticity = "0.5";
   bounceFriction = "0.2";
   gravityMod = "1";
   doColorShift = 1;
   colorShiftColor = "1 0 1 1";

   impactImpulse	     = 600;
   verticalImpulse	  = 600;
};

function SnowballProjectile::OnCollision(%this, %obj, %target, %fade, %pos, %normal, %velocity)
{
   if(%target == $santa)
      Santa_TargetNearest();//$santa.naughty=%obj.sourceObject;
   if(%target.getclassname() !$= "Player")
      return;
   
   //determine deflection status before checking stun state, shouldn't conflict because you cant be stunned and have a present
   %deflected = false;
   if(%target.hasPresent)
   {
      %srcVector=vectornormalize(setword(vectorsub(%obj.sourceObject.geteyetransform(), %target.geteyetransform()), 2, 0));
      //    this     where %theta = FOV of deflection in radians
      //  VVVVVVVV = mSqrt( mPow( mSin(0.5 * %theta) , 2) + mPow( 1 - mCos(0.5 * %theta) , 2) )
      if(0.642879 > vectordist(%srcVector, vectornormalize(setword(%target.getforwardvector(), 2, 0))))
      {  
         %deflected = true;
      }
   }

   //don't apply impulse if snowball was deflected, makes it too easy for people to get away
   if(%deflected)
   {
      bottomprint(%cl, "<bitmap:base/client/ui/ci/star> \c4Snowball \c6to \c4" @ %target.client.name @ " \c3DEFLECTED", 4);
      bottomprint(%target.client, "<bitmap:base/client/ui/ci/star> \c4Snowball \c6from \c4" @ %cl.name @ " \c3DEFLECTED", 4);
   }
   else
   {
      %this.impactImpulse(%obj,%target,%velocity);
   }

   if(%target.stunned)
      return;
   if(%target.stunTimeout > getSimTime())
      return;

 
   %cl=%obj.sourceObject.client;
   %dist=mFloor(0.5 + 2 * vectordist(setword(%pos,2,0), setword(%obj.originPoint,2,0)));
// if(%dist<8)
//  return;
// if((%img=%target.getmountedimage(0))==0 && %target.snowballPlayerType$="")
//  return;
   

   %target.stunTimeout = getSimTime() + 3500;
   %target.stun(2);
   %target.settempcolor("0.8 0.8 1 1", 3500);
   ServerPlay3D(slowimpactsound, %target.getposition());
   
   if(%dist < 1)
      %dist = 1;

   bottomprint(%cl, "<bitmap:base/client/ui/ci/star> \c4Snowball \c6to \c4" @ %target.client.name @ " \c6at \c4" @ %dist @ " \c6ft.", 4);
   bottomprint(%target.client, "<bitmap:base/client/ui/ci/star> \c4Snowball \c6from \c4" @ %cl.name @ " \c6at \c4" @ %dist @ " \c6ft.", 4);
}


datablock ShapeBaseImageData(SnowballImage)
{
   className = "WeaponImage";
   shapeFile = "./snowball.dts";
   offset = "-0.1 0.2 0.2";
   eyeOffset = "0.7 1.2 -0.55";
   doColorShift = 1;
   colorShiftColor = "1 1 1 1";

   stateName[0]                = "Activate";
   stateTimeoutValue[0]        = 0.1;
   stateTransitionOnTimeout[0] = "Ready";
   stateSequence[0]            = "root";

   stateName[1]                    = "Ready";
   stateTransitionOnTriggerDown[1] = "Fire";
   stateAllowImageChange[1]        = true;

   stateName[2]                = "Fire";
   stateTransitionOnTimeout[2] = "Ready";
   stateTimeoutValue[2]        = 0.01;
   stateFire[2]                = true;
   stateSequence[2]            = "fire";
   stateScript[2]              = "onFire";
   stateWaitForTimeout[2]      = true;
   stateAllowImageChange[2]    = false;
};

function SnowballImage::OnFire(%this, %obj, %slot)
{
   %obj.unmountimage(%slot);
   %obj.playthread(0, shiftAway);
   %obj.spawnprojectile(35, SnowballProjectile, 0, 1);
   %obj.client.play3d(brickPlantSound, vectoradd(%obj.client.player.geteyetransform(), "0 0 5"));

   // if(isobject($santa))
   //  if(vectordist($santa.getposition(),%obj.getposition())<50)
   //   if(Santa_LOS(%obj))
   //    $santa.naughty=%obj;
}



datablock ParticleData(coalTrailParticle : snowballTrailParticle)
{
   textureName = "base/data/particles/chunk";
   animTexName[0] = "base/data/particles/chunk";
   colors[0] = "0.100000 0.100000 0.100000 0.066667";
   colors[1] = "0.100000 0.100000 0.100000 0.000000";
   colors[2] = "1.000000 0.200000 0.200000 1.000000";
   colors[3] = "1.000000 0.200000 0.200000 1.000000";
};

datablock ParticleEmitterData(coalTrailEmitter : snowballTrailEmitter)
{
   particles = "coalTrailParticle";
   uiName = "Coal Trail";
};

datablock ProjectileData(coalProjectile : snowballProjectile)
{
   projectileShapeName = "./coal.dts";
   particleEmitter = "coalTrailEmitter";
   doColorShift = 1;
   colorShiftColor = "0.1 0.1 0.1 1";
   uiName = "Coal";
};


function CoalProjectile::OnCollision(%this, %obj, %target, %fade, %pos, %normal)
{
   if(%target.getclassname() !$= "Player")
      return;
   if(%target.stunned)
      return;
 
   %cl = %obj.sourceObject.client;
   %dist = mFloor(0.5 + 2 * vectordist(setword(%pos, 2, 0), setword(%obj.originPoint, 2, 0)));

   //if(%dist<2)
   // return;

   %target.stunTimeout = getSimTime() + 5000;
   %target.stun(3.5);
   %target.settempcolor("0.3 0.3 0.3 1", 5000);
   %target.addvelocity(setword(vectorscale(vectornormalize(setword(vectorsub(%target.getposition(), %obj.originPoint), 2, 0)), 12), 2, 6));
   ServerPlay3D(slowimpactsound, %target.getposition());

   if(%dist < 1)
      %dist = 1;

   bottomprint(%target.client, "<bitmap:base/client/ui/ci/star> \c7Coal \c6from \c7Santa \c6at \c7" @ %dist @ " \c6ft.", 4);
}


datablock PlayerData(PlayerCantMove : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxBackwardCrouchSpeed = 0;
	maxForwardCrouchSpeed = 0;
	maxSideSpeed = 0;
	maxSideCrouchSpeed = 0;
	maxStepHeight = 0;
    maxUnderwaterSideSpeed = 0;
	maxUnderwaterForwardSpeed = 0;
	maxUnderwaterBackwardSpeed = 0;
	jumpForce = 0;

	uiName = "";
	showEnergyBar = false;
};


datablock ItemData(presentItem0)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	shapeFile = "./present.dts";
	rotate = 0;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Present 1";
	doColorShift = 1;
	colorShiftColor = $presentColor0;

	image = presentImage0;
	canDrop = 0;
};

function presentItem0::OnAdd(%this, %item)
{
   $present[$presents++ - 1] = %item;
}

function presentItem0::OnRemove(%this, %item)
{
   for(%i = $presents - 1; %i > -1; %i--)
   {
      if($present[%i] == %item)
      {
         $present[%i] = $present[$presents--];
         break;
      }
   }
}

function presentItem0::OnPickup(%this, %item, %obj)
{
   if(%obj.getclassname() !$= "Player")
      return;
   if(%obj.hasPresent)
      return;
   if(%obj.stunned)
      return;
 
   %data = %item.getdatablock();
   %obj.hasPresent = %data;
   %obj.mountimage(%item.getdatablock().image, 0);
   %obj.client.play3d(errorsound, vectoradd(%obj.client.player.geteyetransform(), "0 0 5"));
   %item.delete();
}

datablock ShapeBaseImageData(presentImage0)
{
   className = "WeaponImage";
   shapeFile = "./present.dts";
   mountPoint = 2;
   offset = "0 0.84 -0.2";
   eyeOffset = "0.02 1.2 -0.75";
   doColorShift = 1;
   colorShiftColor = $presentColor0;

   stateName[0]                    = "Idle";
   stateTransitionOnTriggerDown[0] = "Fire";

   stateName[1]                    = "Fire";
   stateTransitionOnTriggerUp[1]   = "Idle";
   stateScript[1]                  = "OnFire";
};

function presentImage0::OnFire(%this, %obj, %slot)
{
   //%obj.activateStuff();
   %obj.unMountImage(%slot);
}

function presentImage0::OnMount(%this, %obj, %slot)
{
   %obj.playthread(0,armreadyboth);
}

function presentImage0::OnUnMount(%this, %obj, %slot)
{
   %obj.playthread(0,root);
   %data = %obj.hasPresent;
   %obj.hasPresent = "";

   //%t = %obj.geteyetransform();
   //%v = %obj.getforwardvector();
   //%pos = vectoradd(%t, %v);
   //%vel = vectoradd(%obj.getvelocity(), vectorscale(%v, 7));

//   %pos = %obj.getMuzzlePoint(%slot);
   %pos = getWords(%obj.getMuzzlePoint(%slot), 0, 2) SPC getWords(%obj.getTransform(), 3, 6);

   if(%obj.stunned)
   {
      %v = %obj.getForwardVector();
      %v = vectorScale(%v, 5);
      %v = vectorAdd(%obj.getVelocity(), %v);
   }
   else
   {
      %v = %obj.getMuzzleVector(%slot);
      %v = vectorScale(%v, 10);
      %v = vectorAdd(%obj.getVelocity(), %v);
   }

   if(containerraycast(%t, %pos, $typemasks::fxbrickobjecttype))
   {
      //%pos = vectorsub(%t, %v);
      //%vel = vectorscale(%vel, -1);
   }
   %i = new item()
   { 
      datablock = %data; 
      position = %pos; 
      owner = %obj.client; 
   };
   %i.setTransform(%pos);
   %i.setCollisionTimeout(%obj);
   missionCleanup.add(%i);
   %i.setvelocity(%v);
}


datablock ParticleData(CryBabyParticle)
{
   dragCoefficient = "0";
   windCoefficient = "0";
   gravityCoefficient = "1";
   inheritedVelFactor = "0";
   constantAcceleration = "0";
   lifetimeMS = "420";
   lifetimeVarianceMS = "175";
   spinSpeed = "0";
   spinRandomMin = "-50";
   spinRandomMax = "50";
   useInvAlpha = "1";
   animateTexture = "0";
   framesPerSec = "1";
   textureName = "base/data/particles/bubble";
   animTexName[0] = "base/data/particles/bubble";
   colors[0] = "0.1 0.2 0.9 1";
   colors[1] = "0.1 0.2 0.9 1";
   colors[2] = "0.5 0.7 0.7 0";
   sizes[0] = "0.05";
   sizes[1] = "0.2";
   sizes[2] = "0.05";
   times[0] = "0";
   times[1] = "0.898039";
   times[2] = "1";
};

datablock ParticleEmitterData(CryBabyEmitter) 
{
   className = "ParticleEmitterData";
   ejectionPeriodMS = "8";
   periodVarianceMS = "0";
   ejectionVelocity = "3";
   velocityVariance = "0";
   ejectionOffset = "0";
   thetaMin = "0";
   thetaMax = "5";
   phiReferenceVel = "0";
   phiVariance = "0";
   overrideAdvance = "0";
   orientParticles = "0";
   orientOnVelocity = "1";
   particles = "CryBabyParticle";
   lifetimeMS = "0";
   lifetimeVarianceMS = "0";
   useEmitterSizes = "0";
   useEmitterColors = "0";
   uiName = "CryBaby Tears";
   doFalloff = "1";
   doDetail = "1";
};



datablock ParticleData(HugeBurnParticle)
{
	textureName          = "base/data/particles/cloud";
	dragCoefficient      = 0.0;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 3.0;
	lifetimeMS           = 1200;
	lifetimeVarianceMS   = 100;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1   1   0.3 0.0";
	colors[1]	= "1   1   0.3 1.0";
	colors[2]	= "0.6 0.0 0.0 0.0";

	sizes[0]	= 0.0;
	sizes[1]	= 7.0;
	sizes[2]	= 2.0;

	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(HugeBurnEmitter)
{
   ejectionPeriodMS = 14;
   periodVarianceMS = 4;
   ejectionVelocity = 0;
   ejectionOffset   = 1.00;
   velocityVariance = 0.0;
   thetaMin         = 30;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = HugeBurnParticle;   

   uiName = "Huge Fire";
};





function createPresentDatablocks()
{
   if(isObject(presentItem1))
      return;

   for(%j = 1; %j < $presentColors; %j++)
   {
      eval("datablock ItemData(presentItem" @ %j @ " : presentItem0){ uiName=\"Present " @ (%j + 1) @ "\";colorShiftColor=\"" @ $presentColor[%j] @ "\";image=\"presentImage" @ %j @ "\";};");
      eval("function presentItem" @ %j @ "::onAdd(%this,%jtem){presentItem0.onAdd(%jtem);}");
      eval("function presentItem" @ %j @ "::onRemove(%this,%jtem){presentItem0.onRemove(%jtem);}");
      eval("function presentItem" @ %j @ "::onPickup(%this,%jtem,%obj){presentItem0.onPickup(%jtem,%obj);}");
      eval("datablock ShapeBaseImageData(presentImage" @ %j @ " : presentImage0){colorShiftColor=\"" @ $presentColor[%j] @ "\";};");
      eval("function presentImage" @ %j @ "::OnMount(%this,%obj,%slot){presentImage0.onMount(%obj,%slot);}");
      eval("function presentImage" @ %j @ "::OnUnMount(%this,%obj,%slot){presentImage0.onUnMount(%obj,%slot);}");
      eval("function presentImage" @ %j @ "::OnFire(%this,%obj,%slot){presentImage0::onfire(%this, %obj, %slot);}");
   }
}

createPresentDatablocks();

