//Pheonix Blaster - extrude

/////////
//Audio//
/////////

datablock AudioProfile(pBlasterShot)
{
	filename = "./pBlaster.wav";
	description = AudioClose3d;
	preload = true;
};

datablock ParticleData(PBlasterSmokeParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 425;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.7";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.05;
	sizes[1]      = 0.25;

	useInvAlpha = false;
};

datablock ParticleEmitterData(PBlasterSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PBlasterSmokeParticle";
};

datablock ParticleData(PBlasterTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 120;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 0 0 1";
	colors[1]	= "1 0 0 1";
	colors[2]	= "1 0 0 1";
	sizes[0]	= 0.2;
	sizes[1]	= 0.15;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(PBlasterTracer)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = PBlasterTrailParticle;

   useEmitterColors = true;
};

datablock ExplosionData(PBlasterExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 150;

   particleEmitter = gunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = gunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.8 0.1 0.1";
   lightEndColor = "0 0 0";
};

AddDamageType("PBlaster",   '<bitmap:add-ons/Weapon_PBlaster/generic> %1',    '%2 <bitmap:add-ons/Weapon_PBlaster/generic> %1',0.5,1);
datablock ProjectileData(PBlasterProjectile)
{
   directDamage        = 15;
   directDamageType    = $DamageType::PBlaster;
   radiusDamageType    = $DamageType::PBlaster;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 15;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 20;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 4;
   verticalImpulse	  = 3;
   explosion           = PBlasterExplosion;
   particleEmitter     = PBlasterTracer;

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

    armingDelay         = 00;
   lifetime            = 30000;
   fadeDelay           = 29500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod          = 0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Pheonix Blaster";
};

//////////
// item //
//////////
datablock ItemData(PBlasterItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./PBlaster.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Pheonix Blaster";
	iconName = "./Icon_PBlaster";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = PBlasterImage;
	canDrop = true;


};


////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(PBlasterImage)
{
   // Basic Item properties
   shapeFile = "./PBlaster.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.0 1.0 -0.85"
   rotation = ""; //eulerToMatrix( "0 0 0" )

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = PBlasterProjectile;
   projectileType = Projectile;

//Terraria needs your help!

	//casing = GunShellDebris;
	//shellExitDir        = "1.0 -1.3 1.0";
	//shellExitOffset     = "0 0 0";
	//shellExitVariance   = 15.0;	
	//shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   LarmReady = true;

   doColorShift = true;
   colorShiftColor = PBlasterItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.5;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]					= weaponSwitchSound;
	
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]				= "ready";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Smoke";
	stateTimeoutValue[3]            = 0.25;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]			= true;
	stateEmitter[3]					= gunFlashEmitter;
	stateEmitterTime[3]				= 0.10;
	stateEmitterNode[3]				= "muzzleNode";
	stateSound[3]					= pBlasterShot;
	stateTimeoutValue[3]            = 0.2;
	stateTransitionOnTimeout[3]     = "Ready";
	
};

function PBlasterImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, shiftAway);
	Parent::onFire(%this,%obj,%slot);	
}
