$SpaceMods::Client::AutoWrench::ApplyAutoWrench		= 0;
$SpaceMods::Client::AutoWrench::ApplyAutoVehicles	= 0;
$SpaceMods::Client::AutoWrench::ApplyAutoSounds		= 0;
$SpaceMods::Client::AutoWrench::ApplyAutoEvents		= 0;
$SpaceMods::Client::AutoWrench::AutoCancel		= 0;

package autoEvents
{
	function WrenchDlg::onWake(%this)
	{
		Parent::onWake(%this);
		if($SpaceMods::Client::AutoWrench::ApplyAutoWrench || $SpaceMods::Client::AutoWrench::ApplyAutoEvents)
		{
			if($SpaceMods::Client::AutoWrench::ApplyAutoWrench)
				%this.send();
			
			if($SpaceMods::Client::AutoWrench::ApplyAutoEvents)
				WrenchEventsDlg.send();
			
			clientcmdCenterPrint("\c3Auto Wrench\c5 options set.",2);
			
			cancel($SpaceMods::Client::AutoWrench::AutoCancel);
			$SpaceMods::Client::AutoWrench::AutoCancel = schedule(30000,0,cancelAutoWrench);
		}
	}
	
	function WrenchSoundDlg::onWake(%this)
	{
		Parent::onWake(%this);
		if($SpaceMods::Client::AutoWrench::ApplyAutoSounds || $SpaceMods::Client::AutoWrench::ApplyAutoEvents)
		{
			if($SpaceMods::Client::AutoWrench::ApplyAutoSounds)
				%this.send();
			
			if($SpaceMods::Client::AutoWrench::ApplyAutoEvents)
				WrenchEventsDlg.send();
			
			clientcmdCenterPrint("\c3Auto Wrench\c5 options set.",2);
			
			cancel($SpaceMods::Client::AutoWrench::AutoCancel);
			$SpaceMods::Client::AutoWrench::AutoCancel = schedule(30000,0,cancelAutoWrench);
		}
	}
	
	function WrenchVehicleSpawnDlg::onWake(%this)
	{
		Parent::onWake(%this);
		if($SpaceMods::Client::AutoWrench::ApplyAutoVehicles || $SpaceMods::Client::AutoWrench::ApplyAutoEvents)
		{
			if($SpaceMods::Client::AutoWrench::ApplyAutoVehicles)
				%this.send();
			
			if($SpaceMods::Client::AutoWrench::ApplyAutoEvents)
				WrenchEventsDlg.send();
			
			clientcmdCenterPrint("\c3Auto Wrench\c5 options set.",2);
			
			cancel($SpaceMods::Client::AutoWrench::AutoCancel);
			$SpaceMods::Client::AutoWrench::AutoCancel = schedule(30000,0,cancelAutoWrench);
		}
	}
	
	function disconnect(%a)
	{
		cancel($SpaceMods::Client::AutoWrench::AutoCancel);
		$SpaceMods::Client::AutoWrench::ApplyAutoWrench		 = 0;
		$SpaceMods::Client::AutoWrench::ApplyAutoVehicles		= 0;
		$SpaceMods::Client::AutoWrench::ApplyAutoSounds		 = 0;
		$SpaceMods::Client::AutoWrench::ApplyAutoEvents		 = 0;
		$SpaceMods::Client::AutoWrench::AutoCancel			= 0;
		return Parent::disconnect(%a);
	}
};activatePackage(autoEvents);

function toggleAutoWrench(%val)
{
	if(!%val)
		return;
	
	cancel($SpaceMods::Client::AutoWrench::AutoCancel);
	$SpaceMods::Client::AutoWrench::AutoCancel = 0;
	
	if($SpaceMods::Client::AutoWrench::ApplyAutoWrench || $SpaceMods::Client::AutoWrench::ApplyAutoVehicles || $SpaceMods::Client::AutoWrench::ApplyAutoSounds || $SpaceMods::Client::AutoWrench::ApplyAutoEvents)
	{
		if($SpaceMods::Client::AutoWrench::ApplyAutoWrench)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoWrench = 0;
			%msg = (%msg $= "" ? "\c3Auto Wrench\c5 disabled." : %msg NL "\c3Auto Wrench\c5 disabled.");
		}
		
		if($SpaceMods::Client::AutoWrench::ApplyAutoVehicles)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoVehicles = 0;
			%msg = (%msg $= "" ? "\c3Auto Vehicles\c5 disabled." : %msg NL "\c3Auto Vehicles\c5 disabled.");
		}
		
		if($SpaceMods::Client::AutoWrench::ApplyAutoSounds)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoSounds = 0;
			%msg = (%msg $= "" ? "\c3Auto Sounds\c5 disabled." : %msg NL "\c3Auto Sounds\c5 disabled.");
		}
		
		if($SpaceMods::Client::AutoWrench::ApplyAutoEvents)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoEvents = 0;
			%msg = (%msg $= "" ? "\c3Auto Events\c5 disabled." : %msg NL "\c3Auto Events\c5 disabled.");
		}
		
		clientCmdCenterPrint(%msg,2);
		return;
	}
	
	%check[0] = WrenchLock_Name.getValue();
	%check[1] = WrenchLock_Lights.getValue();
	%check[2] = WrenchLock_Emitters.getValue();
	%check[3] = WrenchLock_EmitterDir.getValue();
	%check[4] = WrenchLock_Items.getValue();
	%check[5] = WrenchLock_ItemPos.getValue();
	%check[6] = WrenchLock_ItemDir.getValue();
	%check[7] = WrenchLock_ItemRespawnTime.getValue();
	%check[8] = WrenchLock_Raycasting.getValue();
	%check[9] = WrenchLock_Collision.getValue();
	%check[10] = WrenchLock_Rendering.getValue();
	%chk = 11;
	for(%i=0;%i<11;%i++)
	{
		if(!%check[%i]){%chk--;}
	}
	
	%wrench = (%chk > 0);
	%events = WrenchLock_Events.getValue();
	%sounds = (WrenchSoundLock_Name.getValue() || WrenchSoundLock_Sounds.getValue());
	
	%check[0] = WrenchVehicleSpawnLock_Name.getValue();
	%check[1] = WrenchVehicleSpawnLock_Vehicles.getValue();
	%check[2] = WrenchVehicleSpawnLock_ReColorVehicle.getValue();
	%check[3] = WrenchVehicleSpawnLock_Raycasting.getValue();
	%check[4] = WrenchVehicleSpawnLock_Collision.getValue();
	%check[5] = WrenchVehicleSpawnLock_Rendering.getValue();
	%chk = 6;
	for(%i=0;%i<6;%i++)
	{
		if(!%check[%i]){%chk--;}
	}
	
	%vehicles = (%chk > 0);
	
	if(!%wrench && !%events && !%sounds && !%vehicles)
	{
		clientcmdCenterPrint("\c5Set some wrench options to \c3Copy\c5 before enabling \c3Auto Wrench\c5.",2);
		return;
	}
	
	if(%wrench)
	{
		$SpaceMods::Client::AutoWrench::ApplyAutoWrench = 1;
		%msg = (%msg $= "" ? "\c3Auto Wrench\c5 enabled." : %msg NL "\c3Auto Wrench\c5 enabled.");
	}
	
	if(%vehicles)
	{
		$SpaceMods::Client::AutoWrench::ApplyAutoVehicles = 1;
		%msg = (%msg $= "" ? "\c3Auto Vehicles\c5 enabled." : %msg NL "\c3Auto Vehicles\c5 enabled.");
	}
	
	if(%sounds)
	{
		$SpaceMods::Client::AutoWrench::ApplyAutoSounds = 1;
		%msg = (%msg $= "" ? "\c3Auto Sounds\c5 enabled." : %msg NL "\c3Auto Sounds\c5 enabled.");
	}
	
	if(%events)
	{
		$SpaceMods::Client::AutoWrench::ApplyAutoEvents = 1;
		%msg = (%msg $= "" ? "\c3Auto Events\c5 enabled." : %msg NL "\c3Auto Events\c5 enabled.");
	}
	
	clientCmdCenterPrint(%msg,2);
	$SpaceMods::Client::AutoWrench::AutoCancel = schedule(30000,0,cancelAutoWrench);
}

function cancelAutoWrench()
{
	$SpaceMods::Client::AutoWrench::AutoCancel = 0;
	
	if($SpaceMods::Client::AutoWrench::ApplyAutoWrench || $SpaceMods::Client::AutoWrench::ApplyAutoVehicles || $SpaceMods::Client::AutoWrench::ApplyAutoSounds || $SpaceMods::Client::AutoWrench::ApplyAutoEvents)
	{
		if($SpaceMods::Client::AutoWrench::ApplyAutoWrench)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoWrench = 0;
			%msg = (%msg $= "" ? "\c3Auto Wrench\c5 disabled. (Unused for 30 seconds)" : %msg NL "\c3Auto Wrench\c5 disabled. (Unused for 30 seconds)");
		}
		
		if($SpaceMods::Client::AutoWrench::ApplyAutoVehicles)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoVehicles = 0;
			%msg = (%msg $= "" ? "\c3Auto Vehicles\c5 disabled. (Unused for 30 seconds)" : %msg NL "\c3Auto Vehicles\c5 disabled. (Unused for 30 seconds)");
		}
		
		if($SpaceMods::Client::AutoWrench::ApplyAutoSounds)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoSounds = 0;
			%msg = (%msg $= "" ? "\c3Auto Sounds\c5 disabled. (Unused for 30 seconds)" : %msg NL "\c3Auto Sounds\c5 disabled. (Unused for 30 seconds)");
		}
		
		if($SpaceMods::Client::AutoWrench::ApplyAutoEvents)
		{
			$SpaceMods::Client::AutoWrench::ApplyAutoEvents = 0;
			%msg = (%msg $= "" ? "\c3Auto Events\c5 disabled. (Unused for 30 seconds)" : %msg NL "\c3Auto Events\c5 disabled. (Unused for 30 seconds)");
		}
		
		clientCmdCenterPrint(%msg,2);
		return;
	}
}

//Randy made this
function AddBind(%division, %name, %command)
{
	 for(%i=0;%i<$remapCount;%i++)
	 {
			if($remapDivision[%i] $= %division)
			{
				%foundDiv = 1;
				continue;
			}
			if(%foundDiv && $remapDivision[%i] !$= "")
			{
				%position = %i;
				break;
			}
	 }
	 if(!%foundDiv)
	 {
			error("Division not found: " @ %division);
			return;
	 }
	 if(!%position)
	 {
			$remapName[$remapCount] = %name;
			$remapCmd[$remapCount] = %command;
			$remapCount++;
			return;
	 }
	 for(%i=$remapCount;%i>%position;%i--)
	 {
			$remapDivision[%i] = $remapDivision[%i - 1];
			$remapName[%i] = $remapName[%i - 1];
			$remapCmd[%i] = $remapCmd[%i - 1];
	 }
	 $remapDivision[%position] = "";
	 $remapName[%position] = %name;
	 $remapCmd[%position] = %command;
	 $remapCount++;
}
if(!$addedAutoWrenchBinds)
{
	 AddBind("Recording","Toggle Automatic Wrench","toggleAutoWrench");
	 $addedAutoWrenchBinds = true;
}