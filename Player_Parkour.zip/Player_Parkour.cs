datablock playerData( playerParkourArmor : playerStandardArmor)
{
	parkourPlayer = 1;

	canJet = 0;

	firstPersonOnly = $PlayerParkour::FirstPersonOnly;

	runForce = 36 * 90;
	maxForwardSpeed = 10;
	maxSideSpeed = 9;
	maxBackwardSpeed = 8;

	maxForwardCrouchSpeed = 7;
	maxBackwardCrouchSpeed = 4;
	maxSideCrouchSpeed = 5;

	jumpForce = 12 * 90;

	minImpactSpeed = 19;
	speedDamageScale = 2.9;

	jumpDelay = 30;

	maxStepHeight = 1;

	uiName = "Parkour Player";

	runSurfaceAngle  = 55;
	jumpSurfaceAngle = 55;

	mass = 120;

	airControl = 0.2;
};

datablock playerData( playerParkourRushArmor : playerParkourArmor )
{
	firstPersonOnly = $PlayerParkour::FirstPersonOnly;

	maxForwardSpeed = 13;
	maxSideSpeed = 8;

	jumpDelay = 32;

	uiName = "";

	airControl = 0.15;
};

datablock PlayerData( PlayerSlidingArmor : playerParkourArmor )
{
	firstPersonOnly = $PlayerParkour::FirstPersonOnly;

	runForce = 5 * 90;

	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxSideSpeed = 0;

	maxForwardCrouchSpeed = 0;
	maxBackwardCrouchSpeed = 2;
	maxSideCrouchSpeed = 0;

	jumpForce = 0;

	uiName = "";

	friction = 0.9;
};

//~~Parkour functions~~\\

function player::parkourRightTrigger( %this )
{
	%this.doLedgeDrop();
}

function player::climbLoop( %this )
{
	cancel( %this.climbLoop );

	%upvel = getWord( %this.getVelocity(), 2 );

	if( !isObject(%this) || %this.getState() $= "Dead" || !%this.trigger[ 2 ] || !%this.getDatablock().parkourPlayer || %this.isGrabbing )
	{
		%this.isClimbing = 0;
		%this.canClimb = true;
		return;
	}

	%start = %this.getHackPosition();
	%beam = vectorScale( %this.getForwardVector(), 1 );
	%stop = vectorAdd( %start, %beam );

	%wallcheck1 = %this.wallCheck( %start, %beam, %stop );
	%check1endpos = %wallcheck1.endPos;

	%start = %this.getPosition();
	%beam = vectorScale( %this.getForwardVector(), 1 );
	%stop = vectorAdd( %start, %beam );

	%wallcheck2 = %this.wallCheck( %start, %beam, %stop );
	%check2endpos = %wallcheck2.endPos;

	%start = %this.getEyePoint();
	%beam = vectorScale( %this.getForwardVector(), 1 );
	%stop = vectorAdd( %start, %beam );
	%wallcheck3 = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );

	//%this.debugLine( %start, %stop, %wallcheck3 );


	%start = %this.getHackPosition();
	%dir = %this.getForwardVector();

	%cross = vectorCross( %dir, "0 0 1" );
	%stop = vectorAdd( %start, vectorScale( %cross, 1.1 ) );

	%wallRunCheckR = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
	//%this.debugLine( %start, %stop, %wallRunCheckR );

	if( %this.canClimb )
	{
		if( %wallRunCheckR )
		{
			%side = "right";
			%this.doWallRun(%side);
		}
		else
		{
			%start = %this.getHackPosition();
			%dir = %this.getForwardVector();

			%cross = vectorCross( %dir, "0 0 -1" );
			%stop = vectorAdd( %start, vectorScale( %cross, 1.1 ) );

			%wallRunCheckL = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
			//%this.debugLine( %start, %stop, %wallRunCheckL );

			if( %wallRunCheckL )
			{
				%side = "left";
				%this.doWallRun(%side);
			}
		}

		if( !%this.isOnGround() )
		{
			if( ( %ledge = %this.ledgeGrabCheck() ) != 0 )
			{
				if( !%this.isGrabbing )
				{
					%this.grabPos = getWords( %this.getTransform(), 0, 1 ) SPC ( GetWord( %ledge.getWorldBox(), 5 ) - 1.5 );
					%this.setTransform( %this.grabPos );
					%this.doLedgeGrab();
					%this.isClimbing = 0;

					if( %this.climbs > 2 )
					{
						%this.climbs = 2;
					}
					return;
				}
			}
			else
			if( isObject( %wallcheck1 ) && isObject( %wallcheck2 ) && isObject( %wallCheck3 ) )
			{
				%this.doClimb();
				%this.isClimbing = 1;
			}
			else
			{
				%start = %this.getHackPosition();
				%beam = vectorScale( %this.getForwardVector(), 1.2 );
				%stop = vectorSub( %start, %beam );
				%wallcheck1 = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
				%this.debugLine( %start, %stop, %wallcheck1 );

				if( isObject( %wallcheck1 ) )
				{
					%this.doWalljump();
					%this.isClimbing = 0;	
				}
			}
		}
	}

	%this.climbLoop = %this.schedule( 32, "climbLoop" );
}

function player::doClimb( %this )
{
	if( %this.isOnGround() || %this.climbs >= 5 || %this.isCrouched() || $Sim::TIme - %this.lastClimb < 0.2)
	{
		return;
	}

	%this.lastClimb = $Sim::Time;

	%vel = %this.getVelocity();
	%speed = vectorLen( getWords( %vel, 0, 1 ) SPC getWord( %vel, 2 ) );
	%upv = 5;	//getWord( %vel, 2 );

	if( %speed > 20 )
	{
		%this.playThread( 3, "talk" );
		%this.schedule( 300, "playThread", 3, "root" );
		%this.playThread( 2, "activate2" );
		serverPlay3d( parkourSlipSound, %this.getHackPosition() );

		%this.addVelocity("0 0 3");
		return;
	}

	if ( %upv < 12 )
	{
		%upv += 4;

		if ( %upv > 12 )
		{
			%upv = 12;
		}
	}

	%vel = vectorScale( %vel, 0.5 );

	%this.setVelocity( getWords( %vel, 0, 1 ) SPC %upv );
	%this.playThread( 0, "fall" );
	%this.schedule( 50, "playThread", 0, "jump" );
	%this.playThread( 2, "shiftUp" );

	%this.climbs += 1;
	if( $PlayerParkour::NinjaMode )
	{
		serverPlay3D( ninjaFootstepSound, %this.getHackPosition() );
	}
	else
	{
		serverPlay3D( parkourClimbSound, %this.getHackPosition() );
	}
}

function player::doWallJump( %this )
{
	if( %this.isOnGround() || %this.trigger[ 3 ] || %this.isCrouched() )
	{
		return;
	}

	if( $Sim::Time - %this.lastWallJump < 0.5 )
	{
		return;
	}

	%this.lastWallJump = $Sim::Time;

	%vel = %this.getVelocity();
	%dir = vectorScale( %this.getForwardVector(), 7 );
	%velXY = "0 0";
	%impulse = getWords( vectorAdd( %velXY, %dir ), 0, 1 );

	if( vectorLen( %this.getVelocity() ) > 20 )
	{
		%this.setVelocity( %impulse SPC getWord( %vel, 2 ) );
	}
	else
	{
		%this.setVelocity( %impulse SPC ( ( getWord( %vel, 2 ) / 2 ) + 10 ) );
	}

	%this.playThread( 0, "jump" );
	%this.playThread( 2, "walk" );
	%this.playThread( 3, "leftrecoil" );
	%this.schedule( 200, "playThread", 2, "root" );

	if( $PlayerParkour::NinjaMode )
	{
		serverPlay3D( ninjaImpactSound, %this.getHackPosition() );
	}
	else
	{
		serverPlay3D( parkourWalljumpSound, %this.getHackPosition() );
	}
}
function player::doWallRun( %this, %side )
{
	if( %this.isOnGround() || %this.isCrouched() )
	{
		return;
	}

	if( !%this.isWallRunning && %this.canWallrun )
	{

		%vel = %this.getVelocity();
		%zvel = getWord( %vel, 2 );
		%zspeed = mAbs( %zvel );
		%xyspeed = vectorLen( getWords( %vel, 0, 1 ) );

		if( %zspeed > 10 )
		{
			return;
		}

		if( %xyspeed < playerParkourArmor.maxForwardSpeed * 0.4 )
		{
			return;
		}

		%this.wallRunStart = $Sim::Time;
		%this.wallRunLoop( %side );
	}
}
function player::wallRunLoop( %this, %side )
{
	cancel( %this.wallRunLoop );

	if( !isObject(%this) || %this.getState() $= "Dead" || %this.isOnGround() || %this.isCrouched() || !%this.trigger[ 2 ] )
	{
		%this.wallRunStop();
		return;
	}

	if( $Sim::Time - %this.wallRunStart > 2.5 )
	{
		%this.wallRunStop();
		return;
	}

	%data = %this.getDatablock();

	%vel = %this.getVelocity();
	%zvel = getWord( %vel, 2 );

	%speed = vectorLen( %vel );
	%zspeed = mAbs( %zvel ); // Turns negative results into positive.
	%xyspeed = vectorLen( getWords( %vel, 0, 1 ) );

	if( %zspeed > 10 )
	{
		%this.wallRunStop();
		return;
	}
	//commandToClient( %this.client, 'bottomprint', "\c6Speed\c3: " @ %zvel @"\c6.\n", 3, true );

	if( %xyspeed < playerParkourArmor.maxForwardSpeed * 0.4 )
	{
		%this.wallRunStop();
		return;
	}

	if( %side $= "left")
	{
		%start = %this.getHackPosition();
		%dir = %this.getForwardVector();

		%cross = vectorCross( %dir, "0 0 -1" );
		%stop = vectorAdd( %start, vectorScale( %cross, 1.1 ) );

		%wallRunCheckL = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
		%this.debugLine( %start, %stop, %wallRunCheckR );
		
		if( !isObject( %wallRunCheckL ) )
		{
			%this.wallRunStop();
			return;
		}
	}
	else if ( %side $= "right" )
	{
		%start = %this.getHackPosition();
		%dir = %this.getForwardVector();

		%cross = vectorCross( %dir, "0 0 1" );
		%stop = vectorAdd( %start, vectorScale( %cross, 1.1 ) );

		%wallRunCheckR = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
		%this.debugLine( %start, %stop, %wallRunCheckR );

		if( !isObject( %wallRunCheckR ) )
		{
			%this.wallRunStop();
			return;
		}
	}

	if( $Sim::Time - %this.lastStepSound > 0.2 )
	{
		%num = getRandom(1, 2);
		if( $PlayerParkour::NinjaMode )
		{
			serverPlay3D( ninjaFootstepSound, %this.getHackPosition() );
		}
		else
		{
			serverPlay3D( parkourWallRun @ %num @ Sound, %this.getHackPosition() );
		}
		%this.lastStepSound = $Sim::Time;
	}

	//if( %zvel < 3 )
	//{
	//	%upv = 0.4;
	//}
	//else
	//{
		%upv = 0.4;
	//}

	%this.addVelocity("0 0" SPC %upv );
	%this.canClimb = false;
	%this.isWallRunning = true;
	%this.canWallrun = false;

	%this.wallRunLoop = %this.schedule( 32, "wallRunLoop", %side );
}

function player::wallRunStop( %this )
{
	//%this.wallRunZone.delete();
	//%this.WallRunZoneCube.delete();
	//%this.WallRunZoneCube = "";
	%this.canClimb = true;
	%this.isWallRunning = false;
	%this.playThread( 0, "root" );
	%this.wallRunStart = 0;
}

//function player::wallRunZone( %this )
//{
//	%zonePos = %this.getWorldBoxCenter();
//	%zonePos = vectorAdd( %zonePos, "0 0" SPC ( getWord( %this.getObjectBox(), 5 ) / -2 - 0.09 ) );
//
//	%this.wallRunZone = new PhysicalZone() 
//	{
//		position = %zonePos;
//		scale = "0.1 0.1 0.1";
//		velocityMod = 0;
//		gravityMod = 0.5;
//		extraDrag = 1; //31;
//		polyhedron = "0 0 0 1 0 0 0 -1 0 0 0 1";//"0 0 0 1 0 0 0 -1 0 0 0 1";
//	};
//
//	if( $PlayerParkour::Debug )
//	{
//		if( isObject( %this.WallRunZoneCube ) )
//		{
//			%this.WallRunZoneCube.delete();
//			%this.WallRunZoneCube = "";
//		}
//
//		%this.WallRunZoneCube = createCube( %zonePos, %this.wallRunZone.scale, "0 1 0 0.8" );
//	}
//}


function player::doRoll( %this )
{
	%this.isRolling = true;
	serverPlay3D( parkourRollSound, %this.getHackPosition() );

	%this.setDatablock(PlayerSlidingArmor);

	%vel = %this.getVelocity();
	%dir = vectorScale( %this.getForwardVector(), 2 );
	%velXY = getWords( %vel, 0, 1 );
	%impulse = getWords( vectorAdd( %velXY, %dir ), 0, 1 );

	%this.setVelocity( %impulse SPC getWord( %vel, 2 ) );

	%this.schedule(300, "stopRoll");
}

function player::stopRoll( %this )
{
	%this.setDatablock( playerParkourArmor );
	%this.isRolling = false;
	serverPlay3D( parkourRollSound, %this.getHackPosition() );
}

function player::doSlide( %this )
{
	if ( $Sim::Time - %this.lastSlide < 2 )
	{
		return;
	}

	if( %this.isSliding || %this.isRolling )
	{
		return;
	}

	%vel = %this.getVelocity();
	%speed = vectorLen( %vel );
	%zvel = getWord( %vel, 2 );
	%maxSpeed = playerParkourArmor.maxForwardSpeed;
	%data = %this.getDataBlock();

	if( %speed < %maxSpeed * 0.9 || %zvel > %data.minImpactSpeed )
	{
		return;
	}

	serverPlay3D( parkourSlideSound, %this.getHackPosition() );

	%this.lastSlide = $Sim::Time;

	%this.isSliding = true;
	%this.setDatablock( playerSlidingArmor );
	%this.playThread( 0, "crouch" );
	%this.schedule( 1500, "stopSliding" );
}

function player::stopSliding( %this )
{
	%this.setDatablock( playerParkourArmor );
	%this.isSliding = false;
	%this.playThread( 0, "root" );
}

function player::doLedgeClimb( %this )
{
	if ( !%this.isGrabbing )
	{
		return;
	}

	if ( $Sim::Time - %this.lastLedgeJump < 0.4 )
	{
		return;
	}

	%this.lastLedgeJump = $Sim::Time;
	%this.isGrabbing = 0;
	%this.parkourGrabZone.delete();

	if( isObject( %this.grabZoneCube ) )
	{
		%this.grabZoneCube.delete();
		%this.grabZoneCube = "";
	}

	%this.schedule( 32, "setVelocity", "0 0 10" );
	%this.playThread( 3, "shiftDown" );
	%this.schedule( 50, "playThread", 0, "jump" );
	%this.schedule( 100, "playThread", 2, "root" );

	serverPlay3D( parkourLedgejumpSound, %this.getHackPosition() );
}

function player::doLedgeGrab( %this )
{
	if ( $Sim::Time - %this.lastLedgeGrab < 0.3 )
	{
		return;
	}

	if ( %this.isGrabbing ||  %this.isOnGround() || %this.trigger[ 3 ] || %this.isCrouched() )
	{
		return;
	}

	%vel = %this.getVelocity();
	%speed = vectorLen( getWords( %vel, 0, 1 ) SPC getWord( %vel, 2 ) );

	if( %speed > 20 )
	{
		%damage = 25;

		%health = %this.getDataBlock().MaxDamage - %this.getDamageLevel() - %damage;
		if( %speed > 30 || %health < 0 )
		{
			%this.playThread( 2, "armReadyBoth" );
			%this.playThread( 0, "fall" );
			serverPlay3D( parkourFallSoftSound, %this.getHackPosition() );

			%this.schedule( 100, "playThread", 0, "jump" );
			%this.schedule( 100, "playThread", 2, "activate2" );
			schedule( 100, "serverPlay3d", "parkourSlipSound", "%this.getHackPosition()" );
			return;
		}
		else
		{
			%this.damage( "", %this.getHackPosition, %damage, "Fall" );
			serverPlay3D( parkourFallSoftSound, %this.getHackPosition() );
		}
	}

	%this.lastLedgeGrab = $Sim::Time;
	%this.isGrabbing = 1;

	//%this.prevpos = %this.getTransform();

	%this.playThread( 2, "armReadyBoth" );
	%this.playThread( 0, "fall" );
	%this.setVelocity( "0 0 0" );
	%this.parkourGrabZone();
	%this.parkourGrabLoop();
	serverPlay3D( parkourGrabSound, %this.getHackPosition() );
}

function player::doLedgeDrop( %this )
{
	if( %this.isGrabbing )
	{
		%this.isGrabbing = 0;
		%this.playThread( 2, "shiftUp" );
		%this.schedule( 100, "playThread", 0, "root" );
		%this.schedule( 300, "playThread", 2, "root" );
		%this.bothHandsUp = false;
		%this.parkourGrabZone.delete();
		if( isObject( %this.grabZoneCube ) )
		{
			%this.grabZoneCube.delete();
			%this.grabZoneCube = "";
		}
	}
}

function player::parkourGrabZone( %this )
{
	%zonePos = %this.getWorldBoxCenter();
	%zonePos = vectorAdd( %zonePos, "0 0" SPC ( getWord(%this.getObjectBox(), 5 ) / -2 - 0.09 ) );

	%this.parkourGrabZone = new PhysicalZone() 
	{
		position = %zonePos;
		scale = "0.1 0.1 0.1";
		velocityMod = 0;
		gravityMod = 0;
		extraDrag = 2; //31;
		polyhedron = "0 0 0 1 0 0 0 -1 0 0 0 1";//"0 0 0 1 0 0 0 -1 0 0 0 1";
	};

	if( $PlayerParkour::Debug )
	{
		if( isObject( %this.grabZoneCube ) )
		{
			%this.grabZoneCube.delete();
			%this.grabZoneCube = "";
		}

		%this.grabZoneCube = createCube( %zonePos, %this.parkourGrabZone.scale, "0 1 0 0.8" );
	}
}


function player::parkourSpeedLoop( %this )
{
	cancel( %this.parkourSpeedLoop );
	
	%data = %this.getDatablock();
	%client = %this.client;

	%vel = %this.getVelocity();
	%zvel = getWord( %vel, 2 );

	%speed = vectorLen( %vel );

	%maxSpeed = playerParkourArmor.maxForwardSpeed;
	%rushSpeed = playerParkourRushArmor.maxForwardSpeed;

	if( %this.isOnGround() )
	{
		%this.climbs = 0;
		%this.canClimb = true;
		%this.canWallRun = true;
	}

	if( !isObject(%this) || %this.getState() $= "Dead" || !%data.parkourPlayer )
	{
		commandToClient( %client, 'setVignette' ,$EnvGuiServer::VignetteMultiply, $EnvGuiServer::VignetteColor );
		if( %this.getMountedImage( 0 ) == nameToID( "parkourRightHandImage" ) )
		{
			%this.unmountImage( 0 );
		}
		if( %this.getMountedImage( 1 ) == nameToID( "parkourLeftHandImage" ) )
		{
			%this.unmountImage( 1 );
		}
		return;
	}

	if( %this.getDamageLevel() > 0 )
	{
		if( $Sim::Time - %this.lastRegen > 0.5 )
		{
			%this.addHealth( 1 );
			%this.lastRegen = $Sim::Time;
		}
	}

	if( %speed >= %maxSpeed * 0.9 )
	{
		if( %data.getName() $= "playerParkourArmor" )
		{
			%this.runTimer += 1;
			if( %this.runtimer >= 30 )
			{
				%this.setDatablock( playerParkourRushArmor );
				%this.runtimer = 0;
				%this.rush = true;
			}
		}
	}
	else
	{
		%this.runtimer = 0;
		if( %data.getName() !$= "playerParkourArmor" )
		{
			%this.setDatablock( playerParkourArmor );
			%this.rush = false;
		}	
	}

	//commandToClient( %client, 'centerPrint', %this.rush ? "\c6Rush!" : "\c6No rush", 3, true );

	if( $PlayerParkour::SpeedVignette )
	{
		%random = getRandom( -1, 1 );
		%random = %random * 0.05;

		%color = 1 - ( %speed * 0.02 );
		%blue = %color;

		if( %this.rush )
		{
			%green = %color / 2;
			%red = %color / 2;
			%alpha = %speed * 0.04;
		}
		else
		{
			%green = %color;
			%red = %color;
			%alpha = %speed * 0.03;
		}

		if( %alpha > 1 )
		{
			%alpha = 0.9;
		}
		if( %alpha > 0.2 )
		{
			%alpha += %random;
		}

		%colors = %red SPC %green SPC %blue;
		//commandToClient( %client, 'centerPrint', "\c6Vignette Alpha\c3: " @ %alpha @"\c6.\n" SPC %colors, 3, true );
		commandToClient( %client, 'SetVignette', false, %colors SPC %alpha );
	}

	%this.parkourSpeedLoop = %this.schedule( 32, "parkourSpeedLoop" );
}

function player::parkourGrabLoop( %this )
{
	cancel( %this.parkourGrabLoop );
	if( !isObject(%this) || %this.getState() $= "Dead" )
	{
		%this.isGrabbing = 0;
		%this.parkourGrabZone.delete();
		%this.grabZoneCube.delete();
		%this.grabZoneCube = "";
		return;
	}

	if ( %this.trigger[ 3 ] || %this.isCrouched() || !%this.isGrabbing )
	{
		%this.doLedgeDrop();
		return;
	}

	if( vectorLen( %this.getVelocity() ) > 0 )
	{
		%this.parkourGrabZone.delete();
		%this.parkourGrabZone();
	}

	%rotation = getWords( %this.getTransform(), 3, 6 );
	%newpos = %this.detectEdge(); //%this.BoundaryCheck();

	if( %newpos != 0 )
	{
		%this.setTransform( %newpos );
	}

	%start = %this.getHackPosition();
	%beam = vectorScale( %this.getForwardVector(), 0.9 );
	%stop = vectorAdd( %start, %beam );
	%ray1 = containerRayCast( %start, %stop, $TypeMasks::FxBrickObjectType, %this );
	%dist1 = vectorDist( %start, %ray1 $= 0 ? %stop : getWords( %ray1, 1, 3 ) );
	//commandToClient( %this.client, 'centerPrint', "\c6VectorDist \c3" @ %dist1 @"\c6.\n", 1, true );

	%beam = vectorScale( %this.getForwardVector(), 0.8 );
	%stop = vectorAdd( %start, %beam );
	%ray2 = containerRayCast( %start, %stop, $TypeMasks::FxBrickObjectType, %this );

	%start = %this.getHackPosition();
	%dir = %this.getForwardVector();
	%cross = vectorCross( %dir, "0 0 1" );
	%stop = vectorAdd( %start, vectorScale( %cross, 1.1 ) );
	%rayCheckR = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
	%this.debugLine( %start, %stop, %rayCheckR );

	%start = %this.getHackPosition();
	%dir = %this.getForwardVector();
	%cross = vectorCross( %dir, "0 0 -1" );
	%stop = vectorAdd( %start, vectorScale( %cross, 1.1 ) );
	%rayCheckL = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
	%this.debugLine( %start, %stop, %rayCheckL );

	if ( %this.trigger[ 2 ] )
	{
		if( !isObject( %ray1 ) || !isObject( %ray2 ) )
		{
			%start = %this.getHackPosition();
			%beam = vectorScale( %this.getForwardVector(), 1.2 );
			%stop = vectorSub( %start, %beam );
			%wallcheck1 = containerRayCast( %start, %stop, $TypeMasks::fxBrickObjectType, %this );
			%this.debugLine( %start, %stop, %wallcheck1 );

			if( isObject( %wallCheck1 ) )
			{
				%this.doLedgeDrop();
				%this.doWallJump();
				return;
			}
		}
		else
		{
			if( $Sim::Time - %this.lastLedgeGrab > 0.5 )
			{
				%this.doLedgeClimb();
			}
		}
	}

	if( !isObject( %ray1 ) || !isObject( %ray2 ) || %dist1 > 0.8 || %dist1 < 0.7 )
	{ 
		%this.setTransform( %this.grabPos SPC %rotation );
	}

	if( isObject( %rayCheckR ) )
	{
		if( !%this.rightHandUp )
		{
			%this.playThread( 2, "armReadyRight" );
			%this.leftHandUp = false;
			%this.rightHandUp = true;
			%this.bothHandsUp = false;
		}
	}
	else
	{
		if( isObject( %rayCheckL ) )
		{
			if( !%this.leftHandUp )
			{
				%this.playThread( 2, "armReadyLeft" );
				%this.leftHandUp = true;
				%this.rightHandUp = false;
				%this.bothHandsUp = false;
			}
		}
		else
		{
			if( !%this.bothHandsUp )
			{
				if( !isObject( %ray1 ) || !isObject( %ray2 ) )
				{
					if( %this.leftHandUp || %this.rightHandUp || %this.bothHandsUp )
					{
						%this.playThread( 2, "root" );
						%this.leftHandUp = false;
						%this.rightHandUp = false;
						%this.bothHandsUp = false;
					}
				}
				else
				{
					%this.playThread( 2, "armReadyBoth" );
					%this.leftHandUp = false;
					%this.rightHandUp = false;
					%this.bothHandsUp = true;
				}
			}
		}
	}

	%this.grabPos = getWords( %this.getTransform(), 0, 2 );

	%this.parkourGrabLoop = %this.schedule( 16, "parkourGrabLoop" );
}