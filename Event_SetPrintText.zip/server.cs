function fxDTSbrick::setPrintText(%brick,%text,%fill,%client,%instigator)
{
	// infinite loop prevention! yaaaay
	if(isObject(%instigator))
	{
		if(%instigator.getid() == %brick.getID())
		{
			return;
		}
	} else {
		%instigator = %brick;
	}
	%db = %brick.getDatablock();
	if(isPackage("VCE_Main"))
	{
		%check = filterVariableString(%text,$inputTarget_Self,%client,%client.player);
		if(%check !$= %text)
		{
			%text = %check;
		}
	}
	if(!%db.hasPrint)
	{
		return;
	}
	%char = getsubstr(%text,0,1);
	if(%char $= "[")
	{
		// Check some stuff
		%pos = stripos(%text,"]");
		if(%pos != -1)
		{
			%possname = getsubstr(%text,1,%pos - 1);
			if($printNameTable[%db.printAspectRatio @ "/" @ %possname] !$= "")
			{
				%char = "[" @ %db.printAspectRatio @ "/" @ %possname;
				%text = getsubstr(%text,%pos,strlen(%text));
			}
		}
	}
	%char = resolvePrintIndex(%char);
	if(%char !$= "")
	{
		%brick.setPrint(%char);
	}
	%text = getsubstr(%text,1,strlen(%text));
	if(!%fill && strlen(%text) <= 0) // lolwut, less or equal 0?
	{
		return;
	}

	%angle = %brick.angleID;
	%vec = $Vec[%angle];
	%width = %db.brickSizeX / 2;
	%vec = vectorAdd(%brick.getWorldBoxCenter(),vectorScale(%vec,%width));
	%ray = containerRayCast(%brick.getWorldBoxCenter(),%vec,$TypeMasks::fxBrickAlwaysObjectType,%brick);
	if(isObject(%tar = getWord(%ray,0)))
	{
		%tardb = %tar.getDatablock();
		if(%tardb.hasPrint && getTrustLevel(%tar,%brick) >= 2)
		{
			%tar.setPrintText(%text,%fill,%client,%instigator);
		}
	}
}
//0123
//WSEN
$vec[0] = "1 0 0";
$vec[1] = "0 -1 0";
$vec[2] = "-1 0 0";
$vec[3] = "0 1 0";

function resolvePrintIndex(%char)
{
	if(strlen(%char) > 1)
	{
		%poss = $printNameTable[getsubstr(%char,1,strlen(%char))];
		if(%poss !$= "")
		{
			return %poss;
		} else {
			%char = getsubstr(%char,0,1);
		}
	}
	switch$(%char)
	{
	case "&": %char = "-and";
	case "'": %char = "-quote";
	case "*": %char = "-asterisk";
	case "@": %char = "-at";
	case "!": %char = "-bang";
	case "^": %char = "-caret";
	case "$": %char = "-dollar";
	case "=": %char = "-equals";
	case ">": %char = "-greater_than";
	case "<": %char = "-less_than";
	case "]": %char = "-greater_than";
	case "[": %char = "-less_than";
	case ")": %char = "-greater_than";
	case "(": %char = "-less_than";
	case "}": %char = "-greater_than";
	case "{": %char = "-less_than";
	case "-": %char = "-minus";
	case "%": %char = "-percent";
	case ".": %char = "-period";
	case "+": %char = "-plus";
	case "#": %char = "-pound";
	case "?": %char = "-qmark";
	case " ": %char = "-space";
	}
	%ind = $printNameTable["Letters/" @ %char];
	if(%ind $= "")
	{
		return $printNameTable["Letters/-space"];
	}
	return %ind;
}

registerOutputEvent("fxDTSbrick","setPrintText","string 200 200\tbool",1);