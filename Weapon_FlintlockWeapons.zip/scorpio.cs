//########## Scorpio Portable Turret

//### Sounds

datablock AudioProfile(gc_ScorpioSetupSound)
{
  filename = "./scorpiosetup.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_ScorpioReloadSound)
{
  filename = "./scorpioreload.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Turrets

datablock TSShapeConstructor(scorpioDts)
{
  baseShape = "./scorpio.dts";
  sequence0 = "./scorpio_root.dsq root";
  sequence1 = "./scorpio_look.dsq look";
  sequence2 = "./scorpio_fire.dsq fire";
  sequence3 = "./scorpio_reload.dsq reload";
  sequence4 = "./scorpio_setup.dsq setup";
};

datablock PlayerData(gc_ScorpioTurretPlayer)
{
  renderFirstPerson = true;
  emap = true;
  className = Armor;
  shapeFile = "./scorpio.dts";
  cameraMaxDist = 8;
  cameraTilt = 0.261;
  cameraVerticalOffset = 1;
  cameraDefaultFov = 90;
  cameraMinFov = 5;
  cameraMaxFov = 120;
  aiAvoidThis = true;
  minLookAngle = -1.6;
  maxLookAngle = 1.6;
  maxFreelookAngle = 3;
  mass = 200000;
  drag = 1;
  density = 5;
  maxDamage = 300;
  maxEnergy = 10;
  repairRate = 0.33;
  rechargeRate = 0.4;
  runForce = 1000;
  runEnergyDrain = 0;
  minRunEnergy = 0;
  maxForwardSpeed = 0;
  maxBackwardSpeed = 0;
  maxSideSpeed = 0;
  maxForwardCrouchSpeed = 0;
  maxBackwardCrouchSpeed = 0;
  maxSideCrouchSpeed = 0;
  maxUnderwaterForwardSpeed = 0;
  maxUnderwaterBackwardSpeed = 0;
  maxUnderwaterSideSpeed = 0;
  jumpForce = 0;
  jumpEnergyDrain = 0;
  minJumpEnergy = 0;
  jumpDelay = 0;
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
  minImpactSpeed = 250;
  speedDamageScale = 3.8;
  boundingBox = "1 1 7";
  crouchBoundingBox = "1 1 7";
  pickupRadius = 0;
  jetEmitter = "";
  jetGroundEmitter = "";
  jetGroundDistance = 4;
  splash = PlayerSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 0.1;
  splashEmitter[0] = PlayerFoamDropletsEmitter;
  splashEmitter[1] = PlayerFoamEmitter;
  splashEmitter[2] = PlayerBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  runSurfaceAngle = 85;
  jumpSurfaceAngle = 86;
  minJumpSpeed = 20;
  maxJumpSpeed = 30;
  horizMaxSpeed = 68;
  horizResistSpeed = 33;
  horizResistFactor = 0.35;
  upMaxSpeed = 80;
  upResistSpeed = 25;
  upResistFactor = 0.3;
  footstepSplashHeight = 0.35;
  JumpSound = "";
  groundImpactMinSpeed = 10;
  groundImpactShakeFreq = "4 4 4";
  groundImpactShakeAmp = "1 1 1";
  groundImpactShakeDuration = 0.8;
  groundImpactShakeFalloff = 10;
  maxItems = 0;
  maxWeapons = 0;
  maxTools = 0;
  uiName = "Scorpio Turret";
  rideable = true;
  lookUpLimit = 0.5;
  lookDownLimit = 0.3;
  canRide = false;
  showEnergyBar = false;
  paintable = true;
  brickImage = horseBrickImage;
  numMountPoints = 1;
  mountThread[0] = "root";
  protectPassengersBurn = false;
  protectPassengersRadius = false;
  protectPassengersDirect = false;
  useCustomPainEffects = true;
  PainHighImage = "";
  PainMidImage = "";
  PainLowImage = "";
  painSound = "";
  deathSound = "";
  useEyePoint = 1;
  gc_portableTurret = 1;
  gc_turretItem = gc_ScorpioItem;
};

function gc_ScorpioTurretPlayer::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  %obj.playThread(0,setup);
  %obj.lastShotTime = getSimTime()+1300;
  %obj.PlayAudio(0,gc_ScorpioSetupSound);
  schedule(1300,0,gc_ScorpioReadyUp,%obj);
}

function gc_ScorpioReadyUp(%obj)
{
  if(!isObject(%obj)) return;
  %obj.playThread(0,root);
  %obj.playThread(1,reload);
  %obj.PlayAudio(1,gc_ScorpioReloadSound);
}

//### Effects

datablock StaticShapeData(gc_TurretPlacementBoxGreenStatic) { shapeFile = "./placementboxgreen.dts"; };
datablock StaticShapeData(gc_TurretPlacementBoxRedStatic) { shapeFile = "./placementboxred.dts"; };

//### Projectile

AddDamageType("gc_Scorpio",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_scorpio> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_scorpio> %1',0.2,1);

datablock ProjectileData(gc_ScorpioProjectile)
{
  uiName = "";
  projectileShapeName = "./scorpiobolt.dts";
  directDamage = 30;
  directVehicleDamage = 15;
  directDamageType = $DamageType::gc_Scorpio;
  radiusDamageType = $DamageType::gc_Scorpio;
  brickExplosionRadius = 0;
  brickExplosionImpact = false;
  impactImpulse = 500;
  verticalImpulse = 0;
  particleEmitter = "";
  explosion = SpearExplosion;
  particleEmitter = gc_GrenadeTrailEmitter;
  muzzleVelocity = 200;
  armingDelay = 0;
  lifetime = 5000;
  fadeDelay = 5000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 0.5;
};

function gc_ScorpioProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(miniGameCanDamage(%obj,%col) && getMiniGameFromObject(%col) != -1) {
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
  if(%col.isCrouched() != 1) {
  %colscale = getWord(%col.getScale(),2);
  if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale)
  { %col.damage(%obj,%pos,%this.directDamage/2,%this.directDamageType); } } }
  if(%col.getType() & $TypeMasks::VehicleObjectType)
  { %col.damage(%obj,%pos,%this.directVehicleDamage,%this.directDamageType); return 1; } }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}

//### Item

datablock ItemData(gc_ScorpioItem)
{
  uiName = "Crossbow Turret";
  iconName = "./icon_scorpio";
  image = gc_ScorpioImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./scorpioitem.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  canDrop = true;
  gc_placementTurret = gc_ScorpioTurretPlayer;
  gc_placementBoxSize = "1 1 1.2";
};

//### Item Image

datablock shapeBaseImageData(gc_ScorpioImage)
{
  shapeFile = "./scorpioitem.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_ScorpioItem;
  melee = false;
  doReaction = false;
  armReady = true;
  offset = "-0.52 0 0";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTimeoutValue[1] = 0.05;
  stateTransitionOnTimeout[1] = "Ready";
  stateWaitForTimeout[1] = false;
  stateScript[1] = "checkPlacement";

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.6";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateScript[2] = "onFire";
};

function gc_ScorpioImage::checkPlacement(%this,%obj,%slot) { gc_PTcheckPlacement(%this,%obj,%slot); }
function gc_ScorpioImage::onFire(%this,%obj,%slot) { gc_PTplaceDown(%this,%obj,%slot); }
function gc_ScorpioImage::onMount(%this,%obj,%slot) { parent::onMount(%this,%obj,%slot); %obj.playThread(1,armreadyboth); bottomPrint(%obj.client,"\c0Left click\c3 to place turret! \c0Right click\c3 on placed turret to pick it up! You can<br>\c3only place one turret! Type \c0/clearturret\c3 to remove your current one!",10); }
function gc_ScorpioImage::onUnMount(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.playThread(1,root); gc_PTclear(%obj); }

package gc_ScorpioPackage
{
  function Player::Burn(%obj,%time)
  {
    if(%obj.dataBlock $= gc_ScorpioTurretPlayer) return;
    parent::Burn(%obj,%time);
  }
  function Player::emote(%obj,%emote)
  {
    if(%obj.dataBlock $= gc_ScorpioTurretPlayer) return;
    parent::emote(%obj,%emote);
  }
  function armor::onMount(%this,%obj,%col,%slot)
  {
    parent::onMount(%this,%obj,%col,%slot);
    if(isObject(%obj.client))
      if(%col.getDataBlock() == gc_ScorpioTurretPlayer.getId()) { %col.playThread(0,root); ServerCmdUnUseTool(%obj.client); }
  }
  function armor::onTrigger(%this,%obj,%triggerNum,%val)
  {
    %mount = %obj.getObjectMount();
    if(%obj.getDataBlock().getID() == gc_ScorpioTurretPlayer.getID()) %mount = %obj;
    if(isObject(%mount))
    {
      if(%mount.getDataBlock() == gc_ScorpioTurretPlayer.getId() && %triggerNum == 0 && %val)
      {
        %client = %obj.client;
        if(isObject(%client)) ServerCmdUnUseTool(%client);
        if(getSimTime() - %mount.lastShotTime < 1800) return;
        %scaleFactor = getWord(%mount.getScale(),2);
        %p = new Projectile()
        {
          dataBlock = gc_ScorpioProjectile;
          initialPosition = %mount.getSlotTransform(1);
          initialVelocity = MatrixMulVector(MatrixCreateFromEuler(((getRandom()-0.5)*0.01) SPC ((getRandom()-0.5)*0.01) SPC ((getRandom()-0.5)*0.01)),VectorScale(%mount.getMuzzleVector(1),150));
          sourceObject = %obj;
          client = %obj.client;
          sourceSlot = 0;
          originPoint = %mount.getSlotTransform(1);
        };
        MissionCleanup.add(%p);
        %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
        %mount.PlayAudio(0,gc_CrossbowFireSound);
        %mount.lastShotTime = getSimTime();
        %mount.playThread(1,fire);
        %mount.schedule(500,playThread,1,reload);
        %mount.schedule(500,PlayAudio,1,gc_ScorpioReloadSound);
        return;
      }
    }
    parent::onTrigger(%this,%obj,%triggerNum,%val);
  }
};
activatepackage(gc_ScorpioPackage);
