exec("./language.cs");
exec("./blrsServerControl.gui");
exec("./guiMessageDisplay.cs");
exec("./blrsServerSelector.gui");
exec("./serverSelector.cs");
exec("./guiControlSelect.cs");
exec("./playersList.cs");
exec("./clientConnect.cs");
exec("./autoReconnect.cs"); 
if(!$pref::be::dontseparateHosts)
	exec("./hostNames.cs");
exec("./playerList.cs");
exec("./eventing.cs");
//exec("./clientFOV.cs");  :c
exec("./toggleWalk.cs");
exec("./Syj_ServerBind.gui");
exec("./keybinds.cs");
exec("./blrsClient.cs");
exec("./highlightBE.cs");
exec("./BEsettings.gui");
exec("./BEsettings.cs");
exec("./buffetClient.cs");

$systemVersion::client = 1.4;

function reloadTheSystemClient()
{
	exec("add-ons/System_BlocklandEssentials/client.cs");
}

function clientcmdsystemAck(%version)
{
	$serverSystemVersion = %version;
	$serverHasSystem = true;
	commandtoserver('systemAck',$systemVersion::client);
}

function clientcmdsystemAckbe(%version,%b)
{
	$serverSystemVersion = %version;
	$serverHasSystem = true;
	commandtoserver('systemAck',$systemVersion::client);
}

package beClearVersion
{
	function disconnectedCleanup(%bool)
	{
		$serverSystemVersion = 0;
		$serverHasSystem = false;
		parent::disconnectedCleanup(%bool);
		$serverSystemVersion = 0;
		$serverHasSystem = false;
	}
};
activatepackage(beClearVersion);
