//if(isFile("Add-Ons/Weapon_Blockombat/effects.cs"))
//{
//return;
//}
//else
//{
AddDamageType("UniversalHeadshot",   '<bitmap:base/client/ui/ci/skull> %1',    '%2 <bitmap:base/client/ui/ci/skull> %1',0.2,1);
datablock ParticleData(LightSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.4 0.4 0.4 0.125";
	colors[1]     = "0.4 0.4 0.4 0.0";
	sizes[0]      = 0.2;
	sizes[1]      = 0.1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(LightSmokeEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 45;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "LightSmokeParticle";
};
datablock ParticleData(GBExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 500;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.6 0.6 0.6 0.4";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.75;
	sizes[1]      = 0.25;
	useInvAlpha = true;
};
datablock ParticleEmitterData(GBExplosionEmitter)
{
   lifeTimeMS		= 30;
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 10;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "GBExplosionParticle";
};
datablock ParticleData(GBExplosion2Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 5.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 60;
	textureName          = "base/data/particles/chunk";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.01 0.01 0.01 0.9";
	colors[1]     = "0.01 0.01 0.01 0.6";
	sizes[0]      = 0.1;
	sizes[1]      = 0.1;
	useInvAlpha = true;
};
datablock ParticleEmitterData(GBExplosion2Emitter)
{
   ejectionPeriodMS = 24;
   periodVarianceMS = 2;
   ejectionVelocity = 15;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 80;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "GBExplosion2Particle";
};
//}
datablock ExplosionData(GBImpact2Explosion)
{
	soundProfile = bullethitSound;
	lifeTimeMS = 150;
	particleEmitter = GBExplosionEmitter;
	particleDensity = 5;
	particleRadius = 0.2;
	emitter[0] = GBExplosion2Emitter;
	faceViewer     = true;
	explosionScale = "1 1 1";
	shakeCamera = True;
	camShakeFreq = "0.0 1.0 1.0";
	camShakeAmp = "0.0 3.0 2.5";
	camShakeDuration = 0.5;
	camShakeRadius = 0.5;
	lightStartRadius = 0;
	lightEndRadius = 0;
};
datablock ExplosionData(ScopeBoltExplosion : ATACRecoilExplosion)
{
   lifeTimeMS = 150;
   shakeCamera = true;
   camShakeFreq = "1 1 1";
   camShakeAmp = "30 10.0 70";
   camShakeDuration = 0.8;
   camShakeRadius = 2.5;
};
datablock ProjectileData(ScopeBoltProjectile : ATACRecoilProjectile)
{
	explosion		= ScopeBoltExplosion;
};
datablock ExplosionData(ATACRecoilExplosion)
{
   lifeTimeMS = 150;
   faceViewer     = true;
   explosionScale = "1 1 1";
   shakeCamera = true;
   camShakeFreq = "1 0 1";
   camShakeAmp = "4 0 4";
   camShakeDuration = 0.5;
   camShakeRadius = 2.5;
};
datablock ProjectileData(ATACRecoilProjectile)
{
	lifetime		= 10;
	fadeDelay		= 10;
	explodeondeath	= true;
	explosion		= ATACRecoilExplosion;
};
datablock ParticleData(ATACFlashParticle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 30;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 50.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.9 0.9 0.0 0.9";
	colors[1]     = "0.9 0.5 0.0 0.3";
	sizes[0]      = 1.0;
	sizes[1]      = 0.15;
	useInvAlpha = false;
};
datablock ParticleEmitterData(ATACFlashEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 20.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ATACFlashParticle";
};
datablock ExplosionData(ATACFlashExplosion)
{
   lifeTimeMS = 100;
   lightStartRadius = 7;
   lightEndRadius = 10;
   lightStartColor = "0.9 0.8 0.7";
   lightEndColor = "0.9 0.5 0.0";
};
datablock ProjectileData(ATACFlashProjectile)
{
	projectileShapeName	= "base/data/shapes/empty.dts";
	directDamage		= 50;
	directDamageType	= $DamageType::UniversalHeadshot;
	lifetime			= 25;
	fadeDelay			= 25;
    armingDelay			= 0;
	muzzleVelocity		= 20;
	explodeondeath		= true;
	explosion			= ATACFlashExplosion;
};
datablock ParticleData(ShortVaporTrailParticle)
{
	dragCoefficient		= 8;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 75;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	useInvAlpha		= false;
	animateTexture		= false;
	textureName		= "base/data/particles/dot";
	colors[0]     = "0.9 0.9 0.0 0.8";
	colors[1]     = "0.9 0.5 0.0 0.4";
	colors[2]     = "0.9 0.9 0.9 0.0";
	sizes[0]      = 0.14;
	sizes[1]      = 0.07;
	sizes[2]      = 0.0;
};
datablock ParticleEmitterData(ShortVaporTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 0;
   ejectionOffset = 0;
   thetaMin         = 0.0;
   thetaMax         = 0.1;  
   particles = ShortVaporTrailParticle;
   useEmitterColors = False;
};