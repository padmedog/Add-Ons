function OpenConfirmDlg()
{
	if(getField($DelGui.getValue(),0)!$="")
	{
		canvas.pushDialog("DeleteSave_ConfirmDlg");
	}
}

exec("./DeleteConfirmGui.gui");

function LoadBricks_Window::OnWake(%this)
{
	$DelGui = "LoadBricks_FileList";

	if(!isObject(LoadBricks_DeleteButton))
	{
		LoadBricks_LoadButton.delete();

		for(%iA=0;%iA<LoadBricks_Window.getCount();%iA++)
		{
			%objA=LoadBricks_Window.getObject(%iA);

			if(%objA.text $= "Cancel")
			%objA.delete();
		}
	exec("./LoadBricksGui.gui");
	}
}

function SaveBricks_Window::OnWake(%this)
{
	$DelGui = "SaveBricks_FileList";

	if(!isObject(SaveBricks_DeleteButton))
	{
		exec("./SaveBricksGui.gui");
	}
}

function DeleteSave_Confirm()
{
		%fileName=getField($DelGui.getValue(),0);

		%file = "saves/" @ %fileName @ ".bls";

		if(isFile(%file))
		filedelete(%file);

		if(isFile("saves/" @ %fileName @ ".png"))
		%img = "saves/" @ %fileName @ ".png";
	else
		if(isFile("saves/" @ %fileName @ ".jpg"))
		%img = "saves/" @ %fileName @ ".jpg";

		if(isFile(%img))
		filedelete(%img);

		$DelGui.RemoveRowById($DelGui.getSelectedID());
		$DelGui.setSelectedRow(0);
}