//########## Russian Main Battle Tank T-90

exec("./t90.cs");
