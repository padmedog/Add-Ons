//########## G17
datablock AudioProfile(G18WhizSound){filename="./Sounds/whiz.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G18DeploySound){filename="./Sounds/equip.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G18HitSound){filename="./Add-Ons/Weapon_Gun/bulletHit.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G18MetalHitSound){filename="./Add-Ons/Weapon_Gun/bulletHit.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G17FireSound){filename="./Sounds/G17fire.wav";description=AudioClose3d;preload=true;};

datablock AudioProfile(G18ClickSound){filename="./Sounds/empty.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G18Reload1Sound){filename="./Sounds/G18Reload1.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G18Reload2Sound){filename="./Sounds/G18Reload2.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(G18CockSound){filename="./Sounds/G18Cock.wav";description=AudioClosest3d;preload=true;};

datablock ParticleData(G17bulletExplosionParticle){dragCoefficient=8;gravityCoefficient=0;inheritedVelFactor=0.2;constantAcceleration=0;lifetimeMS=1000;lifetimeVarianceMS=0;textureName="base/data/particles/cloud";spinSpeed=10;spinRandomMin=-50;spinRandomMax=50;colors[0]="0.4 0.4 0.4 0.5";colors[1]="0.2 0.2 0.2 0";sizes[0]=0.5;sizes[1]=2;useInvAlpha=true;};

datablock ParticleEmitterData(G17bulletExplosionEmitter){uiName="";ejectionPeriodMS=8;periodVarianceMS=0;ejectionVelocity=2;velocityVariance=1;ejectionOffset=0;thetaMin=89;thetaMax=90;phiReferenceVel=0;phiVariance=360;overrideAdvance=false;particles="G17bulletExplosionParticle";};

datablock ParticleData(G17bulletDebrisExplosionParticle){dragCoefficient=0;gravityCoefficient=5;inheritedVelFactor=0.2;constantAcceleration=0;lifetimeMS=1000;lifetimeVarianceMS=500;textureName="base/data/particles/chunk";spinSpeed=10;spinRandomMin=-50;spinRandomMax=50;colors[0]="0.2 0.2 0.2 1";colors[1]="0.2 0.2 0.2 0";sizes[0]=0.2;sizes[1]=0.2;useInvAlpha=true;};

datablock ParticleEmitterData(G17bulletDebrisExplosionEmitter){uiName="";ejectionPeriodMS=3;periodVarianceMS=0;ejectionVelocity=16;velocityVariance=8;ejectionOffset=0;thetaMin=0;thetaMax=30;phiReferenceVel=0;phiVariance=360;overrideAdvance=false;particles="G17bulletDebrisExplosionParticle";};

datablock ParticleData(G17bulletExplosionSmokeParticle : G17bulletExplosionParticle){dragCoefficient=6;gravityCoefficient=0.2;inheritedVelFactor=0;lifetimeMS=1400;lifetimeVarianceMS=200;textureName="base/data/particles/cloud";colors[0]="0.6 0.6 0.6 1";colors[1]="0.6 0.6 0.6 0.2";colors[2]="0.4 0.4 0.4 0";sizes[0]=0.5;sizes[1]=0.6;sizes[2]=5;times[0]=0;times[1]=0.1;times[2]=1;useInvAlpha=true;};

datablock ParticleEmitterData(G17bulletExplosionSmokeEmitter : G17bulletExplosionEmitter){uiName="";ejectionPeriodMS=8;ejectionVelocity=9;velocityVariance=8;thetaMin=0;thetaMax=30;overrideAdvance=false;particles="G17bulletExplosionSmokeParticle";};

datablock ExplosionData(G17bulletExplosion){lifeTimeMS=50;emitter[0]=G17bulletExplosionSmokeEmitter;emitter[1]=G18bulletDebrisExplosionEmitter;faceViewer=true;explosionScale="1 1 1";shakeCamera=true;camShakeFreq="2 2 2";camShakeAmp="2 2 2";camShakeDuration=0.5;camShakeRadius=1;};

datablock ExplosionData(G17RecoilExplosion){lifeTimeMS=1;explosionScale="1 1 1";shakeCamera=true;camShakeFreq="1.0 1.0 1.0";camShakeAmp="0.9 1.0 0.9";camShakeDuration=0.4;camShakeRadius=1;};

datablock ProjectileData(G17Recoil){uiName="";explosion=G18RecoilExplosion;muzzleVelocity=0;velInheritFactor=1;lifetime=1;fadeDelay=1;explodeOnDeath=true;};

datablock ParticleData(G17FlashParticle : G18bulletExplosionParticle){dragCoefficient=0;inheritedVelFactor=1;lifetimeMS=30;textureName="base/data/particles/cloud";spinSpeed=50;spinRandomMin=-500;spinRandomMax=500;colors[0]="1 0.5 0 1";colors[1]="1 0.8 0.6 1";colors[2]="1 0.6 0.3 0";sizes[0]=0.1;sizes[1]=0.5;sizes[2]=0;times[9]=0;times[1]=0.3;times[2]=1;useInvAlpha=false;};

datablock ParticleEmitterData(G17FlashEmitter : G17bulletExplosionEmitter){ejectionPeriodMS=3;ejectionVelocity=50;velocityVariance=0;thetaMin=0;thetaMax=10;particles="G17FlashParticle";uiName="";};

datablock DebrisData(G17ShellDebris){shapeFile="./Models/pistolShell.dts";lifetime=2;minSpinSpeed=-400;maxSpinSpeed=200;elasticity=0.5;friction=0.2;numBounces=3;staticOnMaxBounce=true;snapOnMaxBounce=false;fade=true;gravModifier=2;};

datablock ParticleData(PistolsTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 120;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 0 1";
	colors[1]	= "1 1 0.4 1";
	colors[2]	= "1 1 1 1";
	sizes[0]	= 0.2;
	sizes[1]	= 0.15;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(PistolsTracer)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 30.0;  

   particles = PistolsTrailParticle;

   useEmitterColors = true;
};

AddDamageType("G17",'<bitmap:Add-ons/Weapon_Pistols/CI_G18>%1','%2<bitmap:Add-ons/Weapon_Pistols/CI_G18> %1',0.2,1);

datablock ProjectileData(G17Projectile){uiName="";
projectileShapeName="./Models/modernBullet.dts";
directDamage=35;
directDamageType=$DamageType::G17;
radiusDamageType=$DamageType::G17;brickExplosionRadius=0;
brickExplosionImpact=true;
brickExplosionForce=30;brickExplosionMaxVolume=1;
brickExplosionMaxVolumeFloating=2;
impactImpulse=60;
explosion=G17bulletExplosion;
particleEmitter     = "PistolsTracer";
muzzleVelocity=500;
verInheritFactor=1;
lifetime=4000;
fadeDelay=2000;
bounceElasticity=0.5;
bounceFriction=0.2;
isBallistic=true;
gravityMod=0.55;
sound=G18WhizSound;

};

datablock ItemData(G17Item){uiName="G17";iconName="./G17";

image=G17Image;category=Weapon;className=Weapon;shapeFile="./Models/G17Display.dts";
mass=1;
density=0.2;
elasticity=0;
friction=0.6;
emap=true;
doColorShift=true;
colorShiftColor="1 1 1 1";
canDrop=true;G17reload=1;G17maxmag=16;};
datablock shapeBaseImageData(G17Image){shapeFile="./Models/G17.dts";
emap=true;
correctMuzzleVector=true;className="WeaponImage";
item=G17Item;
ammo="";
projectile=G17Projectile;
projectileType=Projectile;
casing=G17ShellDebris;
shellExitDir="1 0.5 0.5";
shellExitVariance=10;
shellVelocity=6;
melee=false;
doReaction=false;
armReady=true;
doColorShift=true;
colorShiftColor="1 1 1 1";

//#########################################################################################
//#-Sequences-										#
//#											#
//#	fire / fire the weapon								#
//#	reload / reloads the weapon -clipIn and clipOut combined-			#
//#	use / When you equip the weapon -I added this-					#	
//#											#		
//#########################################################################################	
	
	stateName[0]="Activate";
	stateTimeoutValue[0]=0.01;
	stateTransitionOnTimeout[0]="AmmoCheck";
	stateSequence[0]="ready";
	stateSound[0]=G18DeploySound;

	stateName[1]="Ready";
	stateTransitionOnTriggerDown[1]="Fire1";
	stateAllowImageChange[1]=true;
	stateTransitionOnNoAmmo[1]="Empty";
	
	stateName[2]="Fire1";
	stateTransitionOnTimeout[2]="AmmoCheck";
	stateTimeoutValue[2]="0.04";
	stateFire[2]=true;
	stateAllowImageChange[2]=false;
	stateWaitForTimeout[2]=true;
	stateEmitter[2]=G17FlashEmitter;
	stateEmitterTime[2]=0.05;
	stateEmitterNode[2]="muzzlePoint";
	stateSound[2]=G17FireSound;
	stateScript[2]="onFire1";
	stateEjectShell[2]=true;
	stateSequence[2]="Fire";

	stateName[3]="Fire2";
	stateTransitionOnTimeout[3]="AmmoCheck";
	stateTimeoutValue[3]="0.005";
	stateFire[3]=true;
	stateAllowImageChange[3]=false;
	stateWaitForTimeout[3]=true;
	stateEmitter[3]=G17FlashEmitter;
	stateEmitterTime[3]=0.05;
	stateEmitterNode[3]="muzzlePoint";
	stateSound[3]=G17FireSound;
	stateScript[3]="onFire2";
	stateEjectShell[3]=true;
	stateSequence[3]="Fire";
	
    stateName[4]="AmmoCheck";
	stateTransitionOnTriggerUp[4]="Ready";
	stateAllowImageChange[4]=true;
	stateScript[4]="onAmmoCheck";
	
	stateName[5]="Reload";
	stateTimeoutValue[5]=0.8;
	stateSequence[5]="Reload1";
	stateTransitionOnTimeout[5]="Reload2";
	stateWaitForTimeout[5]=true;
	stateSound[5]=G18Reload1Sound;
	stateAllowImageChange[5]=true;

	stateName[9]="Reload2";
	stateTimeoutValue[9]=0.7;
	stateSequence[9]="Reload2";
	stateTransitionOnTimeout[9]="Cock";
	stateWaitForTimeout[9]=true;
	stateSound[9]=G18Reload2Sound;
	stateAllowImageChange[9]=true;
	
	stateName[10]="Cock";
	stateTimeoutValue[10]=1.0;
	stateSequence[10]="Cock";
	stateTransitionOnTimeout[10]="Done";
	stateWaitForTimeout[10]=true;
	stateSound[10]=G18CockSound;
	stateAllowImageChange[10]=true;
	
	stateName[6]="Done";
	stateTransitionOnTimeout[6]="Ready";
	stateTimeoutValue[6]=0.1;
	stateAllowImageChange[6]=true;
	stateScript[6]="onReload";stateName[7]="Empty";
	
	stateTransitionOnTriggerDown[7]="EmptyFire";
	stateAllowImageChange[7]=true;
	stateTransitionOnAmmo[7]="Reload";
	
	stateName[8]="EmptyFire";
	stateTransitionOnTriggerUp[8]="Ready";
	stateTimeoutValue[8]="0.15";
	stateAllowImageChange[8]=false;
	stateWaitForTimeout[8]=true;
	stateSound[8]=G18ClickSound;

};		
	
	datablock shapeBaseImageData(G17ImageScoped : G17Image)
{
	offset = "-0.2 0.3 0"; //-Left +Right, -Back +Front, -Down +Up
   	eyeOffset="0.0 1.5 -0.85"; //-Left +Right, -Back +Front, -Down +Up


	stateName[0]="Activate";
	stateTimeoutValue[0]=0.001;
	stateTransitionOnTimeout[0]="AmmoCheck";
    stateSequence[0]="ready";
	
	stateName[1]="Ready";
	stateTransitionOnTriggerDown[1]="Fire1";
	stateAllowImageChange[1]=true;
	stateTransitionOnNoAmmo[1]="Empty";
	stateSequence[1]="Ready";
	
	stateName[2]="Fire1";
	stateTransitionOnTimeout[2]="AmmoCheck";
	stateTimeoutValue[2]="0.005";
	stateFire[2]=true;
	stateAllowImageChange[2]=false;
	stateWaitForTimeout[2]=true;
	stateEmitter[2]=G17FlashEmitter;
	stateEmitterTime[2]=0.10;
	stateEmitterNode[2]="muzzlePoint";
	stateSound[2]=G17FireSound;
	stateScript[2]="onFire1";
	stateEjectShell[2]=true;
	stateSequence[2]="Fire";
	
	stateName[3]="Fire2";
	stateTransitionOnTimeout[3]="AmmoCheck";
	stateTimeoutValue[3]="0.004";
	stateFire[3]=true;
	stateAllowImageChange[3]=false;
	stateWaitForTimeout[3]=true;
	stateEmitter[3]=G17FlashEmitter;
	stateEmitterTime[3]=0.05;
	stateEmitterNode[3]="muzzlePoint";
	stateSound[3]=G17FireSound;
	stateScript[3]="onFire2";
	stateEjectShell[3]=true;
	stateSequence[3]="Fire";
	
	stateName[4]="AmmoCheck";
	stateTransitionOnTriggerUp[4]="Ready";
	stateAllowImageChange[4]=true;
	stateScript[4]="onAmmoCheck";
	
	stateName[5]="Reload";
	stateTimeoutValue[5]=0.9;
	stateSequence[5]="Reload";
	stateTransitionOnTimeout[5]="Reload2";
	stateWaitForTimeout[5]=true;
	stateSound[5]=G18Reload1Sound;
	stateAllowImageChange[5]=true;
	stateSequence[5]="Reload1";

	stateName[10]="Reload2";
	stateTimeoutValue[10]=0.8;
	stateSequence[10]="Reload2";
	stateTransitionOnTimeout[10]="Cock";
	stateWaitForTimeout[10]=true;
	stateSound[10]=G18Reload2Sound;
	stateAllowImageChange[10]=true;
	
	stateName[11]="Cock";
	stateTimeoutValue[11]=1.0;
	stateSequence[11]="Cock";
	stateTransitionOnTimeout[11]="Done";
	stateWaitForTimeout[11]=true;
	stateSound[11]=G18CockSound;
	stateAllowImageChange[11]=true;

	stateName[6]="Done";
	stateTransitionOnTimeout[6]="Ready";
	stateTimeoutValue[6]=0.1;
	stateAllowImageChange[6]=true;
	stateScript[6]="onReload";

	stateName[7]="Empty";
	stateTransitionOnTriggerDown[7]="EmptyFire";
	stateAllowImageChange[7]=true;
	stateTransitionOnAmmo[7]="Reload";
	stateName[8]="EmptyFire";
	stateTransitionOnTriggerUp[8]="Ready";
	stateTimeoutValue[8]="0.15";
	stateAllowImageChange[8]=false;
	stateWaitForTimeout[8]=true;
	stateSound[8]=G18ClickSound;

	stateName[9]="ReadyWeap";
	stateSequence[9]="Ready";
	stateTimeoutValue[9]=0.95;
	stateSound[9]=G18DeploySound;
	stateTransitionOnTimeout[9]="Ready";

};
   
function G17Image::onAmmoCheck(%this,%obj,%slot)
{
	if(%obj.toolMag[%obj.currTool]<1)
	{	
		%obj.toolMag[%obj.currTool]=0;

	}
	if(%obj.toolMag[%obj.currTool]>%this.item.G17maxmag)
	
	{
		%obj.toolMag[%obj.currTool]=%this.item.G17maxmag;
	
	}
	if(%obj.toolMag[%obj.currTool]<1)
	
	{

		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

}
}
function G17Image::onReload(%this,%obj,%slot)
	
{
	%obj.toolMag[%obj.currTool]=%this.item.G17maxmag;%obj.setImageAmmo(0,1);

}
function G17Image::onFire1(%this,%obj,%slot)

	{
		%obj.toolMag[%obj.currTool]-=1;if(%obj.toolMag[%obj.currTool]<1)

	{
		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

	}
		G17Fire(%this,%obj,%slot,0.0015,1,0.02);

}
function G17Image::onFire2(%this,%obj,%slot)
	{
		%obj.toolMag[%obj.currTool]-=1;

	if(%obj.toolMag[%obj.currTool]<1)
	{
		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

	}
		G17Fire(%this,%obj,%slot,0.0030,1,0.04);
}
	function G17Image::onMount(%this,%obj,%slot)
	
{
	if(%obj.toolMag[%obj.currTool]$="")
	{

		%obj.toolMag[%obj.currTool]=%this.item.G17maxmag;
}

		parent::onMount(%this,%obj,%slot);

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
}
function G17Image::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);
			%obj.unhideNode("ALL");

	if(isObject(%obj.client))
	{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();
	}
	else{applyDefaultCharacterPrefs(%obj);

	}

			%obj.client.setControlCameraFov(90);

}
function G17ImageScoped::onAmmoCheck(%this,%obj,%slot)

{
	if(%obj.toolMag[%obj.currTool]<1)

	{
			%obj.toolMag[%obj.currTool]=0;

	}
	if(%obj.toolMag[%obj.currTool]>%this.item.G17maxmag)

	{
			%obj.toolMag[%obj.currTool]=%this.item.G17maxmag;

	}
	if(%obj.toolMag[%obj.currTool]<1)

	{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

}
}
function G17ImageScoped::onReload(%this,%obj,%slot)

		{
			%obj.toolMag[%obj.currTool]=%this.item.G17maxmag;
			%obj.setImageAmmo(0,1);

}
	function G17ImageScoped::onFire1(%this,%obj,%slot)

		{
			%obj.toolMag[%obj.currTool]-=1;
	
	if(%obj.toolMag[%obj.currTool]<1)
		
		{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

	}
		G17Fire(%this,%obj,%slot,0.0015,1,0.02);

}
function G17ImageScoped::onFire2(%this,%obj,%slot)

{
			%obj.toolMag[%obj.currTool]-=1;

	if(%obj.toolMag[%obj.currTool]<1)

		{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

	}
		G17Fire(%this,%obj,%slot,0.0030,1,0.04);

}
function G17ImageScoped::onMount(%this,%obj,%slot)

{
	if(%obj.toolMag[%obj.currTool]$="")

{

			%obj.toolMag[%obj.currTool]=%this.item.G17maxmag;
}

		parent::onMount(%this,%obj,%slot);
			
			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");

}
function G17ImageScoped::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);

			%obj.unhideNode("ALL");

	if(isObject(%obj.client))

		{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();

		}
			else{applyDefaultCharacterPrefs(%obj);

		}
			%obj.client.setControlCameraFov(90);

}
function G17Projectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)

{
	if(%col.getClassName()$="WheeledVehicle"||%col.getClassName()$="FlyingVehicle")serverPlay3D(G18MetalHitSound,%obj.getTransform());


			else{serverPlay3D(G18HitSound,%obj.getTransform());

	}
		parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);

}
function G17Fire(%this,%obj,%slot,%spread,%shellcount,%recoil)


{
	if(%obj.isCrouched()==1){%spread=%spread-0.001;%recoil=%recoil/2;

}
	if(vectorLen(%obj.getVelocity()) >= 0.1 && !isObject(%obj.getObjectMount()))

		{
			%spread=%spread+0.001;}%vector=%obj.getMuzzleVector(%slot);%p=new Projectile()

{
dataBlock=G17Recoil;initialVelocity=%obj.getVelocity();

	initialPosition=%obj.getEyePoint();
	sourceObject=%obj;sourceSlot=%slot;client=%obj.client;};
	for(%shell=0;%shell<%shellcount;
	%shell++){%x=(getRandom()-0.5)*31.415926*%spread;
	%y=(getRandom()-0.5)*30.415926*%spread;
	%z=(getRandom()-0.5)*30.415926*%spread;
	%p=new Projectile(){dataBlock=G17Projectile;
	initialVelocity=MatrixMulVector(MatrixCreateFromEuler(%x@" "@%y@" "@%z),VectorScale(%obj.getMuzzleVector(%slot),G17Projectile.muzzleVelocity));
	initialPosition=%obj.getMuzzlePoint(%slot);
	sourceObject=%obj;sourceSlot=%slot;
	client=%obj.client;};
	MissionCleanup.add(%p);

}
	if(isObject(%obj.getObjectMount()))

	{
		return %p;}%a=%obj.getTransform();

			%rnd=getRandom(1);if(%rnd==1)

		{
			%recoil=%recoil*-1;

		}
			%obj.setTransform(getWord(%a,0)@" "@getWord(%a,1)@" "@getWord(%a,2)@" "@getWord(%a,3)@" "@getWord(%a,4)@" "@getWord(%a,5)@" "@getWord(%a,6)+%recoil);

	return %p;}package G17

{
function GameConnection::onDeath(%this,%killerPlayer,%killer,%damageType,%damageLoc)

{
		%this.player.client.setControlCameraFov(90);

		parent::onDeath(%this,%killerPlayer,%killer,%damageType,%damageLoc);

}
function Armor::onTrigger(%this,%player,%slot,%val){if(isObject(%player.getMountedImage(0)))

	{
		%item=%player.getMountedImage(0).getName();if((%item $= "G17Image" || %item $= "G17ImageScoped") && %slot $= 4 && %val)

{
	if(%item$="G17Image"){%player.mountImage(G17ImageScoped,0);

			%player.client.setControlCameraFov(80);
}
	if(%item$="G17ImageScoped")

	{
		%player.mountImage(G17Image,0);

			%player.client.setControlCameraFov(90);

		}
		}
		else{parent::onTrigger(%this,%player,%slot,%val);

		}
		}
		else{parent::onTrigger(%this,%player,%slot,%val);

}
}
function Player::pickUp(%this,%item)

	{
			%data=%item.dataBlock;
			%mag=%item.mag;
			%status=parent::pickUp(%this,%item);

	if(!%status==1)

	{
		return %status;}
			%slot=-1;
	
	for(%i=0;%i<%this.dataBlock.maxTools;%i++)


	if(isObject(%this.tool[%i])&&%this.tool[%i].getID()==%data.getID()){%slot=%i;break;
}	

	if(%slot == -1)
	
{
		return %val;

}
	if(%mag $= "")

		{
			%this.toolMag[%slot]=%data.G17maxmag;

		}
			else%this.toolMag[%slot]=%mag;

}
function serverCmdDropTool(%client,%slot)

{
	if(!isObject(%client.player))

	{
		return parent::serverCmdDropTool(%client,%slot);

}
	$weaponMag=%client.player.toolMag[%client.player.currTool];

			%client.player.toolMag[%client.player.currTool]="";

		return parent::serverCmdDropTool(%client,%slot);

}
function ItemData::onAdd(%this,%obj){if($weaponMag!$="")

{
			%obj.mag=$weaponMag;$weaponMag="";

	}
		parent::onAdd(%this,%obj);

}
function serverCmdLight(%client)

	{
		%player=%client.player;

			%image=%player.getMountedImage(0);

	if(%image.item.G17reload)

{
	if(%player.getImageState(0)$="Ready"||%player.getImageState(0)$="Empty")

{
	if(%player.toolMag[%player.currTool]<%image.item.G17maxmag)

{
		%player.setImageAmmo(0,0);

			%player.Schedule(50,setImageAmmo,0,1);

		}
			else{parent::serverCmdLight(%client);

	}
	}
		return;}parent::serverCmdLight(%client);

}
}
;activatePackage(G17);