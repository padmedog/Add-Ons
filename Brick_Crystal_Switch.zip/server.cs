datablock fxDTSBrickData (brickData_LOZcrystalSwitch)
{
	brickFile = "./crystalSwitch.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Crystal Switch";
	iconName = "Add-Ons/Brick_Crystal_Switch/crystalSwitch";
};

datablock fxDTSBrickData (brickData_LOZcrystalSphereSwitch)
{
	brickFile = "./crystalSphereSwitch.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Crystal Sphere Switch";
	iconName = "Add-Ons/Brick_Crystal_Switch/crystalSphereSwitch";
};