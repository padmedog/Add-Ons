datablock WheeledVehicleTire(BlockstangTire:jeepTire)
{
   shapeFile = "./mustangwheel.dts";
};
datablock WheeledVehicleData(BlockstangVehicle:JeepVehicle)
{
	category = "Vehicles";
	uiname="Blockstang";
	numMountPoints = 2;
	displayName = " ";
	defaultTire	= BlockstangTire;
	shapeFile = "./mustang.dts"; 
	handsOnVehicle=1;
};
function MustangVehicle::onAdd(%this,%obj)
{
   Parent::onAdd(%this,%obj);
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}