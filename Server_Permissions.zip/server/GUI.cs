getPermissionManager().registerPermission("Modify Permissions", "permissions.modify", 3);
getPermissionManager().registerPermission("List all roles (and members)", "permissions.roles.list", 0);

function niceStringifiedPermissionRole(%role, %people) {
	%total = "\c2* \c3" @ %role SPC "\c2 -";

	%peopleCount = getFieldCount(%people);
	for (%i = 0 ; %i < %peopleCount ; %i++) {
		%person = getField(%people, %i);
		%name = getPermissionManager().getNameCache().getNameForBL_ID(%person);
		%personRecord = " \c6" @ %person @ (%name !$= "" ? " \c3-\c6" SPC %name : "") @ "\c7,";

		%total = %total @ %personRecord;
	}

	return trim(getSubStr(%total, 0, strLen(%total) - 2));
}

function serverCmdListRoles(%cl) {
	if (!%cl.hasPermission("permissions.roles.list"))
		return;

	%pm = getPermissionManager();

	for (%i = 0; %i < %pm.knownClientCount; %i++) {
		%blid = %pm.knownClient[%i];
		%role = %pm.getRoleByClientBL_ID(%blid).name;
		%roleMembers[%role] = %roleMembers[%role] TAB %blid;
	}

	%pm = getPermissionManager();
	for (%i = 0 ; %i < %pm.roleCount ; %i++) {
		%role = %pm.role[%i].name;
		%roleMessage = niceStringifiedPermissionRole(%role, trim(%roleMembers[%role]));

		messageClient(%cl, '', %roleMessage);
	}
}

function servercmdPermGui(%client, %arg1, %arg2, %arg3, %arg4)
{
	if(!%client.hasPermission("permissions.modify") && %client.getAdminLevel() >= 3)
		return;

	if(%arg1 $= "SETPERM")
	{
		%roleName = %arg2;
		%permName = %arg3;
		%value = %arg4;
		%roleSO = getPermissionManager().getRole(%roleName);
		
		%roleSO.setPermission(%permName, %value);
	}
	else if(%arg1 $= "SETROLE")
	{
		if(%arg2 !$= "")
		{
			getPermissionManager().setRoleByClientBL_ID(%arg2, getPermissionManager().getRole(%arg3));
			if(%client.PermGui_viewingRole !$= "")
				servercmdPermGui(%client, "GETPLAYERS", %client.PermGui_viewingRole);
		}

	}
	else if(%arg1 $= "GETPERM")
	{
		%roleSO = getPermissionManager().getRole(%arg2);
		commandtoclient(%client, 'permgui', "VALUE", %roleSO.hasPermission(%arg3, false));
	}
	else if(%arg1 $= "NEWROLE")
	{
		if(%arg2 !$= "")
			getPermissionManager().createRole(%arg2);
	}
	else if(%arg1 $= "DELROLE")
	{
		if(%arg2 !$= "")
			getPermissionManager().deleteRole(%arg2);		
	}
	else if(%arg1 $= "GETPLAYERS")
	{
		if(%arg2 !$= "")
		{
			%client.PermGui_viewingRole = %arg2;
			%pm = getPermissionManager();
			commandtoclient(%client, 'permgui', "CLEAR", "PLAYERS");
			for (%i = 0; %i < %pm.knownClientCount; %i++)
			{
				%blid = %pm.knownClient[%i];
       			if(%pm.getRoleByClientBL_ID(%blid).name $= %arg2)
       				commandtoclient(%client, 'permgui', "PLAYER", %blid, %pm.getNameCache().getNameForBL_ID(%blid));
   			}
		}
	}
}

function PermGui_sendInfo(%client)
{
	commandtoclient(%client, 'permgui', "CLEAR");
	if(%client.hasPermission("permissions.modify") || %client.blid == getNumKeyId())
	{
		for(%i = 0; %i < getPermissionManager().roleCount; %i++)
		{
			%role = getPermissionManager().role[%i];
			commandtoclient(%client, 'permgui', "ROLE", %role.name);
		}
		for(%j = 0; %j < $Permissions::PermissionCount; %j++)
		{
			commandtoclient(%client, 'permgui', "PERM", $Permissions::PermissionFriendlyName[%j] TAB $Permissions::PermissionName[%j]);
		}
	}
}

package PermissionsGUIServer
{
	function GameConnection::autoAdminCheck(%client)
	{
		PermGui_sendInfo(%client);
		return parent::autoAdminCheck(%client);        
	}
}; activatePackage(PermissionsGUIServer);
