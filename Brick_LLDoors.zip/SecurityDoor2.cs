datablock fxDTSBrickData ( brickSecurityDoorOpenCWData )
{
	brickFile = "./SecurityDooropenCW.blb";
	uiName = "Security Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickSecurityDoorCWData";
	openCW = "brickSecurityDoorOpenCWData";
	
	closedCCW = "brickSecurityDoorCWData";
	openCCW = "brickSecurityDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickSecurityDoorOpenCCWData : brickSecurityDoorOpenCWData )
{
	brickFile = "./SecurityDooropenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickSecurityDoorCWData : brickSecurityDoorOpenCWData )
{
	brickFile = "./SecurityDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/SecurityDoor";
	
	isOpen = 0;
};