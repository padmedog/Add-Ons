datablock TSShapeConstructor(WHProneDts)
{
	baseShape  = "base/data/shapes/player/m.dts";
	sequence0  = "base/data/shapes/player/m_sit.dsq root";

	sequence1  = "base/data/shapes/player/m_sit.dsq run";
	sequence2  = "base/data/shapes/player/m_sit.dsq walk";
	sequence3  = "base/data/shapes/player/m_sit.dsq back";
	sequence4  = "base/data/shapes/player/m_sit.dsq side";

	sequence5  = "base/data/shapes/player/m_sit.dsq crouch";
	sequence6  = "base/data/shapes/player/m_sit.dsq crouchRun";
	sequence7  = "base/data/shapes/player/m_sit.dsq crouchBack";
	sequence8  = "base/data/shapes/player/m_sit.dsq crouchSide";

	sequence9  = "base/data/shapes/player/m_sit.dsq look";
	sequence10 = "base/data/shapes/player/m_sit.dsq headside";
	sequence11 = "base/data/shapes/player/m_sit.dsq headUp";

	sequence12 = "base/data/shapes/player/m_sit.dsq jump";
	sequence13 = "base/data/shapes/player/m_sit.dsq standjump";
	sequence14 = "base/data/shapes/player/m_sit.dsq fall";
	sequence15 = "base/data/shapes/player/m_sit.dsq land";

	sequence16 = "base/data/shapes/player/m_sit.dsq armAttack";
	sequence17 = "base/data/shapes/player/m_armreadyleft.dsq armReadyLeft";
	sequence18 = "base/data/shapes/player/m_armreadyright.dsq armReadyRight";
	sequence19 = "base/data/shapes/player/m_armreadyboth.dsq armReadyBoth";
	sequence20 = "base/data/shapes/player/m_sit.dsq spearready";  
	sequence21 = "base/data/shapes/player/m_sit.dsq spearThrow";

	sequence22 = "base/data/shapes/player/m_sit.dsq talk";  

	sequence23 = "base/data/shapes/player/m_death1.dsq death1"; 
	
	sequence24 = "base/data/shapes/player/m_sit.dsq shiftUp";
	sequence25 = "base/data/shapes/player/m_sit.dsq shiftDown";
	sequence26 = "base/data/shapes/player/m_sit.dsq shiftAway";
	sequence27 = "base/data/shapes/player/m_sit.dsq shiftTo";
	sequence28 = "base/data/shapes/player/m_sit.dsq shiftLeft";
	sequence29 = "base/data/shapes/player/m_sit.dsq shiftRight";
	sequence30 = "base/data/shapes/player/m_sit.dsq rotCW";
	sequence31 = "base/data/shapes/player/m_sit.dsq rotCCW";

	sequence32 = "base/data/shapes/player/m_sit.dsq undo";
	sequence33 = "base/data/shapes/player/m_sit.dsq plant";

	sequence34 = "base/data/shapes/player/m_sit.dsq sit";

	sequence35 = "base/data/shapes/player/m_sit.dsq wrench";

   sequence36 = "base/data/shapes/player/m_sit.dsq activate";
   sequence37 = "base/data/shapes/player/m_sit.dsq activate2";

   sequence38 = "base/data/shapes/player/m_sit.dsq leftrecoil";
};   
datablock PlayerData(WHproneArmor : PlayerStandardArmor)
{
	firstPersonOnly=0;

   runForce = 10 * 180;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;

   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;
   
   minLookAngle = -1.5708;
  maxLookAngle = 1.5708;
  // maxFreelookAngle = 3.0;
   jumpForce = 0 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;


	uiName = "";
	showEnergyBar = false;

   runSurfaceAngle  = 45;
   jumpSurfaceAngle = 45;
   
   crouchBoundingBox = PlayerStandardArmor.boundingBox;
};
