// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-------------------------------------------+

$Slayer::Client::Debug = 0;

// +-----------------------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

if(isObject(SlayerClient))
	SlayerClient.delete();

$Slayer::Version = "3.9.4+release-20151024";

$Slayer::Client::Version = $Slayer::Version;
$Slayer::Client::CompatibleVersion = "3.9.0+release-20140829";

$Slayer::Platform = "Client";

$Slayer::Path = filePath(expandFileName("./client.cs"));
$Slayer::Common::Path = $Slayer::Path @ "/common";
$Slayer::Client::Path = $Slayer::Path @ "/client";

$Slayer::Common::ConfigDir = "config/common/Slayer";
$Slayer::Client::ConfigDir = "config/client/Slayer";

$Slayer::Client::FirstRun = !isFile($Slayer::Client::ConfigDir @ "/config_last.cs");

// +------+
// | Core |
// +------+
exec($Slayer::Common::Path @ "/main.cs"); //load common scripts
exec($Slayer::Client::Path @ "/main.cs"); //load client scripts

// +----------+
// | KeyBinds |
// +----------+
//remove the old keybind from pre v3.0
SlayerClient_Support::removeKeyBind("Slayer","Setup","SlayerClient_pushSetup");

//add keybinds
SlayerClient_Support::addKeyBind("Slayer","Edit Minigame","SlayerClient_pushMain");
SlayerClient_Support::addKeyBind("Slayer","Options","SlayerClient_pushOptions");

// +-----------------+
// | Blockland Glass |
// +-----------------+
if(isObject(BLG_DT))
{
	BLG_DT.registerImageIcon("Slayer Options","canvas.pushDialog(Slayer_Options);",$Slayer::Client::Path @ "/resources/images/logo_icon.png");
}

// +--------------+
// | Fully Loaded |
// +--------------+
warn("Slayer Version" SPC $Slayer::Client::Version);