datablock fxDTSBrickData(brickIndusLightData)
{
	brickFile = "./Brick_Light.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Industrial Light";
	iconName = "Add-Ons/Brick_indusLight/icon";
};