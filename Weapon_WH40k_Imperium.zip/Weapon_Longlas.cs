datablock AudioProfile(LonglasFireSound)
{
   filename    = "./longlas_shot.wav";
   description = AudioClose3d;
   preload = true;
};


//////////
// item //
//////////
datablock ItemData(LonglasItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Longlas.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Long-las";
	iconName = "./Longlas";
	doColorShift = false;
	colorShiftColor = "0.4 0.43 0.42 1.000";

	 // Dynamic properties defined by the scripts
	image = LonglasImage;
	canDrop = true;
    
   //Ammo Guns Parameters
   maxAmmo = 10;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(LonglasImage)
{
   raycastWeaponRange = 400;
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = LasrifleExplosionProjectile;
   raycastTracerProjectile = LasrifleTracerProjectile;
   raycastCritTracerProjectile = LasrifleTracerProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastCritDirectDamageType = $DamageType::Lasrifle;
   raycastDirectDamage = 100; //Varies
   raycastDirectDamageType = $DamageType::Lasrifle;
   raycastSpreadAmt = 0; //Varies

   // Basic Item properties
	shapeFile = "./Longlas.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = LonglasItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   minShotTime = 1450;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = false;
   colorShiftColor = LonglasItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.2;
	stateSequence[0]			  = "Activate";
	stateSound[0]			  = weaponSwitchSound;
	stateTransitionOnTimeout[0]     = "Ready";

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Wait2";
	stateTimeoutValue[2]            = 0.1;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
	stateEmitter[2]			  = gunFlashEmitter;
	stateEmitterTime[2]		  = 0.05;
	stateEmitterNode[2]		  = "muzzleNode";
	stateSound[2]			  = LonglasFireSound;

	stateName[3] 			  = "Smoke";
	stateEmitter[3]			  = gunSmokeEmitter;
	stateEmitterTime[3]		  = 0.1;
	stateEmitterNode[3]		  = "muzzleNode";
	stateSequence[3]			  = "eject";
	stateTimeoutValue[3]            = 0.75;
	stateTransitionOnTimeout[3]     = "Wait3";


	stateName[12] 			  = "Wait2";
	stateTimeoutValue[12]            = 0.1;
	stateTransitionOnTimeout[12]     = "Smoke";

	stateName[13] 			  = "Wait3";
	stateTimeoutValue[13]            = 0.1;
	stateTransitionOnTimeout[13]     = "Ready";
};

function LonglasImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);

   %obj.lastFireTime = getSimTime() - 500;
}

function LonglasImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
	if((%obj.lastFireTime+%this.minShotTime) > getSimTime())
	{
		%thread = "plant";
		%this.raycastExplosionProjectile = LasrifleExplosionProjectile;
		%this.raycastSpreadAmt = ((%obj.lastFireTime+%this.minShotTime) - getSimTime())/%this.minShotTime*0.005;
		%this.raycastDirectDamage = 35;
	}
	else
	{
		%thread = "plant";
		%this.raycastExplosionProjectile = LasrifleExplosionProjectile;
		%this.raycastSpreadAmt = 0;
		%this.raycastDirectDamage = 35;
	}
	Parent::onFire(%this,%obj,%slot);
}
	

function LonglasImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(%this.raycastSpreadAmt > 0)
      return 0;
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}
