//audio

AddDamageType("PopGun",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_PopGun> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_PopGun> %1',0.75,1);
datablock ProjectileData(PopGunProjectile1)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 12;
   directDamageType    = $DamageType::PopGun;
   radiusDamageType    = $DamageType::PopGun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 20;
   verticalImpulse     = 10;
   explosion           = gunExplosion;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.5;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock DebrisData(PopGunShellDebris)
{
	shapeFile = "./PopGunShell.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};


//////////
// item //
//////////
datablock ItemData(PopGunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./PopGun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Pop-Gun";
	iconName = "./icon_PopGun";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = PopGunImage;
	canDrop = true;
	
	maxAmmo = 6;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(PopGunImage)
{
   // Basic Item properties
   shapeFile = "./PopGun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = PopGunItem;
   ammo = " ";
   projectile = PopGunProjectile1;
   projectileType = Projectile;

   casing = PopGunShellDebris;
   shellExitDir        = "-1.0 1.0 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = PopGunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= PGFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.025; //0.05
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[4]              = true;
        stateSequence[4]		= "Flap";
        stateTimeoutValue[4]		= 0.1; //0.2
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 1.1;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.3;
	stateScript[9]				= "onReloaded";
        stateTransitionOnTimeout[9]		= "Ready";
};

function PopGunImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>21 Gauge Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["21Gauge"] @ "", 1, 2, 3, 4); 
}

function PopGunImage::onFire(%this,%obj,%slot)
{
	%projectile = PopGunProjectile1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1)
	{
		%spread = 0.002; //0.00025
	}
	else
	{
		%spread = 0.0025; //0.0025
	}
	
	%shellcount = 4;

	%obj.playThread(2, shiftaway);
	%shellcount = 4;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>21 Gauge Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["21Gauge"] @ "", 4, 2, 3, 4); 

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function PopGunImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>21 Gauge Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["21Gauge"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["21Gauge"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function PopGunImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["21Gauge"] >= 1)
	{

	%obj.playThread(2, plant);
        if(%obj.client.quantity["21Gauge"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["21Gauge"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
            serverPlay3D(FWReload1Sound,%obj.getPosition());
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>21 Gauge Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["21Gauge"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["21Gauge"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["21Gauge"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
            serverPlay3D(PGReloadSound,%obj.getPosition());
		%obj.client.quantity["21Gauge"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>21 Gauge Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["21Gauge"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}

//statescript onBounce