//Add our events in...
registerOutputEvent("Player","SetVignette","paintcolor 0" TAB "float 0 1 0.05 1" TAB "bool");
registerOutputEvent("Player","ResetVignette");

//Event functions...
function Player::SetVignette(%this,%paint,%slider,%multiply)
	{
		%client = %this.client; //Get client of the player who activates the event
		%RGB = getColorIdTable(%paint); //Turns the color ID to an RGB color.
		%RGB = getWord(%RGB,0) SPC getWord(%RGB,1) SPC getWord(%RGB,2) SPC %slider; //Removes alpha from RGB so we can add our own.
		commandToClient(%client,'setVignette',%multiply,%RGB); //Set Vignette for the player who activates this event.
	}
	
function Player::ResetVignette(%this)
	{
		%client = %this.client;
		commandToClient(%client,'setVignette',$EnvGuiServer::VignetteMultiply,$EnvGuiServer::VignetteColor); //Sets the player who activates this event back to the server's vignette settings.
	}