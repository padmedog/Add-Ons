$starboundmessage=1;
$starboundmin=10000;
$starboundmax=30000;
schedule(30000, 0, starboundloop);

function starboundloop()
{
	if($starboundmessage)
	{
	for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
			%client = clientGroup.getObject(%i);
			if(!%client.optoutstarbound)
			{
				messageclient(%client, '', "Pre-Order Starbound today! Click <a:playstarbound.com/store>here!</a> \c3Do /nostarbound to stop seeing this message.");
			}
			if(%i > clientGroup.getCount())
			{
				break;
			}
		}
		schedule(getrandom($starboundmin, $starboundmax), 0, starboundloop);
		
	}
	else
	{
		schedule(getrandom($starboundmin, $starboundmax), 0, starboundloop);
	}
	
}

function servercmdtogglestarboundmessage(%client)
{
	if(%client.isadmin)
	{
		if($starboundmessage)
		{
			$starboundmessage=0;
			messageclient(%client, '', "Starbound message spam disabled.");
		}
		else
		{
			$starboundmessage=1;
			messageclient(%client, '', "Starbound message spam enabled.");
		}
	}
}

function servercmdnostarbound(%client)
{
	if(!%client.optoutstarbound)
	{
		%client.optoutstarbound=1;
	}
}

function servercmdsetstarboundtimer(%client, %min, %max)
{
	if(%client.isadmin)
	{
		if(%min<%max)
		{
			$starboundmin = %min;
			$starboundmax = %max;
		}
		else
		{
			$starboundmin = %min;
			$starboundmax = %min;
		}
	}
}