%this = new PhysicalZone(AdjustableZone)
{
	position = "-500 500 -500";
	rotation = "1 0 0 0";
	scale = "9999 9999 9999";
	velocityMod = "1";
	gravityMod = "0";
	extraDrag = "0";
	isWater = "0";
	waterViscosity = "40";
	waterDensity = "1";
	waterColor = "0.200000 0.600000 0.600000 0.300000";
	appliedForce = "0 0 0";
	polyhedron = "0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 -1.0000000 0.0000000 0.0000000 0.0000000 1.0000000";
};
missiongroup.add(%this);

function servercmdsetgravity(%client, %val)
{
	if(!%client.isAdmin || !isobject(AdjustableZone))
		return;

	%val *= 1; //makes it a number

	AdjustableZone.gravityMod = %val;
	messageall('', "\c4"@ %client.name @"\c6 has changed the gravity to \c0"@ %val);
}
