//PACNET2012 & credit of height script to Bushido
$GroundDelete::Security = 3;

$GroundOn = true; 
function serverCmdGroundPerm(%client, %level)
{
    if(%client.bl_id == getnumkeyid())
    {
        if(%level == 1)
        {
            %client.chatMessage("<font:impact:30><color:00ff00>The Ground Remove / Add security is set to <color:FFFF00>Admin.");
            $GroundDelete::Security = %level;
        }
        if(%level == 2)
        {
            %client.chatMessage("<font:impact:30><color:00ff00>The Ground Remove / Add security is set to <color:FFFF00>Super Admin.");
            $GroundDelete::Security = %level;
        }
        if(%level == 3)
        {
            %client.chatMessage("<font:impact:30><color:00ff00>The Ground Remove / Add security is set to <color:FFFF00>Host Only. That [should be] you!");
            $GroundDelete::Security = %level;
        }
    }
}

function serverCmdToggleGround(%client)
{
    if($GroundDelete::Security == 1)
    {
        if(%client.isAdmin) 
        {
            if($GroundOn)
            {
                groundPlane.delete();  
                $GroundOn = false;
            }
            else if(!$GroundOn)
            {
                makeGP();
                $GroundOn = true;
            }
        }
        else
        {
            %client.chatMessage("<font:impact:30><color:00ff00>The Ground Remove / Add security is set to <color:FFFF00>Admin.");  
        }
    }
    else if($GroundDelete::Security == 2)
    {
        if(%client.isSuperAdmin) 
        {
            if($GroundOn)
            {
                groundPlane.delete();
                $GroundOn = false;
            }
            else if(!$GroundOn)
            {
                makeGP();
                $GroundOn = true;
            }
        }
        else
        {
            %client.chatMessage("<font:impact:30><color:00ff00>The Ground Remove / Add security is set to <color:FFFF00>Super Admin.");  
        }
    }
    else if($GroundDelete::Security == 3)
    {
        if(%client.bl_id == getnumkeyid()) 
        {
            if($GroundOn)
            {
                groundPlane.delete();
                echo( "<color:FFFF00>The Host<color:FF0000> removed the ground.");   
                $GroundOn = false;
            }
            else if(!$GroundOn)
            {
                makeGP();
                echo( "<color:FFFF00>The Host<color:FF0000> re-added the ground.");
                $GroundOn = true;
            }
        }
        else
        {
            %client.chatMessage("<font:impact:30><color:00ff00>The Ground Remove / Add security is set to <color:FFFF00>Host only.");  
        }
    }
}

function serverCmdGroundHelp(%client)
{
    %client.chatMessage("<font:impact:30><color:FFFFFF>You can remove or re-add the server's ground using /toggleGround.");  
    %client.chatMessage("<font:impact:30><color:FFFFFF>The host can set what group is allowed to do so (Admin, Super Admin, or only the Host)"); 
    %client.chatMessage("<font:impact:30><color:FFFFFF>The host can set what groups are allowed using /groundPerm [level]");   
    %client.chatMessage("<font:impact:30><color:FFFFFF>[level] is either 1 for Admin, 2 for SA, or 3 for Host-Only. /groundPerm 2 would make it SA, for example.");  
    %client.chatMessage("<font:impact:30><color:FFFFFF>A die-when-you-get-too-far-under the server mod will be added soon.");  
    %client.chatMessage("<font:impact:30><color:FFFFFF>^ V You may Page Up or Page Down to view these instructions.");  
}

//bushido's height script
$minHeight = -100;
 
function heightCheck()
{
        for(%i = 0; %i < ClientGroup.getCount(); %i++)
        {
                %cl = ClientGroup.getObject(%i);
                if(isObject(%cl.player) && getWord(%cl.player.getPosition(), 2) < $minHeight)
                        %cl.player.kill();
        }
       
        if(!isEventPending($heightCheckSched))
                $heightCheckSched = schedule(500, 0, "heightCheck");
}
 
heightCheck();

function makeGP()
{
new fxPlane(groundPlane) {
   position = "0 0 -0.5";
   rotation = "1 0 0 0";
   scale = "1 1 1";
   topTexture = "Add-Ons/Ground_Plate/plate.png";
   bottomTexture = "Add-Ons/Ground_Plate/plate.png";
   loopsPerUnit = "2";
   scrollSpeed = "0.000000 0.000000";
   color = "0 128 64 255";
   rayCastColor = "128 128 128 255";
   blend = "0";
   additiveBlend = "0";
   colorMultiply = "0";
   isSolid = "1";
};
}
