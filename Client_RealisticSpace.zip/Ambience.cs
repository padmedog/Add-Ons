$RSC::Revision += 4;
$RSC::AmbVolume = 2;

//Credits:
//    A few minutes of space ambience.ogg - Squideey

function RSC_Ambience()
{
	cancel($RSC::Ambience);
	if($RSC::AmbienceCount == 0) return;
	%index = getRandom(0, $RSC::AmbienceCount - 1);
	%file = $RSC::Ambience[%index]; %audio = $RSC::Ambience_[%file];
	$RSC::Ambience = schedule(alxGetWaveLen(%file), 0, "RSC_Ambience");
	for(%i=0;%i<$RSC::AmbVolume;%i++)
		$RSC::AmbHandle[%i] = alxPlay(%audio, 1);
}

function RSC_FindAmbience()
{
	%file = findFirstFile("Add-Ons/Client_RealisticSpace/Ambience/*.wav");
	while(%file !$= "")
	{
		$RSC::Ambience[-1+$RSC::AmbienceCount++] = %file;
		$RSC::Ambience_[%file] = new AudioProfile()
		{
			description = "AudioGUI";
			filename = %file;
		};
		%file = findNextFile("Add-Ons/Client_RealisticSpace/Ambience/*.wav");
	}
}
//if($RSC::AmbienceCount == 0)
//	RSC_FindAmbience();   //Doesn't work properly yet :(