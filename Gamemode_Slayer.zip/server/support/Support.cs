// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+


// +-------------------------+
// | Stuff for finding stuff |
// +-------------------------+

function Slayer_Support::getClientFromObject(%obj)
{
	if(!isObject(%obj))
		return -1;

	//generic stuff
	if(isObject(%obj.client))
		return %obj.client;
	if(isObject(%obj.sourceClient))
		return %obj.sourceClient;

	//special cases
	%class = %obj.getClassName();
	if(%class $= "GameConnection" || %class $= "AiConnection")
		%client = %obj;
	else if(%class $= "AiPlayer" || striPos(%class,"Vehicle") >= 0)
		%client = %obj.getControllingObject().client;
	else if(%class $= "fxDtsBrick")
		%client = %obj.getGroup().client;

	if(isObject(%client))
		return %client;

	return -1;
}

function Slayer_Support::getBLIDFromObject(%obj)
{
	if(!isObject(%obj))
		return -1;

	if(%obj.bl_id !$= "")
		return %obj.bl_id;

	%class = %obj.getClassName();

	if(%class $= "GameConnection")
		return %obj.getBLID();
	if(%class $= "Player" && isObject(%obj.client))
		return %obj.client.getBLID();
	if(%class $= "fxDtsBrick" && isObject(%obj.getGroup()))
		return %obj.getGroup().bl_id;
	if(Slayer_Support::isVehicle(%obj) && isObject(%obj.brickGroup))
		return %obj.brickGroup.bl_id;
	if(%class $= "Item")
	{
		if(isObject(%obj.spawnBrick))
			return %obj.spawnBrick.getGroup().bl_id;
	}
	if(%obj.class $= "Slayer_MinigameSO")
		return %obj.creatorBLID;

	return -1;
}

function Slayer_Support::getBlocklandID()
{
	if($Server::LAN)
		return getLAN_BLID();
	else
		return getNumKeyID();
}

// +-------+
// | Debug |
// +-------+

function Slayer_Support::Debug(%level,%title,%value)
{
	if($Slayer::Server::Debug == -1)
		return;

	if(%value $= "")
		%val = %title;
	else
		%val = %title @ ":" SPC %value; 

	if(%level <= $Slayer::Server::Debug)
		echo("\c4Slayer (Server):" SPC %val);

	%path = $Slayer::Server::ConfigDir @ "/debug_server.log";
	if(isWriteableFileName(%path))
	{
		if(!isObject(Slayer.DebugFO))
		{
			Slayer.debugFO = new fileObject();
			Slayer.add(Slayer.debugFO);

			Slayer.debugFO.openForWrite(%path);
			Slayer.debugFO.writeLine("//Slayer Version" SPC $Slayer::Server::Version SPC "-----" SPC getDateTime());
			Slayer.debugFO.writeLine("//By Greek2me, Blockland ID 11902");
		}

		Slayer.debugFO.writeLine(%val);
	}
}

function Slayer_Support::Error(%title,%value)
{
	if(%value $= "")
		%val = %title;
	else
		%val = %title @ ":" SPC %value; 

	error("Slayer Error (Server):" SPC %val);

	%path = $Slayer::Server::ConfigDir @ "/debug_server.log";
	if(isWriteableFileName(%path))
	{
		if(!isObject(Slayer.DebugFO))
		{
			Slayer.debugFO = new fileObject();
			Slayer.add(Slayer.debugFO);

			Slayer.debugFO.openForWrite(%path);
			Slayer.debugFO.writeLine("//Slayer Version" SPC $Slayer::Server::Version SPC "-----" SPC getDateTime());
			Slayer.debugFO.writeLine("//By Greek2me, Blockland ID 11902");
		}

		Slayer.debugFO.writeLine("ERROR:" SPC %val);
	}
}

// +-------+
// | Other |
// +-------+

function Slayer_Support::isVehicle(%obj)
{
	if(!isObject(%obj))
		return 0;

	if(!isFunction(%obj.getClassName(),"getDatablock"))
		return 0;

	if((%obj.getType() & $TypeMasks::VehicleObjectType) || %obj.getDatablock().numMountPoints > 0)
		return 1;
	else
		return 0;
}