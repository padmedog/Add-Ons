$RSC::Revision += 3;

package MoveInds
{
	function clientcmdBottomPrint(%text, %time, %box)
	{
		Parent::clientcmdBottomPrint(%text, %time, %box);
		if(strPos(%text, "Relative to ") != -1)
		{
			if(!isObject(%cl = ServerConnection)) return;
			if(!isObject(%pl = %cl.getControlObject())) return;
			%ind = strPos(%text, "Position: ");
			%relPos = getWords(getSubStr(%text, %ind, strLen(%text) - %ind), 1, 3);
			%fore = %pl.getForwardVector();
			%right = vectorCross(%fore, "0 0 1");
			$MoveInds::TargetPos = vectorAdd(vectorAdd(vectorScale(%fore, getWord(%relPos, 0)),
				vectorScale(%right, getWord(%relPos, 1))), vectorScale("0 0 -1", getWord(%relPos, 2)));
		}
		else $MoveInds::TargetPos = "";
	}
	
	function disconnect(%a)
	{
		if(isObject(RSC_DirMarkers))
		{
			%markers = RSC_DirMarkers.getCount();
			for(%i=%markers-1;%i>=0;%i--)
			{
				%marker = RSC_DirMarkers.getObject(%i);
				if(isObject(%text = %marker.textObj)) %text.delete();
				%marker.delete();
			}
		}
		return parent::disconnect(%a);
	}
};
activatePackage("MoveInds");

function mEulerToAxis(%euler)
{
	 %euler = VectorScale(%euler, 0.0174533);
	 %matrix = MatrixCreateFromEuler(%euler);
	 return getWords(%matrix, 3, 6);
}

if(isObject(ProgradeMarker))
	ProgradeMarker.delete();
new GuiBitmapCtrl(ProgradeMarker)
{
	bitmap = Crosshair.bitmap;
	position = "-32 -32";
	extent = "32 32";
};

if(isObject(RetrogradeMarker))
	RetrogradeMarker.delete();
new GuiBitmapCtrl(RetrogradeMarker)
{
	bitmap = Crosshair.bitmap;
	position = "-32 -32";
	extent = "32 32";
};

function showDirectionMarkers()
{
	cancel($ShowDirectionMarkers);
	if(!isObject(%cl = ServerConnection) || !isObject(%pl = %cl.getControlObject())
		|| %pl.getClassName() !$= "Player" || %pl.getState() $= "DEAD")
	{
		ProgradeMarker.setVisible(0);
		RetrogradeMarker.setVisible(0);
		if(isObject(RSC_DirMarkers))
		{
			%markers = RSC_DirMarkers.getCount();
			for(%i=0;%i<%markers;%i++)
			{
				%marker = RSC_DirMarkers.getObject(%i);
				if(isObject(%text = %marker.textObj))
					%text.setVisible(0);
				%marker.setVisible(0);
			}
		}
		$ShowDirectionMarkers = schedule(16, 0, "showDirectionMarkers"); return;
	}
	%dir = vectorNormalize(%vel = %pl.getVelocity());
	%muzzle = %pl.getMuzzleVector(0); %fore = %pl.getForwardVector();
	%yaw = mAtan(getWord(%fore, 0), getWord(%fore, 1)) + 3.14159265; if(%yaw >= 3.14159265) %yaw -= 6.2831853;
	%eyeTrans = "0 0 0 "@mEulerToAxis(mAsin(vectorDot(vectorNormalize(%muzzle), "0 0 1"))*-57.2958@" 0 "@%yaw*-57.2958);
	if(!PlayGUI.isMember(ProgradeMarker)) PlayGUI.add(ProgradeMarker);
	if(!PlayGUI.isMember(RetrogradeMarker)) PlayGUI.add(RetrogradeMarker);
	ProgradeMarker.setVisible(!$RSC::HideVelIndicators && vectorDot(%dir, %muzzle) > 0.025);
	RetrogradeMarker.setVisible(!$RSC::HideVelIndicators && vectorDot(%dir, %muzzle) < -0.025);
	%fov = ServerConnection.getControlCameraFOV();
	%proScreenPos = worldToScreen(%eyeTrans, %dir, %res = getRes(), %fov);
	ProgradeMarker.resize(getWord(%proScreenPos, 0) - 16, (getWord(%res, 1) - getWord(%proScreenPos, 1)) - 16, 32, 32);
	%retScreenPos = worldToScreen(%eyeTrans, vectorScale(%dir, -1), %res, %fov);
	RetrogradeMarker.resize(getWord(%retScreenPos, 0) - 16, (getWord(%res, 1) - getWord(%retScreenPos, 1)) - 16, 32, 32);
	if(isObject(RSC_DirMarkers))
	{
		%pos = vectorAdd(%pl.getPosition(), (%pl.isCrouched() ? "0 0 0.627" : "0 0 2.156"));
		%markers = RSC_DirMarkers.getCount();
		for(%i=0;%i<%markers;%i++)
		{
			%marker = RSC_DirMarkers.getObject(%i);
			%dir = vectorNormalize(vectorSub(%marker.worldPos, %pos));
			%marker.setVisible(vectorDot(%dir, %muzzle) > 0.025);
			%markScreenPos = worldToScreen(%eyeTrans, %dir, %res, %fov);
			%marker.resize(getWord(%markScreenPos, 0) - 16, (getWord(%res, 1) - getWord(%markScreenPos, 1)) - 16, 32, 32);
			if(!PlayGUI.isMember(%marker)) PlayGUI.add(%marker);
			if(!isObject(%text = %marker.textObj))
			{
				PlayGUI.add(%marker.textObj = (%text = new GuiMLTextCtrl()
				{ text = ColorToTag(%marker.getColor())@%marker.screenText; }));
			}
			%text.resize(getWord(%marker.position, 0) + 25, getWord(%marker.position, 1) + 9, 128, getWord(%text.extent, 1));
			%text.setVisible(vectorDot(%dir, %muzzle) > %marker.textAng);
		}
	}
	ProgradeMarker.setColor("0 1 0 "@(getMin(vectorLen(%vel), 2.5) / 2.5));
	RetrogradeMarker.setColor("1 0 0 "@(getMin(vectorLen(%vel), 2.5) / 2.5));
	$ShowDirectionMarkers = schedule(16, 0, "showDirectionMarkers");
}

function RSC_UpdateDirMarker(%name, %pos, %color, %text, %ang, %echo)
{
	%marker = $RSC_DirMarker_[%name];
	if(!isObject(%marker) && %pos !$= "DELETE")
		%marker = ($RSC_DirMarker_[%name] = new GuiBitmapCtrl() { bitmap = Crosshair.bitmap; position = "-32 -32"; extent = "32 32"; });
	if(%pos $= "DELETE")
	{
		if(isObject(%marker))
		{
			if(isObject(%textObj = %marker.textObj)) %textObj.delete();
			if(PlayGUI.isMember(%marker)) PlayGUI.remove(%marker);
			%marker.delete();
		}
		return 0;
	}
	if(!isObject(RSC_DirMarkers)) new SimSet(RSC_DirMarkers);
	RSC_DirMarkers.add(%marker); %marker.worldPos = %pos; %marker.markerName = %name;
	%marker.setColor(%color); %marker.screenText = %text; %marker.textAng = getMax(%ang, 0);
	if(isObject(%textObj = %marker.textObj)) %textObj.setValue(ColorToTag(%color)@%marker.screenText);
	return %marker;
}

function clientcmdRSC_UpdateDirMarker(%name, %pos, %color, %text, %ang)
{ RSC_UpdateDirMarker("Server_"@%name, %pos, %color, %text, %ang); }

function ColorToTag(%color)
{
	%col0 = mClampF(mFloor(getWord(%color, 0) * 255), 0, 255);
	%col1 = mClampF(mFloor(getWord(%color, 1) * 255), 0, 255);
	%col2 = mClampF(mFloor(getWord(%color, 2) * 255), 0, 255);
	if(getWordCount(%color) == 3) %col3 = 255;
	else %col3 = mClampF(mFloor(getWord(%color, 3) * 255), 0, 255);
	%hexChars = "0123456789ABCDEF"; for(%i=0;%i<4;%i++)
		%tag = %tag @ getSubStr(%hexChars, mFloor(%col[%i] / 16), 1) @ getSubStr(%hexChars, %col[%i] % 16, 1);
	return "<color:"@%tag@">";
}

function worldToScreen(%eyeTransform, %worldPosition, %screenExtent, %cameraFoV)
{
	%offset = MatrixMulVector("0 0 0" SPC getWords(%eyeTransform, 3, 5) SPC -1 * getWord(%eyeTransform, 6), VectorSub(%worldPosition, %eyeTransform));
	%x = getWord(%offset, 0);
	%y = getWord(%offset, 1);
	%z = getWord(%offset, 2);

	%fovFactor = %y * (%cameraFoV != 90 ? mTan(%cameraFoV * $pi / 360) : 1);
	%screenWidth = getWord(%screenExtent, 0);
	%screenHeight = getWord(%screenExtent, 1);

	%screenX = ((%x / %fovFactor) + 1) / 2 * %screenWidth;
	%screenY = ((%z / %fovFactor * %screenWidth) - %screenHeight) / -2;

	return %screenX SPC %screenY;
}

function toggleDirectionMarkers(%tog)
{
	if(!isObject(%cl = ServerConnection)) return;
	if(!isObject(%pl = %cl.getControlObject())) return;
	if(%tog)
	{
		if(isEventPending($ShowDirectionMarkers))
		{
			cancel($ShowDirectionMarkers);
			ProgradeMarker.setVisible(0);
			RetrogradeMarker.setVisible(0);
			if(isObject(RSC_DirMarkers))
			{
				%markers = RSC_DirMarkers.getCount();
				for(%i=0;%i<%markers;%i++)
				{
					%marker = RSC_DirMarkers.getObject(%i); %marker.setVisible(0);
					if(isObject(%text = %marker.textObj)) %text.setVisible(0);
				}
			}
		}
		else showDirectionMarkers();
		clientcmdCenterPrint("\c6Directional indicators now o"@(isEventPending($ShowDirectionMarkers)?"n":"ff")@".", 3);
	}
}

if(!$RealisticSpaceClientBound)
{
	$remapName[$remapCount++] = "Toggle Directional Indicators";
	$remapCmd[$remapCount] = "toggleDirectionMarkers";
}