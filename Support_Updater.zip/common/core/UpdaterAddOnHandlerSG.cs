//@param	string name
//@return	UpdaterAddOnSO
function UpdaterAddOnHandlerSG::getObjectByName(%this, %name)
{
	for(%i = %this.getCount() - 1; %i >= 0; %i --)
	{
		%obj = %this.getObject(%i);
		if(%obj.name $= %name)
			return %obj;
	}
	return 0;
}