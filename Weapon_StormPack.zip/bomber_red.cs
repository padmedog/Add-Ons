datablock StaticShapeData(StormBomberRedShape)
{
	shapeFile = "./BomberRedBullet.dts";
};

datablock fxLightData(StormBomberRedLight : StormBomberBlueLight)
{
	color  = "1 0 0 1";
	uiName = "Storm Light - Red";
};

datablock ParticleData(StormBomberRedExplosionParticle : StormBomberBlueExplosionParticle)
{
	colors[0]	  = "1 0.25 0.25 0.9";
	colors[1]	  = "1 0.1 0.1 0.8";
	colors[2]	  = "1 0 0 0.6";
	colors[3]	  = "1 0 0 0.4";
};

datablock ParticleEmitterData(StormBomberRedExplosionEmitter : StormBomberBlueExplosionEmitter)
{
	particles = "StormBomberRedExplosionParticle";
};

datablock ParticleData(StormBomberRedExplosionRingParticle : StormBomberBlueExplosionRingParticle)
{
	colors[0]	  = "1 0.25 0.25 0.9";
	colors[1]	  = "1 0.1 0.1 0.8";
	colors[2]	  = "1 0 0 0.6";
	colors[3]	  = "1 0 0 0.4";
};

datablock ParticleEmitterData(StormBomberRedExplosionRingEmitter : StormBomberBlueExplosionRingEmitter)
{
	particles = "StormBomberRedExplosionRingParticle";
};

datablock ParticleData(StormBomberRedExplosionChunkParticle : StormBomberBlueExplosionChunkParticle)
{
	colors[0]	  = "1 0.25 0.25 0.9";
	colors[1]	  = "1 0.1 0.1 0.8";
	colors[2]	  = "1 0 0 0.6";
	colors[3]	  = "1 0 0 0.4";
};

datablock ParticleEmitterData(StormBomberRedExplosionDotEmitter : StormBomberBlueExplosionDotEmitter)
{
		particles = "StormBomberRedExplosionDotParticle";
};

datablock ParticleData(StormBomberRedExplosionDotParticle : StormBomberBlueExplosionDotParticle)
{
	colors[0]	  = "1 0.25 0.25 0.9";
	colors[1]	  = "1 0.1 0.1 0.8";
	colors[2]	  = "1 0 0 0.6";
	colors[3]	  = "1 0 0 0.4";
};

datablock ParticleEmitterData(StormBomberRedExplosionChunkEmitter : StormBomberBlueExplosionChunkEmitter)
{
	particles = "StormBomberRedExplosionChunkParticle";
};

datablock ExplosionData(StormBomberRedExplosion : StormBomberBlueExplosion)
{
	particleEmitter = StormBomberRedExplosionEmitter;

	emitter[0] = StormBomberRedExplosionChunkEmitter;
	emitter[1] = StormBomberRedExplosionRingEmitter;
	emitter[2] = StormBomberRedExplosionDotEmitter;

	lightStartColor = "1 0 0 1";
	lightEndColor = "1 0 0 0";
};

datablock ProjectileData(StormBomberRedStuckProjectile : StormBomberBlueStuckProjectile)
{
	explosion = StormBomberRedExplosion;
};

datablock ProjectileData(StormBomberRedProjectile : StormBomberBlueProjectile)
{
	projectileShapeName = "./BomberRedBullet.dts";
	hasLight	 = true;
	lightColor  = "1 0 0 1";
};

//////////
// item //
//////////

datablock ItemData(StormBomberRedItem : StormBomberBlueItem)
{
	uiName = "Storm Bomber - Red";

	doColorShift = true;
	colorShiftColor = "1 0 0 1";

	image = StormBomberRedImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBomberRedImage : StormBomberBlueImage)
{
	shapeFile = "./StormBomber.dts";
	item = StormBomberRedItem;
	projectile = StormBomberRedProjectile;
	colorShiftColor = StormBomberRedItem.colorShiftColor;
};

//----------------------------------------------------------------------------

function StormBomberRedImage::onFire(%this, %obj, %slot)
{
	if (!isObject(%bomb = %obj.stormBomb))
	{
		if ($Sim::Time - %obj.lastBomberShotTime >= 2)
		{
			ServerPlay3d(StormBomberShotSound, %obj.getPosition());

			%p = new Projectile()
			{
				dataBlock       = StormBomberRedProjectile;
				initialPosition = %obj.getMuzzlePoint(0);
				initialVelocity = vectorScale(%obj.getMuzzleVector(0), 30);
				sourceObject    = %obj;
				client          = %client;
				sourceSlot      = 0;
				originPoint     = %obj.getMuzzlePoint(0);
				type 			= "Red";
			};
			MissionCleanup.add(%p);
			%obj.stormBomb = %p;

			schedule(1900, 0, SpawnBomberExplosion, %p, "Red");
			%p.schedule(1900, delete);

			%obj.lastBomberShotTime = $Sim::Time;
		}
	}
	else
	{
		SpawnBomberExplosion(%bomb, "Red");
		%obj.stormBomb = "";
	}
}

function StormBomberRedProjectile::onCollision(%this, %obj, %col, %fade, %pos, %normal)
{
	if (isObject(%source = %obj.sourceObject) && isObject(%source) && %source.getMountedImage(0) == StormBomberRedImage.getId() &&
		%col.getClassName() !$= "Player" && %col.getClassName() !$= "AiPlayer" && 
		%col.getClassName() !$= "Vehicle" && %col.getClassName() !$= "WheeledVehicle")
	{
		%light = new fxLight()
		{
			dataBlock = StormBomberRedLight;
			position = vectorAdd(%pos, "0 0 0.3");
		};
		MissionCleanup.add(%light);

		%p = new StaticShape()
		{
			dataBlock = StormBomberRedShape;
			position = %pos;
			type = "Red";
			objectAttachedTo = %col;
			client = %source.client;
			light = %light;
		};
		MissionCleanup.add(%p);

		if (%col.stormBombCount $= "")
			%col.stormBombCount = 0;

		%col.attachedStormBomb[%col.stormBombCount] = %p;
		%col.stormBombCount++;

		if (isObject(%source))
			%source.stormBomb = %p;

		%obj.delete();
	}
	else
	{
		%p = new Projectile()
		{
			dataBlock = StormBomberRedStuckProjectile;
			initialPosition = %pos;
			client = %source.client;
			sourceObject = %source.client;
		};
		MissionCleanup.add(%p);
		%p.explode();
	}
}

function StormBomberRedImage::onUnmount(%this, %obj, %slot)
{
	if (isObject(%bomb = %obj.stormBomb))
	{
		SpawnBomberExplosion(%bomb, "Red");
		%obj.stormBomb = "";
	}
}