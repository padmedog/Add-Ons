function blrsConnect()
{
	%ip = blrs_IPBox.getValue();
	%port = blrs_portBox.getValue();

	if(isObject(blrsUser))
		blrsUser.delete();
	
	new TCPObject(blrsUser);
	blrsUser.connect(%ip @ ":" @ %port);
}

function blrsLogin()
{
	%pass = blrs_passwordBox.getValue();
	
	if(!isObject(blrsUser))
	{
		blrs_addStatus("You must be connected first!");
		return;
	}

	blrsUser.send("PASS\t" @ %pass @ "\t\n");
}

function blrsAnnounce()
{
	%msg = blrs_MessageAll.getValue();
	blrsUser.send("SHOUT\t" @ %msg @ "\t\n");
}

function blrsGetPlayers()
{
	$blrs::selectedPlayer = -1;
	blrs_playersList.clear();
	blrsUser.send("PLAYERS\n");
}

function blrsUser::onConnected(%this,%line)
{
	blrs_addStatus("Connected!");
	blrsUser.send("VERSION" TAB $blrs::clientVersion @ "\t\n");
}

function blrsUser::onConnectFailed(%this,%line)
{
	blrs_addStatus("Connection failed!");
	%this.delete();
}

function posTurn(%pos)
{
	return mCeil(getWord(%pos,0)) SPC mCeil(getWord(%pos,1)) SPC mCeil(getWord(%pos,2));
}

function blrsUser::onLine(%this,%line)
{
	if(getField(%line,0) $= "CHAT")
	{
		blrs_addChats(getField(%line,1) @ " : " @ getField(%line,2));
	}
	else if(getField(%line,0) $= "PASS")
	{
		if(getField(%line,1) $= "OKAY")
			blrs_addStatus("Password accepted, logged in!");
		else if(getField(%line,1) $= "BAD")
			blrs_addStatus("Password rejected!");
		else if(getField(%line,1) $= "NONE")
			blrs_addStatus("The server does not have a password set.");
		else
			blrs_addStatus("Odd responce to password received.");
	}
	else if(getField(%line,0) $= "MSG")
	{
		blrs_addStatus(getField(%line,1));
	}
	else if(getField(%line,0) $= "NOTFOUND")
	{
		blrs_addStatus("Target not found.");
	}
	else if(getField(%line,0) $= "VERSION")
	{
		blrs_addStatus("Server is running BLRS version: " @ getField(%line,1));
		%theirs = getField(%line,1);
		%latest = $blrs::latestServer;
		if(%theirs < %latest)
			blrs_addStatus("The latest version is: " @ $blrs::latestServer @ " please tell the server owner to update!");
	}
	else if(getField(%line,0) $= "DEAD")
	{
		blrs_addEvents(getField(%line,1) SPC "has died.");
	}
	else if(getField(%line,0) $= "CLEARBRICKS")
	{
		blrs_addEvents(getField(%line,1) SPC "has cleared their bricks.");
	}
	else if(getField(%line,0) $= "CLEARALLBRICKS")
	{
		blrs_addEvents(getField(%line,1) SPC "has cleared all bricks.");
	}
	else if(getField(%line,0) $= "LEAVE")
	{
		blrs_addEvents(getField(%line,1) SPC "left the game.");
	}
	else if(getField(%line,0) $= "JOIN")
	{
		blrs_addEvents(getField(%line,1) SPC "joined the game.");
	}
	else if(getField(%line,0) $= "NEEDAUTH")
		blrs_addStatus("You need to login to do that!");
	else if(getField(%line,0) $= "WORKED")
		blrs_addStatus("Command received!");
	else if(getField(%line,0) $= "WRONG")
		blrs_addStatus("The server isn't running that gamemode!");
	else if(getField(%line,0) $= "PLAYERS")
	{
		%number = getField(%line,1);
		for(%a=0; %a<%number; %a++)
		{
			$blrs::playerData::name[%a] = getField(%line,2+(%a*6));
			$blrs::playerData::blid[%a] = getField(%line,3+(%a*6));
			$blrs::playerData::pos[%a] = posTurn(getField(%line,4+(%a*6)));
			$blrs::playerData::health[%a] = getField(%line,5+(%a*6));
			$blrs::playerData::tool[%a] = getField(%line,6+(%a*6));
			$blrs::playerData::bricks[%a] = getField(%line,7+(%a*6));
		}

		for(%a=0;%a<%number; %a++)
		{
			blrs_playersList.addRow(%a,$blrs::playerData::name[%a]);
		}

		blrs_playersList.sort(0);

		BLRS_playerCount.setValue("Players: " @ %number);
	}
}

function blrs_playersList::onSelect(%this,%id,%text)
{
	BLRS_BLName.setValue($blrs::playerData::name[%id]);
	BLRS_BLID.setValue("BLID: " @ $blrs::playerData::blid[%id]);
	blrs_Pos.setValue("Pos: " @ $blrs::playerData::pos[%id]);
	blrs_Health.setValue("Health: " @ $blrs::playerData::health[%id]);
	blrs_Tool.setValue("Tool: " @ $blrs::playerData::tool[%id]);
	blrs_Bricks.setValue("Bricks: " @ $blrs::playerData::bricks[%id]);

	$blrs::selectedPlayer = %id;
}

function blrsWarn()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	%warnText = blrs_WarnText.getValue();
	blrsUser.send("WARN" TAB %blid TAB %warnText @ "\t\n");
}

function blrsKill()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("KILL" TAB %blid @ "\t\n");
}

function blrsKick()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("KICK" TAB %blid @ "\t\n");
}

function blrsMute()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("MUTE" TAB %blid @ "\t\n");
}

function blrsUnmute()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("UNMUTE" TAB %blid @ "\t\n");
}

function blrsAdmin()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("ADMIN" TAB %blid @ "\t\n");
}

function blrsDeadmin()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("DEADMIN" TAB %blid @ "\t\n");
}

function blrsclearPlayerBricks()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	blrsUser.send("CPB" TAB %blid @ "\t\n");
}

function blrsBan()
{
	%blid = $blrs::playerData::blid[$blrs::selectedPlayer];
	%mins = blrs_BanTime.getValue();
	if(%mins $= "" || %mins $= " ")
	{
		blrs_addStatus("You need to enter a value time!");
		return;
	}
	blrsUser.send("BAN" TAB %blid TAB %mins @ "\t\n");
}

function blrsClearBricks()
{
	blrsUser.send("CAB\t\n");
}

function blrsResetBots()
{
	blrsUser.send("CLEARBOTS\t\n");
}

function blrsClearRelays()
{
	blrsUser.send("CLEAREVENTS\t\n");
}

function blrsNextTrack()
{
	blrsUser.send("NEXTTRACK\t\n");
}
