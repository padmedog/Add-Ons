//-------------------------------------------------------------
// Server_Oxygen
// SolarFlare
//-------------------------------------------------------------

//-------------------------------------------------------------
// RTB Preference Registration

function oxygen_defaultPrefs()
{
   $Pref::Oxygen::IntervalValue = 3;
   $Pref::Oxygen::Maximum = 6;
   $Pref::Oxygen::FullBubble = "<bitmap:add-ons/Script_SFOxygen/b>";
   $Pref::Oxygen::EmptyBubble = "<bitmap:add-ons/Script_SFOxygen/b2>";
   $Pref::Oxygen::DefaultPrefs = true;
}

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
   if(!$RTB::RTBR_ServerControl_Hook)
      exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
 
   RTB_registerPref("Oxygen Intervals (s)", "Oxygen Mod", "$Pref::Oxygen::IntervalValue", "int 0 10", "Script_SFOxygen", 3);
   RTB_registerPref("Oxygen Bubbles", "Oxygen Mod", "$Pref::Oxygen::Maximum", "int 0 6", "Script_SFOxygen", 6);
   RTB_registerPref("Full Bubble Graphic", "Oxygen Mod", "$Pref::Oxygen::FullBubble", "string 37", "Script_SFOxygen", "<bitmap:add-ons/Script_SFOxygen/b>");
   RTB_registerPref("Empty Bubble Graphic", "Oxygen Mod", "$Pref::Oxygen::EmptyBubble", "string 37", "Script_SFOxygen", "<bitmap:add-ons/Script_SFOxygen/b2>");
}
else
{
   if(!$Pref::Oxygen::DefaultPrefs)
      oxygen_defaultPrefs();
}

//-------------------------------------------------------------
// Datablocks

datablock DecalData(BubbleOn)
{
   textureName = "./b";
};  

datablock DecalData(BubbleOff)
{
   textureName = "./b2";
};  

datablock AudioProfile(oxygenBubbleSound)
{
   filename    = "./bubbles.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(oxygenBubbleParticle : painMidParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -2.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 800;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;

	textureName		= "base/data/particles/bubble";
   
	colors[0]	= "0.2 0.6 1 0.4";
	colors[1]	= "0.2 0.6 1 0.8";
	colors[2]	= "0.2 0.6 1 0.8";
	sizes[0]	= 0.2;
	sizes[1]	= 0.4;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.8;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(oxygenBubbleEmitter : painMidEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 2;
   ejectionOffset   = 0.2;
   thetaMin         = 0;
   thetaMax         = 105;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = oxygenBubbleParticle;

   uiName = "Oxygen Bubbles";
};

datablock ShapeBaseImageData(oxygenBubbleImage : painMidImage)
{
	stateTimeoutValue[1] = 0.05;
	stateEmitter[1] = oxygenBubbleEmitter;
	stateEmitterTime[1]	= 0.05;
};

function oxygenBubbleImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

//-------------------------------------------------------------
// Main

if(isPackage(oxygen_Script))
   deactivatePackage(oxygen_Script);

package oxygen_Script
{
   function armor::onEnterLiquid(%this, %obj, %cov, %type)
   {
      %obj.oxygenValue = $Pref::Oxygen::Maximum;
      
      for(%i = 0; %i < $Pref::Oxygen::Maximum; %i++)
         %string = %string @ $Pref::Oxygen::FullBubble;
      
      centerPrint(%obj.client, "<just:right>" @ %string, $Pref::Oxygen::IntervalValue + 1);
      
      if(isEventPending(%obj.oxygenTick))
         cancel(%obj.oxygenTick);
      
     %obj.oxygenTick = %obj.schedule($Pref::Oxygen::IntervalValue * 1000, oxygenTick);
      
      parent::onEnterLiquid(%this, %obj, %cov, %type);
   }
   
   function player::oxygenTick(%obj)
   {   
      if(!isObject(%obj))
         return;
      
      if(%obj.getWaterCoverage() == 1 && %obj.getMountedImage(0) != adminWandImage.getID())
      {
         %obj.oxygenValue--;
         %obj.emote(oxygenBubbleImage, 1);
         %obj.playAudio(0, oxygenBubbleSound);
      }
      else
         %obj.oxygenValue = $Pref::Oxygen::Maximum;
      
      for(%i = 0; %i < ( $Pref::Oxygen::Maximum - %obj.oxygenValue ); %i++)
         %string = %string @ $Pref::Oxygen::EmptyBubble;
      
      for(%i = 0; %i < %obj.oxygenValue; %i++)
         %string = %string @ $Pref::Oxygen::FullBubble;
      
      centerPrint(%obj.client, "<just:right>" @ %string, $Pref::Oxygen::IntervalValue + 1);
      
      if(%obj.oxygenValue == 0)
      {
         for(%i = 0; %i < $Pref::Oxygen::Maximum; %i++)
            %string = %string @ $Pref::Oxygen::EmptyBubble;
      
         centerPrint(%obj.client, "<just:right>" @ %string, $Pref::Oxygen::IntervalValue + 1);
         
         %obj.kill();
         
         return;
      }
      
      %obj.oxygenTick = %obj.schedule($Pref::Oxygen::IntervalValue * 1000, oxygenTick);
   }
   
    function armor::onLeaveLiquid(%this, %obj, %type)
    {
      if(isEventPending(%obj.oxygenTick))
         cancel(%obj.oxygenTick);
      
      %obj.oxygenValue = $Pref::Oxygen::Maximum;
       
      for(%i = 0; %i < $Pref::Oxygen::Maximum; %i++)
         %string = %string @ $Pref::Oxygen::FullBubble;
      
      centerPrint(%obj.client, "<just:right>" @ %string, 1);
    }
};
activatePackage(oxygen_Script);

//-------------------------------------------------------------
// Events

registerOutputEvent("Player", "SetOxygen", "int 1 6 1");

function player::setOxygen(%obj, %oxy)
{
   if(%obj.getWaterCoverage() != 0)
   {
      %obj.oxygenValue = %oxy;
      %obj.oxygenValue = mClamp(%obj.oxygenValue, 0, $Pref::Oxygen::Maximum);
      
      for(%i = 0; %i < ( $Pref::Oxygen::Maximum - %obj.oxygenValue ); %i++)
         %string = %string @ $Pref::Oxygen::EmptyBubble;
      
      for(%i = 0; %i < %obj.oxygenValue; %i++)
         %string = %string @ $Pref::Oxygen::FullBubble;
      
      centerPrint(%obj.client, "<just:right>" @ %string, $Pref::Oxygen::IntervalValue + 1);
      
      if(isEventPending(%obj.oxygenTick))
         cancel(%obj.oxygenTick);
      
     %obj.oxygenTick = %obj.schedule($Pref::Oxygen::IntervalValue * 1000, oxygenTick);
   }
}

registerOutputEvent("Player", "AddOxygen", "int 1 6 1");

function player::addOxygen(%obj, %oxy)
{
   if(%obj.getWaterCoverage() != 0)
   {
      %obj.oxygenValue += %oxy;
      %obj.oxygenValue = mClamp(%obj.oxygenValue, 0, $Pref::Oxygen::Maximum);
      
      for(%i = 0; %i < ( $Pref::Oxygen::Maximum - %obj.oxygenValue ); %i++)
         %string = %string @ $Pref::Oxygen::EmptyBubble;
      
      for(%i = 0; %i < %obj.oxygenValue; %i++)
         %string = %string @ $Pref::Oxygen::FullBubble;
      
      centerPrint(%obj.client, "<just:right>" @ %string, $Pref::Oxygen::IntervalValue + 1);
      
      if(isEventPending(%obj.oxygenTick))
         cancel(%obj.oxygenTick);
      
     %obj.oxygenTick = %obj.schedule($Pref::Oxygen::IntervalValue * 1000, oxygenTick);
   }
}