
 function tongueloop(%zom,%target,%tongue)
 {
	 if(isobject(%zom) && isobject(%target) && isobject(%tongue))
	 {
		%target.dismount();
		%tongue.setscale("1" SPC vectordist(%zom.getposition(),%target.getposition())/25-0.05 SPC "1");
		%tongue.settransform("0 0 0 0 0 0 0");
		//forcepush(%zom,%target);
		smokerpull(%zom, %target, 1);
		%target.damage(%zom,0,%zom.getdatablock().attackpower,$DamageType::zombiebite);
		if(%target.getstate() $= "dead")
		 {
			//%tongue.unmount();
			%tongue.delete();
			//echo(%target.client);
			if(!%target.displayeddeath)
			{
				chatMessageTeam(%zom.targetclientid,'fakedeathmessage',"Zombie" SPC %zom.name SPC "<bitmapk:add-ons/gamemode_zombie/CI_Smoker>" SPC %zom.targetclientid.name);
				%target.displayeddeath = 1;
				%target.strangler = "";
			}
			//chatMessageTeam(%zom.targetclientid,'fakedeathmessage',"Zombie" SPC %zom.name SPC "<bitmapk:add-ons/gamemode_zombie/CI_Smoker>" SPC %zom.targetclientid.name);
			%zom.isstrangling = 0;
			%zom.stranglerish = 0;
			return;
		 }
		%zom.tongueloop = schedule(100,0,tongueloop,%zom,%target,%tongue);
	 }
	 
 }
 function tongue(%zom,%target)
 {
	%zom.tongue = new player()
	{
		datablock = SmokerTongueA;
	};	
	missioncleanup.add(%zom.tongue);
	%target.downer = %zom;
	%target.strangler = %zom;
	%zom.targetclientid = %target.client;
	%zom.fspecsched = schedule(1000,0,forcespecz,%target.client,0,%zom);
	%zom.stranglerish = %target;
	%zom.isstrangling = 1;
	%zom.tongue.setnodecolor("ALL","1 0 0 1");
	%zom.mountobject(%zom.tongue,5);
	%zom.setmoveobject("");
	%zom.setmovedestination(%zom.gettransform());
	%zom.setmovey(0);
	%zom.setaimobject(%target);
	//%zom.StopPlayerSearch();
	tongueloop(%zom,%target,%zom.tongue);
 }
 function TongueVisCheck(%this)
	{
		//echo(%this);
		////if(IsInMinigame(%this))
		//{
		if(%this.isstrangling != 1)
		{
			//echo("TONGUE CHECK GO");
			%eyeVec = %this.getEyeVector();

			%startPos = %this.getEyePoint();
			%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,30));

			%mask = $TypeMasks::FxBrickObjectType | $typemasks::PlayerObjectType | $TypeMasks::InteriorObjectType;
			%target = ContainerRayCast(%startPos, %endPos, %mask);
			if(%target && %target.getclassname() $= "player")
			{
				//if (%target.getclassname() $= "Player" && IsInSameMinigame(%this,%target))
				if (%target.getclassname() $= "Player" && IsInMinigame(%target) && IsInSameMinigame(%this,%target))
				{	
					//echo("OMG FOUND YOU");
					tongue(%this,%target);
				}
			}
		}
		if(isobject(%this.stranglerish))
		{
			//%this.setaimobject(%this.stranglerish
		}
		//}
	}
 function RotSmokerZombie::SpecialAttack(%this)
	{
		////if(IsInMinigame(%this))
		//{
			//echo("TONGUE CHECK GO");
		if(%this.isstrangling != 1)
		{
			%eyeVec = %this.getEyeVector();

			%startPos = %this.getEyePoint();
			%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,30));

			%mask = $TypeMasks::FxBrickObjectType | $typemasks::PlayerObjectType | $TypeMasks::InteriorObjectType;
			%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
			if(%target && %target.getclassname() $= "player")
			{
				//if (%target.getclassname() $= "Player" && IsInSameMinigame(%this,%target))
				if (IsInSameMinigame(%target,%this))
				{	
					//echo("OMG FOUND YOU");
					tongue(%this,%target);
				}
			}
		}
		//}
	}
 datablock PlayerData(RotSmokerZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;

	maxDamage = 120;
	runforce = 60 * 90;
	maxForwardSpeed = 7;
	maxBackwardSpeed = 7;
	maxSideSpeed = 14;
	attackpower = 2;
	jumpsound = "ZombieJumpSound";
	
	jumpForce = 10 * 90; //8.3 * 90;
	BrickDestroyMaxVolume = 150;
	BrickMaxJumpHeight = 40;
	uiName = "Zombie Smoker";
	rideable = true;
	canRide = true;
	BrickKillRadius = 3;
	skinColor = "0.4 0.5 0.7 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
	aimatplayer = 1;
	SearchRadius = 50;
	OneAtATime = 1;

	SpecialAttack = 1;
	ignorePipeBombs = 1;
};
datablock PlayerData(SmokerTongueA : PlayerStandardArmor)
{
	cameraVerticalOffset = 3;
	shapefile = "./tongue3.dts";
	canJet = 0;
	mass = 120;
   drag = 0.02;
   density = 0.6;
   runSurfaceAngle = 1;
   jumpSurfaceAngle = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxForwardCrouchSpeed = 0;
   maxSideSpeed = 0;
   maxSideCrouchSpeed = 0;
   maxStepHeight = 0;
    maxUnderwaterSideSpeed = 0;

	uiName = "";
	showEnergyBar = false;
	
   jumpForce = 0; //8.3 * 90;
   jumpEnergyDrain = 10000;
   minJumpEnergy = 10000;
   jumpDelay = 127;
   minJumpSpeed = 0;
   maxJumpSpeed = 0;
	
	rideable = false;
	canRide = false;
	paintable = true;
	
   boundingBox			= vectorScale("2 2 1", 1); //"2.5 2.5 2.4";
   crouchBoundingBox	= vectorScale("2 2 1", 1); //"2.5 2.5 2.4";
   proneBoundingBox		= vectorScale("2 2 1", 1); //"2.5 2.5 2.4";
	
   lookUpLimit = 0.65;
	lookDownLimit = 0.45;
	
   numMountPoints = 3;
   mountThread[0] = "sit";
   mountThread[1] = "sit";
   mountThread[2] = "sit";
   
   upMaxSpeed = 1;
   upResistSpeed = 1;
   upResistFactor = 1;
};
function RotSmokerZombie::ondisabled(%this,%obj)
{
	if(isobject(%obj.tongue))
	{
		%obj.tongue.delete();
	}
	if(isobject(%obj.stranglerish) && %obj.stranglerish.getstate() !$= "Dead")
	{
		%obj.stranglerish.client.setcontrolobject(%obj.stranglerish);
	}
	cancel(%obj.fspecsched);
	if(isobject(%obj.stranglerish))
	{
		forcespecz(%obj.stranglerish.client,1);
		//echo(%obj.stranglerish);
	}
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotSmokerZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotSmokerZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotSmokerZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotSmokerZombie::onAdd(%this,%obj)
{
	//%obj.mountobject(tongue,5);
	//tongue(%obj,findclientbyname(rot).player,tongue);
	//%obj.setaimobject(findclientbyname(rot).player);
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
	%obj.setscale("1 1 1.3");
}
function food(%pos,%vec)
{
   //%pos = %zombie.getEyePoint();
   //%vec = %zombie.getEyeVector();
   %vec = vectorScale(%vec, 10);

   %p = new Projectile()
   {
      dataBlock = gunProjectile;
      initialPosition = %pos;
      initialVelocity = %vec;
   };
   missionCleanup.add(%p);  
   
}
function forcepush(%me, %them)
{
  //%forcepower = -1500;
  %forcepower = -300;
   %dc = %me.getEyeVector();
  // %position = getWords(%them.getTransform(), 0, 2);
   %position = %them.getposition();
   %x1 = getWord(%dc, 0) * %forcepower;
   %y1 = getWord(%dc, 1) * %forcepower;
   %z1 = getWord(%dc, 2) * %forcepower;
   %impulseVec = %x1 SPC %y1 SPC %z1;
   %them.applyimpulse(%them.getposition(),"0 0 90");
   %them.applyimpulse(%them.getposition(), %impulseVec);
  // echo(%impulsevec);
  // %them.setvelocity(%impulseVec);
}
function SmokerTongueA::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	if(isobject(%player))
	{
		%player.schedule(20,delete);
	}
}
function smokerpull(%this, %obj, %power)
{
	//if (strLen(%power))
	//%power = 100;
	
	//echo("Woahn");
	%tPos = %this.getPosition();//our position
	%oPos = getWords(%obj.getTransform(), 0, 2); //object's position
	%dis = VectorSub(%oPos, %tPos); //displacement is distance and direction of object from us, it's pos - our pos
	%normVec = vectorscale(VectorNormalize(%dis),400); //get rid of the distance (setting it to 1) so we only have direction left
	%flipVec = -getWord(%normVec, 0) SPC -getWord(%normVec, 1) SPC -getWord(%normVec, 2); //flip the vector so it's facing from the object to us, we're pushing not pulling it
	%vec = VectorScale(%flipVec, %power); //the vector is facing the right way so all that is left is to make it bigger so it can actually push
	%obj.applyImpulse(%obj.getPosition(), getwords(%vec,0,1) SPC 100);
}
function forcespecz(%client,%n,%zom)
{
	if(isobject(%zom) && %zom.getstate() !$= "dead")
	{
		if(%n == 0)
		{
			%client.camera.setmode("Smoker");
			%client.setcontrolobject(%client.camera);
			%client.camera.setorbitmode(%client.player,0,5,10,5,0);
		}
	}
	if(%n == 1)
	{
		%client.setcontrolobject(%client.player);
		//%client.player.setvelocity("0 0 0");
	}
}