datablock fxLightData(OrangeHazardLight)
{
	uiName = "Orange Hazard";
	LightOn = true;
	radius = 1;
	brightness = 50;
	color = "1 0.5 0";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/flare2";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	AnimRadius	= true;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "1 1 0";
	MaxColor		= "0 0 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 1;
	MaxRadius		= 5;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= false;
	RedKeys			= "AAAAAAA";
	GreenKeys		= "DHSFJYJ";
	BlueKeys		= "ZZZZZZZ";
	BrightnessKeys	= "AZAZAZA";
	RadiusKeys		= "AZAZAZA";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 1;
	BrightnessTime	= 1;
	RadiusTime		= 1;
	OffsetTime		= 1;
	RotationTime	= 1;
	LerpColor		= false;
	LerpBrightness	= false;
	LerpRadius		= false;
	LerpOffset		= false;
	LerpRotation	= false;
};
datablock fxLightData(YellowHazardLight : OrangeHazardLight)
{
	uiName = "Yellow Hazard";
	color = "1 1 0";
};
datablock fxLightData(FastStrobeLight)
{
	uiName = "Fast Strobe";
	LightOn = true;
	radius = 10;
	brightness = 30;
	color = "1 1 1";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/flare";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.01;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "1 1 0";
	MaxColor		= "0 0 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 0.1;
	MaxRadius		= 20;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= false;
	BrightnessKeys	= "AZAZAZA";
	RadiusKeys		= "AZAAAAA";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 0.25;
	BrightnessTime	= 0.25;
	RadiusTime		= 0.25;
	OffsetTime		= 0.25;
	RotationTime	= 0.25;
	LerpColor		= false;
	LerpBrightness	= false;
	LerpRadius		= false;
	LerpOffset		= false;
	LerpRotation	= false;
};
datablock fxLightData(FlickerRLight)
{
	uiName = "Red Flickering";
	LightOn = true;
	radius = 1;
	brightness = 10;
	color = "1 0 0";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/corona";
	FlareColor		= "1 0 0";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.01;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	AnimRadius	= true;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "1 1 0";
	MaxColor		= "0 0 1";
	MinBrightness	= 0.1;
	MaxBrightness	= 1.0;
	MinRadius		= 1;
	MaxRadius		= 5;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= true;
	RedKeys			= "AAAAAAA";
	GreenKeys		= "DHSFJYJ";
	BlueKeys		= "ZZZZZZZ";
	BrightnessKeys	= "AAAZAAZAAAAZZAZ";
	RadiusKeys		= "AAAZAAZAAAAZZAZ";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 1;
	BrightnessTime	= 1;
	RadiusTime		= 1;
	OffsetTime		= 1;
	RotationTime	= 1;
	LerpColor		= false;
	LerpBrightness	= true;
	LerpRadius		= false;
	LerpOffset		= false;
	LerpRotation	= false;
};

datablock fxLightData(FlickerWLight : FlickerRLight)
{
	uiName = "White Flickering";
	color = "1 1 1";
};

datablock fxLightData(FlickerYLight : FlickerRLight)
{
	uiName = "Yellow Flickering";
	color = "1 1 0";
};
datablock fxLightData(FlickerDLight : FlickerWLight)
{
	uiName = "Dull Flickering";
	radius = 0.1;
	brightness = 0.1;
	MinBrightness	= 0.05;
	MaxBrightness	= 0.1;
	MinRadius		= 0.05;
	MaxRadius		= 0.1;
};
datablock fxLightData(RainbowZLight)
{
	uiName = "Rainbow Light";
	LightOn = true;
	radius = 10;
	brightness = 1;
	color = "1 1 1";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/corona";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
	BlendMode		= 0;
	AnimColor		= true;
	AnimBrightness		= false;
	AnimOffsets		= false;
	AnimRotation		= false;
	AnimRadius		= false;
	LinkFlare		= true;
	LinkFlareSize	= false;
	MinColor		= "0 0 0";
	MaxColor		= "1 1 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 1;
	MaxRadius		= 10;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= false;
	RedKeys			= "AAMZZZZMAA";
	GreenKeys		= "ZMAAAMZZZA";
	BlueKeys		= "ZZZZMAAAMA";
	BrightnessKeys	= "";
	RadiusKeys		= "";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 1;
	BrightnessTime	= 1.0;
	RadiusTime		= 0.8;
	OffsetTime		= 1.0;
	RotationTime	= 1.0;
	LerpColor		= true;
	LerpBrightness	= false;
	LerpRadius		= false;
	LerpOffset		= false;
	LerpRotation	= false;
};
datablock fxLightData(CandleZLight)
{
	uiName = "Candle Light A";
	LightOn = true;
	radius = 1;
	brightness = 1;
	color = "1 0.8 0.2";
	FlareOn			= false;
	FlareTP			= false;
	Flarebitmap		= "";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	AnimRadius		= true;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "0 0 0";
	MaxColor		= "1 1 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 2;
	MaxRadius		= 3;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= true;
	RedKeys			= "";
	GreenKeys		= "";
	BlueKeys		= "";
	BrightnessKeys	= "AZMMHZAMMA";
	RadiusKeys		= "AZMMHZAMMA";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 0.8;
	BrightnessTime	= 1;
	RadiusTime		= 1;
	OffsetTime		= 1.0;
	RotationTime	= 1.0;
	LerpColor		= true;
	LerpBrightness	= false;
	LerpRadius		= false;
	LerpOffset		= false;
	LerpRotation	= false;
};
datablock fxLightData(RedAlarmLight)
{
	uiName = "Red Alarm";
	LightOn = true;
	radius = 5;
	brightness = 5;
	color = "1 0 0";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/corona";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	AnimRadius		= true;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "0 0 0";
	MaxColor		= "1 1 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 1;
	MaxRadius		= 5;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= true;
	RedKeys			= "";
	GreenKeys		= "";
	BlueKeys		= "";
	BrightnessKeys	= "AZAZAZA";
	RadiusKeys		= "AZAZAZA";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 0.8;
	BrightnessTime	= 0.5;
	RadiusTime		= 0.5;
	OffsetTime		= 1.0;
	RotationTime	= 1.0;
	LerpColor		= true;
	LerpBrightness	= true;
	LerpRadius		= true;
	LerpOffset		= false;
	LerpRotation	= false;
};
datablock fxLightData(GreenAlarmLight : RedAlarmLight)
{
	uiName = "Green Alarm";
	color = "0 1 0";
};
datablock fxLightData(YellowAlarmLight : RedAlarmLight)
{
	uiName = "Yellow Alarm";
	color = "1 1 0";
};
datablock fxLightData(OrangeAlarmLight : RedAlarmLight)
{
	uiName = "Orange Alarm";
	color = "1 0.75 0";
};
datablock fxLightData(BlueAlarmLight : RedAlarmLight)
{
	uiName = "Blue Alarm";
	color = "0 0 1";
};
datablock fxLightData(PurpleAlarmLight : RedAlarmLight)
{
	uiName = "Purple Alarm";
	color = "1 0 1";
};
datablock fxLightData(WhiteAlarmLight : RedAlarmLight)
{
	uiName = "White Alarm";
	color = "1 1 1";
};
datablock fxLightData(CyanAlarmLight : RedAlarmLight)
{
	uiName = "Cyan Alarm";
	color = "0 1 1";
};
datablock fxLightData(PlaneStrobeWLight)
{
	uiName = "Plane Strobe White";
	LightOn = true;
	radius = 5;
	brightness = 5;
	color = "1 1 1";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/corona";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	AnimRadius		= true;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "0 0 0";
	MaxColor		= "1 1 1";
	MinBrightness	= 0.0;
	MaxBrightness	= 1.0;
	MinRadius		= 1;
	MaxRadius		= 5;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= true;
	RedKeys			= "";
	GreenKeys		= "";
	BlueKeys		= "";
	BrightnessKeys	= "AZAZAAAAAA";
	RadiusKeys		= "AZAZAAAAAA";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 0.8;
	BrightnessTime	= 0.5;
	RadiusTime		= 0.5;
	OffsetTime		= 1.0;
	RotationTime	= 1.0;
	LerpColor		= true;
	LerpBrightness	= true;
	LerpRadius		= true;
	LerpOffset		= false;
	LerpRotation	= false;
};
datablock fxLightData(PlaneStrobeRLight : PlaneStrobeWLight)
{
	uiName = "Plane Strobe Red";
	color = "1 0 0";
	NearSize		= 5;
	FarSize			= 2;
};
datablock fxLightData(PlaneStrobeYLight : PlaneStrobeWLight)
{
	uiName = "Plane Strobe Yellow";
	color = "1 1 0";
};
datablock fxLightData(PlaneStrobeGLight : PlaneStrobeWLight)
{
	uiName = "Plane Strobe Green";
	color = "0 1 0";
};
datablock fxLightData(PlaneStrobeBLight : PlaneStrobeWLight)
{
	uiName = "Plane Strobe Blue";
	color = "0 0 1";
	NearSize		= 10;
	FarSize			= 5;
};
datablock fxLightData(PlaneStrobeCLight : PlaneStrobeWLight)
{
	uiName = "Plane Strobe Cyan";
	color = "0 1 1";
};
datablock fxLightData(PlaneStrobePLight : PlaneStrobeWLight)
{
	uiName = "Plane Strobe Purple";
	color = "1 0 1";
	NearSize		= 2.5;
	FarSize			= 1;
};
datablock fxLightData(NoFlareWLight)
{
	uiName = "No Flare Wite";
	LightOn = true;
	radius = 5;
	brightness = 5;
	color = "1 1 1";
	FlareOn			= false;
	FlareTP			= false;
	Flarebitmap		= "";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
};
datablock fxLightData(NoFlareStreetLight : NoFlareWLight)
{
	uiname = "No Flare Street";
	color = "0.5 0.5 0.15";
};
datablock fxLightData(NoFireLight : NoFlareWLight)
{
	uiname = "No Flare Candle";
	color = "1 0.5 0";
};
datablock fxLightData(StreetLight)
{
	uiName = "Street Light";
	LightOn = true;
	radius = 5;
	brightness = 5;
	color = "0.5 0.5 0.15";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/corona";
	FlareColor		= "0.5 0.5 0.15";
	ConstantSizeOn	= true;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
};