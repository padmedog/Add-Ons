//audio

datablock ParticleData(ballisticShotgunTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 2000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 1.0 1.0 0.2";
	colors[1]     = "0.8 0.8 0.8 0.1";
   colors[2]     = "0.6 0.6 0.6 0.05";
   colors[3]     = "0.4 0.4 0.4 0.025";

	sizes[0]      = 0.2;
	sizes[1]      = 0.1;
   sizes[2]      = 0.05;
 	sizes[3]      = 0.025;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.5;
   times[3] = 2.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ballisticShotgunTrailEmitter)
{
   ejectionPeriodMS = 2; //5
   periodVarianceMS = 1;
   ejectionVelocity = -0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180; //90
   phiReferenceVel  = 0;
   phiVariance      = 0; //360
   overrideAdvance = false;
   particles = "ballisticShotgunTrailParticle";

   uiName = "Slug Shotgun Trail";
};


AddDamageType("ballisticShotgun",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ballisticShotgun> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ballisticShotgun> %1',0.75,1);
AddDamageType("ballisticShotgunHeadshot",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ballisticShotgun>  <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_FWHeadshot>%1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ballisticShotgun> <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_FWHeadshot>%1',0.75,1);
datablock ProjectileData(ballisticShotgunProjectile)
{
   projectileShapeName = "Add-Ons/Weapon_Frogs_Weaponry/Slug.dts";
   directDamage        = 55; //14;
   directDamageType    = $DamageType::ballisticShotgun;
   radiusDamageType    = $DamageType::ballisticShotgun;
   particleEmitter     = ballisticShotgunTrailEmitter;

   brickExplosionRadius = 0.2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 15;
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 3000; //500
   verticalImpulse     = 250;
   explosion           = gunExplosion;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.4;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(ballisticShotgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./ballisticShotgun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Ballistic Shotgun";
	iconName = "./icon_ballisticShotgun";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = ballisticShotgunImage;
	canDrop = true;
	
	maxAmmo = 6;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ballisticShotgunImage)
{
   // Basic Item properties
   shapeFile = "./ballisticShotgun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ballisticShotgunItem;
   ammo = " ";
   projectile = ballisticShotgunProjectile;
   projectileType = Projectile;

   casing = BreakShotgunShellDebris;
   shellExitDir        = "-0.2 1.0 1.75"; //-1.0 1.0 1.0
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 1000;

   doColorShift = true;
   colorShiftColor = ballisticShotgunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]			  = "Activate";
	stateTransitionOnTimeout[0]     = "Eject";
	stateSound[0]			  = weaponSwitchSound;

	stateName[1]                    	= "Ready";
	stateTransitionOnTriggerDown[1] 	= "FireCheckA";
	stateTransitionOnNoAmmo[1]		= "ReloadCheckA";
	stateScript[1]                  = "onReady";
	stateAllowImageChange[1]		= true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateEmitter[2]			= gunFlashEmitter;
    stateEmitterTime[2]		= 0.025; //0.05
	stateEmitterNode[2]		= "muzzleNode";
	stateTimeoutValue[2]            = 0.1;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;

	stateName[3] 			  = "Smoke";
    stateEmitter[3]			= gunSmokeEmitter;
    stateEmitterTime[3]		= 0.5; //0.05
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.2;
	stateTransitionOnTimeout[3]     = "Eject";

	stateName[4]			  = "Eject";
	stateTimeoutValue[4]		  = 0.5;
	stateTransitionOnTimeout[4]	  = "LoadCheckA";
	stateWaitForTimeout[4]		  = true;
	stateEjectShell[4]       	  = true;
	stateSequence[4]			  = "pump";
	stateSound[4]			  = ballisticShotgunReloadSound;
	stateScript[4]                  = "onEject";
	
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTransitionOnTriggerUp[5]		= "LoadCheckB";
						
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "Reload";
	
	stateName[7]				= "ReloadCheckA";
	stateScript[7]				= "onReloadCheck";
	stateTimeoutValue[7]			= 0.01;
	stateTransitionOnTimeout[7]		= "ReloadCheckB";
						
	stateName[8]				= "ReloadCheckB";
	stateTransitionOnAmmo[8]		= "CompleteReload";
	stateTransitionOnNoAmmo[8]		= "Reload";
						
	stateName[9]				= "ForceReload";
	stateTransitionOnTimeout[9]     	= "ForceReloaded";
	stateTimeoutValue[9]			= 0.25;
	stateSequence[9]			= "Reload";
	stateSound[9]				= Block_MoveBrick_Sound;
	stateScript[9]				= "onReloadStart";
	
	stateName[10]				= "ForceReloaded";
	stateTransitionOnTimeout[10]     	= "ReloadCheckA";
	stateTimeoutValue[10]			= 0.2;
	stateScript[10]				= "onReloaded";
	
	stateName[11]				= "Reload";
	stateTransitionOnTimeout[11]     	= "Reloaded";
	stateTransitionOnTriggerDown[11] 	= "Fire";
	stateWaitForTimeout[11]			= false;
	stateTimeoutValue[11]			= 0.25;
	stateSequence[11]			= "Reload";
	//stateSound[11]				= Block_MoveBrick_Sound;
	stateScript[11]				= "onReloadStart";
	
	stateName[12]				= "Reloaded";
	stateTransitionOnTimeout[12]     	= "ReloadCheckA";
	stateWaitForTimeout[12]			= false;
	stateTimeoutValue[12]			= 0.2;
	stateScript[12]				= "onReloaded";

	stateName[13]			  = "CompleteReload";
	stateTimeoutValue[13]		  = 0.5;
	stateWaitForTimeout[13]		  = true;
	stateTransitionOnTimeout[13]     	= "Ready";
	stateSequence[13]			  = "pump";
	stateSound[13]			  = ballisticShotgunReloadSound;
	stateScript[13]                  = "onEject";

	stateName[14]				= "FireCheckA";
	stateScript[14]				= "onLoadCheck";
	stateTimeoutValue[14]		  = 0.01;
	stateTransitionOnTimeout[14]     	= "FireCheckB";
						
	stateName[15]				= "FireCheckB";
	stateTransitionOnAmmo[15]		= "Fire";
	stateTransitionOnNoAmmo[15]		= "Reload";
};

function ballisticShotgunImage::onFire(%this,%obj,%slot)
{
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{

  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
            serverPlay3D(ballisticShotgunfireSound,%obj.getPosition());
	%obj.playThread(2, activate);
	%obj.toolAmmo[%obj.currTool]--;

	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Slug Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Slugs"] @ "", 4, 2, 3, 4); 

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1)
	{
		%spread = 0.00025; //0.0010
	}
	else
	{
		%spread = 0.00025; //0.0050
	}
	
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	


	//just the muzzleflash
	//
	//nothing really special about this
	///////////////////////////////////////////////////////////

	%projectile = "shotgunFlashProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;
}
	else
	{
            serverPlay3D(ballisticShotgunJamSound,%obj.getPosition());
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Slug Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Slugs"] @ "", 4, 2, 3, 4); 
	}
}

function ballisticShotgunImage::onEject(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
	%obj.playThread(2, plant);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Slug Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Slugs"] @ "", 4, 2, 3, 4); 
}

function ballisticShotgunImage::onReloadStart(%this,%obj,%slot)
{
    if(%obj.client.quantity["Slugs"] >= 1)
	{
	%obj.playThread(2, shiftto);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Slug Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Slugs"] @ "", 4, 2, 3, 4); 
}

function ballisticShotgunImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["Slugs"] >= 1)
	{
		%obj.client.quantity["Slugs"]--;
		%obj.toolAmmo[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Slug Shells <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Slugs"] @ "", 4, 2, 3, 4); 
	}
}
function ballisticShotgunProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 55;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 2;
         %damageType = $DamageType::ballisticShotgunHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}