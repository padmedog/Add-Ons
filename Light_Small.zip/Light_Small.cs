datablock fxLightData(smallyellowlight) //This was made by sluggy BL_ID (5412)
{
	uiName = "Small YellowLight";

	LightOn = true;
	radius = 3;
	brightness = 1;
	color = "1 1 0 1";

	flareOn = true;
	flarebitmap = "base/lighting/flare2";
	NearSize	= 0.65;
	FarSize = 1;
};
datablock fxLightData(smallpurplelight : smallyellowlight)
{
	uiName = "Small PurpleLight";
	color = "0.5 0 1 1";
};
datablock fxLightData(smallgreenlight : smallyellowlight)
{
	uiName = "Small GreenLight";
	color = "0 1 0 1";
};
datablock fxLightData(smallcyanLight : smallyellowlight)
{
	uiName = "Small CyanLight";
	color = "0 1 1 1";
};
datablock fxLightData(smallorangelight : smallyellowlight)
{
	uiName = "Small OrangeLight";
	color = "1 0.5 0 1";
};
datablock fxLightData(smallbluelight : smallyellowlight)
{	
	uiName = "Small Bluelight";
	color = "0 0 1 1";
};
datablock fxLightData(smallredlight : smallyellowlight)
{
	uiName = "Small Redlight";
        color = "1 0 0 1";
};