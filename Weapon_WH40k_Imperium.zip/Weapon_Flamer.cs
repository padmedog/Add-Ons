//audio
datablock AudioProfile(WHFlamerFireSound)
{
   filename    = "./Flamer_fire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock ParticleData(WHFlamerSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 525;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 0.75 0.25 0.25";
	colors[1]     = "1 1 1 0.0";
	sizes[0]      = 0.6;
	sizes[1]      = 1.2;

	useInvAlpha = false;
};

datablock ParticleEmitterData(WHFlamerSmokeEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 2.5;
   velocityVariance = 1.25;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "WHFlamerSmokeParticle";
};

datablock ParticleData(WHFlamerFireParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.5;
	constantAcceleration = 0.0;
	lifetimeMS           = 750;
	lifetimeVarianceMS   = 250;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.25 0.5 1 0.5";
	colors[1]     = "1 1 0.25 0.25";
   	colors[2]     = "1 0 0 0";
	sizes[0]      = 0.75;
	sizes[1]      = 1.50;
 	sizes[2]      = 3.0;
   	times[0] = 0;
   	times[1] = 0.0625;
   	times[2] = 1;
	useInvAlpha = false;
};

datablock ParticleEmitterData(WHFlamerFireEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 75;
   velocityVariance = 50.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "WHFlamerFireParticle";
};

datablock ParticleData(WHFlamerLighterParticle)
{
	dragCoefficient      = 1.0;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.5;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1 1 0.25 1";
	colors[1]     = "1 0.3 0.25 0";
	sizes[0]      = 0.15;
	sizes[1]      = 0;
   	times[0]		= 0;
   	times[1] 		= 1;
	useInvAlpha = false;
};

datablock ParticleEmitterData(WHFlamerLighterEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "WHFlamerLighterParticle";
};

datablock ParticleData(WHFlamerExplosionParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.25;
	lifetimeMS           = 750;
	lifetimeVarianceMS   = 250;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 50.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1 1 0.25 0.9";
	colors[1]     = "1 0.3 0.25 0.0";
	sizes[0]      = 4;
	sizes[1]      = 0;
    times[0] = 0.0;
    times[1] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(WHFlamerExplosionEmitter)
{
   lifetimeMS = 1000;
   ejectionPeriodMS = 10;
   periodVarianceMS = 9;
   ejectionVelocity = 2.5;
   velocityVariance = 0.5;
   ejectionOffset   = 1.0;
   thetaMin         = 45;
   thetaMax         = 90;
   phiReferenceVel  = 360;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "WHFlamerExplosionParticle";

   useEmitterColors = false;
};


datablock ParticleData(WHFlamerExplosionSmokeParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = -1.5;
	inheritedVelFactor   = 1;
	constantAcceleration = 0.0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 500;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 50.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1 1 0.25 0.25";
	colors[1]     = "1 0.3 0.25 0.0";
	sizes[0]      = 4;
	sizes[1]      = 2;

	useInvAlpha = false;
};
datablock ParticleEmitterData(WHFlamerExplosionSmokeEmitter)
{
	lifeTimeMS = 1000;

   ejectionPeriodMS = 30;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "WHFlamerExplosionSmokeParticle";

   useEmitterColors = true;
};

datablock ExplosionData(WHFlamerExplosion)
{
   //explosionShape = "";

   lifeTimeMS = 2500;

   particleEmitter = WHFlamerExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = WHFlamerExplosionSmokeEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 2.5;
   
   damageRadius = 3; 
   radiusDamage = 15;                                           
   impulseRadius = 0;  
   impulseForce = 0;    

   playerBurnTime = 5000;  
   
   // Dynamic light
   lightStartRadius = 4;
   lightEndRadius = 0;
   lightStartColor = "1 0.81 0.25 1";
   lightEndColor = "1 0.25 0 0";
   
   uiName = "Flamer Explosion";
};

AddDamageType("WHFlamer",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Flamer> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Flamer> %1',0.75,1);
datablock ProjectileData(WHFlamerProjectile)
{
   //projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::WHFlamer;
   radiusDamageType    = $DamageType::WHFlamer;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground
   
   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = WHFlamerExplosion;
//   particleEmitter     = "WHFlamerTrailEmitter";

   muzzleVelocity      = 50;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 500;
   fadeDelay           = 250;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 6.0;
   lightColor  = "1 0.75 0";
};

//////////
// item //
//////////
datablock ItemData(WHFlamerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Flamer.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Flamer";
	iconName = "./Flamer";
	doColorShift = false;
	colorShiftColor = "0.7 0.7 0.72 1.000";

	 // Dynamic properties defined by the scripts
	image = WHFlamerImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 100;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(WHFlamerImage)
{

   // Basic Item properties
   shapeFile = "./Flamer.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = WHFlamerItem;
   ammo = " ";
   projectile = WHFlamerProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = WHFlamerItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTimeout[1]	   = "Ready";
	stateTimeoutValue[1]            = 0.2;
	stateWaitForTimeout[1]		   = true;
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";
	stateEmitter[1]			   = WHFlamerLighterEmitter;
	stateEmitterTime[1]		   = 0.025;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.0025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= WHFlamerFireEmitter;
	stateEmitterTime[2]		= 0.25;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= WHFlamerFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= WHFlamerSmokeEmitter;
	stateEmitterTime[3]		= 0.05;
	stateEmitterNode[3]		= "smoke";
	stateTimeoutValue[3]            = 0.0025;
	stateTransitionOnTimeout[3]     = "Ready";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.0;
	stateTransitionOnTimeout[4]	= "Ready";

};
	
function WHFlamerImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
//	%obj.playThread(2, plant);

	if($Pref::Server::WHUseAmmo == 0 || $Pref::Server::WHUseAmmo == 1)

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0036;
	}
	else
	{
		%spread = 0.0036;
	}
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}

