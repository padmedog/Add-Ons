// =================
// Client code for Cross Server Chatting
// =================

$CSM::online = 0;

if (isObject(Chat_ServerList))
	Chat_ServerList.delete();

exec("./browser.gui");

// =================
// Buttons
// =================

// Toggle chat server
function Client_ToggleChat()
{
	if ($CSM::online)
		Client_DestroyChat();
	else
		Client_CreateChat();
}

// Create chat server
function Client_CreateChat()
{
	%pass = Chat_ServerList_PassServer.getValue();
	commandToServer('CreateChat', %pass);
}

// Destroy chat server
function Client_DestroyChat()
{
	%pass = Chat_ServerList_PassServer.getValue();
	commandToServer('DestroyChat', %pass);
}

// Get up the gui
function Client_PushServerList()
{
	Canvas.pushDialog(Chat_ServerList);
	if ($CSM::online)
		GetServerList();
}

// Request a chat
function Client_RequestChat()
{
	if (!$CSM::online)
		return;
	%id = Chat_ServerList_List.getSelectedId();
	if (%id == -1)
		%id = Chat_ServerList_ListConnect.getSelectedId();
	if (%id == -1)
		return;
	%ip = $Chat::List::IP[%id];
	%pass = Chat_ServerList_Pass.getValue();
	
	commandToServer('OpenChat', %ip, %pass);
}

// Close chat
function Client_CloseChat()
{
	if (!$CSM::online)
		return;
	%id = Chat_ServerList_ListConnect.getSelectedId();
	if (%id == -1)
		return;
	%ip = $Chat::List::IP[%id];
	
	commandToServer('CloseChat', %ip);
}

// Force close chat
function Client_ForceCloseChat()
{
	if (!$CSM::online)
		return;
	%id = Chat_ServerList_ListConnect.getSelectedId();
	if (%id == -1)
		return;
	%ip = $Chat::List::IP[%id];
	
	commandToServer('ForceCloseChat', %ip);
}

// Keymapping
if (!$ChatXServer_Controls)
{
	$remapDivision[$remapCount] = "Cross Server Chatting";
	$remapName[$remapCount] = "Server List";
	$remapCmd[$remapCount] = "Client_PushServerList";
	$remapCount++;
	$ChatXServer_Controls = 1;
}

// =================
// Client commands
// =================

// Define if the chat is open or not
function clientCmdXChat_Online(%online)
{
	$CSM::online = %online;
	Chat_ServerList_Button.setText((%online) ? "Destroy chat" : "Create chat");
	if (%online)
	{
		GetServerList();
		commandToServer('GetOnlineList');
	}
	else
	{
		Chat_ServerList_List.clear();
		Chat_ServerList_ListConnect.clear();
		deleteVariables("$Chat::List::Online*");
	}
}

// Add to the online list
function clientCmdChat_AddToList(%addr, %type)
{
	// "Unique" id
	%id = getUniqueID(%addr);
	$Chat::List::Online[%id] |= %type;
	ParseServerList($Chat::Receive);
}

// Remove from the online list
function clientCmdChat_RemoveFromList(%addr, %type)
{
	// "Unique" id
	%id = getUniqueID(%addr);
	$Chat::List::Online[%id] &= ~%type;
	ParseServerList($Chat::Receive);
}

// =================
// Get master server information
// =================

// Create unique ID from an IP
function getUniqueID(%ip)
{
	// Crop it because Torque does not like big numbers
	return mAbs(getStringCRC(%ip)) % 1000000;
}

// Adds an IP to a row
function Chat_AddIP(%ip, %name)
{
	// Create unique id
	%id = getUniqueID(%ip);
	$Chat::List::IP[%id] = %ip;
	
	%online = $Chat::List::Online[%id];
	// Is online
	if (%online)
	{
		%t = "";
		switch (%online)
		{
			case 1:
				%t = "Sending";
			case 2:
				%t = "Receiving";
			case 3:
				%t = "Connected";
			default:
				%t = "Unknown";
		}
		Chat_ServerList_ListConnect.addRow(%id, %name TAB %t);
	}
	// Add row
	else
		Chat_ServerList_List.addRow(%id, %name);
}

// Get the list for all servers
function GetServerList()
{
	Chat_ServerList_List.clear();
	Chat_ServerList_ListConnect.clear();
	Chat_ServerList_List.addRow(0, "Getting server list");
	
	%tcp = new TCPObject(ServerList);
	
	%tcp.connect("master2.blockland.us:80");
}

// Parse the information from a list
function ParseServerList(%list)
{
	Chat_ServerList_List.clear();
	Chat_ServerList_ListConnect.clear();
	deleteVariables("$Chat::List::IP*");
	
	for (%i = 0; %i < %list.getCount(); %i++)
	{
		%line = %list.getObject(%i).line;
		%ip = getField(%line, 0);
		%name = getField(%line, 4);
		
		Chat_AddIP(%ip, %name);
	}
	
	Chat_ServerList_List.sort(0);
	Chat_ServerList_ListConnect.sort(0);
}

function ServerList::onConnected(%this)
{
	if (isObject($Chat::Receive))
	{
		// Clear list
		while ($Chat::Receive.getCount())
			$Chat::Receive.getObject(0).delete();
		$Chat::Receive.delete();
	}
	%this.send("GET /index.php HTTP/1.0\r\nHost: master2.blockland.us\r\n\r\n");
}

function ServerList::onLine(%this, %line)
{
	if (%line $= "")
		return;
	
	if (%line $= "START")
	{
		%this.receive = new SimSet();
		Chat_ServerList_List.clear();
		Chat_ServerList_ListConnect.clear();
		deleteVariables("$Chat::List::IP*");
		return;
	}
	if (!isObject(%this.receive))
		return;
	
	if (%line $= "")
		return;
	if (%line $= "END")
	{
		%this.disconnect();
		$Chat::Receive = %this.receive;
		%this.receive = 0;
		//ParseServerList($Chat::Receive);
		Chat_ServerList_List.sort(0);
		Chat_ServerList_ListConnect.sort(0);
		// Delete TCP
		%this.schedule(0, delete);
		return;
	}
	%this.receive.add(new SimObject()
	{
		line = %line;
	});
	// Append instead
	%ip = getField(%line, 0);
	%name = getField(%line, 4);
	Chat_AddIP(%ip, %name);
}