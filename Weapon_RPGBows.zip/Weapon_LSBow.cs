//lsbow.cs
//rpgbow and rpgbowarrow weapon stuff

//rpgbowarrow trail
datablock ParticleData(greenbowarrowTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 200;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "./Rpgbowimages/moss";
	//animTexName		= "./Rpgbowimages/moss";

	// Interpolation variables
	colors[0]	= "1 1 1 0.2";
	colors[1]	= "1 1 1 0.0";
	sizes[0]	= 0.2;
	sizes[1]	= 0.01;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(greenbowarrowTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = greenbowarrowTrailParticle;

   useEmitterColors = true;
   uiName = "Green Eye";
};

//effects
datablock ParticleData(greenbowarrowStickExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "./Rpgbowimages/glob";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.6 0.9";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.0;
};
datablock ParticleEmitterData(greenbowarrowStickExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 80;
   thetaMax         = 80;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "greenbowarrowStickExplosionParticle";

   useEmitterColors = true;
   uiName = "Green Arrow Glob";
};
datablock ExplosionData(greenbowarrowStickExplosion)
{
   //explosionShape = "";
	soundProfile = arrowhitSound;

   lifeTimeMS = 50;

   particleEmitter = greenbowarrowStickExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = "";

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 1;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};



datablock ParticleData(greenbowarrowExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.3;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "./Rpgbowimages/glob";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.5 0.5 0.5 0.9";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.45;
	sizes[1]      = 0.0;

   useInvAlpha = true;
};
datablock ParticleEmitterData(greenbowarrowExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "greenbowarrowExplosionParticle";

   useEmitterColors = true;
   uiName = "Arrow Explosion Green";
};
datablock ExplosionData(greenbowarrowExplosion)
{
   //explosionShape = "";
	soundProfile = "";

   lifeTimeMS = 50;

   emitter[0] = greenbowarrowExplosionEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "2.0 3.0 2.0";
   camShakeAmp = "0.5 0.5 0.5";
   camShakeDuration = 0.2;
   camShakeRadius = 5.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 1;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};


//projectile

datablock ProjectileData(greenlongbowarrowProjectile)
{
   projectileShapeName = "./arrows/sbbowarrow.dts";

   directDamage        = 25;
   directDamageType    = $DamageType::greenlongbowarrowDirect;

   radiusDamage        = 0;
   damageRadius        = 0;
   radiusDamageType    = $DamageType::greenlongbowarrowDirect;

   explosion             = greenbowarrowExplosion;
   stickExplosion        = greenbowarrowStickExplosion;
   bloodExplosion        = greenbowarrowStickExplosion;
   particleEmitter       = greenbowarrowTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = true;  

   armingDelay         = 5000;
   lifetime            = 6000;
   fadeDelay           = 5000;

   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.10;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   muzzleVelocity      = 120;
   velInheritFactor    = 1;

   uiName = "Green Feathered Arrow";
};


//////////
// item //
//////////
datablock ItemData(lsbowitem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./lsbow.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Long Standard Bow";
	iconName = "./icon_lsbow";
	doColorShift = true;
	colorShiftColor = "0.400 0.196 0 1.000";

	 // Dynamic properties defined by the scripts
	image = lsbowimage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(lsbowimage)
{
   // Basic Item properties
   shapeFile = "./lsbow.dts";
   emap = true;

   // Specify mount moss & offset for 3rd person, and eye offset
   // for first person rendering.
   mountmoss = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 10" );

   // When firing from a moss offset from the eye, muzzle correction
   // will adjust the muzzle vector to moss to the eye LOS moss.
   // Since this weapon doesn't actually fire from the muzzle moss,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = lsbowitem;
   ammo = " ";
   projectile = greenlongbowarrowProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = lsbowitem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // pgreenict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = swordDrawSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "StopFire";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;
	
	stateName[4]                    = "StopFire";
	stateTransitionOnTimeout[4]     = "wait";
	stateTimeoutValue[4]            = 0.2;
	stateAllowImageChange[4]        = false;
	stateWaitForTimeout[4]		= true;
	stateSequence[4]                = "StopFire";
	stateScript[4]                  = "onStopFire";

	stateName[5]                    = "wait";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 1.2;
	stateWaitForTimeout[5]		= true;


};


