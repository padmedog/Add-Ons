//########## Custom Homing Projectile Script

function Projectile::gc_spawnHomingRocket(%this)
{
  if(!%this.target) return;
  if(!isObject(%this.target)) return;
  if(!isObject(%this.client)) return;
  if(!isObject(%this) || vectorLen(%this.getVelocity()) == 0) return;
  %client = %this.client;
  %muzzle = vectorLen(%this.getVelocity());
  %found = %this.target;
  %pos = %this.getPosition();
  %start = %pos;
  %end = %found.getPosition();
  %enemypos = %end;
  %vec = vectorNormalize(vectorSub(%end,%start));
  for(%i=0;%i<5;%i++)
  {
    %t = vectorDist(%start,%end) / vectorLen(vectorScale(getWord(%vec,0) SPC getWord(%vec,1),%muzzle));
    %velaccl = vectorScale(%accl,%t);
    %x = getWord(%velaccl,0);
    %y = getWord(%velaccl,1);
    %z = getWord(%velaccl,2);
    %x = (%x < 0 ? 0 : %x);
    %y = (%y < 0 ? 0 : %y);
    %z = (%z < 0 ? 0 : %z);
    %vel = vectorAdd(vectorScale(%found.getVelocity(),%t),%x SPC %y SPC %z);
    %end = vectorAdd(%enemypos,%vel);
    %vec = vectorNormalize(vectorSub(%end,%start));
  }
  %addVec = vectorAdd(%this.getVelocity(),vectorScale(%vec,%this.dataBlock.turningLength/vectorDist(%pos,%end)*(%muzzle/%this.dataBlock.turningDelay)));
  %vec = vectorNormalize(%addVec);
  %p = new Projectile()
  {
    dataBlock = %this.dataBlock;
    initialPosition = %pos;
    initialVelocity = vectorScale(%vec,%muzzle);
    sourceObject = %this.sourceObject;
    client = %this.client;
    sourceSlot = 0;
    originPoint = %this.originPoint;
    doneHoming = 1;
    target = %this.target;
  };
  if(isObject(%p))
  {
    MissionCleanup.add(%p);
    %p.setScale(%this.getScale());
    %this.delete();
  }
}
