datablock fxDTSBrickData(brick2x2CrateData)
{
	brickFile = "./2x2Crate.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "2x2 Crate";
	iconName = "add-ons/Brick_LegoCrates/2x2Crate";
};

datablock fxDTSBrickData(brick3x4CrateData)
{
	brickFile = "./3x4Crate.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "3x4 Crate";
	iconName = "add-ons/Brick_LegoCrates/3x4Crate";
};