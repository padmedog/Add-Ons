//########## Lightning Effects

datablock AudioDescription(AudioLightning3d : AudioDefault3d)
{
  maxDistance = 5000;
  referenceDistance = 15;
  is3d = false;
  volume = 1;
};
datablock AudioProfile(ThunderCrash1Sound)
{
  filename = "./thunder1.wav";
  description = AudioLightning3d;
};
datablock AudioProfile(ThunderCrash2Sound : ThunderCrash1Sound) { filename = "./thunder2.wav"; };
datablock AudioProfile(ThunderCrash3Sound : ThunderCrash1Sound) { filename = "./thunder3.wav"; };
datablock AudioProfile(ThunderCrash4Sound : ThunderCrash1Sound) { filename = "./thunder4.wav"; };
datablock AudioProfile(ThunderStrikeSound) { filename = "./thunderstrike.wav"; description = AudioClose3d; };

//### Effects

datablock ParticleData(LightningExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 1;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "./sparks";
  spinSpeed = 0;
  spinRandomMin = -10;
  spinRandomMax = 10;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "0 0 1 0";
  sizes[0] = 4;
  sizes[1] = 2;
  useInvAlpha = false;
};

datablock ParticleEmitterData(LightningExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 5;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  orientParticles = true;
  particles = "LightningExplosionParticle";
};

datablock ParticleData(LightningSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0.5 1 1";
  colors[1] = "0 0 0 0.5";
  colors[2] = "0 0 0 0";
  sizes[0] = 10;
  sizes[1] = 11;
  sizes[2] = 14;
  times[0] = 0;
  times[1] = 0.15;
  times[2] = 1;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(LightningSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 8;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 5;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "LightningSmokeParticle";
};

datablock ExplosionData(LightningExplosion)
{
  lifeTimeMS = 150;
  emitter[0] = LightningExplosionEmitter;
  emitter[1] = LightningSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 10;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 8;
  radiusDamage = 100;
  impulseRadius = 8;
  impulseForce = 100;
  soundProfile = LightningStrikeSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 16;
};

//### Projectiles/etc.

AddDamageType("Lightning",'<bitmap:Add-Ons/Server_ThunderStorm/CI_lightning> %1','%2 <bitmap:Add-Ons/Server_ThunderStorm/CI_lightning> %1',0.2,1);

datablock ProjectileData(LightningProjectile)
{
  uiName = "";
  directDamageType = $DamageType::Lightning;
  radiusDamageType = $DamageType::Lightning;
  explosion = LightningExplosion;
  lifetime = 1;
  fadeDelay = 1;
  explodeOnDeath = true;
};

datablock LightningData(LightningStorm)
{
  strikeTextures[0] = "Add-Ons/Server_ThunderStorm/lightning1frame1.png";
  strikeTextures[1] = "Add-Ons/Server_ThunderStorm/lightning1frame2.png";
  strikeTextures[2] = "Add-Ons/Server_ThunderStorm/lightning1frame3.png";
  thunderSounds[0] = ThunderCrash1Sound;
  thunderSounds[1] = ThunderCrash2Sound;
  thunderSounds[2] = ThunderCrash3Sound;
  thunderSounds[3] = ThunderCrash4Sound;
  directDamageType = $DamageType::Lightning;
  directDamage = 500;
};

function LightningData::applyDamage(%data,%lightning,%target,%position,%normal)
{
  %p = new Projectile()
  {
    dataBlock = LightningProjectile;
    initialVelocity = 0;
    initialPosition = %position;
  };
  MissionCleanup.add(%p);
//  %target.spawnExplosion(rocketLauncherProjectile,"1 1 1");
  %target.damage(%lightning,%position,%data.directDamage,%data.directDamageType);
}

//### Functions

function serverCmdToggleThunder(%client)
{
  if(%client.isSuperAdmin)
  {
    if($Thunder)
    {
      messageAll('',"\c3" @ %client.name @"\c0 disabled lightning strikes!");
      cancel($Thunder);
      $Thunder = "";
      missionGroup.remove($Lightning);
      $Lightning.delete();
    }
    else
    {
      messageAll('',"\c3" @ %client.name @"\c0 enabled lightning strikes!");
      $Thunder = schedule(getRandom(1000,50000),0,Thunderstorm);
      $Lightning = new Lightning() {
        position = "0 0 1024";
        rotation = "1 0 0 0";
        scale = "2048 2048 1024";
        dataBlock = "LightningStorm";
        strikesPerMinute = "0.0000000001";
        strikeWidth = "10";
        strikeRadius = "256";
        color = "1 1 1 1";
        fadeColor = "0.5 0.75 1 1";
        chanceToHitTarget = "0.5";
        boltStartRadius = "20";
        useFog = "0";
      };
      missionGroup.add($Lightning);
      $Lightning.strikesPerMinute = 0.0000000001;
    }
  }
}

function Thunderstorm()
{
  cancel($Thunder);
  $Thunder = schedule(getRandom(1000,50000),0,Thunderstorm);
  schedule(500,0,LightningResetFlash,missionGroup.getObject(1).color);
  missionGroup.getobject(1).color = "1 1 1 1";
  missionGroup.getobject(1).sendupdate();
  serverPlay3D("ThunderCrash" @ getRandom(1,4) @ "Sound","0 0 0");
  $Lightning.strikeRandomPoint();
}

function LightningResetFlash(%color)
{
  missiongroup.getobject(1).color = %color;
  missiongroup.getobject(1).sendupdate();
}
