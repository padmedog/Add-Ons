AddDamageType("WHMortar",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Mortar> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Mortar> %1',0.75,1);

datablock ExplosionData(WHMortarExplosion)
{
   explosionShape = "";
   soundProfile = WHMissilelauncherHitSound;

   lifeTimeMS = 750;

   debris = WHMissilelauncherDebris;
   debrisNum = 30;
   debrisNumVariance = 10;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 45;
   debrisVelocity = 50;
   debrisVelocityVariance = 25;

   particleEmitter = IGGrenadeLauncherExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = IGGrenadeLauncherSmokeEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "5.0 5.5 5.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.25;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 2.5;
   lightStartColor = "1 0.875 0.5 1";
   lightEndColor = "1 0.75 0 0";

   damageRadius = 12;
   radiusDamage = 250;

   impulseRadius = 5;
   impulseForce = 1000;
};

datablock ProjectileData(WHMortarProjectile)
{
 projectileShapeName = "./mortarprojectile.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::WHMortar;
   radiusDamageType    = $DamageType::WHMortar;

   brickExplosionRadius = 4;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 45;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   impactImpulse	     = 1000;
   verticalImpulse	  = 1000;
   explosion           = WHMortarExplosion;
   particleEmitter     = "IGGrenadeTrailEmitter";

   muzzleVelocity      = 130;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 30000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = true;
   lightRadius = 6.0;
   lightColor  = "1 0.5 0";
   
   uiName = "Mortar";
};


//////////
// item //
//////////
datablock ItemData(WHMortarItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Mortarmounted.dts";
	rotate = false;
	mass = 10;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Mortar";
	iconName = "./Mortar";
	doColorShift = false;
	colorShiftColor = "0.2 0.2 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = WHMortarImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 1;
	
};




datablock ShapeBaseImageData(WHMortarproneImage)
{

   // Basic Item properties
   shapeFile = "./Mortarmounted.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0.4 1.4 -0.65"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = WHMortarItem;
   ammo = " ";
   projectile = WHMortarProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "10 -1.3 0.3";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 10.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = False;
   colorShiftColor = WHMortarItem.colorShiftColor;//"0.400 0.196 0 1.000";
   

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
// Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 1.35;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= BoltgunflashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= IGGrenadeLauncherFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 1;
	stateTransitionOnTimeout[4]	= "Ready";
	
};
datablock ShapeBaseImageData(WHMortarImage)
{


   shapeFile = "./Mortarmounted.dts";
   emap = false;
mountPoint = 0;
offset = "0 0 0";
   eyeOffset = "0 0 0"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";



melee = false;
armReady = false;
 doColorShift = False;
   colorShiftColor = WHMortarItem.colorShiftColor;//"0.400 0.196 0 1.000";



	stateName[0]                     = "Activate";
		statesequence[0]                     = "ready";
};


function WHMortarproneImage::onfire(%this,%obj,%slot)
{
	%obj.playThread(3, plant);
	%obj.spawnExplosion(TTHugeRecoilProjectile,"1 1 1");
	
	%dist = 100;
	%range = 300*getWord(%obj.getScale(),2);
	%start = %obj.getEyePoint();
	%fvec = %obj.getForwardVector();
	%fX = getWord(%fvec,0);
	%fY = getWord(%fvec,1);
	%evec = %obj.getEyeVector();
	%eX = getWord(%evec,0);
	%eY = getWord(%evec,1);
	%eZ = getWord(%evec,2);
	%eXY = mSqrt(%eX*%eX+%eY*%eY);
	%aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%end = vectorAdd(%start,vectorScale(%aimVec,%range));
	%ray = containerRayCast(%start,%end,$TypeMasks::All,%obj);
	%target = firstWord(%ray);
	if(isObject(%target))
	{
		%pos = posFromRaycast(%ray);
		%dist = vectorDist(%obj.getPosition(),%pos);
	}
	%initVelocity = vectorScale(%obj.getMuzzleVector(%slot),18.25);
	%initVelocity = vectorAdd(%initVelocity,getRandom(0,3) / 5 SPC getRandom(0,3) / 5 SPC %dist/3.75);
	%p = new (%this.projectileType)()
	{
		dataBlock = %this.projectile;
		initialVelocity = %initVelocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
}

package WHMortar
{
function Armor::onTrigger(%this, %player, %slot, %val)

	{
	if(isObject(%player.getMountedImage(0)))

		{

			if((%player.getMountedImage(0).getName() $= "WHMortarImage" || %player.getMountedImage(0).getName() $= "WHMortarproneImage") && %slot $= 4 && %val)
			{
			switch$(%player.getMountedImage(0).getName())
				{
				case "WHMortarimage":
				%player.mountImage(WHMortarproneimage,0);
					%player.playthread(1, armreadyboth);
					%player.playthread(0, sit);
				
				case "WHMortarproneimage":
				%player.mountImage(WHMortarimage,0);
					%player.playthread(0, root);
					%player.playthread(1, armreadyboth);
				//%player.playthread(2, armready);
				}
			}
		else
			{
			Parent::onTrigger(%this, %player, %slot, %val);
			}
		}
		else
		{
		Parent::onTrigger(%this, %player, %slot, %val);
	}
}
};	
ActivatePackage(WHMortar);	



function WHMortarproneImage::onMount(%this,%obj,%slot)
{
   
	%obj.playthread(1, armready);
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;
	%client.player.setDataBlock("WHproneArmor"); 
	
	   Parent::onMount(%this,%obj,%slot);
}


function WHMortarproneImage::onUnMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;

		%obj.playthread(0, root);
		%obj.playthread(3, root);
		if(!isObject(%client.minigame))
		{
			%client.player.setDataBlock("PlayerStandardArmor");

		}
		else
		{
			%client.player.setdatablock(%client.minigame.playerDatablock);

		}
}
function WHMortarImage::onMount(%this,%obj,%slot)
{
%obj.playthread(1, armreadyboth);
	Parent::onMount(%this,%obj,%slot);	




}

function WHMortarImage::onUnMount(%this,%obj,%slot)
{
//%obj.playthread(1, armready);
	Parent::onMount(%this,%obj,%slot);	

}
