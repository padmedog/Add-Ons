datablock PlayerData( SharkHoleBotBottom : SharkHoleBot)
{
	density = 5;
	hName = "";
};
function SharkHoleBotBottom::onAdd(%this,%obj)
{
	return;
}
function SharkHoleBotBottom::onNewDataBlock(%this,%obj)
{
	return;
}
function SharkHoleBotBottom::onBotLoop(%this,%obj)
{
	SharkHoleBot::onBotLoop(%this,%obj);
}

function SharkHoleBotBottom::onBotCollision(%this, %obj, %col, %a, %b)
{
	SharkHoleBot::onBotCollision(%this, %obj, %col, %a, %b);
}

function SharkHoleBotBottom::onRemove(%this,%obj)
{
	SharkHoleBot::onRemove(%this,%obj);
}

function SharkHoleBotBottom::onDisabled(%this,%obj,%a)
{
	SharkHoleBot::onDisabled(%this,%obj,%a);
}

function SharkHoleBotBottom::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	SharkHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type);
}

datablock PlayerData( SharkHoleBotTop : SharkHoleBot)
{
	drag = 0.02;//0.02
	density = 0.8;
	hName = "";
};
function SharkHoleBotTop::onAdd(%this,%obj)
{
	return;
}
function SharkHoleBotTop::onNewDataBlock(%this,%obj)
{
	return;
}
function SharkHoleBotTop::onBotLoop(%this,%obj)
{
	SharkHoleBot::onBotLoop(%this,%obj);
}

function SharkHoleBotTop::onBotCollision(%this, %obj, %col, %a, %b)
{
	SharkHoleBot::onBotCollision(%this, %obj, %col, %a, %b);
}

function SharkHoleBotTop::onRemove(%this,%obj)
{
	SharkHoleBot::onRemove(%this,%obj);
}

function SharkHoleBotTop::onDisabled(%this,%obj,%a)
{
	SharkHoleBot::onDisabled(%this,%obj,%a);
}

function SharkHoleBotTop::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	SharkHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type);
}

