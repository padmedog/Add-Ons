datablock fxDTSBrickData(brick1x1x3poleData)
{
	brickFile = "./1x1x3pole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1x3 Pole";
	iconName = "Add-Ons/Brick_Pole/1x1x3pole";
	collisionShapeName = "./1x1x3pole.dts";
};

datablock fxDTSBrickData(brick1x1poleData)
{
	brickFile = "./1x1pole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1 Pole";
	iconName = "Add-Ons/Brick_Pole/1x1pole";
	collisionShapeName = "./1x1pole.dts";
};

datablock fxDTSBrickData(brick1x1fpoleData)
{
	brickFile = "./1x1fpole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole";
	iconName = "Add-Ons/Brick_Pole/1x1fpole";
	collisionShapeName = "./1x1fpole.dts";
};