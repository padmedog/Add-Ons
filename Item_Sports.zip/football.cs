//basketball.cs contains all functions related to the basketball

//Datablocks

// user goes into punt mode, mounts kick power image
// user waits till he sees the power he wants, user triggers
// calculate how much time has passed
// unmount footballKickPowerImage, and shoot ball

// convert our number to our power rating out of 10
// function puntPowerConvert( %num )
// {
	// get elapsed time
	// %time = %num;
	
	// set the max power time
	// %max = 10;
	
	// %mod = mFloor( %time/%max );
	
	// if( %time >= %max )
		// %nTime = %time - %max*%mod;
	// else
		// %nTime = %time;
	
	// if mod is uneven invert things
	// if( %mod % 2 )
		// %nTime = mAbs( %nTime - %max );
	
	// echo( %mod );
	// echo( %time );
	
	// echo( %nTime );
	
	// return %nTime;
// }

// power stuff
//The image used for ball handling and dribbling
// datablock ShapeBaseImageData( footballKickPowerImage )
// {
	// sportball info
	// item = footballItem;
	// isSportBall = 1;

	// shapeFile = "./powerBar.dts";
	// emap = true;

	// mounts and offsets
	// mountPoint = 8;
	// offset = "0 -2 0";
	// eyeOffset = 0; //"0.7 1.2 -0.5";
	// rotation = eulerToMatrix( "0 0 0" );
	
	// doColorShift = false;

	//casing = " ";

	// Initial start up state
	// stateName[0]			= "Activate";
	// stateTimeoutValue[0]		= 0.1;
	// stateTransitionOnTimeout[0]	= "Activate";
	// stateSequence[0]		= "ambient";
// };

// punting stuff, not so sure about this
// function startKickPower( %obj )
// {
	// write down our start time
	// %obj.footballKickTime = getSimTime();
	
	// mount our power image
	//%obj.unMountImage( 2 );
	// %obj.mountImage( footballKickPowerImage, 0 );
	
	// debug timing helper
	// tempPuntFeedBackLoop( %obj, 0 );
// }

// function stopKickPower( %obj )
// {
	// unmount power image
	// %obj.unMountImage( 2 );
	
	// calculate power
	// %timeP = getSimTime() - %obj.footballKickTime;
	
	// %time = mCeil( %timeP/50 );//was mFloor
	
	// %time = puntPowerConvert( %time );
	
	// debug print it out
	// %obj.client.centerPrint( %time );
	
	// return %time;
// }

// function footballKickPowerImage::onBallTrigger(%this, %obj, %trigger, %val)
// {
	// if( %trigger == 0 && %val == 1 )
	// {
		// %obj.footballKickPower = stopKickPower( %obj );
		
		// startKickDir( %obj );
	// }
// }

//The image used for ball handling and dribbling
// datablock ShapeBaseImageData( footballKickDirectionImage )
// {
	// sportball info
	// item = footballItem;
	// isSportBall = 1;
	
	// shapeFile = "./directionBar.dts";
	// emap = true;

	// mounts and offsets
	// mountPoint = 8;
	// offset = "0 -2 0";
	// eyeOffset = 0; //"0.7 1.2 -0.5";
	// rotation = eulerToMatrix( "0 0 0" );
	
	// doColorShift = false;

	//casing = " ";

	// Initial start up state
	// stateName[0]			= "Activate";
	// stateTimeoutValue[0]		= 0.1;
	// stateTransitionOnTimeout[0]	= "Activate";
	// stateSequence[0]		= "ambient";
// };

// punting stuff, not so sure about this
// function startKickDir( %obj )
// {
	// write down our start time
	// %obj.footballKickTime = getSimTime();
	
	// mount our power image
	//%obj.unMountImage( 2 );
	// %obj.mountImage( footballKickDirectionImage, 0 );
	
	// debug timing helper
	// tempPuntFeedBackLoop( %obj, 0 );
// }

// function stopKickDir( %obj )
// {
	// unmount power image
	// %obj.unMountImage( 2 );
	
	// calculate power
	// %timeP = getSimTime() - %obj.footballKickTime;
	
	// %time = mFloatLength( ( %timeP/50 ), 0 );
	
	// %time = puntPowerConvert( %time );
	
	// convert it to left right positive negative
	// %direction = %time - 5;
	
	// debug print it out
	// %obj.client.centerPrint( %direction );
	
	// return %direction;
// }

// function footballKickDirectionImage::onBallTrigger(%this, %obj, %trigger, %val)
// {
	// if( %trigger == 0 && %val == 1 )
	// {
		// %kickDir = stopKickDir( %obj );
		
		// %kickPow = %obj.footballKickPower;
		
		// echo( %kickDir SPC %kickPow );
		
		// %pos = %obj.getMuzzlePoint( 1 );//%obj.getPosition();
		
		// %vec = %obj.getForwardVector();
		
		// %xVec = getWord( %vec, 0 );
		// %yVec = getWord( %vec, 1 );
		
		// %vec = vectorScale( %vec, 2.5 );
		
		// %vel =  vectorScale( %vec, %kickPow );
		
		// %zAdd = 2 * %kickPow;
		
		// add in z height
		// %vel = vectorAdd( %vel, "0 0" SPC %zAdd );

		// alter the direction
		// if( %kickPow == 0 )
			// %sVec = "0 0 0";
		// else if( %kickPow < 0 )//Left Check
			// %sVec = -%yVec SPC %xVec SPC 0;
		// else if( %kickPow > 0 )//Right Check
			// %sVec = %yVec SPC -%xVec SPC 0;
			
		// add in the altered direction
		// %sVec = vectorScale( %sVec, %kickDir*3 );
		
		// %vel = vectorAdd( %vel, %sVec );
		
		// finally add in our players velocity
		// %vel = vectorAdd( %vel, %obj.getVelocity() );
		
		// %dataBlock = footballProjectile;
		
		// unmount bar
		// %obj.unMountImage( 0 );
		
		// unmount football then spawn new football
		// %obj.unMountImage( 1 );
		
		// %p = %obj.spawnBall( %dataBlock, %vel );
	// }
// }

// entering kick mode
// function serverCmdKickMode( %client )
// {
	// %obj = %client.player;
	
	// %image = %obj.getMountedImage( 0 );
	
	// check everything
	// if( isObject( %image ) && %image.isSportBall && %image == footballImage.getID() )
	// {
		// put us in kick mode
		// %obj.isInKickMode = 1;
		// %obj.mountImage( footballImage, 1 );
		// startKickPower( %obj );
	// }
// }


// function stopPuntPower2( %obj )
// {
	// weird hack to get things to time a bit better
	// %obj.footballKickTime;//-= 0.01333;
	
	// %timeP = getSimTime() - %obj.footballKickTime;
	
	// echo( %timeP/50 );
	// %time = mFloor( %timeP/50 );
	// echo( %time );
	// %time = puntPowerConvert( %time );
	// %obj.client.centerPrint( %time );
	
	// return %time;
// }

// function tempPuntFeedBackLoop( %obj, %n )
// {
	// %wtf = stopPuntPower2( %obj );
	// %obj.client.bottomPrint( puntPowerConvert( %n ) SPC ":" SPC %wtf );
	// stopPuntPower2( %obj );
	// $tempSched = schedule( 50, %obj, tempPuntFeedBackLoop, %obj, %n++ );
// }

// fumble the football, used when tackled
function fumbleFootBall(%obj)
{
	if(!%obj.hasFootball)
		return;

	%power = -10;
	%zAdd = 5;
	
	%rVec = sGetRandomFloat(5,10,1) SPC sGetRandomFloat(5,10,1) SPC 1.5;
	%playerVel = %obj.getVelocity();
	
	%rVec = vectorScale( %rVec,getRandom(2,4) );
	
	// make sure to send the ball flying high
	%fVel =  vectorAdd(%rVec , "0 0 6");

	%vel = vectorAdd(%fVel, %playerVel);
	%dataBlock = footballProjectile;
	
	%p = %obj.spawnBall( %dataBlock, %vel );
	
	// with this set true, the next person to grab the football gets a star above their head
	%p.isFumbled = 1;
	
	%obj.playThread(1,root);
	%obj.playthread(3,activate2);
	%obj.unMountImage(0);
	
	// increase the sbTimeout so that the guy who just lost the ball can't instantly get it back
	%obj.sbTimeout = getSimTime()+1000;
}

// tackle player function, send tackled player a tumblin
function tacklePlayer( %obj, %col )
{
	// tackle timeout, to prevent massive griefing
	if( %obj.tackleTimeout > getSimTime() )
		return;

	// tackle timeout
	%obj.tackleTimeout = getSimTime() + 5000;
		
	// randomly fumble football, not sure if this should happen before or after our tumble
	// if( !getRandom( 0, 9 ) )
	fumbleFootBall( %obj );
		
	// tumble player
	tumble( %obj, 3000 );
	%newcar = %obj.getObjectMount();
		
	// make sure we tumbled
	if( !isObject( %newcar ) )
		return;
	
	// calculate the tacklers velocity
	%velocity = %col.getVelocity();
	
	// calculate direction between the two players
	%objPos = %obj.getPosition();
	%colPos = %col.getPosition();
		
	// check if the velocity is too low, this is so we can have an interesting tumble effect every time
	if( vectorLen( %velocity ) < 3 )
	{	
		// normalize the vector
		%vec = vectorNormalize( vectorSub( %objPos, %colPos ) );

		// scale the vector up
		%velocity = vectorScale( %vec, 3 );
	}
	
	// this detects when we're coming straight down on a player, and adds a little randomness to the tackle
	if( vectorDot( vectorNormalize( %velocity ), "0 0 -1" ) >= 0.95 )
	{
		%mVec = sGetRandomFloat( 5, 10, 1 ) SPC sGetRandomFloat( 5, 10, 1 ) SPC "0";
		
		%mVec = vectorScale( %mVec, 6 );
		
		%velocity = vectorAdd( %velocity, %mVec );
	}
	
	%objZ = getWord( %objPos, 2 );
	%colZ = getWord( %colPos, 2 );
	
	// if our tackler is above our head then give him a push 
	if( %colZ - %objZ > 2.65 )
		%col.addVelocity( "0 0 10" );
			
	// apply impulse
	%newcar.setVelocity( "0 0 0" );
	%pos = vectorAdd( %newcar.getPosition(), "0 0 -2" );
	
	// scale by mass so we actually move it
	%newcar.applyImpulse( %pos, vectorScale( %velocity, %newcar.getDataBlock().mass ) );// vectorScale(%newcar.getVelocity() * -1, %newcar.getDataBlock().mass) );
	// %newcar.setVelocity( %velocity );
}

//Item only for testing will be removed later
datablock ItemData(FootballItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	// Basic Item Properties
	shapeFile = "./football.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Ball Football";
	// iconName = "./icon_gun";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	// Dynamic properties defined by the scripts
	isSportBall = 1;
	image = footballImage;
	canDrop = true;
};

// this is called when someone collides with us while we have a ball, kind of confusing
function FootballItem::onBallCollision( %this, %obj, %col )
{			
	// if player is dead return
	if( %col.isDisabled() )
		return;
	
	%zVel = getWord( %col.getVelocity(), 2 );
	
	// we've been hit so toss the ball
	if( %col.isCrouched() || %zVel != 0 )
	{
		// for minigame do a tumble effect, outside of minigame just fumble the ball
		if( isObject( getMiniGameFromObject( %obj ) ) )
			tacklePlayer( %obj, %col );
		else
			fumbleFootBall( %obj );
	}
}

datablock ProjectileData(footballProjectile)
{
	activateSeq = "ambient";
	maintainSeq = "ambient";
	sportBallImage = "footballImage";
	projectileShapeName = "./football.dts";
	explosion           = "";
	bounceExplosion     = "";
	particleEmitter     = smallBallTrailEmitter;
	explodeOnDeath = true;

	brickExplosionRadius = 0;
	brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
	brickExplosionForce  = 0;             
	brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

	sound = "";

	muzzleVelocity      = 40;
   restVelocity        = 3;
	velInheritFactor    = 1.0;

	armingDelay         = 20000;
	lifetime            = 20000;
	fadeDelay           = 19500;
	bounceElasticity    = 0.4;
	bounceFriction      = 0.7;
	isBallistic         = true;
	gravityMod          = 1;
   ballRadius          = 0.2;

	hasLight    = false;

	uiName = "Ball Football"; 
};

datablock ShapeBaseImageData(footballImage)
{
	isSportBall = 1;
	//ooooooh mystery tag
	isChargeWeapon = 1;
	// Basic Item properties
	shapeFile = "./football.dts";
	emap = true;

	mountPoint = 0;
	offset = "-0.1 0.1 0";
	rotation = eulerToMatrix( "90 180 0" );
	//eyeOffset = "0.1 0.2 -0.55";

	correctMuzzleVector = true;

	className = "WeaponImage";

	// balls need to know about their item in image, for certain methods
	item = footballItem;
	ammo = " ";
	projectile = footballProjectile;
	projectileType = Projectile;

	melee = false;

	armReady = false;

	//casing = " ";
	doColorShift = true;
	colorShiftColor = "0.400 0.196 0 1.000";

	// Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	// stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]	= true;

	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.7;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "AbortCharge";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;

	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "Ready";
	stateTimeoutValue[3]		= 0.3;
	stateWaitForTimeout[3]		= true;
	stateScript[3]			= "onAbortCharge";
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateAllowImageChange[4]	= false;

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.5;
	stateFire[5]			= true;
	stateSequence[5]		= "fire";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;
	//stateSound[5]				= spearFireSound;
};

function footballImage::onMount(%this, %obj, %slot)
{
	%obj.hasSportBall = 1;
	%obj.hasFootball = 1;
}
function footballImage::onUnMount(%this, %obj, %slot)
{
	%obj.hasSportBall = 0;
	%obj.hasFootball = 0;
	%obj.playThread(2,root);
}
function footballImage::onCharge(%this, %obj, %slot)
{
	%obj.playThread(1,armReadyRight);
	%obj.playthread(2, spearReady);
}

function footballImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playThread(1,root);
	%obj.playthread(2, root);
}

function footballImage::onFire(%this, %obj, %slot)
{
	if(%obj.isTackled)
		return;

	%power = 40;
	%zAdd = 0;

	%playerVel = %obj.getVelocity();
	%fVel =  vectorAdd( vectorScale(%obj.getMuzzleVector(0),%power) , "0 0" SPC %zAdd);

	%vel = vectorAdd(%fVel, %playerVel);
	%dataBlock = footballProjectile;
	
	%p = %obj.spawnBall( %dataBlock, %vel );
	
	// let it be known it was thrown, lool
	%p.wasThrown = 1;
	
	%obj.playThread(1,root);
	%obj.playthread(2, spearThrow);
	%obj.unMountImage(0);
}

// onBall trigger, this time it's a lateral/snap type move
function footballImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	if(%trigger != 4 || %val != 1 || %obj.getDataBlock().canJet)
		return;

	%power = -10;
	%zAdd = 5;

	%playerVel = %obj.getVelocity();
	%fVel =  vectorAdd( vectorScale(%obj.getForwardVector(),%power) , "0 0" SPC %zAdd);

	%vel = vectorAdd( %fVel, %playerVel );
	%dataBlock = footballProjectile;
	
	%p = %obj.spawnBall( %dataBlock, %vel );

	%obj.playThread(1,root);
	%obj.playthread(3,activate2);
	%obj.unMountImage(0);
}

// resets football record 
function serverCmdResetFootballRecord( %client )
{
	if( %client.isAdmin || %client.isSuperAdmin )
	{
		$Pref::Server::FootballRecord = 0;
		$Pref::Server::FootballRecordHolders = "";
		messageAll( 'fbRecReset', %client.name SPC "has reset the football record." );
	}
}

// tells the player who holds the record
function serverCmdFootballRecord( %client )
{
	messageClient( %client, 'footballRecordCheck', $Pref::Server::FootballRecordHolders SPC "<color:FF0000>currently hold the football record at<color:FFFFFF>" SPC $Pref::Server::FootballRecord @ "ft." );
}

// tell the players how awesome they are
function CatchFootballMessage( %obj, %source, %sourcePos, %sourceName, %wasThrown )
{
	%client = %obj.client;
	%name = %client.name;
	
	// if( %obj.isBot || %obj.isHoleBot )
		// %name = %obj.name;
	
	%sClient = %source;
	
	// check that both clients exist
	if( isObject( %obj.spawnBrick ) )
	{
		%name = %obj.getDataBlock().uiName;
		
		if( %obj.isHoleBot || %obj.isBot )
			%name = %obj.name;
		
		%isBot = 1;
	}
	
	// calculate the distance
	%pos1 = getWords( %sourcePos, 0, 1 );
	%pos2 = getWords( %obj.getPosition(), 0, 1 );
	
	%dist = vectorDist( %pos1, %pos2 )*1.875;//*1.86;
	
	// trim down dist
	%dist = mFloatLength( %dist, 0 );
	
	// build the message
	%color = "<color:ffff00>";
	%wColor = "<color:FFFFFF>";
	%rColor = "<color:FF0000>";
	
	// might want to increase font size
	%prefix = "<bitmap:base/client/ui/CI/star>" SPC %color @ "FOOTBALL -";
	%messageBase = %rColor @ "at<color:FFFFFF>" SPC %dist @ "ft!";
	
	// check if new record, and make sure we're not throwing it to ourselves
	if( !%isBot && %wasThrown && %dist > $Pref::Server::FootballRecord && %client != %sClient )
	{
		// message everyone
		%recordMessage = %color @ %sourceName SPC %rColor @ "&" @ %color SPC %name SPC %rColor @ "set a new football record," SPC "<color:FFFFFF>" @ %dist @ "ft!";
		messageall( 'footballRecord', %recordMessage );
		
		// change the messageBase
		%messageBase = %messageBase SPC %rColor @ "<just:center>NEW RECORD!!!";
		
		// set the new record
		$Pref::Server::FootballRecord = %dist;
		$Pref::Server::FootballRecordHolders = %color @ %sourceName SPC %rColor @ "&" SPC %color @ %name;
		
		// play the orchestra hit sound for receiver
		serverPlay3D(rewardSound, %obj.getPosition() );
		
		// play star emoete & sound for qb
		if( isObject( %sClient.player ) )
		{
			%sClient.player.emote( winStarProjectile );
			serverPlay3D(rewardSound, %sClient.player.getPosition() );
		}
		
	}
	
	// message the qb
	%qbMessage = %color @ %name SPC %messageBase;
	
	if( isObject( %sClient ) )
		%sClient.bottomPrint( %prefix SPC %rColor @ "To" SPC %qbMessage, 5 );
	
	// message the receiver
	%receiverMessage = %color @ %sourceName SPC %messageBase;// SPC "at" SPC %dist @ "ft!";
	
	if( isObject( %client ) )
		%client.bottomPrint( %prefix SPC %rColor @ "From" SPC %receiverMessage, 5 );
}

function footballProjectile::onRest(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%obj.haveSpawnedItem)
      return;
   else
      %obj.haveSpawnedItem = 1;

   %item = new item()
   {
      dataBlock = "footballItem";
      scale = %obj.getScale();
      minigame = getMiniGameFromObject( %obj );//%obj.minigame;
      isFumbled = %obj.isFumbled;
	  spawnBrick = %obj.spawnBrick;
   };
   missionCleanup.add(%item);
   
   // check if a bot spawned the thing
   // if( isObject( %obj.sourceObject.spawnBrick ) )
      // %item.minigame = getMiniGameFromObject( %obj );//%obj.sourceObject.spawnBrick.getGroup().client.minigame;
      
   %rot = hGetAnglesFromVector( vectorNormalize(%obj.lVelocity) );

   %item.setTransform(%obj.getPosition() SPC  "0 0 1" SPC %rot);
   %item.schedulePop();
   %item.isSportBall = 1;
   
   // this is done to prevent leaks, so the object is deleted after the function is over.
   %obj.delete();// %obj.schedule( 0, delete );
}

function footballProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	//Play bounce sound and check that we haven't played it too recently
	%obj.playSportBallSound();
	
	// do onBallHit event, only call this on bricks obviously
	if( %col.getType() & $TypeMasks::FxBrickObjectType )
		%col.onBallHit( %obj.sourceObject, %obj );

	%vel = %obj.getVelocity();
	%speed = vectorLen(%vel);
	
	%source = %obj.client;
	%sourcePos = %obj.originPoint;
	%sourceName = %obj.client.name;
	%wasThrown = %obj.wasThrown;
	
	if( passBallCheck(%obj,%col) )
	{
		// if we have successfully caught the ball play the caught message
		if( !%obj.hasHitGround && !%obj.isFumbled )
			 CatchFootballMessage( %col, %source, %sourcePos, %sourceName, %wasThrown );
		
		if( !%obj.hasHitGround || %obj.isFumbled )
			%col.emote(winStarProjectile);
	
		if(%speed > 5)
			%col.playThread(3,activate2);
		else
			%col.playThread(3,activate);

      %obj.haveSpawnedItem = 1; //set this flag so if we onRest in this tick we don't spawn an item
		return;
	}
	
	%obj.hasHitGround = 1;
	
	%obj.lVelocity = %obj.getVelocity();
	parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
}