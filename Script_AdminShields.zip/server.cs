package Script_AdminShields
{
	function serverCmdMessageSent(%client,%msg)
	{
		%oldPrefix = %client.clanPrefix;
		if(%client.isAdmin)
		{
			%client.clanPrefix = "<bitmap:add-ons/script_adminshields/icon_silverBadge.png>\c7 " @ %oldPrefix;
			if(%client.isSuperAdmin)
			{
				%client.clanPrefix = "<bitmap:add-ons/script_adminshields/icon_goldBadge.png>\c7 " @ %oldPrefix;
			}
		}
		Parent::serverCmdMessageSent(%client,%msg);
		%client.clanPrefix = %oldPrefix;
	}
};
activatepackage(Script_AdminShields);
datablock DecalData(AdminShield)
{
	textureName = "add-ons/script_adminshields/icon_goldBadge.png";
};
datablock DecalData(ModeratorShield)
{
	textureName = "add-ons/script_adminshields/icon_silverBadge.png";
};