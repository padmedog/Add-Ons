datablock AudioProfile(ChemGrenadeExplosionSound)
{
   filename    = "./ChemExplode.wav";
   description = AudioDefault3d;
   preload = false;
};

datablock AudioProfile(ChemGrenadeBounceSound)
{
   filename    = "./ChemBounce.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(ChemGrenadeFireSound)
{
   filename    = "./ChemFire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock DebrisData(ChemGrenadePinDebris)
{
	shapeFile = "./ChemPin.dts";
	lifetime = 5.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};



datablock ParticleData(PlayerToxicParticle)
{
	textureName				= "base/data/particles/cloud";
	dragCoefficient			= 0.0;
	gravityCoefficient		= -0.1;
	inheritedVelFactor		= 0.0;
	windCoefficient			= 2;
	constantAcceleration	= 0.3;
	lifetimeMS				= 1500;
	lifetimeVarianceMS		= 250;
	spinSpeed				= 0;
	spinRandomMin			= -90.0;
	spinRandomMax			=  90.0;
	useInvAlpha				= false;
		
	colors[0]	= "0.0 0.6 0.3 0.2";
	colors[1]	= "0.1 0.5 0.3 0.8";
	colors[2]	= "0.3 0.5 0.0 0.1";
		
	sizes[0]	= 0.4;
	sizes[1]	= 10.0;
	sizes[2]	= 7.0;
		
	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 0.7;
};


datablock ParticleEmitterData(PlayerToxicEmitter)
{
	ejectionPeriodMS	= 5;
	periodVarianceMS	= 4;
	ejectionVelocity	= 4;
	ejectionOffset		= 1.00;
	velocityVariance	= 0;
	thetaMin			= 30;
	thetaMax			= 90;
	phiReferenceVel		= 0;
	phiVariance			= 360;
	overrideAdvance		= false;

	particles = playerToxicParticle;  		
		uiName = "ChemGas Player"; 
};

datablock ParticleData(ToxicTrailParticle)
{
	textureName          = "base/data/particles/cloud";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 050;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "0.0 1.0 0.3 0.2";
	colors[1]	= "0.4 1.0 0.3 1.0";
	colors[2]	= "0.6 1.0 0.0 0.1";

	sizes[0]	= 0.1;
	sizes[1]	= 0.2;
	sizes[2]	= 0.12;

	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(ToxicTrailEmitter)
{
	ejectionPeriodMS = 0;
	periodVarianceMS = 0;
	ejectionVelocity = 0;
	ejectionOffset   = 0.00;
	velocityVariance = 0.0;
	thetaMin         = 0;
	thetaMax         = 1;
	phiReferenceVel  = 0;
	phiVariance      = 360;
	overrideAdvance = false;
	
	particles = ToxicTrailParticle;   
	
	uiName = "ChemGas Trail";
};

datablock DebrisData(ChemGrenadeDebris)
{
	emitters = "PlayerToxicEmitter";
	shapeFile = "base/data/shapes/empty.dts";
	lifetime = 60.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0;
	friction = 0.2;
	numBounces = 2;
	staticOnMaxBounce = true;
	snapOnMaxBounce = true;
	fade = false;
	gravModifier = 2;
};

datablock ExplosionData(ChemGrenadeExplosion : vehicleFinalExplosion)
{
	burnPlayerTime = 0;
	damageRadius = 1;
	impulseForce = 0;
	impulseRadius = 0;
	radiusDamage = 400;
	uiName = "";
	soundProfile = "ChemGrenadeExplosionSound";
		
	lifetimeMS = 10000;
	
	debris = "ChemGrenadeDebris";
	debrisNum = 1;
	debrisNumVariance = 0;
	debrisPhiMin = 0;
	debrisPhiMax = 360;
	debrisThetaMin = 30;
	debrisThetaMax = 30;
	debrisVelocity = 0;
	debrisVelocityVariance = 0;


   	particleEmitter = "";
		
	emitter[0] = "";
	emitter[1] = "";
	emitter[2] = "";
	emitter[3] = "";
	times[0] = "0";
	times[1] = "0";
	times[2] = "0";
	times[3] = "0";
	sizes[0] = "1 1 1";
	sizes[1] = "1 1 1";
	sizes[2] = "1 1 1";
	sizes[3] = "1 1 1";

   	hasLight    = false;
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0 0 0 0";
   lightEndColor = "0 0 0 0";
};

AddDamageType("Toxic", '<bitmap:base/client/ui/CI/skull> %1', '%2 <bitmap:base/client/ui/CI/skull> %1', 0.2, 1);
datablock ProjectileData(ChemGrenadeProjectile)
{
   projectileShapeName = "./ChemGrenadeProjectile.dts";
   directDamage        = 0;
   directDamageType  = $DamageType::Toxic;
   radiusDamageType  = $DamageType::Toxic;
   impactImpulse	   = 200;
   verticalImpulse	   = 200;
   explosion           = ChemGrenadeExplosion;
   particleEmitter     = ToxicTrailEmitter;

   brickExplosionRadius			= 0;
   brickExplosionImpact			= false;
   brickExplosionForce				= 0;
   brickExplosionMaxVolume			= 0;
   brickExplosionMaxVolumeFloating	= 0;

   muzzleVelocity      = 30;
   velInheritFactor    = 0;
   explodeOnDeath = true;

   armingDelay         = 2500; 
   lifetime            = 2500;
   fadeDelay           = 3000;
   bounceElasticity    = 0.4;
   bounceFriction      = 0.3;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Chemical Grenade";
};


datablock ItemData(ChemGrenadeItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./ChemGrenade.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "Chemical Grenade";
	iconName = "./icon_ChemGrenade";
	doColorShift = false;
	colorShiftColor = "0.400 0.196 0 1.000";

	image = ChemGrenadeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(ChemGrenadeImage)
{

   shapeFile = "./ChemGrenade.dts";
   emap = true;

   mountPoint = 0;
   offset = "0 0.1 0";

   correctMuzzleVector = true;

   className = "WeaponImage";

   item = ChemGrenadeItem;
   ammo = " ";
   projectile = ChemGrenadeProjectile;
   projectileType = Projectile;

   	casing = ChemGrenadePinDebris;
	shellExitDir        = "-2.0 1.0 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   melee = false;
   armReady = true;

   doColorShift = false;
   colorShiftColor = "0.400 0.196 0 1.000";


	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Pindrop";
	stateAllowImageChange[1]	= true;

	stateName[2]			= "Pindrop";
	stateTransitionOnTimeout[2]	= "Pinfallen";
	stateAllowImageChange[2]	= false;
	stateTimeoutValue[2]		= 0.2;
	stateSound[2]				= ChemGrenadeFireSound;
	stateSequence[2]                = "Pinpull";
	stateEjectShell[2]       = true;

	stateName[3]			= "Pinfallen";
	stateTransitionOnTriggerDown[3]	= "Charge";
	stateAllowImageChange[3]	= false;
	
	stateName[4]                    = "Charge";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.7;
	stateWaitForTimeout[4]		= false;
	stateTransitionOnTriggerUp[4]	= "AbortCharge";
	stateScript[4]                  = "onCharge";
	stateAllowImageChange[4]        = false;
	
	stateName[5]			= "AbortCharge";
	stateTransitionOnTimeout[5]	= "Pinfallen";
	stateTimeoutValue[5]		= 0.3;
	stateWaitForTimeout[5]		= true;
	stateScript[5]			= "onAbortCharge";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Armed";
	stateTransitionOnTriggerUp[6]	= "Fire";
	stateAllowImageChange[6]	= false;

	stateName[7]			= "Fire";
	stateTransitionOnTimeout[7]	= "Done";
	stateTimeoutValue[7]		= 0.5;
	stateFire[7]			= true;
	stateSequence[7]		= "fire";
	stateScript[7]			= "onFire";
	stateWaitForTimeout[7]		= true;
	stateAllowImageChange[7]	= false;

	stateName[8]					= "Done";
	stateScript[8]					= "onDone";

};


datablock ShapeBaseImageData(ToxicScreenImage)
{
  shapeFile = "./ToxicFacemask.dts";
  emap = true;
  mountPoint = $HeadSlot;
  offset = "0 0 0";
  eyeOffset = "0 0.05 -0.05";
  rotation = eulerToMatrix("0 0 0");
  eyeRotation = eulerToMatrix("0 0 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = false;
  colorShiftColor = "1 1 1 1";
  hasLight = false;
   doRetraction = false;

};


package ChemGrenadePackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "ChemGrenadeItem" && %col.canPickup)
		{
			for(%i=0;%i<%this.maxTools;%i++)
			{
				%item = %obj.tool[%i];
				if(%item $= 0 || %item $= "")
				{
					%freeSlot = 1;
					break;
				}
			}

			if(%freeSlot)
			{
				%obj.pickup(%col);
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(ChemGrenadePackage);

function ChemGrenadeImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
	%obj.lastChemSlot = %obj.currTool;
}

function ChemGrenadeImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function ChemGrenadeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	serverPlay3D(ChemGrenadeBounceSound,%obj.getTransform());
}

function ChemGrenadeImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, spearThrow);
	Parent::OnFire(%this, %obj, %slot);

	%currSlot = %obj.lastChemSlot;
	%obj.tool[%currSlot] = 0;
	%obj.weaponCount--;
	messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
	serverCmdUnUseTool(%obj.client);
}

function ChemGrenadeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

package Weapon_ChemGrenade_Package
{
	
	function Player::ToxicLoop(%obj, %loopRuns, %loopDamage, %source, %val, %client)
	{
	if(%obj.client.Gasmask == 0)
	{
		if(%obj.getType() & $TypeMasks::PlayerObjectType && %obj.getState() !$= "Dead")
		{
			%db = %obj.getDatablock();
			
				if(!%obj.isPlayer)
				{
					%damage = %loopDamage * 1.25;
					%damageType = $DamageType::Toxic;
					%pos = %obj.getPosition();
					
					if(%damage * 45 < %db.maxDamage)
					{
						%damage = mCeil((%db.maxDamage / 45) * getWord(%obj.getScale(), 2));
					}
				}
				
				%obj.damage(%source, %pos, %damage, %damageType);
				
				if(isObject(%obj) && %obj.getState() !$= "Dead")
				{
					cancel(%obj.damageToxicSched);

					if(%obj.client.Gasmask == 0 && %loopRuns > 0)
					{
						%obj.damageToxicSched = %obj.schedule(1000, "ToxicLoop", %loopRuns, %loopDamage, %source);
						%obj.damageToxicLoops = %loopRuns;
						%obj.damageToxicDamage = %loopDamage;
   						%obj.mountImage(ToxicScreenImage,3);
					}
					else
					{
						%obj.damageToxicLoops = 0;
						%obj.damageToxicDamage = 0;
						%obj.unMountImage(3);
					}
				}
			}
		}
	}

};
activatePackage(Weapon_ChemGrenade_Package);

function ChemGrenadeProjectile::continuousDamage(%this, %obj, %source, %pos, %radius, %damage, %damageType, %duration)
{
	if(%damage > 0)
	{
		%searchMask = $TypeMasks::PlayerObjectType;
		%rayMasks = ($TypeMasks::FxBrickObjectType | $TypeMasks::StaticObjectType);
		initContainerRadiusSearch(%pos, %radius, %searchMask);
		
		%col = containerSearchNext();
		
		while(isObject(%col))
		{
			if(!miniGameCanDamage(%source, %col))
			{
				%col = containerSearchNext();
				continue;
			}
			
			%hit = getWord(containerRayCast(%pos, %col.getEyePoint(), %rayMasks), 0);
			
			if(!isObject(%hit))
			{
				if(isObject(%source) && %source.getID() == %col.getID())
				{
					%col.damage(%source, %pos, %damage, $DamageType::Toxic);
					%col.toxic(1000);
				}
				else
				{
					%col.ToxicLoop(6, %damage, %source);
				}
			}
			
			%col = containerSearchNext();
		}
		
		if(%duration > 0)
		{
			%this.schedule(250, "continuousDamage", %obj, %source, %pos, %radius, %damage, %damagetype, %duration - 250);
		}
	}
}

function ChemGrenadeProjectile::onExplode(%this, %obj, %pos, %fade)
{
	%this.continuousDamage(%obj, %obj.client, %pos, %this.explosion.damageRadius, %this.explosion.radiusDamage / 32, %this.radiusDamageType, 10000);
	return parent::onExplode(%this, %obj, %pos, %fade);
}


