//GUI
exec("./LSG_Gui.gui");
exec("./LSGPreviewGui.gui");
exec("./LSGCGui.gui");
exec("./LSG_searchfile.gui");

//DataMan
exec("./Support_DataMan.cs");

//Main
exec("./script_LSG.cs");