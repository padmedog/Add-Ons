$Pref::Server::PlayerLights = 1; //The defualt server pref for lights.

package PlayerLightControl
{
	function servercmdLight(%client)
	{
		if($Pref::Server::PlayerLights == 1)
		{
			Parent::servercmdLight(%client);
		}
		else
		{
			commandToCLient(%client,'centerPrint',"Lights are disabled.",1);
		}
	
	}
};
activatePackage(PlayerLightControl);

function serverCmdToggleLights(%client)
{
	if(%client.isAdmin)
	{
		if($Pref::Server::PlayerLights == 0)
		{
			$Pref::Server::PlayerLights = 1;
			messageAll('', "\c0 Player lights have been \c3enabled\c0.");
		}
		else
		{
			$Pref::Server::PlayerLights = 0;
			messageAll('', "\c0 Player lights have been \c3disabled\c0.");
			for(%i = 0; %i<ClientGroup.getCount(); %i++)
			{
				%cl = ClientGroup.getObject(%i);
				%lght = %cl.player.light;
				if(isObject(%cl.player.light))
				{
					%lght.delete();
					%cl.player.light = 0;
				}
	
			}
		}
	}
}