//########## Cutlass

//### Projectiles

AddDamageType("gc_Cutlass",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_cutlass> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_cutlass> %1',0.2,1);

//### Item

datablock ItemData(gc_CutlassItem)
{
  uiName = "Cutlass";
  iconName = "./icon_cutlass";
  image = gc_CutlassImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./cutlass.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_CutlassImage)
{
  shapeFile = "./cutlass.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_CutlassItem;
  ammo = "";
  projectile = gc_MeleeProjectile;
  gc_MeleeSystem = 1;
  gc_MeleeSecondary = 1;
  gc_MeleeBlock = 2;
  directDamage = 60;
  headDamage = 100;
  vehicleDamage = 1;
  directDamageType = $DamageType::gc_Cutlass;
  range = 4;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateTransitionOnNoAmmo[1] = "Block";
  stateAllowImageChange[1] = true;
  stateSequence[1] = "Ready";

  stateName[2] = "PreFire";
  stateTimeoutValue[2] = 0.1;
  stateWaitForTimeout[2] = true;
  stateTransitionOnTimeout[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateAllowImageChange[2] = false;
  stateSequence[2] = "Ready";
  stateScript[2] = "onPreFire";

  stateName[3] = "Fire";
  stateTimeoutValue[3] = 0.4;
  stateWaitForTimeout[3] = true;
  stateTransitionOnTimeout[3] = "PostFire";
  stateAllowImageChange[3] = false;
  stateScript[3] = "onFire";
  stateSound[3] = gc_MeleeSwingSound;

  stateName[4] = "PostFire";
  stateTransitionOnTriggerUp[4] = "Ready";
  stateAllowImageChange[4] = true;
  stateSequence[4] = "Ready";

  stateName[5] = "Block";
  stateTransitionOnTimeout[5] = "Block";
  stateAllowImageChange[5] = true;
  stateSequence[5] = "Block";
  stateWaitForTimeout[5] = false;
  stateTransitionOnAmmo[5] = "Ready";
};

function gc_CutlassImage::onPreFire(%this,%obj,%slot)
{
  %obj.playThread(2,wrench);
}

function gc_CutlassImage::onFire(%this,%obj,%slot)
{
  %obj.playThread(2,activate);
  gc_MeleeRaycast(%this,%obj);
}
