%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("Content_Safe: JVS_Content is missing and is required for this Add-On to work.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/Content_Safe/types/SafeContent.cs");
}
