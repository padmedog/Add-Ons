//gun.cs

datablock AudioProfile(quakeVolleyFireSound)
{
   filename    = "./volley_gun.wav";
   description = AudioClose3d;
   preload = true;
};

//bullet trail effects
datablock ParticleData(quakeVolleyGunTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 1.0 0.0 0.4";
	colors[1]     = "1.0 0.2 0.0 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 0.85;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.00;

   times[0] = 0.0;
   times[1] = 0.02;
   times[2] = 0.3;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(quakeVolleyGunTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakeVolleyGunTrailParticle";
};

datablock ParticleData(quakemissileSmokeParticle)
{
	dragCoefficient      = 6;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1400;
	lifetimeVarianceMS   = 1305;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 0.2 0.0 0.2";
	colors[1]     = "1.0 1 0.9 0.1";
   colors[2]     = "0.20 0.20 0.20 0.05";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 1.95;
	sizes[1]      = 0.35;
   sizes[2]      = 0.15;
 	sizes[3]      = 0;

   times[0] = 0.0;
   times[1] = 0.01;
   times[2] = 0.4;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(quakemissileSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = -16.00;
   velocityVariance = 15.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakerocketSmokeParticle";
};

datablock ExplosionData(quakeVolleyGunExplosion : quakeRocketExplosion)
{
   //explosionShape = "";

   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";
   damageRadius = 5;
   radiusDamage = 30;

   impulseRadius = 6;
   impulseForce = 1600;
};

AddDamageType("quakeVolleyGun",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_volley> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_volley> %1',0.2,1);
datablock ProjectileData(quakeVolleyGunProjectile : gunProjectile)
{
   projectileShapeName = "./rocket_1.dts";

   directDamage        = 46;
   directDamageType    = $DamageType::quakeVolleyGun;
   radiusDamageType    = $DamageType::quakeVolleyGun;

   impactImpulse	     = 500;
   verticalImpulse	  = 1000;
   explosion           = quakeVolleyGunExplosion;
   particleEmitter     = quakeVolleyGunTrailEmitter; //bulletTrailEmitter;

   muzzleVelocity      = 150;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.9;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(quakeVolleyGunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./volley_gun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Volley Missiles";
	iconName = "./volleymissiles";
	doColorShift = true;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = quakeVolleyGunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(quakeVolleyGunImage)
{
   // Basic Item properties
	shapeFile = "./volley_gun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 -0.05";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = quakeVolleyGunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = quakeVolleyGunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "FireB";
	stateTimeoutValue[2]            = 0.09;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakerocketFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= quakeVolleyFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakeMissileSmokeEmitter;
	stateScript[3]                  = "onBoltback";
	stateEmitterTime[3]				= 0.04;
	stateEmitterNode[3]				= "tailNode";
	stateTimeoutValue[3]            = 0.32;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Fire";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.05;
	stateTransitionOnTimeout[5]     = "Wait";

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.01;
	stateTransitionOnTimeout[6]     = "Ready";

	stateName[7]                    = "FireB";
	stateTransitionOnTimeout[7]     = "FireC";
	stateTimeoutValue[7]            = 0.09;
	stateFire[7]                    = true;
	stateAllowImageChange[7]        = false;
	stateScript[7]                  = "onFire";
	stateWaitForTimeout[7]			= true;
	stateEmitter[7]					= quakerocketFireEmitter;
	stateEmitterTime[7]				= 0.05;
	stateEmitterNode[7]				= "muzzleNode";
	stateSound[7]					= quakeVolleyFireSound;

	stateName[8]                    = "FireC";
	stateTransitionOnTimeout[8]     = "Smoke";
	stateTimeoutValue[8]            = 0.09;
	stateFire[8]                    = true;
	stateAllowImageChange[8]        = false;
	stateScript[8]                  = "onFire";
	stateWaitForTimeout[8]			= true;
	stateEmitter[8]					= quakerocketFireEmitter;
	stateEmitterTime[8]				= 0.05;
	stateEmitterNode[8]				= "muzzleNode";
	stateSound[8]					= quakeVolleyFireSound;
};

function quakeVolleyGunImage::onFire(%this,%obj,%slot)
{
	%projectile = quakeVolleyGunProjectile;
	%spread = 0.0023;
	%shellcount = 1;

	%obj.playThread(2, shiftleft);
	%obj.playThread(0, shiftright);
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
			scale = "0.75 0.75 0.75";
		};
		MissionCleanup.add(%p);
	}
}
