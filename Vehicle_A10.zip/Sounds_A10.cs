datablock AudioDescription(AudiojetGPWS3d)
{
   volume   = 1;
   isLooping= false;
   is3D     = true;
   ReferenceDistance= 100.0;
   MaxDistance= 100.0;
   type     = $GuiAudioType;
};
datablock AudioDescription(AudiojetExt3d)
{
   volume   = 0.7;
   isLooping= false;
   is3D     = true;
   ReferenceDistance= 200.0;
   MaxDistance= 200.0;
   type     = $SimAudioType;
};
datablock AudioProfile(A10lockedSound)
{
   filename    = "./sounds/locked.wav";
   description = AudiojetGPWS3d;
   preload = true;
};
datablock AudioProfile(A10cannonfireSound)
{
   filename    = "./sounds/SmallMachineGunLoop.wav";
   description = AudiojetExt3d;
   preload = true;
};
datablock AudioProfile(A10flarefireSound)
{
   filename    = "./sounds/flare.wav";
   description = AudiojetExt3d;
   preload = true;
};
datablock AudioProfile(A10RocketfireSound)
{
   filename    = "./sounds/missilelaunch.wav";
   description = AudiojetExt3d;
   preload = true;
};
datablock AudioProfile(A10StartSound)
{
   filename    = "./sounds/F18Start.wav";
   description = AudiojetExt3d;
   preload = true;
};
datablock AudioProfile(A10AmbSound)
{
   filename    = "./sounds/F18engineAmb.wav";
   description = AudiojetExt3d;
   preload = true;
};

