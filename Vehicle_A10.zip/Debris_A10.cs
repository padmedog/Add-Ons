datablock DebrisData(A10ExplosionDebris1)
{
   emitters = "Vehicleburnemitter";

	shapeFile = "./shapes/deb1.dts";
	lifetime = 6.0;
	minSpinSpeed = -900.0;
	maxSpinSpeed = 900.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};
datablock DebrisData(A10ExplosionDebris2 : A10ExplosionDebris1)
{
 emitters = "Vehicleburnemitter";
	shapeFile = "./shapes/deb2.dts";
	
};
datablock DebrisData(A10ExplosionDebris3 : A10ExplosionDebris1)
{
 emitters = "Vehicleburnemitter";
	shapeFile = "./shapes/deb3.dts";
};
datablock DebrisData(A10ExplosionDebris4 : A10ExplosionDebris1)
{
 emitters = "Vehicleburnemitter";
	shapeFile = "./shapes/deb4.dts";
		minSpinSpeed = -500.0;
	maxSpinSpeed = 500.0;
};
datablock ExplosionData(A10FinalExplosion : vehicleFinalExplosion)
{
   debris = A10ExplosionDebris1;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 180;
   debrisThetaMin = 0;
   debrisThetaMax = 90;
   debrisVelocity = 28;
   debrisVelocityVariance = 5;
    damageRadius = 12;
   radiusDamage = 500;
   
      impulseRadius = 0;
   impulseForce = 0;
};
datablock ExplosionData(A10FinalExplosion2 : A10FinalExplosion)
{
	particleEmitter = "";
   debris = A10ExplosionDebris2;
   debrisNum = 2;

};
datablock ExplosionData(A10FinalExplosion3 : A10FinalExplosion)
{
	particleEmitter = "";
   debris = A10ExplosionDebris3;
   debrisNum = 2;

};
datablock ExplosionData(A10FinalExplosion4 : A10FinalExplosion)
{
	particleEmitter = "";
   debris = A10ExplosionDebris4;
   debrisNum = 1;

};
//Debris
AddDamageType("A10Exp",   '<color:FFFF00>[A-10 Explosion]<color:FF0000> %1',    '%2 <color:FFFF00>[A-10 Explosion]<color:FF0000> %1',0.2,1);
datablock ProjectileData(A10finalExplosionProjectile1 : vehicleFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 20;
   damageRadius        = 500;
   explosion           = A10FinalExplosion;

   directDamageType  = $DamageType::A10Exp;
   radiusDamageType  = $DamageType::A10Exp;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 0;


};

datablock ProjectileData(A10finalExplosionProjectile2 : A10finalExplosionProjectile1)
{
	explosion           = A10FinalExplosion2;
};
//new-----------------------


datablock ProjectileData(A10finalExplosionProjectile3 : A10finalExplosionProjectile1)
{
	explosion           = A10FinalExplosion3;
};
//new-----------------------


datablock ProjectileData(A10finalExplosionProjectile4 : A10finalExplosionProjectile1)
{
	explosion           = A10FinalExplosion4;
};

