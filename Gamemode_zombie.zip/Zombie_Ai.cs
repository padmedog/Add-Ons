//%client.tdmTeam -1 no team 0 - 5
function AiPlayer::StartPlayerSearch(%obj)
{
	if(%obj.spawnbrick.getgroup().client.minigame != 0 && %obj.spawnbrick.getgroup().client.minigame != -1 && $pref::Server::ZombiesEnabled == 1)
	{
		PlayerSearchLoop(%obj);
	}
}
function AiPlayer::StopPlayerSearch(%obj)
{
	cancel(%obj.searchsched);
	%obj.setmoveobject("");
}
function AiPlayer::zFollow(%player,%id)
{
	%player.isfollowing = 1;
	%player.setmovey(1);
	%player.setmoveobject(%id);
	%player.isAniStop = 0;
	%player.playthread(3,root);
	%player.doublefollow = 1;
	%player.isfollowingid = %id;
	if(%player.getdatablock().aimatplayer == 1)
	{
		%player.setaimobject(%id);
	}
	if(%player.armsup == 0)
	{
		%player.playthread(1,%player.getdatablock().FollowAnim);
		%player.armsup = 1;
	}
	if(getword(%player.getposition(),2)+1 < getword(%id.getposition(),2) && %player.spawnbrick.getgroup().client.minigame.ZombieCanJump == 1)
	{
		%player.setimagetrigger(2,1);
		%player.schedule(2000,setimagetrigger,2,0);
	}
	if(getword(%player.getposition(),2) > getword(%id.getposition(),2)+0.5 || %id.iscrouched())
	{
		if(%player.minigame.zombieCanCrouch)
		{
			%player.mountimage(ZombieCrouchImage,3);
			%player.setimagetrigger(3,1);
			%player.schedule(2000,setimagetrigger,3,0);
		}
	}
		
}
function AiPlayer::IncScore(%obj)
{
	//wait what?
}
function AiPlayer::ValidateAvatarPrefs(%obj)
{
	//wait what?
}

function playersearchloop(%player)
{
	//echo("Tick Tock");
	if(!isobject(%player) || %player.iszombie == 0)
	{
		return;
	}
	if(IsInMinigame(%player) == 0 || IsInMinigame(%player) == -1 || MinigameIncludesPlayerBricks(%player) != 1 || %player.spawnbrick.getgroup().client.minigame.EnableZombies == 0 || $pref::Server::ZombiesEnabled == 0)
	{	
		%player.spawnbrick.respawnvehicle();
		return;

	}
	if(%player.spawnbrick.getgroup().client.minigame.ZombieBrickDamage == 1 && %player.getdatablock().brickkillradius > 0)
	{
		ZombieFKillbrickSearch(%player);
	}
	if(%player.spawnbrick.getgroup().client.minigame.ZombieCanJump == 1 && %player.getdatablock().ZNoJump != 1)
	{
		%player.firstjumps = schedule(500,0,ZombieJumpSearch,%player);
		%player.secondjumps = schedule(2000,0,ZombieJumpSearch,%player);
	}
	if(%player.doublefollow != 1 && %player.isstrangling != 1)
	{
		%foundp = PlayerSearch(%player);
		//%foundp = testblah(%player);
		if(%foundp == 1 && %player.getdatablock().SpecialAttack == 1)
		{
			%player.schedule(200,SpecialAttack);
		}
		if(%foundp == 0)
		{
			%player.isfollowing = 0;
			if(%player.getdatablock().noRandomwalk != 1 && %player.minigame.zombieNoRandomWalk != 1)
			{
				%player.stopthread(1);
				%player.armsup = 0;
				%player.setmoveobject("");
				%dest = Randomwalk(%player);
				%player.setmoveDestination(%dest);
			}
			if(%player.getdatablock().noRandomwalk)
			{
				%player.setmoveobject("");
			}
			if(%player.getdatablock().noRandomwalk == 1 && %player.isAniStop == 0)
			{
				%player.isAniStop = 1;
				%player.playthread(3,%player.getdatablock().AnimationWhenStopped);
			}
			if(%player.minigame.zombieNoRandomWalk)
			{
				%player.setmovedestination(%player.getposition());
				%n = getrandom(0,5);
				if(%n == 5)
				{
					%player.playthread(3,sit);
				}
				if(%n == 2)
				{
					%player.playthread(3,crouch);
				}
			}
			//%player.randommove();
		}
	}
	if(%player.doublefollow == 1)
	{
		%player.doublefollow = 0;
	}
	//echo(%player.gettransform() SPC %player.getvelocity());
	%player.searchsched = schedule(3000,0,playersearchloop,%player);
}
 function PlayerSearch(%player)
{
	if(%player)
	{
		%searchMasks = $TypeMasks::PlayerObjectType;
		%IsPanic = %player.spawnbrick.getgroup().client.minigame.ZombieIsPanic;
		%AlwaysFindPlayer = %player.spawnbrick.getgroup().client.minigame.ZombieAlwaysFindPlayer;

		//chance zombies will attack
		%chance = %player.getdatablock().chance;
		if(!%chance)
		{
			%chance = 80;
		}
		if(%player.minigame.zombieChanceOver >= 0)
		{
			%chance = %player.minigame.zombieChanceOver;
		}
		if(%AlwaysFindPlayer == 1 || %IsPanic == 1)
		{
			%chance = 100;
		}
		//Radius
		%radius = %player.getdatablock().SearchRadius;
		
		if(%player.getdatablock().SearchRadius == 0)
		{
			%radius = 20;
		}
		if(%player.minigame.zombieRadiusOver >= 0)
		{
			%radius = %player.minigame.zombieRadiusOver;
		}
		if(%AlwaysFindPlayer == 1 && %player.getdatablock().noRandomwalk != 1)
		{
				%radius = 10000;
		}
		if(%IsPanic == 1)
		{
				%radius = 10000;
		}
		%pos = %player.getPosition();
		InitContainerRadiusSearch(%pos, %radius, %searchMasks);
	  
		while ((%targetid = containerSearchNext()) != 0 )
		{
			%id = %targetid.getId();
			//if(%id.getclassname() $= "Player" && IsInMinigame(%player) && IsInSameMinigame(%id,%player))
			if(IsInMinigame(%player) && IsInSameMinigame(%id,%player) && %id != %player && %player.ZTeam !$= %id.ZTeam)
			{
				%exc = 0;
				if(%player.isgoodguy == 1 && %id.getclassname() $= "Player" && %player.spawnbrick.getgroup().client.tdmTeam == %id.client.tdmTeam)%exc = 1;
					
				if(%player.isgoodguy && %id.isgoodguy && %player.spawnbrick.getgroup().client.tdmTeam == %id.spawnbrick.getgroup().client.tdmTeam)%exc = 1;

				if(%id.getclassname() $= "AiPlayer" && %id.iszombie != 1)%exc = 1;

				if(%id.isCloaked)%chance = -1;

				if(getrandom(0,100) <= %chance && %exc != 1)
				{
					if(ZombieLOSCheck(%id,%player))
					{
						%player.zFollow(%id);
						return 1;
					}
				}
			}
		}  
	}
	%player.clearmovey();
	return 0;
}
function ZombieJumpSearch(%this)
{
	if(isobject(%this) && %this.getstate !$= "Dead" && %this.spawnbrick.getgroup().client.minigame.ZombieCanJump == 1 && %this.getdatablock().ZNoJump != 1)
	{
		%eyeVec = %this.getforwardVector();

		//%startPos = vectoradd(vectoradd(%this.getposition(),"0 0 1"),"0" SPC getword(%eyeVec,1)*2 SPC "0");
		%startPos = vectoradd(%this.getEyePoint(),"0 0 -0.5");
		
		%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,8));

		%mask = $TypeMasks::FxBrickObjectType | $typemasks::PlayerObjectType | $TypeMasks::InteriorObjectType;
		%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
		//food(%startpos,%eyevec);

		if (%target)
		{
			//echo(%target);
			jumpbrick(getword(%target,0),%this);
			if(%target.getclassname() $= "FxDtsBrick" && %target.numevents >= 1)
			{
				%target.onactivate(%this,%this);
			}
			//if(%t
			//%this.setimagetrigger(2,1);
			//%this.schedule(500,setimagetrigger,2,0);
		}
	}
}
function jumpbrick(%col,%obj)
{
	if(%obj.spawnbrick.getgroup().client.minigame.ZombieCanJump == 1)
	{
	  if(%col.getClassName() $= "FxDtsBrick")
		  {
				%check = %col.getdatablock().BrickSizeZ;
				if(%check <= %obj.getdatablock().BrickMaxJumpHeight){
				%obj.setimagetrigger(2,1);
				%obj.schedule(500,setimagetrigger,2,0);
				}
		  }
		 else
		{
			 if(%col.getclassname() !$= "Player")
			{
				%obj.setimagetrigger(2,1);
				%obj.schedule(500,setimagetrigger,2,0);
			}
		}
	}
}
function Randomwalk(%player)
{
	if(%player.getdatablock().aimatplayer == 1)
	{
		%player.setaimobject("");
	}
	if(%player.isGoodGuy && %player.getdatablock().noGoodGuyFollow != 1 && %player.minigame.zombieGGCanFollow)
	{
		if(goodGuyFollowSearch(%player) == 1)
		{
			return;
		}
	}
	if(%player.minigame.zombieReturnToSpawn)
	{
		if(vectordist(%player.getposition(),%player.spawnbrick.getposition()) >= 20)
		{
			return %player.spawnbrick.getposition();
		}
	}
	%pos = %player.getposition();
	%ranpos = vectoradd(%pos,getrandom(-20,20) SPC getrandom(-20,20) SPC getword(%pos,2));
	if(getrandom(0,4) == 0)
	{
		%ranpos = %pos;
	}
	return %ranpos;
}
function goodGuyFollowSearch(%player)
{
	%pos = %player.getposition();
	%box = "40 40 5";
	%type = $TypeMasks::PlayerObjectType;
	InitContainerBoxSearch(%pos,%box,%type);
	while(%targ = containerSearchNext())
	{
		if(%targ.getclassname() $= "Player" && isInMinigame(%targ) && isInSameMinigame(%player,%targ) && %player.spawnbrick.getgroup().client.tdmTeam == %targ.client.tdmTeam)
		{	
			%player.setmoveobject(%targ);
			return 1;
		}
	}
	return 0;
}
function servercmdcast(%client,%sand){
	if(%sand $= "sandwich" || %sand $= "sandvich")
	{
		Messageclient(%client,'0',"You cast a sandwich...");
		%client.player.mountimage(sandwichimage,0);
		%client.player.playthread(2,armreadyright);

		if(%client.name $= "Badspot")
		{
			schedule(2000,0,messageclient,%client,'0',"...but Badspot... wait wtf?");
			return;
		}

		%client.player.schedule(2000,playthread,2,root);
		%client.player.schedule(2000,unmountimage,0);
		schedule(2000,0,messageclient,%client,'0',"...but Badspot takes it before you eat it.");
		return;
	}
	if(%sand $= "fireball"){
		Messageclient(%client,'0',"You cast a fireball, but then you realize this isn't Age of Time.");
		return;
	}
	if(%sand $= "Badspot")
	{
		Messageclient(%client,'0',"You have casted poorly.");
		schedule(10000,0,Messageclient,%client,'0',"<color:0000EE>Badspot connected.");
		schedule(14000,0,Messageclient,%client,'0',"<color:FFFF00>Badspot<color:FFFFFF>: hey");
		schedule(20000,0,Messageclient,%client,'0',"<color:0000EE>Badspot spawned.");
		return;
	}
	if(%sand $= "")
	{
		Messageclient(%client,'0',"You cast nothing.");
		schedule(2000,0,Messageclient,%client,'0',"Nothing happened.");
		return;
	}
		Messageclient(%client,'0',"You have casted poorly.");

}

function zombiedriveloop(%zomb)
{
	if(!isobject(%zomb))
	{
		return;
	}
	//%superrandom = getrandom(0,1);
//	if(%superrandom == 0 && IsInMinigame(%zomb))
	//{
	//	echo("we're actually here");
	//	Armor::DoDismount(%zomb.getdatablock(),%zomb);
	//	return;
//	}
		%a = getrandom(-1,1);
		%b = getrandom(-1,1);
		%zomb.setmovex(%a);
		%zomb.setmovey(%b);
		%zomb.drivesched = schedule(3000,0,zombiedriveloop,%zomb);

}
datablock AudioProfile(ZombieBrickKillSound)
{
	filename = "base/data/sound/breakbrick.wav";
	description = AudioClosest3d;
	preload = true;
};
function ZombieFKillbrickSearch(%player)
{
	if(%player)
	{
		%searchMasks = $TypeMasks::FxBrickObjectType;
		%radius = 5;
		%foundbrick = 0;
		%pos = vectoradd(%player.getPosition(),"0 0 1");
		InitContainerRadiusSearch(%pos, %radius, %searchMasks);
	  
		while ((%targetid = containerSearchNext()) != 0 ) 
		{

			%id = %targetid.getId();
			if(isobject(%id) && %id.isfakedead() != 1)
			{
				%foundbrick = 1;
				break;
			}
		}
		if(%foundbrick)
		{
			%boom = new Projectile()
			{
				dataBlock = ZBKMediumProjectile;
				initialVelocity = "0 0 0";
				initialPosition = %pos;
				Position = %pos;
				originpoint = %pos;
				scale = "1 1 1";
				sourceobject = %player;
				client = %player;
			};
			%player.playthread(2,activate2);
		}
	}
}
function DownPlayerScramble(%player)
{
	if($pref::Server::ZombiesEnabled == 1)
	{
		if(isobject(%player) && %player.client.minigame.EnableZombies != 0){
	   %searchMasks = $TypeMasks::PlayerObjectType;
	   %radius = 40;
	   %pos = %player.getPosition();
	   InitContainerRadiusSearch(%pos, %radius, %searchMasks);
	  
	   while ((%targetid = containerSearchNext()) != 0 ) {

	   %id = %targetid.getId();
	   if(%id.getclassname() $= "AiPlayer" && IsInMinigame(%player) && IsInSameMinigame(%player,%id) && MinigameIncludesPlayerBricks(%id) == 1 && %id.iszombie == 1)
		   {	if(%id.isstrangling != 1 && %id.isGoodGuy != 1)
				{
					%id.zFollow(%player);
					cancel(%id.searchsched);
					%id.searchsched = schedule(5000,0,playersearchloop,%id);
				}
		   }
	  }  
		}
	}
}
function IsInMinigame(%player)
{
	if(isobject(%player))
	{
		if(%player.getclassname() $= "Player")
		{
			if(%player.client.minigame != 0 && %player.client.minigame != -1)
			{
				return 1;

			}
		}
		if(%player.getclassname() $= "AiPlayer")
		{
			if(isobject(%player.spawnbrick) && %player.spawnbrick.getgroup().client.minigame != 0 && %player.spawnbrick.getgroup().client.minigame != -1)
			{
				return 1;
			}
		}
		return 0;
	}
}
function MinigameIncludesPlayerBricks(%player)
{
	if(isobject(%player))
	{
		%client = %player.client;
		if(%player.getclassname() $= "AiPlayer" && isobject(%player.spawnbrick))
		{
			%client = %player.spawnbrick.getgroup().client;
		}
		if(IsInMinigame(%player))
		{
			if(%client.minigame.playerdatablock.isSurvivor != 1)
			{
				//return 0;
			}
			if(%client == %client.minigame.owner)
			{
				return 1;
			}
			if(%client.minigame.UseAllPlayersBricks == 1)
			{
				return 1;
			}
		}
		return 0;
	}
}
function MinigameIncludesItem(%item)
{
	if(isobject(%item))
	{
		%client = %item.spawnbrick.getgroup().client;
		if(isobject(%client.minigame))
		{
			if(%client == %client.minigame.owner)
			{
				return 1;
			}
			if(%client.minigame.UseAllPlayersBricks == 1)
			{
				return 1;
			}
		}
		return 0;
	}
}
function IsInSameMinigame(%player,%bot)
{
	if(isobject(%player) && isobject(%bot))
	{
		if(%player.getclassname() $= "Player" && %bot.getclassname() $= "Player")
		{
			if(%player.client.minigame == %bot.client.minigame)
			{
				return 1;
			}
		}
		if(%player.getclassname() $= "Player" && %bot.getclassname() $= "AiPlayer")
		{
			if(%player.client.minigame == %bot.spawnbrick.getgroup().client.minigame)
			{
				return 1;
			}
		}
		if(%player.getclassname() $= "AiPlayer" && %bot.getclassname() $= "Player")
		{
			if(%bot.client.minigame == %player.spawnbrick.getgroup().client.minigame)
			{
				return 1;
			}

		}
		if(%player.getclassname() $= "AiPlayer" && %bot.getclassname() $= "AiPlayer")
		{
			if(%bot.spawnbrick.getgroup().client.minigame == %player.spawnbrick.getgroup().client.minigame)
			{
				return 1;
			}

		}
	}
	return 0;
}

function ZombieLOSCheck(%this,%obj)
{
	if(isobject(%this))
	{
		%tPos = %this.getPosition();
	}
	if(isobject(%obj))
	{
		%oPos = %obj.getposition();
	}
	if(%obj.minigame.zombieIsPanic || %obj.minigame.zombieAlwaysFindPlayer || %obj.minigame.zombieDisableLosChecks)
	{
		return 1;
	}
	if(vectordist(%tpos,%opos) <= 3)
	{
		return 1;
	}
	%dis = VectorSub(%oPos, %tPos);
	%normVec = VectorNormalize(%dis);

	//%eyeVec = %this.getEyeVector();
	%eyevec = %normVec;
				
	%startPos = vectoradd(%tpos,"0 0 2");
	%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,100));

	%mask = $TypeMasks::FxBrickObjectType | $typemasks::PlayerObjectType | $TypeMasks::InteriorObjectType;
	%target = ContainerRayCast(%startPos, %endPos, %mask,%this);

	//%p = new Projectile()
	// {
	// dataBlock = gunProjectile;
	//initialPosition = %startpos;
	//	  initialVelocity = vectorscale(%eyevec,20);
	//   };
	//   missionCleanup.add(%p); 

	if(%target == %obj)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}