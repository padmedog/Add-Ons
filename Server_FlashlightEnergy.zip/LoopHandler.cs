// How to use this:
//  Step 1. Create a LoopHandler object. This can be done using a named object or a classed object (if you can't work that out, you shouldn't be playing with this)
//  Step 2. On this object, you can call four methods:
//   1. .addEvent("loopID","myLoopingFunction",timeinms,"mySetupFunction")
//    This is to create a new loop. The LoopID should be an identifier you can use to cancel or pause this loop later. It must be unique, and can only contain A-Z and 0-9. No spaces, underscores, etc.
//    Your looping function can take one argument. This is an object, which is made for this one loop. You can store values on it, and they'll still be there next time the function happens.
//    The timeinms should be a number. It must be greater than or equal to 1. Your looping function will occur at a period of every (that many) milliseconds.
//    The "mySetupFunction" part is optional. If you put the name of a function in, it'll call that (with the memory object) before the loop starts, so use this if it needs to be setup somehow.

//   2. .cancelEvent("loopID")
//    This is to cancel a loop that this handler runs. Just pass that ID you chose earlier and it'll cancel and tidy up everything for you.

//   3. .pause("loopID") and .unpause("loopID")
//    These will stop and un-stop (respectively) the given loop, preserving the time remaining on its iterations so you can resume it later as if nothing ever happened.

function LoopHandler::addEvent(%this,%id,%callback,%time,%setup)
{
	// Validate the arguments and output descriptive errors if anything is wrong.
	// We use error() here not echo() because error() outputs the call stack (list of functions that have been called to get to where we are).
	// This makes it much easier to debug. Good practice. Don't use it everywhere but for things that really shouldn't happen, stick it in.
	if(%this.hasLoop[%id] || !validateLoopID(%id))
	{
		// The loop ID for reference later is invalid (not alphanumeric)
		error("Invalid loopID \"" @ %id @ "\" - ID in use or not alphanumeric");
		return -1;
	}
	if(!isFunction(%callback))
	{
		// The callback function does not exist
		error("Invalid function \"" @ %callback @ "\".");
		return -1;
	}
	if(%time < 1)
	{
		// The delay is too short
		error("Invalid delay value" SPC %time SPC "- must be at least 1ms");
	}

	// This little object can be used as memory for your looping function if you need to store data between calls.
	// It will be passed as the first and only argument.
	%this.loopMemory[%id] = new ScriptObject();
	if(!isObject(%this.memorySet))
	{
		%this.memorySet = new SimSet();
	}
	%this.memorySet.add(%this.loopMemory[%id]);

	if(isFunction(%setup))
	{
		// If you passed a valid function in as the last argument, it will be called before the loop begins, with the loop memory object as the first and only argument.
		call(%setup,%this.loopMemory[%id]);
	}

	%this.loopCallback[%id] = %callback;
	%this.loopDelay[%id] = %time;
	%this.hasLoop[%id] = 1;

	%this.fireEvent(%id);
}
function LoopHandler::cancelEvent(%this,%id)
{
	cancel(%this.loopSchedule[%id]);

	// Delete the loop memory object
	%this.loopMemory[%id].delete();

	// Blank out all the variables for tracking the loop data

	%this.hasLoop[%id] = "";
	%this.loopCallback[%id] = "";
	%this.loopDelay[%id] = "";
	%this.loopSchedule[%id] = "";
	%this.loopMemory[%id] = "";

	%this.lastRunTime[%id] = "";
	%this.resumeTime[%id] = "";
}
function LoopHandler::pause(%this,%id)
{
	if(!%this.hasLoop[%id] || %this.resumeTime[%id] !$= "")
	{
		return;
	}
	// The last run time is a $Sim::Time value, which is in seconds.
	// So we get the difference, in seconds, and multiply it by 1000.
	// This tells us how long it has been since the loop was last run, then we subtract that from the loop's tick length to get a resume time for when you .unpause() it.
	%this.resumeTime[%id] = %this.loopDelay[%id] - (($Sim::Time - %this.lastRunTime[%id]) * 1000);
	cancel(%this.loopSchedule[%id]);
}
function LoopHandler::unpause(%this,%id)
{
	if(!%this.hasLoop[%id] || %this.resumeTime[%id] $= "" || isEventPending(%this.loopSchedule[%id]))
	{
		// The isEventPending() call is to ensure that the schedule wasn't somehow restarted elsewhere.
		// This function shouldn't take precedence in this case.
		return;
	}
	// Now take the resume time that the .pause() created, and schedule to run this much later.
	%this.loopSchedule[%id] = %this.schedule(%this.resumeTime[%id],"fireEvent",%id);
	// Set the last run time to the unpause time, so if it's paused again it will run from now instead of before whenever it was paused (potentially ages ago)
	%this.lastRunTime[%id] = $Sim::Time;
	%this.resumeTime[%id] = "";
}

// Inner workings - concern yourself not, peasants

function LoopHandler::fireEvent(%this,%id)
{
	// Cancel the loop schedule, to prevent multiple copies of the same loop ID from running
	// Then call the loop function, passing in the loop memory object
	// Then schedule the new iteration of the loop
	cancel(%this.loopSchedule[%id]);
	if(!%this.hasLoop[%id])
	{
		return;
	}
	call(%this.loopCallback[%id],%this.loopMemory[%id]);
	%this.lastRunTime[%id] = $Sim::Time;
	if(%this.hasLoop[%id])
	{
		// The reason I added that if() is that if the loop decides it's done, it can tell the loop handler to remove it
		// This will result in an invalid call if it's been removed, so this prevents it from continuing the loop if it was removed
		%this.loopSchedule[%id] = %this.schedule(%this.loopDelay[%id],"fireEvent",%id);
	}
}
function validateLoopID(%id)
{
	%allowed = "abcdefghijklmnopqrstuvwxyz0123456789"; // Alphanumeric mask
	for(%i=0;%i<strlen(%id);%i++)
	{
		// Check if each character of the ID is in the allowed string
		if(stripos(%allowed,getsubstr(%id,%i,1)) == -1)
		{
			// This character isn't allowed, so the ID is invalid.
			return false;
		}
	}
	// It's fine, return true
	return true;
}
function LoopHandler::onRemove(%this)
{
	if(isObject(%this.memorySet))
	{
		// It has some loop memory stores so go through them, and delete them after this happens
		for(%i=0;%i<%this.memorySet.getCount();%i++)
		{
			%this.memorySet.getObject(%i).schedule(0,"delete");
		}
		// And also delete the memory set. Keep your room tidy, kids!
		%this.memorySet.schedule(0,"delete");
	}
}