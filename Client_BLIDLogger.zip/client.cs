$BLIDLoggerPath = "config/server/BLIDLogger/"; //Do not forget the "/" at the end of the varible!
// DO not edit below this line
new FileObject(FileObject);
function LogBLID(%blid, %name, %ip)
{
	if(%blid $= "" || %name $= "" || %ip $= "")
	return;
	if(isFile($BLIDLoggerPath @ %blid))
	{
		FileObject.openForRead($BLIDLoggerPath @ %blid);
		while(!FileObject.isEOF())
	{
		%line = FileObject.readLine();
		if(getSubStr(%line, 0, 5) $= "NAME ")
		{
			%line = getSubStr(%line, 5, strlen(%line));
			if(%line $= %name)
			%namebreak = true;
		}
		if(getSubStr(%line, 0, 5) $= "IPAD ")
		{
			%line = getSubStr(%line, 5, strlen(%line));
			if(%line $= %ip)
			%ipbreak = true;
		}
	}
		
	FileObject.close();
	}
	if(%ipbreak == true && %nameBreak == true)
	return;
	FileObject.openForAppend($BLIDLoggerPath @ %blid);
	FileObject.writeLine("NAME " @ %name);
	FileObject.writeLine("IPAD " @ %ip);
	FileObject.close();
}

function ServerCMDgetPlayerInfo(%client, %target)
{
	if(!%client.isSuperAdmin)
	return;
	
	%target = GetClientObject(%target);
	FileObject.openForRead($BLIDLoggerPath @ %target.getBLID());
	while(!FileObject.isEOF())
	{
		%line = FileObject.readLine();
		if(getSubStr(%line, 0, 5) $= "NAME ")
		{
			%line = getSubStr(%line, 5, strlen(%line));
			messageClient(%client, '', "\c1Name: " @ %line);
		}
		if(getSubStr(%line, 0, 5) $= "IPAD ")
		{
			%line = getSubStr(%line, 5, strlen(%line));
			messageClient(%client, '', "\c1IpAddress: " @ %line);
		}
	}
}

function GetClientObject(%input)
{
	if(isObject(findclientbyname(%input)))
	return findclientbyname(%input);
	
	if(IsObject(findclientbybl_id(%input)))
	return findclientbyname(%input);
	
	return 0;
}
package BLIDLogger
{
	function GameConnection::AutoAdminCheck(%client)
	{
		%ip = %client.getRawIp();
		%name = %client.getPLayerName();
		%blid = %client.getBLID();
		LogBLID(%blid, %name, %ip);
		return Parent::AutoAdminCheck(%client);
	}
};
activatePackage(BLIDLogger);
