////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
//  ////////    ////////    //                ////////    //////      //    ////////    ////////    //////    //
//  //          //    //    //                //          //    //    //       //       //    //    //    //  //
//  //          //    //    //                //          //    //    //       //       //    //    //    //  //
//  //          //    //    //                ////////    //    //    //       //       //    //    //////    //
//  //          //    //    //                //          //    //    //       //       //    //    ////      //
//  //          //    //    //                //          //    //    //       //       //    //    //  //    //
//  ////////    ////////    ////////          ////////    //////      //       //       ////////    //    //  //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// By Zeblote //
////////////////


//Create gui profiles
if(!isObject(ColorSetCreatorBorderProfile))
	new GuiControlProfile(ColorSetCreatorBorderProfile : GuiBitmapBorderProfile)
	{
		bitmap = "./img/contentArray";
	};
if(!isObject(ColorSetCreatorEditProfile))
	new GuiControlProfile(ColorSetCreatorEditProfile : GuiTextEditProfile)
	{
	   fillColor = "255 255 255 255";
	   borderColor = "188 191 193 255";
	   fontSize = 12;
	   fontType = "Verdana";
	   fontColor = "68 68 68 255";
	   fontColors[0] = "64 64 64 255";
	   fontColors[1] = "0 0 0";
	   numbersOnly = 1;
	};
if(!isObject(ColorSetCreatorEditProfile2))
	new GuiControlProfile(ColorSetCreatorEditProfile2 : ColorSetCreatorEditProfile)
	{
	   numbersOnly = 0;
	};
if(!isObject(ColorSetCreatorButtonProfile))
	new GuiControlProfile (ColorSetCreatorButtonProfile : GuiDefaultProfile)
	{
		fontColor = "68 68 68 255";
		fontSize = 15;
		fontType = "Verdana Bold";
		justify = "center";
	};
if(!isObject(ColorSetCreatorListProfile))
	new GuiControlProfile (ColorSetCreatorListProfile : GuiDefaultProfile)
	{
		fontColor = "68 68 68 255";
		fontSize = 13;
		fontType = "Verdana";
	};
if(!isObject(ColorSetCreatorScrollProfile))
	new GuiControlProfile(ColorSetCreatorScrollProfile)
	{
	   fontType = "Book Antiqua";
	   fontSize = 22;
	   justify = center;
	   fontColor = "0 0 0";
	   fontColorHL = "130 130 130";
	   fontColorNA = "255 0 0";
	   fontColors[0] = "0 0 0";
	   fontColors[1] = "0 255 0";  
	   fontColors[2] = "0 0 255"; 
	   fontColors[3] = "255 255 0";
	   hasBitmapArray = true;	   
	   bitmap = "./img/scrollArray";
	};

//Create container object
if(!isObject(ColorSetCreator))
	new ScriptGroup(ColorSetCreator){};

//Create gui
exec("./ColorSetCreator.gui");

//Do some initial stuff
function ColorSetCreator::Init()
{
	ColorSetCreator::ClearSets();
}

//Remove the set objects and the gui objects
function ColorSetCreator::ClearSets()
{
	ColorSetCreator::DeselectColor();
	ColorSetCreator_PreviewBlock.visible = 1;
	ColorSetCreator_PreviewText.setText("<color:444444><font:Verdana Bold:12>Create or load a new set to preview.");
	ColorSetCreator_Window.setText("Color Set Editor | No Set Open");
	ColorSetCreator_PreviewSwatch.clear();
	ColorSetCreator_PreviewSwatch.resize(1,1,1,1);
	ColorSetCreator_ColEditPasteBlock.visible = 1;
	if(isObject(ColorSetCreator.active))
		ColorSetCreator.active.delete();
	ColorSetCreator::SetToolbox("100 CreateNewSet Create Set" TAB "100 LoadSet Load Set" TAB "100 StealSet Steal Set");
}

//Deselect color and close color editor
function ColorSetCreator::DeselectColor()
{
	if(isObject(ColorSetCreator.active.select))
		ColorSetCreator.active.select.delete();
	ColorSetCreator.active.currentdiv = -1;
	ColorSetCreator.active.currentcolor = -1;
	ColorSetCreator_ColEditBlock.visible = 1;
	ColorSetCreator_ColEditText.setText("<color:444444><font:Verdana Bold:12>Select a color in the preview to edit");
	ColorSetCreator_ColEditPreview.color = "0 0 0 0";
	ColorSetCreator_ColEditRSlider.setValue(0);
	ColorSetCreator_ColEditGSlider.setValue(0);
	ColorSetCreator_ColEditBSlider.setValue(0);
	ColorSetCreator_ColEditASlider.setValue(0);
	ColorSetCreator_ColEditRField.setText(0);
	ColorSetCreator_ColEditGField.setText(0);
	ColorSetCreator_ColEditBField.setText(0);
	ColorSetCreator_ColEditAField.setText(0);
	ColorSetCreator_ColEditRField.makeFirstResponder(0);
	ColorSetCreator_ColEditGField.makeFirstResponder(0);
	ColorSetCreator_ColEditBField.makeFirstResponder(0);
	ColorSetCreator_ColEditAField.makeFirstResponder(0);
	ColorSetCreator::SetToolbox("100 SaveSet Save Set" TAB "180 ShowInSinglePlayer Show In Single Player" TAB "100 CloseSet Close Set");
}

//Select a color from the preview and open it in the color editor
function ColorSetCreator::SelectColor(%div, %color, %always)
{
	if(ColorSetCreator.active.currentdiv == %div && ColorSetCreator.active.currentcolor == %color)
	{
		ColorSetCreator::DeselectColor();
		if(%always != 1)
			return;
	}
	if(isObject(ColorSetCreator.active.select))
		ColorSetCreator.active.select.delete();
	ColorSetCreator.active.currentdiv = %div;
	ColorSetCreator.active.currentcolor = %color;
	ColorSetCreator_ColEditBlock.visible = 0;
	ColorSetCreator_ColEditText.setText("<color:444444><font:Verdana Bold:12>Edit the color with the sliders/boxes");
	%col = ColorSetCreator.active.color[%div, %color];
	ColorSetCreator_ColEditPreview.color = %col;
	ColorSetCreator.active.currentR = getWord(%col, 0);
	ColorSetCreator.active.currentG = getWord(%col, 1);
	ColorSetCreator.active.currentB = getWord(%col, 2);
	ColorSetCreator.active.currentA = getWord(%col, 3);
	ColorSetCreator_ColEditRSlider.setValue(getword(%col, 0));
	ColorSetCreator_ColEditGSlider.setValue(getword(%col, 1));
	ColorSetCreator_ColEditBSlider.setValue(getword(%col, 2));
	ColorSetCreator_ColEditASlider.setValue(getword(%col, 3));
	ColorSetCreator_ColEditRField.setText(getword(%col, 0));
	ColorSetCreator_ColEditGField.setText(getword(%col, 1));
	ColorSetCreator_ColEditBField.setText(getword(%col, 2));
	ColorSetCreator_ColEditAField.setText(getword(%col, 3));
	ColorSetCreator.active.divbg[%div].add(
		%select = new GuiBitmapCtrl()
		{
			position = "1 " @ %color * 24 + 1;
			extent = "26 26";
			bitmap = "./img/selected";
			new GuiBitmapButtonCtrl()
			{
				position = "3 3";
				extent = "20 20";
				command = "ColorSetCreator::DeselectColor();";
				text = " ";
				bitmap = "./img/select";
			};
		}
	);
	ColorSetCreator.active.select = %select;
	if(ColorSetCreator.CopyColorCount)
		ColorSetCreator::SetToolbox("100 SetDivName Set Div Name" TAB "100 DeleteColor Delete Color" TAB "100 DeleteDiv Delete Div" TAB "100 InsertColor Insert Color" TAB "100 InsertDiv Insert Div" TAB "100 CopyColorPrev Copy Color" TAB "120 CopyDivUp Copy Div Up" TAB "120 CopyDivDown Copy Div Down" TAB "180 PasteInto Paste Into Current Div" TAB "180 PasteAsNew Paste As New Div");
	else
		ColorSetCreator::SetToolbox("100 SetDivName Set Div Name" TAB "100 DeleteColor Delete Color" TAB "100 DeleteDiv Delete Div" TAB "100 InsertColor Insert Color" TAB "100 InsertDiv Insert Div" TAB "100 CopyColorPrev Copy Color" TAB "120 CopyDivUp Copy Div Up" TAB "120 CopyDivDown Copy Div Down");
}

//Copy the color from the color editor onto the selected color in the preview
function ColorSetCreator::ApplyColor()
{
	ColorSetCreator.active.colswatch[ColorSetCreator.active.currentdiv, ColorSetCreator.active.currentcolor].color = ColorSetCreator_ColEditPreview.color;
	ColorSetCreator.active.color[ColorSetCreator.active.currentdiv, ColorSetCreator.active.currentcolor] = ColorSetCreator_ColEditPreview.color;
}

//Copy the color from the color editor into buffer
function ColorSetCreator::CopyColor()
{
	ColorSetCreator.active.buffer = ColorSetCreator_ColEditPreview.color;
	ColorSetCreator_ColEditPasteBlock.visible = 0;
}

//Paste the color from the buffer into the color editor
function ColorSetCreator::PasteColor()
{
	%col = ColorSetCreator.active.buffer;
	ColorSetCreator_ColEditPreview.color = %col;
	ColorSetCreator.active.currentR = getWord(%col, 0);
	ColorSetCreator.active.currentG = getWord(%col, 1);
	ColorSetCreator.active.currentB = getWord(%col, 2);
	ColorSetCreator.active.currentA = getWord(%col, 3);
	ColorSetCreator_ColEditRSlider.setValue(getword(%col, 0));
	ColorSetCreator_ColEditGSlider.setValue(getword(%col, 1));
	ColorSetCreator_ColEditBSlider.setValue(getword(%col, 2));
	ColorSetCreator_ColEditASlider.setValue(getword(%col, 3));
	ColorSetCreator_ColEditRField.setText(getword(%col, 0));
	ColorSetCreator_ColEditGField.setText(getword(%col, 1));
	ColorSetCreator_ColEditBField.setText(getword(%col, 2));
	ColorSetCreator_ColEditAField.setText(getword(%col, 3));
}

//Called when a color slider is moved or something is entered in the box
function ColorSetCreator::OnSetColor(%type, %box)
{
	if(%box)
	{
		%val = eval("return ColorSetCreator_ColEdit" @ %type @ "Field.getValue();");
		if(%val > 255)
			%val = 255;
		if(%val < 0)
			%val = 0;
		eval("ColorSetCreator_ColEdit" @ %type @ "Field.setText(" @ %val @ ");");
		eval("ColorSetCreator_ColEdit" @ %type @ "Slider.setValue(" @ %val @ ");");
		eval("ColorSetCreator.active.current" @ %type @ " = " @ %val @ ";");
	}
	else
	{
		%val = mfloor(eval("return ColorSetCreator_ColEdit" @ %type @ "Slider.getValue();"));
		eval("ColorSetCreator_ColEdit" @ %type @ "Field.setText(" @ %val @ ");");
		eval("ColorSetCreator.active.current" @ %type @ " = " @ %val @ ";");		
	}
	ColorSetCreator_ColEditPreview.color = ColorSetCreator.active.currentR SPC ColorSetCreator.active.currentG SPC ColorSetCreator.active.currentB SPC ColorSetCreator.active.currentA;
}

//Create a new division in the active set with one color: red
function ColorSetCreator::CreateDiv()
{
	if(ColorSetCreator::GetColorCount() >= 64)
	{
		ColorSetCreator::Error("Can't have more than 64 colors.");
		return;
	}
	ColorSetCreator.active.colorsindiv[ColorSetCreator.active.divs] = 1;
	ColorSetCreator.active.color[ColorSetCreator.active.divs, 0] = "255 0 0 255";
	ColorSetCreator.active.divs++;
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(ColorSetCreator.active.divs - 1, 0);
	ColorSetCreator.active.divname[ColorSetCreator.active.divs - 1] = "New Division";
}

//Create a new color to a specific division
function ColorSetCreator::CreateColor(%div)
{
	if(ColorSetCreator::GetColorCount() >= 64)
	{
		ColorSetCreator::Error("Can't have more than 64 colors.");
		return;
	}
	ColorSetCreator.active.color[%div, ColorSetCreator.active.colorsindiv[%div]] = "255 0 0 255";
	ColorSetCreator.active.colorsindiv[%div] += 1;
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(%div, ColorSetCreator.active.colorsindiv[%div] - 1);
}

//Loads a colorset from a colorset.txt file and builds it into the gui
function ColorSetCreator::LoadSetFromFile(%path)
{
	if(!isFile(%path))
	{
		ColorSetCreator::Error("File doesn't exist.");
		return;
	}
	%read = new FileObject(){};
	if(!%read.openForRead(%path))
	{
		ColorSetCreator::Error("Unable to read file.");
		%read.delete();
		return;
	}
	ColorSetCreator::ClearSets();
	ColorSetCreator_Window.setText("Color Set Editor | Loaded Set");
	ColorSetCreator.add(%set = new ScriptObject(){divs = 0;});
	ColorSetCreator.active = %set;
	%currentdiv = 0;
	%currentcolor = 0;
	while(!%read.isEOF())
	{
		%line = %read.readLine();
		if(strPos(%line, "//") != -1)
			%line = getSubStr(%line, 0, strPos(%line, "//"));
		if(getSubStr(%line, 0, 4) $= "DIV:")
		{
			%set.divname[%currentdiv] = trim(getSubStr(%line, 4, strLen(%line) - 4));
			%set.colorsindiv[%currentdiv] = %currentcolor;
			%currentcolor = 0;
			%currentdiv++;
			%set.divs++;
		}
		else if(getWordCount(%line) == 4)
		{
			if(getSubStr(%line, 1, 1) $= ".")
			{
				for(%i = 0; %i < 4; %i++)
					%line = %line SPC mfloor(getWord(%line, %i) * 255);
				%line = getWords(%line, 4, 7);
			}
			for(%i = 0; %i < 4; %i++)
				if(getWord(%line, %i) < 0 || getWord(%line, %i) > 255)
					%line = "255 0 0 255";
			%set.color[%currentdiv, %currentcolor] = %line;
			%currentcolor++;
		}
	}
	%read.close();
	%read.delete();
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(0,0);
	ColorSetCreator::BoxOK("Set Loaded", "The set has been loaded.");
}

//Create a new set object and set up basic gui for creating the first column
function ColorSetCreator::CreateNewSet()
{
	ColorSetCreator::ClearSets();
	ColorSetCreator_Window.setText("Color Set Editor | New Set");
	ColorSetCreator.add(%set = new ScriptObject(){divs = 0;});
	ColorSetCreator.active = %set;
	ColorSetCreator::RenderSet();
	ColorSetCreator::CreateDiv();
	ColorSetCreator::BoxOK("Set Created", "The set has been created.");
}

//Creates gui for the active set
function ColorSetCreator::RenderSet()
{
	ColorSetCreator_PreviewBlock.visible = 0;
	ColorSetCreator_PreviewText.setText("<color:444444><font:Verdana Bold:12>Click colors to edit | Click + to add colors/divs");
	ColorSetCreator::DeselectColor();
	ColorSetCreator_PreviewSwatch.clear();
	%mostcolors = 0;
	for(%i = 0; %i < ColorSetCreator.active.divs; %i++)
	{
		ColorSetCreator_PreviewSwatch.add(
			%divbg = new GuiSwatchCtrl()
			{
				position = %i * 32 @ " 3";
				extent = "28 " @ ColorSetCreator.active.colorsindiv[%i] * 24 + 28;
				color = "0 0 0 30";
			}
		);
		%divbg.add(
			%addbutton = new GuiBitmapButtonCtrl()
			{
				position = "2 " @ ColorSetCreator.active.colorsindiv[%i] * 24 + 2;
				extent = "24 24";
				text = " ";
				bitmap = "./img/plus";
				command = "ColorSetCreator::CreateColor(" @ %i @ ");";
			}
		);
		for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i]; %j++)
		{
			%divbg.add(
				%colbg = new GuiBitmapCtrl()
				{
					position = "4 " @ %j * 24 + 4;
					extent = "20 20";
					bitmap = "./img/grid";
					wrap = 1;
				}
			);
			%colbg.add(
				%colswatch = new GuiSwatchCtrl()
				{
					position = "0 0";
					extent = "20 20";
					color = ColorSetCreator.active.color[%i, %j];
				}
			);
			%colswatch.add(
				%colbutton = new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "20 20";
					text = " ";
					bitmap = "./img/select";
					command = "ColorSetCreator::SelectColor(" @ %i @ ", " @ %j @ ");";	
				}
			);
			ColorSetCreator.active.colbg[%i, %j] = %colbg;
			ColorSetCreator.active.colswatch[%i, %j] = %colswatch;
			ColorSetCreator.active.colbutton[%i, %j] = %colbutton;
			ColorSetCreator.active.select[%i, %j] = %select;
		}
		if(ColorSetCreator.active.colorsindiv[%i] > %mostcolors)
			%mostcolors = ColorSetCreator.active.colorsindiv[%i];
		ColorSetCreator.active.divbg[%i] = %divbg;
		ColorSetCreator.active.addbutton[%i] = %addbutton;
	}
	ColorSetCreator_PreviewSwatch.add(
		%newdivbg = new GuiSwatchCtrl()
		{
			position = ColorSetCreator.active.divs * 32 @ " 3";
			extent = "28 28";
			color = "0 0 0 30";			
		}
	);
	%newdivbg.add(
		%newdivbutton = new GuiBitmapButtonCtrl()
		{
			position = "2 2";
			extent = "24 24";
			text = " ";
			bitmap = "./img/plus";
			command = "ColorSetCreator::CreateDiv();";			
		}
	);
	ColorSetCreator_PreviewSwatch.resize(1,1,ColorSetCreator.active.divs * 32 + 31, %mostcolors * 24 + 34);
}

//Create toolbox entries for button list
function ColorSetCreator::SetToolbox(%box)
{
	ColorSetCreator_Toolbox_MainSwatch.clear();
	ColorSetCreator_Toolbox_MainSwatch.add(
		%swatch = new GuiSwatchCtrl()
		{
			position = "0 3";
			extent = "1 28";
			color = "0 0 0 30";
		}
	);
	%btnpos = "4 4";
	for(%i = 0; %i < getFieldCount(%box); %i++)
	{
		%field = getField(%box, %i);
		%width = getWord(%field, 0);
		%cmd = getWord(%field, 1);
		%title = getWords(%field, 2, getWordCount(%field));
		%swatch.add(
			%swa = new GuiSwatchCtrl()
			{
				position = %btnpos @ " 4";
				extent = %width @ " 20";
				color = "0 0 0 30";
			}
		);
		%swa.add(
			%button = new GuiBitmapButtonCtrl()
			{
				profile = "ColorSetCreatorButtonProfile";
				position = "2 2";
				text = %title;
				extent = %width - 4 @ " 16";
				command = "ColorSetCreator::" @ %cmd @ "();";
				bitmap = "base/client/ui/btnBlank";
			}
		);
		%btnpos += %width + 4;
	}
	%swatch.resize(0, 3, %btnpos, 28);
	ColorSetCreator_Toolbox_MainSwatch.resize(1, 1, %btnpos, 31);
}

//Block the Windows and open a modal
function ColorSetCreator::SetModalWindow(%name)
{
	if(ColorSetCreator.modalOpen)
		ColorSetCreator::CloseModalWindow();
	ColorSetCreator.PreviewVis = ColorSetCreator_PreviewBlock.visible;
	ColorSetCreator.ColEditVis = ColorSetCreator_ColEditBlock.visible;
	ColorSetCreator.ToolboxVis = ColorSetCreator_ToolboxBlock.visible;
	ColorSetCreator_PreviewBlock.visible = 1;
	ColorSetCreator_ColEditBlock.visible = 1;
	ColorSetCreator_ToolboxBlock.visible = 1;
	ColorSetCreator_ModalSwatch.visible = 1;
	nameToId("ColorSetCreator_Modal_" @ %name).visible = 1;
	ColorSetCreator.modalOpen = 1;
	ColorSetCreator.currentModal = %name;
}

//Close modal and unblock the windows
function ColorSetCreator::CloseModalWindow()
{
	if(!ColorSetCreator.modalOpen)
		return;
	ColorSetCreator_PreviewBlock.visible = ColorSetCreator.PreviewVis;
	ColorSetCreator_ColEditBlock.visible = ColorSetCreator.ColEditVis;
	ColorSetCreator_ToolboxBlock.visible = ColorSetCreator.ToolboxVis;
	ColorSetCreator_ModalSwatch.visible = 0;
	nameToId("ColorSetCreator_Modal_" @ ColorSetCreator.currentModal).visible = 0;
	ColorSetCreator.modalOpen = 0;
	ColorSetCreator.currentModal = "";
}

//Make a super cool YES/NO box
function ColorSetCreator::BoxYesNo(%title, %text, %yescallback, %nocallback)
{
	ColorSetCreator_BoxYesNo_Title.setText("<font:Verdana Bold:12><color:444444>" @ %title);
	ColorSetCreator_BoxYesNo_Text.setText("<font:Verdana Bold:12><color:444444>" @ %text);
	ColorSetCreator_BoxYesNo_Yes.command = "ColorSetCreator::CloseModalWindow();" @ %yescallback;
	ColorSetCreator_BoxYesNo_No.command = "ColorSetCreator::CloseModalWindow();" @ %nocallback;
	ColorSetCreator::SetModalWindow("BoxYesNo");
}

//Make a super cool OK box
function ColorSetCreator::BoxOK(%title, %text, %okcallback)
{
	ColorSetCreator_BoxOK_Title.setText("<font:Verdana Bold:12><color:444444>" @ %title);
	ColorSetCreator_BoxOK_Text.setText("<font:Verdana Bold:12><color:444444>" @ %text);
	ColorSetCreator_BoxOK_OK.command = "ColorSetCreator::CloseModalWindow();" @ %okcallback;
	ColorSetCreator::SetModalWindow("BoxOK");
}

//Make a super cool ERROR box
function ColorSetCreator::Error(%msg)
{
	ColorSetCreator_BoxError_Text.setText("<color:444444><font:Verdana Bold:12>" @ %msg);
	ColorSetCreator::SetModalWindow("BoxError");
}

//Delete a color in a div
function ColorSetCreator::DeleteColor(%yes)
{
	if(%yes)
	{
		%col = ColorSetCreator.active.currentcolor;
		%div = ColorSetCreator.active.currentdiv;
		if(ColorSetCreator.active.colorsindiv[%div] > 1)
		{
			ColorSetCreator.active.colorsindiv[%div]--;
			for(%i = %col; %i < ColorSetCreator.active.colorsindiv[%div]; %i++)
			{
				ColorSetCreator.active.color[%div, %i] = ColorSetCreator.active.color[%div, %i + 1];
			}
			ColorSetCreator.active.color[%div, %i++] = "";
			ColorSetCreator::RenderSet();
			ColorSetCreator::SelectColor(%div, (%col > ColorSetCreator.active.colorsindiv[%div] - 1 ? %col - 1 : %col));
		}
		else
		{
			ColorSetCreator::DeleteDiv(1);
		}
	}
	else
		ColorSetCreator::BoxYesNo("Delete Color", "Delete the selected color?", "ColorSetCreator::DeleteColor(1);");
}

//Delete the selected division
function ColorSetCreator::DeleteDiv(%yes)
{
	if(%yes)
	{
		%div = ColorSetCreator.active.currentdiv;
		if(ColorSetCreator.active.divs > 1)
		{
			ColorSetCreator.active.divs--;
			for(%i = %div; %i < ColorSetCreator.active.divs; %i++)
			{
				ColorSetCreator.active.colorsindiv[%i] = ColorSetCreator.active.colorsindiv[%i + 1];
				for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i + 1]; %j++)
				{
					ColorSetCreator.active.color[%i, %j] = ColorSetCreator.active.color[%i + 1, %j];
				}
			}
			for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i + 1]; %j++)
			{
				ColorSetCreator.active.color[%i, %j] = "";
			}
			ColorSetCreator.active.colorsindiv[%i + 1] = "";
			ColorSetCreator::RenderSet();
			ColorSetCreator::SelectColor((%div == ColorSetCreator.active.divs ? %div - 1 : %div), 0);
		}
		else
		{
			ColorSetCreator::ClearSets();
		}
	}
	else
		ColorSetCreator::BoxYesNo("Delete Division", "Delete the selected division?", "ColorSetCreator::DeleteDiv(1);");
}

//Delete the open set
function ColorSetCreator::CloseSet()
{
	ColorSetCreator::BoxYesNo("Close Set", "Your set will not be saved.", "ColorSetCreator::ClearSets();");
}

//Insert a color after the selected one
function ColorSetCreator::InsertColor()
{
	if(ColorSetCreator::GetColorCount() >= 64)
	{
		ColorSetCreator::Error("Can't have more than 64 colors.");
		return;
	}
	%div = ColorSetCreator.active.currentdiv;
	%col = ColorSetCreator.active.currentcolor;
	ColorSetCreator.active.colorsindiv[%div]++;
	for(%i = ColorSetCreator.active.colorsindiv[%div] - 1; %i > %col; %i--)
	{
		ColorSetCreator.active.color[%div, %i] = ColorSetCreator.active.color[%div, %i - 1];
	}
	ColorSetCreator.active.color[%div, %col + 1] = "255 0 0 255";
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(%div, %col + 1);
}

//Inset a div after the selected one
function ColorSetCreator::InsertDiv()
{
	if(ColorSetCreator::GetColorCount() >= 64)
	{
		ColorSetCreator::Error("Can't have more than 64 colors.");
		return;
	}
	%div = ColorSetCreator.active.currentdiv;
	if(%div < ColorSetCreator.active.divs - 1)
	{
		ColorSetCreator.active.divs++;
		for(%i = ColorSetCreator.active.divs - 1; %i > %div + 1; %i--)
		{
			ColorSetCreator.active.colorsindiv[%i] = ColorSetCreator.active.colorsindiv[%i - 1];
			for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i - 1]; %j++)
			{
				ColorSetCreator.active.color[%i, %j] = ColorSetCreator.active.color[%i - 1, %j];
			}
			ColorSetCreator.active.divname[%i] = ColorSetCreator.active.divname[%i - 1];
		}
		ColorSetCreator.active.colorsindiv[%div + 1] = 1;
		ColorSetCreator.active.color[%div + 1, 0] = "255 0 0 255";
		ColorSetCreator::RenderSet();
		ColorSetCreator::SelectColor(%div + 1, 0);
		ColorSetCreator.active.divname[%div + 1] = "New Division";
	}
	else
		ColorSetCreator::CreateDiv();
}

//Get a list of colorset.txt filed to load into the editor
function ColorSetCreator::LoadSet()
{
	ColorSetCreator_SelectFileToLoad_List.clear();
	%search = "Add-Ons/Colorset_*/colorset.txt";
	%count = 0;
	for(%f = findfirstfile(%search); isfile(%f); %f = findnextfile(%search))
	{
		%path = getSubStr(%f, 0, strLen(%f) - 12);
		if(isFile(%path @ "description.txt"))
		{  
			%title = "Unnamed Colorset";
			%read = new FileObject();
			if(%read.openForRead(%path @ "description.txt"))
			{
				while(!%read.isEOF())
				{
					%line = %read.readLine();
					if(strPos(%line, "Title:") $= 0)
					{
						%title = trim(getSubStr(%line, 6, strLen(%line) - 6));
						break;
					}
				}
				%read.close();
			}
			else
				echo("Failed to read description.txt for colorset");
				%read.delete();
		}
		else
			echo("Failed to read description.txt for colorset");
		ColorSetCreator.filePath[%count] = %path;		
		ColorSetCreator_SelectFileToLoad_List.addRow(%count, %title);
		%count++;
	}
	ColorSetCreator::SetModalWindow("SelectFileToLoad");
}

//Load the set from the file and close modal
function ColorSetCreator::LoadSetFile()
{
	%path = ColorSetCreator.filePath[ColorSetCreator_SelectFileToLoad_List.getSelectedId()] @ "colorSet.txt";
	ColorSetCreator::CloseModalWindow();
	ColorSetCreator::LoadSetFromFile(%path);
}

//Copy the colorset from the server #hax
function ColorSetCreator::StealSet()
{
	if(!ServerConnection.getCount())
	{
		ColorSetCreator::Error("You aren't in a server!");
		return;
	}
	ColorSetCreator::ClearSets();
	ColorSetCreator_Window.setText("Color Set Editor | Stolen Set");
	ColorSetCreator.add(%set = new ScriptObject(){divs = 0;});
	ColorSetCreator.active = %set;
	%currentColor = 0;
	for(%i = 0; %i < $Paint_NumPaintRows - 1; %i++)
	{
		%set.divname[%i] = getSprayCanDivisionName(%i);
		%count = getSprayCanDivisionSlot(%i) + 1;
		%set.colorsindiv[%i] = %count - %currentcolor;
		for(%j = %currentColor; %j <= %count; %j++)
		{
			%line = getColorIDTable(%j);
			if(getSubStr(%line, 1, 1) $= ".")
			{
				for(%v = 0; %v < 4; %v++)
					%line = %line SPC mfloor(getWord(%line, %v) * 255);
				%line = getWords(%line, 4, 7);
			}
			for(%v = 0; %v < 4; %v++)
				if(getWord(%line, %v) < 0 || getWord(%line, %v) > 255)
					%line = "255 0 0 255";
			%set.color[%i, %j - %currentcolor] = %line;
		}
		%currentcolor = %count;
	}
	%set.divs = $Paint_NumPaintRows - 1;
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(0,0);
	ColorSetCreator::BoxOK("Set Stolen", "The server's set has been loaded.");
}

//How many color datablocks do we have?
function ColorSetCreator::GetColDataBlockCount()
{
	for(%i = 63; %i > -1; %i--)
		if(isObject(nameToId("color" @ %i @ "SprayCanImage")))
			return %i + 1;
	return 0;
}

//Show the colorset in a singleplayer
function ColorSetCreator::ShowInSinglePlayer(%state)
{
	if(%state $= "")
	{
		if($Server::ServerType !$= "SinglePlayer")
		{
			ColorSetCreator::Error("You are not in a SP");
			return;
		}
		if(getBrickCount() > 0)
			ColorSetCreator::BoxYesNo("Preview Set in SP", "This will clear bricks first.", "ColorSetCreator::ShowInSinglePlayer(1);");
		else
			ColorSetCreator::ShowInSinglePlayer(1);
	}
	else if(%state == 1)
	{
		serverCmdClearAllBricks(ClientGroup.getObject(0));
		ColorSetCreator::ShowInSinglePlayer(2);		
	}
	else if(%state == 2)
	{
		if((%need = ColorSetCreator::GetColorCount() - ColorSetCreator::GetColDataBlockCount()) > 0)
			ColorSetCreator::BoxYesNo("Preview Set in SP", "Create " @ %need * 7 @ " paint datablocks?", "ColorSetCreator::ShowInSinglePlayer(3);", "ColorSetCreator::Error(\"" @ %need * 7 @ " more datablocks are needed.\");");
		else
			ColorSetCreator::ShowInSinglePlayer(3);				
	}
	else if(%state == 3)
	{
		if(DataBlockGroup.getCount() + (ColorSetCreator::GetColorCount() * 7 - ColorSetCreator::GetColDataBlockCount() * 7) > 4092)
			ColorSetCreator::Error("Too many Datablocks.");
		else
			ColorSetCreator::ShowInSinglePlayer(4);					
	}
	else if(%state == 4)
	{
		%currentcolor = -1;
		for(%i = 0; %i < ColorSetCreator.active.divs; %i++)
		{
			for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i]; %j++)
			{
				%currentcolor++;
				setSprayCanColorI(%currentcolor, ColorSetCreator.active.color[%i, %j]);
			}
			setSprayCanDivision(%i, %currentcolor, ColorSetCreator.active.divname[%i]);
		}
		while(getSprayCanDivisionSlot(%i++) != 0)
			setSprayCanDivision(%i, 0, "");
		clientCmdPlayGui_LoadPaint();
		transmitDatablocks();
		ColorSetCreator::BoxOK("Colorset loaded!");
	}
}

//Set the name of a division
function ColorSetCreator::SetDivName(%yes)
{
	if(%yes)
	{
		ColorSetCreator.active.divname[ColorSetCreator.active.currentdiv] = ColorSetCreator_SetDivName_Name.getValue();
		ColorSetCreator::CloseModalWindow();
	}
	else
	{
		ColorSetCreator_SetDivName_Name.setText(ColorSetCreator.active.divname[ColorSetCreator.active.currentdiv]);
		ColorSetCreator::SetModalWindow("SetDivName");
	}
}

//Save the colorset to a file
function ColorSetCreator::SaveSetToFile(%path)
{
	if(!strLen(%path))
	{
		ColorSetCreator::Error("No file specified");
		return;
	}
	if(!isWriteableFileName(%path))
	{
		ColorSetCreator::Error("File is read-only");
		return;
	}
	%write = new FileObject(){};
	if(!%write.openForWrite(%path))
	{
		%write.delete();
		ColorSetCreator::Error("Failed to write file");
		return;
	}
	for(%i = 0; %i < ColorSetCreator.active.divs; %i++)
	{
		for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i]; %j++)
		{
			%write.writeLine(ColorSetCreator.active.color[%i, %j]);
		}
		%write.writeLine("DIV: " @ ColorSetCreator.active.divname[%i]);
		%write.writeLine("");
	}
	%write.close();
	%write.delete();
	ColorSetCreator::BoxOK("Set Saved", "The set has been saved.");
}

//Open modal to set file paths etc
function ColorSetCreator::SaveSet(%yes)
{
	if(%yes)
	{
		ColorSetCreator::CloseModalWindow();
		ColorSetCreator::SaveSetToFile("Add-ons/Colorset_" @ ColorSetCreator_SelectFileToSave_File.getValue() @ "/colorSet.txt");
		%write = new FileObject(){};
		%write.openForWrite("Add-ons/Colorset_" @ ColorSetCreator_SelectFileToSave_File.getValue() @ "/description.txt");
		%write.writeLine("Title: " @ ColorSetCreator_SelectFileToSave_Title.getValue());
		%write.writeLine("Author: " @ ColorSetCreator_SelectFileToSave_Author.getValue());
		%write.writeLine(ColorSetCreator_SelectFileToSave_Desc.getValue());
		%write.close();
		%write.delete();
		ColorSetCreator_Window.setText("Color Set Editor | Saved Set");
		CustomGameGui.loadColorSets();
		if(CustomGameGui.isAwake())			
			CustomGameGui.createColorsetGui();
	}
	else
		ColorSetCreator::SetModalWindow("SelectFileToSave");
}

//How many colors are in tha set
function ColorSetCreator::GetColorCount()
{
	%count = 0;
	for(%i = 0; %i < ColorSetCreator.active.divs; %i++)
		%count += ColorSetCreator.active.colorsindiv[%i];
	return %count;
}

//Move one color to buffer
function ColorSetCreator::CopyColorPrev()
{
	ColorSetCreator.CopyColorCount = 1;
	ColorSetCreator.CopyColor[0] = ColorSetCreator.active.color[ColorSetCreator.active.currentdiv, ColorSetCreator.active.currentcolor];
	ColorSetCreator::SelectColor(ColorSetCreator.active.currentdiv, ColorSetCreator.active.currentcolor);
	ColorSetCreator::BoxOK("Copied one color.");
}

//Move all below colors to buffer
function ColorSetCreator::CopyDivDown()
{
	%col = ColorSetCreator.active.currentcolor;
	%div = ColorSetCreator.active.currentdiv;
	ColorSetCreator.CopyColorCount = ColorSetCreator.active.colorsindiv[%div] - %col;
	for(%i = 0; %i < ColorSetCreator.CopyColorCount; %i++)
		ColorSetCreator.CopyColor[%i] = ColorSetCreator.active.color[%div, %col + %i];
	ColorSetCreator::SelectColor(%div, %col, 1);
	if(ColorSetCreator.CopyColorCount == 1)
		ColorSetCreator::BoxOK("Copied one color.");
	else
		ColorSetCreator::BoxOK("Copied " @ ColorSetCreator.CopyColorCount @ " colors.");
}

//Move all above colors to buffer
function ColorSetCreator::CopyDivUp()
{
	%col = ColorSetCreator.active.currentcolor;
	%div = ColorSetCreator.active.currentdiv;
	ColorSetCreator.CopyColorCount = %col + 1;
	for(%i = 0; %i < %col + 1; %i++)
		ColorSetCreator.CopyColor[%i] = ColorSetCreator.active.color[%div, %i];
	ColorSetCreator::SelectColor(%div, %col, 1);
	if(ColorSetCreator.CopyColorCount == 1)
		ColorSetCreator::BoxOK("Copied one color.");
	else
		ColorSetCreator::BoxOK("Copied " @ ColorSetCreator.CopyColorCount @ " colors.");
}

//Paste buffer after the selection
function ColorSetCreator::PasteInto()
{
	if(ColorSetCreator::GetColorCount() + ColorSetCreator.CopyColorCount > 64)
	{
		ColorSetCreator::Error("Can't have more than 64 colors.");
		return;		
	}
	%col = ColorSetCreator.active.currentcolor;
	%div = ColorSetCreator.active.currentdiv;
	%tempcount = 0;
	for(%i = %col + 1; %i < ColorSetCreator.active.colorsindiv[%div]; %i++)
	{
		%temp[%tempcount] = ColorSetCreator.active.color[%div, %i];
		%tempcount++;
	}
	ColorSetCreator.active.colorsindiv[%div] += ColorSetCreator.CopyColorCount;
	for(%i = 0; %i < ColorSetCreator.CopyColorCount; %i++)
		ColorSetCreator.active.color[%div, %i + %col + 1] = ColorSetCreator.CopyColor[%i];
	for(%i = 0; %i < %tempcount; %i++)
		ColorSetCreator.active.color[%div, %i + %col + 1 + ColorSetCreator.CopyColorCount] = %temp[%i];
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(%div, %col, 1);
	if(ColorSetCreator.CopyColorCount == 1)
		ColorSetCreator::BoxOK("Pasted one color.");
	else
		ColorSetCreator::BoxOK("Pasted " @ ColorSetCreator.CopyColorCount @ " colors.");
}

//Paste buffer as new division
function ColorSetCreator::PasteAsNew()
{
	if(ColorSetCreator::GetColorCount() + ColorSetCreator.CopyColorCount > 64)
	{
		ColorSetCreator::Error("Can't have more than 64 colors.");
		return;
	}

	%div = ColorSetCreator.active.currentdiv;
	if(%div < ColorSetCreator.active.divs - 1)
	{
		ColorSetCreator.active.divs++;
		for(%i = ColorSetCreator.active.divs - 1; %i > %div + 1; %i--)
		{
			ColorSetCreator.active.colorsindiv[%i] = ColorSetCreator.active.colorsindiv[%i - 1];
			for(%j = 0; %j < ColorSetCreator.active.colorsindiv[%i - 1]; %j++)
			{
				ColorSetCreator.active.color[%i, %j] = ColorSetCreator.active.color[%i - 1, %j];
			}
			ColorSetCreator.active.divname[%i] = ColorSetCreator.active.divname[%i - 1];
		}
		ColorSetCreator.active.colorsindiv[%div + 1] = ColorSetCreator.CopyColorCount;
		for(%i = 0; %i < ColorSetCreator.CopyColorCount; %i++)
			ColorSetCreator.active.color[%div + 1, %i] = ColorSetCreator.CopyColor[%i];
		ColorSetCreator.active.divname[%div + 1] = "New Division";
	}
	else
	{
		ColorSetCreator.active.colorsindiv[%div + 1] = ColorSetCreator.CopyColorCount;
		ColorSetCreator.active.divs++;
		for(%i = 0; %i < ColorSetCreator.CopyColorCount; %i++)
			ColorSetCreator.active.color[%div + 1, %i] = ColorSetCreator.CopyColor[%i];
		ColorSetCreator.active.divname[%div + 1] = "New Division";
	}
	ColorSetCreator::RenderSet();
	ColorSetCreator::SelectColor(%div + 1, 0, 1);
	if(ColorSetCreator.CopyColorCount == 1)
		ColorSetCreator::BoxOK("Pasted one color.");
	else
		ColorSetCreator::BoxOK("Pasted " @ ColorSetCreator.CopyColorCount @ " colors.");
}

//Convert 00-FF to 0-255
function ColorSetCreator::HexToRGB(%val)
{
	%str = "0123456789ABCDEF";
	if(strPos(%str, getSubStr(%val, 0, 1)) == -1 || strPos(%str, getSubStr(%val, 1, 1)) == -1)
		return -1;
	return strPos(%str, getSubStr(%val, 0, 1)) * 16 + strPos(%str, getSubStr(%val, 1, 1));
}

//Convert 0-255 to 00-FF
function ColorSetCreator::RGBToHex(%val)
{
	if(%val == 0)
		return "00";
	%i = 0;
	while(%i * 16 < %val)
		%i++;
	%i--;
	%str = "0123456789ABCDEF";
	return getSubStr(%str, %i, 1) @ getSubStr(%str, %val - %i * 16, 1);
}

//Edit the color value with hex colors - for fags
function ColorSetCreator::EditHexColor(%yes)
{
	if(%yes)
	{
		ColorSetCreator::CloseModalWindow();
		%r = ColorSetCreator::HexToRGB(ColorSetCreator_SetHexValue_R.getValue());
		%g = ColorSetCreator::HexToRGB(ColorSetCreator_SetHexValue_G.getValue());
		%b = ColorSetCreator::HexToRGB(ColorSetCreator_SetHexValue_B.getValue());
		%a = ColorSetCreator::HexToRGB(ColorSetCreator_SetHexValue_A.getValue());
		if(%r == -1 || %g == -1 || %b == -1 || %a == -1)
		{
			ColorSetCreator::Error("Invalid hex value.");
			return;
		}
		%col = %r SPC %g SPC %b SPC %a;		
		ColorSetCreator_ColEditPreview.color = %col;
		ColorSetCreator.active.currentR = getWord(%col, 0);
		ColorSetCreator.active.currentG = getWord(%col, 1);
		ColorSetCreator.active.currentB = getWord(%col, 2);
		ColorSetCreator.active.currentA = getWord(%col, 3);
		ColorSetCreator_ColEditRSlider.setValue(getword(%col, 0));
		ColorSetCreator_ColEditGSlider.setValue(getword(%col, 1));
		ColorSetCreator_ColEditBSlider.setValue(getword(%col, 2));
		ColorSetCreator_ColEditASlider.setValue(getword(%col, 3));
		ColorSetCreator_ColEditRField.setText(getword(%col, 0));
		ColorSetCreator_ColEditGField.setText(getword(%col, 1));
		ColorSetCreator_ColEditBField.setText(getword(%col, 2));
		ColorSetCreator_ColEditAField.setText(getword(%col, 3));
	}
	else
	{
		ColorSetCreator_SetHexValue_R.setText(ColorSetCreator::RGBToHex(ColorSetCreator_ColEditRSlider.getValue()));
		ColorSetCreator_SetHexValue_G.setText(ColorSetCreator::RGBToHex(ColorSetCreator_ColEditGSlider.getValue()));
		ColorSetCreator_SetHexValue_B.setText(ColorSetCreator::RGBToHex(ColorSetCreator_ColEditBSlider.getValue()));
		ColorSetCreator_SetHexValue_A.setText(ColorSetCreator::RGBToHex(ColorSetCreator_ColEditASlider.getValue()));
		ColorSetCreator::SetModalWindow(SetHexValue);
	}
}

//Open and close editor!
function ColorSetCreatorToggle(%val)
{
	if(!%val)
		return;
	if(ColorSetCreatorGui.isAwake())
		Canvas.popDialog(ColorSetCreatorGui);
	else
		Canvas.pushDialog(ColorSetCreatorGui);
}

//Keybinds!
if(!ColorSetCreator.hasBinds)
{
	$remapdivision[$remapcount] = "Colorset Editor";
	$remapname[$remapcount] = "Open Editor";
	$remapcmd[$remapcount] = "ColorSetCreatorToggle";
	$remapcount++;
	ColorSetCreator.hasBinds = 1;
}
//Package
package ColorSetEditor
{
	//We gotta add a fancy button to the RTB colorset manager!
	function CustomGameGui::createColorsetGui(%this)
	{
		parent::createColorsetGui(%this);
		%k = getWord(CustomGameGui_ColorsetSwatch.extent, 1) / %this.fontSize;
		CustomGameGui_ColorsetSwatch.add(
			%ctrl = new GuiBitmapButtonCtrl()
			{
				profile = "ImpactBackButtonProfile";
				bitmap = "base/client/ui/btnBlank";
				text = "Colorset Editor";	         
				command = "ColorSetCreatorToggle(1);";
			}
		);
		%ctrl.resize(10,%k * %this.fontSize,getWord(CustomGameGui_ColorsetSwatch.extent, 0),%this.fontSize);
		CustomGameGui_ColorsetSwatch.resize(0,0,getWord(CustomGameGui_ColorsetSwatch.extent,0),(%k + 1) * %this.fontSize);
	}
};
activatePackage(ColorSetEditor);

//We are ready to start!
ColorSetCreator::Init();