datablock WheeledVehicleData(DeloreanVehicle)
{
	isCitiVehicle = 1;
	
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./Delorean.dts"; //"~/data/shapes/skivehicle.dts"; //
	emap = true;
	minMountDist = 3;
   
   numMountPoints = 2;
   mountThread[0] = "sit";
   mountThread[1] = "sit";


	maxDamage = 200.00;
	destroyedLevel = 200.00;
	energyPerDamagePoint = 160;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0.4";
   //massBox = "2 5 1";

	maxSteeringAngle = 0.8;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 10;         // Far distance from vehicle
	cameraOffset = 6;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.4;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

	defaultTire	= DeloreanTire;
	defaultSpring	= DeloreanSpring;
	flatTire	= jeepFlatTire;
	flatSpring	= jeepFlatSpring;

   numWheels = 4;

	// Rigid Body
	mass = 200;
	density = 5.0;
	drag = 4.5;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 4000; //4000;       // Engine power
	engineBrake = 900;         // Braking when throttle is 0
	brakeTorque = 3200;        // When brakes are applied
	maxWheelSpeed = 45;        // Engine scale by current speed / max speed

	rollForce		= 900;
	yawForce		= 600;
	pitchForce		= 1000;
	rotationalDrag		= 0;

	// Advanced Steering
   steeringAutoReturn = true;
   steeringAutoReturnRate = 1;
   steeringAutoReturnMaxSpeed = 10;
   steeringUseStrafeSteering = true;
   steeringStrafeSteeringRate = 0.08;
	
	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	splash = jeepSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = VehicleFoamDropletsEmitter;
	splashEmitter[1] = VehicleFoamEmitter;
	splashEmitter[2] = VehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "DeLorean";
	rideable = true;
		lookUpLimit = 0.50;
		lookDownLimit = 0.50;

	paintable = true;
   
   damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

   initialExplosionProjectile = DeloreanExplosionProjectile;
   initialExplosionOffset = 0;         //offset only uses a z value for now

   burnTime = 4000;

   finalExplosionProjectile = DeloreanFinalExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now


   minRunOverSpeed    = 2;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 5;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed
};

function Deloreanvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");

	
	
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

function DeloreanBTTFvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");

	
	
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

datablock WheeledVehicleData(DeloreanBTTFVehicle : DeloreanVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./DeloreanBTTF.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "Delorean BTTF";
	finalExplosionProjectile = DeloreanFinalExplosionProjectile;
};


function DeloreanBTTFVehicle::onDriverLeave(%this,%obj)
{
	%driver = %obj.getControllingObject();
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
	%driver.client.schedule(0,"applybodyparts");
}

package DeloreanVehiclePackage
{
	function armor::onMount(%this,%obj,%col,%slot)
   	{
    	Parent::onMount(%this,%obj,%col,%slot);
      
        if(%obj.getMountNode() != 0)
			return;
		
		%vehicle = %obj.getObjectMount();
		
		if(%vehicle.getDatablock().isDeloreanVehicle == 1)
		{
			%t = %obj.activeThread[1];
			if(!(%t $= "armReadyRight" || %t $= "armReadyBoth"))
			{
				%col.unhideNode($rhand[%obj.client.rhand]);
				%col.setNodeColor($rhand[%obj.client.rhand],%obj.client.rhandcolor);
				%obj.hideNode("rhand");
				%obj.hideNode("rhook");
			}
			if(!(%t $= "armReadyLeft" || %t $= "armReadyBoth"))
			{
				%col.unhideNode($lhand[%obj.client.lhand]);
				%col.setNodeColor($lhand[%obj.client.lhand],%obj.client.lhandcolor);
				%obj.hideNode("lhand");
				%obj.hideNode("lhook");
			}
		}
    }
	function armor::onUnMount(%this,%obj,%col,%slot)
   	{	
    	Parent::onUnMount(%this,%obj,%col,%slot);
      
      	if(!isObject(%col))
      		return;
      	
        if(%obj.getMountNode() != 0)
			return;
		
		if(%col.getDatablock().isDeloreanVehicle == 1)
		{
			%t = %obj.activeThread[1];
			if(!(%t $= "armReadyRight" || %t $= "armReadyBoth"))
			{
				%obj.unhideNode($rhand[%obj.client.rhand]);
				//%obj.setNodeColor($rhand[%obj.client.rhand],%obj.client.rhandcolor);
				%col.hideNode("rhand");
				%col.hideNode("rhook");
			}
			if(!(%t $= "armReadyLeft" || %t $= "armReadyBoth"))
			{
				%obj.unhideNode($lhand[%obj.client.lhand]);
				//%obj.setNodeColor($lhand[%obj.client.lhand],%obj.client.lhandcolor);
				%col.hideNode("lhand");
				%col.hideNode("lhook");
			}
		}
    }
	function GameConnection::applyBodyParts(%this)
	{
		Parent::applyBodyParts(%this);
		
		%player = %this.player;
		
		if(isObject(%player) == 0 || isObject(%veh = %player.getObjectMount()) == 0)
			return;
		
		if(%player.getMountNode() != 0)
			return;
		
		if(%veh.getDatablock().isDeloreanVehicle == 1)
		{
			%player.hideNode("lhand");
			%player.hideNode("rhand");
			%player.hideNode("lhook");
			%player.hideNode("rhook");
			%veh.hideNode("lhand");
			%veh.hideNode("rhand");
			%veh.hideNode("lhook");
			%veh.hideNode("rhook");
			%veh.unhideNode($lhand[%this.lhand]);
			%veh.unhideNode($rhand[%this.rhand]);
			%veh.setNodeColor($lhand[%this.lhand],%this.lhandColor);
			%veh.setNodeColor($rhand[%this.rhand],%this.rhandColor);
		}
	}
	function Player::playThread(%player,%slot,%thread)
	{
		Parent::playThread(%player,%slot,%thread);
		
		if(%player.getMountNode() != 0)
			return;
		
		%veh = %player.getObjectMount();
		%player.activeThread[%slot] = %thread;
		if(isObject(%veh) && %veh.getDatablock().isDeloreanVehicle == 1)
		{
			if(%slot == 1)
			{
				if(%thread $= "armReadyRight")
				{
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					%player.unHideNode($rhand[%player.client.rhand]);
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.setNodeColor($lhand[%player.client.lhand],%player.client.lhandColor);
					%player.hideNode("lhand");
					%player.hideNode("lhook");
				} else if(%thread $= "armReadyLeft")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					%player.unHideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($rhand[%player.client.rhand],%player.client.rhandColor);
					%player.hideNode("rhand");
					%player.hideNode("rhook");
				} else if(%thread $= "armReadyBoth")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					%player.unHideNode($lhand[%player.client.lhand]);
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					%player.unHideNode($rhand[%player.client.rhand]);
				} else if(%thread $= "root")
				{
					%player.hideNode("lhand");
					%player.hideNode("rhand");
					%player.hideNode("lhook");
					%player.hideNode("rhook");
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($lhand[%player.client.lhand],%player.client.lhandColor);
					%veh.setNodeColor($rhand[%player.client.rhand],%player.client.rhandColor);
				}
			}
		}
	}
};
activatePackage(DeloreanVehiclePackage);