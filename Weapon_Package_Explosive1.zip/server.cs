//set up T+T's grenade system
	RTB_registerPref("Starting Conc Grenades","Tier+Tactical Ammo 4","$Pref::Server::TTG1Ammo","int 0 10","Script_GamePreferences",4,0,1);
	RTB_registerPref("Starting Stick Grenades","Tier+Tactical Ammo 4","$Pref::Server::TTG2Ammo","int 0 10","Script_GamePreferences",3,0,1);
	RTB_registerPref("Starting Molotov Grenades","Tier+Tactical Ammo 4","$Pref::Server::TTG3Ammo","int 0 10","Script_GamePreferences",2,0,1);

	RTB_registerPref("Max Conc Grenades","Tier+Tactical Ammo 4","$Pref::Server::TTM1Ammo","int 0 10","Script_GamePreferences",4,0,1);
	RTB_registerPref("Max Stick Grenades","Tier+Tactical Ammo 4","$Pref::Server::TTM2Ammo","int 0 10","Script_GamePreferences",3,0,1);
	RTB_registerPref("Max Molotov Grenades","Tier+Tactical Ammo 4","$Pref::Server::TTM3Ammo","int 0 10","Script_GamePreferences",2,0,1);


exec("add-ons/weapon_rocket_launcher/Weapon_rocket launcher.cs");
exec("add-ons/projectile_gravityrocket/server.cs");

exec("./prjemit.cs");
exec("./Weapon_stickgrenade.cs");
exec("./Weapon_fraggrenade.cs");
exec("./Weapon_petrbomb.cs");

function nadesOnSpawn(%this,%obj)
{
   %obj.client.quantity["fragNades"] = $Pref::Server::TTG1Ammo;
   %obj.client.quantity["stickNades"] = $Pref::Server::TTG2Ammo;
   %obj.client.quantity["molNades"] = $Pref::Server::TTG3Ammo;
}

package nadesSpawn
{
function armor::onadd(%this,%obj)
   {
      Parent::onadd(%this,%obj);
      nadesOnSpawn(%this,%obj);
   }
};
activatePackage(nadesSpawn);

datablock ItemData(grenadeBagItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./grenade_bag.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Grenade Bag";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
};

function grenadeBagItem::onAdd(%this, %obj)
{
	if(%obj.stickCount $= "" && %obj.molCount $= "" && %obj.fragCount $= "")//if there is ABSOLUTELY NO TRACE OF ANY GRENADES PRIOR
	{
	%obj.stickCount = 1;
	%obj.fragCount = 2;
	%obj.molCount = 2;
	}

	%obj.rotate = true;
	Parent::onAdd(%this, %obj);
}

package GrenadeBagPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "grenadeBagItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["stickNades"] += %col.stickCount;
	%obj.client.quantity["fragNades"] += %col.fragCount;
	%obj.client.quantity["molNades"] += %col.stickCount;


	if(%obj.client.quantity["stickNades"] > $Pref::Server::TTM2Ammo)
		{
		%obj.client.quantity["stickNades"] = $Pref::Server::TTM2Ammo;
		}
	if(%obj.client.quantity["fragNades"] > $Pref::Server::TTM1Ammo)
		{
		%obj.client.quantity["fragNades"] = $Pref::Server::TTM1Ammo;
		}
	if(%obj.client.quantity["molNades"] > $Pref::Server::TTM3Ammo)
		{
		%obj.client.quantity["molNades"] = $Pref::Server::TTM3Ammo;
		}

	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(GrenadeBagPackage);

package GrenadeDropPackage
{
	function gameConnection::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA)
	{
		if($Pref::Server::TT2Drop == 1)
		{
		%pos = %client.player.getPosition();
		%posX = getWord(%pos,0);
		%posY = getWord(%pos,1);
		%posZ = getWord(%pos,2) + 1;

		%vec = %client.player.getVelocity();
		%vecX = getWord(%vec,0);
		%vecY = getWord(%vec,1);
		%vecZ = getWord(%vec,2);
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = grenadeBagItem;
				canPickup = true;
				stickcount = %client.quantity["stickNades"];
				fragcount = %client.quantity["fragNades"];
				molcount = %client.quantity["molNades"];
				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);
			MissionCleanup.add(%i);
			%i.setShapeName(%i.ammocount);
		}
		parent::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA);
		}
};
activatePackage(GrenadeDropPackage);