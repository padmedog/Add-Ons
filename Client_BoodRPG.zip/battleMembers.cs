
activatePackage(BRPG_BattleMembers_Package);
