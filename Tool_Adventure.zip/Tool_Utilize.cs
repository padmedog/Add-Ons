datablock ExplosionData(emptyExplosion)
{
   lifeTimeMS = 300;


   particleDensity = 8;
   particleRadius = 0.1;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "12.0 14.0 12.0";
   camShakeAmp = "0.7 0.7 0.7";
   camShakeDuration = 0.35;
   camShakeRadius = 7.0;

   lightStartRadius = 1.5;
   lightEndRadius = 0;
   lightStartColor = "1 1 1";
   lightEndColor = "0 0 0";
};

datablock ItemData(UtilizeItem : swordItem)
{
	shapeFile = "base/data/shapes/empty.dts";
	doColorShift = false;
	colorShiftColor = "1.000 1.000 1.000 1.000";

	image = UtilizeImage;
	canDrop = true;
	iconName = "./icon_Utilize";
	
	
	uiName = "Utilize";
};

datablock ProjectileData(UtilizeProjectile)
{
   directDamage      = 20;
   directDamageType  = $DamageType::Utilize;
   radiusDamageType  = $DamageType::Utilize;
   explosion         = emptyExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Utilize";
};

datablock ShapeBaseImageData(UtilizeImage)
{
   shapeFile = "base/data/shapes/empty.dts";
   emap = true;

   mountPoint = 0;
   offset = "0 0 0";

   correctMuzzleVector = false;

   className = "WeaponImage";

   item = UtilizeItem;
   ammo = " ";
   projectile = UtilizeProjectile;
   projectileType = Projectile;


   melee = true;
   doRetraction = false;

   armReady = f;


   doColorShift = false;
   colorShiftColor = "1.000 1.000 1.000 1.000";

	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "StopFire";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "StopFire";
	stateTransitionOnTimeout[4]     = "Ready";
	stateTimeoutValue[4]            = 0.2;
	stateAllowImageChange[4]        = false;
	stateWaitForTimeout[4]		= true;
	stateSequence[4]                = "StopFire";
	stateScript[4]                  = "onStopFire";


};

function UtilizeImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, activate);
}

function UtilizeImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function UtilizeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
	if(%col.getClassName() $= "fxDTSBrick")
	{
		$InputTarget_["Self"] = %col;
		$InputTarget_["Player"] = %obj.client.player;
		$InputTarget_["Client"] = %obj.client;
		if($Server::LAN)
		{
			$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj.client);
		}
		else
		{
			if(getMiniGameFromObject(%col) == getMiniGameFromObject(%obj.client))
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%col);
			}
			else
			{
				$InputTarget_["MiniGame"] = 0;
			}
		}
		%col.processInputEvent(onUtilize,%obj.client);
	}
}