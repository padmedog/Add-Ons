datablock fxDTSBrickData(brick1x1toplessrampx1Data)
{
	brickFile = "./1x1toplessrampx1/1x1toplessrampx1.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x1 Topless Ramp x1";
	iconName = "Add-Ons/Brick_ToplessRamps/1x1toplessrampx1/1x1toplessrampx1";
	collisionShapeName = "./1x1toplessrampx1/1x1toplessrampx1.dts";
};
datablock fxDTSBrickData(brick1x1toplessrampx2Data)
{
	brickFile = "./1x1toplessrampx2/1x1toplessrampx2.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x1 Topless Ramp x2";
	iconName = "Add-Ons/Brick_ToplessRamps/1x1toplessrampx2/1x1toplessrampx2";
	collisionShapeName = "./1x1toplessrampx2/1x1toplessrampx2.dts";
};
datablock fxDTSBrickData(brick1x2toplessrampx1Data)
{
	brickFile = "./1x2toplessrampx1/1x2toplessrampx1.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x2 Topless Ramp x1";
	iconName = "Add-Ons/Brick_ToplessRamps/1x2toplessrampx1/1x2toplessrampx1";
	collisionShapeName = "./1x2toplessrampx1/1x2toplessrampx1.dts";
};
datablock fxDTSBrickData(brick1x2toplessrampx2Data)
{
	brickFile = "./1x2toplessrampx2/1x2toplessrampx2.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x2 Topless Ramp x2";
	iconName = "Add-Ons/Brick_ToplessRamps/1x2toplessrampx2/1x2toplessrampx2";
	collisionShapeName = "./1x2toplessrampx2/1x2toplessrampx2.dts";
};
datablock fxDTSBrickData(brick2x1toplessrampx1Data)
{
	brickFile = "./2x1toplessrampx1/2x1toplessrampx1.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "2x1 Topless Ramp x1";
	iconName = "Add-Ons/Brick_ToplessRamps/2x1toplessrampx1/2x1toplessrampx1";
	collisionShapeName = "./2x1toplessrampx1/2x1toplessrampx1.dts";
};
datablock fxDTSBrickData(brick2x1toplessrampx2Data)
{
	brickFile = "./2x1toplessrampx2/2x1toplessrampx2.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "2x1 Topless Ramp x2";
	iconName = "Add-Ons/Brick_ToplessRamps/2x1toplessrampx2/2x1toplessrampx2";
	collisionShapeName = "./2x1toplessrampx2/2x1toplessrampx2.dts";
};
datablock fxDTSBrickData(brick1x1toplessrampinvx1Data)
{
	brickFile = "./1x1toplessrampinvx1/1x1toplessrampinvx1.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x1 Topless Ramp x1 Inverted";
	iconName = "Add-Ons/Brick_ToplessRamps/1x1toplessrampinvx1/1x1toplessrampinvx1";
	collisionShapeName = "./1x1toplessrampinvx1/1x1toplessrampinvx1.dts";
};
datablock fxDTSBrickData(brick1x1toplessrampinvx2Data)
{
	brickFile = "./1x1toplessrampinvx2/1x1toplessrampinvx2.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x1 Topless Ramp x2 Inverted";
	iconName = "Add-Ons/Brick_ToplessRamps/1x1toplessrampinvx2/1x1toplessrampinvx2";
	collisionShapeName = "./1x1toplessrampinvx2/1x1toplessrampinvx2.dts";
};
datablock fxDTSBrickData(brick1x2toplessrampinvx1Data)
{
	brickFile = "./1x2toplessrampinvx1/1x2toplessrampinvx1.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x2 Topless Ramp x1 Inverted";
	iconName = "Add-Ons/Brick_ToplessRamps/1x2toplessrampinvx1/1x2toplessrampinvx1";
	collisionShapeName = "./1x2toplessrampinvx1/1x2toplessrampinvx1.dts";
};
datablock fxDTSBrickData(brick1x2toplessrampinvx2Data)
{
	brickFile = "./1x2toplessrampinvx2/1x2toplessrampinvx2.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "1x2 Topless Ramp x2 Inverted";
	iconName = "Add-Ons/Brick_ToplessRamps/1x2toplessrampinvx2/1x2toplessrampinvx2";
	collisionShapeName = "./1x2toplessrampinvx2/1x2toplessrampinvx2.dts";
};
datablock fxDTSBrickData(brick2x1toplessrampinvx1Data)
{
	brickFile = "./2x1toplessrampinvx1/2x1toplessrampinvx1.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "2x1 Topless Ramp x1 Inverted";
	iconName = "Add-Ons/Brick_ToplessRamps/2x1toplessrampinvx1/2x1toplessrampinvx1";
	collisionShapeName = "./2x1toplessrampinvx1/2x1toplessrampinvx1.dts";
};
datablock fxDTSBrickData(brick2x1toplessrampinvx2Data)
{
	brickFile = "./2x1toplessrampinvx2/2x1toplessrampinvx2.blb";
	category = "Ramps";
	subCategory = "Topless";
	uiName = "2x1 Topless Ramp x2 Inverted";
	iconName = "Add-Ons/Brick_ToplessRamps/2x1toplessrampinvx2/2x1toplessrampinvx2";
	collisionShapeName = "./2x1toplessrampinvx2/2x1toplessrampinvx2.dts";
};