        RTB_registerPref("Drop 21 Gauge Ammo","Frog's Weaponry Drops","$Pref::Server::FW1Drop","int 0 1","Script_GamePreferences",1,0,1);
        RTB_registerPref("Drop .45 Caliber Ammo","Frog's Weaponry Drops","$Pref::Server::FW2Drop","int 0 1","Script_GamePreferences",1,0,1);
        RTB_registerPref("Drop Impact Grenade Ammo","Frog's Weaponry Drops","$Pref::Server::FW5Drop","int 0 1","Script_GamePreferences",1,0,1);
		RTB_registerPref("Drop Slug Ammo","Frog's Weaponry Drops","$Pref::Server::FW6Drop","int 0 1","Script_GamePreferences",1,0,1);
	    RTB_registerPref("Drop Blast Round Ammo","Frog's Weaponry Drops","$Pref::Server::FW7Drop","int 0 1","Script_GamePreferences",1,0,1);
	
	    RTB_registerPref("Starting 21 Gauge Ammo","Frog's Weaponry Ammo","$Pref::Server::FW1Ammo","int 0 72","Script_GamePreferences",6*6,0,1);
        RTB_registerPref("Starting .45 Caliber Ammo","Frog's Weaponry Ammo","$Pref::Server::FW2Ammo","int 0 192","Script_GamePreferences",8*6,0,1);
        RTB_registerPref("Starting Impact Grenade Ammo","Frog's Weaponry Ammo","$Pref::Server::FW5Ammo","int 0 12","Script_GamePreferences",4*2,0,1);
		RTB_registerPref("Starting Slug Ammo","Frog's Weaponry Ammo","$Pref::Server::FW6Ammo","int 0 30","Script_GamePreferences",6*5,0,1);
	    RTB_registerPref("Starting Blast Round Ammo","Frog's Weaponry Ammo","$Pref::Server::FW7Ammo","int 0 32","Script_GamePreferences",8*4,0,1);
	    RTB_registerPref("Starting Payload Ammo","Frog's Weaponry Ammo","$Pref::Server::FW3Ammo","int 0 1","Script_GamePreferences",1*1,0,1);
	    RTB_registerPref("Starting Strike Rocket Ammo","Frog's Weaponry Ammo","$Pref::Server::FW4Ammo","int 0 6","Script_GamePreferences",1*6,0,1);
	    RTB_registerPref("Starting .50 Caliber Ammo","Frog's Weaponry Ammo","$Pref::Server::FW8Ammo","int 0 200","Script_GamePreferences",200*1,0,1);
		
        RTB_registerPref("Vulcan is Deployable","Frog's Weaponry Misc.","$Pref::Server::VulcanDeploy","bool 0 1","Script_GamePreferences",1,0,1);
		
		
		datablock PlayerData(DeployedArmor : PlayerStandardArmor)
{
   runForce = 10000; //Huge number to prevent the player from sliding across the terrain like ice.
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;

   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;

   jumpForce = 8.3 * 1000; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	showEnergyBar = false;

   runSurfaceAngle  = 55;
   jumpSurfaceAngle = 55;
};

datablock PlayerData(SlowedArmor : PlayerStandardArmor)
{
   runForce = 25 * 180;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 3;
   maxBackwardSpeed = 2;
   maxSideSpeed = 2.75;

   maxForwardCrouchSpeed = 1;
   maxBackwardCrouchSpeed = 0.25;
   maxSideCrouchSpeed = 1;

   jumpForce = 8.3 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	showEnergyBar = false;

   runSurfaceAngle  = 55;
   jumpSurfaceAngle = 55;
};

 datablock AudioProfile(BreakshotgunFireSound)
{
   filename    = "./BreakshotgunFire.wav";
   description = AudioClose3d;
   preload = true;
};
    
 datablock AudioProfile(CombatMGFireSound)
{
   filename    = "./CombatMGFire.wav";
   description = AudioClose3d;
   preload = true;
};

 datablock AudioProfile(CombatRifleFireSound)
{
   filename    = "./CombatRifle_Shot.wav";
   description = AudioClose3d;
   preload = true;
};

   datablock AudioProfile(FWAmmogetSound)
{
   filename    = "./FWAmmoget.wav";
   description = AudioClose3d;
   preload = true;
};	
	
  datablock AudioProfile(FWReload1Sound)
{
   filename    = "./FWReload1.wav";
   description = AudioClose3d;
   preload = true;
};	

 datablock AudioProfile(FWReload2Sound)
{
   filename    = "./FWReload2.wav";
   description = AudioClose3d;
   preload = true;
};
	
 datablock AudioProfile(HawkeyeSniperfireSound)
{
   filename    = "./HawkeyeFire.wav";
   description = AudioClose3d;
   preload = true;
};	
 
 datablock AudioProfile(HeavySMGFireSound)
{
   filename    = "./HeavySMGFire.wav";
   description = AudioClose3d;
   preload = true;
};	

 datablock AudioProfile(ImpactGrenadeExplosionSound)
{
   filename    = "./ImpactGrenadeExplode.wav";
   description = AudioClose3d;
   preload = true;
};

 datablock AudioProfile(ImpactLauncherFireSound)
{
   filename    = "./ImpactLauncherFireSound.wav";
   description = AudioClose3d;
   preload = true;
};
  
  datablock AudioProfile(PayloadLauncherExplodeSound)
{
   filename    = "./PayloadLauncherExplode.wav";
   description = AudioClose3d;
   preload = true;
};	

 datablock AudioProfile(PayloadLauncherfireSound)
{
   filename    = "./PayloadLauncherFire.wav";
   description = AudioClose3d;
   preload = true;
};	

 datablock AudioProfile(PayloadLauncherLoopSound)
{
   filename    = "./PayloadLauncherLoop.wav";
   description = AudiodefaultLooping3d;
   preload = true;
};	
 
 datablock AudioProfile(PGFireSound)
{
   filename    = "./PGShot.wav";
   description = AudioClose3d;
   preload = true;
};	

 datablock AudioProfile(PistolPullBackSound)
{
   filename    = "./Pistol_Pull_Back.wav";
   description = AudioClose3d;
   preload = true;
};
 
 datablock AudioProfile(ballisticShotgunfireSound)
{
   filename    = "./ballisticShotgunfire.wav";
   description = AudioClose3d;
   preload = true;
};	

 datablock AudioProfile(ballisticShotgunReloadSound)
{
   filename    = "./ballisticShotgunpump.wav";
   description = AudioClose3d;
   preload = true;
};
	
 datablock AudioProfile(SmokeGrenadeSound)
{
   filename    = "./SmokeGrenadeExplode.wav";
   description = AudioClose3d;
   preload = true;
};

 datablock AudioProfile(StrikeLauncherExplosionSound)
{
   filename    = "./StrikeLauncherExplosion.wav";
   description = AudioClose3d;
   preload = true;
};

 datablock AudioProfile(StrikeLauncherFireSound)
{
   filename    = "./StrikeLauncherFire.wav";
   description = AudioClose3d;
   preload = true;
};

 datablock AudioProfile(StrikeLauncherRocketLoopSound)
{
   filename    = "./StrikeLauncherRocketLoop.wav";
   description = AudiodefaultLooping3d;
   preload = true;
};
 
 datablock AudioProfile(VulcanFireSound)
{
   filename    = "./VulcanFire.wav";
   description = AudioClose3d;
   preload = true;
};
 
 datablock AudioProfile(VulcanSpinSound)
{
   filename    = "./VulcanSpin.wav";
   description = AudioClose3d;
   preload = true;
};
 
 datablock AudioProfile(VulcanWindDownSound)
{
   filename    = "./VulcanWinddown.wav";
   description = AudioClose3d;
   preload = true;
};

 datablock AudioProfile(VulcanWindupSound)
{
   filename    = "./VulcanWindup.wav";
   description = AudioClose3d;
   preload = true;
};

datablock DebrisData(BigShellDebris)
{
	shapeFile = "./BigShell.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

function FWAmmoOnSpawn(%this,%obj)
{
   %obj.client.quantity["21Gauge"] = $Pref::Server::FW1Ammo; //Pop-Gun, APG
   %obj.client.quantity["45Caliber"] = $Pref::Server::FW2Ammo; //Heavy Pistols
   %obj.client.quantity["Payload"] = $Pref::Server::FW3Ammo; //Payload Launcher
   %obj.client.quantity["StrikeRocket"] = $Pref::Server::FW4Ammo; //Strike Launcher
   %obj.client.quantity["ImpactGrenade"] = $Pref::Server::FW5Ammo; //Impact Launcher
   %obj.client.quantity["Slugs"] = $Pref::Server::FW6Ammo; //Ballistic Shotgun
   %obj.client.quantity["BlastRounds"] = $Pref::Server::FW7Ammo; //Blast Rifle
   %obj.client.quantity["50Cal"] = $Pref::Server::FW8Ammo; //Vulcan

}

package FWAmmoOnSpawn
{
function armor::onadd(%this,%obj)
   {
      Parent::onadd(%this,%obj);
      FWAmmoOnSpawn(%this,%obj);
   }
};

activatePackage(FWAmmoOnSpawn);


if(isFile("Add-Ons/Gamemode_Zombie/server.cs") && $AddOn__Gamemode_Zombie == 1)
{
	$BushidoL4DGuns::UsingRotZombies = 1;
	$BushidoL4DGuns::UsingZombies = 1;
}

if(isFile("Add-Ons/Gamemode_ZAPT/server.cs") && $AddOn__Gamemode_ZAPT == 1)
{
	$BushidoL4DGuns::UsingZombies = 1;
}

//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Frogs_Weaponry - required add-on Weapon_Gun");
}
else
{
   
   exec("./Weapon_CombatRifle.cs"); 
   exec("./Weapon_CombatMG.cs"); 
   exec("./Weapon_Vulcan.cs"); 
   exec("./Weapon_HeavyPistol.cs");
   exec("./Weapon_PopGun.cs");  
   exec("./Weapon_APG.cs");  
   exec("./Weapon_StrikeLauncher.cs");   
   exec("./Weapon_PayloadLauncher.cs");
   exec("./Weapon_ImpactGrenade.cs");  
   exec("./Weapon_ImpactLauncher.cs");  
   exec("./Weapon_AutomaticShotgun.cs"); 
   exec("./Weapon_Hawkeye.cs"); 
   exec("./Weapon_ballisticShotgun.cs"); 
   exec("./Weapon_HeavySMG.cs"); 
   exec("./Weapon_BlastRifle.cs");    
   exec("./Weapon_SmokeGrenade.cs"); 
   exec("./Item_FWAmmo.cs");   
 //exec("./Weapon_BreakShotgun.cs"); 
 }
