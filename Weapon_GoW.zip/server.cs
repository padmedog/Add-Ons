//GoW.cs

//audio
datablock AudioProfile(GoWFireSound)
{
   filename    = "./GoWFire.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(GoWExplodeSound)
{
   filename    = "./GoWBoom.wav";
   description = AudioClose3d;
   preload = true;
};


//muzzle flash effects

datablock ParticleData(GoWSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 550;
	lifetimeVarianceMS   = 75;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.9";
	colors[1]     = "0.45 0.45 0.45 0.0";
	sizes[0]      = 0.2;
	sizes[1]      = 0.35;

	useInvAlpha = false;
};
datablock ParticleEmitterData(GoWSmokeEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "GoWSmokeParticle";

   uiName = "GoW Smoke";
};


datablock ParticleData(GoWExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 4000;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -10.0;
	spinRandomMax		= 10.0;
	colors[0]     = "0.3 0.3 0.3 0.9";
	colors[1]     = "0.9 0.9 0.9 0.0";
	sizes[0]      = 3.0;
	sizes[1]      = 4.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(GoWExplosionEmitter)
{
   ejectionPeriodMS = 300;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "GoWExplosionParticle";

   useEmitterColors = true;
   uiName = "Grapes of Wrath Explosion Cloud";
};


datablock ParticleData(GoWBlastParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 35;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 0.0 0.7 0.9";
	colors[1]     = "0.1 0.0 0.7 0.0";
	sizes[0]      = 8;
	sizes[1]      = 2;

	useInvAlpha = true;
};
datablock ParticleEmitterData(GoWBlastEmitter)
{
	lifeTimeMS = 250;

   ejectionPeriodMS = 500;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "GoWBlastParticle";

   useEmitterColors = true;
   uiName = "Grapes of Wrath Explosion Flash";
};

//bullet trail effects
datablock ParticleData(TCGrapeGTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 2000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "0.7 0.0 0.5 0.4";
	colors[1]     = "0.8 0.0 0.6 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.15;
	sizes[1]      = 0.65;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 1.0;
   times[3] = 2.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(TCGrapeGTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TCGrapeGTrailParticle";

   uiName = "Grape Trail";
};

datablock ExplosionData(GoWExplosion)
{
   //explosionShape = "";
	soundProfile = GoWExplodeSound;

   lifeTimeMS = 150;

   particleEmitter = GoWExplosionEmitter;
   particleDensity = 20;
   particleRadius = 3.0;

   emitter[0] = GoWBlastEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "3.0 4.0 3.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 1.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";

   damageRadius = 7.0;
   radiusDamage = 40;
};


AddDamageType("GoW",   '<bitmap:add-ons/Weapon_GoW/CI_GoW> %1',    '%2 <bitmap:add-ons/Weapon_GoW/CI_GoW> %1',0.2,1);
datablock ProjectileData(GoWProjectile)
{
   projectileShapeName = "./bullet.dts";
   directDamage        = 120;
   directDamageType    = $DamageType::GoW;
   radiusDamageType    = $DamageType::GoW;

   brickExplosionRadius = 7.0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;
   brickExplosionMaxVolume = 100;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 150;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = GoWExplosion;
   particleEmitter     = TCGrapeGTrailEmitter;

   muzzleVelocity      = 70;
   velInheritFactor    = 0.5;

   armingDelay         = 00;
   lifetime            = 30000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.05;
   isBallistic         = true;
   gravityMod = 0.5;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "0.5 0 0.3";

   uiName = "Grape";
};

//////////
// item //
//////////
datablock ItemData(GoWItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./GoW.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Grapes of Wrath";
	iconName = "./Icon_GoW";
	doColorShift = true;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = GoWImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(GoWImage)
{
   // Basic Item properties
   shapeFile = "./GoW.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = GoWProjectile;
   projectileType = Projectile;

	casing = GoWShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "1 1 1";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = GoWItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.30;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.2;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= GoWFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= GoWFireSound;
	stateEjectShell[2]       = false;

	stateName[3] = "Smoke";
	stateEmitter[3]					= GoWSmokeEmitter;
	stateEmitterTime[3]				= 0.2;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.2;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

};

function GoWImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, plant);
	Parent::onFire(%this,%obj,%slot);	
}