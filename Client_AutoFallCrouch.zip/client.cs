package swol_AutoCrouch
{
	function swol_crouchLoopCheck()
	{
		cancel($Swol::AutoCrouchLoopSched);
		if(!isObject(serverConnection))
		{
			$Swol::AutoCrouchLoopSched = schedule(8000,0,swol_crouchLoopCheck);
			return;
		}
		if(!isObject(serverConnection.getControlObject()))
		{
			$Swol::AutoCrouchLoopSched = schedule(2000,0,swol_crouchLoopCheck);
			return;
		}
		%velocity = serverConnection.getControlObject().getVelocity();
		if(getWord(%velocity,2) < -27)
		{
			if(getWord(%velocity,2) < -34.87)
			{
				schedule(16,0,swol_crouchLoopCheck);
				return;
			}
			cancel($Swol::CancelCrouchSched);
			crouch(1);
			$Swol::CancelCrouchSched = schedule(32,0,swol_cancelCrouch);
		}
		schedule(16,0,swol_crouchLoopCheck);
	}
	function swol_cancelCrouch()
	{
		cancel($Swol::CancelCrouchSched);
		crouch(0);
	}
};
ActivatePackage(swol_AutoCrouch);
swol_crouchLoopCheck();