datablock AudioProfile(BoltRifleReloadSound)
{
   filename    = "./bolt_boltrifle.wav";
   description = AudioClosest3d;
   preload = true;
};

//audio
datablock AudioProfile(MilitarySniperFireSound)
{
   filename    = "./sniper_rifle_fire.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(MilitarySniperRicSound)
{
   filename    = "./Military_Sniper_Ricochet.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ExplosionData(militarySniperExplosion)
{
   //explosionShape = "";
	soundProfile = MilitarySniperRicSound;

   lifeTimeMS = 150;

   particleEmitter = shotgunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = gunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";

   impulseRadius = 2;
   impulseForce = 1000;
};

AddDamageType("MilitaryRifle",   '<bitmap:add-ons/Weapon_Package_Tier2/CI_MilitaryRifle> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2/CI_MilitaryRifle> %1',0.75,1);
AddDamageType("MilitaryRifleHeadshot",   '<bitmap:add-ons/Weapon_Package_Tier2/CI_MilitaryRifle> <bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2/CI_MilitaryRifle> <bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',0.75,1);

datablock ProjectileData(MilitarySniperProjectile : shotgunBlastProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::MilitaryRifle;
   radiusDamageType    = $DamageType::MilitaryRifle;

   brickExplosionRadius = 0.4;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;
   brickExplosionMaxVolume = 25;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 35;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 300;
   verticalImpulse     = 100;
   explosion           = militarySniperExplosion;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 70;
   fadeDelay           = 0;
   isBallistic         = true;
   gravityMod = 0.0;
};

datablock ProjectileData(milTracerProjectile : pistolTracerProjectile)
{
   directDamage        = 1;
   directDamageType    = $DamageType::MilitaryRifle;
   muzzleVelocity      = 200;
   radiusDamageType    = $DamageType::MilitaryRifle;
};

//////////
// item //
//////////
datablock ItemData(MilitarySniperItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./sniper_rifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Sniper Rifle";
	iconName = "./sniperrifle";
	doColorShift = true;
	colorShiftColor = "0.3 0.3 0.3 1.000";

	 // Dynamic properties defined by the scripts
	image = MilitarySniperImage;
	canDrop = true;
    
   //Ammo Guns Parameters
   maxAmmo = 4;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MilitarySniperImage)
{
   raycastWeaponRange = 900;
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = shotgunBlastProjectile;
   raycastTracerProjectile = milTracerProjectile;
   raycastCritTracerProjectile = milTracerProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastCritDirectDamageType = $DamageType::MilitaryRifleHeadshot;
   raycastDirectDamage = 100; //Varies
   raycastDirectDamageType = $DamageType::MilitaryRifle;
   raycastSpreadAmt = 0; //Varies

   // Basic Item properties
	shapeFile = "./sniper_rifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = MilitarySniperItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   minShotTime = 1450;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = true;
   colorShiftColor = MilitarySniperItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.2;
	stateSequence[0]			  = "Activate";
	stateTransitionOnTimeout[0]     = "Smoke";
	stateSound[0]			  = weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1] = "Reload";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Wait2";
	stateTimeoutValue[2]            = 0.1;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
	stateEmitter[2]			  = gunFlashEmitter;
	stateEmitterTime[2]		  = 0.05;
	stateEmitterNode[2]		  = "muzzleNode";
	stateSound[2]			  = militarysniperfireSound;

	stateName[3] 			  = "Smoke";
	stateSequence[3]			  = "eject";
	stateSound[3]			  = boltriflereloadSound;
	stateTimeoutValue[3]            = 0.7;
	stateScript[3]                  = "onSmoke";
	stateTransitionOnTimeout[3]     = "Wait3";

	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 0.2;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Reload1";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadSmoke";
	
	stateName[10] 				= "ReloadSmoke";
	stateTimeoutValue[10]			= 0.3;
	stateTransitionOnTimeout[10]		= "Reload";
	
	stateName[11]				= "Reloaded";
	stateTimeoutValue[11]			= 0.4;
	stateScript[11]				= "onReloaded";
	stateTransitionOnTimeout[11]		= "Smoke";

	stateName[12] 			  = "Wait2";
	stateTimeoutValue[12]            = 0.7;
	stateTransitionOnTimeout[12]     = "Smoke";

	stateName[13] 			  = "Wait3";
	stateTimeoutValue[13]            = 0.7;
	stateTransitionOnTimeout[13]     = "LoadCheckA";

	stateName[14]				= "Reload1";
	stateTimeoutValue[14]			= 1.5;
	stateScript[14]				= "onReloaded1";
	stateTransitionOnTimeout[14]		= "Wait";

};

///////// notes on the reload sequence:
///////// it goes (reloadsmoke)-reload-reload1-wait-reloaded
///////// complex, huh?
///////////////////////////////////

function MilitarySniperImage::onReloadStart(%this,%obj,%slot)
{           		
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
	%obj.playThread(2, plant);
		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
}

function MilitarySniperImage::onReloaded1(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
		%obj.playThread(2, shiftleft);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function MilitarySniperImage::onReloadWait(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
		serverPlay3D(block_ChangeBrick_Sound,%obj.getPosition());
		%obj.playThread(2, shiftRight);
	}
}

function MilitarySniperImage::onSmoke(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
		%obj.playThread(2, plant);
	}
}


function MilitarySniperImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["308rounds"] >= 1)
	{
	%obj.client.quantity["308rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["308rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["308rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["308rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["308rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["308rounds"] = 0;

		
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

function MilitarySniperImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
	}
   %obj.lastFireTime = getSimTime() - 500;
}

function MilitarySniperImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");

  	%fvec = %obj.getForwardVector();
  	%fX = getWord(%fvec,0);
 	 %fY = getWord(%fvec,1);
  
 	 %evec = %obj.getEyeVector();
  	%eX = getWord(%evec,0);
 	 %eY = getWord(%evec,1);
 	 %eZ = getWord(%evec,2);
  
 	 %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  	%aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-4")));
	if((%obj.lastFireTime+%this.minShotTime) > getSimTime())
	{
		%thread = "plant";
		%this.raycastExplosionProjectile = militarySniperProjectile;
		%this.raycastSpreadAmt = ((%obj.lastFireTime+%this.minShotTime) - getSimTime())/%this.minShotTime*0.005;
		%this.raycastDirectDamage = 30;
	}
	else
	{
		%thread = "plant";
		%this.raycastExplosionProjectile = shotgunBlastProjectile;
		%this.raycastSpreadAmt = 0;
		%this.raycastDirectDamage = 33;
	}
	
	Parent::onFire(%this,%obj,%slot);

	if(!%obj.fireTrace)
	{
		%obj.lastFireTime = getSimTime();

		%obj.playThread(2, %thread);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool] -= 1;
		%obj.AmmoSpent[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
	}
}
	}

function MilitarySniperImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(%this.raycastSpreadAmt > 0)
      return 0;
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}