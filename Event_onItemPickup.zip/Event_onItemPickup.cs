registerInputEvent(fxDTSBrick,onItemPickup,"Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame Minigame");

package itemPickup
{
 function Player::pickup(%this,%item)
 {
  %brick = %item.spawnBrick;
  %val = Parent::pickup(%this,%item);
  if(%val == 1 && isObject(%brick) && %this.getClassName() $= "Player" && isObject(%this.client))
  {
   %client = %this.client;
   $InputTarget_["Self"]   = %brick;
   $InputTarget_["Player"] = %client.player;
   $InputTarget_["Client"] = %client;

   if($Server::LAN)
   {
      $InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
   }
   else
   {
      if(getMiniGameFromObject(%brick) == getMiniGameFromObject(%client))
         $InputTarget_["MiniGame"] = getMiniGameFromObject(%brick);
      else
         $InputTarget_["MiniGame"] = 0;
   }

   %brick.processInputEvent(onItemPickup,%client);
  }
  return %val;
 }
};activatePackage(itemPickup);