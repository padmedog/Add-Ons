if(!$toggleWalkBind)
{
	$toggleWalkBind = true;
	$remapDivision[$remapCount] = "Movement";
	$remapCmd[$remapCount] = "toggleWalk";
	$remapName[$remapCount] = "Toggle Walk";
	$remapCount++;
}

function toggleWalk(%down)
{
	if(!%down)
		return;
	
	$walking = !$walking;
	walk($walking);
}
