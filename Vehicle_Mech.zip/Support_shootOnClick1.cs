$TP::Version=1.1; //Version number, do NOT change this unless you know what you are doing.

if($Support::shootonclick1<$Prop::Version) {return;} //Newer version already loaded.
$Support::shootonclick1=$TP::Version;

package shootonclick1_Pack
{
	function armor::onTrigger(%db,%obj,%slot,%val)
	{
		if(%obj.getClassName()$="Player")
		{
			if(%slot==0)
			{
				if(%val)
				{
					if($Sim::Time<%obj.client.SOC11_LastFireTime)
					{
						return;
					}
				}
				%obj.SOC11_Shoot(%slot,%val);
			}
		}
		return Parent::onTrigger(%db,%obj,%slot,%val);
	}
};
ActivatePackage(shootonclick1_Pack);

function repeatedVectorAddwithScale(%vecs)
{
	%vec="0 0 0";
	%cnt=getFieldCount(%vecs);
	for(%i=0;%i<%cnt;%i++)
	{
		%fld=getField(%vecs,%i);
		%tvec=getWords(%fld,0,3);
		%scale=getWord(%fld,3);
		%svec=vectorScale(%tvec,%scale);
		%vec=vectorAdd(%vec,%svec);
	}
	return %vec;
}

function SimObject::getLeftVector(%obj)
{
	return vectorCross(%obj.getEyeVector(),%obj.getUpVector());
}

function SimObject::getRightVector(%obj)
{
	return vectorScale(%obj.getLeftVector(%obj),-1);
}

function Player::SOC11_Shoot(%obj,%slot,%val)
{
	if(!%val) {cancel(%obj.SOC11_reshoot);return;}
	
	%mnt= %obj.getObjectMount();
	if(!isObject(%mnt))
	{
		return;
	}

	%data= %mnt.getDatablock();
	
	%mountObj= %mnt.getMountNodeObject(%data.shootonclick1_RequiredSlot);
	if(%mountObj!$=%Obj) {return;}
	
	if(%data.shootonclick1)
	{
		//Checks OK, shoot it all.
		%cnt=%data.shootonclick1_ProjectileCount;
		for(%i=0;%i<%cnt;%i++)
		{
			%pos= %mnt.getPosition();
			%PVec= %data.shootonclick1_Position[%i];
			%VVec= %data.shootonclick1_Velocity[%i];
			%iPos= repeatedVectorAddwithScale(
			%mnt.getEyeVector() SPC getWord(%PVec,0) TAB
			%mnt.getLeftVector() SPC getWord(%PVec,1) TAB
			%mnt.getUpVector() SPC getWord(%PVec,2)
			);
			%iVel= repeatedVectorAddwithScale(
			%mnt.getEyeVector() SPC getWord(%VVec,0) TAB
			%mnt.getLeftVector() SPC getWord(%VVec,1) TAB
			%mnt.getUpVector() SPC getWord(%VVec,2)
			);
			%scale=%data.shootonclick1_Scale[%i];
			if(%scale$="") {%scale="1 1 1";}
			%p= new Projectile()
			{
				dataBlock= %data.shootonclick1_Projectile[%i];
				initialPosition= vectorAdd(%pos,%iPos);
				initialVelocity= %iVel;
				sourceObject= %obj;
				client= %obj.client;
				sourceSlot= %slot;
				scale= %scale;
			};missionCleanup.add(%p);
		}
		serverPlay3d(%data.shootonclick1_Sound,%pos);
		
		//If hold, schedule.
		if(%data.shootonclick1_Hold)
		{
			//Delay according to datablocks.
			%obj.SOC11_reshoot= %obj.schedule(%data.shootonclick1_ReshootDelay,SOC11_Shoot,%slot,%val);
		}
		%obj.client.SOC11_LastFireTime=$Sim::Time+%data.shootonclick1_ShootDelay/1000;
	}
}