//########## Rum

//### Sounds

datablock AudioProfile(gc_RumOpenSound)
{
  filename = "./rumopen.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_RumDrinkSound)
{
  filename = "./rumdrink.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_RumParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = -1;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 500;
  lifetimeVarianceMS = 100;
  textureName = "base/data/particles/dot";
  colors[0] = "0.3 0.2 0.1 1";
  colors[1] = "0.3 0.2 0.1 0.5";
  sizes[0] = 0;
  sizes[1] = 0.2;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_RumEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 0.5;
  velocityVariance = 0.5;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_RumParticle";
};

//### Item

datablock ItemData(gc_RumItem)
{
  uiName = "Rum";
  iconName = "./icon_rum";
  image = gc_RumImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./rum.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_RumImage)
{
  shapeFile = "./rum.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_RumItem;
  melee = false;
  doReaction = false;
  armReady = true;

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = gc_RumOpenSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateEmitter[1] = gc_RumEmitter;
  stateEmitterTime[1] = 10;
  stateTimeoutValue[1] = 10;
  stateTransitionOnTimeout[1] = "Ready";
  stateWaitForTimeout[1] = false;

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.6";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateScript[2] = "onFire";
  stateSound[2] = gc_RumDrinkSound;
};

function gc_RumImage::onFire(%this,%obj,%slot)
{
  if(%obj.getDamageLevel() > 0)
  {
    cancel(%obj.gc_bleed);
    %obj.setDamageFlash(0);
    %obj.setDamageLevel(%obj.getDamageLevel()-10);
    if(%obj.getDamagePercent() <= 0.75) centerPrint(%obj.client,"<color:ff0000>I feel terrible!",1);
    else if(%obj.getDamagePercent() <= 0.5) centerPrint(%obj.client,"<color:ffff00>I feel bad!",1);
    else if(%obj.getDamagePercent() <= 0.25) centerPrint(%obj.client,"<color:ffffff>I feel mildly sick!",1);
  }
  else
  {
    centerPrint(%obj.client,"<color:ffffff>I am fine!",1);
  }
}
