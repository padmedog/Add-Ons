//TITLE: CrossPick
//AUTHOR: HellsHero
//LETS YOU PICK CROSSHAIRS FROM A GUI WITH IMAGES.
//--------------------------------------------------------
//EXECUTE
exec("./Gui Files/GuiCrossPick.gui");
exec("./Gui Files/noCustomErrorGui.gui");
//GUI FUNCTIONS
if(!$CrossPickBind)
{
	$remapDivision[$remapCount] = "CrossHair Exchange";
	$remapName[$remapCount] = "Open CrossHair Window";
	$remapCmd[$remapCount] = "toggleCrossPickGUI";
	$remapCount++;
	$CrossPickBind = 1;
}
function startFolders()
{
	for(%x = 1; %x < 11; %x++)
	{
		%object = new fileObject();
		%object.openForWrite("Config/Client/CrossPick/Custom/"@%x@"/File.txt");
		%object.close();
		%object.delete();
		fileDelete("Config/Client/CrossPick/Custom/"@%x@"/File.txt");
	}
}
if(!isFile("Config/Client/CrossPick/Custom/ReadMe.txt"))
{
	echo("First time starting up... Creating Custom CrossHair readme and folders...");
	%file = new fileObject();
	%path = "Config/Client/CrossPick/Custom/ReadMe.txt";
	%file.openForWrite(%path);
	%file.writeLine("These are the custom CrossHair folders for the CrossPick GUI, by");
	%file.writeLine("putting a crossHair.png file into a folder that doesn't have one");
	%file.writeLine("will make you able to use it in-game with my add-on!");
	%file.writeLine("");
	%file.writeLine("HOW TO INSTALL CUSTOM CROSSHAIRS:");
	%file.writeLine("1: Take a crossHair.png file that is not already installed with this mod.");
	%file.writeLine("2: Put it into one of these folders. (Any folder without one OR you can");
	%file.writeLine("   replace one already in the custom folders)");
	%file.writeLine("3: Launch Blockland.");
	%file.writeLine("4: Start a game or join one.");
	%file.writeLine("5: Open up the CrossPick GUI and choose the new CrossHair that will appear!");
	%file.writeLine("6: And you're done!");
	%file.close();
	%file.delete();
	startFolders();
}

function toggleCrossPickGUI(%i)
{
	if(%i)
		if(GuiCrossPick.isAwake())
			canvas.popDialog(GuiCrossPick);
		else
			canvas.pushDialog(GuiCrossPick);
}
function noCustomError()
{
	canvas.pushDialog(noCustomErrorGUI);
}
function checkNoCustomCross(%val)
{
	if(!isFile("Config/Client/CrossPick/Custom/"@%val@"/crossHair.png"))
		noCustomError();
	else
		crossHair.setBitmap("Config/Client/CrossPick/Custom/"@%val@"/crossHair");
}
	
function defaultCross() //Default
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/1/crossHair");
}
function Tc1Cross() //Tc572
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/1/crossHair");
}
function Tc2Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/2/crossHair");
}
function Tc3Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/3/crossHair");
}
function Tc4Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/4/crossHair");
}
function Tc5Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/5/crossHair");
}
function Tc6Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/6/crossHair");
}
function Tc7Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/7/crossHair");
}
function Tc8Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/8/crossHair");
}
function Tc9Cross()
{
	crossHair.setBitmap("Add-Ons/Client_CrossPick/CrossHair/Tc572/9/crossHair");
}
function Cust1Cross() //Custom
{
	%val = 1;
	checkNoCustomCross(%val);
}
function Cust2Cross()
{
	%val = 2;
	checkNoCustomCross(%val);
}
function Cust3Cross()
{
	%val = 3;
	checkNoCustomCross(%val);
}
function Cust4Cross()
{
	%val = 4;
	checkNoCustomCross(%val);
}
function Cust5Cross()
{
	%val = 5;
	checkNoCustomCross(%val);
}
function Cust6Cross()
{
	%val = 6;
	checkNoCustomCross(%val);
}
function Cust7Cross()
{
	%val = 7;
	checkNoCustomCross(%val);
}
function Cust8Cross()
{
	%val = 8;
	checkNoCustomCross(%val);
}
function Cust9Cross()
{
	%val = 9;
	checkNoCustomCross(%val);
}
function Cust10Cross()
{
	%val = 10;
	checkNoCustomCross(%val);
}