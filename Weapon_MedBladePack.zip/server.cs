exec("./BattleAxes.cs");
exec("./Daggers.cs");
exec("./LongSwords.cs");
exec("./ShortSwords.cs");