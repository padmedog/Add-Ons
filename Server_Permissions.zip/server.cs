$Permissions::Loaded = true;

if ($Permissions::Shim::Version !$= "")
	deactivatePackage("PermissionsShimV" @ $Permissions::Shim::Version);

exec("./server/PermissionNameCache.cs");
exec("./server/PermissionRoleBase.cs");
exec("./server/PermissionManager.cs");
exec("./server/GameConnection.cs");
exec("./server/GUI.cs");

exec("./server/DefaultRetrofits.cs");

exec("./Updater_Server.cs");

function reloadPerms() {
    exec("./server.cs");
}

getPermissionManager().saveSched = getPermissionManager().schedule(0, doSave); // Bootstrap the save loop after all add-ons have loaded