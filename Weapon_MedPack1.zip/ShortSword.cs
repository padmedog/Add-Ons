//ShortSword.cs
datablock AudioProfile(ShortSwordDrawSound)
{
   filename    = "./WeaponDraw.wav";
   description = AudioClosest3d;
   preload = true;
};
datablock AudioProfile(ShortSwordHitSound)
{
   filename    = "./WeaponHit.wav";
   description = AudioClosest3d;
   preload = true;
};


//effects
datablock ParticleData(ShortSwordExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/dot";
   colors[0]     = "0.7 0.7 0.0 0.9";
   colors[1]     = "0.5 0.5 0.0 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};

datablock ParticleEmitterData(ShortSwordExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 4.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ShortSwordExplosionParticle";

   uiName = "ShortSword Hit";
};

datablock ExplosionData(ShortSwordExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 500;

   soundProfile = ShortSwordHitSound;

   particleEmitter = ShortSwordExplosionEmitter;
   particleDensity = 30;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "00.0 0.2 0.6";
   lightEndColor = "0 0 0";
};

//projectile
AddDamageType("ShortSword",  'Shortened %1',    '%2 Shortened %1!',1,1);
datablock ProjectileData(ShortSwordProjectile)
{
   directDamage        = 35;
   directDamageType  = $DamageType::ShortSword;
   radiusDamageType  = $DamageType::ShortSword;
   explosion           = ShortSwordExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 40;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "ShortSword Slice";
};

//////////
// item //
//////////
datablock ItemData(ShortSwordItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./ShortSword.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotation = "0 0 180";

	//gui stuff
	uiName = "ShortSword";
	iconName = "./icon_ShortSword";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = ShortSwordImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ShortSwordImage)
{
   // Basic Item properties
   shapeFile = "./ShortSword.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = "0 0 0";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ShortSwordItem;
   ammo = " ";
   projectile = ShortSwordProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = ShortSwordDrawSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = true;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Fire2";
	stateTimeoutValue[3]            = 0.1;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = true;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "Fire2";
	stateScript[4]                  = "onFire2";
	stateTransitionOnTimeout[4]     = "CheckFire";
	stateAllowImageChange[4]        = true;
	stateTimeoutValue[4]            = 0.5;

	stateName[5]			= "CheckFire";
	stateTransitionOnTriggerUp[5]	= "StopFire";
	stateTransitionOnTriggerDown[5]	= "Fire";

	
	stateName[6]                    = "StopFire";
	stateTransitionOnTimeout[6]     = "Ready";
	stateTimeoutValue[6]            = 0.5;
	stateAllowImageChange[6]        = false;
	stateWaitForTimeout[6]		= true;
	stateSequence[6]                = "StopFire";
	stateScript[6]                  = "onStopFire";


};

function ShortSwordImage::onFire(%this, %obj, %slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, ShiftDown);
	Parent::onFire(%this,%obj,%slot);	
}

function ShortSwordImage::onFire2(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, ShiftAway);
	Parent::onFire(%this,%obj,%slot);	
}

function ShortSwordImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}