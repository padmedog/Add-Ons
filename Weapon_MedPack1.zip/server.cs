exec("./Pike.cs");
exec("./BroadSword.cs");
exec("./ThrowingDagger.cs");
exec("./ShortSword.cs");
exec("./Scimitar.cs");
exec("./MorningStar.cs");
exec("./Rage.cs");
exec("./Vengence.cs");