
function getEventRow(%swatch)
{
	for(%a=0;%a<WrenchEvents_Box.getCount();%a++)
		if(WrenchEvents_Box.getObject(%a) == %swatch)
			return %a;
	return -1;
}

function getEmptyEventSwatch()
{
	for(%a=0;%a<WrenchEvents_Box.getCount();%a++)
	{
		%swatch = WrenchEvents_Box.getObject(%a);
		if(getInputFromEventSwatch(%swatch).getSelected() == -1 || getInputFromEventSwatch(%swatch).getValue() $= "")
			return %swatch;
	}
	return -1;
}

function getDelayFromEventSwatch(%swatch)
{
	for(%a=0;%a<%swatch.getCount();%a++)
	{
		%object = %swatch.getObject(%a);
		if(%object.command $= "$ThisControl.setText(mClamp($ThisControl.getValue(), 0, 30000));")
			return %object;
	}
	return -1;
}

function getEnabledFromEventSwatch(%swatch)
{
	for(%a=0;%a<%swatch.getCount();%a++)
	{
		%object = %swatch.getObject(%a);
		if(%object.profile $= "GuiCheckBoxProfile")
		{
			if(%object.position $= "0 0")
				return %object;
		}
	}
	return -1;
}

function getInputFromEventSwatch(%swatch)
{
	for(%b=0;%b<%swatch.getCount();%b++)
	{
		if(%swatch.getObject(%b).profile $= "GuiPopUpMenuProfile")
		{
			if(stripos(%swatch.getObject(%b).command,"createTargetList") != -1)
			{
				return %swatch.getObject(%b);
			}
		}
	}
	return -1;
}

function getTargetFromEventSwatch(%swatch)
{
	for(%b=0;%b<%swatch.getCount();%b++)
	{
		if(%swatch.getObject(%b).profile $= "GuiPopUpMenuProfile")
		{
			if(stripos(%swatch.getObject(%b).command,"createOutputList") != -1 && !(%swatch.getObject(%b).getName() $= "namedBrickList"))
			{
				return %swatch.getObject(%b);
			}
		}
	}
	return -1;
}

function getOutputFromEventSwatch(%swatch)
{
	for(%b=0;%b<%swatch.getCount();%b++)
	{
		if(%swatch.getObject(%b).profile $= "GuiPopUpMenuProfile")
		{
			if(stripos(%swatch.getObject(%b).command,"createOutputParameters") != -1)
			{
				return %swatch.getObject(%b);
			}
		}
	}
	return -1;
}

function getBrickFromEventSwatch(%swatch)
{
	for(%b=0;%b<%swatch.getCount();%b++)
	{
		if(%swatch.getObject(%b).profile $= "GuiPopUpMenuProfile")
		{
			if(stripos(%swatch.getObject(%b).command,"createOutputList") != -1 && %swatch.getObject(%b).getName() $= "namedBrickList")
			{
				return %swatch.getObject(%b);
			}
		}
	}
	return -1;
}

function copyEventRow(%button)
{
	%swatch = %button.parent;
	%targetRow = getEmptyEventSwatch();

	%oldEnabled = getEnabledFromEventSwatch(%swatch).getValue();
	%oldInput = getInputFromEventSwatch(%swatch).getSelected();
	%oldTarget = getTargetFromEventSwatch(%swatch).getSelected();
	%oldDelay = getDelayFromEventSwatch(%swatch).getValue();
	%oldBrick = 0;
	if(getTargetFromEventSwatch(%swatch).getValue() $= "<NAMED BRICK>")
		%oldBrick = getBrickFromEventSwatch(%swatch).getSelected();	
	%oldOutput = getOutputFromEventSwatch(%swatch).getSelected();

	getInputFromEventSwatch(%targetRow).setSelected(%oldInput);
	getInputFromEventSwatch(%targetRow).forceClose();
	getTargetFromEventSwatch(%targetRow).setSelected(%oldTarget);
	getTargetFromEventSwatch(%targetRow).forceClose();
	if(getTargetFromEventSwatch(%swatch).getValue() $= "<NAMED BRICK>")
	{
		getBrickFromEventSwatch(%targetRow).setSelected(%oldBrick);
		getBrickFromEventSwatch(%targetRow).forceClose();
	}
	getOutputFromEventSwatch(%targetRow).setSelected(%oldOutput);
	getOutputFromEventSwatch(%targetRow).forceClose();
	getEnabledFromEventSwatch(%targetRow).setValue(%oldEnabled);
	getDelayFromEventSwatch(%targeTRow).setValue(%oldDelay);

	%use = false;
	$tempArgs = 0;
	for(%a=0;%a<%swatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%swatch.getObject(%a) == getOutputFromEventSwatch(%swatch))
				%use = true;
		}
		else
		{
			%form = %swatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				$tempArg[$tempArgs] = %form.getSelected();
				$tempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				$tempArg[$tempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
				$tempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				$tempArg[$tempArgs] = 	%form.value;
				$tempArgs++;
			}
			else
			{
				$tempArg[$tempArgs] = %form.getValue();
				$tempArgs++;
			}
		}
	}

	%use = false;
	%argCount = 0;
	for(%a=0;%a<%targetRow.getCount();%a++)
	{
		if(!%use)
		{
			if(%targetRow.getObject(%a) == getOutputFromEventSwatch(%targetRow))
				%use = true;
		}
		else
		{
			%form = %targetRow.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				%form.setSelected($tempArg[%argCount]);
				%argCount++;
				%form.forceClose();
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				%form.getObject(0).setValue(getWord($tempArg[%argCount],0));
				%form.getObject(1).setValue(getWord($tempArg[%argCount],1));
				%form.getObject(2).setValue(getWord($tempArg[%argCount],2));
				%argCount++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				%form.value = $tempArg[%argCount];
				%color = getColorIDTable(%form.value);
				%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
				%form.color = %value;
				%argCount++;
			}
			else
			{
				%form.setValue($tempArg[%argCount]);
				%argCount++;
			}
		}
	}	
}

function downEventRow(%button)
{
	%currentSwatch = %button.parent;
	%currentRow = getEventRow(%currentSwatch);
	%targetRow = %currentRow+1;

	%targetSwatch = WrenchEvents_Box.getObject(%targetRow);

	if(!isObject(%targetSwatch))
		return;

	if(!isObject(getOutputFromEventSwatch(%targetSwatch)))
		return;

	%currentEnabled = getEnabledFromEventSwatch(%currentSwatch).getValue();
	%currentInput = getInputFromEventSwatch(%currentSwatch).getSelected();
	%currentTarget = getTargetFromEventSwatch(%currentSwatch).getSelected();
	%currentDelay = getDelayFromEventSwatch(%currentSwatch).getValue();
	%currentBrick = 0;
	if(getTargetFromEventSwatch(%currentSwatch).getValue() $= "<NAMED BRICK>")
		%currentBrick = getBrickFromEventSwatch(%currentSwatch).getSelected();
	%currentOutput = getOutputFromEventSwatch(%currentSwatch).getSelected();

	%targetEnabled = getEnabledFromEventSwatch(%targetSwatch).getValue();
	%targetInput = getInputFromEventSwatch(%targetSwatch).getSelected();
	%targetTarget = getTargetFromEventSwatch(%targetSwatch).getSelected();
	%targetDelay = getDelayFromEventSwatch(%targetSwatch).getValue();
	%targetBrick = 0;
	if(getTargetFromEventSwatch(%targetSwatch).getValue() $= "<NAMED BRICK>")
		%targetBrick = getBrickFromEventSwatch(%targetSwatch).getSelected();
	%targetOutput = getOutputFromEventSwatch(%targetSwatch).getSelected();

	%use = false;
	$currentTempArgs = 0;
	for(%a=0;%a<%currentSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%currentSwatch.getObject(%a) == getOutputFromEventSwatch(%currentSwatch))
				%use = true;
		}
		else
		{
			%form = %currentSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				$currentTempArg[$currentTempArgs] = %form.getSelected();
				$currentTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				$currentTempArg[$currentTempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
				$currentTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				$currentTempArg[$currentTempArgs] = 	%form.value;
				$currentTempArgs++;
			}
			else
			{
				$currentTempArg[$currentTempArgs] = %form.getValue();
				$currentTempArgs++;
			}
		}
	}

	%use = false;
	$targetTempArgs = 0;
	for(%a=0;%a<%targetSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%targetSwatch.getObject(%a) == getOutputFromEventSwatch(%targetSwatch))
				%use = true;
		}
		else
		{
			%form = %targetSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				$targetTempArg[$targetTempArgs] = %form.getSelected();
				$targetTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				$targetTempArg[$targetTempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
				$targetTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				$targetTempArg[$targetTempArgs] = 	%form.value;
				$targetTempArgs++;
			}
			else
			{
				$targetTempArg[$targetTempArgs] = %form.getValue();
				$targetTempArgs++;
			}
		}
	}

	getEnabledFromEventSwatch(%targetSwatch).setValue(%currentEnabled);
	getInputFromEventSwatch(%targetSwatch).setSelected(%currentInput);
	getInputFromEventSwatch(%targetSwatch).forceClose();
	getTargetFromEventSwatch(%targetSwatch).setSelected(%currentTarget);
	getTargetFromEventSwatch(%targetSwatch).forceClose();
	getDelayFromEventSwatch(%targetSwatch).setValue(%currentDelay);
	if(getTargetFromEventSwatch(%targetSwatch).getValue() $= "<NAMED BRICK>")
	{
		getBrickFromEventSwatch(%targetSwatch).setSelected(%currentBrick);
		getBrickFromEventSwatch(%targetSwatch).forceClose();
	}
	getOutputFromEventSwatch(%targetSwatch).setSelected(%currentOutput);
	getOutputFromEventSwatch(%targetSwatch).forceClose();

	%use = false;
	%argCount = 0;
	for(%a=0;%a<%targetSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%targetSwatch.getObject(%a) == getOutputFromEventSwatch(%targetSwatch))
				%use = true;
		}
		else
		{
			%form = %targetSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				%form.setSelected($currentTempArg[%argCount]);
				%argCount++;
				%form.forceClose();
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				%form.getObject(0).setValue(getWord($currentTempArg[%argCount],0));
				%form.getObject(1).setValue(getWord($currentTempArg[%argCount],1));
				%form.getObject(2).setValue(getWord($currentTempArg[%argCount],2));
				%argCount++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				%form.value = $currentTempArg[%argCount];
				%color = getColorIDTable(%form.value);
				%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
				%form.color = %value;
				%argCount++;
			}
			else
			{
				%form.setValue($currentTempArg[%argCount]);
				%argCount++;
			}
		}
	}

	getEnabledFromEventSwatch(%currentSwatch).setValue(%targetEnabled);
	getInputFromEventSwatch(%currentSwatch).setSelected(%targetInput);
	getInputFromEventSwatch(%currentSwatch).forceClose();
	getTargetFromEventSwatch(%currentSwatch).setSelected(%targetTarget);
	getTargetFromEventSwatch(%currentSwatch).forceClose();
	getDelayFromEventSwatch(%currentSwatch).setValue(%targetDelay);
	if(getTargetFromEventSwatch(%currentSwatch).getValue() $= "<NAMED BRICK>")
	{
		getBrickFromEventSwatch(%currentSwatch).setSelected(%targetBrick);
		getBrickFromEventSwatch(%currentSwatch).forceClose();
	}
	getOutputFromEventSwatch(%currentSwatch).setSelected(%targetOutput);
	getOutputFromEventSwatch(%currentSwatch).forceClose();
	
	%use = false;
	%argCount = 0;
	for(%a=0;%a<%currentSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%currentSwatch.getObject(%a) == getOutputFromEventSwatch(%currentSwatch))
				%use = true;
		}
		else
		{
			%form = %currentSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				%form.setSelected($targetTempArg[%argCount]);
				%argCount++;
				%form.forceClose();
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				%form.getObject(0).setValue(getWord($targetTempArg[%argCount],0));
				%form.getObject(1).setValue(getWord($targetTempArg[%argCount],1));
				%form.getObject(2).setValue(getWord($targetTempArg[%argCount],2));
				%argCount++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				%form.value = $targetTempArg[%argCount];
				%color = getColorIDTable(%form.value);
				%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
				%form.color = %value;
				%argCount++;
			}
			else
			{
				%form.setValue($targetTempArg[%argCount]);
				%argCount++;
			}
		}
	}
}


function upEventRow(%button)
{
	%currentSwatch = %button.parent;
	%currentRow = getEventRow(%currentSwatch);
	%targetRow = %currentRow-1;

	if(%targetRow < 0)
		return;

	%targetSwatch = WrenchEvents_Box.getObject(%targetRow);

	if(!isObject(%targetSwatch))
		return;

	if(!isObject(getOutputFromEventSwatch(%targetSwatch)))
		return;

	%currentEnabled = getEnabledFromEventSwatch(%currentSwatch).getValue();
	%currentInput = getInputFromEventSwatch(%currentSwatch).getSelected();
	%currentTarget = getTargetFromEventSwatch(%currentSwatch).getSelected();
	%currentDelay = getDelayFromEventSwatch(%currentSwatch).getValue();
	%currentBrick = 0;
	if(getTargetFromEventSwatch(%currentSwatch).getValue() $= "<NAMED BRICK>")
		%currentBrick = getBrickFromEventSwatch(%currentSwatch).getSelected();
	%currentOutput = getOutputFromEventSwatch(%currentSwatch).getSelected();

	%targetEnabled = getEnabledFromEventSwatch(%targetSwatch).getValue();
	%targetInput = getInputFromEventSwatch(%targetSwatch).getSelected();
	%targetTarget = getTargetFromEventSwatch(%targetSwatch).getSelected();
	%targetDelay = getDelayFromEventSwatch(%targetSwatch).getValue();
	%targetBrick = 0;
	if(getTargetFromEventSwatch(%targetSwatch).getValue() $= "<NAMED BRICK>")
		%targetBrick = getBrickFromEventSwatch(%targetSwatch).getSelected();
	%targetOutput = getOutputFromEventSwatch(%targetSwatch).getSelected();

	%use = false;
	$currentTempArgs = 0;
	for(%a=0;%a<%currentSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%currentSwatch.getObject(%a) == getOutputFromEventSwatch(%currentSwatch))
				%use = true;
		}
		else
		{
			%form = %currentSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				$currentTempArg[$currentTempArgs] = %form.getSelected();
				$currentTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				$currentTempArg[$currentTempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
				$currentTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				$currentTempArg[$currentTempArgs] = 	%form.value;
				$currentTempArgs++;
			}
			else
			{
				$currentTempArg[$currentTempArgs] = %form.getValue();
				$currentTempArgs++;
			}
		}
	}

	%use = false;
	$targetTempArgs = 0;
	for(%a=0;%a<%targetSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%targetSwatch.getObject(%a) == getOutputFromEventSwatch(%targetSwatch))
				%use = true;
		}
		else
		{
			%form = %targetSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				$targetTempArg[$targetTempArgs] = %form.getSelected();
				$targetTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				$targetTempArg[$targetTempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
				$targetTempArgs++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				$targetTempArg[$targetTempArgs] = 	%form.value;
				$targetTempArgs++;
			}
			else
			{
				$targetTempArg[$targetTempArgs] = %form.getValue();
				$targetTempArgs++;
			}
		}
	}

	getEnabledFromEventSwatch(%targetSwatch).setValue(%currentEnabled);
	getInputFromEventSwatch(%targetSwatch).setSelected(%currentInput);
	getInputFromEventSwatch(%targetSwatch).forceClose();
	getTargetFromEventSwatch(%targetSwatch).setSelected(%currentTarget);
	getTargetFromEventSwatch(%targetSwatch).forceClose();
	getDelayFromEventSwatch(%targetSwatch).setValue(%currentDelay);
	if(getTargetFromEventSwatch(%targetSwatch).getValue() $= "<NAMED BRICK>")
	{
		getBrickFromEventSwatch(%targetSwatch).setSelected(%currentBrick);
		getBrickFromEventSwatch(%targetSwatch).forceClose();
	}
	getOutputFromEventSwatch(%targetSwatch).setSelected(%currentOutput);
	getOutputFromEventSwatch(%targetSwatch).forceClose();

	%use = false;
	%argCount = 0;
	for(%a=0;%a<%targetSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%targetSwatch.getObject(%a) == getOutputFromEventSwatch(%targetSwatch))
				%use = true;
		}
		else
		{
			%form = %targetSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				%form.setSelected($currentTempArg[%argCount]);
				%argCount++;
				%form.forceClose();
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				%form.getObject(0).setValue(getWord($currentTempArg[%argCount],0));
				%form.getObject(1).setValue(getWord($currentTempArg[%argCount],1));
				%form.getObject(2).setValue(getWord($currentTempArg[%argCount],2));
				%argCount++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				%form.value = $currentTempArg[%argCount];
				%color = getColorIDTable(%form.value);
				%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
				%form.color = %value;
				%argCount++;
			}
			else
			{
				%form.setValue($currentTempArg[%argCount]);
				%argCount++;
			}
		}
	}

	getEnabledFromEventSwatch(%currentSwatch).setValue(%targetEnabled);
	getInputFromEventSwatch(%currentSwatch).setSelected(%targetInput);
	getInputFromEventSwatch(%currentSwatch).forceClose();
	getTargetFromEventSwatch(%currentSwatch).setSelected(%targetTarget);
	getTargetFromEventSwatch(%currentSwatch).forceClose();
	getDelayFromEventSwatch(%currentSwatch).setValue(%targetDelay);
	if(getTargetFromEventSwatch(%currentSwatch).getValue() $= "<NAMED BRICK>")
	{
		getBrickFromEventSwatch(%currentSwatch).setSelected(%targetBrick);
		getBrickFromEventSwatch(%currentSwatch).forceClose();
	}
	getOutputFromEventSwatch(%currentSwatch).setSelected(%targetOutput);
	getOutputFromEventSwatch(%currentSwatch).forceClose();
	
	%use = false;
	%argCount = 0;
	for(%a=0;%a<%currentSwatch.getCount();%a++)
	{
		if(!%use)
		{
			if(%currentSwatch.getObject(%a) == getOutputFromEventSwatch(%currentSwatch))
				%use = true;
		}
		else
		{
			%form = %currentSwatch.getObject(%a);
			if(%form.profile $= "GuiPopUpMenuProfile")
			{
				%form.setSelected($targetTempArg[%argCount]);
				%argCount++;
				%form.forceClose();
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
			{
				%form.getObject(0).setValue(getWord($targetTempArg[%argCount],0));
				%form.getObject(1).setValue(getWord($targetTempArg[%argCount],1));
				%form.getObject(2).setValue(getWord($targetTempArg[%argCount],2));
				%argCount++;
			}
			else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
			{
				%form.value = $targetTempArg[%argCount];
				%color = getColorIDTable(%form.value);
				%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
				%form.color = %value;
				%argCount++;
			}
			else
			{
				%form.setValue($targetTempArg[%argCount]);
				%argCount++;
			}
		}
	}
}

function deleteEventRow(%button)
{
	getInputFromEventSwatch(%button.parent).setSelected(-1);	
}

package newEventLine3
{
	function WrenchEventsDlg::onWake(%this,%b)
	{
		for(%a=0;%a<$copyButtons;%a++)
			if(isObject($copyButtonStack[%a]))
				$copyButtonStack[%a].delete();
		$copyButtons = 0;
		for(%a=0;%a<$upButtons;%a++)
			if(isObject($upButtonStack[%a]))
				$upButtonStack[%a].delete();
		$upButtons = 0;
		for(%a=0;%a<$downButtons;%a++)
			if(isObject($downButtonStack[%a]))
				$downButtonStack[%a].delete();
		$downButtons = 0;
		for(%a=0;%a<$deleteButtons;%a++)
			if(isObject($deleteButtonStack[%a]))
				$deleteButtonStack[%a].delete();
		$deleteButtons = 0;
		return Parent::onWake(%this,%b);
	}

	function wrenchEventsDlg::createOutputParameters(%this,%swatch,%popup,%target)
	{
		%act = Parent::createOutputParameters(%this,%swatch,%popup,%target);

		%ret = new GuiBitmapButtonCtrl()
		{
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "0 20";
			extent = "12 12";
			visible = true;
			mColor = "100 200 100 255";
			bitmap = "base/client/ui/button2";
			copyButton = true;
			text = "";
			parent = %swatch;
		};
		%ret.command = "copyEventRow(" @ %ret @ ");";

		if(!($copyButtons > 0 || $copyButtons < 0))
			$copyButtons = 0;
		$copyButtonStack[$copyButtons] = %ret;
		$copyButtons++;

		%swatch.add(%ret);

		%ret = new GuiBitmapButtonCtrl()
		{
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "39 20";
			extent = "12 12";
			visible = true;
			mColor = "200 100 100 255";
			bitmap = "base/client/ui/button2";
			deleteButton = true;
			text = "";
			parent = %swatch;
		};
		%ret.command = "deleteEventRow(" @ %ret @ ");";

		if(!($deleteButtons > 0 || $deleteButtons < 0))
			$deleteButtons = 0;
		$deleteButtonStack[$deleteButtons] = %ret;
		$deleteButtons++;

		%swatch.add(%ret);

		%ret = new GuiBitmapButtonCtrl()
		{
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "24 20";
			extent = "12 12";
			visible = true;
			mColor = "220 220 220 255";
			bitmap = "add-ons/System_BlocklandEssentials/up";
			downButton = true;
			parent = %swatch;
		};
		%ret.command = "downEventRow(" @ %ret @ ");";

		if(!($downButtons > 0 || $downButtons < 0))
			$downButtons = 0;
		$downButtonStack[$downButtons] = %ret;
		$downButtons++;

		%swatch.add(%ret);

		%ret = new GuiBitmapButtonCtrl()
		{
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "12 20";
			extent = "12 12";
			visible = true;
			mColor = "220 220 220 255";
			bitmap = "add-ons/System_BlocklandEssentials/down";
			upButton = true;
			parent = %swatch;
		};
		%ret.command = "upEventRow(" @ %ret @ ");";

		if(!($upButtons > 0 || $upButtons < 0))
			$upButtons = 0;
		$upButtonStack[$upButtons] = %ret;
		$upButtons++;

		%swatch.add(%ret);

		return %act;
	}
};
activatepackage(newEventLine3);

function addSaveLoadEventsButton()
{
	if(isObject(saveLoadEventsButton))
		return;

	%ret = new GuiBitmapButtonCtrl(saveLoadEventsButton)
	{
		profile = "BlockButtonProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "339 549";
		extent = "122 38";
		minExtent = "100 30";
		visible = true;
		bitmap = "base/client/ui/button2";
		command = "canvas.pushDialog(eventSavingDlg);";
		text = "Save/Load events";
		mColor = "255 255 255 255";
	};
	WrenchEvents_Window.add(%ret);
}

addSaveLoadEventsButton();

if(!$eventSavingDlgFile)
	exec("./eventSavingDlg.gui");

$eventSavesDirectory = "config/client/eventSaves/";

function clearEventsWindow()
{
	for(%a=0;%a<WrenchEvents_Box.getCount();%a++)
	{
		getInputFromEventSwatch(WrenchEvents_Box.getObject(%a)).setSelected(-1);
		//getInputFromEventSwatch(WrenchEvents_Box.getObject(%a)).setValue("");
	}
}

function loadEventsWait()
{
	%name = eventSavesList.getValue();
	
	%fileObject = new fileObject();
	%fileObject.openForRead(%name);
	%fileObject.readLine();

	while(!%fileObject.isEOF())
	{
		%swatch = getEmptyEventSwatch();

		%line = %fileObject.readLine();
		%inputArg = getField(%line,0);
		%targetArg = getField(%line,1);

		if(%targetArg $= "<NAMED BRICK>")
		{
			%input = getInputFromEventSwatch(%swatch);
			%input.setSelected(%input.findText(%inputArg));
			%input.forceClose();

			%target = getTargetFromEventSwatch(%swatch);
			%target.setSelected(%target.findText(%targetArg));
			%target.forceClose();
			
			%brickArg = getField(%line,2);
			%brick = getBrickFromEventSwatch(%swatch);

			if(%brick.findText(%brickArg) == -1)
			{
				%input.setSelected(-1);
				%input.forceClose();
				warn("This event save requires a brick named " @ %brickArg @ " but there wasn't one. Event line skipped.");
			}
			else
			{

				%brick.setSelected(%brick.findText(%brickArg));
				%brick.forceClose();

				%outputArg = getField(%line,3);
				%output = getOutputFromEventSwatch(%swatch);
				%output.setSelected(%output.findText(%outputArg));
				%output.forceClose();

				%delayArg = getField(%line,4);
				getDelayFromEventSwatch(%swatch).setValue(%delayArg);
	
				$tempArgs = 0;
				for(%a = 5; %a<getFieldCount(%line); %a++)
				{
					$tempArg[$tempArgs] = getField(%line,%a);
					$tempArgs++;
				}

				%use = false;
				%argCount = 0;
				for(%a=0;%a<%swatch.getCount();%a++)
				{
					if(!%use)
					{
						if(%swatch.getObject(%a) == getOutputFromEventSwatch(%swatch))
							%use = true;
					}
					else
					{
						%form = %swatch.getObject(%a);
						if(%form.profile $= "GuiPopUpMenuProfile")
						{
							%form.setSelected($tempArg[%argCount]);
							%argCount++;
							%form.forceClose();
						}
						else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
						{
							%form.getObject(0).setValue(getWord($tempArg[%argCount],0));
							%form.getObject(1).setValue(getWord($tempArg[%argCount],1));
							%form.getObject(2).setValue(getWord($tempArg[%argCount],2));
							%argCount++;
						}
						else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
						{
							%form.value = $tempArg[%argCount];
							%color = getColorIDTable(%form.value);
							%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
							%form.color = %value;
							%argCount++;
						}
						else
						{
							%form.setValue($tempArg[%argCount]);
							%argCount++;
						}
					}
				}
			}
		}
		else
		{
			%input = getInputFromEventSwatch(%swatch);
			%input.setSelected(%input.findText(%inputArg));
			%input.forceClose();

			%target = getTargetFromEventSwatch(%swatch);
			%target.setSelected(%target.findText(%targetArg));
			%target.forceClose();

			%outputArg = getField(%line,2);
			%output = getOutputFromEventSwatch(%swatch);
			%output.setSelected(%output.findText(%outputArg));
			%output.forceClose();

			%delayArg = getField(%line,3);
			getDelayFromEventSwatch(%swatch).setValue(%delayArg);

			$tempArgs = 0;
			for(%a = 4; %a<getFieldCount(%line); %a++)
			{
				$tempArg[$tempArgs] = getField(%line,%a);
				$tempArgs++;
			}

			%use = false;
			%argCount = 0;
			for(%a=0;%a<%swatch.getCount();%a++)
			{
				if(!%use)
				{
					if(%swatch.getObject(%a) == getOutputFromEventSwatch(%swatch))
						%use = true;
				}
				else
				{
					%form = %swatch.getObject(%a);
					if(%form.profile $= "GuiPopUpMenuProfile")
					{
						%form.setSelected($tempArg[%argCount]);
						%argCount++;
						%form.forceClose();
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
					{
						%form.getObject(0).setValue(getWord($tempArg[%argCount],0));
						%form.getObject(1).setValue(getWord($tempArg[%argCount],1));
						%form.getObject(2).setValue(getWord($tempArg[%argCount],2));
						%argCount++;
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
					{
						%form.value = $tempArg[%argCount];
						%color = getColorIDTable(%form.value);
						%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
						%form.color = %value;
						%argCount++;
					}
					else
					{
						%form.setValue($tempArg[%argCount]);
						%argCount++;
					}
				}
			}
		}
	}

	%fileObject.close();
}

function loadEventsOverwrite()
{
	clearEventsWindow();
	schedule(100,0,loadEventsWait);
}

function deleteEvents()
{
	%name = eventSavesList.getValue();
	fileDelete(%name);
	
	eventSavesList.clear();
	while((%file = findNextFile($eventSavesDirectory @ "*")) !$= "")
		eventSavesList.addRow(%inc++,%file);
}

function loadEventsAppend()
{
	%name = eventSavesList.getValue();
	
	%fileObject = new fileObject();
	%fileObject.openForRead(%name);
	%fileObject.readLine();

	while(!%fileObject.isEOF())
	{
		%swatch = getEmptyEventSwatch();

		%line = %fileObject.readLine();
		%inputArg = getField(%line,0);
		%targetArg = getField(%line,1);

		if(%targetArg $= "<NAMED BRICK>")
		{
			%input = getInputFromEventSwatch(%swatch);
			%input.setSelected(%input.findText(%inputArg));
			%input.forceClose();

			%target = getTargetFromEventSwatch(%swatch);
			%target.setSelected(%target.findText(%targetArg));
			%target.forceClose();
			
			%brickArg = getField(%line,2);
			%brick = getBrickFromEventSwatch(%swatch);

			if(%brick.findText(%brickArg) == -1)
			{
				%input.setSelected(-1);
				%input.forceClose();
				warn("This event save requires a brick named " @ %brickArg @ " but there wasn't one. Event line skipped.");
			}
			else
			{

				%brick.setSelected(%brick.findText(%brickArg));
				%brick.forceClose();

				%outputArg = getField(%line,3);
				%output = getOutputFromEventSwatch(%swatch);
				%output.setSelected(%output.findText(%outputArg));
				%output.forceClose();

				%delayArg = getField(%line,4);
				getDelayFromEventSwatch(%swatch).setValue(%delayArg);
	
				$tempArgs = 0;
				for(%a = 5; %a<getFieldCount(%line); %a++)
				{
					$tempArg[$tempArgs] = getField(%line,%a);
					$tempArgs++;
				}

				%use = false;
				%argCount = 0;
				for(%a=0;%a<%swatch.getCount();%a++)
				{
					if(!%use)
					{
						if(%swatch.getObject(%a) == getOutputFromEventSwatch(%swatch))
							%use = true;
					}
					else
					{
						%form = %swatch.getObject(%a);
						if(%form.profile $= "GuiPopUpMenuProfile")
						{
							%form.setSelected($tempArg[%argCount]);
							%argCount++;
							%form.forceClose();
						}
						else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
						{
							%form.getObject(0).setValue(getWord($tempArg[%argCount],0));
							%form.getObject(1).setValue(getWord($tempArg[%argCount],1));
							%form.getObject(2).setValue(getWord($tempArg[%argCount],2));
							%argCount++;
						}
						else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
						{
							%form.value = $tempArg[%argCount];
							%color = getColorIDTable(%form.value);
							%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
							%form.color = %value;
							%argCount++;
						}
						else
						{
							%form.setValue($tempArg[%argCount]);
							%argCount++;
						}
					}
				}
			}
		}
		else
		{
			%input = getInputFromEventSwatch(%swatch);
			%input.setSelected(%input.findText(%inputArg));
			%input.forceClose();

			%target = getTargetFromEventSwatch(%swatch);
			%target.setSelected(%target.findText(%targetArg));
			%target.forceClose();

			%outputArg = getField(%line,2);
			%output = getOutputFromEventSwatch(%swatch);
			%output.setSelected(%output.findText(%outputArg));
			%output.forceClose();

			%delayArg = getField(%line,3);
			getDelayFromEventSwatch(%swatch).setValue(%delayArg);

			$tempArgs = 0;
			for(%a = 4; %a<getFieldCount(%line); %a++)
			{
				$tempArg[$tempArgs] = getField(%line,%a);
				$tempArgs++;
			}

			%use = false;
			%argCount = 0;
			for(%a=0;%a<%swatch.getCount();%a++)
			{
				if(!%use)
				{
					if(%swatch.getObject(%a) == getOutputFromEventSwatch(%swatch))
						%use = true;
				}
				else
				{
					%form = %swatch.getObject(%a);
					if(%form.profile $= "GuiPopUpMenuProfile")
					{
						%form.setSelected($tempArg[%argCount]);
						%argCount++;
						%form.forceClose();
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
					{
						%form.getObject(0).setValue(getWord($tempArg[%argCount],0));
						%form.getObject(1).setValue(getWord($tempArg[%argCount],1));
						%form.getObject(2).setValue(getWord($tempArg[%argCount],2));
						%argCount++;
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
					{
						%form.value = $tempArg[%argCount];
						%color = getColorIDTable(%form.value);
						%value = mFloor(getWord(%color,0)*255) SPC mFloor(getWord(%color,1)*255) SPC mFloor(getWord(%color,2)*255) SPC 255;
						%form.color = %value;
						%argCount++;
					}
					else
					{
						%form.setValue($tempArg[%argCount]);
						%argCount++;
					}
				}
			}
		}
	}

	%fileObject.close();
}

function saveEvents()
{
	%name = eventSavingNameBox.getValue();
	eventSavingNameBox.setValue("");
	%file = $eventSavesDirectory @ %name @ ".txt";
	
	%fileObject = new fileObject();
	%fileObject.openForWrite(%file);
	%fileObject.writeLine("��������");

	for(%a=0;%a<WrenchEvents_Box.getCount();%a++)
	{
		%swatch = WrenchEvents_Box.getObject(%a);

		if(isObject(getTargetFromEventSwatch(%swatch)))
		{

		%input = getInputFromEventSwatch(%swatch).getValue();
		%target = getTargetFromEventSwatch(%swatch).getValue();
		%delay = getDelayFromEventSwatch(%swatch).getValue();
		if(%target $= "<NAMED BRICK>")
		{
			%brick = getBrickFromEventSwatch(%swatch).getValue();
			%output = getOutputFromEventSwatch(%swatch).getValue();

			%use = false;
			$tempArgs = 0;
			for(%b=0;%b<%swatch.getCount();%b++)
			{
				if(!%use)
				{
					if(%swatch.getObject(%b) == getOutputFromEventSwatch(%swatch))
						%use = true;
				}
				else
				{
					%form = %swatch.getObject(%b);
					if(%form.getClassName() $= "GuiBitmapButtonCtrl")
					{

					}
					else if(%form.profile $= "GuiPopUpMenuProfile")
					{
						$tempArg[$tempArgs] = %form.getSelected();
						$tempArgs++;
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
					{
						$tempArg[$tempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
						$tempArgs++;
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
					{
						$tempArg[$tempArgs] = 	%form.value;
						$tempArgs++;
					}
					else
					{
						$tempArg[$tempArgs] = %form.getValue();
						$tempArgs++;
					}
				}
			}
	
			%outStr = %input TAB %target TAB %brick TAB %output TAB %delay;
			for(%c=0;%c<$tempArgs;%c++)
				%outStr = %outStr TAB $tempArg[%c];
			%fileObject.writeLine(%outStr);
		}
		else
		{
			%output = getOutputFromEventSwatch(%swatch).getValue();
			
			%use = false;
			$tempArgs = 0;
			for(%b=0;%b<%swatch.getCount();%b++)
			{
				if(!%use)
				{
					if(%swatch.getObject(%b) == getOutputFromEventSwatch(%swatch))
						%use = true;
				}
				else
				{
					%form = %swatch.getObject(%b);
					if(%form.getClassName() $= "GuiBitmapButtonCtrl")
					{

					}
					else if(%form.profile $= "GuiPopUpMenuProfile")
					{
						$tempArg[$tempArgs] = %form.getSelected();
						$tempArgs++;
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 3)
					{
						$tempArg[$tempArgs] = %form.getObject(0).getValue() SPC %form.getObject(1).getValue() SPC %form.getObject(2).getValue();
						$tempArgs++;
					}
					else if(%form.getClassName() $= "GuiSwatchCtrl" && %form.getCount() == 1)
					{
						$tempArg[$tempArgs] = 	%form.value;
						$tempArgs++;
					}
					else
					{
						$tempArg[$tempArgs] = %form.getValue();
						$tempArgs++;
					}
				}
			}
	
			%outStr = %input TAB %target TAB %output TAB %delay;
			for(%c=0;%c<$tempArgs;%c++)
				%outStr = %outStr TAB $tempArg[%c];
			%fileObject.writeLine(%outStr);
		}
		
		}
	}

	%fileObject.close();

	eventSavesList.clear();
	while((%file = findNextFile($eventSavesDirectory @ "*")) !$= "")
		eventSavesList.addRow(%inc++,%file);
}

function eventSavingDlg::onWake(%this,%that)
{
	eventSavesList.clear();
	while((%file = findNextFile($eventSavesDirectory @ "*")) !$= "")
		eventSavesList.addRow(%inc++,%file);
}
