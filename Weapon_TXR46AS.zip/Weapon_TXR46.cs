//TXR-46 Auto Shotgun -- By Takato14

/////////
//Audio//
/////////

datablock AudioProfile(TXRFireSound)
{
	filename = "./Shotty_Fire.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(TXRReloadSound)
{
	filename = "./Drum_Rotate.wav";
	description = AudioClose3d;
	preload = true;
};

//////////////////////////
//Particles and Emitters//
//////////////////////////

//Muzzle Smoke

datablock ParticleData(TXRSmokeParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 425;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.7";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.05;
	sizes[1]      = 0.25;

	useInvAlpha = false;
};
datablock ParticleEmitterData(TXRSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TXRSmokeParticle";
};

//Explosion

datablock ParticleData(TXRExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.6 0.9";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(TXRExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 30;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TXRExplosionParticle";
};

/////////////
//Explosion//
/////////////

datablock ExplosionData(TXRExplosion)
{
   //explosionShape = "";
   soundProfile = "BulletHitSound";

   lifeTimeMS = 150;

   particleEmitter = TXRExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 0;
   lightStartColor = "1 1 1";
   lightEndColor = "0 0 0";

   uiName = "TXR-46";

   };

//CI

AddDamageType("TXR",   '<bitmap:add-ons/Weapon_TXR46AS/CI_TXR> %1',    '%2 <bitmap:add-ons/Weapon_TXR46AS/CI_TXR> %1',0.5,1);

//////////////
//Projectile//
//////////////

datablock ProjectileData(TXRProjectile)
{
   projectileShapeName = "./Bullet.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::TXR;
   radiusDamageType    = $DamageType::TXR;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 15;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 20;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 4;
   verticalImpulse	  = 3;
   explosion           = TXRExplosion;
   //particleEmitter     = "";

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

    armingDelay         = 00;
   lifetime            = 30000;
   fadeDelay           = 29500;
   bounceElasticity    = 0.99;
   bounceFriction      = 0.00;
   isBallistic         = false;
   gravityMod          = 1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "TXR-46";
};

/////////////////////
//Projectile Casing//
/////////////////////

datablock DebrisData(TXRShellDebris)
{
	shapeFile = "./ShotShell.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};


//////////
// item //
//////////

datablock ItemData(TXRItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./TXR.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "TXR-46";
	iconName = "./Icon_TXR";
	doColorShift = false;
	colorShiftColor = (180/255) SPC (180/255) SPC (180/255) SPC (255/255);

	 // Dynamic properties defined by the scripts
	image = TXRImage;
	canDrop = true;


};


////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(TXRImage)
{
   // Basic Item properties
   shapeFile = "./TXR.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.0 1.0 -0.85"
   rotation = ""; //eulerToMatrix( "0 0 0" )

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = TXRProjectile;
   projectileType = Projectile;

	casing = TXRShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   LarmReady = true;

   doColorShift = true;
   colorShiftColor = TXRItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]					= weaponSwitchSound;
	
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]				= "ready";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Reload";
	stateTimeoutValue[3]            = 0.3;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	//stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]			= true;
	stateEmitter[3]					= gunFlashEmitter;
	stateEmitterTime[3]				= 0.01;
	stateEmitterNode[3]				= "muzzleNode";
	stateSound[3]					= TXRFireSound;
	//stateEjectShell[3]       		= false;

	stateName[4] 					= "Reload";
	stateEmitter[4]					= TXRSmokeEmitter;
	stateEmitterTime[4]				= 0.05;
	stateEmitterNode[4]				= "muzzleNode";
	stateSound[4]					= TXRReloadSound;
	stateTimeoutValue[4]            = 0.15;
	stateTransitionOnTimeout[4]     = "Ready";
	stateSequence[4]				= "DrumRotate";
	stateEjectShell[4]       		= true;

	
};

/////////////
//Functions//
/////////////

//Bullet Spread

function TXRImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, plant);
	%projectile = %this.projectile;
	%spread = 0.0041;
	%shellcount = 10;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

