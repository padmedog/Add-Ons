exec("./Jeepserver_MainMenuGui.gui");
if (!$TestGuiBindings)
{
   $remapDivision[$remapCount] = "Jeep Server";
   $remapName[$remapCount] = "Main Menu";
   $remapCmd[$remapCount] = "openJSMainMenu";
   $remapCount++;
   $Jeepserver_MainMenuGui=true;
}

