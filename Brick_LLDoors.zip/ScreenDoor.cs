datablock fxDTSBrickData ( brickScreenDoorOpenCWData )
{
	brickFile = "./ScreenDooropenCW.blb";
	uiName = "Screen Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickScreenDoorCWData";
	openCW = "brickScreenDoorOpenCWData";
	
	closedCCW = "brickScreenDoorCWData";
	openCCW = "brickScreenDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickScreenDoorOpenCCWData : brickScreenDoorOpenCWData )
{
	brickFile = "./ScreenDooropenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickScreenDoorCWData : brickScreenDoorOpenCWData )
{
	brickFile = "./ScreenDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/ScreenDoor";
	
	isOpen = 0;
};