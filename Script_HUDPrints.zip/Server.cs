// Title: Server.cs
// Author: Boom (9740)
// Executes Scripts

exec("./Scripts/Prefs.cs"); //Configures Preferences for this Add-On
exec("./Scripts/Server Commands.cs"); //Creates Functions to Modify Preferences without RTB
exec("./Scripts/HUD Prints.cs"); //Schedules the HUD and parses Formatting
exec("./Scripts/Package.cs"); //Creates and Activates Package for this Add-On