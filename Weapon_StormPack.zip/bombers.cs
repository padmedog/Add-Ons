datablock StaticShapeData(StormBomberBlueShape)
{
	shapeFile = "./BomberBlueBullet.dts";
};

datablock fxLightData(StormBomberBlueLight)
{
	lightRadius = 50;
	brightness  = 2;
	color  = "0.157 0.44 1 1";
	flareOn			= false;

	uiName = "Storm Light - Blue";
};

datablock ParticleData(StormBomberBlueExplosionParticle)
{
	dragCoefficient		= 1;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 1010;
	lifetimeVarianceMS	= 400;
	textureName			 = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;

	colors[0]	  = "0.157 0.44 1 0.9";
	colors[1]	  = "0.157 0.44 1 0.8";
	colors[2]	  = "0.157 0.44 1 0.6";
	colors[3]	  = "0.157 0.44 1 0.4";

	sizes[0]		= 3.0;
	sizes[1]		= 4.0;
	sizes[2]		= 2.0;
	sizes[3]		= 3.5;

	times[0] = 0.0;
	times[1] = 0.3;
	times[2] = 0.6;
	times[3] = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(StormBomberBlueExplosionEmitter)
{
	ejectionPeriodMS = 3;
	periodVarianceMS = 0;
	ejectionVelocity = 5;
	velocityVariance = 1.0;
	ejectionOffset	= 3.0;
	thetaMin			= 0;
	thetaMax			= 40;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "StormBomberBlueExplosionParticle";

	uiName = "Storm Bomber Explosion - Blue";
};

datablock ParticleData(StormBomberBlueExplosionDotParticle)
{
	dragCoefficient		= 4;
	gravityCoefficient	= -0.0;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 500;
	lifetimeVarianceMS	= 100;
	textureName			 = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	  = "0.157 0.44 1 0.9";
	colors[1]	  = "0.157 0.44 1 0.8";
	colors[2]	  = "0.157 0.44 1 0.6";
	colors[3]	  = "0.157 0.44 1 0.4";

	sizes[0]		= 1.0;
	sizes[1]		= 1.5;
	sizes[2]		= 1.75;
	sizes[3]		= 1.25;

	times[0] = 0.0;
	times[1] = 0.3;
	times[2] = 0.6;
	times[3] = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(StormBomberBlueExplosionDotEmitter)
{
	lifeTimeMS = 100;

	ejectionPeriodMS = 1;
	periodVarianceMS = 0;
	ejectionVelocity = 20;
	velocityVariance = 10.0;
	ejectionOffset	= 0.0;
	thetaMin			= 0;
	thetaMax			= 180;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "StormBomberBlueExplosionDotParticle";

		uiName = "Storm Bomber Explosion Dot - Blue";
};

datablock ParticleData(StormBomberBlueExplosionRingParticle)
{
	dragCoefficient		= 4;
	gravityCoefficient	= -0.0;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 500;
	lifetimeVarianceMS	= 100;
	textureName			 = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	  = "0.157 0.44 1 0.9";
	colors[1]	  = "0.157 0.44 1 0.8";
	colors[2]	  = "0.157 0.44 1 0.6";
	colors[3]	  = "0.157 0.44 1 0.4";

	sizes[0]		= 1.0;
	sizes[1]		= 1.5;
	sizes[2]		= 2.0;
	sizes[3]		= 2.5;

	times[0] = 0.0;
	times[1] = 0.3;
	times[2] = 0.6;
	times[3] = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(StormBomberBlueExplosionRingEmitter)
{
	lifeTimeMS = 100;

	ejectionPeriodMS = 1;
	periodVarianceMS = 0;
	ejectionVelocity = 20;
	velocityVariance = 10.0;
	ejectionOffset	= 0.0;
	thetaMin			= 80;
	thetaMax			= 90;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "StormBomberBlueExplosionRingParticle";

		uiName = "Storm Bomber Explosion Ring - Blue";
};

datablock ParticleData(StormBomberBlueExplosionChunkParticle)
{
	dragCoefficient		= 2;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 500;
	lifetimeVarianceMS	= 400;
	textureName			 = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	colors[0]	  = "0.157 0.44 1 0.9";
	colors[1]	  = "0.157 0.44 1 0.8";
	colors[2]	  = "0.157 0.44 1 0.6";
	colors[3]	  = "0.157 0.44 1 0.4";
	sizes[0]		= 1.5;
	sizes[1]		= 2.0;
	sizes[2]		= 2.5;
	sizes[3]		= 3.0;
	times[0] = 0.0;
	times[1] = 0.5;
	times[2] = 1.0;
	times[3] = 1.5;

	useInvAlpha = false;
};

datablock ParticleEmitterData(StormBomberBlueExplosionChunkEmitter)
{
	lifeTimeMS = 100;

	ejectionPeriodMS = 1;
	periodVarianceMS = 0;
	ejectionVelocity = 10;
	velocityVariance = 5.0;
	ejectionOffset	= 1.0;
	thetaMin			= 0;
	thetaMax			= 180;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "StormBomberBlueExplosionChunkParticle";

	uiName = "Storm Bomber Explosion Chunk - Blue";
};

datablock ExplosionData(StormBomberBlueExplosion)
{
	explosionShape = "";
	soundProfile = StormBomberExplosionSound;

	lifeTimeMS = 600;

	particleEmitter = StormBomberBlueExplosionEmitter;
	particleDensity = 10;
	particleRadius = 0.5;

	emitter[0] = StormBomberBlueExplosionChunkEmitter;
	emitter[1] = StormBomberBlueExplosionRingEmitter;
	emitter[2] = StormBomberBlueExplosionDotEmitter;

	//subExplosion[0] = "";
	//subExplosion[1] = StormBomberBlueSubExplosion1;

	faceViewer	  = true;
	explosionScale = "0.4 0.4 0.4";

	shakeCamera = false;
	camShakeFreq = "10.0 11.0 10.0";
	camShakeAmp = "3.0 10.0 3.0";
	camShakeDuration = 0.5;
	camShakeRadius = 20.0;

	// Dynamic light
	lightStartRadius = 15;
	lightEndRadius = 20;
	lightStartColor = "0.157 0.44 1 1";
	lightEndColor = "0.157 0.44 1 0";

	damageRadius = 8;
	radiusDamage = 50;

	impulseRadius = 10;
	impulseForce = 4000;

	playerBurnTime = 3000;
};

datablock ProjectileData(StormBomberBlueStuckProjectile)
{
	explosion			 	  = StormBomberBlueExplosion;
	directDamage		  = 100;
	lifeTime = 100;
};

datablock ProjectileData(StormBomberBlueProjectile)
{
	projectileShapeName = "./BomberBlueBullet.dts";
	directDamage		  = 35;
	directDamageType	 = $DamageType::StormBomber;
	radiusDamageType	 = $DamageType::StormBomber;
	impactImpulse		 	= 800;
	verticalImpulse	  	= 800;
	explosion			 	  = "";//StormBomberBlueExplosion;
	//particleEmitter	 	  = StormBomberBlueTrailEmitter;

	brickExplosionRadius = 2;
	brickExplosionImpact = false;			 //destroy a brick if we hit it directly?
	brickExplosionForce  = 10;
	brickExplosionMaxVolume = 10;			 //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground  

	muzzleVelocity		= 120;
	velInheritFactor	 = 1;

	armingDelay			= 0;
	lifetime				= 2000;
	fadeDelay			  = 6000;
	bounceElasticity	 = 0.5;
	bounceFriction		= 0.20;
	isBallistic			= true;
	gravityMod = 0;
	ProjectileScale = "1 1 1";

	hasLight	 = true;
	lightRadius = 20;
	lightColor  = "0.157 0.44 1 1";
	
	//ui name removed
};

//////////
// item //
//////////

datablock ItemData(StormBomberBlueItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./StormBomber.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Storm Bomber - Blue";
	iconName = "./icon_StormBomber";

	doColorShift = true;

	colorShiftColor = "0.157 0.44 1 1";

	 // Dynamic properties defined by the scripts
	image = StormBomberBlueImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBomberBlueImage)
{
	// Basic Item properties
	shapeFile = "./StormBomber.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	// When firing from a point offset from the eye, muzzle correction
	// will adjust the muzzle vector to point to the eye LOS point.
	// Since this weapon doesn't actually fire from the muzzle point,
	// we need to turn this off.  
	correctMuzzleVector = true;

	// Add the WeaponImage namespace as a parent, WeaponImage namespace
	// provides some hooks into the inventory system.
	className = "WeaponImage";

	// Projectile && Ammo.
	item = StormBomberBlueItem;
	ammo = " ";
	projectile = StormBomberBlueProjectile;
	projectileType = Projectile;

	//casing = StormBomberBlueShellDebris;
	//shellExitDir		  = "1.0 -1.3 1.0";
	//shellExitOffset	  = "0 0 0";
	//shellExitVariance	= 15.0;	
	//shellVelocity		 = 7.0;

	//melee particles shoot from eye node for consistancy
	melee = false;
	//raise your arm up or not
	armReady = true;
	minShotTime = 200;
	doColorShift = true;
	colorShiftColor = StormBomberBlueItem.colorShiftColor;

	//casing = "";

	// Images have a state system which controls how the animations
	// are run, which sounds are played, script callbacks, etc. This
	// state system is downloaded to the client so that clients can
	// predict state changes and animate accordingly.  The following
	// system supports basic ready->fire->reload transitions as
	// well as a no-ammo->dryfire idle state.

	// Initial start up state
	stateName[0]					 = "Activate";
	stateTimeoutValue[0]			 = 1;
	stateTransitionOnTimeout[0]		 = "Ready";
	stateSound[0] 					 = StormEquipSound;

	stateName[1]					 = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]		 = true;
	stateSequence[1]				 = "Ready";

	stateName[2]					 = "Fire";
	stateTransitionOnTimeout[2]	     = "Smoke";
	stateTimeoutValue[2]			 = 0.14;
	stateFire[2]					 = true;
	stateAllowImageChange[2]		 = false;
	stateSequence[2]				 = "Fire";
	stateScript[2]					 = "onFire";
	stateWaitForTimeout[2]			 = true;
	stateEmitterTime[2]				 = 0.05;
	stateEmitterNode[2]				 = "muzzleNode";
	//stateSound[2]					 = StormBomberShotSound;
	stateEjectShell[2]			 	 = false;

	stateName[3] = "Smoke";
	stateEmitterTime[3]				 = 0.2;
	stateEmitterNode[3]				 = "muzzleNode";
	stateTransitionOnTimeout[3]	     = "Reload";

	stateName[4]					 = "Reload";
	stateSequence[4]				 = "Reload";
	stateTransitionOnTriggerUp[4]	 = "Ready";
	stateSequence[4]				 = "Ready";
};

function StormBomberBlueImage::onFire(%this, %obj, %slot)
{
	if (!isObject(%bomb = %obj.stormBomb))
	{
		if ($Sim::Time - %obj.lastBomberShotTime >= 2)
		{
			ServerPlay3d(StormBomberShotSound, %obj.getPosition());

			%p = new Projectile()
			{
				dataBlock       = StormBomberBlueProjectile;
				initialPosition = %obj.getMuzzlePoint(0);
				initialVelocity = vectorScale(%obj.getMuzzleVector(0), 30);
				sourceObject    = %obj;
				client          = %client;
				sourceSlot      = 0;
				originPoint     = %obj.getMuzzlePoint(0);
				type 			= "Blue";
			};
			MissionCleanup.add(%p);
			%obj.stormBomb = %p;

			schedule(1900, 0, SpawnBomberExplosion, %p, "Blue");
			%p.schedule(1900, delete);

			%obj.lastBomberShotTime = $Sim::Time;
		}
	}
	else
	{
		SpawnBomberExplosion(%bomb, "Blue");
		%obj.stormBomb = "";
	}
}

function StormBomberBlueProjectile::onCollision(%this, %obj, %col, %fade, %pos, %normal)
{
	if (isObject(%source = %obj.sourceObject) && isObject(%source) && %source.getMountedImage(0) == StormBomberBlueImage.getId() &&
		%col.getClassName() !$= "Player" && %col.getClassName() !$= "AiPlayer" && 
		%col.getClassName() !$= "Vehicle" && %col.getClassName() !$= "WheeledVehicle")
	{
		%light = new fxLight()
		{
			dataBlock = StormBomberBlueLight;
			position = vectorAdd(%pos, "0 0 0.3");
		};
		MissionCleanup.add(%light);

		%p = new StaticShape()
		{
			dataBlock = StormBomberBlueShape;
			position = %pos;
			type = "Blue";
			objectAttachedTo = %col;
			client = %source.client;
			light = %light;
		};
		MissionCleanup.add(%p);

		if (%col.stormBombCount $= "")
			%col.stormBombCount = 0;

		%col.attachedStormBomb[%col.stormBombCount] = %p;
		%col.stormBombCount++;

		if (isObject(%source))
			%source.stormBomb = %p;

		%obj.delete();
	}
	else
	{
		%p = new Projectile()
		{
			dataBlock = StormBomberBlueStuckProjectile;
			initialPosition = %pos;
			client = %source.client;
			sourceObject = %source.client;
		};
		MissionCleanup.add(%p);
		%p.explode();
	}
}

function StormBomberBlueImage::onUnmount(%this, %obj, %slot)
{
	if (isObject(%bomb = %obj.stormBomb))
	{
		SpawnBomberExplosion(%bomb, "Blue");
		%obj.stormBomb = "";
	}
}

function SpawnBomberExplosion(%obj, %type)
{
	if (!isObject(%obj))
		return;

	%p = new Projectile()
	{
		dataBlock = "StormBomber" @ %type @ "StuckProjectile";
		initialPosition = %obj.getPosition();
		client = %obj.sourceObject.client;
		sourceObject = %obj.client;
	};
	MissionCleanup.add(%p);
	%p.explode();

	%light = %obj.light;

	if (isObject(%light))
		%light.delete();

	if (isObject(%obj))
		%obj.delete();
}


package Weapon_StormPack_bombers
{
	function GameConnection::instantRespawn(%this)
	{
		if (isObject(%player = %this.player))
		{
			if (isObject(%bomb = %player.stormBomb))
			{
				SpawnBomberExplosion(%bomb, %bomb.type);
				%bomb.delete();
				%player.stormBomb = "";
			}
		}
		Parent::spawnPlayer(%this, %spawn);
	}

	function GameConnection::onDeath(%this, %obj, %killer, %type, %area)
	{
		if (isObject(%player = %this.player))
		{
			if (isObject(%bomb = %player.stormBomb))
			{
				SpawnBomberExplosion(%bomb, %bomb.type);
				%player.stormBomb = "";
			}
		}
		Parent::onDeath(%this, %obj, %killer, %type, %area);
	}

	function Armor::onRemove(%this, %obj)
	{
		//if (isObject(%player = %this.player))
		//{
			if (isObject(%bomb = %obj.stormBomb))
			{
				SpawnBomberExplosion(%bomb, %bomb.type);
				%obj.stormBomb = "";
			}
		//}
		Parent::onRemove(%this, %obj);
	}

	function fxDTSBrick::onBotDeath(%obj)
	{
		%bot = %obj.hBot;

		if (isObject(%bot))
		{
			if (isObject(%bomb = %bot.stormBomb))
			{
				if(!(%bomb.getType() & $TypeMasks::ProjectileObjectType))
				{
					SpawnBomberExplosion(%obj, %bomb.type);
				}
			}
		}
		Parent::onBotDeath(%obj);
	}

	function fxDTSBrick::onDeath(%obj)
	{
		Parent::onDeath(%obj);

		if (%obj.stormBombCount > 0)
		{
			for (%i = 0; %i < %obj.stormBombCount; %i++)
			{
				%client = %obj.attachedStormBomb[%i].client;
				%bomb = %obj.attachedStormBomb[%i];

				SpawnBomberExplosion(%bomb, %bomb.type);
			}
		}
	}

	function fxDTSBrick::onRemove(%obj)
	{
		Parent::onRemove(%obj);

		if (isObject(%obj.stormBombCount > 0))
		{
			for (%i = 0; %i < %obj.stormBombCount; %i++)
			{
				%client = %obj.attachedStormBomb[%i].client;
				%bomb = %obj.attachedStormBomb[%i];

				SpawnBomberExplosion(%bomb, %bomb.type);
			}
		}
	}
};
activatePackage(Weapon_StormPack_bombers);

exec("./bomber_red.cs");
exec("./bomber_green.cs");
exec("./bomber_yellow.cs");