datablock fxDTSBrickData (brickLamppost_LightData)
{
	brickfile = "./LAmppostlight.blb";
	category = "Special";
	subcategory = "Home-Made";
	uiname = "Lamppost";
	iconName = "Add-ons/Brick_Lamppostlight/Lamppostimg";
};