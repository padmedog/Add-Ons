// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+


//TO-DO
// - Slayer_PathHandlerSG::findPath needs to check if all nodes in existing path are in LOS


//Creates the node sets.
function Slayer_PathHandlerSG::onAdd(%this)
{
	%this.nodes = new simSet();
	%this.add(%this.nodes);

	%this.rallyNodes = new simSet();
	%this.add(%this.rallyNodes);

	%this.paths = new simSet();
	%this.add(%this.paths);
}

//Adds a node to the node network.
//@param	object obj	The object to add. obj.position must be defined.
function Slayer_PathHandlerSG::addNode(%this,%obj)
{
	if(%this.nodes.isMember(%obj))
		return;

	if(%obj.position $= "")
	{
		Slayer_Support::Error("Slayer_PathHandlerSG::addNode","obj.position must be defined!");
		return;
	}

	%this.nodes.add(%obj);

	%obj.linkCount = 0;
	%this.findLinks(%obj,true);

	if(!isObject(%obj.nodeTrigger))
		%obj.nodeTrigger = %obj.createTrigger(Slayer_NodeTriggerData);

	//Rally Nodes
	if(%obj.getDatablock().isRallyNode)
	{
		if(!%this.rallyNodes.isMember(%obj))
			%this.rallyNodes.add(%obj);
	}
}

//Removes a node from the node network.
//@param	object obj	The node to remove.
function Slayer_PathHandlerSG::removeNode(%this,%obj)
{
	%this.destroyAllLinks(%obj);
	if(isObject(%obj.nodeTrigger))
		%obj.nodeTrigger.delete();
	if(%this.nodes.isMember(%obj))
		%this.nodes.remove(%obj);
	if(%this.rallyNodes.isMember(%obj))
		%this.rallyNodes.remove(%obj);
}

//Destroys the node graph and then recalculates all links.
function Slayer_PathHandlerSG::rebuildNodeGraph(%this)
{
	for(%i = 0; %i < %this.nodes.getCount(); %i ++)
		%this.destroyAllLinks(%this.nodes.getObject(%i));
	for(%i = 0; %i < %this.nodes.getCount(); %i ++)
		%this.findLinks(%this.nodes.getObject(%i),true);
}

//Searches for nodes that are visible to the specified node and links them.
//@param	object obj	The node to find links to.
//@see	Slayer_PathHandlerSG::setLink
function Slayer_PathHandlerSG::findLinks(%this,%obj,%avoidCliffs)
{
	%nodeCount = %this.nodes.getCount();
	for(%i = 0; %i < %nodeCount; %i ++)
	{
		%node = %this.nodes.getObject(%i);

		if(%node == %obj)
			continue;

		%pos = vectorAdd(%obj.position,"0 0 1");
		if(%this.checkPathClear(%pos,%node))
		{
			//basic cliff detection
			if(%avoidCliffs && %obj.getName() !$= "_ignore_cliff")
			{
				if(%this.checkCliffBlocking(%obj.position,%node.position,"",8))
					continue;
			}
			%this.setLink(%obj,%node);
		}
	}
}

//Links two nodes to each other.
//@param	object objA	The first of the two nodes.
//@param	object objB	The second of the two nodes.
//@see Slayer_PathHandlerSG::findLinks
function Slayer_PathHandlerSG::setLink(%this,%objA,%objB)
{
	if(!%this.nodes.isMember(%objA) || !%this.nodes.isMember(%objB))
	{
		Slayer_Support::Error("Slayer_PathHandlerSG::setLink","Node not in set.");
		return;
	}

	if(%objA == %objB)
	{
		Slayer_Support::Error("Slayer_PathHandlerSG::setLink","Cannot link to self.");
		return;
	}

	if(!%objA.linkedTo[%objB])
	{
		%objA.linkedTo[%objB] = true;
		%objA.link[%objA.linkCount] = %objB;
		%objA.linkCount ++;
	}

	if(!%objB.linkedTo[%objA])
	{
		%this.setLink(%objB,%objA);
	}
}

//Destroys the link between two nodes.
//@param	object objA	The first of the two nodes.
//@param	object objB	The second of the two nodes.
//@see Slayer_PathHandlerSG::findLinks
//@see Slayer_PathHandlerSG::setLink
function Slayer_PathHandlerSG::destroyLink(%this,%objA,%objB)
{
	if(%objA.linkedTo[%objB])
	{
		%index = -1;
		for(%i = 0; %i < %objA.linkCount; %i ++)
		{
			if(%objA.link[%i] == %objB)
			{
				%index = %i;
				break;
			}
		}
		if(%index >= 0)	
		{
			for(%i = %index + 1; %i < %objA.linkCount; %i ++)
				%objA.link[%i - 1] = %objA.link[%i];

			%objA.link[%objA.linkCount - 1] = "";
			%objA.linkCount --;
		}

		%objA.linkedTo[%objB] = "";
	}

	if(%objB.linkedTo[%objA])
	{
		%this.destroyLink(%objB,%objA);
	}
}

//Removes all links to/from an object.
//@param	object obj	The object to remove all links from.
function Slayer_PathHandlerSG::destroyAllLinks(%this,%obj)
{
	for(%i = %this.nodes.getCount() - 1; %i >= 0; %i --)
		%this.destroyLink(%obj,%this.nodes.getObject(%i));
}

//Finds the nearest node to a position.
//@param	point3F position	The 3D cartesian coordinate to search around.
//@param	bool visible	Determines if only visible nodes are checked.
//@return	object	The closest node that was found.
function Slayer_PathHandlerSG::findClosestNode(%this,%position,%visible)
{
	%best = 999999;
	%bestNode = 0;

	%count = %this.nodes.getCount();
	for(%i = 0; %i < %count; %i ++)
	{
		%node = %this.nodes.getObject(%i);

		if(%visible && !%this.checkPathClear(%position,%node))
			continue;

		%distance = vectorDist(%position,%node.position);

		if(%distance < %best)
		{
			%best = %distance;
			%bestNode = %node;
		}
	}

	return %bestNode;
}

//Checks whether a drop-off is located between two points.
//@param	point3F posA	The starting point.
//@param	point3F posB	The ending point.
//@param	float intervalFraction	A cliff detection will be performed every fraction of the way between the points.
//@param	float maxCliffHeight	The maximum height that is not blocking.
//@param	string groundType	A typemask for the ground.
//@param	object excludeObj	An object to exclude from raycast checks.
//@return	bool	True if a drop-off is located between the points, otherwise false.
function Slayer_PathHandlerSG::checkCliffBlocking(%this,%posA,%posB,%intervalFraction,%maxCliffHeight,%groundType,%excludeObj)
{
	if(%intervalFraction $= "")
		%intervalFraction = 0.1;
	if(%maxCliffHeight $= "")
		%maxCliffHeight = 10;
	if(%groundType $= "")
		%groundType = $TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType;

	for(%i = %intervalFraction; %i < 1; %i += %intervalFraction)
	{
		%posC = vectorAdd(%posA,vectorScale(vectorNormalize(vectorSub(%posB,%posA)),vectorDist(%posA,%posB) * %i));
		%posD = vectorSub(%posC,"0 0" SPC %maxCliffHeight);
		%hit = containerRayCast(%posC,%posD,%groundType,%excludeObj);
		if(!isObject(firstWord(%hit)))
		{
			return true;
		}
	}

	return false;
}

//Checks whether there is a clear path to a node from a specified position. 
//A "clear path" means that there are no bricks between the position and the node 
//with rendering or collision enabled.
//@param	point3F position	The starting position.
//@param	object node	Check if this node is in the line-of-sight from %position.
//@return	bool	A boolean determining if the node is visible.
function Slayer_PathHandlerSG::checkPathClear(%this,%position,%node)
{
	%raycast = containerRayCast(%position,%node.position,$TypeMasks::fxBrickAlwaysObjectType);
	%obj = firstWord(%raycast);

	while(isObject(%obj) && %obj != %node && !%obj.isColliding() && !%obj.isRendering())
	{
		%pos = getWords(%raycast,1,4);
		%raycast = containerRayCast(%pos,%node.position,$TypeMasks::fxBrickAlwaysObjectType,%obj);
		%obj = firstWord(%raycast);
	}

	return (%obj == %node);
}

//Finds a path between two nodes.
//@param	string callback	Function called when the path is completed. (onMyPathCompleted(%path,%result))
//@param	string heuristic	The name of a function that returns the heuristic. Default: "euclideanPathCost"
//@param	string finder	The name of the finder class. Default: "AStarFinder"
//@return	object	The path object.
//@see	calculatePath
function Slayer_PathHandlerSG::findPath(%this,%nodeA,%nodeB,%callback,%heuristic,%finder)
{
	if(!%this.nodes.isMember(%nodeA) || !%this.nodes.isMember(%nodeB))
		return;

	//Let's see if we have a path already.
	%pathCount = %this.paths.getCount();
	for(%i = 0; %i < %pathCount; %i ++)
	{
		%p = %this.paths.getObject(%i);
		if(%p.a == %nodeA && %p.b == %nodeB)
		{
			%path = %p;
			break;
		}
	}

	if(isObject(%path))
	{
		if(%path.done)
		{
			if(%path.result $= "")
			{
				//This is a broken path.
				%path.delete();
			}
			else
			{
				%count = getWordCount(%path.result);
				for(%i = 0; %i < %count; %i ++)
				{
					%obj = getWord(%path.result,%i);
					if(!isObject(%obj))
					{
						//This is a broken path.
						%path.delete();
						break;
					}
				}
			}
		}
	}

	if(!isObject(%path))
	{
		%path = calculatePath(%nodeA,%nodeB,%callback,%heuristic,%finder);
		%this.paths.add(%path);
	}

	if(%path.done)
	{
		scheduleNoQuota(0,0,"call",%callback,%path,%path.result);
	}

	return %path;
}

if(!isObject(Slayer.PathHandler))
{
	Slayer.PathHandler = new scriptGroup(Slayer_PathHandlerSG);
	Slayer.add(Slayer.PathHandler);
}