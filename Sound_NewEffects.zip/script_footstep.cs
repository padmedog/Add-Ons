//footsteps.cs
//by munk

datablock AudioProfile(foot_boot1)
{
	fileName = "./sounds/sn_walk_conc_4.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_boot2)
{
	fileName = "./sounds/sn_walk_conc_3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_boot3)
{
	fileName = "./sounds/sn_walk_conc_2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_boot4)
{
	fileName = "./sounds/sn_walk_conc_1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_quiet1)
{
	fileName = "./sounds/walkQuiet1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_quiet2)
{
	fileName = "./sounds/walkQuiet2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_quiet3)
{
	fileName = "./sounds/walkQuiet3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(foot_quiet4)
{
	fileName = "./sounds/walkQuiet4.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(jet_start)
{
	fileName = "./sounds/jet_start.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(jet_idle)
{
	fileName = "./sounds/jet_loop.wav";
	description = AudioClosest3d;
	preload = false;
};

$footsteps = 1;

package footstep
{
	function gameConnection::spawnPlayer(%this)
	{
		parent::spawnPlayer(%this);
		%this.player.footLoop();
	}

	function player::footLoop(%this)
	{
		//echo("FOOTLOOP WOOOOO!@#@#$@#4");
		if($footsteps)
		{
			%pos = getWords(%this.getPosition(), 0, 1);
			if(%this.f_lastPos $= getWords(%this.getPosition(), 0, 1) || %this.crouch || !%this.isOnGround())
			{
				//echo("same position");
				//do nothing!
			}
			else if(!%this.isMounted())
			{
				//echo("diff position");
				if(makePositive(getWord(%this.getVelocity(),0)) < 3 && makePositive(getWord(%this.getVelocity(),1)) < 3)
				{
					%this.playFootStep(1);
				}
				else
				{
					%this.playFootStep(2);
				}

				%this.f_lastPos = getWords(%this.getPosition(), 0, 1);
			}
			//echo("@#@#$@#%@#$@#$NUMBER 2");
			%this.schedule(320, footloop);

			//windNoiseLoop(%this);
		}
	}

	function player::playFootStep(%this,%type)
	{
		%random = getRandom(0, 3);
		if(%type == 1)
		{
			%sound = "foot_quiet" @ (%random + 1);
		}
		else
		{
			%sound = "foot_boot" @ (%random + 1);
		}
 
		serverplay3d(%sound,%this.getHackPosition() SPC "0 0 1 0");
	}

	function Armor::onTrigger(%datablock,%player,%slot,%val)
	{
		Parent::onTrigger(%datablock,%player,%slot,%val);
		switch(%slot)
		{
			case 0:
				%player.fire = %val;
			case 2:
				%player.jump = %val;
			case 3:
				%player.crouch = %val;
			case 4:
				%player.jet = %val;
		}

		if(%slot == 4 && %datablock.canJet)
		{
			if(%val)
			{
				if(%player.jetStart)
				{
					%player.jetStart = 0;
					%sound = "jet_start";
					//serverPlay3d(%sound, %player.getHackPosition() SPC "0 0 1 0");
					idleJetLoop(%player);
				}
			}
			else if(%val == 0)
			{
				cancel(%player.idleJetLoop);
				%player.jetStart = 1;
				%player.playAudio(3,jet_start);
				//serverPlay3d("jet_idle", %player.getHackPosition() SPC "0 0 1 0");
			}
		}
	}

	function idleJetLoop(%player)
	{
		cancel(%player.idleJetLoop);
		if(%player.jet)
		{
			%sound = "jet_idle";
			%player.playAudio(3,jet_idle);
			%player.idleJetLoop = schedule(5000, 0, idleJetLoop, %player);
		}
	}


	//From AGILE Player
	function Player::IsOnGround(%player)
	{
		%pos = %player.getPosition();
		%scale = %player.getScale();
		%xs = getWord(%scale,0);
		%ys = getWord(%scale,1);
		
		%nw = vectorAdd(%pos,0 - (0.75 * %xs) SPC 0 - (0.75 * %ys) SPC 0);
		%dnw = vectorAdd(%nw,"0 0 -0.5");
		%ne = vectorAdd(%pos,(0.75 * %xs) SPC 0 - (0.75 * %ys) SPC 0);
		%dne = vectorAdd(%ne,"0 0 -0.5");
		%se = vectorAdd(%pos,(0.75 * %xs) SPC (0.75 * %ys) SPC 0);
		%dse = vectorAdd(%se,"0 0 -0.5");
		%sw = vectorAdd(%pos,0 - (0.75 * %xs) SPC (0.75 * %ys) SPC 0);
		%dsw = vectorAdd(%sw,"0 0 -0.5");
		%dpos = vectorAdd(%pos,"0 0 -0.5");

		%raynw = ag_bicheck(getWord(containerRaycast(%nw,%dnw,$TypeMasks::FxBrickAlwaysObjectType|$TypeMasks::InteriorObjectType),0));
		%rayne = ag_bicheck(getWord(containerRaycast(%ne,%dne,$TypeMasks::FxBrickAlwaysObjectType|$TypeMasks::InteriorObjectType),0));
		%rayse = ag_bicheck(getWord(containerRaycast(%se,%dse,$TypeMasks::FxBrickAlwaysObjectType|$TypeMasks::InteriorObjectType),0));
		%raysw = ag_bicheck(getWord(containerRaycast(%sw,%dsw,$TypeMasks::FxBrickAlwaysObjectType|$TypeMasks::InteriorObjectType),0));
		%rayce = ag_bicheck(getWord(containerRaycast(%pos,%dpos,$TypeMasks::FxBrickAlwaysObjectType|$TypeMasks::InteriorObjectType),0));

		if(%raynw || %rayne || %rayse || %raysw || %rayce)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function ag_bicheck(%obj)
	{
		if(!isObject(%obj))
		{
			return 0;
		}
		if(%obj.getClassName() $= "fxDTSbrick")
		{
			if(%obj.isColliding() && %obj.isRendering())
			{
				return 1;
			}
			return 0;
		}
		return 1;
	}
};
activatepackage(footstep);

function makePositive(%num)
{
	if(%num < 0)
	{
		return %num * -1;
	}
	else
	{
		return %num;
	}
}