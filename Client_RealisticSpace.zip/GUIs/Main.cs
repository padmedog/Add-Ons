$RSC::Revision += 1;

if(isObject(RSClientGUI))
	RSClientGUI.delete();
new GuiControl(RSClientGUI)
{
	visible = 0;
	
	new GuiWindowCtrl(RSClientWindow)
	{
		position = "250 100";
		extent = "224 88";
		
		closeCommand = "Canvas.popDialog(RSClientGUI);";
		command = "Canvas.popDialog(RSClientGUI);";
		accelerator = "Escape";
		
		text = "Realistic Space Menu";
		
		canMinimize = 0;
		canMaximize = 0;
		resizeHeight = 0;
		resizeWidth = 0;
		
		new GuiTextCtrl()
		{
			position = "10 36";
			extent = "50 20";
			
			text = "Filter Tag:";
		};
		
		new GuiTextEditCtrl(RSC_TagFilterBox)
		{
			position = "60 36";
			extent = "100 20";
			
			command = "RSC_UpdateTagFiltered();";
		};
		
		new GuiPopupMenuCtrl(RSC_TagFilterAction)
		{
			position = "164 36";
			extent = "50 20";
			
			command = "RSC_UpdateTagFiltering();";
		};
		
		new GuiTextCtrl()
		{
			position = "10 56";
			extent = "50 20";
			
			text = "Transponder:";
		};
		
		new GuiBitmapButtonCtrl(RSC_SilentModeButton)
		{
			position = "78 57";
			extent = "34 14";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/"@($Pref::RSClient::SilentMode ? "OFF" : "ON");
			mColor = ($Pref::RSClient::SilentMode ? "255 0 0 255" : "0 255 0 255");
			command = "RSC_SilentModeButton.toggleSilentMode();"; text = "";
		};
	};
};

RSC_TagFilterAction.add("Parse", 0);
RSC_TagFilterAction.add("Show", 1);
RSC_TagFilterAction.add("Remove", 2);

function RSC_SilentModeButton::toggleSilentMode(%this)
{
	$Pref::RSClient::SilentMode = !$Pref::RSClient::SilentMode;
	%this.setColor($Pref::RSClient::SilentMode ? "1 0 0 1" : "0 1 0 1");
	%this.setBitmap("Add-Ons/Client_RealisticSpace/GUIs/"@($Pref::RSClient::SilentMode ? "OFF" : "ON"));
}

function RSC_UpdateTagFiltered()
{ RSC_TagFilterAction.setSelected(2 - $Pref::RSClient::AllowTag_[RSC_TagFilterBox.getValue()]); }

function RSC_UpdateTagFiltering()
{
	%filter = 2 - RSC_TagFilterAction.getSelected();
	%value = RSC_TagFilterBox.getValue();
	if(%filter || $Pref::RSClient::AllowTag_[%value])
		$Pref::RSClient::AllowTag_[%value] = %filter;
}

function toggleRSClientGUI(%tog)
{
	if(%tog)
		if(RSClientGUI.visible)
			Canvas.popDialog(RSClientGUI);
		else
			Canvas.pushDialog(RSClientGUI);
}

if(!$RealisticSpaceClientBound)
{
	$remapName[$remapCount++] = "Toggle Realistic Space GUI";
	$remapCmd[$remapCount] = "toggleRSClientGUI";
}

exec("./Fabricator GUI.cs");
exec("./RSC HUD.cs");