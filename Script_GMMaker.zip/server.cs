//+=========================================================================================================+\\
//|			Made by..																						|\\
//|		   ____   ____  _ 				 __ 		 _ 														|\\
//|		  |_  _| |_  _|(_)              [  |        / |														|\\
//|		    \ \   / /  __   .--.   .--.  | |  ,--. `| |-' .--.   _ .--.										|\\
//|			 \ \ / /  [  | ( (`\]/ .'`\ \| | `'_\ : | | / .'`\ \[ `/'`\]									|\\
//|			  \ ' /    | |  `'.'.| \__. || | // | |,| |,| \__. | | |										|\\
//|			   \_/    [___][\__) )'.__.'[___]\'-;__/\__/ '.__.' [___]										|\\
//|								BL_ID: 20490																|\\
//|				Forum Profile: http://forum.blockland.us/index.php?action=profile;u=40877;                  |\\
//|																											|\\
//+=========================================================================================================+\\

function serverCmdGMMGui(%this)
{
	if(%this.getBLID() != getNumKeyID())
	{
		if($Pref::Server::AllowGamemodesForSAs)
		{
			if(!%this.isSuperAdmin)
				return;
		}
		else
			return;
	}

	commandToClient(%this, 'OpenGMM');
}

function serverCmdGMM_RequestFiles(%this)
{
	if(%this.getBLID() != getNumKeyID())
	{
		if($Pref::Server::AllowGamemodesForSAs)
		{
			if(!%this.isSuperAdmin)
				return;
		}
		else
			return;
	}

	%filePath = "add-ons/*/server.cs";
	for(%file = findFirstFile(%filePath); %file !$= ""; %file = findNextFile(%filePath))
	{
		%fileP = filePath(%file);
		%fileP = strReplace(%fileP, "Add-Ons/", "");
		if(isFile(%file))
			commandToClient(%this, 'GMM_addFile', %fileP);
	}
}

function serverCmdGMM_SetToAddOnList(%this)
{
	if(%this.getBLID() != getNumKeyID())
	{
		if($Pref::Server::AllowGamemodesForSAs)
		{
			if(!%this.isSuperAdmin)
				return;
		}
		else
			return;
	}

	serverCmdGMM_RequestFiles(%this);
	%filePath = "config/server/ADD_ON_LIST.cs";
	if(!isFile(%filePath))
		return;

	%file = new FileObject();
	%file.openForRead(%filePath);
	while(!%file.isEOF())
	{
		%line = %file.readLine();
		//echo(%line);
		%addOn = strReplace(%line, " = 1;", "");
		%addOn = strReplace(%addOn, "$AddOn__", "");
		if(strPos(%line, " = 1;") >= 0)
		{
			//echo("Adding " @ %addOn);
			if(isFile("add-ons/" @ %addon @ "/server.cs"))
				commandToClient(%this, 'GMM_addModeFile', %addOn);
		}
	}
	%file.close();
	%file.delete();
}

function serverCmdGMM_ResetLines(%this)
{
	if(%this.getBLID() != getNumKeyID())
	{
		if($Pref::Server::AllowGamemodesForSAs)
		{
			if(!%this.isSuperAdmin)
				return;
		}
		else
			return;
	}

	%this.chatMessage("Line upload reset for Gamemode.txt and Description.txt");
	%this.lineUpload_Gamemode = "";
	%this.lineUpload_Description = "";
}

function serverCmdGMM_AddLine(%this, %line, %type)
{
	if(%this.getBLID() != getNumKeyID())
	{
		if($Pref::Server::AllowGamemodesForSAs)
		{
			if(!%this.isSuperAdmin)
				return;
		}
		else
			return;
	}

	if(%type $= "Description")
		%this.lineUpload_Description = %this.lineUpload_Description NL %line;
	else if(%type $= "Gamemode")
		%this.lineUpload_Gamemode = %this.lineUpload_Gamemode NL %line;
}

function serverCmdGMM_CreateGamemode(%this, %name)
{
	if(%this.getBLID() != getNumKeyID())
	{
		if($Pref::Server::AllowGamemodesForSAs)
		{
			if(!%this.isSuperAdmin)
				return;
		}
		else
			return;
	}
	%this.chatMessage("\c6Creating gamemode: " @ %name @ " (" @ getLineCount(%this.lineUpload_Gamemode) @ " Lines)");

	%file = "add-ons/" @ %name @ "/";

	%file0 = new FileObject();
	%file0.openForWrite(%file @ "description.txt");
	for(%i=0;%i<getLineCount(%this.lineUpload_Description);%i++)
		%file0.writeLine(getLine(%this.lineUpload_Description, %i));
	%file0.close();
	%file0.delete();

	%file1 = new FileObject();
	%file1.openForWrite(%file @ "gamemode.txt");
	for(%a=0;%a<getLineCount(%this.lineUpload_Gamemode);%a++)
		%file1.writeLine(getLine(%this.lineUpload_Gamemode, %a));
	%file1.close();
	%file1.delete();
}