$GravityTurismoTypemasks=$typemasks::fxbrickobjecttype | $typemasks::interiorobjecttype | $typemasks::terrainobjecttype | $typemasks::StaticObjectType;

datablock wheeledvehicledata(GravityTurismoVehicle : TurismoVehicle){
 cameraRoll=true;
 cameramaxdist=8;
 cameraoffset=0;
 uiname="Gravity Turismo";
};

function GravityTurismoVehicle::onadd(%this,%obj){
 %obj.isshiftinggravity=1;
 %obj.grav="0 0 -0.5";
 shiftgravitycheck(%obj);
 parent::onadd(%this,%obj);
}

function shiftgravitycheck(%obj){
 if(!%obj.isshiftinggravity)
  return;
 %pos=%obj.getposition();
 %ray=containerraycast(%pos,vectoradd(%pos,vectorscale(%obj.getupvector(),"-4 -4 -4")),$GravityTurismoTypemasks,%obj);
 %normal=getwords(%ray,4,6);
 if(%normal!$="")
  %obj.grav=vectorscale(%normal,"-0.5 -0.5 -0.5");
 %obj.setvelocity(vectoradd(%obj.getvelocity(),vectoradd("0 0 0.5",%obj.grav)));
 schedule(25,0,shiftgravitycheck,%obj);
}