%error = ForceRequiredAddOn("Player_Tactical");if(%error == $Error::AddOn_NotFound)return;
function TacticalPlayer_HeartBeat(%Obj,%Type) { return; }
function Player::TacticalRepair(%obj) { return; }
DeActivatePackage(Tactical_Player);

package HeatMod_Overwrites
{
	function TacticalPlayer::onDamage(%this,%obj,%am)
	{
		parent::onDamage(%this,%obj,%am);
		
		if(%am > 0 && $TACPLAYER::Healable)
		{
			if(isEventPending(%obj.Tac_Repair))
			cancel(%obj.Tac_Repair);
				
			if(%obj.getState() !$= "Dead")
			%obj.Tac_Repair = %obj.schedule($TacPlayer::HealDelay,TacticalRepair);
		}
		if(%Obj.GetDamageLevel() >= 80)
		{
			%Obj.SetDataBlock("TacticalPlayerLow");
			TacticalPlayer_HeartBeat(%Obj,1);
			return;
		}
		if(%Obj.GetDamageLevel() >= 60)
		{
			%Obj.SetDataBlock("TacticalPlayerMed");
			TacticalPlayer_HeartBeat(%Obj,0);
			return;
		}
	}
	function TacticalPlayerMed::OnDamage(%This,%Obj,%Am)
	{
		parent::OnDamage(%This,%Obj,%Am);
		if(%Obj.GetDamageLevel() <= 60)
		{
			%Obj.SetDataBlock("TacticalPlayer");
			return;
		}
		if(%Obj.GetDamageLevel() >= 80)
		{
			%Obj.SetDataBlock("TacticalPlayerLow");
			TacticalPlayer_HeartBeat(%Obj.client,1);
			return;
		}
	}
	function TacticalPlayerLow::OnDamage(%This,%Obj,%Am)
	{
		parent::OnDamage(%This,%Obj,%Am);
		if(%Obj.GetDamageLevel() <= 60)
		{
			%Obj.SetDataBlock("TacticalPlayer");
			return;
		}
		if(%Obj.GetDamageLevel() <= 80)
		{
			%Obj.SetDataBlock("TacticalPlayerMed");
			TacticalPlayer_HeartBeat(%Obj,0);
			return;
		}
	}
	function TacticalPlayerCrippled::OnDamage(%This,%Obj,%Am)
	{
		if(%Obj.GetDamageLevel() <= 50)
		{
			%Obj.SetDataBlock("TacticalPlayerCrippledHealed");
			%obj.setCrippledMsg=0;
			TacticalPlayer_HeartBeat(%Obj,0);
			return;
		}
	}
	function TacticalPlayerCrippledHealed::OnDamage(%This,%Obj,%Am)
	{
		if(%Obj.GetDamageLevel() <= 20)
		{
			%obj.setCrippledMsg=0;
			%Obj.SetDataBlock("TacticalPlayer");
			return;
		}
	}
//---------------------------
// HeartBeat
//---------------------------
	function TacticalPlayer_HeartBeat(%Obj,%Type)
	{
		cancel(%Obj.Tac_HeartBeatSchedule);
		if(isObject(%Obj.player))
		%Obj=%Obj.Player;
		if(!isobject(%obj))
		return;
		if(%obj.getstate() $= "Dead")
		return;
		
		if(%obj.getdamagelevel() <= %obj.client.heatHealthLost-%obj.getDatablock().maxDamage)
		return;
		
		if(%obj.getdatablock().getname() $= "TacticalPlayerLow" || %obj.getdatablock().getname() $= "TacticalPlayerMed" || %obj.getdatablock().getname() $= "TacticalPlayerCrippled" || %obj.getdatablock().getname() $= "TacticalPlayerCrippledHealed")
		{
			%Client = %Obj.Client;

			if(%obj.getdatablock().getname() $= "TacticalPlayerMed" || %obj.getdatablock().getname() $= "TacticalPlayerCrippledHealed")
			{
				if(%Client.heatHealthLost < 60)
				{
					commandToClient( %Client,'SetVignette',false,"1 0 0" SPC 0.5);
					%Client.Play2d(Tactical_HeartBeatFaintSound);
					%Obj.setdamageflash(0.2);
				}
				%Obj.Tac_HeartBeatSchedule = schedule(750,0,TacticalPlayer_HeartBeat,%Obj,%Am);
				TacticalPlayer_HeartBeatFade(%Obj.client,0.5);
			}
			if(%obj.getdatablock().getname() $= "TacticalPlayerLow" || %obj.getdatablock().getname() $= "TacticalPlayerCrippled")
			{
				if(%Client.heatHealthLost < 60)
				{
					commandToClient( %Client,'SetVignette',false,"1 0 0" SPC 1);
					%Client.Play2d(Tactical_HeartBeatSound);
				}
				if(%Obj.GetDamageLevel() >= 90)
				{
					if(%obj.setCrippledMsg > 0)
					{
						%obj.setCrippledMsg--;
						centerPrint(%Client,"<br><br><br><br>\c6Your legs have been crippled<br>\c0Seek cover!", 1);
					} else {
						if($TACPLAYER::Healable)
							if(%Client.bodyTemp > 20 && %client.heatHealthLost < 1)
							{
								centerPrint(%Client,"<br><br><br><br><br>\c0You are injured seek cover!", 1);							
							}
						if(!$TACPLAYER::Healable)
						centerPrint(%Client,"<br><br><br><br><br>\c0You are injured!", 1);
					}

					if(%Client.heatHealthLost < 60)
					%Obj.setdamageflash(0.6);
				}
				if(%Obj.GetDamageLevel()+%client.heatHealthLost >= 80 && %Client.bodyTemp < 20 && %client.heatHealthLost > 5)
				{
					centerPrint(%Client,"<br><br><br><br><br>\c0You are freezing find some place to warm up!", 1);
				}
				if(%Obj.GetDamageLevel() < 89)
				{
					%obj.setCrippledMsg=0;
					if(%Client.heatHealthLost < 60)
					%Obj.setdamageflash(0.3);
				}

				%Obj.Tac_HeartBeatSchedule = schedule(600,0,TacticalPlayer_HeartBeat,%Obj,%Am);
				TacticalPlayer_HeartBeatFade(%Obj.client,1);
			}
		}
	}
	function TacticalPlayer_HeartBeatFade(%Client,%Am,%Val)
	{
		cancel(Tac_HeartFadeSchedule);
		
		if(%Am < 0)
		{
			commandToClient(%Client,'SetVignette',$EnvGuiServer::VignetteMultiply,$EnvGuiServer::VignetteColor);
			return;
		}
		if(%Client.heatHealthLost > 60)
		{
			commandToClient( %Client,'SetVignette',false,"1 1 1" SPC %Am);
		} else {
			commandToClient( %Client,'SetVignette',false,"1 0 0" SPC %Am);
		}
		%Client.Tac_HeartFadeSchedule = schedule(50,0,"TacticalPlayer_HeartBeatFade",%Client,%Am-0.1);
		

	}
//---------------------------
// Fall Damage
//---------------------------
	function TacticalPlayer::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
	{
		if(%damageType == $DamageType::Fall || %damageType == $DamageType::Impact)
		{
			if(%obj.getDatablock().maxDamage - %obj.getDamageLevel() > %damage/$TacPlayer::FallDamageDampener + 0.2)
			{
				%obj.addhealth(-%damage/$TacPlayer::FallDamageDampener + 0.2);
				%p = new Projectile()
       				{
            				datablock = TacticalProjectile;
            				scale = "1 1 1";
            				initialVelocity = "0 0 0";
            				initialPosition = %obj.position;
            				sourceObject = %obj;
            				sourceSlot = 0;
            				client = %obj.client;
         			};
				if($TacPlayer::FallDamageDampener == 3)
				{
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 30)
				%boost = 5;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 40)
				%boost = 10;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 50)
				%boost = 15;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 60)
				%boost = 20;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 70)
				%boost = 25;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 80)
				%boost = 30;
					%Obj.addvelocity("0 0" SPC %boost);
				}
				if(!$TACPLAYER::CrippledLegs)
				{
					return parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType);
				}
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 0)
				%crippleamt = 10;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 60)
				%crippleamt = 6;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 70)
				%crippleamt = 4;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 80)
				%crippleamt = 2;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 90)
				%crippleamt = 1;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 95)
				%crippleamt = 0;

				%random = getrandom(0,%crippleamt);

				switch(%random)
				{
					case 0:
					%obj.sethealth(1);
					%obj.setCrippledMsg = 10;
					centerPrint(%Obj.Client,"");
					%obj.setdatablock("TacticalPlayerCrippled");
					return;
				}

				return;
			} else {
				return parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType);
			}
		} else {
			return parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType);
		}
	}
//---------------------------
// Healing
//---------------------------
	function Player::TacticalRepair(%obj)
	{
		if(%obj.getdamagelevel() > 0)
        {
				if(%obj.getdamagelevel() <= %obj.client.heatHealthLost)
				return;
				
        		%obj.addhealth(1);
        		%obj.Tac_Repair = %obj.schedule($TacPlayer::HealSpeed+%obj.getDamageLevel(),TacticalRepair);
	  	}
	}
};
ActivatePackage(HeatMod_Overwrites);