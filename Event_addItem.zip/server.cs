//Finds any item by its name
//%val will reset the count by any means
function findItemByName(%item, %val)
{
	if(isObject(%item)) return %item.getName();
	if($lastDatablockCount != DatablockGroup.getCount() || %val) //We don't need to cause lag everytime we try to find an item
	{
		//talk("findItemByName - Resetting cached tables"); - Debug stuff
		$itemTableLookUp_Count = 0;
		for(%i = 0; %i < DatablockGroup.getCount(); %i++)
		{
			%obj = DatablockGroup.getObject(%i);
			if(%obj.getClassName() $= "ItemData" && strLen(%obj.uiName) > 0)
			{
				$itemTableLookup[$itemTableLookUp_Count] = %obj;
				$itemTableLookUp_Count++;
			}
		}
		//talk("findItemByName - Cached tables set to " @ $itemTableLookUp_Count); - Debug stuff
	}
	for(%a = 0; %a < $itemTableLookUp_Count; %a++)
	{
		%objA = $itemTableLookup[%a];
		if(%objA.getClassName() $= "ItemData")
			if(strPos(%objA.uiName, %item) >= 0)
				return %objA.getName();
	}
	$lastDatablockCount = DatablockGroup.getCount();
	return -1;
}

function Player::addItem(%player, %item) //Replace the old event - Some mods might be using this if using other mods
{
	%player.addNewItem(%item);
}

//Finds an item and ueses the item, can be searched for or use the ID of it
//Example: %player.addNewItem("Hammer"); or %player.addNewItem(HammerItem);
//It doesn't have to be fully spelled, but if you may have to spell it better if there is more than one of the related item
function Player::addNewItem(%player, %item)
{
	if(!isObject(%player))
		return false; //No.

	%client = %player.client;
	if(isObject(%item))
	{
		if(%item.getClassName() !$= "ItemData") return false; //Someone is a little weird..
		%item = %item.getName();
	}
	else
		%item = findItemByName(%item);

	if(!isObject(%item)) //Don't keep going if the item doesn't even exist
		return false;

	%itemID = nameToID(%item);
	for(%i = 0; %i < %player.getDatablock().maxTools; %i++)
	{
		%tool = %player.tool[%i];
		if(!isObject(%tool))
			%ye = true;
		else if(%tool.getClassName() !$= "ItemData") //If we assume it exists, let's check if it has a different classname
			%ye = true;

		if(%ye)
		{
			%player.tool[%i] = %itemID;
			%player.weaponCount++;
			messageClient(%client,'MsgItemPickup', '', %i, %itemID);
			return true; //Let's not use break
		}
	}
	return false; //We didn't find a slot :(
}
registerOutputEvent("Player","addNewItem","string 50 50");