//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_Disabled)
{
 
   GunItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   
   error("ERROR: Weapon_Pistols - required add-on Weapon_Gun not found");
}
else
{
   exec("./Weapon_G18.cs");
   exec("./Weapon_G17.cs"); 
   exec("./Weapon_M9.cs"); 
   exec("./Weapon_M93.cs"); 
   exec("./Weapon_M1911.cs"); 
}