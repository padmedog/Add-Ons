function servercmdgetIP(%client,%target)
{
	%target = findclientbyname(%target);
	if(!isObject(%target))
	{
		messageclient(%client,'',"No user by that name!");
		return;
	}
	messageclient(%client,'',%target.name SPC %target.getRawIP());
}

function servercmdgetPING(%client,%target)
{
	%target = findclientbyname(%target);
	if(!isObject(%target))
	{
		messageclient(%client,'',"No user by that name!");
		return;
	}
	messageclient(%client,'',%target.name SPC %target.getPing());
}
