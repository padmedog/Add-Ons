exec("./eksi.cs");
exec("./fleksi.cs");
exec("./eksiH.cs");
exec("./fleksiH.cs");