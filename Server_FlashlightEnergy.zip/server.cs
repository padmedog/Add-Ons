//Flashlight Energy
//By Daenth
//Credit to Clockturn for the LoopHandler script.

//--Miscellaneous--
//Preferences
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs")) {
	if(!$RTB::Hooks::ServerControl)
		exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");
	RTB_registerPref("Enabled","Flashlight Energy","$FLEnergy::Status","bool","Server_FlashlightEnergy","1",0,0,"updateFlStatus");
	RTB_registerPref("Starting Energy","Flashlight Energy","$FLEnergy::StartingEnergy","int 0 100","Server_FlashlightEnergy","100",0,0);
	RTB_registerPref("Regeneration Speed","Flashlight Energy","$FLEnergy::RegenSpeed","int 0 60000","Server_FlashlightEnergy","1000",0,0,"updateFlProperties");
	RTB_registerPref("Drain Speed","Flashlight Energy","$FLEnergy::DrainSpeed","int 1 60000","Server_FlashlightEnergy","1000",0,0,"updateFlProperties");
}
else {
	$FLEnergy::Status = 1;
	$FLEnergy::StartingEnergy = 100;
	$FLEnergy::RegenSpeed = 1000;
	$FLEnergy::DrainSpeed = 1000;
}

//RTB Update Functions
function updateFlStatus() {
	if(!$FLEnergy::Status && isObject(flashlightEnergy))
			flashlightEnergy.delete();
	else if(!isObject(flashlightEnergy)) {
		new ScriptObject(flashlightEnergy) {
			class = "LoopHandler";
		};
	}
	%clnum = ClientGroup.getCount();
	for(%i=0;%i<%clnum;%i++) {
		%cl = ClientGroup.getObject(%i);
		if($FLEnergy::Status) {
			messageClient(%cl,'',"Flashlight Energy has been enabled!");
			if(isObject(%cl.player))
				%cl.player.setupflEnergy();
		}
		else {
			messageClient(%cl,'',"Flashlight Energy has been disabled!");
			if(isObject(%cl.player)) {
				%cl.player.flEnergy = "";
				commandToClient(%cl,'ClearCenterPrint');
			}
		}
	}
}

function updateFlProperties() {
	if($FLEnergy::Status) {
		%clnum = ClientGroup.getCount();
		for(%i=0;%i<%clnum;%i++) {
			%cl = ClientGroup.getObject(%i);
			if(isObject(%cl.player))
				%cl.player.setupflEnergy(1);
		}
	}
}

//Executing LoopHandler.cs
exec("./LoopHandler.cs");

if($FLEnergy::Status) {
	new ScriptObject(flashlightEnergy) {
		class = "LoopHandler";
	};
}

//changeflEnergy Event
registerOutputEvent(Player,changeflEnergy,"list Set 0 Add 1 \tint -200 200 0",0);

function Player::changeflEnergy(%this,%type,%val) {
	if(!$FLEnergy::Status)
		return;
	if(!%type)
		%this.flEnergy = %val;
	else
		%this.flEnergy += %val;
	if(%this.flEnergy < 0)
		%this.flEnergy = 0;
	if(%this.flEnergy > 200)
		%this.flEnergy = 200;
	if(%this.flEnergy == 0 && isObject(%this.light))
		serverCmdLight(%this.client);
}

//--Main Code--
package flashlightEnergyPackage {
	function VCE_initServer() {
		Parent::VCE_initServer();
		registerSpecialVar(Player,"flEnergy","%this.flEnergy");
	}

	function GameConnection::spawnPlayer(%this) {
		Parent::spawnPlayer(%this);
		if($FLEnergy::Status)
			%this.player.setupflEnergy();
	}

	function Player::Kill(%this) {
		//The kill message overrides the center print.
		Parent::Kill(%this);
		if($FLEnergy::Status) {
			flashlightEnergy.cancelEvent("drain" @ %this);
			if(flashlightEnergy.hasLoop["regen" @ %this])
				flashlightEnergy.cancelEvent("regen" @ %this);
		}
	}

	function serverCmdlight(%cl) {
		%pl = %cl.player;
		if(!$FLEnergy::Status || !isObject(%pl)) {
			Parent::serverCmdlight(%cl);
			return;
		}
		//Add something here to accommodate the light trigger limit. Delay: 215ms
		if(isObject(%pl.light)) {
			commandToClient(%cl,'ClearCenterPrint');
			//This is necessary due to a weird bug related to the LoopHandler script.
			flashlightEnergy.schedule(1,pause,"drain" @ %pl);
			if(flashlightEnergy.hasLoop["regen" @ %pl])
				flashlightEnergy.unpause("regen" @ %pl);
			//This function has a time limit so this is needed to circumvent it.
			if(getSimTime() - %pl.lastLightTime < 215) {
				%pl.light.delete();
				ServerPlay3D(lightOnSound,%pl.getPosition());
			}
			else
				Parent::serverCmdlight(%cl);
		}
		else {
			if(getSimTime() - %pl.lastLightTime < 215)
				return Parent::serverCmdlight(%cl);
			if(%pl.flEnergy < 1)
				commandToClient(%cl,'CenterPrint',"Your light does not have enough energy to run!",1);
			else {
				commandToClient(%cl,'CenterPrint',"<just:left>\c3Light Energy:\c6" SPC %pl.flEnergy @ "%",-1);
				flashlightEnergy.unpause("drain" @ %pl);
				if(flashlightEnergy.hasLoop["regen" @ %pl])
					flashlightEnergy.pause("regen" @ %pl);
				Parent::serverCmdlight(%cl);
			}
		}
	}
};
activatePackage(flashlightEnergyPackage);

function Player::setupflEnergy(%this,%val) {
	if(flashlightEnergy.hasLoop["drain" @ %this])
		flashlightEnergy.cancelEvent("drain" @ %this);
	if(flashlightEnergy.hasLoop["regen" @ %this])
		flashlightEnergy.cancelEvent("regen" @ %this);
	flashlightEnergy.addEvent("drain" @ %this,"flEnergyDrain",$FLEnergy::DrainSpeed);
	flashlightEnergy.loopMemory["drain" @ %this].player = %this;
	if($FLEnergy::RegenSpeed != 0) {
		flashlightEnergy.addEvent("regen" @ %this,"flEnergyRegen",$FLEnergy::RegenSpeed);
		flashlightEnergy.loopMemory["regen" @ %this].player = %this;
	}
	if(!%val)
		%this.flEnergy = $FLEnergy::StartingEnergy;
	if(isObject(%this.light)) {
		if(%this.flEnergy < 1) {
			serverCmdlight(%this.client);
			flashlightEnergy.pause("drain" @ %this);
		}
		else {
			if(flashlightEnergy.hasLoop["regen" @ %this])
				flashlightEnergy.pause("regen" @ %this);
			commandToClient(%this.client,'CenterPrint',"<just:left>\c3Light Energy:\c6" SPC %this.flEnergy @ "%",-1);
		}
	}
	else
		flashlightEnergy.pause("drain" @ %this);
}

function flEnergyDrain(%memory) {
	%pl = %memory.player;
	%pl.flEnergy -= 1;
	if(%pl.flEnergy < 0)
		%pl.flEnergy = 0;
	if(%pl.flEnergy == 0)
		serverCmdlight(%pl.client);
	else
		commandToClient(%pl.client,'CenterPrint',"<just:left>\c3Light Energy:\c6" SPC %pl.flEnergy @ "%",-1);
}

function flEnergyRegen(%memory) {
	%pl = %memory.player;
	if(%pl.flEnergy < 100)
		%pl.flEnergy += 1;
}