//MagicWand.cs


datablock AudioProfile(MagicWandExplosionSound)
{
   filename    = "base/data/sound/WandHit.wav";
   description = AudioClose3d;
   preload = false;
};

datablock AudioProfile(MagicWandFireSound)
{
   filename    = "./SpellFire.wav";
   description = AudioClose3d;
   preload = true;
};


//MagicWand trail
datablock ParticleData(MagicWandTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 400;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 500.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/star1";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0.8 0.8 1 0.8";
   	colors[1]     = "0.4 0.4 1 0.8";
	sizes[0]	= 0.7;
	sizes[1]	= 0.2;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(MagicWandTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 5; //0.25;
   velocityVariance = 3; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = MagicWandTrailParticle;
};

//effects
datablock ParticleData(MagicWandExplosionParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 500;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 1000.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/star1";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0.8 0.8 1 0.8";
   	colors[1]     = "0.4 0.4 1 0.8";
	sizes[0]	= 1.2;
	sizes[1]	= 0.5;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(MagicWandExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 1.0;
   ejectionOffset   = 2.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MagicWandExplosionParticle";
};

datablock ParticleData(MagicWandExplosionParticle2)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 500;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 1000.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/star1";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0.8 0.8 1 0.8";
   	colors[1]     = "0.4 0.4 1 0.8";
	sizes[0]	= 1.2;
	sizes[1]	= 0.5;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(MagicWandExplosionEmitter2)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 1.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MagicWandExplosionParticle2";
};

datablock ExplosionData(MagicWandExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = MagicWandExplosionSound;

   emitter[0] = MagicWandExplosionEmitter;
   emitter[1] = MagicWandExplosionEmitter2;
   particleDensity = 500;
   particleRadius = 5.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 4;
   lightEndRadius = 3;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 3.5;
   impulseForce = 1000;

   //radius damage
   radiusDamage        = 15;
   damageRadius        = 3.5;
};

//projectile
AddDamageType("MagicWand",  'Dispelled %1',    '%2 Dispelled %1!',1,1);
datablock ProjectileData(MagicWandProjectile)
{
   projectileShapeName = "";
   directDamage        = 15;
   directDamageType  = $DamageType::MagicWandDirect;
   radiusDamageType  = $DamageType::MagicWandRadius;
   impactImpulse	   = 500;
   verticalImpulse	   = 500;
   explosion           = MagicWandExplosion;
   particleEmitter     = MagicWandTrailEmitter;
   particleEmitter2    = MagicWandTrailEmitter2;

   brickExplosionRadius = 0;
   brickExplosionImpact = true; //destroy a brick if we hit it directly?
   brickExplosionForce  = 20;
   brickExplosionMaxVolume = 200;
   brickExplosionMaxVolumeFloating = 200;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 20000;
   fadeDelay           = 19500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0.9;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "MagicWand Cast";
};


//////////
// item //
//////////
datablock ItemData(MagicWandItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./magicwand.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Magic Wand";
	iconName = "./icon_magicwand";
	doColorShift = true;
   	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = MagicWandImage;
	canDrop = true;
};

//function MagicWand::onUse(%this,%user)
//{
//	//mount the image in the right hand slot
//	%user.mountimage(%this.image, $RightHandSlot);
//}

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MagicWandImage)
{
   // Basic Item properties
   shapeFile = "./magicwand.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = MagicWandItem;
   ammo = " ";
   projectile = MagicWandProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                   = "Activate";
	stateTimeoutValue[0]           = 0.5;
	stateTransitionOnTimeout[0]    = "Ready";
	stateSound[0]                  = weaponSwitchSound;

	stateName[1]                   = "Ready";
	stateTransitionOnTriggerDown[1]= "Fire";
	stateAllowImageChange[1]       = true;
	stateEmitter[1]                = MagicWandTrailEmitter;
	stateEmitterTime[1]            = 300;

	stateName[2]                   = "Fire";
	stateTransitionOnTimeout[2]    = "Reload";
	stateTimeoutValue[2]           = 0.3;
	stateFire[2]                   = true;
	stateAllowImageChange[2]       = false;
	stateSequence[2]               = "Fire";
	stateScript[2]                 = "onFire";
	stateWaitForTimeout[2]         = true;
	stateSound[2]                  = MagicWandFireSound;

	stateName[3]                   = "Reload";
	stateTransitionOnTriggerUp[3]  = "Ready";
};

function MagicWandImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, ShiftUp);
	Parent::onFire(%this, %obj, %slot);
}

function MagicWandImage::onFire(%this,%obj,%slot)
{
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%obj.client.player.getEyeVector(),"0")));
	%obj.playThread(2, shiftAway);

	%projectile = %this.projectile;
	%spread = 0.0001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}