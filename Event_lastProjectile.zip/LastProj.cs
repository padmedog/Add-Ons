RegisterSpecialVar(FxDtsBrick,"lastProj","%this.lastProjectile");

package lastProjectile
{
	function ProjectileData::onCollision(%this,%obj,%col,%fade,%pos,%norm)
	{
		Parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
		if(%col.getClassName() $= "fxDtsBrick")
		{
			%col.lastProjectile = %obj.getDataBlock().uiName;
		}
	}
};
activatePackage(lastProjectile);