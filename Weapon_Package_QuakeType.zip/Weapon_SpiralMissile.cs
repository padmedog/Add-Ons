//spiralMissile.cs

datablock AudioProfile(spiralMissileFireSound)
{
   filename    = "./drill_missile.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("spiralMissile",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_spiralmissile> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_spiralmissile> %1',0.05,1);
datablock ProjectileData(spiralMissileProjectile)
{
   projectileShapeName = "./drill_missile_projectile.dts";
   directDamage        = 75;
   directDamageType    = $DamageType::spiralMissile;
   radiusDamageType    = $DamageType::spiralMissile;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1200;
   verticalImpulse	  = 1000;
   explosion           = quakeRocketExplosion;
   particleEmitter     = quakeRocketTrailEmitter;

   explodeOnPlayerImpact = false;
   explodeondeath = true;

   muzzleVelocity      = 95;
   velInheritFactor    = 0;

   armingDelay         = 1000;
   lifetime            = 1000;
   fadeDelay           = 1000;
   bounceElasticity    = 0.999;
   bounceFriction      = 0.0;
   isBallistic         = false;
   gravityMod = 0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(spiralMissileItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./spiral_missile.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Spiral Missile";
	iconName = "./spiralmissile";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.62 1.000";

	 // Dynamic properties defined by the scripts
	image = spiralMissileImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(spiralMissileImage)
{
   // Basic Item properties
	shapeFile = "./spiral_missile.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = spiralMissileProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = spiralMissileItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakeRocketFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= spiralMissileFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakerocketSmokeEmitter;
	stateEmitterTime[3]				= 0.09;
	stateEmitterNode[3]				= "tailNode";
	stateTimeoutValue[3]            = 0.23;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Fire";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.01;
	stateTransitionOnTimeout[5]     = "Wait";
	stateSound[5]					= sawbladeRifleClickSound;

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.59;
	stateTransitionOnTimeout[6]     = "Ready";
};


function spiralMissileImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, shiftLeft);
	%obj.playThread(0, shiftRight);

	%projectile = spiralMissileProjectile;
	%spread = 0.0008;
	%shellcount = 1;

  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
            serverPlay3D(quakeRocketFireSound,%obj.getPosition());
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
			scale = "1 1 1";
		};
		MissionCleanup.add(%p);
	}
   //%obj.setImageTrigger(1,1);
}

function spiralMissileImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, plant);	
}

function spiralMissileProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{	
		%p=new Projectile()
		{
			datablock=sawbladeRifleSparkProjectile;
			
			initialVelocity=vectorScale(%vec,1);
			initialPosition=%obj.getPosition();
			scale = "3 3 3";
			
			client = %prj.client;
			sourceObject=%obj.sourceobject;
			sourceSlot=%obj.sourceslot;
		};
	
	Parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
}
