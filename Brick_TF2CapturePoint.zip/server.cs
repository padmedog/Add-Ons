datablock fxDTSBrickData(brickTF2CapturePointData)
{
	brickFile = expandFileName("./CapturePoint.blb");
	category = "Slayer";
	subCategory = "TF2";
	uiName = "TF2 Capture Point";
	iconName = filePath(expandFileName("./CapturePoint.png")) @ "/CapturePoint";
	collisionShapeName = "./CP.dts";

	indestructable = 1;

	isSlyrBrick = 1;
	slyrType = "CP";
	CPMaxTicks = 66;

	setOnceOnly = 1;
};