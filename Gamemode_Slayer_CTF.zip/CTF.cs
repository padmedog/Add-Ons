// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

// +----------+
// | Gamemode |
// +----------+
if(!$Slayer::Server::Dependencies::Gamemodes)
	exec("Add-ons/Gamemode_Slayer/Dependencies/Gamemodes.cs");
Slayer.Gamemodes.addMode("Capture the Flag","CTF",1,1);

if(!isObject(Slayer.CTFBricks))
{
	Slayer.CTFBricks = new simSet();
	Slayer.add(Slayer.CTFBricks);
}

if(!isObject(Slayer.CTFFlags))
{
	Slayer.CTFFlags = new simSet();
	Slayer.add(Slayer.CTFFlags);
}

$Slayer::Server::Bots::Priority["CTF_Flag"] = 500;
$Slayer::Server::Bots::Priority["CTF_Return"] = 1000;

// +-------------+
// | Preferences |
// +-------------+
if(!$Slayer::Server::Dependencies::Preferences)
	exec("Add-ons/Gamemode_Slayer/Dependencies/Preferences.cs");
Slayer.Prefs.addPref("CTF","Flag Captures to Win","%mini.CTF_flagReturnsToWin","int 0 50",0,0,1,-1,"Rules CTF Mode");
Slayer.Prefs.addPref("CTF","Flag Return Location","%mini.CTF_flagReturnOnlyAtReturnBrick","list" TAB "0 Flag Spawn or Flag Return Point" TAB "1 Flag Return Point Only",0,0,1,-1,"Rules CTF Mode");
Slayer.Prefs.addPref("CTF","Return Flag Without Own","%mini.CTF_returnWithoutOwn","bool",0,0,1,-1,"Rules CTF Mode");
Slayer.Prefs.addPref("CTF","Neutral Flags","%mini.CTF_neutralFlags","list" TAB "0 Disabled" TAB "1 Enabled" TAB "2 Enabled, Neutral Flags Only",1,0,1,-1,"Rules CTF Mode");
Slayer.Prefs.addPref("CTF","Flag Return","%mini.CTF_points_Flag","int -999 999",20,0,1,-1,"Rules CTF Points");
Slayer.Prefs.addPref("CTF","Flag Recovery","%mini.CTF_points_FlagRecovery","int -999 999",10,0,1,-1,"Rules CTF Points");
Slayer.Prefs.addPref("CTF","Flag Recovery Mode","%mini.CTF_flagRecovery","list" TAB "0 Disabled" TAB "1 Instant Recovery" TAB "2 Manual Recovery",2,0,1,-1,"Rules CTF Respawn");
Slayer.Prefs.addPref("CTF","Flag Respawn Time","%mini.CTF_flagRespawnTime","int 0 1800",10,0,1,-1,"Rules CTF Respawn");
Slayer.Prefs.addPref("CTF","Enable /dropFlag Command","%mini.CTF_manualFlagDrop","bool",1,0,1,-1,"Advanced");
Slayer.Prefs.addPref("CTF","Require Enemy Players","%mini.CTF_requireEnemyPlayers","bool",0,0,1,-1,"Rules CTF Mode");
Slayer.Prefs.addPref("CTF","Flag Type","$Slayer::Server::Preload::CTF::flagType",$flagTypeList,0,0,0,0,"Advanced","",1);
Slayer.Prefs.addNonNetworkedPref("CTF","Max Flag Colors","$Slayer::Server::Preload::CTF::maxFlagColors","int 2 64",10);

$Slayer::Server::CTF::flagModel = $Slayer::Server::Preload::CTF::flagType;

function Slayer_createCTFDBs()
{
	//FLAG SPAWN BRICK
	datablock fxDtsBrickData(brickSlyrCTFFlagData : brick2x2Data)
	{
		uiName = "Flag Spawn";
		category = $Slayer::Server::Bricks::Category;
		subCategory = $Slayer::Server::Bricks::SubCategory @ "CTF";

		indestructable = 1;

		isSlyrBrick = 1;
		slyrType = "CTF_Flag";

		setOnceOnly = 0;
	};

	//FLAG RETURN BRICK
	datablock fxDtsBrickData(brickSlyrCTFFlagReturnData : brick6x6FData)
	{
		uiName = "Flag Return Point";
		category = $Slayer::Server::Bricks::Category;
		subCategory = $Slayer::Server::Bricks::SubCategory @ "CTF";

		indestructable = 1;

		isSlyrBrick = 1;
		slyrType = "CTF_FlagReturn";
	};

	//FLAG RETURN TRIGGER
	datablock TriggerData(slyrCTF_flagReturnTriggerData)
	{
		tickPeriodMS = 150;
	};

	//FLAGS
	for(%i=0; %i < $Slayer::Server::Preload::CTF::maxFlagColors; %i++)
	{
		%color = getColorIDTable(%i);
		datablock ItemData(flagItem)
		{
			className = slyrCTF_FlagItem;

			shapeFile = $Slayer::Server::CTF::flagShapeFile[$Slayer::Server::CTF::flagModel];
			uiName = "";

			doColorShift = true;
			colorShiftColor = %color;
			colorID = %i;
		};
		flagItem.setName("slyrCTF_Flag" @ %i @ "Item");

		datablock ShapeBaseImageData(flagImage)
		{
			className = slyrCTF_FlagImage;
			// class = slyrCTF_FlagImage;

			shapeFile = $Slayer::Server::CTF::flagShapeFile[$Slayer::Server::CTF::flagModel];
			emap = true;
			mountPoint = $Slayer::Server::CTF::flagMountPoint[$Slayer::Server::CTF::flagModel];
			offset = $Slayer::Server::CTF::flagOffset[$Slayer::Server::CTF::flagModel];
			eyeOffset = "0 0 10";

			rotate = true;
			rotation = $Slayer::Server::CTF::flagRotation[$Slayer::Server::CTF::flagModel];

			armReady = false;

			doColorShift = true;
			colorShiftColor = %color;
			colorID = %i;

			hasLight = $Slayer::Server::CTF::flagHasLight[$Slayer::Server::CTF::flagModel];
			lightType = $Slayer::Server::CTF::flagLightType[$Slayer::Server::CTF::flagModel];
			lightColor = %color;
			lightTime = $Slayer::Server::CTF::flagLightTime[$Slayer::Server::CTF::flagModel];
			lightRadius = $Slayer::Server::CTF::flagLightRadius[$Slayer::Server::CTF::flagModel];

			stateName[0] = $Slayer::Server::CTF::flagStateName[0,$Slayer::Server::CTF::flagModel];
			stateTransitionOnTimeout[0] = $Slayer::Server::CTF::flagStateTransitionOnTimeout[0,$Slayer::Server::CTF::flagModel];
			stateTimeoutValue[0] = $Slayer::Server::CTF::flagStateTimeoutValue[0,$Slayer::Server::CTF::flagModel];
			stateSequence[0] = $Slayer::Server::CTF::flagStateSequence[0,$Slayer::Server::CTF::flagModel];
		};
		flagImage.setName("slyrCTF_Flag" @ %i @ "Image");
	}
}

if(!isObject(brickSlyrCTFFlagData))
	Slayer_createCTFDBs();

function Slayer_CTF_onModeStart(%mini)
{
	Slayer_CTF_resetFlags(%mini);
}

function Slayer_CTF_onModeEnd(%mini)
{
	Slayer_CTF_resetFlags(%mini,1);

	for(%i=0; %i < %mini.Teams.getCount(); %i++)
	{
		%team = %mini.Teams.getObject(%i);
		%team.CTF_numFlagReturns = "";
	}
}

function Slayer_CTF_onSlyrBrickAdd(%mini,%brick,%type)
{
	%client = %brick.getGroup().client;
	%color = %brick.getColorID();
	%db = %brick.getDatablock();

	switch$(%type)
	{
		case "CTF_Flag":
			Slayer.CTFBricks.add(%brick);

			if(!isObject(%brick.ctfTrigger))
				%brick.ctfTrigger = %brick.createTrigger(slyrCTF_flagReturnTriggerData);

			if(isSlayerMinigame(%mini))
			{
				if(%mini.mode $= "CTF")
					%brick.resetFlag();

				%teams = %mini.Teams.getTeamsFromColor(%color,"COM",1);
			}
			if(%teams !$= "")
				return "<just:center>\c5" @ %db.uiName SPC "set for" SPC %teams @ "\c5.";

		case "CTF_FlagReturn":
			Slayer.CTFBricks.add(%brick);

			if(!isObject(%brick.ctfTrigger))
				%brick.ctfTrigger = %brick.createTrigger(slyrCTF_flagReturnTriggerData);

			if(isSlayerMinigame(%mini))
			{
				%teams = %mini.Teams.getTeamsFromColor(%color,"COM",1);
			}
			if(%teams !$= "")
				return "<just:center>\c5" @ %db.uiName SPC "set for" SPC %teams @ "\c5.";
	}

	return 0;
}

function Slayer_CTF_onSlyrBrickRemove(%mini,%brick,%type)
{
	if(isObject(%brick.ctfTrigger))
		%brick.ctfTrigger.delete();
}

function Slayer_CTF_preReset(%mini,%client)
{
	Slayer_CTF_resetFlags(%mini);

	for(%i=0; %i < %mini.Teams.getCount(); %i++)
	{
		%team = %mini.Teams.getObject(%i);
		%team.CTF_numFlagReturns = "";
		%team.CTF_numFlagPickups = "";
	}
	for(%i = 0; %i < %mini.numMembers; %i ++)
	{
		%cl = %mini.member[%i];
		%cl.CTF_numFlagReturns = "";
		%cl.CTF_numFlagPickups = "";
	}
}

function Slayer_CTF_preDeath(%mini,%client,%obj,%killer,%type,%area)
{
	if(isObject(%client.player))
		%client.player.dropFlag();
}

function Slayer_CTF_onLeave(%mini,%client)
{
	if(isObject(%client.player))
		%client.player.dropFlag();
}

function Slayer_CTF_Teams_onLeave(%mini,%team,%client)
{
	if(isObject(%client.player))
		%client.player.dropFlag();
}

function Slayer_CTF_onRules(%mini,%client)
{
	if(%mini.CTF_flagReturnsToWin > 0)
	{
		%cap = (%mini.CTF_flagReturnsToWin == 1 ? "capture" : "captures");
		%flag = (%mini.CTF_flagReturnsToWin == 1 ? "flag" : "flags");
		messageClient(%client,'',"\c5 +\c3" SPC %mini.CTF_flagReturnsToWin SPC "\c5flag" SPC %cap SPC "- The first team to capture\c3" SPC %mini.CTF_flagReturnsToWin SPC "\c5" @ %flag SPC "wins.");
	}
}

function Slayer_CTF_scoreListInit(%mini,%header,%var1,%var2,%var3,%var4,%var5,%var6,%var7,%var8,%var9)
{
	%header = '<color:ffffff><tab:100,200,325,450><font:arial:16>%1<h2>%2\t%3\t%4\t%5\t%6</h2><br>';
	%var4 = "Flag Pick-ups";
	%var5 = "Flag Returns";
	return true TAB %header TAB %var1 TAB %var2 TAB %var3 TAB %var4 TAB %var5 TAB %var6;
}

function Slayer_CTF_scoreListAdd(%mini,%obj,%line,%var1,%var2,%var3,%var4,%var5,%var6,%var7,%var8,%var9)
{
	%var4 = %obj.CTF_numFlagPickups;
	%var5 = %obj.CTF_numFlagReturns;
	return true TAB %line TAB %var1 TAB %var2 TAB %var3 TAB %var4 TAB %var5 TAB %var6;
}

function Slayer_CTF_getClosestCTFColor(%rgba)
{
	%prevdist = 100000;
	%colorMatch = 0;
	for(%i=0; %i < $Slayer::Server::Preload::CTF::maxFlagColors; %i++)
	{
		%color = getColorIDTable(%i);
		if(vectorDist(%rgba,getWords(%color,0,2)) < %prevdist && getWord(%rgba,3) - getWord(%color,3) < 0.3 && getWord(%rgba,3) - getWord(%color,3) > -0.3)
		{
			%prevdist = vectorDist(%rgba,%color);
			%colormatch = %i;
		}
	}
	return %colormatch;
}

function Slayer_CTF_isBrickNeutral(%mini,%brick)
{
	%color = %brick.getColorID();
	return %mini.teams.isNeutralColor(%color);
}

function Slayer_CTF_getFlagDisplayName(%mini,%brick)
{
	%color = %brick.getColorID();
	%name = %mini.Teams.getTeamsFromColor(%color,"COM",1);

	if(%name $= "")
	{
		%brickName = trim(strReplace(%brick.getName(),"_"," "));
		%name = (%brickName $= "" ? "Neutral" : %brickName);
		%name = "<sPush><color:" @ Slayer_Support::RgbToHex(getColorIDTable(%color)) @ ">" @ %name @ "<sPop>";
	}

	return %name;
}

function Slayer_CTF_isFlagAtHome(%mini,%color)
{
	%count = Slayer.CTFBricks.getCount();
	for(%i = 0; %i < %count; %i ++)
	{
		%br = Slayer.CTFBricks.getObject(%i);
		if(minigameCanUse(%mini,%br) && %br.getDatablock().slyrType $= "CTF_Flag")
		{
			if(%br.getControl() == %color)
			{
				%item = %br.item;
				if(isObject(%item) && %item.getDatablock().className $= "slyrCTF_FlagItem")
					return 1;
				if(!%isFlagSpawn)
					%isFlagSpawn = true;
			}
		}
	}

	if(%isFlagSpawn)
		return 0;
	else
		return -1;
}

function Slayer_CTF_onFlagReturn(%mini,%client,%team,%brick,%flag)
{
	%player = %client.player;
	%points = %mini.CTF_points_Flag;
	%teamNames = Slayer_CTF_getFlagDisplayName(%mini,%player.flagSpawn);

	%client.incScore(%points);

	if(%points > 0)
		%msg = %team.getColorHex() @ %client.getPlayerName() SPC "<color:ff00ff>returned the" SPC %teamNames SPC "flag for\c3" SPC %points SPC (%points == 1 ? "\c5point." : "\c5points.");
	else
		%msg = %team.getColorHex() @ %client.getPlayerName() SPC "<color:ff00ff>returned the" SPC %teamNames SPC "flag.";
	if(%mini.CTF_flagReturnsToWin > 0)
	{
		%remain = %mini.CTF_flagReturnsToWin - %team.CTF_numFlagReturns - 1;
		if(%remain > 0)
		{
			%cap = (%remain == 1 ? "capture" : "captures");
			%msg = %msg SPC %team.getColoredName() SPC "\c5needs\c3" SPC %remain SPC "\c5flag" SPC %cap SPC "to win.";
		}
	}

	%mini.messageAll('',%msg);

	%player.flagSpawn.resetFlag();

	%player.allowFlagRemoval = 1;
	%player.unMountImage($Slayer::Server::CTF::flagImageSlot,1);
	%player.flagSpawn = "";


	%team.CTF_numFlagReturns ++;
	%client.CTF_numFlagReturns ++;
	if(%team.CTF_numFlagReturns >= %mini.CTF_flagReturnsToWin && %mini.CTF_flagReturnsToWin > 0)
		%mini.endRound(%team);
}

function Slayer_CTF_onFlagRecovery(%mini,%client,%team,%brick,%flag)
{
	%teamNames = Slayer_CTF_getFlagDisplayName(%mini,%brick);

	if(isObject(%flag))
		%flag.delete();
	%brick.resetFlag();

	%points = %mini.CTF_points_FlagRecovery;
	%client.incScore(%points);

	if(%points > 0)
		%mini.messageAll('',%team.getColorHex() @ %client.getPlayerName() SPC "<color:ff00ff>recovered the" SPC %teamNames SPC "flag for\c3" SPC %points SPC (%points == 1 ? "\c5point." : "\c5points."));
	else
		%mini.messageAll('',%team.getColorHex() @ %client.getPlayerName() SPC "<color:ff00ff>recovered the" SPC %teamNames SPC "flag.");
}

function Slayer_CTF_onFlagPickup(%mini,%client,%team,%brick,%flag)
{
	%flagDB = %flag.getDatablock();
	%player = %client.player;
	%teamNames = Slayer_CTF_getFlagDisplayName(%mini,%brick);

	cancel(%mini.CTF_flagRespawnSched[%flagDB.colorID]);

	%image = "slyrCTF_Flag" @ %flagDB.colorID @ "Image";
	%player.mountImage(%image.getID(),$Slayer::Server::CTF::flagImageSlot);
	%player.flagSpawn = %brick;

	%brick.setItem(0);

	if(isObject(%flag))
	{
		if(!%flag.dropped)
		{
			%team.CTF_numFlagPickups ++;
			%client.CTF_numFlagPickups ++;
		}

		%flag.delete();
	}

	%mini.messageAll('',%team.getColorHex() @ %client.getPlayerName() SPC "<color:ff00ff>picked up the" SPC %teamNames SPC "\c5flag.");

	if(%mini.CTF_manualFlagDrop)
		%client.bottomPrint("<just:center>\c5Type \c3/dropFlag \c5to drop the flag.",2,true);

	if(%client.isSlayerBot)
	{
	echo("yes, slayer bot");
		%count = Slayer.CTFBricks.getCount();
		for(%i = 0; %i < %count; %i ++)
		{
			%br = Slayer.CTFBricks.getObject(%i);
			%type = %br.getDatablock().slyrType;
			if((%type $= "CTF_Flag" || %type $= "CTF_FlagReturn") && minigameCanUse(%mini, %br))
			{
				if(%br.getControl() == %team.color)
				{
					echo(%client.addObjective(%br, $Slayer::Server::Bots::Priority["CTF_Return"]));
					%client.schedule(0, "goToNextObjective", true);
					break;
				}
			}
		}
	}
}

function Slayer_CTF_onFlagDrop(%mini,%client,%team,%brick,%flag)
{
	%teamNames = Slayer_CTF_getFlagDisplayName(%mini,%brick);
	%mini.messageAll('',%team.getColorHex() @ %client.getPlayerName() SPC "<color:ff00ff>dropped the" SPC %teamNames SPC "\c5flag.");
}

function Slayer_CTF_flagRespawnTick(%mini,%item,%ticks)
{
	if(!isObject(%item))
		return;

	if(!isObject(%mini))
		return;

	%brick = %item.spawnBrick;
	%color = %brick.getColorID();

	%time = %mini.CTF_flagRespawnTime;

	cancel(%mini.CTF_flagRespawnSched[%color]);

	if(%ticks >= %time)
	{
		%teamNames = Slayer_CTF_getFlagDisplayName(%mini,%brick);
		%mini.messageAll('',"<color:ff00ff>The" SPC %teamNames SPC "flag was respawned.");

		if(isObject(%item))
			%item.delete();

		%brick.resetFlag();
	}
	else
	{
		%item.setShapeNameColor(getColorIDTable(%color));
		%item.setShapeName(%time - %ticks);

		%mini.CTF_flagRespawnSched[%color] = scheduleNoQuota(1000,0,Slayer_CTF_flagRespawnTick,%mini,%item,%ticks++);
	}
}

function Slayer_CTF_resetFlags(%mini,%doNotRespawn)
{
	for(%i = Slayer.CTFFlags.getCount() - 1; %i >= 0; %i --)
	{
		%f = Slayer.CTFFlags.getObject(%i);
		if(minigameCanUse(%mini,%f))
			%f.delete();
	}

	for(%i = 0; %i < Slayer.CTFBricks.getCount(); %i ++)
	{
		%br = Slayer.CTFBricks.getObject(%i);
		if(%br.getDatablock().slyrType $= "CTF_Flag" && minigameCanUse(%mini,%br))
		{
			if(%doNotRespawn)
				%br.setItem(0);
			else
				%br.resetFlag();
		}
	}
}

function Slayer_CTF_assignBotObjectives(%mini, %ai)
{
	%team = %ai.slyrTeam;
	if(isObject(%team))
	{
		//flag spawns
		%count = Slayer.CTFBricks.getCount();
		for(%i = 0; %i < %count; %i ++)
		{
			%br = Slayer.CTFBricks.getObject(%i);
			if(%br.getDatablock().slyrType !$= "CTF_Flag" || !isObject(%br.item))
				continue;
			%blid = %br.getGroup().bl_id;
			if(%canUse[%blid] $= "")
				%canUse[%blid] = miniGameCanUse(%this, %br);
			if(%canUse[%blid])
			{
				if(%br.getControl() != %team.color)
				{
					%ai.addObjective(%br, $Slayer::Server::Bots::Priority["CTF_Flag"], "CTF_Flag");
				}
			}
		}
	}
}

function Slayer_onBotObjectiveReached_CTF_Flag(%mini, %ai, %objective)
{
	talk("BOT" SPC %ai SPC "JUST REACHED FLAG" SPC %objective);
	return -1;
}


///Methods


function fxDtsBrick::resetFlag(%this)
{
	if(%this.getDatablock().slyrType !$= "CTF_Flag")
		return;

	%color = %this.getColorID();
	%flagColor = Slayer_CTF_getClosestCTFColor(getColorIDTable(%color));

	%item = "slyrCTF_Flag" @ %flagColor @ "Item";
	%item = %item.getID();
	%item.uiName = " "; //items without a name don't spawn
	%this.setItem(%item);
	%item.uiName = "";
}

function Player::getFlagImage(%this)
{
	return %this.getMountedImage($Slayer::Server::CTF::flagImageSlot);
}

function Player::dropFlag(%this)
{
	%image = %this.getFlagImage();
	if(!isObject(%image))
		return;

	%client = %this.client;

	%mini = getMinigameFromObject(%client);
	if(!isSlayerMinigame(%mini))
		return;
	if(%mini.mode !$= "CTF")
		return;

	%team = %client.getTeam();
	if(!isObject(%team))
		return;

	%brick = %this.flagSpawn;
	if(!isObject(%brick))
		return;

	%respawn = %mini.CTF_flagRespawnTime;
	if(%respawn <= 0)
		%brick.resetFlag();
	else
	{
		%eyeVect = %this.getEyeVector();
		%pos = getWords(%this.getEyeTransform(),0,2);
		%endPos = vectorAdd(%pos,vectorScale(%eyeVect,1.1));
		%raycast = containerRayCast(%pos,%endPos,$TypeMasks::fxBrickObjectType | $TypeMasks::TerrainObjectType);

		if(!isObject(getWord(%raycast,0)))
			%pos = %endPos;

		%item = new Item()
		{
			dataBlock = "slyrCTF_Flag" @ %image.colorID @ "Item";

			spawnTime = getSimTime();

			position = %pos;
			spawnBrick = %brick;

			dropped = true;
			canPickup = true;
		};
		missionCleanup.add(%item);
		Slayer_CTF_flagRespawnTick(%mini,%item,0);

		%item.setVelocity(vectorAdd(%item.getVelocity(),vectorScale(%eyeVect,3)));
	}

	%this.allowFlagRemoval = 1;
	%this.unMountImage($Slayer::Server::CTF::flagImageSlot);
	%this.flagSpawn = "";

	Slayer_CTF_onFlagDrop(%mini,%client,%team,%brick,%item);
}

function slyrCTF_FlagItem::onAdd(%this,%obj)
{
	Slayer.CTFFlags.add(%obj);

	if($Slayer::Server::CTF::flagIdleAnimation[$Slayer::Server::CTF::flagModel] !$= "")
		%obj.playThread(0,$Slayer::Server::CTF::flagIdleAnimation[$Slayer::Server::CTF::flagModel]);

	//spinning flags
	if(!%obj.dropped && $Slayer::Server::CTF::flagRotate[$Slayer::Server::CTF::flagModel])
		%obj.rotate = 1;
}

function slyrCTF_FlagItem::onPickUp(%this,%flag,%player,%a)
{
	if(getSimTime() - %flag.spawnTime < 200)
		return;

	%client = %player.client;
	%image = %player.getMountedImage($Slayer::Server::CTF::flagImageSlot);
	%mini = getMinigameFromObject(%client);

	if(!isSlayerMinigame(%mini) || %mini.mode !$= "CTF" || %mini.isResetting())
		return;

	if(!minigameCanUse(%mini,%flag))
	{
		%client.centerPrint("That flag is not part of your minigame.",2);
		return;
	}

	%team = %client.getTeam();
	if(!isObject(%team))
		return;

	%brick = %flag.spawnBrick;
	if(!isObject(%brick))
		return;

	%teamNames = Slayer_CTF_getFlagDisplayName(%mini,%brick);

	%color = %brick.getControl();

	//TOUCHING OUR OWN FLAG
	if(%color == %team.color)
	{
		//FLAG RECOVERY
		if(%flag.dropped)
		{
			if(%mini.CTF_flagRecovery == 1)
				Slayer_CTF_onFlagRecovery(%mini,%client,%team,%brick,%flag);
			else if(%mini.CTF_flagRecovery == 2 && %image.className !$= "slyrCTF_FlagImage")
				Slayer_CTF_onFlagPickup(%mini,%client,%team,%brick,%flag);
		}
	}
	//FLAG CAPTURE
	else if(%image.className !$= "slyrCTF_FlagImage")
	{
		//LOCKED BRICK?
		if(%brick.isLocked[%team.color] && %color != %team.color)
		{
			%client.bottomPrint("<just:center>\c5This flag is locked. You cannot capture it yet.",1);
			return;
		}

		//NEUTRAL FLAG?
		%neutral = Slayer_CTF_isBrickNeutral(%mini,%brick);
		if(%neutral && %mini.CTF_neutralFlags == 0)
		{
			%client.bottomPrint("<just:center>\c5You may not pick up neutral flags.",1);
			return;
		}
		else if(!%neutral && %mini.CTF_neutralFlags == 2)
		{
			%client.bottomPrint("<just:center>\c5You may only pick up neutral flags.",1);
			return;
		}

		if(%mini.CTF_requireEnemyPlayers)
		{
			%hasMembers = false;
			for(%i = 0; %i < %mini.teams.getCount(); %i ++)
			{
				%t = %mini.teams.getObject(%i);
				if(%t.color == %color && %t.numMembers > 0)
				{
					%hasMembers = true;
					break;
				}
			}

			if(!%hasMembers)
			{
				%client.bottomPrint("<just:center><color:ff00ff>You cannot capture this flag because nobody is on" SPC %teamNames @ ".",1);
				return;
			}
		}

		Slayer_CTF_onFlagPickup(%mini,%client,%team,%brick,%flag);
	}
}

function slyrCTF_flagReturnTriggerData::onEnterTrigger(%this,%trigger,%player)
{
	if(!(%player.getType() & $TypeMasks::PlayerObjectType) || %player.dataBlock.rideable)
		return;

	%client = %player.client;
	if(!isObject(%client))
		return;

	Slayer_Support::Debug(3,"CTF Flag Trigger Enter",%trigger TAB %player TAB %client);

	//ARE WE HOLDING A FLAG?
	%image = %player.getMountedImage($Slayer::Server::CTF::flagImageSlot);
	if(%image.className !$= "slyrCTF_FlagImage")
		return;

	//VALID MINIGAME?
	%mini = getMinigameFromObject(%client);
	%team = %client.getTeam();
	if(!isSlayerMinigame(%mini) || !isObject(%team) || %mini.mode !$= "CTF")
		return;
	if(%mini.isResetting())
		return;

	//VALID FLAG RETURN BRICK?
	%brick = %trigger.brick;
	if(!minigameCanUse(%mini,%brick))
		return;
	%datablock = %brick.getDatablock();
	%color = %brick.getControl();
	%neutral = %mini.Teams.isNeutralColor(%color);
	%slyrType = %datablock.slyrType;

	%playerFlagSpawn = %player.flagSpawn;
	if(!isObject(%playerFlagSpawn))
	{
		Slayer_Support::Error("slyrCTF_flagReturnTriggerData::onEnterTrigger","Flag spawn not found!");
		return;
	}

	//WE CAN RETURN FLAGS HERE
	if(%color == %team.color || (%neutral && %slyrType $= "CTF_FlagReturn"))
	{
		//LOCKED BRICK?
		if(%brick.isLocked[%team.color])
		{
			%client.bottomPrint("<just:center>\c5This" SPC %datablock.uiName SPC "is locked. You cannot return flags here yet.",4);
			return;
		}

		%flagColor = %playerFlagSpawn.getColorID();

		//IT'S OUR FLAG
		if(%flagColor == %team.color)
		{
			if(%slyrType $= "CTF_Flag")
			{
				%item = %brick.item;
				if(!isObject(%item) || %item.getDatablock().className !$= "slyrCTF_FlagItem")
				{
					//FLAG RECOVERY
					%player.allowFlagRemoval = 1;
					%player.unMountImage($Slayer::Server::CTF::flagImageSlot);
					%player.flagSpawn = "";
					Slayer_CTF_onFlagRecovery(%mini,%client,%team,%brick,0);
				}
			}
		}
		//ENEMY FLAG
		else
		{
			//ONLY ALLOW RETURN AT FLAG RETURN BRICKS?
			if(%mini.CTF_flagReturnOnlyAtReturnBrick && %slyrType !$= "CTF_FlagReturn")
			{
				%client.bottomPrint("<just:center>\c5You must return the flag to a Flag Return Point.",4);
				return;
			}

			//RETURNING TO SAME COLOR?
			if(%flagColor == %color && %neutral)
			{
				%client.bottomPrint("<just:center>\c5You cannot return a flag to a Flag Return Point of the same color.",4);
				return;
			}

			//WE CAN'T RETURN IT IF WE DON'T HAVE OUR OWN FLAG
			if(!%mini.CTF_returnWithoutOwn)
			{
				if(%slyrType $= "CTF_Flag")
				{
					%item = %brick.item;
					if(!isObject(%item) || %item.getDatablock().className !$= "slyrCTF_FlagItem")
						%noFlag = 1;
				}
				else
				{
					if(!Slayer_CTF_isFlagAtHome(%mini,%team.color))
						%noFlag = 1;
				}
			}
			if(%noFlag)
			{
				messageClient(%client,'',"\c5You cannot return this flag while your flag is missing.");
				return;
			}

			//FLAG RETURN
			Slayer_CTF_onFlagReturn(%mini,%client,%team,%brick,0);
		}
	}
}


//This controls what bots do when they reach a flag.
//@param	mini	The bot's minigame.
//@param	ai	The AiConnection.
//@param	objective	The objective that was reached.
function Slayer_onBotObjectiveReached_CTFFlag(%mini,%ai,%objective)
{
	%bot = %ai.player;
	if(!isObject(%bot))
		return;

	%team = %ai.getTeam();

	if(!isObject(%team) || %objective.getControl() == %team)
		return;
	else
	{
		%bot.hClearMovement();

		if(getRandom(0,2))
			%bot.hCrouch(1500 + getRandom(1000,6000));

		//returning -1 prevents the bot from
		//continuing to the next objective
		return -1;
	}
}

///Server Commands

//Allows the client to manually drop a flag.
function serverCmdDropFlag(%client)
{
	if(%client.isSpamming())
		return;
	%mini = getMinigameFromObject(%client);
	if(!%mini.CTF_manualFlagDrop)
		return;
	if(isObject(%client.player))
		%client.player.dropFlag();
}


// +--------------------+
// | Packaged Functions |
// +--------------------+
package Slayer_Gamemode_CTF
{
	function Player::mountImage(%this,%image,%slot,%a,%b)
	{
		%curImage = %this.getMountedImage(%slot);
		if(isObject(%curImage) && %curImage.className $= "SlyrCTF_FlagImage")
			return;

		%parent = parent::mountImage(%this,%image,%slot,%a,%b);

		return %parent;
	}

	function Player::unMountImage(%this,%slot)
	{
		%curImage = %this.getMountedImage(%slot);
		if(!%this.allowFlagRemoval && isObject(%curImage) && %curImage.className $= "SlyrCTF_FlagImage")
			return;

		%this.allowFlagRemoval = 0;

		return parent::unMountImage(%this,%slot);
	}

	function serverCmdSetWrenchData(%client,%info)
	{
		%brick = %client.wrenchBrick;
		if(isObject(%brick.item))
			%itemDB = %brick.item.getDatablock();
		parent::serverCmdSetWrenchData(%client,%info);
		if(%brick.getDatablock().slyrType $= "CTF_Flag")
		{
			if(isObject(%itemDB) && %itemDB.className $= "slyrCTF_FlagItem")
				%brick.resetFlag();
		}
	}
};
activatePackage(Slayer_Gamemode_CTF);