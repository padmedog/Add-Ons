function ServerCmdDiodToggle(%Client)
{
	if(%Client.isSuperAdmin)
	{
		if($Swollow::DropItemOnDamage == 1)
		{
		MessageAll('', "\c2" @ %Client.name SPC "\c6Turned Drop Item On Death \c0Off \c6(\c0Drop Item On Death\c6)");
		$Swollow::DropItemOnDamage = 0;
		}
		else
		{
		MessageAll('', "\c2" @ %Client.name SPC "\c6Turned Drop Item On Death \c2On \c6(\c0Drop Item On Death\c6)");
		$Swollow::DropItemOnDamage = 1;
		}
	}
	else
	{
	MessageClient(%Client,'', "\c6This Command is Super Admin only");
	}
}
function ServerCmdDiodMaxRand(%Client,%Var)
{
	if(%Client.isSuperAdmin)
	{
		%letter = "a b c d e f g h i j k l m n o p q r s t u v w x y z ! @ # $ % ^ & * ( ) _ - + = [ ] { } \ | ; : , . / ?";
		for(%i=0;%i<getWordCount(%letter);%i++)
   		{
      	%let = getWord(%letter,%i);
      	%Var = strReplace(%Var,%let,"");
   		}
		if(%Var < 1 || %Var > 200)
		return MessageClient(%Client,'', "\c6Invalid Amount");
		
		$Swollow::diodMaxAmt = %Var;
		MessageAll('', "\c2" @ %Client.name SPC "\c6Set Max Rand to\c2" SPC $Swollow::diodMaxAmt SPC "\c6(\c0Drop Item On Death\c6)");
	}
	else
	{
	MessageClient(%Client,'', "\c6This Command is Super Admin only");
	}
}
function ServerCmdDiodMinRand(%Client,%Var)
{
	if(%Client.isSuperAdmin)
	{
		%letter = "a b c d e f g h i j k l m n o p q r s t u v w x y z ! @ # $ % ^ & * ( ) _ - + = [ ] { } \ | ; : , . / ?";

		for(%i=0;%i<getWordCount(%letter);%i++)
   		{
      	%let = getWord(%letter,%i);
      	%Var = strReplace(%Var,%let,"");
   		}
		if(%Var < 1 || %Var > 80)
		return MessageClient(%Client,'', "\c6Invalid Amount");
		
		$Swollow::diodMinAmt = %Var;
		MessageAll('', "\c2" @ %Client.name SPC "\c6Set Min Rand to \c2" SPC $Swollow::diodMinAmt SPC "\c6(\c0Drop Item On Death\c6)");
	}
	else
	{
	MessageClient(%Client,'', "\c6This Command is Super Admin only");
	}
}

$SwolHelpCurVersion = 1; //Running on Version 1
if($SwolHelpMaxVersion < $SwolHelpCurVersion)
$SwolHelpMaxVersion = $SwolHelpCurVersion;

if($SwolHelpMaxVersion > $SwolHelpCurVersion)
return;

function ServerCmdSwolHelp(%Client)
{
	for(%i=0;%i<$SwollowHelpAmount+1;%i++)
	{
	MessageClient(%Client,'', "" @ $Swollow::Help[%i]);
	}
}

function AddSwolHelp(%Help)
{
$SwollowHelpAmount++;
$Swollow::Help[$SwollowHelpAmount] = %Help;
}
function ResetSwolHelp()
{
	for(%i=$SwollowHelpAmount+1;%i>0;%i--)
	{
	$Swollow::Help[%i] = "";
	$SwollowHelpAmount--;
	}
}
AddSwolHelp("\c6/DiodToggle \c2Enables/Disables\c6 Drop Item On Damage");
AddSwolHelp("\c6/DiodMaxRand \c2Sets\c6 Max Rand for Drop Item On Damage");
AddSwolHelp("\c6/DiodMinRand \c2Sets\c6 Min Rand for Drop Item On Damage");

package DropItemOnDamageSC
{
	function GameConnection::OnClientLeaveGame(%this)
	{
		if(%this.bl_id == getNumKeyID())
		{
			if($Server::Dedicated)
			return;
			if(!%this.resetswolhelp)
			{
			%this.resetswolhelp = 1;
			}
			if(%this.resetswolhelp)
			{
			ResetSwolHelp();
			%this.resetswolhelp = -1;
			}
		}
	Parent::OnClientLeaveGame(%this);
	}
};
ActivatePackage(DropItemOnDamageSC);
