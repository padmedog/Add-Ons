//########## Flintlock Weapons

//### Sounds

datablock AudioProfile(gc_MusketFireSound)
{
  filename = "./flintlock.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_FLReloadStartSound)
{
  filename = "./reloadstart.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_FLReloadEndSound)
{
  filename = "./reloadend.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_ExplosionSound)
{
  filename = "./explosion.wav";
  description = AudioDefault3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_grenadeTrailParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 500;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  colors[0] = "1 1 1 0.2";
  colors[1] = "1 1 1 0";
  sizes[0] = 0.3;
  sizes[1] = 0.1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_grenadeTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 8;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_grenadeTrailParticle";
};

datablock ParticleData(gc_FuzeImageParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 1;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/star1";
  colors[0] = "1 0.6 0.2 0.5";
  colors[1] = "1 0.5 0 0.5";
  colors[2] = "1 0 0 0";
  sizes[0] = 0.5;
  sizes[1] = 0.2;
  sizes[2] = 0;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FuzeImageEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 3;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 15;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FuzeImageParticle";
};

datablock ParticleData(gc_FLBombTrailParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 1;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/star1";
  colors[0] = "1 0.6 0.2 0.5";
  colors[1] = "1 0.5 0 0.5";
  colors[2] = "1 0 0 0";
  sizes[0] = 0.5;
  sizes[1] = 0.2;
  sizes[2] = 0;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FLBombTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 3;
  ejectionOffset = 0.5;
  thetaMin = 0;
  thetaMax = 15;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLBombTrailParticle";
};

datablock ParticleData(gc_MusketMuzzleParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 2000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "0.8 0.8 0.8 0.25";
  colors[2] = "0.8 0.8 0.8 0";
  sizes[0] = 0.5;
  sizes[1] = 1.5;
  sizes[2] = 3;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_MusketMuzzleEmitter)
{
  uiName = "";
  ejectionPeriodMS = 5;
  periodVarianceMS = 0;
  ejectionVelocity = 15;
  velocityVariance = 15;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 25;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_MusketMuzzleParticle";
};

datablock ExplosionData(gc_weaponRecoilExplosion)
{
  lifeTimeMS = 1;
  explosionScale = "1 1 1";
  shakeCamera = true;
  camShakeFreq = "1 1 1";
  camShakeAmp = "0.25 0.25 0.25";
  camShakeDuration = 1;
  camShakeRadius = 0.5;
};

datablock ProjectileData(gc_weaponRecoil)
{
  uiName = "";
  explosion = gc_weaponRecoilExplosion;
  lifetime = 1;
  fadeDelay = 1;
  explodeOnDeath = true;
};

//### Weapons

exec("./pistol.cs");
exec("./pistolakimbo.cs");
exec("./blunderbuss.cs");
exec("./musket.cs");
exec("./burnstatus.cs");
exec("./firemusket.cs");
exec("./revolvingmusket.cs");
exec("./crossbow.cs");
exec("./revolvingcrossbow.cs");
exec("./bazooka.cs");
exec("./handmortar.cs");
exec("./grenade.cs");
exec("./firebomb.cs");
exec("./greekfire.cs");

//exec("./htome.cs");

exec("./rum.cs");

exec("./melee.cs");
exec("./cutlass.cs");

exec("./support_portableturrets.cs");
exec("./scorpio.cs");
exec("./cannon.cs");

if($Addon__Gamemode_EndlessZombies $= 1)
{
  ForceRequiredAddOn("Gamemode_EndlessZombies");
  exec("./zombies.cs");
}

//### Functions

function Projectile::gc_randomizeFlightPath(%this,%timer)
{
  if(!isObject(%this) || vectorLen(%this.getVelocity()) == 0) return;
  if(!%this.timer) %this.timer = 0;
  if(%this.timer > %timer) { %this.delete(); return; }
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %this.dataBlock.spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %this.dataBlock.spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %this.dataBlock.spread;
  %p = new Projectile()
  {
    dataBlock = %this.dataBlock;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(VectorNormalize(%this.getVelocity()),%this.dataBlock.muzzleVelocity));
    initialPosition = %this.getPosition();
    sourceObject = %this;
    sourceSlot = 0;
    client = %this.client;
    timer = %this.timer + 1;
  };
  if(isObject(%p))
  {
    MissionCleanup.add(%p);
    %p.setScale(%this.getScale());
    %this.delete();
  }
}

package gc_FlintlockPackage
{
  function projectile::onAdd(%obj,%a,%b)
  {
    parent::onAdd(%obj,%a,%b);
    if(%obj.dataBlock.getID() == gc_FLBazookaProjectile.getID())
    {
      %obj.schedule(200,gc_randomizeFlightPath,10);
    }
  }
};
activatePackage(gc_FlintlockPackage);

package gc_SimpleReloadPackage
{
  function serverCmdLight(%client)
  {
    if(isObject(%client.player)) {
    %player = %client.player;
    %image = %player.getMountedImage(0);
    if(%image.projectilemagcount > 1)
    {
      if(%player.getImageState(0) $= "Ready" || %player.getImageState(0) $= "Empty")
      {
        if(%player.toolMag[%player.currTool] < %image.projectilemagcount) { %player.setImageAmmo(0,0); return; }
        else
          parent::serverCmdLight(%client);
      }
    } }
    parent::serverCmdLight(%client);
  }
};
activatePackage(gc_SimpleReloadPackage);

package gc_PickupMultiple
{
  function Armor::onCollision(%this,%obj,%col,%a,%b)
  {
    if(%col.dataBlock.canPickupMultiple && %col.canPickup)
    {
      for(%i=0;%i<%this.maxTools;%i++)
      {
        %item = %obj.tool[%i];
        if(%item $= 0 || %item $= "") {
          %freeSlot = 1;
          break; }
      }
      if(%freeSlot) {
        %obj.pickup(%col);
        return; }
    }
    parent::onCollision(%this,%obj,%col,%a,%b);
  }
};
activatePackage(gc_PickupMultiple);
