forceRequiredAddon("Weapon_Gun");
forceRequiredAddon("Weapon_Rocket_Launcher");
exec("./Support_PreWeapon.cs");
exec("./Weapon_Amerigun.cs");