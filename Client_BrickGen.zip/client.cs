exec("./calcNormal.cs");
exec("./BrickGen.gui");

function BrickGen_GENERATE()
{
	if(BrickGen_Type0.getValue() == 1)
	GenerateCubic();

	if(BrickGen_Type1.getValue() == 1)
	GenerateRound();

	if(BrickGen_Type2.getValue() == 1)
	GenerateRamp();

	if(BrickGen_Type3.getValue() == 1)
	GenerateWindow();
}

function GenerateCubic()
{
	%x = BrickGen_SizeX.getValue();
	%y = BrickGen_SizeY.getValue();
	%z = BrickGen_SizeZ.getValue();

	if(%x == 0)
	return;

	if(%y == 0)
	return;

	if(%z == 0)
	return;

	if(%x+%y+%z<289)
	{

	%file = new FileObject();
	%filename = "config/BrickGen/Brick_"@%x@"x"@%y@"x"@%z@"Brick/"@%x@"x"@%y@"x"@%z@".blb";
	%file.openForWrite(%filename);
	%file.writeLine(%x SPC %y SPC %z);
	%file.writeLine("SPECIAL");
	%file.writeLine("");

	for(%i=0;%i<%x;%i++)
	%b = %b @"b";
	for(%i=0;%i<%x;%i++)
	%u = %u @"u";
	for(%i=0;%i<%x;%i++)
	%XX = %XX @"X";
	for(%i=0;%i<%x;%i++)
	%d = %d @"d";

for(%ia = 0; %ia < %y; %ia++)
{
	if(%z < 2)
	{
		%file.writeLine(%b);
		%file.writeLine("");
	}

if(%z == 2)
{
	%file.writeLine(%u);
	%file.writeLine(%d);
	%file.writeLine("");
}
    
if(%z > 2)
{
	%file.writeLine(%u);
        
	for(%ib = 0; %ib <= %z-3; %ib++)
	{
		%file.writeLine(%XX);
	}

		%file.writeLine(%d);
		%file.writeLine("");
	}
}

//Brick
	%file.writeLine("1");
	%file.writeLine("");
	%file.writeLine("0 0 0");
	%file.writeLine(%x SPC %y SPC %z);
	%file.writeLine("COVERAGE:");
	%file.writeLine("1 : "@%x*%y);
	%file.writeLine("1 : "@%x*%y);
	%file.writeLine("1 : "@%x*%z);
	%file.writeLine("1 : "@%y*%z);
	%file.writeLine("1 : "@%x*%z);
	%file.writeLine("1 : "@%y*%z);
	%file.writeLine("----------------top quads:");
	%file.writeLine("1");
	%file.writeLine("");
	if(Top_Print.getValue() == 1)
		%file.writeLine("TEX:PRINT");
	else
		%file.writeLine("TEX:TOP");
	%file.writeLine("POSITION:");
	%file.writeLine(0.5*%x SPC 0.5*%y SPC %z*0.5);
	%file.writeLine(0.5*%x SPC -0.5*%y SPC %z*0.5);
	%file.writeLine(-0.5*%x SPC -0.5*%y SPC %z*0.5);
	%file.writeLine(-0.5*%x SPC 0.5*%y SPC %z*0.5);
	%file.writeLine("UV COORDS:");

		if(Top_Print.getValue() == 1)
		{
			%file.writeLine("0 0");
			%file.writeLine("1 0");
			%file.writeLine("1 1");
			%file.writeLine("0 1");
		}
	else
		{
			%file.writeLine("0" SPC %y);
			%file.writeLine("0 0");
			%file.writeLine(%x SPC "0");
			%file.writeLine(%x SPC %y);
		}

	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 1");
	%file.writeLine("0 0 1");
	%file.writeLine("0 0 1");
	%file.writeLine("0 0 1");
	%file.writeLine("----------------bottom quads:");
if(Bottom_Print.getValue() == 1)
{
	%file.writeLine("1");
	%file.writeLine("");
	%file.writeLine("TEX:PRINT");
	%file.writeLine("POSITION:");
	%file.writeLine(0.5*%x SPC -0.5*%y SPC %z*-0.5);
	%file.writeLine(0.5*%x SPC 0.5*%y SPC %z*-0.5);
	%file.writeLine(-0.5*%x SPC 0.5*%y SPC %z*-0.5);
	%file.writeLine(-0.5*%x SPC -0.5*%y SPC %z*-0.5);
	%file.writeLine("UV COORDS:");
	%file.writeLine("1 1");
	%file.writeLine("0 1");
	%file.writeLine("0 0");
	%file.writeLine("1 0");
	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
}
	else
{
	%file.writeLine("5");
	%file.writeLine("");
	%file.writeLine("TEX:BOTTOMLOOP");
	%file.writeLine("POSITION:");
	%file.writeLine(%x/2-0.5 SPC 0-0.5*%y+0.5 SPC %z*-0.5);
	%file.writeLine(%x/2-0.5 SPC %y/2-0.5 SPC %z*-0.5);
	%file.writeLine(0-0.5*%x+0.5 SPC %y/2-0.5 SPC %z*-0.5);
	%file.writeLine(0-0.5*%x+0.5 SPC 0-0.5*%y+0.5 SPC %z*-0.5);
	%file.writeLine("UV COORDS:");
	%file.writeLine("0 0");
	%file.writeLine("0" SPC %y-1);
	%file.writeLine(%x-1 SPC %y-1);
	%file.writeLine(%x-1 SPC "0");
	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("");
	%file.writeLine("TEX:BOTTOMEDGE");
	%file.writeLine("POSITION:");
	%file.writeLine(-0.5*%x SPC -0.5*%y SPC  %z*-0.5);
	%file.writeLine(0.5*%x SPC -0.5*%y SPC  %z*-0.5);
	%file.writeLine(0.5*%x-0.5 SPC -0.5*%y+0.5 SPC  %z*-0.5);
	%file.writeLine(-0.5*%x+0.5 SPC -0.5*%y+0.5 SPC  %z*-0.5);
	%file.writeLine("UV COORDS:");
	%file.writeLine("-0.5 0");
	%file.writeLine(%x-0.5 SPC "0");
	%file.writeLine(%x-1 SPC "0.5");
	%file.writeLine("0 0.5");
	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("");
	%file.writeLine("TEX:BOTTOMEDGE");
	%file.writeLine("POSITION:");
	%file.writeLine(0.5*%x SPC 0.5*%y SPC %z*-0.5);
	%file.writeLine(-0.5*%x SPC 0.5*%y SPC %z*-0.5);
	%file.writeLine(-0.5*%x+0.5 SPC 0.5*%y-0.5 SPC %z*-0.5);
	%file.writeLine(0.5*%x-0.5 SPC 0.5*%y-0.5 SPC %z*-0.5);
	%file.writeLine("UV COORDS:");
	%file.writeLine("-0.5 0");
	%file.writeLine(%x-0.5 SPC "0");
	%file.writeLine(%x-1 SPC "0.5");
	%file.writeLine("0 0.5");
	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("");
	%file.writeLine("TEX:BOTTOMEDGE");
	%file.writeLine("POSITION:");
	%file.writeLine(0.5*%x SPC -0.5*%y SPC %z*-0.5);
	%file.writeLine(0.5*%x SPC 0.5*%y SPC %z*-0.5);
	%file.writeLine(0.5*%x-0.5 SPC 0.5*%y-0.5 SPC %z*-0.5);
	%file.writeLine(0.5*%x-0.5 SPC -0.5*%y+0.5 SPC %z*-0.5);
	%file.writeLine("UV COORDS:");
	%file.writeLine("-0.5 0");
	%file.writeLine(%y-0.5 SPC "0");
	%file.writeLine(%y-1 SPC "0.5");
	%file.writeLine("0 0.5");
	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("");
	%file.writeLine("TEX:BOTTOMEDGE");
	%file.writeLine("POSITION:");
	%file.writeLine(-0.5*%x SPC 0.5*%y SPC %z*-0.5);
	%file.writeLine(-0.5*%x SPC -0.5*%y SPC %z*-0.5);
	%file.writeLine(-0.5*%x+0.5 SPC -0.5*%y+0.5 SPC %z*-0.5);
	%file.writeLine(-0.5*%x+0.5 SPC 0.5*%y-0.5 SPC %z*-0.5);
	%file.writeLine("UV COORDS:");
	%file.writeLine("-0.5 0");
	%file.writeLine(%y-0.5 SPC "0");
	%file.writeLine(%y-1 SPC "0.5");
	%file.writeLine("0 0.5");
	%file.writeLine("NORMALS:");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
	%file.writeLine("0 0 -1");
}
	%file.writeLine("----------------north quads:");
	%file.writeLine("1");
	%file.writeLine("");
	if(North_Print.getValue() == 1)
		%file.writeLine("TEX:PRINT");
	else
		%file.writeLine("TEX:SIDE");
	%file.writeLine("POSITION:");
	%file.writeLine(0-0.5*%x SPC %y/2 SPC %z*0.5);  //-0.5 0.5
	%file.writeLine(0-0.5*%x SPC %y/2 SPC %z*-0.5); //-0.5 0.5
	%file.writeLine(%x/2 SPC %y/2 SPC %z*-0.5);       //0.5 0.5
	%file.writeLine(%x/2 SPC %y/2 SPC %z*0.5);        //0.5 0.5
	%file.writeLine("UV COORDS:");

	if(North_Print.getValue() == 1)
	{
		%file.writeLine("1 0");
		%file.writeLine("1 1");
		%file.writeLine("0 1");
		%file.writeLine("0 0");
	}
else
	{
		%file.writeLine((-((11-((11/%x)*2))/512)+1) SPC (11-((11/%z)*5))/512);
		%file.writeLine((-((11-((11/%x)*2))/512)+1) SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%x)*2))/512 SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%x)*2))/512 SPC (11-((11/%z)*5))/512);
	}

	%file.writeLine("NORMALS:");
	%file.writeLine("0 1 0");
	%file.writeLine("0 1 0");
	%file.writeLine("0 1 0");
	%file.writeLine("0 1 0");
	%file.writeLine("----------------east quads:");
	%file.writeLine("1");
	%file.writeLine("");
	if(East_Print.getValue() == 1)
		%file.writeLine("TEX:PRINT");
	else
		%file.writeLine("TEX:SIDE");
	%file.writeLine("POSITION:");
	%file.writeLine(%x/2 SPC %y/2-%y SPC %z*0.5);
	%file.writeLine(%x/2 SPC %y/2 SPC %z*0.5);
	%file.writeLine(%x/2 SPC %y/2 SPC %z*-0.5);
	%file.writeLine(%x/2 SPC %y/2-%y SPC %z*-0.5);
	%file.writeLine("UV COORDS:");

	if(East_Print.getValue() == 1)
	{
		%file.writeLine("0 0");
		%file.writeLine("1 0");
		%file.writeLine("1 1");
		%file.writeLine("0 1");
	}
else
	{
		%file.writeLine((11-((11/%y)*2))/512 SPC (11-((11/%z)*5))/512);
		%file.writeLine((-((11-((11/%y)*2))/512)+1) SPC (11-((11/%z)*5))/512);
		%file.writeLine((-((11-((11/%y)*2))/512)+1) SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%y)*2))/512 SPC (-((11-((11/%z)*5))/512)+1));
	}

	%file.writeLine("NORMALS:");
	%file.writeLine("1 0 0");
	%file.writeLine("1 0 0");
	%file.writeLine("1 0 0");
	%file.writeLine("1 0 0");
	%file.writeLine("----------------south quads:");
	%file.writeLine("1");
	%file.writeLine("");
	if(South_Print.getValue() == 1)
		%file.writeLine("TEX:PRINT");
	else
		%file.writeLine("TEX:SIDE");
	%file.writeLine("POSITION:");
	%file.writeLine(%x/2 SPC %y/2-%y SPC %z*0.5);
	%file.writeLine(%x/2 SPC %y/2-%y SPC %z*-0.5);
	%file.writeLine(%x/2-%x SPC %y/2-%y SPC %z*-0.5);
	%file.writeLine(%x/2-%x SPC %y/2-%y SPC %z*0.5);
	%file.writeLine("UV COORDS:");

	if(South_Print.getValue() == 1)
	{
		%file.writeLine("1 0");
		%file.writeLine("1 1");
		%file.writeLine("0 1");
		%file.writeLine("0 0");
	}
else
	{
		%file.writeLine((-((11-((11/%x)*2))/512)+1) SPC (11-((11/%z)*5))/512);
		%file.writeLine((-((11-((11/%x)*2))/512)+1) SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%x)*2))/512 SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%x)*2))/512 SPC (11-((11/%z)*5))/512);
	}

	%file.writeLine("NORMALS:");
	%file.writeLine("0 -1 0");
	%file.writeLine("0 -1 0");
	%file.writeLine("0 -1 0");
	%file.writeLine("0 -1 0");
	%file.writeLine("----------------west quads:");
	%file.writeLine("1");
	%file.writeLine("");
	if(West_Print.getValue() == 1)
		%file.writeLine("TEX:PRINT");
	else
		%file.writeLine("TEX:SIDE");
	%file.writeLine("POSITION:");
	%file.writeLine(%x/2-%x SPC %y/2-%y SPC %z*-0.5);
	%file.writeLine(0-0.5*%x SPC %y/2 SPC %z*-0.5); //-0.5 0.5
	%file.writeLine(0-0.5*%x SPC %y/2 SPC %z*0.5); //-0.5 0.5
	%file.writeLine(%x/2-%x SPC %y/2-%y SPC %z*0.5);
	%file.writeLine("UV COORDS:");

	if(West_Print.getValue() == 1)
	{
		%file.writeLine("1 1");
		%file.writeLine("0 1");
		%file.writeLine("0 0");
		%file.writeLine("1 0");
	}
else
	{
		%file.writeLine((-((11-((11/%y)*2))/512)+1) SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%y)*2))/512 SPC (-((11-((11/%z)*5))/512)+1));
		%file.writeLine((11-((11/%y)*2))/512 SPC (11-((11/%z)*5))/512);
		%file.writeLine((-((11-((11/%y)*2))/512)+1) SPC (11-((11/%z)*5))/512);
	}

	%file.writeLine("NORMALS:");
	%file.writeLine("-1 0 0");
	%file.writeLine("-1 0 0");
	%file.writeLine("-1 0 0");
	%file.writeLine("-1 0 0");
	%file.writeLine("----------------omni quads:");
	%file.writeLine("0");
	%file.close();
	%file.delete();

	%file2 = new FileObject();

	%filename2 = "config/BrickGen/Brick_"@%x@"x"@%y@"x"@%z@"Brick/server.cs";
	%file2.openForWrite(%filename2);

	%file2.writeLine("datablock fxDTSBrickData(brick"@ %x @"x"@ %y @"x"@ %z@"BrickData)");
	%file2.writeLine("{");
	%file2.writeLine("" TAB "brickFile = \"./"@ %x @"x"@ %y @"x"@ %z @".blb"@"\";");
	%file2.writeLine("" TAB "category = \"Special\";");
	%file2.writeLine("" TAB "subCategory = \"Generated\";");
	%file2.writeLine("" TAB "uiName = \""@ %x @"x"@ %y @"x"@ %z@"\";");
	%file2.writeLine("" TAB "iconName = \"\";");

if(Top_Print.getValue() + Bottom_Print.getValue() + North_Print.getValue() + East_Print.getValue() + South_Print.getValue() + West_Print.getValue() > 0)
{
		%file2.writeLine("" TAB "hasPrint = 1;");
		%file2.writeLine("" TAB "printAspectRatio = \""@BrickGenRatio.getValue()@"\";");
}

	%file2.writeLine("};");
	%file2.close();
	%file2.delete();

	%file3 = new FileObject();

	%filename3 = "config/BrickGen/Brick_"@%x@"x"@%y@"x"@%z@"Brick/Description.txt";
	%file3.openForWrite(%filename3);

	%file3.writeLine("Title: "@%x@"x"@%y@"x"@%z@" Brick");
	%file3.writeLine("Author: "@$pref::Player::NetName);

	%file3.close();
	%file3.delete();

	}
}

BrickGenRatio.addFront("2x2f",0,0);
BrickGenRatio.addFront("1x2f",1,0);
BrickGenRatio.addFront("1x1f",2,0);

function GenerateRound()
{
	%RHeight = BrickGen_Round_Height.getValue();

	%RWidLen = BrickGen_Round_WidthLength.getValue();

	%file = new FileObject();
	%filename = "config/BrickGen/Brick_"@%RWidLen@"x"@%RWidLen@"x"@%RHeight@"Round/"@%RWidLen@"x"@%RWidLen@"x"@%RHeight@"round.blb";
	%file.openForWrite(%filename);

	%file.writeLine(%RWidLen SPC %RWidLen SPC %RHeight);
	%file.writeLine("SPECIAL");
	%file.writeLine("");

	for(%gridAA=0;%gridAA<%RWidLen;%gridAA++)
	%gridB = %gridB @ "b";

	for(%gridBB=0;%gridBB<%RWidLen;%gridBB++)
	%gridU = %gridU @ "u";

	for(%gridCC=0;%gridCC<%RWidLen;%gridCC++)
	%gridX = %gridX @ "X";

	for(%gridDD=0;%gridDD<%RWidLen;%gridDD++)
	%gridD = %gridD @ "d";

	if(%RHeight == 1)
	{
		%file.writeLine(%gridB);
	}
		else
	{
		for(%dup=0;%dup<%RWidLen;%dup++)
		{

		%file.writeLine(%gridU);

		for(%GRID=2;%GRID<%RHeight;%GRID++)
		%file.writeLine(%gridX);

		%file.writeLine(%gridD);
		%file.writeLine("");

		}
	}

	%file.writeLine("1");
	%file.writeLine("");
	%file.writeLine("0 0 0");
	%file.writeLine(%RWidLen SPC %RWidLen SPC %RHeight);
	%file.writeLine("COVERAGE: //TBNESW");
	%file.writeLine("0 : "@%RWidLen*%RWidLen);
	%file.writeLine("0 : "@%RWidLen*%RWidLen);
	%file.writeLine("0 : 99");
	%file.writeLine("0 : 99");
	%file.writeLine("0 : 99");
	%file.writeLine("0 : 99");
	%file.writeLine("----------------top quads:");

	if(%RWidLen == 1)
	{
		%file.writeLine("4");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("0 0.5" SPC %RHeight/2);
		%file.writeLine("0.35 0.35" SPC %RHeight/2);
		%file.writeLine("0.5 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("-0.5 0.5");
		%file.writeLine("-0.5 1");
		%file.writeLine("-0.85 0.85");
		%file.writeLine("-1 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.5 0" SPC %RHeight/2);
		%file.writeLine("-0.35 0.35" SPC %RHeight/2);
		%file.writeLine("0 0.5" SPC %RHeight/2);
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0 0.5");
		%file.writeLine("-0.15 0.85");
		%file.writeLine("-0.5 1");
		%file.writeLine("-0.5 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0.5 0" SPC %RHeight/2);
		%file.writeLine("0.35 -0.35" SPC %RHeight/2);
		%file.writeLine("0 -0.5" SPC %RHeight/2);
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("-1 -0.5");
		%file.writeLine("-0.85 -0.85");
		%file.writeLine("-0.5 -1");
		%file.writeLine("-0.5 -0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("0 -0.5" SPC %RHeight/2);
		%file.writeLine("-0.35 -0.35" SPC %RHeight/2);
		%file.writeLine("-0.5 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("-0.5 0.5");
		%file.writeLine("-0.5 0");
		%file.writeLine("-0.15 0.15");
		%file.writeLine("0 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("----------------- Bottom quads:");
		%file.writeLine("4");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("0.28 0.28" SPC -0.5*%RHeight);
		%file.writeLine("0 0.4" SPC -0.5*%RHeight);
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.9 0.5");
		%file.writeLine("0.78 0.78");
		%file.writeLine("0.5 0.9");
		%file.writeLine("0.5 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("0 0.4" SPC -0.5*%RHeight);
		%file.writeLine("-0.28 0.28" SPC -0.5*%RHeight);
		%file.writeLine("-0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5 0.5");
		%file.writeLine("0.5 0.9");
		%file.writeLine("0.22 0.78");
		%file.writeLine("0.1 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("0 -0.4" SPC -0.5*%RHeight);
		%file.writeLine("0.28 -0.28" SPC -0.5*%RHeight);
		%file.writeLine("0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5 0.5");
		%file.writeLine("0.5 0.1");
		%file.writeLine("0.78 0.22");
		%file.writeLine("0.9 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("-0.28 -0.28" SPC -0.5*%RHeight);
		%file.writeLine("0 -0.4" SPC -0.5*%RHeight);
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.1 0.5");
		%file.writeLine("0.22 0.22");
		%file.writeLine("0.5 0.1");
		%file.writeLine("0.5 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("----------------- North quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- East quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- South quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- West quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- Omni quads:");
		%file.writeLine("20");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.35 0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0 1");
		%file.writeLine("0.5 1");
		%file.writeLine("1 1");
		%file.writeLine("0.5 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0 0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.35 0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0 1");
		%file.writeLine("0.5 0.5");
		%file.writeLine("1 1");
		%file.writeLine("0.5 1");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 -0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.35 -0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0 1");
		%file.writeLine("0.5 0.5");
		%file.writeLine("1 1");
		%file.writeLine("0.5 1");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.35 -0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 -0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0 1");
		%file.writeLine("0.5 1");
		%file.writeLine("1 1");
		%file.writeLine("0.5 0.5");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0 -0.4" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.28 -0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.28 -0.28" SPC -0.5*%RHeight);
		%file.writeLine("0 -0.4" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.2 1.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 -1 0");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("0 -1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0.28 -0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.4 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("0.28 -0.28" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.2 1.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("1 0 0");
		%file.writeLine("1 0 0");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0 -0.4" SPC -0.5*%RHeight);
		%file.writeLine("-0.28 -0.28" SPC -0.5*%RHeight);
		%file.writeLine("-0.28 -0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0 -0.4" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 1.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("-0 -1 0");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("-0 -1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.28 -0.28" SPC -0.5*%RHeight);
		%file.writeLine("-0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("-0.4 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.28 -0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 1.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0.4" SPC -0.5*%RHeight);
		%file.writeLine("0.28 0.28" SPC -0.5*%RHeight);
		%file.writeLine("0.28 0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 0.4" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 1.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 1 0");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("0 1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0.28 0.28" SPC -0.5*%RHeight);
		%file.writeLine("0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("0.4 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.28 0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 1.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("1 0 0");
		%file.writeLine("1 0 0");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0 0.4" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.28 0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.28 0.28" SPC -0.5*%RHeight);
		%file.writeLine("-0 0.4" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.2 1.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("-0 1 0");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("-0 1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.28 0.28" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.4 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.4 0" SPC -0.5*%RHeight);
		%file.writeLine("-0.28 0.28" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.2 -0.325");
		%file.writeLine("0.8 -0.325");
		%file.writeLine("0.8 1.325");
		%file.writeLine("0.2 1.325");
		%file.writeLine("NORMALS:");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("//hard part");

		%UV1 = (-((11-((11/%RHeight+1)*5))/512)+1);
		%UV2 = ((11-((11/%RHeight+1)*5+1))/512);

		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0 -0.5" SPC %RHeight/2);
		%file.writeLine("0.35 -0.35" SPC %RHeight/2);
		%file.writeLine("0.35 -0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0 -0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 -1 0");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("0 -1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0.35 -0.35" SPC %RHeight/2);
		%file.writeLine("0.5 0" SPC %RHeight/2);
		%file.writeLine("0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.35 -0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("NORMALS:");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("1 0 0");
		%file.writeLine("1 0 0");
		%file.writeLine("0.707107 -0.707107 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0 -0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.35 -0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.35 -0.35" SPC %RHeight/2);
		%file.writeLine("-0 -0.5" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("NORMALS:");
		%file.writeLine("-0 -1 0");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("-0 -1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.35 -0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.5 0" SPC %RHeight/2);
		%file.writeLine("-0.35 -0.35" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("NORMALS:");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-0.707107 -0.707107 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.35 0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.35 0.35" SPC %RHeight/2);
		%file.writeLine("0 0.5" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 1 0");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("0 1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("0.35 0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("0.5 0" SPC %RHeight/2);
		%file.writeLine("0.35 0.35" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("NORMALS:");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("1 0 0");
		%file.writeLine("1 0 0");
		%file.writeLine("0.707107 0.707107 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0 0.5" SPC %RHeight/2);
		%file.writeLine("-0.35 0.35" SPC %RHeight/2);
		%file.writeLine("-0.35 0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0 0.5" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("NORMALS:");
		%file.writeLine("-0 1 0");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("-0 1 0");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");
		%file.writeLine("-0.35 0.35" SPC %RHeight/2);
		%file.writeLine("-0.5 0" SPC %RHeight/2);
		%file.writeLine("-0.5 0" SPC -0.5*%RHeight+0.5);
		%file.writeLine("-0.35 0.35" SPC -0.5*%RHeight+0.5);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV2);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("0.5" SPC %UV1);
		%file.writeLine("NORMALS:");
		%file.writeLine("-0.707107 0.707107 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-1 0 0");
		%file.writeLine("-0.707107 0.707107 0");

		%file.close();
		%file.delete();
	}
		else
	{
		%file.writeLine("6");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("0" SPC %RWidLen/2 SPC %RHeight/2);
		%file.writeLine(0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine(-0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine(-0.5*%RWidLen SPC %RWidLen);
		%file.writeLine(-0.75*%RWidLen SPC 0.93*%RWidLen);
		%file.writeLine(-0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(%RWidLen/2 SPC "0" SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine(-0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine(-0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine(-1*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine(-0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine("0" SPC -0.5*%RWidLen SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine(-0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine(-0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine(-0.75*%RWidLen SPC 0.07*%RWidLen);
		%file.writeLine(-0.5*%RWidLen SPC "0");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine("0" SPC 0.5*%RWidLen SPC %RHeight/2);
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine(0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine(0.75*%RWidLen SPC 0.93*%RWidLen);
		%file.writeLine(0.5*%RWidLen SPC %RWidLen);
		%file.writeLine(0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.5*%RWidLen SPC "0" SPC %RHeight/2);
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine(0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine(%RWidLen SPC %RWidLen/2);
		%file.writeLine(0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine(%RWidLen/2 SPC %RWidLen/2);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("");
		%file.writeLine("TEX:TOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0" SPC -0.5*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine("0 0" SPC %RHeight/2);
		%file.writeLine("UV COORDS:");
		%file.writeLine(%RWidLen/2 SPC "0");
		%file.writeLine(0.75*%RWidLen SPC 0.07*%RWidLen);
		%file.writeLine(0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine(%RWidLen/2 SPC %RWidLen/2);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("0 0 1");
		%file.writeLine("----------------bottom quads:");
		%file.writeLine("6");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("0" SPC %RWidLen/2 SPC -0.5*%RHeight);
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine(-0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine(-0.75*%RWidLen SPC 0.93*%RWidLen);
		%file.writeLine(-0.5*%RWidLen SPC %RWidLen);
		%file.writeLine(-0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(%RWidLen/2 SPC "0" SPC -0.5*%RHeight);
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine(-0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine(-1*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine(-0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine(-0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0" SPC -0.5*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine(-0.5*%RWidLen SPC "0");
		%file.writeLine(-0.75*%RWidLen SPC 0.07*%RWidLen);
		%file.writeLine(-0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine(-0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine("0" SPC 0.5*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine(0.5*%RWidLen SPC 0.5*%RWidLen);
		%file.writeLine(0.5*%RWidLen SPC %RWidLen);
		%file.writeLine(0.75*%RWidLen SPC 0.93*%RWidLen);
		%file.writeLine(0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.5*%RWidLen SPC "0" SPC -0.5*%RHeight);
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine(%RWidLen/2 SPC %RWidLen/2);
		%file.writeLine(0.93*%RWidLen SPC 0.75*%RWidLen);
		%file.writeLine(%RWidLen SPC %RWidLen/2);
		%file.writeLine(0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("");
		%file.writeLine("TEX:BOTTOMLOOP");
		%file.writeLine("POSITION:");
		%file.writeLine("0 0" SPC -0.5*%RHeight);
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("0" SPC -0.5*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine(%RWidLen/2 SPC %RWidLen/2);
		%file.writeLine(0.93*%RWidLen SPC 0.25*%RWidLen);
		%file.writeLine(0.75*%RWidLen SPC 0.07*%RWidLen);
		%file.writeLine(%RWidLen/2 SPC "0");
		%file.writeLine("NORMALS:");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("0 0 -1");
		%file.writeLine("----------------- North quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- East quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- South quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- West quads:");
		%file.writeLine("0");
		%file.writeLine("----------------- Omni quads:");
		%file.writeLine("12");
		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		//NORMALS

		%Norm1A = 0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2;
		%Norm1B = "0" SPC %RWidLen/2 SPC %RHeight/2;
		%Norm1C = "0" SPC %RWidLen/2 SPC -0.5*%RHeight;

		%Norm2A = 0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2;
		%Norm2B = 0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2;
		%Norm2C = 0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight;

		%Norm3A = 0.5*%RWidLen SPC "0" SPC %RHeight/2;
		%Norm3B = 0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2;
		%Norm3C = 0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight;

		%Norm4A = 0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2;
		%Norm4B = 0.5*%RWidLen SPC "0" SPC %RHeight/2;
		%Norm4C = 0.5*%RWidLen SPC "0" SPC -0.5*%RHeight;

		%Norm5A = 0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2;
		%Norm5B = 0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2;
		%Norm5C = 0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight;

		%Norm6A = "0" SPC -0.5*%RWidLen SPC %RHeight/2;
		%Norm6B = 0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2;
		%Norm6C = 0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight;

		%Norm7A = -0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2;
		%Norm7B = "0" SPC -0.5*%RWidLen SPC %RHeight/2;
		%Norm7C = "0" SPC -0.5*%RWidLen SPC -0.5*%RHeight;

		%Norm8A = -0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2;
		%Norm8B = -0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2;
		%Norm8C = -0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight;

		%Norm9A = -0.5*%RWidLen SPC "0" SPC %RHeight/2;
		%Norm9B = -0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2;
		%Norm9C = -0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight;

		%Norm10A = -0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2;
		%Norm10B = -0.5*%RWidLen SPC "0" SPC %RHeight/2;
		%Norm10C = -0.5*%RWidLen SPC "0" SPC -0.5*%RHeight;

		%Norm11A = -0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2;
		%Norm11B = -0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2;
		%Norm11C = -0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight;

		%Norm12A = "0" SPC 0.5*%RWidLen SPC %RHeight/2;
		%Norm12B = -0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2;
		%Norm12C = -0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight;

		NC_addVertices(%Norm12A,%Norm12B,%Norm12C);
		NC_addVertices(%Norm1A,%Norm1B,%Norm1C);
		%var1 = NC_calc();

		NC_addVertices(%Norm1A,%Norm1B,%Norm1C);
		NC_addVertices(%Norm2A,%Norm2B,%Norm2C);
		%var2 = NC_calc();

		NC_addVertices(%Norm2A,%Norm2B,%Norm2C);
		NC_addVertices(%Norm3A,%Norm3B,%Norm3C);
		%var3 = NC_calc();

		NC_addVertices(%Norm3A,%Norm3B,%Norm3C);
		NC_addVertices(%Norm4A,%Norm4B,%Norm4C);
		%var4 = NC_calc();

		NC_addVertices(%Norm4A,%Norm4B,%Norm4C);
		NC_addVertices(%Norm5A,%Norm5B,%Norm5C);
		%var5 = NC_calc();

		NC_addVertices(%Norm5A,%Norm5B,%Norm5C);
		NC_addVertices(%Norm6A,%Norm6B,%Norm6C);
		%var6 = NC_calc();

		NC_addVertices(%Norm6A,%Norm6B,%Norm6C);
		NC_addVertices(%Norm7A,%Norm7B,%Norm7C);
		%var7 = NC_calc();

		NC_addVertices(%Norm7A,%Norm7B,%Norm7C);
		NC_addVertices(%Norm8A,%Norm8B,%Norm8C);
		%var8 = NC_calc();

		NC_addVertices(%Norm8A,%Norm8B,%Norm8C);
		NC_addVertices(%Norm9A,%Norm9B,%Norm9C);
		%var9 = NC_calc();

		NC_addVertices(%Norm9A,%Norm9B,%Norm9C);
		NC_addVertices(%Norm10A,%Norm10B,%Norm10C);
		%var10 = NC_calc();

		NC_addVertices(%Norm10A,%Norm10B,%Norm10C);
		NC_addVertices(%Norm11A,%Norm11B,%Norm11C);
		%var11 = NC_calc();

		NC_addVertices(%Norm11A,%Norm11B,%Norm11C);
		NC_addVertices(%Norm12A,%Norm12B,%Norm12C);
		%var12 = NC_calc();

		//NORMALS

		%file.writeLine(0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine("0" SPC %RWidLen/2 SPC %RHeight/2);
		%file.writeLine("0" SPC %RWidLen/2 SPC -0.5*%RHeight);
		%file.writeLine(0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var2);
		%file.writeLine(%var1);
		%file.writeLine(%var1);
		%file.writeLine(%var2);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var3);
		%file.writeLine(%var2);
		%file.writeLine(%var2);
		%file.writeLine(%var3);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(0.5*%RWidLen SPC "0" SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(0.5*%RWidLen SPC "0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var4);
		%file.writeLine(%var3);
		%file.writeLine(%var3);
		%file.writeLine(%var4);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.5*%RWidLen SPC "0" SPC %RHeight/2);
		%file.writeLine(0.5*%RWidLen SPC "0" SPC -0.5*%RHeight);
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var5);
		%file.writeLine(%var4);
		%file.writeLine(%var4);
		%file.writeLine(%var5);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var6);
		%file.writeLine(%var5);
		%file.writeLine(%var5);
		%file.writeLine(%var6);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine("0" SPC -0.5*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("0" SPC -0.5*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var7);
		%file.writeLine(%var6);
		%file.writeLine(%var6);
		%file.writeLine(%var7);

		//Second side

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(-0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine("0" SPC -0.5*%RWidLen SPC %RHeight/2);
		%file.writeLine("0" SPC -0.5*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var8);
		%file.writeLine(%var7);
		%file.writeLine(%var7);
		%file.writeLine(%var8);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.25*%RWidLen SPC -0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.25*%RWidLen SPC -0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var9);
		%file.writeLine(%var8);
		%file.writeLine(%var8);
		%file.writeLine(%var9);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(-0.5*%RWidLen SPC "0" SPC %RHeight/2);
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.43*%RWidLen SPC -0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.5*%RWidLen SPC "0" SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var10);
		%file.writeLine(%var9);
		%file.writeLine(%var9);
		%file.writeLine(%var10);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.5*%RWidLen SPC "0" SPC %RHeight/2);
		%file.writeLine(-0.5*%RWidLen SPC "0" SPC -0.5*%RHeight);
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var11);
		%file.writeLine(%var10);
		%file.writeLine(%var10);
		%file.writeLine(%var11);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine(-0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.43*%RWidLen SPC 0.25*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine(-0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var12);
		%file.writeLine(%var11);
		%file.writeLine(%var11);
		%file.writeLine(%var12);

		%file.writeLine("");
		%file.writeLine("TEX:SIDE");
		%file.writeLine("POSITION:");

		%file.writeLine("0" SPC 0.5*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.25*%RWidLen SPC 0.43*%RWidLen SPC %RHeight/2);
		%file.writeLine(-0.25*%RWidLen SPC 0.43*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("0" SPC 0.5*%RWidLen SPC -0.5*%RHeight);
		%file.writeLine("UV COORDS:");
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (11-((11/%RHeight)*5))/512);
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("0.5" SPC (-((11-((11/%RHeight)*5))/512)+1));
		%file.writeLine("NORMALS:");
		%file.writeLine(%var1);
		%file.writeLine(%var12);
		%file.writeLine(%var12);
		%file.writeLine(%var1);

	%file.close();
	%file.delete();
}

	%file2 = new FileObject();

	%filename2 = "config/BrickGen/Brick_"@%RWidLen@"x"@%RWidLen@"x"@%RHeight@"Round/server.cs";
	%file2.openForWrite(%filename2);

	%file2.writeLine("datablock fxDTSBrickData(brick"@%RWidLen@"x"@%RWidLen@"x"@%RHeight@"RoundData)");
	%file2.writeLine("{");
	%file2.writeLine("" TAB "brickFile = \"./"@ %RWidLen @"x"@ %RWidLen @"x"@ %RHeight @"round.blb"@"\";");
	%file2.writeLine("" TAB "category = \"Rounds\";");
	%file2.writeLine("" TAB "subCategory = \"Generated\";");
	%file2.writeLine("" TAB "uiName = \""@ %RWidLen @"x"@ %RWidLen @"x"@ %RHeight SPC "Round\";");
	%file2.writeLine("" TAB "iconName = \"\";");
	%file2.writeLine("};");

	%file2.close();
	%file2.delete();

	%file3 = new FileObject();

	%filename3 = "config/BrickGen/Brick_"@%RWidLen@"x"@%RWidLen@"x"@%RHeight@"Round/Description.txt";
	%file3.openForWrite(%filename3);

	%file3.writeLine("Title: "@%RWidLen@"x"@%RWidLen@"x"@%RHeight@" Round");
	%file3.writeLine("Author: "@$pref::Player::NetName);

	%file3.close();
	%file3.delete();
}

function 	GenerateRamp()
{
	error("ERROR: Brick Type not implemented yet");
}

function 	GenerateWindow()
{
	error("ERROR: Brick Type not implemented yet");
}