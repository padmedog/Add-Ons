
datablock ExplosionData(Rowboat_IIExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleExplosionEmitter;
   emitter[1] = vehicleExplosionEmitter2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light


   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(Rowboat_IIExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 100;
   damageRadius        = 100;
   explosion           = Rowboat_IIExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};

datablock DebrisData(Rowboat_IIDebris)
{
   emitters = "jeepDebrisTrailEmitter";

	shapeFile = "./shapes/Rowboat.dts";
	lifetime = 10.0;
	minSpinSpeed = -30.0;
	maxSpinSpeed = 30.0;
	elasticity = 0.5;
	friction = 0.0;
	numBounces = 0;
	staticOnMaxBounce = false;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ExplosionData(Rowboat_IIFinalExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleFinalExplosionEmitter3;
   emitter[1] = vehicleFinalExplosionEmitter2;

   particleEmitter = vehicleFinalExplosionEmitter;
   particleDensity = 20;
   particleRadius = 1.0;

   debris = Rowboat_IIDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 50;
   debrisVelocity = 15;
   debrisVelocityVariance = 3;

   faceViewer     = true;
   explosionScale = "5 5 5";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light

   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(Rowboat_IIFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 100;
   damageRadius        = 100;
   explosion           = Rowboat_IIFinalExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};

datablock ParticleData(Rowboat_IIPropParticle)
{
  animateTexture = "0";
  animTexName[0] = "base/data/particles/bubble";
  constantAcceleration = "0";
  dragCoefficient = "0";
  framesPerSec = "1";
  gravityCoefficient = "0";
  inheritedVelFactor = "0.499022";
  lifetimeMS = "2000";
  lifetimeVarianceMS = "100";

  colors[0] = "0.666667 0.800000 1.000000 0.500000";
  colors[1] = "0.666667 0.800000 1.000000 0.800000";
  colors[2] = "0.666667 0.800000 1.000000 0.000000";
  colors[3] = "1.000000 1.000000 1.000000 0.500000";

  sizes[0] = "0.3";
  sizes[1] = "0.2";
  sizes[2] = "0.1";
  sizes[3] = "0.05";

  times[0] = "0";
  times[1] = "0.498039";
  times[2] = "1";
  times[3] = "2";

  spinRandomMax = "500";
  spinRandomMin = "-90";
  spinSpeed = "0";
  textureName = "base/data/particles/bubble";
  useInvAlpha = "0";
  windCoefficient = "1";
};

datablock ParticleEmitterData(Rowboat_IIPropEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 1.0;
   ejectionOffset   = -1.4;
   thetaMin         = 85;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "Rowboat_IIPropParticle";

   useEmitterColors = true;

};


datablock ShapeBaseImageData(Rowboat_IIProp)
{
   shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 3;
   rotation = "0 1 0 0";
   
   	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;
	
	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "FireE";
	stateWaitForTimeout[1]			= true;
	stateEmitter[1]					= Rowboat_IIPropEmitter;
	stateEmitterTime[1]				= 1;
	stateEmitterNode[1]				= "emitterPoint";
	stateTimeoutValue[1]			= 0.2;
	
	stateName[2]					= "FireE";
	stateTransitionOnTimeout[2]		= "FireA";
	stateWaitForTimeout[2]			= true;
	stateTimeoutValue[2]			= 0.2;	
};


datablock WheeledVehicleData(Rowboat_IIVehicle)
{

	category = "Vehicles";
	displayName = " ";
	shapeFile = "./shapes/Rowboat.dts";
	emap = true;
	minMountDist = 3;

	numMountPoints = 3;
	mountThread[0] = "sit";
	mountThread[1] = "sit";
	mountThread[2] = "sit";



	maxDamage = 100.00;
	destroyedLevel = 100.00;
	energyPerDamagePoint = 160;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0";

	maxSteeringAngle = 0.6785;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = ShipTrailEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 10;         // Far distance from vehicle
	cameraOffset = 4;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.0;
	collisionTol = 0.1;        // Collision distance tolerance
	contactTol = 0.1;

	useEyePoint = false;	

	numWheels = 0;

	// Rigid Body
	mass = 100;
	density = 2;//5
	drag = 0.1;//1.6
	bodyFriction = 0.1;
	bodyRestitution = 0.1;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 5000; //4000;       // Engine power
	engineBrake = 100;         // Braking when throttle is 0
	brakeTorque = 1000;        // When brakes are applied
	maxWheelSpeed = 55;        // Engine scale by current speed / max speed

	rollForce		= 1000;
	yawForce		= 10000;
	pitchForce		= 1000;
	rotationalDrag		= 10;

	forwardThrust		= 1000;
	reverseThrust		= 500;
	lift			= 10;
	maxForwardVel		= 20;
	maxReverseVel		= 20;//2
	horizontalSurfaceForce	= 80;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 0; 
	stallSpeed		= -1;

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;

	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;

	justcollided = 0;

	uiName = "Rowboat II";
	rideable = true;
	lookUpLimit  = 0.5;
	lookDownLimit = 0.5;

	paintable = true;

	damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0 -3.0 0";
	damageLevelTolerance[0] = 0.50;

	damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

	numDmgEmitterAreas = 1;

	initialExplosionProjectile = Rowboat_IIExplosionProjectile;
	initialExplosionOffset = 1;         //offset only uses a z value for now

	burnTime = 0;

	finalExplosionProjectile = Rowboat_IIFinalExplosionProjectile;
	finalExplosionOffset = 0.5;          //offset only uses a z value for now


	minRunOverSpeed    = 4;   //how fast you need to be going to run someone over (do damage)
	runOverDamageScale = 25;   //when you run over someone, speed * runoverdamagescale = damage amt
	runOverPushScale   = 1.2; //how hard a person you're running over gets pushed
	minRowboat_IISpeed = 5;
	//protection for passengers
	protectPassengersBurn   = true;  //protect passengers from the burning effect of explosions?
	protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
	protectPassengersDirect = true; //protect passengers from direct damage (bullets) ?

	// boat vars
	maxForwardPitch = 0;	
	maxBackwardPitch = 2;	
	maxYaw = 1;	
	waterLevelOffset = 1.3;
};

function Rowboat_IIVehicle::onAdd(%this,%obj)
{
	Rowboat_IITick(%this, %obj, false);
}

function Rowboat_IIVehicle::onDriverLeave(%this,%obj)
{
	%obj.unmountimage(3);
}

//Where the magic happens; feel free to msg me for help!
function Rowboat_IITick(%this, %obj, %water)
{
	if(isObject(%obj)) {
		
		for(%i=0;%i<MissionGroup.getCount();%i++)
		{
			if(MissionGroup.getObject(%i).getclassname() $= "PhysicalZone")
			{
				%water = MissionGroup.getObject(%i);
				continue;
			}
		}
		%speed = mFloor(vectorlen(%obj.getvelocity())+0.5);
		if(%speed > 5)
		{
			%obj.unmountimage(3);
			%obj.mountimage(Rowboat_IIProp,3);
		}
		else
		{
			%obj.unmountimage(3);
		}

		if (isObject(%water)) {

			%waterlevel = getword(%water.getid().gettransform(),2)+getword(%water.getid().getscale(),2) + %this.waterLevelOffset;
			%trans = %obj.getTransform();
			%Vel = %obj.getvelocity();

			%eH = getWord(%obj.gettransform(),2);
			
			%eX = getWord(axisToEuler(%obj.gettransform()),0);
			%eY = getWord(axisToEuler(%obj.gettransform()),1);
			%eZ = getWord(axisToEuler(%obj.gettransform()),2);

			if (isObject(%obj.getMountNodeObject(0))) {
					if(%eH < %waterlevel - 1) {
						%obj.setvelocity(getWords(%Vel,0,1) SPC mAbs(%eH - %waterlevel)*mLog(mAbs(%eH - %waterlevel)));
					}
					if(%eH > %waterlevel + 1 && %eH < %waterlevel + 5) {
						%obj.setvelocity(getWords(%Vel,0,1) SPC (mAbs(%eH - %waterlevel) * -1)*mLog(mAbs(%eH - %waterlevel)));
					}
				} else {
					if(%eH > %waterlevel - 2 && %eH < %waterlevel - 1) {
						%obj.setvelocity(getWords(%Vel,0,1) SPC 0.6);
					}
					if(%eH < %waterlevel - 2) {
						%obj.setvelocity(getWords(%Vel,0,1) SPC mAbs(%waterlevel-%eH));
					}
				}
			
			if(%eX > %this.maxForwardPitch) { // forward
				%eX = %eX - 0.2;
			}
			if(%eX < %this.maxBackwardPitch) { // backward
				%eX = %eX + 0.2;
			}
			if(%eY > %this.maxYaw) {
				%eY = %eY - 0.7;
			}
			if(%eY < (-1 * %this.maxYaw)) {
				%eY = %eY + 0.7;
			}
			%obj.setTransform(%obj.getPosition() SPC eulerToAxis(%eX SPC %eY SPC %eZ));
			%obj.setvelocity(getWords(vectorscale(%Vel,0.99),0,1) SPC getWord(%obj.getvelocity(),2));

			if(getword(%obj.getposition(),2) > %waterlevel)
				%obj.setvelocity(vectorAdd(%vel,"0 0 -1"));
			}	
		}


		schedule(10,0,"Rowboat_IITick",%this,%obj,%water);
}
// TGE to XYZ
function eulerToAxis(%euler)
{
	%euler = VectorScale(%euler,$pi / 180);
	%matrix = MatrixCreateFromEuler(%euler);
	return getWords(%matrix,3,6);
}

function axisToEuler(%axis)
{
	%angleOver2 = getWord(%axis,6) * 0.5;
	%angleOver2 = -%angleOver2;
	%sinThetaOver2 = mSin(%angleOver2);
	%cosThetaOver2 = mCos(%angleOver2);
	%q0 = %cosThetaOver2;
	%q1 = getWord(%axis,3) * %sinThetaOver2;
	%q2 = getWord(%axis,4) * %sinThetaOver2;
	%q3 = getWord(%axis,5) * %sinThetaOver2;
	%q0q0 = %q0 * %q0;
	%q1q2 = %q1 * %q2;
	%q0q3 = %q0 * %q3;
	%q1q3 = %q1 * %q3;
	%q0q2 = %q0 * %q2;
	%q2q2 = %q2 * %q2;
	%q2q3 = %q2 * %q3;
	%q0q1 = %q0 * %q1;
	%q3q3 = %q3 * %q3;
	%m13 = 2.0 * (%q1q3 - %q0q2);
	%m21 = 2.0 * (%q1q2 - %q0q3);
	%m22 = 2.0 * %q0q0 - 1.0 + 2.0 * %q2q2;
	%m23 = 2.0 * (%q2q3 + %q0q1);
	%m33 = 2.0 * %q0q0 - 1.0 + 2.0 * %q3q3;
	return mRadToDeg(mAsin(%m23)) SPC mRadToDeg(mAtan(-%m13, %m33)) SPC mRadToDeg(mAtan(-%m21, %m22));
}

