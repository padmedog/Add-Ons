datablock fxDTSBrickData ( brickSlidingDoorOpenCWData )
{
	brickFile = "./SlidingDooropen.blb";
	uiName = "Sliding Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickSlidingDoorCWData";
	openCW = "brickSlidingDoorOpenCWData";
	
	closedCCW = "brickSlidingDoorCWData";
	openCCW = "brickSlidingDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickSlidingDoorOpenCCWData : brickSlidingDoorOpenCWData )
{
	brickFile = "./SlidingDooropen.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickSlidingDoorCWData : brickSlidingDoorOpenCWData )
{
	brickFile = "./SlidingDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";
	
	iconName = "Add-Ons/Brick_LLDoors/SlidingDoor";
	
	isOpen = 0;
};