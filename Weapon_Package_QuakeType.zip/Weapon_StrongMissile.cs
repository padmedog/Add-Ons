//gun.cs

datablock AudioProfile(strongMissileFireSound)
{
   filename    = "./xabunker_fire2.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(strongMissileChargeSound)
{
   filename    = "./xabunker_charge.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ExplosionData(strongMissileExplosion : gravityRocketExplosion)
{
   //explosionShape = "";

   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";

   damageRadius = 8;
   radiusDamage = 220;

   impulseRadius = 9;
   impulseForce = 2500;

	burnTime = 0;
};
//bullet trail effects
datablock ParticleData(strongMissileTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 505;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 1.0 0.0 0.4";
	colors[1]     = "1.0 0.2 0.0 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 1.55;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.25;
   times[2] = 0.6;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(strongMissileTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = -15;
   velocityVariance = 6.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "strongMissileTrailParticle";
};

datablock ParticleData(strongMissileSmokeParticle)
{
	dragCoefficient      = 6;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1400;
	lifetimeVarianceMS   = 1305;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 0.2 0.0 0.2";
	colors[1]     = "1.0 1 0.9 0.1";
   colors[2]     = "0.20 0.20 0.20 0.05";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 1.75;
	sizes[1]      = 0.35;
   sizes[2]      = 0.15;
 	sizes[3]      = 0;

   times[0] = 0.0;
   times[1] = 0.02;
   times[2] = 0.9;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(strongMissileSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = -15.00;
   velocityVariance = 14.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "strongMissileSmokeParticle";
};

AddDamageType("strongMissile",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_warheadlauncher> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_warheadlauncher> %1',0.2,1);
datablock ProjectileData(strongMissileProjectile : quakeRocketProjectile)
{
   projectileShapeName = "./xabunker_projectile.dts";

   directDamage        = 50;
   directDamageType    = $DamageType::strongMissile;
   radiusDamageType    = $DamageType::strongMissile;

   impactImpulse	     = 50;
   verticalImpulse	  = 700;
   explosion           = strongMissileExplosion;
   particleEmitter     = strongMissileTrailEmitter; //bulletTrailEmitter;

   sound = quakeRocketLoopSound;

   muzzleVelocity      = 30;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.9;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(strongMissileItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./xabunker_buster.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Warhead Launcher";
	iconName = "./warheadlauncher";
	doColorShift = true;
	colorShiftColor = "0.5 0.52 0.51 1.000";

	 // Dynamic properties defined by the scripts
	image = strongMissileImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(strongMissileImage)
{
   // Basic Item properties
	shapeFile = "./xabunker_buster.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = strongMissileProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = strongMissileItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateSequence[0]	= "Fire";
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Charge";
	stateAllowImageChange[1]         = true;
	stateScript[1]                  = "onCharge";
	stateSequence[1]	= "Activate";
	stateSound[1]					= sawbladeRifleClickSound;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.02;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]	= "Fire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakeRocketFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= strongMissileFireSound;

	stateName[3] = "Smoke";
	//stateEmitter[3]					= quakeRocketSmokeEmitter;
	//stateEmitterTime[3]				= 0.09;
	//stateEmitterNode[3]				= "tailNode";
	stateTimeoutValue[3]            = 0.18;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Fire";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.6;
	stateTransitionOnTimeout[5]     = "Wait";

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.04;
	stateTransitionOnTimeout[6]     = "Ready";

	stateName[7] = "Charge";
	stateEmitter[7]					= strongMissileTrailEmitter;
	stateEmitterTime[7]				= 0.6;
	stateEmitterNode[7]				= "muzzleNode";
	stateTimeoutValue[7]            = 0.6;
	stateTransitionOnTimeout[7]     = "Fire";
	stateScript[7]                  = "onCharge";
	stateSequence[7]	= "Activate";
	stateSound[7]					= strongMissileChargeSound;
};

function strongMissileImage::onCharge(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
}

function strongMissileImage::onFire(%this,%obj,%slot)
{
	%projectile = strongMissileProjectile;
	%spread = 0.0005;
	%shellcount = 1;

	%obj.playThread(2, shiftLeft);
	%obj.playThread(0, shiftRight);
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-12")));
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}
