registerOutputEvent(gameConnection,MessageBoxOK,"string 100 100\tstring 200 200");

function gameConnection::messageBoxOK(%this, %arg1, %arg2, %client)
{
	if(%arg1 $= "" || %arg2 $= "")
	{
		return;
	}
	
	commandToClient(%client,'messageBoxOK',%arg1,%arg2);
}
	