//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier2A");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Skins_Bullpup - required add-on Weapon_Package_Tier2A not found");
}
else
{
   exec("./Weapon_scopedbullpup.cs");
   exec("./Weapon_slimbullpup.cs"); 
}
