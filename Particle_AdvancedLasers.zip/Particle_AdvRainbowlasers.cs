
datablock ParticleData(AdvLaserParticleB)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1 0 0 1";
	colors[1]	= "0 1 0 1";
	colors[2]	= "0 0 1 1";
	colors[3]	= "1 0 1 0";

	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	sizes[3]	= 0.1;

	times[0]	= 0.0;
	times[1]	= 0.45;
	times[2]	= 0.9;
	times[3]	= 1.0;
};

datablock ParticleData(LaserUpParticle)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 0.0;
	gravityCoefficient   = -0.015;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 20100;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1 0 0 1";
	colors[1]	= "0 1 0 1";
	colors[2]	= "0 0 1 1";
	colors[3]	= "1 0 1 0";

	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	sizes[3]	= 0.1;

	times[0]	= 0.0;
	times[1]	= 0.45;
	times[2]	= 0.9;
	times[3]	= 1.0;
};

datablock ParticleData(LaserDwnParticle)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.015;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 20100;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1 0 0 1";
	colors[1]	= "0 1 0 1";
	colors[2]	= "0 0 1 1";
	colors[3]	= "1 0 1 0";

	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	sizes[3]	= 0.1;

	times[0]	= 0.0;
	times[1]	= 0.45;
	times[2]	= 0.9;
	times[3]	= 1.0;
};

datablock ParticleData(LaserMidParticle)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 10.0;
	gravityCoefficient   = 0.0025;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 10;
	lifetimeMS           = 20100;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1 0 0 1";
	colors[1]	= "0 1 0 1";
	colors[2]	= "0 0 1 1";
	colors[3]	= "1 0 1 0";

	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	sizes[3]	= 0.1;

	times[0]	= 0.0;
	times[1]	= 0.45;
	times[2]	= 0.9;
	times[3]	= 1.0;
};

datablock ParticleData(OffsetLaserParticleC)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 10.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 1100;
	lifetimeVarianceMS   = 300;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1 0 0 1";
	colors[1]	= "0 1 0 1";
	colors[2]	= "0 0 1 1";
	colors[3]	= "1 0 1 0";

	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	sizes[3]	= 0.1;

	times[0]	= 0.0;
	times[1]	= 0.45;
	times[2]	= 0.9;
	times[3]	= 1.0;
};

datablock ParticleData(OffsetLaserParticleD)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 10.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 1600;
	lifetimeVarianceMS   = 300;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1 0 0 1";
	colors[1]	= "0 1 0 1";
	colors[2]	= "0 0 1 1";
	colors[3]	= "1 0 1 0";

	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	sizes[3]	= 0.1;

	times[0]	= 0.0;
	times[1]	= 0.45;
	times[2]	= 0.9;
	times[3]	= 1.0;
};



//The special angular Laser particles may be difficult to use. To use them correctly, make sure to use East, West, South and North directions
//only. Using the Up and Down directions work, but will not shoot the Lasers in the right directions (choosing Up for any Down-going Laser
//will cause the Laser to shoot upwards instead at a strange angle)

datablock ParticleEmitterData(halfDegDwnLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 45;
   thetaMax         = 45.1;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "LR 45o Dwn Laser";
};

datablock ParticleEmitterData(twothirdDegDwnLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 22.5;
   thetaMax         = 22.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "LR 67o Dwn Laser";
};

datablock ParticleEmitterData(thirdsDegDwnLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 67.5;
   thetaMax         = 67.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "LR 22o Dwn Laser";
};

//The Up angular particles will shoot out in the Opposite direction specified by the emission point (i.e., the brick in this case).
//If the emitter is shooting West, the Up-going Laser will shoot East instead, at the correct specified angle.

datablock ParticleEmitterData(halfDegUpLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = -37;
   thetaMax         = -37.1;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "LR 45o Up Laser";
};

datablock ParticleEmitterData(thirdDegUpLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = -12.5;
   thetaMax         = -12.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "LR 22o Up Laser";
};

datablock ParticleEmitterData(twothirdsDegUpLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = -58.5;
   thetaMax         = -58.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "LR 67o Up Laser";
};




datablock ParticleEmitterData(duoLaserUpEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserUpParticle";

    uiName = "LR Dual Up Laser";
};

datablock ParticleEmitterData(duoLaserDwnEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserDwnParticle";

    uiName = "LR Dual Dwn Laser";
};

datablock ParticleEmitterData(duoLaserMidEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserMidParticle";

    uiName = "LR Dual Mid Laser";
};

datablock ParticleEmitterData(triLaserDwnEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = LaserDwnParticle;   

	uiName = "LR Tri Dwn Laser";
};

datablock ParticleEmitterData(triLaserUpEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = LaserUpParticle;   

	uiName = "LR Tri Up Laser";
};

datablock ParticleEmitterData(triLaserMidEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = LaserMidParticle;   

	uiName = "LR Tri Mid Laser";
};

datablock ParticleEmitterData(quadraLaserUpEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserUpParticle";

    uiName = "LR Quadra Up Laser";
};

datablock ParticleEmitterData(quadraLaserDwnEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserDwnParticle";

    uiName = "LR Quadra Dwn Laser";
};

datablock ParticleEmitterData(quadraLaserMidEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserMidParticle";

    uiName = "LR Quadra Mid Laser";

};

datablock ParticleEmitterData(hexaLaserUpEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = LaserUpParticle;   

	uiName = "LR Hexa Up Laser";
};

datablock ParticleEmitterData(hexaLaserDwnEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = LaserDwnParticle;   

	uiName = "LR Hexa Dwn Laser";
};

datablock ParticleEmitterData(hexaLaserMidEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = LaserMidParticle;   

	uiName = "LR Hexa Mid Laser";
};

//Rotating Lasers

datablock ParticleEmitterData(slowrotatingLaserEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 10;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "AdvLaserParticleB";

    uiName = "LR Slow Scanning Laser";
};

datablock ParticleEmitterData(medrotatingLaserEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 20;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "AdvLaserParticleB";

    uiName = "LR Med Scanning Laser";
};

datablock ParticleEmitterData(fastrotatingLaserEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 30;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "AdvLaserParticleB";

    uiName = "LR Fast Scanning Laser";
};


//offset Lasers

datablock ParticleEmitterData(offsetCloseLaserEmitter)
{
   ejectionPeriodMS = 8.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.0;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;

   emitterNode = GenericEmitterNode;        //used when placed on a brick
   pointEmitterNode = FourtiethEmitterNode; //used when placed on a 1x1 brick   

	uiName = "LR offset Close BarLaser";
};

//offset circular Lasers

datablock ParticleEmitterData(offsetClosecirScleLaserEmitter)
{
   ejectionPeriodMS = 8.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.02;
   velocityVariance = 0.0;
   thetaMin         = 10;
   thetaMax         = 10.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;   

	uiName = "LR offset Small CircleLaser";
};

datablock ParticleEmitterData(offsetClosecirMcleLaserEmitter)
{
   ejectionPeriodMS = 5.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.15;
   velocityVariance = 0.0;
   thetaMin         = 30;
   thetaMax         = 30.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;   

	uiName = "LR offset Medium CircleLaser";
};

datablock ParticleEmitterData(offsetClosecirLcleLaserEmitter)
{
   ejectionPeriodMS = 3.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.42;
   velocityVariance = 0.0;
   thetaMin         = 45;
   thetaMax         = 45.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = offsetLaserParticleD;   

	uiName = "LR offset Large CircleLaser";
};


