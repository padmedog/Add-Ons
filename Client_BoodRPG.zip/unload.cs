


BRPG_Client_SwitchCursor("default");


//Battle members

if(isObject(BRPG_BattleMembers_Body))
	BRPG_BattleMembers_Body.delete();

deactivatePackage(BRPG_BattleMembers_Package);


//Controls

deactivatePackage(BRPG_Client_Controls_Package);
if(isObject(BRPG_Client_Targeting_Gui))
	BRPG_Client_Targeting_Gui.delete();


//Player shapes

if(isObject(nDts))
	nDts.delete();
if(isObject(cDts))
	cDts.delete();