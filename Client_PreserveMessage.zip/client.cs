package PreserveMessage
{
	function LoadingGUI::onSleep(%this)
	{
		LoadingGUI.wasTyping = newMessageHud.isAwake();
		parent::onSleep(%this);
	}
	
	function PlayGUI::onWake(%this)
	{
		parent::onWake(%this);
		if(LoadingGUI.wasTyping)
			canvas.pushDialog(newMessageHud);
		LoadingGUI.wasTyping = ""; //Clear it out so it only happens once.
	}
};
activatePackage(PreserveMessage);