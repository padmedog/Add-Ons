if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	if(!$Pref::Server::AnnounceEnabled)
    {
        $Pref::Server::AnnounceEnabled = true;
    }
	if(!$Pref::Server::AnnouncePrivs)
    {
        $Pref::Server::AnnouncePrivs = 2;
    }
    RTB_registerPref("Enabled?","Announcement Mod","$Pref::Server::AnnounceEnabled","bool","Server_Announcements",$Pref::Server::AnnounceEnabled,0,1);
	RTB_registerPref("Priviledges","Announcement Mod","$Pref::Server::AnnouncePrivs","list Player 0 Admin 1 SuperAdmin 2 Host 3 None 4","Server_Announcements",$Pref::Server::AnnouncePrivs,0,1);
}
else if($Pref::Server::AnnounceEnabled $= "")
{
	$Pref::Server::AnnounceEnabled = true;
	$Pref::Server::AnnouncePrivs = 2;
}

function ServerCMDAnnounce(%client, %Chat, %Chat2, %Chat3, %Chat4, %Chat5, %Chat6, %Chat7, %Chat8, %Chat9, %Chat10, %Chat11, %Chat12, %Chat13, %Chat14, %Chat15, %Chat16, %Chat17)
{
    // Check if mod is enabled
    if ($Pref::Server::AnnounceEnabled == true)
	{
		// Enabled
        // Check Priv Level
        if ($Pref::Server::AnnouncePrivs == 0)
	    {
		    // Anyone
            %count = ClientGroup.getCount();
		    for(%cl = 0; %cl < %count; %cl++)
		    {
		    	%clientB = ClientGroup.getObject(%cl);
		    	%clientB.chatMessage(%chat SPC %chat2 SPC %chat3 SPC %chat4 SPC %chat5 SPC %chat6 SPC %chat7 SPC %chat8 SPC %chat9 SPC %chat10 SPC %chat11 SPC %chat12 SPC %chat13 SPC %chat14 SPC %chat15 SPC %chat16,10);
		    }
	    }
        else if ($Pref::Server::AnnouncePrivs == 1)
	    {
		    // Admin
           if (%client.isAdmin == true)
	        {
		        // Is Admin
                %count = ClientGroup.getCount();
		        for(%cl = 0; %cl < %count; %cl++)
		        {
		        	%clientB = ClientGroup.getObject(%cl);
		        	%clientB.chatMessage(%chat SPC %chat2 SPC %chat3 SPC %chat4 SPC %chat5 SPC %chat6 SPC %chat7 SPC %chat8 SPC %chat9 SPC %chat10 SPC %chat11 SPC %chat12 SPC %chat13 SPC %chat14 SPC %chat15 SPC %chat16,10);
		        }
	        }
            else
        	{
                // Not Admin
                messageClient(%client,'',"You do not have permission to set an announcement.");
	        }
	    }
        else if ($Pref::Server::AnnouncePrivs == 2)
	    {
		    // Super Admin
           if (%client.isSuperAdmin == true)
	        {
		        // Is SA
                %count = ClientGroup.getCount();
		        for(%cl = 0; %cl < %count; %cl++)
		        {
		        	%clientB = ClientGroup.getObject(%cl);
		        	%clientB.chatMessage(%chat SPC %chat2 SPC %chat3 SPC %chat4 SPC %chat5 SPC %chat6 SPC %chat7 SPC %chat8 SPC %chat9 SPC %chat10 SPC %chat11 SPC %chat12 SPC %chat13 SPC %chat14 SPC %chat15 SPC %chat16,10);
		        }
	        }
            else
        	{
                // Not SA
                messageClient(%client,'',"You do not have permission to set an announcement.");
	        }
	    }
        else if ($Pref::Server::AnnouncePrivs == 3)
	    {
		    // Host
            if (%client.bl_id == getNumKeyID() && $client.isSuperAdmin == true)
	        {
		        // Is Host
                %count = ClientGroup.getCount();
		        for(%cl = 0; %cl < %count; %cl++)
		        {
		        	%clientB = ClientGroup.getObject(%cl);
		        	%clientB.chatMessage(%chat SPC %chat2 SPC %chat3 SPC %chat4 SPC %chat5 SPC %chat6 SPC %chat7 SPC %chat8 SPC %chat9 SPC %chat10 SPC %chat11 SPC %chat12 SPC %chat13 SPC %chat14 SPC %chat15 SPC %chat16,10);
		        }
	        }
            else
        	{
                // Not Host
                messageClient(%client,'',"You do not have permission to set an announcement.");
	        }
	    }
        else if ($Pref::Server::AnnouncePrivs == 4)
	    {
		    // No-one
            messageClient(%client,'',"You do not have permission to set an announcement.");
	    }
	}
    else
	{
        // Disabled
        messageClient(%client,'',"Announcements are disabled (Hosts can enable it via Server Prefs)");
	}
}