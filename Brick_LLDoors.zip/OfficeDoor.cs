datablock fxDTSBrickData ( brickOfficeDoorOpenCWData )
{
	brickFile = "./OfficeDooropenCW.blb";
	uiName = "Office Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickOfficeDoorCWData";
	openCW = "brickOfficeDoorOpenCWData";
	
	closedCCW = "brickOfficeDoorCWData";
	openCCW = "brickOfficeDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickOfficeDoorOpenCCWData : brickOfficeDoorOpenCWData )
{
	brickFile = "./OfficeDooropenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickOfficeDoorCWData : brickOfficeDoorOpenCWData )
{
	brickFile = "./OfficeDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/OfficeDoor";
	
	isOpen = 0;
};