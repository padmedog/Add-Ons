// Title: HUD Prints.cs
// Author: Boom (9740)
// Schedules the HUD and parses Formatting

// Main Print Scheduler
function GameConnection::HUDPrints(%this)
{
	cancel(%this.HUDPrintSchedule);

	if(isObject(%this.player))
	{
		if($Pref::HUDPrints::CenterPrint !$= "" && $Pref::HUDPrints::Enabled)
			%this.HUDCenterPrint(parsePrint($Pref::HUDPrints::CenterPrint, false), $Pref::HUDPrints::PrintDelay/1000 + 1, "");

		if($Pref::HUDPrints::BottomPrint !$= "" && $Pref::HUDPrints::Enabled)
			%this.HUDBottomPrint(parsePrint($Pref::HUDPrints::BottomPrint, false), $Pref::HUDPrints::PrintDelay/1000 + 1, "");

		%this.HUDPrintSchedule = %this.schedule($Pref::HUDPrints::PrintDelay, HUDPrints);
	}
}

// Main Chat Scheduler
function GameConnection::HUDChat(%this)
{
	cancel(%this.HUDChatSchedule);

	if(isObject(%this.player))
	{
		if($Pref::HUDPrints::ChatMessage !$= "" && $Pref::HUDPrints::Enabled)
			%this.HUDChatMessage(parsePrint($Pref::HUDPrints::ChatMessage, true));

		%this.HUDChatSchedule = %this.schedule($Pref::HUDPrints::ChatDelay * 60 * 1000, HUDChat);
	}
}

// Sends Information to Chat
function GameConnection::HUDChatMessage(%this, %msg)
{
	messageClient(%this, '', %msg);
}

// Sends Information to Center Print when available
function GameConnection::HUDCenterPrint(%client, %msg, %time, %back)
{
	if(getSimTime() - %client.centerPrintSimTime <= %client.centerPrintTime * 1000 - $Pref::HUDPrints::PrintDelay)
		return false;
	else
		return %client.centerPrint(%msg, %time, %back, true);
}

// Sends Information to Bottom Print when available
function GameConnection::HUDBottomPrint(%client, %msg, %time, %back)
{
	if(getSimTime() - %client.bottomPrintSimTime < %client.bottomPrintTime * 1000 - $Pref::HUDPrints::PrintDelay)
		return false;
	else
		return %client.bottomPrint(%msg, %time, %back, true);

}

// Parses Information and handles Formatting
function parsePrint(%print, %chat)
{
	if(!$Pref::HUDPrints::Formatting)
		return %print SPC "_HUD_";

	%parse = "";

	for(%i = 0; %i < strLen(%print); %i++)
	{
		%sub = getSubStr(%print, %i, 2);
		%index = getSubStr(%print, %i+2, 1);

		if(%sub $= "%c") //Parse Color
		{
			%parse = %parse @ "<color:" @ $Pref::HUDPrints::Color[%index] @ ">";
			%i += 2; //Skip "c" and Index Characters
		}
		else if(%sub $= "%f") //Parse Font
		{
			%bold = "";
			%italics = "";
			%size = $Pref::HUDPrints::Size[$Pref::HUDPrints::DefaultSize];

			%font = $Pref::HUDPrints::Font[%index];
			%typeA = getSubStr(%print, %i+3, 1); //First Modifier: Bold, Italics, or Size
			%typeB = getSubStr(%print, %i+4, 1); //Second Modifier: Italics, Size, or Size Amount
			%typeC = getSubStr(%print, %i+5, 1); //Third Modifier: Size, or Size Amount
			%typeD = getSubStr(%print, %i+6, 1); //Fourth Modifier: Size Amount

			if(%typeA $= "b")
			{
				%bold = " bold";
				%i++; //Skip "b" Character

				if(%typeB $= "i")
				{
					%italics = " italic";
					%i++; //Skip "i" Character

					if(%typeC $= "s")
					{
						%size = $Pref::HUDPrints::Size[%typeD];
						%i += 2; //Skip "s" and Size Amount Characters
					}
				}
				else if(%typeB $= "s")
				{
					%size = $Pref::HUDPrints::Size[%typeC];
					%i += 2; //Skip "s" and Size Amount Characters
				}
			}
			else if(%typeA $= "i")
			{
				%italic = " italic";
				%i++; //Skip "i" Character

				if(%typeB $= "s")
				{
					%size = $Pref::HUDPrints::Size[%typeC];
					%i += 2; //Skip "s" and Size Amount Characters
				}
			}
			else if(%typeA $= "s")
			{
				%size = $Pref::HUDPrints::Size[%typeB];
				%i += 2; //Skip "s" and Size Amount Characters
			}

			%parse = %parse @ "<font:" @ %font @ %bold @ %italic @ ":" @ %size @ ">";
			%i += 2;
		}
		else //No Parsing
			%parse = %parse @ getSubStr(%print, %i, 1);
	}

	if(%chat)
		return %parse;
	else
		return %parse SPC "_HUD_";
}