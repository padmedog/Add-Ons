//########## Flintlock Bazooka

//### Sounds

datablock AudioProfile(gc_FLBazookaFireSound)
{
  filename = "./bazooka.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_FLBazookaReloadSound)
{
  filename = "./bazookareload.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_FLBazookaBackBlastParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.8 0.8 0.8 1";
  colors[1] = "0.8 0.8 0.8 0.5";
  colors[2] = "0.8 0.8 0.8 0";
  sizes[0] = 0.5;
  sizes[1] = 1.5;
  sizes[2] = 3;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_FLBazookaBackBlastEmitter)
{
  uiName = "";
  ejectionPeriodMS = 5;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 10;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 45;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLBazookaBackBlastParticle";
};

datablock ParticleData(gc_FLBazookaTrailParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 2000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.8 0.8 0.8 1";
  colors[1] = "0.8 0.8 0.8 0.5";
  colors[2] = "0.8 0.8 0.8 0";
  sizes[0] = 0.4;
  sizes[1] = 0.8;
  sizes[2] = 2;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_FLBazookaTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 6;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLBazookaTrailParticle";
};

datablock ParticleData(gc_FLBazookaExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/star1";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 16;
  sizes[1] = 12;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FLBazookaExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLBazookaExplosionParticle";
};

datablock ParticleData(gc_FLBazookaSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 6;
  sizes[1] = 12;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_FLBazookaSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 6;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 1;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLBazookaSmokeParticle";
};

datablock ExplosionData(gc_FLBazookaExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_FLBazookaExplosionEmitter;
  emitter[1] = gc_FLBazookaSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 6;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 4;
  radiusDamage = 50;
  impulseRadius = 6;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 12;
};

//### Projectile

AddDamageType("gc_FLBazooka",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_bazooka> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_bazooka> %1',0.2,1);

datablock ProjectileData(gc_FLBazookaProjectile)
{
  uiName = "";
  projectileShapeName = "Add-ons/Weapon_Rocket_Launcher/rocketprojectile.dts";
  directDamage = 30;
  directDamageType = $DamageType::gc_FLBazooka;
  radiusDamageType = $DamageType::gc_FLBazooka;
  brickExplosionRadius = 3;
  brickExplosionImpact = true;
  brickExplosionForce = 25;
  brickExplosionMaxVolume = 50;
  brickExplosionMaxVolumeFloating = 50;
  impactImpulse = 300;
  explosion = gc_FLBazookaExplosion;
  particleEmitter = gc_FLBazookaTrailEmitter;
  muzzleVelocity = 100;
  armingDelay = 0;
  lifetime = 3000;
  fadeDelay = 3000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  sound = gc_BazookaLoopSound;
  explodeOnDeath = true;
  spread = 0.002;
};

//### Item

datablock ItemData(gc_FLBazookaItem)
{
  uiName = "Bazooka";
  iconName = "./icon_bazooka";
  image = gc_FLBazookaImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./bazooka.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_FLBazookaImage)
{
  shapeFile = "./bazooka.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_FLBazookaItem;
  ammo = "";
  projectile = gc_FLBazookaProjectile;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "AmmoCheck";
  stateTimeoutValue[2] = "0.1";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_FLBazookaBackBlastEmitter;
  stateEmitterTime[2] = 0.1;
  stateEmitterNode[2] = "tailPoint";
  stateSound[2] = gc_FLBazookaFireSound;
  stateScript[2] = "onFire";

  stateName[3] = "AmmoCheck";
  stateTransitionOnTimeout[3] = "Ready";
  stateAllowImageChange[3] = true;
  stateScript[3] = "onAmmoCheck";

  stateName[4] = "Reload";
  stateTimeoutValue[4] = 3;
  stateTransitionOnTimeout[4] = "Done";
  stateWaitForTimeout[4] = true;
  stateAllowImageChange[4] = true;
  stateScript[4] = "onReloadStart";

  stateName[5] = "Done";
  stateTransitionOnTimeout[5] = "Ready";
  stateTimeoutValue[5] = 0.1;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReload";
};

//### Functions

function gc_FLBazookaImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %obj.spawnExplosion(gc_weaponRecoil,"1 1 1");
  %obj.playThread(2,plant);
  %spread = 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
}

function gc_FLBazookaImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_FLBazookaImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,shiftRight); serverPlay3D(gc_FLBazookaReloadSound,%obj.getPosition()); }
function gc_FLBazookaImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(0,1); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }
