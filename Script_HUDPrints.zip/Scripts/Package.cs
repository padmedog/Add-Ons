// Title: Package.cs
// Author: Boom (9740)
// Creates and Activates Package for this Add-On

package HUDPrintsPackage
{
	function GameConnection::SpawnPlayer(%this)
	{
		%this.schedule($Pref::HUDPrints::PrintDelay, HUDPrints); //Center and Bottom Prints
		%this.schedule($Pref::HUDPrints::ChatDelay, HUDChat); //Chat Messages

		return Parent::SpawnPlayer(%this);
	}

	function GameConnection::CenterPrint(%client, %msg, %time, %back)
	{
		if(striPos(%msg, "_HUD_") == -1)
		{
			%client.centerPrint = %msg;
			%client.centerPrintTime = %time;
			%client.centerPrintSimTime = getSimTime();
		}

		%msg = strReplace(%msg, "_HUD_", "");

		return Parent::CenterPrint(%client, %msg, %time, %back);
	}

	function GameConnection::BottomPrint(%client, %msg, %time, %back)
	{
		if(striPos(%msg, "_HUD_") == -1)
		{
			%client.bottomPrint = %msg;
			%client.bottomPrintTime = %time;
			%client.bottomPrintSimTime = getSimTime();
		}

		%msg = strReplace(%msg, "_HUD_", "");

		return Parent::BottomPrint(%client, %msg, %time, %back);
	}
};
activatePackage(HUDPrintsPackage);