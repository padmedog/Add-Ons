datablock ItemData(CovertPistolItem : PistolItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
   shapeFile = "./pistol_Covert.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Covert Pistol";
	iconName = "./Covertpistol";
	doColorShift = true;
	colorShiftColor = "0.4 0.4 0.4 1.000";
	l4ditemtype = "secondary";

	 // Dynamic properties defined by the scripts
	image = CovertPistolImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 14;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
AddDamageType("CovertL4Pistol",   '<bitmap:add-ons/Weapon_Skins_Pistol/ci_Cover_pistol> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Pistol/ci_Cover_pistol> %1',0.75,1);
datablock ShapeBaseImageData(CovertPistolImage : PistolImage)
{
   raycastDirectDamage = 13;

   shapeFile = "./pistol_Covert.dts";
   // Projectile && Ammo.
   item = CovertPistolItem;
   doColorShift = true;
   colorShiftColor = CovertPistolItem.colorShiftColor;
};

function CovertpistolImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0018;
		%this.raycastWeaponRange = 85;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0009;
		%this.raycastWeaponRange = 200;
	}
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>10x18mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	
	%obj.playThread(2, shiftAway);	
}

function CovertPistolImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>10x18mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function CovertPistolImage::onBounce(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>10x18mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	%obj.playThread(2, plant);
}

function CovertPistolImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>10x18mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
}

function CovertPistolImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{

	%obj.playThread(2, plant);
        if(%obj.client.quantity["9MMrounds"] >  %this.item.maxAmmo)
	{
		%obj.client.quantity["9MMrounds"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>10x18mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["9MMrounds"] <=  %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["9MMrounds"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.client.quantity["9MMrounds"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>10x18mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}