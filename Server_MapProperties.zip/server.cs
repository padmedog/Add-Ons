package mapproperties
{
	function setskybox(%path)
	{
		parent::setskybox(%path);
		unloadmapproperties();

		if(isfile(%file = getdirectoryup(%path) @"Properties.cs"))
		{
			%before = missiongroup.getcount();
			echo("Loading Atmospheric Map Properties");
			exec(%file);
			%after = missiongroup.getcount();
			%a = -1;

			for(%i=%before; %i<%after; %i++)
				missiongroup.mapproperty[%a++] = missiongroup.getobject(%i);
			missiongroup.mappropertycount = %a++;
		}
	}
};
activatepackage(mapproperties);

function unloadmapproperties()
{
	for(%i=0; %i<missiongroup.mappropertycount; %i++)
	{
		if(isobject(missiongroup.mapproperty[%i]))
			missiongroup.mapproperty[%i].delete();
	}
	missiongroup.mappropertycount = 0;
}

function getdirectoryup(%path)
{
	%exp = strreplace(%path, "/", "\t");
	%cut = getfield(%exp, getfieldcount(%exp)-1);
	return getsubstr(%path, 0, strlen(%path) - strlen(%cut));
}