//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// Load dts shapes and merge animations
datablock TSShapeConstructor(MechLightDts)
{
	baseShape  = "./MechLight.dts";
	sequence0  = "./M_root.dsq root";

	sequence1  = "./M_run.dsq run";
	sequence2  = "./M_run.dsq walk";
	sequence3  = "./M_back.dsq back";
	sequence4  = "./M_side.dsq side";

	sequence5  = "./M_root.dsq crouch";
	sequence6  = "./M_run.dsq crouchRun";
	sequence7  = "./M_back.dsq crouchBack";
	sequence8  = "./M_side.dsq crouchSide";

	sequence9  = "./M_look.dsq look";
	sequence10 = "./M_root.dsq headside";
	sequence11 = "./M_root.dsq headUp";

	sequence12 = "./M_jump.dsq jump";
	sequence13 = "./M_jump.dsq standjump";
	sequence14 = "./M_root.dsq fall";
	sequence15 = "./M_root.dsq land";

	sequence16 = "./M_root.dsq armAttack";
	sequence17 = "./M_root.dsq armReadyLeft";
	sequence18 = "./M_root.dsq armReadyRight";
	sequence19 = "./M_root.dsq armReadyBoth";
	sequence20 = "./M_root.dsq spearready";  
	sequence21 = "./M_root.dsq spearThrow";

	sequence22 = "./M_root.dsq talk";  

	sequence23 = "./M_Death.dsq death1"; 
	
	sequence24 = "./M_root.dsq shiftUp";
	sequence25 = "./M_root.dsq shiftDown";
	sequence26 = "./M_root.dsq shiftAway";
	sequence27 = "./M_root.dsq shiftTo";
	sequence28 = "./M_root.dsq shiftLeft";
	sequence29 = "./M_root.dsq shiftRight";
	sequence30 = "./M_root.dsq rotCW";
	sequence31 = "./M_root.dsq rotCCW";

	sequence32 = "./M_root.dsq undo";
	sequence33 = "./M_root.dsq plant";

	sequence34 = "./M_root.dsq sit";

	sequence35 = "./M_root.dsq wrench";

   sequence36 = "./M_root.dsq activate";
   sequence37 = "./M_root.dsq activate2";

   sequence38 = "./M_root.dsq leftrecoil";
};    


datablock AudioProfile(MechLightJumpSound)
{
   fileName = "./jumpMech.wav";
   description = AudioClose3d;
   preload = true;
};


datablock DebrisData( MechLightDebris )
{
   explodeOnMaxBounce = false;

   elasticity = 0.15;
   friction = 0.5;

   lifetime = 4.0;
   lifetimeVariance = 0.0;

   minSpinSpeed = 40;
   maxSpinSpeed = 600;

   numBounces = 5;
   bounceVariance = 0;

   staticOnMaxBounce = true;
   gravModifier = 1.0;

   useRadiusMass = true;
   baseRadius = 1;

   velocity = 20.0;
   velocityVariance = 12.0;
};             

datablock PlayerData(MechLightArmor)
{
   renderFirstPerson = true;
   emap = false;
   
   className = Armor;
   shapeFile = "./MechLight.dts";
   cameraMaxDist = 8;
   cameraTilt = 0.261;//0.174 * 2.5; //~25 degrees
   cameraVerticalOffset = 6.1;
   computeCRC = false;
  
   canObserve = true;
   cmdCategory = "Clients";

   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;
   
   //debrisShapeName = "~/data/shapes/player/debris_player.dts";
   //debris = MechLightDebris;

   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 1.5708;
   maxFreelookAngle = 3.0;

   mass = 90;
   drag = 0.1;
   maxdrag = 0.52;
   density = 0.7;
   maxDamage = 300;
   maxEnergy =  10;
   repairRate = 0.33;
   energyPerDamagePoint = 75.0;

   rechargeRate = 0.4;

   runForce = 40 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 25;
   maxBackwardSpeed = 18;
   maxSideSpeed = 3;

   maxForwardCrouchSpeed = 12;
   maxBackwardCrouchSpeed = 6;
   maxSideCrouchSpeed = 1;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 0;
   maxBackwardWalkSpeed = 0;
   maxSideWalkSpeed = 0;

   maxUnderwaterForwardSpeed = 8.4;
   maxUnderwaterBackwardSpeed = 7.8;
   maxUnderwaterSideSpeed = 7.8;

   jumpForce = 21 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

   minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

   recoverDelay = 0;
   recoverRunForceScale = 1.2;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("5 5 11", 4); //"2.5 2.5 2.4";
   crouchBoundingBox	= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";
   proneBoundingBox		= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";

   pickupRadius = 0.75;
   
   // Damage location details
   boxNormalHeadPercentage       = 0.83;
   boxNormalTorsoPercentage      = 0.49;
   boxHeadLeftPercentage         = 0;
   boxHeadRightPercentage        = 1;
   boxHeadBackPercentage         = 0;
   boxHeadFrontPercentage        = 1;

   // Foot Prints
   //decalData   = MechLightFootprint;
   //decalOffset = 0.25;
	
   jetEmitter = "";
   jetGroundEmitter = "";
   jetGroundDistance = 4;
  
   //footPuffEmitter = LightPuffEmitter;
   footPuffNumParts = 10;
   footPuffRadius = 0.25;

   //dustEmitter = LiftoffDustEmitter;

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 85;
   jumpSurfaceAngle = 86;

   minJumpSpeed = 20;
   maxJumpSpeed = 30;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;
   
   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   JumpSound			= MechLightJumpSound;

   // Footstep Sounds
//   FootSoftSound        = MechLightFootFallSound;
//   FootHardSound        = MechLightFootFallSound;
//   FootMetalSound       = MechLightFootFallSound;
//   FootSnowSound        = MechLightFootFallSound;
//   FootShallowSound     = MechLightFootFallSound;
//   FootWadingSound      = MechLightFootFallSound;
//   FootUnderwaterSound  = MechLightFootFallSound;
   //FootBubblesSound     = FootLightBubblesSound;
   //movingBubblesSound   = ArmorMoveBubblesSound;
   //waterBreathSound     = WaterBreathMaleSound;

   //impactSoftSound      = ImpactLightSoftSound;
   //impactHardSound      = ImpactLightHardSound;
   //impactMetalSound     = ImpactLightMetalSound;
   //impactSnowSound      = ImpactLightSnowSound;
   
   impactWaterEasy      = Splash1Sound;
   impactWaterMedium    = Splash1Sound;
   impactWaterHard      = Splash1Sound;
   
   groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;
   
   observeParameters = "0.5 4.5 4.5";

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "Mech Light";
	rideable = true;
		lookUpLimit = 0.45;
		lookDownLimit = 0.45;

	canRide = false;
	showEnergyBar = false;
	paintable = true;

	brickImage = MechLightBrickImage;	//the imageData to use for brick deployment

   numMountPoints = 1;
   mountThread[0] = "crouch";
   mountNode[0] = 0;
   
      //Weapons
   shootonclick = 1;
   
   shootonclick_Hold = 1;
   shootonclick_ShootDelay = 200;
   shootonclick_ReShootDelay = 200;
   shootonclick_ProjectileCount = 2;
   shootonclick_RequiredSlot = 0;
   shootonclick_Sound = gunshot1sound;

   shootonclick_Projectile[0] = MechLightgunProjectile;
   shootonclick_Position[0] = "2 2.8 9.3";
   shootonclick_Velocity[0] = "150 0 0";
   shootonclick_Scale[0] = "2 2 2";
   shootonclick_Projectile[1] = MechLightgunProjectile;
   shootonclick_Position[1] = "2 -2.8 9.3";
   shootonclick_Velocity[1] = "150 0 0";
   shootonclick_Scale[1] = "2 2 2";
};


datablock ProjectileData(MechLightgunProjectile)
{
   projectileShapeName = "add-ons/weapon_gun/bullet.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	   = 0;
   explosion           = gunExplosion;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Mech Light Gun Bullet";
};

function MechLightArmor::onAdd(%this,%obj)
{
   // Vehicle timeout
   %obj.mountVehicle = true;

   // Default dynamic armor stats
   %obj.setRechargeRate(%this.rechargeRate);
   %obj.setRepairRate(0);

}



//called when the driver of a player-vehicle is unmounted
function MechLightArmor::onDriverLeave(%obj, %player)
{
	//do nothing
}