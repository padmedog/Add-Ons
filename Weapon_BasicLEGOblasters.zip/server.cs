exec("./Weapon_lbs.cs");
exec("./Weapon_lls.cs");
exec("./Weapon_lbo.cs");
exec("./Weapon_lbb.cs");
exec("./Weapon_lbp.cs");
exec("./Weapon_dlbp.cs");
exec("./Weapon_ltb.cs");