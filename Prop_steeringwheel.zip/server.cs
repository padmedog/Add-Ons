	datablock StaticShapeData(SWShape)
	{
		shapefile="add-ons/prop_steeringwheel/1x2SW.dts";
	};

	datablock fxDtsBrickData(SWBrickData)
	{
		category="Props";
		subCategory="Packer";
		uiName="Steering Wheel";
		iconName = "add-ons/prop_steeringwheel/SW";
		
		brickSizeX=1;
		brickSizeY=2;
		brickSizeZ=6;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=SWShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

