//Modified homing rocket code (originally by Space Guy)

package RYNO5_Homing
{
	function Projectile::onAdd(%obj, %a, %b)
	{
		Parent::onAdd(%obj, %a, %b);
		if(%obj.getDatablock() == RYNO5_RocketProjectile.getID())
		{
			if(!%obj.doneRYNO5Delay)
			{
				%obj.schedule(300, spawnRyno5Rocket);
			}
			else
			{
				%obj.schedule(75, spawnRyno5Rocket);
			}
		}
	}
};
activatePackage(RYNO5_Homing);

function Projectile::spawnRYNO5Rocket(%this)
{
	if(!isObject(%this.client))
	{
		return;
	}	
	if(!isObject(%this) || vectorLen(%this.getVelocity()) == 0)
	{
		return;
	}	
	%client = %this.client;
	%muzzle = vectorLen(%this.getVelocity());
	if(!isObject(%this.target) || %this.target.getState() $= "Dead" || %this.target.getMountedImage(0) == adminWandImage.getID() || vectorDist(%this.getPosition(),%this.target.getHackPosition()) > 30)
	{
		%pos = %this.getPosition();
		%radius = 100;
		%searchMasks = $TypeMasks::PlayerObjectType;
		InitContainerRadiusSearch(%pos, %radius, %searchMasks);
		%minDist = 1000;
		while(%searchObj = containerSearchNext())
		{
			if((miniGameCanDamage(%client,%searchObj)) == 1)
			{
				if(%searchObj.getState() $= "Dead")
				{
					continue;
				}
				if(%this.sourceObject == %searchObj)
				{
					continue;
				}
				if(isTeamFriendly(%this,%searchObj) != 0)
				{
					continue;
				}
				if(%searchObj.getMountedImage(0) == adminWandImage.getID())
				{
					continue;
				}
				if(%searchObj.isCloaked())
				{
					continue;
				}				
				%d = vectorDist(%pos,%searchObj.getPosition());
				if(%d < %minDist)
				{
					%minDist = %d;
					%found = %searchObj;
				}
			}
		}		
		if(isObject(%found))
		{
			%this.target = %found;
		}
		else
		{
			%notarget = true;
		}
	}
	%pos = %this.getPosition();
	%start = %pos;
	if(!%notarget)
	{
		%found = %this.target;
		%end = %found.getHackPosition();
	}
	else
	{
		%end = vectorAdd(%pos, getRandom(-25, 25) SPC getRandom(-25, 25) SPC getRandom(-25, 25));
	}
	%enemypos = %end;
	%vec = vectorNormalize(vectorSub(%end,%start));
	for(%i=0;%i<5;%i++)
	{
		%t = vectorDist(%start,%end) / vectorLen(vectorScale(getWord(%vec,0) SPC getWord(%vec,1),%muzzle));
		%velaccl = vectorScale(%accl,%t);
		%x = getword(%velaccl,0);
		%y = getword(%velaccl,1);
		%z = getWord(%velaccl,2);
		%x = (%x < 0 ? 0 : %x);
		%y = (%y < 0 ? 0 : %y);
		%z = (%z < 0 ? 0 : %z);
		if(!%notarget)
		{
			%vel = vectorAdd(vectorScale(%found.getVelocity(),%t),%x SPC %y SPC %z);
		}
		%end = vectorAdd(%enemypos,%vel);
		%vec = vectorNormalize(vectorSub(%end,%start));
	}
	%addVec = vectorAdd(%this.getVelocity(),vectorScale(%vec,180/vectorDist(%pos,%end)*(%muzzle/40)));
	%vec = vectorNormalize(%addVec);
	%p = new Projectile()
	{
		dataBlock = %this.dataBlock;
		initialPosition = %pos;
		initialVelocity = vectorScale(%vec,%muzzle);
		sourceObject = %this.sourceObject;
		client = %this.client;
		sourceSlot = 0;
		originPoint = %this.originPoint;
		doneRYNO5Delay = 1;
		target = %this.target;
		reflectTime = %this.reflectTime;
	};
	if(isObject(%p))
	{
		MissionCleanup.add(%p);
		%p.setScale(%this.getScale());
		%this.delete();
	}
}

function isTeamFriendly(%obj1,%obj2)
{
	// 0 = enemy
	// 1 = allied
	//-1 = neutral
	%mini1 = getMinigameFromObject(%obj1);
	%mini2 = getMinigameFromObject(%obj2);
	if(%mini1 != %mini2)
	{
		return -1;
	}
	if(!isObject(%mini1))
	{
		return -1;
	}
	if(%obj1 == %obj2)
	{
		return 1;
	}
	%usingTDM = (isObject(GameModeStorerSO) && GameModeStorerSO.modeUsesTeams[%mini1.gamemode]);
	%usingIbanZombies = ($ZAPT::Version > 0 && miniGameUsingTDMGameMode(%mini1) && %mini1.ZAPT_enabled);
	%usingRotZombies = (%mini1.EnableZombies);
	
	switch$(%obj1.getClassName())
	{
		case "Player":
			%cl1 = %obj1.client;
			%zombie1 = (%usingIbanZombies && %obj1.isZombie);
		case "AIPlayer":
			%zombie1 = %obj1.isZombie;
			if(isObject(%obj1.client))
			{
				%cl1 = %obj1.client;
			}
			else if(isObject(%obj1.spawnBrick) && %usingTDM)
			{
				%team1 = %obj1.spawnBrick.tdmAlliedTeam-1;
			}
		case "Projectile":
			%zombie1 = (isObject(%obj1.sourceObject) && (%obj1.sourceObject.getType() & $TypeMasks::PlayerObjectType) && %obj1.sourceObject.isZombie);
			%cl1 = %obj1.client;
		case "GameConnection":
			%zombie1 = (%obj1.player.isZombie);
			%cl1 = %obj1;
		case "AIConnection":
			%zombie1 = (%obj1.player.isZombie);
			%cl1 = %obj1;
		default:
			return -1;
	}
	if(%usingTDM && %tdmTeam1 $= "" && isObject(%cl1))
	%team1 = %cl1.tdmTeam;
	switch$(%obj2.getClassName())
	{
		case "Player":
			%cl2 = %obj2.client;
			%zombie2 = (%usingIbanZombies && %obj2.isZombie);
		case "AIPlayer":
			%zombie2 = %obj2.isZombie;
			if(isObject(%obj2.client))
			%cl2 = %obj2.client;
			else if(isObject(%obj2.spawnBrick) && %usingTDM)
			%team2 = %obj2.spawnBrick.tdmAlliedTeam-1;
		case "Projectile":
			%zombie2 = (isObject(%obj2.sourceObject) && (%obj2.sourceObject.getType() & $TypeMasks::PlayerObjectType) && %obj2.sourceObject.isZombie);
			%cl2 = %obj2.client;
		case "GameConnection":
			%zombie2 = (%obj2.player.isZombie);
			%cl2 = %obj2;
		case "AIConnection":
			%zombie2 = (%obj2.player.isZombie);
			%cl2 = %obj2;
		default:
			return -1;
	}
	if(%usingTDM && %tdmTeam2 $= "" && isObject(%cl2))
	%team2 = %cl2.tdmTeam;	
	if(%usingTDM && %team1 == %team2)
	{
		if(%team1 == -1)
		return %usingRotZombies;
		
		return 1;
	}
	if(%usingIbanZombies || %usingRotZombies)
	{
		return (%zombie1 == %zombie2);
	}
	return 0;
}