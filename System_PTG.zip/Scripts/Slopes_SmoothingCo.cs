function Slopes_SmoothingCo()
{	
	%ChPxR = mAbs($ChPx);
	%ChPyR = mAbs($ChPy);

	while(%ChPxR >= $TerSS)
		%ChPxR = %ChPxR - $TerSS;
	while(%ChPyR >= $TerSS)
		%ChPyR = %ChPyR - $TerSS;
	if($ChPx < 0 && %ChPxR > 0)
		%ChPxR = $TerSS - %ChPxR;
	if($ChPy < 0 && %ChPyR > 0)
		%ChPyR = $TerSS - %ChPyR;

	////////////////////

	%CaCo = 1;
	%CbCo = 1;

	for($Cy=0;$Cy<$ChS;$Cy=$Cy+2)
	{
		if($SCoV>0)
		{
			if(($Cy < $ChSof && $Cy >= 0) || ($Cy < $ChStf && $Cy >= $ChSoh))
				%CaCo = %CaCo + $SCoV;
			if(($Cy < $ChSoh && $Cy >= $ChSof) || ($Cy < $ChS && $Cy >= $ChStf))
				%CaCo = %CaCo - $SCoV;
		}
		%CaHfs = ($BLCH - (($BLCH - $TLCH) / $TerSS) * (%ChPyR+$Cy)) / %CaCo;

		///////////////////

		if($SCoV>0)
		{
			if(($Cy < $ChSof && $Cy >= 0) || ($Cy < $ChStf && $Cy >= $ChSoh))
				%CbCo = %CbCo + $SCoV;
			if(($Cy < $ChSoh && $Cy >= $ChSof) || ($Cy < $ChS && $Cy >= $ChStf))
				%CbCo = %CbCo - $SCoV;
		}
		%CbHfs = ($BRCH - (($BRCH - $TRCH) / $TerSS) * (%ChPyR+$Cy)) / %CbCo;
		
		////////////////////

		%RCo = 1;

		for($Cx=0;$Cx<$ChS;$Cx=$Cx+2)
		{
			if($SCoV>0)
			{
				if(($Cx < $ChSof && $Cx >= 0) || ($Cx < $ChStf && $Cx >= $ChSoh))
					%RCo = %RCo + $SCoV;
				if(($Cx < $ChSoh && $Cx >= $ChSof) || ($Cx < $ChS && $Cx >= $ChStf))
					%RCo = %RCo - $SCoV;
			}
			$RHfs = (%CaHfs - ((%CaHfs - %CbHfs) / $TerSS) * (%ChPxR+$Cx)) / %RCo;

			////////////////////

			if($NN>1)
			{
				GetHeightValues_BiomeA();
				GetHeightValues_BiomeB();
			}
			if($PrevPass==0)
			{
				if($MTPass==0)
				{
					if($Norm==1)
					{
						if($SolG==1)
						{
							if($Cav==1)
								CreateChunk_Normal_SolidG_Caves();
							if($Cav==0)
								CreateChunk_Normal_SolidG_NoCaves();
						}
						if($SolG==0)
						{
							if($Cav==1)
								CreateChunk_Normal_EmptyG_Caves();
							if($Cav==0)
								CreateChunk_Normal_EmptyG_NoCaves();
						}
					}
					if($FloI==1)
					{
						if($SolG==1)
							CreateChunk_FloatingIslands_SolidG();
						if($SolG==0)
							CreateChunk_FloatingIslands_EmptyG();
					}
					if($Plai==1)
					{
						if($SolG==1)
							CreateChunk_Plains_SolidG();
						if($SolG==0)
							CreateChunk_Plains_EmptyG();
					}
					if($Clo==1)
						CreateChunk_Clouds();
				}
				if($MTPass==1)
				{
					CreateChunk_ModTer_DetPass();

					if($Norm==1 && $db!$=NA)
					{
						if($SolG==1)
						{
							if($Cav==1)
								CreateChunk_ModTer_Normal_SolidG_Caves();
							if($Cav==0)
								CreateChunk_ModTer_Normal_SolidG_NoCaves();
						}
						if($SolG==0)
						{
							if($Cav==1)
								CreateChunk_ModTer_Normal_EmptyG_Caves();
							if($Cav==0)
								CreateChunk_ModTer_Normal_EmptyG_NoCaves();
						}
					}
					if($FloI==1 && $db!$=NA)
						CreateChunk_ModTer_FloatingIslands_SolidGandEmptyG();
				}
			}
			if($PrevPass==1)
				CreateChunk_PTGPreview();
		}
	}
	if($PrevPass==1)
		schedule($ChBD,0,PTGPass);
	if($PrevPass==0)
	{
		deleteVariables("$WArray*");
		schedule($ChBD,0,PTGPass);
	}		
}
function Slope_BiomeA()
{
	%ChPxBio = mAbs($ChPx);
	%ChPyBio = mAbs($ChPy);

	while(%ChPxBio >= $BioSS)
		%ChPxBio = %ChPxBio - $BioSS;
	while(%ChPyBio >= $BioSS)
		%ChPyBio = %ChPyBio - $BioSS;
	if($ChPx < 0 && %ChPxBio > 0)
		%ChPxBio = $BioSS - %ChPxBio;
	if($ChPy < 0 && %ChPyBio> 0)
		%ChPyBio = $BioSS - %ChPyBio;

	%BioCx = %ChPxBio + $Cx;
	%BioCy = %ChPyBio + $Cy;

	%CaHfsBio = $BLCHBio - ((($BLCHBio - $TLCHBio) / $BioSS) * %BioCy);
	%CbHfsBio = $BRCHBio - ((($BRCHBio - $TRCHBio) / $BioSS) * %BioCy); 
	$RHfsBio = %CaHfsBio - (((%CaHfsBio - %CbHfsBio) / $BioSS) * %BioCx);
}
function Slope_BiomeB()
{
	%ChPxBiob = mAbs($ChPx);
	%ChPyBiob = mAbs($ChPy);

	while(%ChPxBiob >= $BioSS)
		%ChPxBiob = %ChPxBiob - $BioSS;
	while(%ChPyBiob >= $BioSS)
		%ChPyBiob = %ChPyBiob - $BioSS;
	if($ChPx < 0 && %ChPxBiob > 0)
		%ChPxBiob = $BioSS - %ChPxBiob;
	if($ChPy < 0 && %ChPyBiob > 0)
		%ChPyBiob = $BioSS - %ChPyBiob;

	%BioCxb = %ChPxBiob + $Cx;
	%BioCyb = %ChPyBiob + $Cy;

	%CaHfsBiob = $BLCHBiob - ((($BLCHBiob - $TLCHBiob) / $BioSS) * %BioCyb);
	%CbHfsBiob = $BRCHBiob - ((($BRCHBiob - $TRCHBiob) / $BioSS) * %BioCyb); 
	$RHfsBiob = %CaHfsBiob - (((%CaHfsBiob - %CbHfsBiob) / $BioSS) * %BioCxb);
}