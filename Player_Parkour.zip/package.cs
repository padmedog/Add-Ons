//~~Package~~\\

package Parkour
{
	function Armor::onAdd( %data, %this )
	{
		parent::onAdd( %data, %this );

		if( !%data.parkourPlayer )
		{
			return;
		}

		%this.climbs = 0;

		if( $PlayerParkour::FPSHands )
		{
			%this.mountImage( "parkourRightHandImage", 0 );
			%this.mountImage( "parkourLeftHandImage", 1 );
		}

		%this.parkourSpeedLoop();
	}

	function gameConnection::onDeath(%this,%obj,%killer,%type,%area)
	{
		commandToClient( %this, 'setVignette' ,$EnvGuiServer::VignetteMultiply, $EnvGuiServer::VignetteColor );
		parent::onDeath(%this,%obj,%killer,%type,%area);
	}

	function Armor::onTrigger( %data, %this, %trig, %tog )
	{
		Parent::onTrigger( %data, %this, %trig, %tog );

		if( !%data.parkourPlayer )
		{
			return;
		}

		if( !isEventPending( %this.parkourSpeedLoop ) )
		{
			if( $PlayerParkour::FPSHands )
			{
				%this.mountImage( "parkourRightHandImage", 0 );
				%this.mountImage( "parkourLeftHandImage", 1 );
			}

			%this.parkourSpeedLoop();
			echo("Starting speed loop from onTrigger!");
		}

		if ( %trig == 0 && %tog && %this.getMountedImage( 0 ) == nameToID( "parkourRightHandImage" ) )
		{
			%this.activateStuff();
		}

		if( %trig == 2 ) // Jump
		{
			%this.trigger[ 2 ] = %tog;

			if( %tog == 1 )
			{
				if( !%this.isClimbing )
				{
					%this.climbLoop();
				}
			}
		}
		if( %trig == 3 ) // Crouch
		{
			%this.trigger[ 3 ] = %tog;
			if( %tog == 1 )
			{
				if( %this.isOnGround() )
				{
					%this.doSlide();
				}
			}

			if( %tog == 0 )
			{
				if( %this.isSliding )
				{
					cancel( %this.stopSliding );
					%this.stopSliding();
				}
			}
		}
		if( %trig == 4 ) // Jet
		{
			%this.trigger[ 4 ] = %tog;

			if( %tog == 1 )
			{
				%this.parkourRightTrigger();
			}
		}
	}

	function player::damage( %this, %sourceObject, %position, %damage, %damageType )
	{
		%data = %this.getDataBlock();
		%maxhealth = %data.MaxDamage;
		%health = %maxhealth - %this.getDamageLevel() - %damage;

		if( !%data.ParkourPlayer )
		{
			parent::damage( %this, %sourceObject, %position, %damage, %damageType );
			return;
		}

		if( $damagetype_Array[%damageType] $= "Fall" )
		{
			%speed = VectorLen( %this.GetVelocity() );
			if( %speed >= %data.minImpactSpeed )
			{
				if( %this.trigger[ 3 ] )
				{
					%damage = %damage * 1.35;
					if( %speed <= %data.minImpactSpeed * 1.5 )
					{
						%this.doRoll();
						return;
					}
				}

				if( %health <= 0 )
				{
					serverPlay3D( parkourFallSound, %this.getHackPosition() );
				}
				else
				{
					serverPlay3D( parkourFallSoftSound, %this.getHackPosition() );
				}
			}
		}
		parent::damage( %this, %sourceObject, %position, %damage, %damageType );
	}

	function player::unmountImage( %this, %slot )
	{
		parent::unmountImage( %this, %slot );
		if( !%this.getDataBlock().parkourPlayer || !$PlayerParkour::FPSHands )
		{
			return;
		}

		if ( %slot == 0 )
		{
			%this.mountImage( "parkourRightHandImage", %slot );
		}
		else if ( %slot == 1 )
		{
			%this.mountImage( "parkourLeftHandImage", %slot );
		}
		// else if ( %slot == 3 )
		// {
		// 	%this.mountImage( "parkourRightShoeImage", %slot );
		// }
		// else if ( %slot == 4 )
		// {
		// 	%this.mountImage( "parkourLeftShoeImage", %slot );
		// }
	}
};
activatePackage( "Parkour" );