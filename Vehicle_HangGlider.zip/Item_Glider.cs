datablock ItemData(GliderItem)
{
	category = "Item";  // Mission editor category

	equipment = true;

	//its already a member of item namespace so dont break it
	//className = "Item"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./glideritem.1.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Hang Glider";
	iconName = "./icon_glider";
	doColorShift = true;
	colorShiftColor = "0.820 0.820 0.860 1.000";
	
	 // Dynamic properties defined by the scripts
	image = GliderWeaponImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(GliderWeaponImage)
{
   // Basic Item properties
   shapeFile = "./glideritem.1.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";
   eyeRotation = eulerToMatrix("0 0 0");

   doColorShift = true;
	colorShiftColor = GliderItem.colorShiftColor;
   

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = GliderItem;

   //melee particles shoot from eye node for consistancy
   melee = true;
   //raise your arm up or not
   armReady = true;

   //casing = " ";

   doColorShift = true;
   colorShiftColor = GliderItem.colorShiftColor; //"0.200 0.200 0.200 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]       = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire";
	stateTransitionOnTriggerUp[2]	= "Ready";
	stateScript[2]                  = "onFire";
};

function  GliderWeaponImage::onFire(%this, %obj, %slot)
{
	%player = %obj;

	if(%player.isMounted())
	{
		%mountedVehicleName = %player.getObjectMount().getDataBlock().getName();
		
		if(%mountedVehicleName !$= "hangGliderVehicle")
		{	
			//we're mounted on some other kind of vehicle
			commandToClient(%player.client, 'CenterPrint', "\c4Can\'t use hang gliders right now.", 2);
			//messageClient(%player.client, 'Clientmsg', 'Can\'t use hang gliders right now.');
			return;
		}
		else
		{
			//we're mounted on a skiVehicle, so stop skiing
			%player.stopSkiing();
			%player.unMount();
			
		}
	}
	else
	{
			%player.startGliding();
			//messageClient(%player.client, 'MsgEquipInv', '', %InvPosition);
			commandToClient(%player.client,'setScrollMode', -1);

			//%player.isEquiped[%invPosition] = true;
			%player.unMountimage(%slot);

			//messageClient(%player.client, 'CenterPrint', 'Can\'t use skis while moving.');
	}
}
function GliderItem::onUse(%this, %player, %InvPosition)
{

	%playerData = %player.getDataBlock();
	%client = %player.client;

	if(%player.getObjectMount())
		%mountedVehicleName = %player.getObjectMount().getDataBlock().getName();
		
	//if(%mountedVehicleName !$= "skiVehicle")
	//{
		%player.updateArm(GliderWeaponImage);
		%player.MountImage(GliderWeaponImage, 0);
	//}

	return;

	if(%player.isMounted())
	{
		%mountedVehicleName = %player.getObjectMount().getDataBlock().getName();
		
		if(%mountedVehicleName !$= "HangGliderVehicle")
		{	
			//we're mounted on some other kind of vehicle
			messageClient(%player.client, 'Clientmsg', 'Can\'t use hang gliders right now.');
			return;
		}
		else
		{
			//we're mounted on a skiVehicle, so stop skiing
			%player.stopSkiing();
		}
	}
	else
	{
			%player.startGliding();
			messageClient(%player.client, 'MsgEquipInv', '', %InvPosition);
			%player.isEquiped[%invPosition] = true;
	}
}


function Player::startGliding(%obj)
{	
	//make a new ski vehicle and mount the player on it
	%client = %obj.client;
	%position = %obj.getTransform();
	%posX = getword(%position, 0);
	%posY = getword(%position, 1);
	%posZ = getword(%position, 2);
	%rot = getWords(%position, 3, 8);

	%posZ += 0.3;

	//%vehicle.setNodeColor(<node or "ALL">, getColorTableId(%client.colorVar));

	%vel = %obj.getVelocity();

	%newcar = new WheeledVehicle() 
	{
		dataBlock = HangGlidervehicle;
		client = %client;
		initialPosition = %posX @ " " @ %posY @ " " @ %posZ;
	};
   MissionCleanup.add(%newcar);

	%color = getColorIDTable(%client.currentColor);

	%newcar.setVelocity(%vel);
	%newcar.setTransform(%posX @ " " @ %posY @ " " @ %posZ @ " " @ %rot);
	%newcar.schedule(1, mountObject, %obj, 0);
	%newcar.setNodeColor("ALL", %color);

}







datablock WheeledVehicleData(HangGliderVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./glider.1.dts"; //"~/data/shapes/glider.1.dts"; //
	emap = true;
	minMountDist = 3;
   
   numMountPoints = 1;
   mountThread[0] = "crouch";

	maxDamage = 10.00;
	destroyedLevel = 200.00;
	energyPerDamagePoint = 160;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0";
   //massBox = "2 5 1";

	maxSteeringAngle = 0.9785;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 6;         // Far distance from vehicle
	cameraOffset = 3.5;        // Vertical offset from camera mount point
	cameraLag = 0.2;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.3;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

   numWheels = 0;

	// Rigid Body
	mass = 100;
	density = 5.0;
	drag = 0.1;
	bodyFriction = 0.2;
	bodyRestitution = 0.2;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 12000; //4000;       // Engine power
	engineBrake = 2000;         // Braking when throttle is 0
	brakeTorque = 4000;        // When brakes are applied
	maxWheelSpeed = 20;        // Engine scale by current speed / max speed

	rollForce		= 1400;
	yawForce		= 1400;
	pitchForce		= 1400;
	rotationalDrag		= 0.4;

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

   isSled = false;

   forwardThrust		= 10;
	reverseThrust		= 10;
	lift			= 70;
	maxForwardVel		= 60;
	maxReverseVel		= 3;
	horizontalSurfaceForce	= 10;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 130; 
	rollForce		= 1400;
	yawForce		= 1400;
	pitchForce		= 1400;
	rotationalDrag		= 0.4;
	stallSpeed		= 2;

//   forwardThrust		= 2000;
//	reverseThrust		= 2000;
//	lift			= 100;
//	maxForwardVel		= 70;
//	maxReverseVel		= 70;
//	horizontalSurfaceForce	= 100;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
//	verticalSurfaceForce	= 100; 
//	rollForce		= 6000;
//	yawForce		= 6000;
//	pitchForce		= 4000;
//	rotationalDrag		= 0.5;
//	stallSpeed		= 10;
//
//   forwardThrust		= 2500;
//	reverseThrust		= 500;
//	lift			= 15000;
//	maxForwardVel		= 60;
//	maxReverseVel		= 10;
//	horizontalSurfaceForce	= 500;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
//	verticalSurfaceForce	= 500; 
//	rollForce		= 5000;
//	yawForce		= 5000;
//	pitchForce		= 5000;
//	rotationalDrag		= 0.1;
//	stallSpeed		= 10;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "";
	rideable = true;
		lookUpLimit = 0.55;
		lookDownLimit = 0.52;

	paintable = true;
   
   damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

   initialExplosionProjectile = vehicleExplosionProjectile;
   initialExplosionOffset = 0;         //offset only uses a z value for now

   burnTime = 10;

   finalExplosionProjectile = vehicleFinalExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now


   minRunOverSpeed    = 2;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 5;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed

   minContrailSpeed = 30;

   steeringUseStrafeSteering = false; //this vehicle has pitch control, so we can't use strafe steering
};
datablock ParticleData(HangcontrailParticle)
{
   dragCoefficient      = 0;
   windCoefficient     = 0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/cloud";
   colors[0]     = "0.8 0.8 1 0";
   colors[1]     = "1 1 1 1";
   colors[2]     = "0.2 0.2 1 0";
   sizes[0]      = 0.17;
   sizes[1]      = 0.16;
   sizes[2]      = 0.11;
};

datablock ParticleEmitterData(HangcontrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "HangcontrailParticle";
};

datablock ShapeBaseImageData(HangContrailImage1)
{
   shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 1;
   rotation = "1 0 0 -90";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= HangContrailEmitter;
	stateEmitterTime[1]				= 10000;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function HangContrailImage1::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
datablock ShapeBaseImageData(HangContrailImage2)
{
   	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 2;
   	rotation = "1 0 0 -90";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= HangContrailEmitter;
	stateEmitterTime[1]				= 10000;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function HangContrailImage2::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

function HangcontrailCheck(%obj)
{
//	return;
	if(!isObject(%obj))
		return;

	%speed = vectorLen(%obj.getVelocity());
	if(%speed < %obj.dataBlock.minContrailSpeed)
	{
		if(%obj.getMountedImage(3) !$= "")
		{
			%obj.unMountImage(2);
			%obj.unMountImage(3);
		}
	}
	else
	{
		if(%obj.getMountedImage(3) $= 0)
		{
			%obj.mountImage(hangcontrailImage1,2);
			%obj.mountImage(hangcontrailImage2,3);
		}
	}

	schedule(2000,0,"HangcontrailCheck",%obj);
}

function HangGlidervehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);

	HangcontrailCheck(%obj);	    
}


function HangGliderVehicle::onDriverLeave(%this, %obj, %player)
{
	//echo("**************** skiVehicle::onDriverLeave ", %this, " ", %obj, " player=", %player);

	if(isObject(%player))
		%player.stopSkiing();

	%obj.setTransform("0 0 -9999");
	%obj.schedule(10, delete);
}

function HangGliderVehicle::onImpact(%this,%obj)
{
	//echo("skivehicle impact");
	%trans = %obj.getTransform();
	%p = new Projectile()
	{
		dataBlock = skiImpactAProjectile;
		initialVelocity  = "0 0 0";
		initialPosition  = %trans;
		sourceObject     = %obj;
		sourceSlot       = 0;
		client           = %obj.client;
	};
	MissionCleanup.add(%p);
}

function HangGliderVehicle::onUnMount(%this, %obj)
{
	%obj.delete();
}



