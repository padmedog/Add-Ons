exec("./blrsServer.cs");
exec("./serverPoster.cs");
exec("./serverOther.cs");
exec("./bvss.cs");
exec("./autosaver.cs"); //doesn't automatically autosave
exec("./playerStatsServer.cs");
exec("./buffetServer.cs");

$systemVersion::server = 1.3;

function servercmdsystemAck(%client)
{
	%client.hasTheSystem = true;
}

function servercmdsystem(%client)
{
	messageclient(%client,'',"Yes.  v" SPC $systemVersion::server);
}

function servercmdsystembe(%client)
{
	messageclient(%client,'',"Yes.  v" SPC $systemVersion::server);
}

function servercmdsystemse(%client)
{
	messageclient(%client,'yesse');
}

package sendStatNames
{
	function GameConnection::autoAdminCheck(%this)
	{
		%ret = parent::autoAdminCheck(%this);
		schedule(500,0,commandtoclient,%this,'systemAckbe',$systemVersion::server);
		return %ret;
	}
};
activatepackage(sendStatNames);
