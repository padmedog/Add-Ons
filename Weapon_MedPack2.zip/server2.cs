%error = forceRequiredAddOn("Weapon_MedPack1");
if(%error $= $Error::AddOn_NotFound)
{
	error("ERROR: Weapon_MedPack2 - required add-on Weapon_MedPack1 not found");
}
else
{
	exec("./Halberd.cs");
	exec("./WarBow.cs");
	exec("./WarAxe.cs");
	exec("./CompactBow.cs");
	exec("./BattleAxe.cs");
	exec("./BombShotBow.cs");
}