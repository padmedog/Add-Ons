//----BOSSES Standard----

//500 Health
datablock PlayerData(PlayerBoss500Health : PlayerStandardArmor)
{
	maxDamage = 500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 500Hp";
	showEnergyBar = false;
};


//750 health
datablock PlayerData(PlayerBoss750Health : PlayerStandardArmor)
{
	maxDamage = 750;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 750Hp";
	showEnergyBar = false;
};


//1000 health
datablock PlayerData(PlayerBoss1000Hp : PlayerStandardArmor)
{
	maxDamage = 1000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 1000Hp";
	showEnergyBar = false;
};


//1500 health
datablock PlayerData(PlayerBoss1500Hp : PlayerStandardArmor)
{
	maxDamage = 1500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 1500Hp";
	showEnergyBar = false;
};


//2500 health
datablock PlayerData(PlayerBoss2500Hp : PlayerStandardArmor)
{
	maxDamage = 2500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 2500Hp";
	showEnergyBar = false;
};


//5000 health
datablock PlayerData(PlayerBoss5000Hp : PlayerStandardArmor)
{
	maxDamage = 5000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 5000Hp";
	showEnergyBar = false;
};

//7500 health
datablock PlayerData(PlayerBoss7500Hp : PlayerStandardArmor)
{
	maxDamage = 7500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 7500Hp";
	showEnergyBar = false;
};


//10000 health
datablock PlayerData(PlayerBoss10000Hp : PlayerStandardArmor)
{
	maxDamage = 10000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 10000Hp";
	showEnergyBar = false;
};


//----BOSSES Slow----

//500 health
datablock PlayerData(PlayerBoss500HpSlow : PlayerStandardArmor)

{


   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 500Hp Slow";
	showEnergyBar = false;
};


//750 health
datablock PlayerData(PlayerBoss750HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 750;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 750Hp Slow";
	showEnergyBar = false;
};


//1000 health
datablock PlayerData(PlayerBoss1000HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 1000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 100Hp Slow";
	showEnergyBar = false;
};


//1500 health
datablock PlayerData(PlayerBoss1500HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 1500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 1500Hp Slow";
	showEnergyBar = false;
};


//2500 health
datablock PlayerData(PlayerBoss2500HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 2500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 2500Hp Slow";
	showEnergyBar = false;
};


//5000 health
datablock PlayerData(PlayerBoss5000HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 5000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 5000Hp Slow";
	showEnergyBar = false;
};

//7500 health
datablock PlayerData(PlayerBoss7500HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 7500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 7500Hp Slow";
	showEnergyBar = false;
};


//10000 health
datablock PlayerData(PlayerBoss10000HpSlow : PlayerStandardArmor)
{

   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;
   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

	maxDamage = 10000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 10000Hp Slow";
	showEnergyBar = false;
};


//----Bosses Fast----

//500 health
datablock PlayerData(PlayerBoss500HpFast : PlayerStandardArmor)

{


   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 500Hp Fast";
	showEnergyBar = false;
};


//750 health
datablock PlayerData(PlayerBoss750HpFast : PlayerStandardArmor)
{

   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 750;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 750Hp Fast";
	showEnergyBar = false;
};


//1000 health
datablock PlayerData(PlayerBoss1000HpFast : PlayerStandardArmor)
{


   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 1000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 1000Hp Fast";
	showEnergyBar = false;
};


//1500 health
datablock PlayerData(PlayerBoss1500HpFast : PlayerStandardArmor)
{


   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 1500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 1500Hp Fast";
	showEnergyBar = false;
};


//2500 health
datablock PlayerData(PlayerBoss2500HpFast : PlayerStandardArmor)
{


   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 2500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 2500Hp Fast";
	showEnergyBar = false;
};


//5000 health
datablock PlayerData(PlayerBoss5000HpFast : PlayerStandardArmor)
{


   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 5000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 5000Hp Fast";
	showEnergyBar = false;
};

//7500 health
datablock PlayerData(PlayerBoss7500HpFast : PlayerStandardArmor)
{


   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 7500;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 7500Hp Fast";
	showEnergyBar = false;
};


//10000 health
datablock PlayerData(PlayerBoss10000HpFast : PlayerStandardArmor)
{

   runForce = 100 * 150;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;
   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	maxDamage = 10000;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Boss 10000Hp Fast";
	showEnergyBar = false;
};