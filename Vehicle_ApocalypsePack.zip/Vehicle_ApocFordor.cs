datablock WheeledVehicleSpring(ApocFordorSedanSpring)
{
	length = 0.3;
	force = 7000;
	damping = 600;
	antiSwayForce = 3;
	
};

datablock WheeledVehicleTire(ApocFordorSedanTire)
{
	shapeFile = "./Apocfordortire.dts";

	mass = 10;
	radius = 1;
	staticFriction = 5;
	kineticFriction = 5;
	restitution = 0.5;	

	lateralForce = 18000;
	lateralDamping = 4000;
	lateralRelaxation = 0.01;

	longitudinalForce = 14000;
	longitudinalDamping = 2000;
	longitudinalRelaxation = 0.01;
};

datablock DebrisData(ApocFordorSedanTireDebris)
{
	emitters = "JeepTireDebrisTrailEmitter";

	shapeFile = "./Apocfordortire.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ExplosionData(ApocFordorSedanExplosion : vehicleExplosion)
{
	debris = ApocFordorSedanTireDebris;
	debrisNum = 4;
	debrisNumVariance = 0;
	debrisPhiMin = 0;
	debrisPhiMax = 360;
	debrisThetaMin = 40;
	debrisThetaMax = 85;
	debrisVelocity = 14;
	debrisVelocityVariance = 3;
};

datablock ProjectileData(ApocFordorSedanExplosionProjectile : vehicleExplosionProjectile)
{
	directDamage = 0;
	radiusDamage = 0;
	damageRadius = 0;
	explosion = ApocFordorSedanExplosion;

	directDamageType  = $DamageType::VehicleExplosion;
	radiusDamageType  = $DamageType::VehicleExplosion;

	explodeOnDeath = 1;

	armingDelay = 0;
	lifetime = 0;

	uiName = "";
};

datablock DebrisData(ApocFordorSedanDebris)
{
	emitters = "JeepDebrisTrailEmitter";

	shapeFile = "./ApocfordorWreck.dts";
	lifetime = 3.0;
	minSpinSpeed = -500.0;
	maxSpinSpeed = 500.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 3;
};


datablock WheeledVehicleData(ApocFordorSedanVehicle)
{
	category = "Vehicles";

	//- Render -
	shapeFile = "./ApocFordor.dts";
	emap = true;

	//- Physics -
	mass = 400;
	drag = 1.0;
	density = 5.0;

	//- Damage/Energy -
	maxEnergy = 100;
	maxDamage = 750;
	destroyedLevel = 750;
	isInvincible = false;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 0.0;
	collDamageMultiplier   = 5.0;

	//- Camera -
	useEyePoint = false;

	//- Vehicle Data -
	jetForce = 3000.0;
	jetEnergyDrain = 2.0;
	minJetEnergy = 30.0;
	massCenter = "0.0 0.0 0.0";
	massBox = "0.0 0.0 0.0";
	bodyRestitution = 0.6;
	bodyFriction = 0.6;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	minImpactSpeed = 10.0;
	softImpactSpeed = 10.0;
	hardImpactSpeed = 15.0;
	maxSteeringAngle = 0.9785;
	integration = 4;
	collisionTol = 0.1;
	contactTol = 0.01;
	cameraRoll = false;
	cameraLag = 0.0;
	cameraDecay = 0.75;
	cameraOffset = 7.5;
	cameraMaxDist = 10.0;
	cameraTilt = 0.4;

	damageEmitter[0] = ApocCriticalDamageEmitter;
	damageEmitterOffset[0] = "0.0 3.125 1.0 ";
	damageLevelTolerance[0] = 0.60;

	//damageEmitter[1] = ApocCriticalDamageEmitter;
	//damageEmitterOffset[1] = "0.0 3.125 1.0 ";
	//damageLevelTolerance[1] = 0.9;

	//damageEmitter[2] = ApocFireDamageEmitter;
	//damageEmitterOffset[2] = "0.0 3.125 1.0 ";
	//damageLevelTolerance[2] = 0.9;

	numDmgEmitterAreas = 2;

	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;

	splashFreqMod = 300.0;
	splashVelEpsilon = 0.6;
	exitSplashSoundVelocity = 5.0;
	softSplashSoundVelocity = 0.0;
	mediumSplashSoundVelocity = 10.0;
	hardSplashSoundVelocity = 20.0;
	uiName = "Post Apocalyptic Fordor";
	rideAble = true;
	
	//- Wheeled Vehicle -
	maxWheelSpeed = 28.0;
	engineTorque = 10000.0;
	engineBrake = 4000.0;
	brakeTorque = 20000.0;
	rollForce =	900.0;
	yawForce = 600.0;
	pitchForce = 3000.0;
	rotationalDrag = 0.2;
	stallSpeed = 0.0;
	steeringUseAutoReturn = true;
	steeringAutoReturnRate = 0.9;
	steeringAutoReturnMaxSpeed = 10;
	steeringUseStrafeSteering = true;
	steeringStrafeSteeringRate = 0.1;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	tireEmitter = vehicleTireEmitter;

	//- Mounting -
	minMountDist = 3;
	numMountPoints = 4;
	mountThread[0] = "sit";
	mountThread[1] = "sit";
	mountThread[2] = "sit";
	mountThread[3] = "armreadyboth";
	lookUpLimit = 0.5;
	lookDownLimit = 0.5;

	//- Vehicle Damage -
	speedDamageScale = 1.04;
	collDamageMultiplier = 0.2;
	collDamageThresholdVel = 20.0;

	//- Passenger Protection -
	protectPassengersBurn = false;
	protectPassengersRadius = true;
	protectPassengersDirect = false;

	//- RunOver -
	minRunOverSpeed = 2.5;
	runOverDamageScale = 8.0;
	runOverPushScale = 1.2;

	//- Guns -
	ShootOnClick=1;
	ShootOnClick_Hold=1;
	ShootOnClick_ShootDelay=200;
	ShootOnClick_ReShootDelay=130;
	ShootOnClick_ProjectileCount=2;
	ShootOnClick_RequiredSlot=0;
	ShootOnClick_Sound=MGSHOT;

	ShootOnClick_Projectile[0]=ApocSideGunsProjectile;
	ShootOnClick_Position[0]="2 -2 1";
	ShootOnClick_Velocity[0]="200 0 0";
	ShootOnClick_Scale[0]="2 2 2";

	ShootOnClick_Projectile[1]=ApocSideGunsProjectile;
	ShootOnClick_Position[1]="2 2 1";
	ShootOnClick_Velocity[1]="200 0 0";
	ShootOnClick_Scale[1]="2 2 2";

	//- Misc -
	defaultTire	= ApocFordorSedanTire;
	defaultSpring = ApocFordorSedanSpring;
	numWheels = 4;
	paintable = true;
	initialExplosionProjectile = ApocFordorSedanExplosionProjectile;
	initialExplosionOffset = 0.0;
	finalExplosionProjectile = ApocFordorSedanFinalExplosionProjectile;
	finalExplosionOffset = 0.5;
	burnTime = 8000;

};



/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
// LINE TAKEN FROM TANK TO MOUNT THE TURRET

function ApocFordorSedanVehicle::onAdd(%this,%obj)
{
	parent::onadd(%this,%obj);

   // turret
   %t = new AIPlayer()
   {
      dataBlock = ApocHvyMGTurretPlayer;
   };
   MissionCleanup.add(%t);
   %obj.mountObject(%t, 3);
   %obj.turret = %t;
   %obj.isCloaked = 1;

   %obj.creationTime = getSimTime();
   %t.schedule(10,"ApocFordorSedanrigTurret");
}

function Player::ApocFordorSedanrigTurret(%obj)
{
   if(%obj.dataBlock !$= ApocHvyMGTurretPlayer)
	   return;

   if(!isObject(%obj))
	   return;

   %parent = %obj.getObjectMount();
   if(!isObject(%parent))
	   return;

   %obj.spawnBrick = %parent.spawnBrick;
   %obj.isCloaked = 1;
   %obj.brickGroup = %parent.brickGroup;
}

function ApocFordorSedanVehicle::onRemove(%this,%obj)
{
   if(isObject(%obj.turret))
	   %obj.turret.delete();
}

package ApocFordorSedanPackage
{
   function Player::burn(%obj,%time)
   {
      if(%obj.dataBlock $= ApocHvyMGTurretPlayer)
         return;
      else
         Parent::burn(%obj,%time);
   }

   function ShapeBase::setNodeColor(%obj,%node,%color)
   {
      Parent::setnodecolor(%obj,%node,%color);
      if(isObject(%obj.turret))
      {
         %obj.turret.setNodeColor("ALL",%color);
      }
   }

   function ApocFordorSedanVehicle::Damage(%this,%obj,%source,%pos,%amm,%type)
   {
      if((%obj.getDamageLevel()+%amm) >= %this.maxDamage)
      {
         if(%obj.destroyed)
            return;

         %obj.setNodeColor("ALL","0 0 0 1");
         if(isObject(%obj.turret))
         {
            %obj.turret.delete();
         }
         else
         {
            %p = new Projectile()
            {
               dataBlock = TankExplosionProjectile;
               initialPosition = vectorAdd(%obj.getPosition(),"0 0" SPC %this.initialExplosionOffset);
               initialVelocity = "0 0 1";
               client = %obj.lastDamageClient;
               sourceClient = %obj.lastDamageClient;
            };
            MissionCleanup.add(%p);
         }
         if(%obj.destroyed)
            return;

         %obj.setDamageLevel(%this.maxDamage);
         %obj.destroyed = 1;
         %obj.schedule(%this.burnTime,"finalExplosion");
         if(isObject(%obj.spawnBrick.client.minigame))
            %respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
         %obj.spawnBrick.schedule(%respawn,"spawnVehicle");
      }
      else
         Parent::Damage(%this,%obj,%source,%pos,%amm,%type);
   }

   function Player::emote(%obj,%emote)
   {
      if(%obj.dataBlock $= ApocHvyMGTurretPlayer)
	      return;
      Parent::emote(%obj,%emote);
   }

   function TankTurretPlayer::onDamage(%this,%obj,%ammount)
   {
      if(%obj.dataBlock $= ApocHvyMGTurretPlayer)
         return;
	   Parent::onDamage(%this,%obj,%ammount);
   }

   function ApocHvyMGTurretPlayer::onDisabled(%this,%obj,%state)
   {
      %obj.schedule(10,"delete");
      %player = %obj.getMountedObject(0);
      if(isObject(%player))
      {
         %obj.getObjectMount().schedule(10,"mountObject",%player,2);
      }
   }

   function ApocHvyMGTurretPlayer::Damage(%this,%obj,%source,%pos,%amm,%type)
   {
      //scale the damage ammount as if this was a vehicle
      %amm *= $Damage::VehicleDamageScale[%type];

      if(%obj.getDamageLevel()+%amm > %this.maxDamage)
         %obj.setDamageLevel(%this.maxDamage);
      else
         Parent::Damage(%this,%obj,%source,%pos,%amm,%type);
   }

   function armor::onMount(%this,%obj,%col,%slot)
   {
      Parent::onMount(%this,%obj,%col,%slot);
      if(%col.getDataBlock() == ApocFordorSedanVehicle.getId())
      {
         if(%slot $= 3)
         {
            %obj.setLookLimits(0.75,0);
         }
      }
      else if(%col.getDataBlock() == ApocHvyMGTurretPlayer.getId())
      {
         %client = %obj.client;
         if(isObject(%client))
            ServerCmdUnUseTool(%client);
      }
   }
};
activatepackage(ApocFordorSedanPackage);