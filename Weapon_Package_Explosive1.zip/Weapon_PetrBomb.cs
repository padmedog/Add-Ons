// DAMN MOLOTOV
// Y U EAT UP DATABLOCKS

datablock AudioProfile(molotovBurnSound)
{
   filename    = "./burn.wav";
   description = AudioClosest3d;
   preload = false;
};


///////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ParticleData(tMolotovTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.3;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 400;
	lifetimeVarianceMS	= 200;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

		textureName				= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
		colors[0]	= "1.0 1.0 0.3 0.0";
		colors[1]	= "1.0 1.0 0.3 0.1";
		colors[2]	= "0.6 0.0 0.0 0.0";
	sizes[0]	= 0.9;
	sizes[1]	= 0.2;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.1;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(tMolotovTrailEmitter)
{
ejectionPeriodMS	= 5;
periodVarianceMS	= 4;
ejectionVelocity	= 0;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0.05;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = tMolotovTrailParticle;
};

///////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ParticleData(tMolotovExplosionParticle)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 100;
	lifetimeVarianceMS	= 000;
	spinSpeed		= 5.0;
	spinRandomMin		= -5.0;
	spinRandomMax		= 5.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "1.0 1.0 0.3 0.0";
	colors[1]	= "1.0 1.0 0.3 0.1";
	colors[2]	= "0.6 0.0 0.0 0.0";
		
	sizes[0]	= 0.0;
	sizes[1]	= 9.0;
	sizes[2]	= 8.0;
	
	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(tMolotovExplosionEmitter)
{
		ejectionPeriodMS	= 5;
		periodVarianceMS	= 4;
		ejectionVelocity	= 0;
		ejectionOffset		= 0.50;
		velocityVariance	= 0.0;
		thetaMin			= 89;
		thetaMax			= 90;
		phiReferenceVel		= 0;
		phiVariance			= 360;
   overrideAdvance = false;
   particles = "tMolotovExplosionParticle";
};

///////////////////////////////////////////////////////////////////////////////////////////////////////

	datablock ParticleData(tierFireBomb2Particle)
	{
		textureName				= "base/data/particles/cloud";
		dragCoefficient			= 0.0;
		gravityCoefficient		= -3.0;
		inheritedVelFactor		= 0.5;
		windCoefficient			= 0;
		constantAcceleration	= 3.0;
		lifetimeMS				= 500;
		lifetimeVarianceMS		= 200;
		spinSpeed				= 0;
		spinRandomMin			= -90.0;
		spinRandomMax			=  90.0;
		useInvAlpha				= false;
		
		colors[0]	= "1 1 1 0.1";
		colors[1]	= "1.0 1.0 0.3 0.3";
		colors[2]	= "0.6 0.0 0.0 0.0";
		
		sizes[0]	= 2.0;
		sizes[1]	= 0.8;
		sizes[2]	= 0.1;
		
		times[0]	= 0.0;
		times[1]	= 0.2;
		times[2]	= 1.0;
	};

	datablock ParticleEmitterData(tierFireBomb2Emitter)
	{
		ejectionPeriodMS	= 5;
		periodVarianceMS	= 4;
		ejectionVelocity	= 0;
		ejectionOffset		= 0.50;
		velocityVariance	= 0.0;
		thetaMin			= 89;
		thetaMax			= 90;
		phiReferenceVel		= 0;
		phiVariance			= 360;
		overrideAdvance		= false;
		
		particles = tierFireBomb2Particle;  
	};

datablock DebrisData(tierFireDebris)
{
   emitters = "tierFireBomb2Emitter";

	lifetime = 10.0;
	minSpinSpeed = -500.0;
	maxSpinSpeed = 500.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = false;

	gravModifier = 4;
};

///////////////////////////////////////////////////////////////////////////////////////////////////////

	datablock ParticleData(tierFireBombParticle)
	{
		textureName				= "base/data/particles/cloud";
		dragCoefficient			= 0.0;
		gravityCoefficient		= -5.0;
		inheritedVelFactor		= 0.5;
		windCoefficient			= 0;
		constantAcceleration	= 3.0;
		lifetimeMS				= 400;
		lifetimeVarianceMS		= 200;
		spinSpeed				= 0;
		spinRandomMin			= -90.0;
		spinRandomMax			=  90.0;
		useInvAlpha				= false;
		
		colors[0]	= "1 1 1 0.1";
		colors[1]	= "1.0 1.0 0.3 0.3";
		colors[2]	= "0.6 0.0 0.0 0.0";
		
		sizes[0]	= 4.0;
		sizes[1]	= 1.7;
		sizes[2]	= 0.8;
		
		times[0]	= 0.0;
		times[1]	= 0.2;
		times[2]	= 1.0;
	};

	datablock ParticleEmitterData(tierFireBombEmitter)
	{
		ejectionPeriodMS	= 5;
		periodVarianceMS	= 4;
		ejectionVelocity	= 0;
		ejectionOffset		= 0.50;
		velocityVariance	= 0.0;
		thetaMin			= 89;
		thetaMax			= 90;
		phiReferenceVel		= 0;
		phiVariance			= 360;
		overrideAdvance		= false;
		
		particles = tierFireBombParticle;  
		
		uiName = "Tier Napalm"; 
	};

///////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ParticleData(tMolotovExplosionParticle2)
{
	dragCoefficient		= 9.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.5;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 14000;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]     = "1 1 1 0.1";
	colors[1]     = "0.1 0.05 0.0 0.2";
	colors[2]     = "0.1 0.05 0.0 0.0";

	sizes[0]	= 3.3;
	sizes[1]	= 14.5;
   sizes[2]	= 17.3;

	times[0]	= 0.0;
	times[1]	= 0.02;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(tMolotovExplosionEmitter2)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 14;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "tMolotovExplosionParticle2";
};

datablock ParticleData(tMolotovExplosionRing2Particle)
{
		textureName				= "base/data/particles/cloud";
		dragCoefficient			= 0.0;
		gravityCoefficient		= -5.0;
		inheritedVelFactor		= 0.5;
		windCoefficient			= 0;
		constantAcceleration	= 3.0;
		lifetimeMS				= 100;
		lifetimeVarianceMS		= 0;
		spinSpeed				= 0;
		spinRandomMin			= -90.0;
		spinRandomMax			=  90.0;
		useInvAlpha				= false;
		
		colors[0]	= "1.0 1.0 0.3 0.0";
		colors[1]	= "1.0 1.0 0.3 0.1";
		colors[2]	= "0.6 0.0 0.0 0.0";
		
		sizes[0]	= 0.0;
		sizes[1]	= 18.0;
		sizes[2]	= 14.0;
		
		times[0]	= 0.0;
		times[1]	= 0.1;
		times[2]	= 1.0;
};
datablock ParticleEmitterData(tMolotovExplosionRing2Emitter)
{
	lifeTimeMS = 33;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 22;
   velocityVariance = 1.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "tMolotovExplosionRing2Particle";
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ExplosionData(tMolotovPlayerExplosion)
{
   lifeTimeMS = 150;

   particleEmitter = tierFirebombEmitter;
   particleDensity = 10;
//   particleDensity = 0;
   particleRadius = 1.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   //impulse
   impulseRadius = 0;

   damageRadius = 0;
};

datablock ExplosionData(tMolotovExplosion)
{
   explosionShape = "Add-Ons/Weapon_Rocket_Launcher/explosionSphere1.dts";
   lifeTimeMS = 150;

   soundProfile = tierFragGrenadeExplosionSound;

   debris = tierFireDebris;
   debrisNum = 15;
   debrisNumVariance = 3;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 20;
   debrisVelocity = 15;
   debrisVelocityVariance = 10;
   
   //emitter[0] = tMolotovExplosionRingEmitter;
   emitter[1] = tMolotovExplosionEmitter;
   emitter[2] = tMolotovExplosionRing2Emitter;
   //emitter[1] = "";
   //emitter[2] = "";
   //emitter[0] = "";

   particleEmitter = tMolotovExplosionEmitter2;
   particleDensity = 10;
//   particleDensity = 0;
   particleRadius = 1.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 9;
   impulseForce = 1900;

   damageRadius = 6;
   radiusDamage = 20;

	uiName = "Big Grenade Explosion";
};

datablock ExplosionData(tierFireSparkExplosion)
{
   lifeTimeMS = 150;

   //particleEmitter = tMolotovExplosionEmitter2;
   //particleDensity = 90;
//   particleDensity = 0;
   particleRadius = 1.0;

   //faceViewer     = true;
   //explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "1.0 1.0 0.3";
   lightEndColor = "1.0 1.0 0.3";

   damageRadius = 5;
   radiusDamage = 5;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

AddDamageType("TfiregrenadeDirect",   '<bitmap:add-ons/weapon_package_explosive1/ci_molotov> %1',    '%2 <bitmap:add-ons/weapon_package_explosive1/ci_molotov> %1',1,1);

//projectile
datablock ProjectileData(tMolotovProjectile)
{
   projectileShapeName = "./molotov.dts";
   directDamage        = 10;
   directDamageType  = $DamageType::TstickGrenadeDirect;
   radiusDamageType  = $DamageType::TstickGrenadeDirect;
   impactImpulse	   = 1200;
   verticalImpulse	   = 1200;
   explosion           = tMolotovExplosion;
   particleEmitter     = tMolotovTrailEmitter;

   muzzleVelocity      = 55;
   velInheritFactor    = 0;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = true;  

   //fireExplosion        = TfireExplosion;
   brickExplosionRadius = 5;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 34;             
   brickExplosionMaxVolume = 45;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 90;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   armingDelay         = 0; 
   lifetime            = 4000;
   bounceAngle         = 120; //fire almost all the time
   minfireVelocity    = 10;
   fadeDelay           = 3999;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Molotov";
};

datablock ProjectileData(tierfireRoastProjectile)
{
   //projectileShapeName = "./fire_grenade.2.dts";
   directDamage        = 5;
   directDamageType  = $DamageType::TstickGrenadeDirect;
   radiusDamageType  = $DamageType::TstickGrenadeDirect;
   impactImpulse	   = 0;
   verticalImpulse	   = 0;
   //explosion           = tMolotovExplosion;
   particleEmitter     = tierFireBombEmitter;

   muzzleVelocity      = 25;
   velInheritFactor    = 0;
   explodeOnPlayerImpact = false;
   explodeOnDeath        = true;  

   //fireExplosion        = TfireExplosion;
   brickExplosionRadius = 1;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   armingDelay         = 13900; 
   lifetime            = 14000;
   fadeDelay           = 13999;
   bounceElasticity    = 0.7;
   bounceFriction      = 0.7;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Embers";

	PrjEmit_enabled = 1;
	PrjEmit_projectile =  tierfireSparkProjectile;
	PrjEmit_velocity = 10;
	PrjEmit_maxemits = 190;
	PrjEmit_ticktime = 300;
	PrjEmit_ammount = 1;
};

///////////////////////////////////////////////////////////////////////// this only exists to explode. ain't life grand

datablock ProjectileData(tierfireSparkProjectile)
{
//   projectileShapeName = "./nailgrenadedeployed.dts";
   directDamage        = 10;
   directDamageType  = $DamageType::TstickGrenadeDirect;
   radiusDamageType  = $DamageType::TstickGrenadeDirect;
   impactImpulse	   = 200;
   verticalImpulse	   = 200;
   //particleEmitter     = lightspeedSparkEmitter;
   explosion           = tierfireSparkExplosion;

   muzzleVelocity      = 29;
   velInheritFactor    = 1;
   explodeOnDeath = true;

   brickExplosionRadius = 1;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   explodeOnDeath = true;
   armingDelay         = 00; 
   lifetime            = 33;
   fadeDelay           = 33;
   bounceElasticity    = 0.6;
   bounceFriction      = 0.1;
   isBallistic         = true;
   gravityMod = 0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(tierfirePlayerProjectile)
{
//   projectileShapeName = "./nailgrenadedeployed.dts";
   directDamageType  = $DamageType::TstickGrenadeDirect;
   radiusDamageType  = $DamageType::TstickGrenadeDirect;
   //particleEmitter     = lightspeedSparkEmitter;
   explosion           = tMolotovPlayerExplosion;
   muzzleVelocity      = 0;
   velInheritFactor    = 0;
   explodeOnDeath = true;

   brickExplosionRadius = 1;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   explodeOnDeath = true;
   armingDelay         = 00; 
   lifetime            = 33;
   fadeDelay           = 33;
   bounceElasticity    = 0.6;
   bounceFriction      = 0.1;
   isBallistic         = true;
   gravityMod = 0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////
// item //
//////////
datablock ItemData(tMolotovItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./molotov_item.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	l4ditemtype = "grenade";

	//gui stuff
	uiName = "Molotov";
	iconName = "./molotovicon";

	 // Dynamic properties defined by the scripts
	image = tMolotovImage;
	canDrop = true;
};

datablock ShapeBaseImageData(tMolotovImage)
{
   // Basic Item properties
	shapeFile = "./molotov_item.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = tMolotovItem;
   ammo = " ";
   projectile = tMolotovProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = false;
   colorShiftColor = "0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state

	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.01;
	stateTransitionOnTimeout[0]	= "Ready";
	stateScript[0]                  = "onActivate";

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateScript[1]                  = "onReady";
	stateTransitionOnTimeout[1]	= "Ready";
	stateEmitter[1]					= tMolotovTrailEmitter;
	stateWaitForTimeout[1]		= false;
	stateEmitterTime[1]				= 0.4;
	stateEmitterNode[1]				= "firenode";
	stateTimeoutValue[1]		= 0.4;
	stateAllowImageChange[1]	= true;
	
	stateName[4]                    = "Charge";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.1;
	stateEmitter[4]					= tMolotovTrailEmitter;
	stateEmitterTime[4]				= 0.1;
	stateEmitterNode[4]				= "firenode";
	stateWaitForTimeout[4]		= false;
	stateScript[4]                  = "onCharge";
	stateAllowImageChange[4]        = true;
	
	stateName[5]			= "AbortCharge";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.1;
	stateWaitForTimeout[5]		= true;
	stateScript[5]			= "onAbortCharge";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Armed";
	stateScript[6]			= "onArmed";
	stateTransitionOnTriggerUp[6]	= "Fire";
	stateEmitter[6]					= tMolotovTrailEmitter;
	stateWaitForTimeout[6]		= false;
	stateTimeoutValue[6]		= 0.4;
	stateEmitterTime[6]				= 0.4;
	stateEmitterNode[6]				= "firenode";
	stateAllowImageChange[6]	= true;

	stateName[7]			= "Fire";
	stateTransitionOnTimeout[7]	= "Activate";
	stateTimeoutValue[7]		= 0.5;
	stateFire[7]			= true;
	stateSound[7]				= tierfraggrenadetossSound;
	stateSequence[7]		= "fire";
	stateScript[7]			= "onFire";
	stateWaitForTimeout[7]		= true;
	stateAllowImageChange[7]	= false;

	stateName[8]					= "Done";
	stateScript[8]					= "onDone";
	stateTransitionOnTimeout[8]	= "Activate";
	stateTimeoutValue[8]		= 0.5;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function tierFireSparkProjectile::onExplode(%this,%obj)
{
   parent::onExplode(%this, %obj);
   initContainerRadiusSearch(%obj.getPosition(),4,$TypeMasks::PlayerObjectType);
   while((%target = ContainerSearchNext()) != 0)
   {
      if(isObject(%obj.client.minigame) && %obj.client.minigame == %target.client.minigame && %obj.client.minigame.weapondamage == 1 && (%obj.client.tdmTeam != %target.client.tdmTeam || %obj.client == %target.client))
      {
		%pos = %target.getPosition();

		%target.spawnExplosion(tierFirePlayerProjectile,"1 1 1"); //not sure of arguments :V
		%target.client.play2D(molotovBurnSound);
		%target.damage(%obj, %pos, 4, $DamageType::TfireGrenadeDirect);
      }
      else if(isObject(%obj.client.minigame) && %obj.client.minigame == %target.client.minigame && %obj.client.minigame.weapondamage == 1 && %obj.client.tdmTeam == %target.client.tdmTeam)
      {
		%pos = %target.getPosition();

		%target.spawnExplosion(tierFirePlayerProjectile,"1 1 1"); //not sure of arguments :V
		%target.client.play2D(molotovBurnSound);
		%target.damage(%obj, %pos, 1, $DamageType::TfireGrenadeDirect);
      }
   }
}

function tMolotovprojectile::onExplode(%this,%obj)
{
   parent::onExplode(%this, %obj);
   //echo("Grenade Explosion");
   %shrapData = tierFireRoastProjectile;
   %position = %obj.getPosition();

   %shards = getRandom(3,4);

   for(%numbar=0; %numbar<%shards; %numbar++)
   {
      %vector = %position;

      %x = (getRandom(-3,3) - 0.5) * 3.141592653;
      %y = (getRandom(-3,3) - 0.5) * 3.141592653;
      %z = (getRandom(-3,3) - 0.5) * 3.141592653;

      //spawn them in random sphere locations.

      %velocity = %x SPC %y SPC %z;

      %shraps = new projectile()
      {
	 dataBlock = %shrapData;
	 initialVelocity = %velocity;
	 initialPosition = %position;
	 sourceObject = %obj;
	 sourceSlot = %obj.client.player.lasttierfireslot;
	 client = %obj.client;
      };
      MissionCleanup.add(%shraps);
      //echo(%obj.client.getplayername());
      //echo(%obj.client.player.getID());
   }
}

function tMolotovImage::onArmed(%this, %obj, %slot)
{
        commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Molotovs <font:impact:34>\c6 " @ %obj.client.quantity["molNades"] @ "", 1, 2, 3, 4); 

	%obj.playthread(2, spearready);
	%obj.lasttierfireslot = %obj.currTool;
}

function tMolotovImage::onFire(%this, %obj, %slot)
{
    	if(%obj.client.quantity["molNades"] >= 1)
	{
	Parent::OnFire(%this, %obj, %slot);
	%obj.client.quantity["molnades"] -= 1;
	}

    	if(%obj.client.quantity["molNades"] <= 0)
	{
	%obj.unMountImage(0);
	}

	%obj.playThread(2, spearthrow);
	serverPlay3D(tierfraggrenadetossSound,%obj.getPosition());

}

function tMolotovImage::onReady(%this, %obj, %slot)
{
            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Molotovs <font:impact:34>\c6 " @ %obj.client.quantity["molNades"] @ "", 1, 2, 3, 4); 

    	if(%obj.client.quantity["molNades"] <= 0)
	{
	%obj.unMountImage(0);
	%obj.playThread(2, root);
	%obj.playThread(1, root);
	%obj.playThread(0, root);
	}
}

function tMolotovImage::onCharge(%this, %obj, %slot)
{
	%obj.playThread(2, shiftDown);
    	if(%obj.client.quantity["molNades"] <= 0)
	{
	%obj.unMountImage(0);
	%obj.playThread(2, root);
	%obj.playThread(1, root);
	%obj.playThread(0, root);
	}
}