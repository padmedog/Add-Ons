datablock fxDTSBrickData (brickTPole1x1fData)
{
	brickFile = "./Brick_TPole1x1f.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1f Thick Pole";
	iconName = "Add-Ons/Brick_ThickPoles/1x1f";
};
datablock fxDTSBrickData (brickTPole1x1Data)
{
	brickFile = "./Brick_TPole1x1.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1 Thick Pole";
	iconName = "Add-Ons/Brick_ThickPoles/1x1";
};
datablock fxDTSBrickData (brickTPole1x3Data)
{
	brickFile = "./Brick_TPole1x3.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x3 Thick Pole";
	iconName = "Add-Ons/Brick_ThickPoles/1x3";
};