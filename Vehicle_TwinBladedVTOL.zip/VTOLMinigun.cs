datablock FlyingVehicleData(VTOLMinigunVehicle : TwinBladedVTOLVehicle)
{

      shapeFile   = "./VTOLMinigun.dts";  
     uiName   = "Minigun VTOL";

shootonclick=1;
shootOnClick_spread = 0.01;
shootonclick_Hold=1;
shootonclick_ShootDelay=100;
shootonclick_ReShootDelay=100;
shootonclick_ProjectileCount=1;
shootonclick_RequiredSlot=0;
shootonclick_Sound=gunshot1sound;

shootonclick_Projectile[0]=gunProjectile;
shootonclick_Position[0]="2.7 0 -3";
shootonclick_Velocity[0]="200 0 0";
shootonclick_Scale[0]="1 1 1";
};
datablock DebrisData(VTOLMinigunDebris : TwinBladedVTOLDebris)
{
	lifetime = 4.0;
};
datablock ExplosionData(VTOLMinigunVehicleExplosion : TwinBladedVTOLFinalExplosion)
{
   lightEndRadius = 21;
};
datablock ProjectileData(VTOLMinigunVehicleProjectile : TwinBladedVTOLFinalExplosionProjectile)
{
   radiusDamage        = 1;
};
function VTOLMinigunvehicle::onadd(%this,%obj)
{
	   %obj.playThread(0,"spin");
}
function VTOLMinigunVehicle::onImpact(%this, %obj, %data)
{
   %speed = vectorLen(%obj.getVelocity());
   if(%speed < 2)
      return;

   %p = new Projectile()
   {
      dataBlock = JeepExplosionProjectile;
      initialPosition = %obj.getPosition();
      client = %obj.lastDamageClient;
      sourceClient = %obj.lastDamageClient;
   };
   MissionCleanup.add(%p);

   if(%obj.destroyed)
      return;

   %obj.setDamageLevel(%this.maxDamage);
   %obj.destroyed = 1;
   %obj.schedule(%this.burnTime, "finalExplosion");
   if(isObject(getminigamefromobject(%obj)))
      %respawn = getminigamefromobject(%obj).vehicleReSpawnTime;
   %obj.spawnBrick.schedule(%respawn,"spawnVehicle");
}
