// ===================
// XChat Server
// ===================
// Authors: DarkLight, McTwist
// Description 
// Creates a connection between servers to share
// chats and some other messages.
// ===================

if (!$pref::CSM::Port)
{
	$pref::CSM::Port = 1212;
}

// List classes
exec("./list.cs");

//---------------------------------------------------------------------

// Receiver
function CrossServer_Receiver::onConnectRequest(%this, %addr, %id)
{
	while (strpos(%addr, ":") != -1)
		%addr = strreplace(%addr, ":", " ");
	
	%client = new TCPObject(CrossServer_Client, %id)
	{
		addr = getWord(%addr, 1);
		group = $CSM::Clients;
	};
	$CSM::Clients.add(%client);
	Chat_AddToList(%client.addr, 2);
}

function CrossServer_Receiver::onDisconnect(%this)
{
	messageAll('', '\c6%1\c3(\c6%2\c3) disconnected.', %this.name, %this.addr);
	Chat_RemoveFromList(%this.addr, 2);
}

//---------------------------------------------------------------------

// Transmit
function CrossServer_Transmit::onConnected(%this)
{
	// Send info data
	%this.send(%this.pass TAB "key" TAB %this.key TAB $pref::Player::NetName @ "\r\n");
	
	messageAll('', '\c3Connected to \c6%1\c3.', %this.addr);
	
	// Send to Super Admins
	Chat_AddToList(%this.addr, 1);
}

// Failure catches
function CrossServer_Transmit::onDNSFailed(%this)
{
	messageAll('', "\c3Failed DNS: \c6" @ %this.addr);
	%this.onDisconnect();
}

function CrossServer_Transmit::onConnectFailed(%this)
{
	messageAll('', "\c3Connection failed: \c6" @ %this.addr);
	%this.onDisconnect();
}

function CrossServer_Transmit::onTimedOut(%this)
{
	messageAll('', "\c3Connection timed out: \c6" @ %this.addr);
	%this.onDisconnect();
}

// Disconnecting
function CrossServer_Transmit::onDisconnect(%this)
{
	Chat_RemoveFromList(%this.addr, 1);
	%this.group.remove(%this);
	%this.schedule(0, delete);
}

//---------------------------------------------------------------------

function CrossServer_Client::onLine(%this, %line)
{
	if (%line $= "")
		return;

	%key = getField(%line, 0);
	%cmd = getField(%line, 1);

    if (%cmd $= "")
		return;

	// Have not got a key
	if (%this.key $= "")
	{
		// Check pass
		if (%key !$= $CSM::Pass)
		{
			// Disconnect
			%this.disconnect();
			%this.onDisconnect();
			return;
		}
		// Get a new key and name
		if (%cmd $= "key")
		{
			%this.key = getField(%line, 2);
			%this.name = getField(%line, 3);
			messageAll('', '\c6%1\c3 connected.', %this.name);
		}
		return;
	}
	
	// Security
	if (%key !$= %this.key)
		return;

	%server = "[" @ %this.name @ "'s Server]";
	
	switch$ (%cmd)
	{
		case "con":
			%name = getField(%line, 2);
			messageAll('', '\c1%1<color:noseep>%2\c1 connected.', %name, %server);
		case "dis":
			%name = getField(%line, 2);
			messageAll('', '\c1%1<color:noseep>%2\c1 has left the game.', %name, %server);
		case "msg":
			%name = getField(%line, 2);
			
			// Muting some players
			for (%i = 0; %i < $CSM::Mute.getCount(); %i++)
			{
				if (strpos(strlwr(%name), strlwr($CSM::Mute.at(%i))) != -1)
				{
					return;
				}
			}
			
			%message = getField(%line, 3);
			messageAll('', '%1<color:noseep>%2\c6: %3', %name, %server, %message);
			echo(stripmlcontrolchars(%name) @ %server @ ": " @ %message);
		default:
			echo("Invalid command: " @ %line);
	}
}

function CrossServer_Client::onDisconnect(%this)
{
	Chat_RemoveFromList(%this.addr, 2);
	messageAll('', '\c6%1\c3(\c6%2\c3) disconnected.', %this.name, %this.addr);
	// Remove itself
	%this.group.remove(%this);
	%this.schedule(0, delete);
}

//---------------------------------------------------------------------

package RemoteChat
{
	// Normal message
	function serverCmdMessageSent(%client, %message)
	{
		parent::serverCmdMessageSent(%client, %message);
		
		sendToAllServers("msg", "\c7" @ %client.clanPrefix @ "\c3" @ %client.name @ "\c7" @ %client.clanSuffix TAB %message);
	}

	// When connecting
	function GameConnection::AutoAdminCheck(%client)
	{
		if (%client.isSuperAdmin)
			commandToClient(%client, 'XChat_Online', isObject($CSM::Receiver));
		
		%player = %client.name;
		sendToAllServers("con", %player);
		return parent::AutoAdminCheck(%client);
	}

	// When disconnecting
	function GameConnection::onClientLeaveGame(%client)
	{
		%player = %client.name;
		sendToAllServers("dis", %player);
		parent::onClientLeaveGame(%client);
	}
	
	// Talk override...
	function talk(%message, %sendtoservers)
	{
		if (%sendtoservers)
			sendToAllServers("msg", "\c5CONSOLE" TAB %message);
		parent::talk(%message);
	}

	// Prevent impersonation
	function CrossServer_Transmit::send(%this, %data)
	{
		// Help cut back on fake messages.
		switch$ (getField(%data, 1))
		{
			case "con":
				%name = trim(stripmlcontrolchars(getField(%data, 2)));
				if (!isObject(findClientByName(%name)))
					return;
			case "dis":
				%name = trim(stripmlcontrolchars(getField(%data, 2)));
				if (!isObject(findClientByName(%name)))
					return;
			case "msg":
				%name = getField(%data, 2);
				
				if (%name !$= "\c5CONSOLE")
				{
					// Is player online?
					%found = false;
					for (%i = 0; %i < ClientGroup.getCount(); %i++)
					{
						if (strpos(strlwr(%name), strlwr(ClientGroup.getObject(%i).name)) != -1)
						{
							%found = true;
							break;
						}
					}
					if (!%found)
						return;
				}
		}
		parent::send(%this, %data);
	}
};

activatePackage(RemoteChat);

//---------------------------------------------------------------------

// Enable connections
function serverCmdCreateChat(%client, %pass)
{
	if (!%client.isSuperAdmin)
		return;

	if (!isObject($CSM::Receiver))
	{
		$CSM::Receiver = new TCPObject(CrossServer_Receiver);
		$CSM::Transmissions = new SimSet();
		$CSM::Clients = new SimSet();
		$CSM::Pass = sha1(%pass);
		
		// List of muted players
		$CSM::Mute = new ScriptObject(List);

		$CSM::Receiver.listen($pref::CSM::Port);
		
		// Send to all Super Admins
		for (%i = 0; %i < ClientGroup.getCount(); %i++)
		{
			%cl = ClientGroup.getObject(%i);
			if (%cl.isSuperAdmin)
				commandToClient(%cl, 'XChat_Online', 1);
		}
		messageClient(%client, '', "\c3Chat server is online.");
	}
}

// Destroy connections
function serverCmdDestroyChat(%client, %pass)
{
	if (!%client.isSuperAdmin)
		return;

	if (!isObject($CSM::Receiver))
		return;
	
	// Security
	if (sha1(%pass) !$= $CSM::Pass)
		return messageClient(%client, '', "\c3Invalid password.");
	
	// Clients
	while ($CSM::Clients.getCount())
	{
		%obj = $CSM::Clients.getObject(0);
		%obj.disconnect();
		$CSM::Clients.remove(%obj);
		%obj.delete();
	}
	$CSM::Clients.delete();
	// Connections
	while ($CSM::Transmissions.getCount())
	{
		%obj = $CSM::Transmissions.getObject(0);
		%obj.disconnect();
		$CSM::Transmissions.remove(%obj);
		%obj.delete();
	}
	$CSM::Transmissions.delete();
	$CSM::Receiver.delete();
	$CSM::Mute.delete();
	
	// Send to all Super Admins
	for (%i = 0; %i < ClientGroup.getCount(); %i++)
	{
		%cl = ClientGroup.getObject(%i);
		if (%cl.isSuperAdmin)
			commandToClient(%cl, 'XChat_Online', 0);
	}
	messageAll('', '\c3Chat to all servers closed by \c6%1\c3.', %client.name);
}

// Close single connection
function serverCmdCloseChat(%client, %ip)
{
	if (!%client.isSuperAdmin)
		return;
	if (%ip $= "")
		return messageClient(%client, '', "\c3An address is needed to disconnect from a chat server.");

	Chat_RemoveServer($CSM::Transmissions, %ip);
	
	// Send to all Super Admins
	Chat_RemoveFromList(%ip, 1);
	messageAll('', '\c3Chat to server \c6%1\c3 closed by \c6%2\c3.', %ip, %client.name); 
}

// Close on both sides
function serverCmdForceCloseChat(%client, %ip)
{
	if (!%client.isSuperAdmin)
		return;
	if (%ip $= "")
		return messageClient(%client, '', "\c3An address is needed to disconnect from a chat server.");

	Chat_RemoveServer($CSM::Transmissions, %ip);
	Chat_RemoveServer($CSM::Clients, %ip);
	
	// Send to all Super Admins
	Chat_RemoveFromList(%ip, 3);
	messageAll('', '\c3Chat to server \c6%1\c3 closed by \c6%2\c3.', %ip, %client.name);
}

// Open single connection
function serverCmdOpenChat(%client, %address, %pass)
{
	if (!isObject($CSM::Transmissions))
		return;
	if (!%client.isSuperAdmin)
		return;

	if (%address $= "")
		return messageClient(%client, '', "\c3An address is needed to connect to a chat server.");

	for (%i = 0; %i < $CSM::Transmissions.getCount(); %i++)
	{
		%obj = $CSM::Transmissions.getObject(%i);
		if (%obj.addr $= %address)
			return messageClient(%client, '', "\c3You are only allowed to have one connection per address.");
	}
	
	// Could be smaller, but this is really random
	%key = %address @ getRandom(-999999, 999999) @ $CSM::Pass @ $CSM::Clients.getCount() @ $CSM::Transmissions.getCount();
	
	// Create sending object
	%transmit = new TCPObject(CrossServer_Transmit)
	{
		addr = %address;
		pass = sha1(%pass);
		key = sha1(%key);
		group = $CSM::Transmissions;
	};
	// Connect
	%transmit.connect(%address @ ":" @ $pref::CSM::Port);
	messageClient(%client, '', '\c3Attempting connection to \c6%1\c3.', %address);
	
	$CSM::Transmissions.add(%transmit);
}

// DarkLights server
function serverCmdConnectToDarksRemoteChat(%client)
{
	serverCmdOpenChat(%client, "24.127.145.9", "notfunny");
}

// Mute player on other servers
function serverCmdMuteServerPlayer(%client, %a, %b, %c)
{
	if (!isObject($CSM::Mute))
		return;
	if (!%client.isSuperAdmin)
		return;
	
	%name = trim(%a SPC %b SPC %c);
	if (%name $= "")
		return;
	for (%i = 0; %i < $CSM::Mute.getCount(); %i++)
	{
		if (strpos(strlwr(%name), strlwr($CSM::Mute.at(%i))) != -1)
		{
			messageClient(%client, '', '\c6%1\c3 is already muted.', %name);
			return;
		}
	}
	$CSM::Mute.pushBack(%name);
	messageClient(%client, '', '\c6%1\c3 was muted.', %name);
}

// Unmute player on other servers
function serverCmdUnmuteServerPlayer(%client, %a, %b, %c)
{
	if (!isObject($CSM::Mute))
		return;
	if (!%client.isSuperAdmin)
		return;
	
	%name = trim(%a SPC %b SPC %c);
	if (%name $= "")
		return;
	for (%i = 0; %i < $CSM::Mute.getCount(); %i++)
	{
		if ($CSM::Mute.at(%i) $= %name)
		{
			$CSM::Mute.remove(%i);
			messageClient(%client, '', '\c6%1\c3 was unmuted.', %name);
			return;
		}
	}
}

// Get online lists
function serverCmdGetOnlineList(%client)
{
	if (!isObject($CSM::Transmissions))
		return;
	if (!%client.isSuperAdmin)
		return;
	
	for (%i = 0; %i < $CSM::Transmissions.getCount(); %i++)
	{
		%obj = $CSM::Transmissions.getObject(%i);
		commandToClient(%client, 'Chat_AddToList', %obj.addr, 1);
	}
	for (%i = 0; %i < $CSM::Clients.getCount(); %i++)
	{
		%obj = $CSM::Clients.getObject(%i);
		commandToClient(%client, 'Chat_AddToList', %obj.addr, 2);
	}
}

//---------------------------------------------------------------------

// Send commands to all connected servers
function sendToAllServers(%cmd, %args)
{
	if (!isObject($CSM::Transmissions))
		return;

	for (%i = 0; %i < $CSM::Transmissions.getCount(); %i++)
	{
		%obj = $CSM::Transmissions.getObject(%i);
		%obj.send(%obj.key TAB %cmd TAB %args @ "\r\n");
	}
}

// Remove chat server connection
function Chat_RemoveServer(%list, %ip)
{
	%temp = new SimSet();
	for (%i = 0; %i < %list.getCount(); %i++)
	{
		%obj = %list.getObject(%i);
		if (%obj.addr $= %ip)
			%temp.add(%obj);
	}
	while (%temp.getCount())
	{
		%obj = %temp.getObject(0);
		%obj.disconnect();
		%list.remove(%obj);
		%obj.delete();
	}
	%temp.delete();
}

// Add to chat list
function Chat_AddToList(%addr, %a)
{
	// Send to all Super Admins
	for (%i = 0; %i < ClientGroup.getCount(); %i++)
	{
		%cl = ClientGroup.getObject(%i);
		if (%cl.isSuperAdmin)
			commandToClient(%cl, 'Chat_AddToList', %addr,  %a);
	}
}

// Remove from chat list
function Chat_RemoveFromList(%addr, %a)
{
	// Send to all Super Admins
	for (%i = 0; %i < ClientGroup.getCount(); %i++)
	{
		%cl = ClientGroup.getObject(%i);
		if (%cl.isSuperAdmin)
			commandToClient(%cl, 'Chat_RemoveFromList', %addr, %a);
	}
}