//Deflector
//Do away with projectiles, maybe even send them right back.

datablock AudioProfile(DeflectorSound)
{
   filename    = "./Deflect.wav";
   description = AudioDefault3d;
   preload = true;
};
datablock AudioProfile(RedirectSound)
{
   filename    = "./Redirected.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock ParticleData(DeflectorParticle)
{
	dragCoefficient      = 0.1;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/thinring";
	colors[0]     = "0.2 0.9 0 0.6";
	colors[1]     = "0.4 0.9 0 0.5";
	sizes[0]      = 0.2;
	sizes[1]      = 18;
	times[0]	  = 0;
	times[1]	  = 1;

	useInvAlpha = true;
};
datablock ParticleEmitterData(DeflectorEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 44;
   velocityVariance = 0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "DeflectorParticle";
   UIName = "Deflector Ring";
};
datablock ItemData(DeflectorItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./deflector.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Deflector";
	iconName = "./Icon_deflector";
	doColorShift = true;
	colorShiftColor = "0.50 1 0.1 1.000";

	 // Dynamic properties defined by the scripts
	image = DeflectorImage;
	canDrop = true;
};

datablock ShapeBaseImageData(DeflectorImage)
{
   shapeFile = "./deflector.dts";
   emap = true;

   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = DeflectorItem;
   ammo = " ";
   projectileType = ""; //We use a connical search rather than a projectile.

   melee = false;
   armReady = true;

   doColorShift = true;
   colorShiftColor = DeflectorItem.colorShiftColor;//"0.0 0.0 0.75 0.85";

   // Initial start up state
	stateName[0]                    	= "Activate";
	stateTimeoutValue[0]				= 1;
	stateTransitionOnTimeout[0]     	= "Ready";
	stateSound[0]						= weaponSwitchSound;

	stateName[1]						= "Ready";
	stateTransitionOnTriggerDown[1]		= "Fire";
	stateAllowImageChange[1]			= true;

	stateName[2]						= "Fire";
	stateEmitter[2]						= DeflectorEmitter;
	stateScript[2]						= "onFire";
	stateEmitterTime[2]					= 0.05;
	stateEmitterNode[2]					= "muzzleNode";
	stateTransitionOnTriggerUp[2]		= "AmmoCheck";
	stateAllowImageChange[2]			= false;
	StateSound[2]						= DeflectorSound;

	stateName[3]						= "AmmoCheck"; //An ammo system is the only way I know to alter the state of a mounted image through script.
	stateTransitionOnNoAmmo[3]			= "Reload";
	StateTransitionOnAmmo[3]			= "Ready";

	stateName[4]						= "Reload";
	stateTransitionOnTimeout[4]			= "Ready";
	stateTimeoutValue[4]				= 1;
};

function DeflectorImage::onFire(%this, %obj, %slot)
{
	%obj.setImageAmmo(0, 0); //Disable the gun.
	%client = %obj.client;
	%eye = %client.player.getEyeTransform(); //Because I hate typing it out over and over again.
	%mask = $TypeMasks::ProjectileObjectType; //I was originally planning to make it shove players around, but I decided this should be better for medium-long range encounters.
	InitContainerRadiusSearch(%eye, 12, %mask);
	while(isObject(%Proj = containerSearchNext()))
	{
		if(!miniGameCanDamage(%Proj, %obj) && (isObject(%proj.client.minigame) || isObject(%client.minigame))) //Don't touch it if it's involved in a different minigame
				continue;
		%velAvg = (mAbs(getWord(%proj.getVelocity(), 0)) + mAbs(getWord(%proj.getVelocity(), 1)) + mAbs(getWord(%proj.getVelocity(), 2))) / 3;
		if(!%proj.origVelocity || %proj.origVelocity < %proj.getDatablock().muzzleVelocity / 2) //We don't want too small of an original velocity to base our reflections on, otherwise we couldn't get it above half normal speed.
			%proj.origVelocity = %velAvg; //Speed cap is based on how fast the projectile was at first deflection.
		%repelForce = ((15 - vectorDist(%eye, %proj.getTransform())) / 6) * %velAvg; //Allow us to boost the speed based on what it already is, instead of the default speed.
		if(%repelForce > %proj.origVelocity * 2.25)
			%repelForce = (2.25 * %proj.origVelocity); //We have to cap it at some point.
		if(%repelForce <= %proj.getDatablock().muzzleVelocity / 2)
			%repelForce = (%proj.getDatablock().muzzleVelocity / 2); //Also imposing a minimum.
		%repelDir = vectorNormalize(vectorSub(%proj.getTransform(), %eye));

			%anglediff = vectorSub(%repelDir,vectorNormalize(%client.player.getEyeVector()));
		%anglediffavg = (mAbs(getWord(%angleDiff, 0)) + mAbs(getWord(%angleDiff, 1)) + mAbs(getWord(%angleDiff, 2))) / 3;
		if(%anglediffavg > 0.3) //Makeshift vector angle comparison. It doesn't work as accurately as I wish it did, but I'm not all that good with vectors.
				continue;

		if(vectorDist(%eye, %proj.getTransform()) <= 6 && isObject(%proj.client.player) && %client != %proj.client)
		{
			%ownerDir = vectorNormalize(vectorSub(%proj.client.player.getEyeTransform(), %eye));
			%ownerAngleDiff = vectorSub(%ownerDir, vectorNormalize(%client.player.getEyeVector()));
			%ownerAngleDiffAvg = (mAbs(getWord(%ownerAngleDiff, 0)) + mAbs(getWord(%ownerAngleDiff, 1)) + mAbs(getWord(%ownerAngleDiff, 2))) / 3; //I thought I've seen a cone-search function somewhere before...
			if(%anglediffavg <= 0.5) //If they're out of our sight, we don't send it at them.
				%repelDir = vectorNormalize(vectorSub(%proj.client.player.getEyeTransform(), %proj.getTransform())); //Step in and tell us where it should go.
		}
		
		%newVelocity = vectorScale(%repelDir, %repelForce); //Get our final calculations as to where we should shoot this thing.
		
		serverPlay3d(RedirectSound, %proj.getPosition());
		%obj.setImageAmmo(0, 1); //Reenable the gun if we actually used it on something
		
		%p = new Projectile() //Because Projectile::Redirect didn't work, and Projectile::SetVelocity doesn't exist for some reason.
		{
			initialVelocity		= %newVelocity;
			origVelocity		= %proj.origVelocity;
			initialPosition		= %proj.getPosition();
			datablock			= %proj.getDatablock();
			sourceObject		= %proj.client.player;
			sourceSlot			= %proj.sourceSlot;
			client				= %client; //Change the owner to us so we can damage the original attacker.
			scale				= %proj.getScale();
		};
		missionCleanup.add(%p);
		%proj.delete(); //Do away with the old one so we don't get facerocketed.
	}
}