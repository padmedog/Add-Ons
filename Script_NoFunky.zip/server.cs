function clearcolorblock(%client,%a)
{
	if(%a == 0)
		%client.colorupdaterecentlyfirst = false;
	if(%a == 1)
		%client.colorupdaterecentlysecond = false;
}

package nomorefunky
{
	function servercmdupdatebodycolors(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p)
	{
		Parent::servercmdupdatebodycolors(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p);
		if(%client.colorupdaterecentlyfirst && !%client.colorupdaterecentlysecond)
		{
			%client.colorupdaterecentlysecond = true;
			schedule(4000,0,clearcolorblock,%client,1);
		}
		else if(%client.colorupdaterecentlyfirst && %client.colorupdaterecentlysecond)
		{
			messageall('MsgAdminForce',"\c3" @ %client.name SPC "\c2was kicked for sending to many avatar change requests.");
			%client.delete("Please do not send so many avatar change requests.");
		}
		%client.colorupdaterecentlyfirst = true;
		schedule(4000,0,clearcolorblock,%client,0);
	}
};
activatepackage(nomorefunky);