%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_Disabled)
{
	error("Content_I04_cPanel: JVS_Content is disabled and is required by this Add-On.");
}
else if(%error == $Error::AddOn_NotFound)
{
	error("Content_I04_cPanel: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/Content_I04_cPanel/types/I04_cPanel.cs");
}
