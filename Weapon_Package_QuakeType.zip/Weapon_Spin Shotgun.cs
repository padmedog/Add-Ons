//spinShotguns.cs

datablock AudioProfile(spinShotgunFireSound)
{
   filename    = "./spin_Shotgun.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(spinShotgunReloadSound)
{
   filename    = "./spin_Shotgun_reload.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("spinShotguns",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_twinshotgun> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_twinshotgun> %1',0.05,1);
datablock ProjectileData(spinShotgunProjectile : quakeShotgunProjectile)
{
   directDamage        = 8;
   directDamageType    = $DamageType::spinShotguns;
   radiusDamageType    = $DamageType::spinShotguns;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = gunExplosion;
   particleEmitter     = "";

   explodeOnPlayerImpact = true;
   explodeondeath = true;

   muzzleVelocity      = 170;
   velInheritFactor    = 0;

   armingDelay         = 000;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(spinShotgunsItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./spin_shotgun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Twin Shotguns";
	iconName = "./twinshotguns";
	doColorShift = true;
	colorShiftColor = "0.3 0.3 0.3 1.000";

	 // Dynamic properties defined by the scripts
	image = spinShotgunsImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(spinShotgunsImage)
{
   // Basic Item properties
	shapeFile = "./spin_shotgun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = spinShotgunProjectile;
   projectileType = Projectile;

	casing = quakeShotgunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = spinShotgunsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Smoke";
	stateTimeoutValue[0] = 0.01;
	stateSequence[0] = "ready";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.15;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = spinShotgunfireSound;
	stateEmitter[2]					= quakeShotgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
   stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.45;
	stateScript[3] = "onReload";
	stateSequence[3] = "Fire";
	stateSound[3] = spinShotgunReloadSound;
	stateTransitionOnTimeout[3]     = "FireAkimbo";
	stateEjectShell[3]       = true;

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerDown[4] = "FireAkimbo";
	stateSequence[4] = "ready";

	stateName[5] = "FireAkimbo";
	stateTimeoutValue[5] = 0.60;
	stateScript[5] = "onFireAkimbo";
	stateTransitionOnTimeOut[5] = "ready";
};


function spinShotgunsImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}


datablock ShapeBaseImageData(LeftHandedspinShotgunImage)
{
   // Basic Item properties
	shapeFile = "./spin_shotgun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = spinShotgunProjectile;
   projectileType = Projectile;

	casing = quakeShotgunShellDebris;
	shellExitDir        = "-1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = spinShotgunsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Smoke";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";
   stateSound[0]		= weaponSwitchSound;

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.15;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = spinShotgunfireSound;
	stateEmitter[2]					= quakeShotgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateSequence[3] = "Fire";
	stateScript[3] = "onReload";
	stateSound[3] = spinShotgunReloadSound;
	stateTimeoutValue[3]            = 0.45;
	stateTransitionOnTimeout[3]     = "Reload";
	stateEjectShell[3]       = true;

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "Ready";
	stateSequence[4] = "ready";
};


function LeftHandedspinShotgunImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2, leftRecoil);
}

function LeftHandedspinShotgunImage::onFire(%this, %obj, %slot)
{
	%projectile = spinShotgunProjectile;
	%spread = 0.0016;
	%shellcount = 5;

	%obj.playThread(2, leftRecoil);
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-4")));
	%obj.spawnExplosion(QuakeLittleRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}

	%projectile = quakeShotgunBlastProjectile;
	%spread = 0.0001;
	%shellcount = 1;
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}

function spinShotgunsImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftHandedspinShotgunImage, 1);
   //%obj.playThread(0, armreadyboth);
}
function spinShotgunsImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount lefthanded gun
   %obj.unMountImage(1);
   //%obj.playThread(0, root);
}


function LeftHandedspinShotgunImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function LeftHandedspinShotgunImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
}

function spinShotgunsImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2, leftRecoil);
}

function spinShotgunsImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, plant);
	%projectile = spinShotgunProjectile;
	%spread = 0.0016;
	%shellcount = 5;

	%obj.playThread(2, shiftAway);
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-4")));
	%obj.spawnExplosion(QuakeLittleRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}

	%projectile = quakeShotgunBlastProjectile;
	%spread = 0.0001;
	%shellcount = 1;
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
   //%obj.setImageTrigger(1,1);
}
