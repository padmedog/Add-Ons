//Default Settings
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
   if(!$RTB::RTBR_ServerControl_Hook)
      exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
      
  // RTB_registerPref("Thirst","Thirst Mod","Thirst::On","bool","Script_Thirst",1,0,0);
   RTB_registerPref("Thirst Tick (seconds)","Thirst Mod","Thirst::TickTime","int 3 480","Script_Thirst",60,0,0);
   RTB_registerPref("Cannibalism","Thirst Mod","Thirst::DrinkPeeps","bool","Script_Thirst",0,0,0);
   RTB_registerPref("Water Cost","Thirst Mod","Thirst::WaterCost","int 0 100","Script_Thirst",10,0,0);
   RTB_registerPref("Events","Thirst Mod","Thirst::Event","bool","Script_Thirst",1,0,0);
   RTB_registerPref("Water in Horses","Thirst Mod","thirst::WaterHorse","int 0 100","Script_Thirst",5,0,0);
}
else
{
	$Thirst::WaterCost = 10;
	$Thirst::TickTime = 30;
	$Thirst::WaterFill = 10;
	$Thirst::DrinkPeeps = 0;
	$Thirst::Event = 1;
	$thirst::WaterHorse = 5;
}
$Thirst::On = 1;
$Thirst::WaterFill = 10;

AddDamageType("Thirst",   '',    '%2 lol how can you kill someone else of thirst? %1',1,1);
AddDamageType("Drink",   '%1 drank of himeself.',    '%2 has drank %1.',1,1);

RegisterSpecialVar(GameConnection,"thirst","%this.thirst");
RegisterSpecialVar(GameConnection,"water","$water[%this.bl_id]");
	
//Package for joining and leaving game
package Thirst
{
   	function GameConnection::autoAdminCheck(%client)
   	{   
   	Parent::autoAdminCheck(%client);
	%client.thirst = 100;
	//$decay[%client] = schedule($Thirst::TickTime,0,"thirstdecay",%client);
	if(!$water[%client.bl_id])
	{
		$water[%client.bl_id] = 2;
	}
	%client.canBuyWater = 0;
   	}
   	
   	function GameConnection::OnClientEnterGame(%client)
	{
		Parent::OnClientEnterGame(%client);
		%client.hasSpawned = 1;
		
		if(!$thirstTick && $Thirst::On == 1)
			thirstTick();
	}

	function player::activateStuff(%obj)
	{
		Parent::activateStuff(%obj);
		if($Thirst::On == 1 && $Thirst::DrinkPeeps == 1)
		{
			%client = %obj.client;
				%target = containerRayCast(%client.player.getEyePoint(), vectorAdd(vectorScale(vectorNormalize(%client.player.getEyeVector()), 8), %client.player.getEyePoint()),$typeMasks::playerObjectType).client;
				if(isObject(%target))
				{
					if(%client.thirst >= 100)
					{
						commandToClient(%client, 'CenterPrint', "\c6You're fully hydrated!", 2);
						return;
					}
					
					if(getRandom(0, 100) >= 85)
					{
						return;
					}
				
					commandToClient(%target, 'CenterPrint', %client.getPlayerName() @ " is drinking you!", 1);
					%target.player.damage(%client.player, %target.player.getTransform, 3, $DamageType::Drink);
					
					%client.thirst = %client.thirst + 5;
					if(%client.thirst > 100)
					{
						%client.thirst = 100;
					}
					commandToClient(%client, 'CenterPrint', "\c6You drunk a peice of \c3" @ %target.getPlayerName() @ "\c6.", 1);
			}
		}
				
	}

	function brickWaterShopData::onPlant(%this,%brick)
	{
 				
		Parent::onPlant(%this,%brick);
 		schedule(100,0,"watershop",%brick);

	}

	function brickWaterShopData::onRemove(%this,%brick)
	{
 		Parent::onRemove(%this,%brick);
 		if(isObject(%brick.trigger)){%brick.trigger.delete();}
	}	
	
	function HorseArmor::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
	{
		parent::damage(%this, %obj, %pos, %damage, %damageType);
		%obj.LastAttacker = %sourceObject.CLient;
		//echo(%obj.LastAttacker);
	}
	
	function HorseArmor::ondisabled(%this,%obj)
	{
		parent::ondisabled(%this,%obj);
		if($Thirst::On == 1 && $thirst::WaterHorse > 0)
		{
			%r = getRandom(-2, 2);
			%water = %r + $thirst::WaterHorse;
			if(%water < 1)
				%water = 1;
			
			$water[%obj.LastAttacker.bl_id] = $water[%obj.LastAttacker.bl_id] + %water;	
			messageClient(%obj.LastAttacker, '', "\c6You get \c3" @ %water @ "\c6 water from the horse. You now have\c3 " @ $water[%obj.LastAttacker.bl_id]  @ "\c6 water.");

		}
	}
};
activatePackage(Thirst);

function thirstTick()
{
	cancel($thirstTick);
	
	if($Thirst::On == 1)
	{
		for(%i=0;%i<ClientGroup.getCount();%i++)
		{
			%cl = ClientGroup.getObject(%i);
			thirstDecay(%cl);
		}	
			
		%time = $Thirst::TickTime * 1000;
		//echo(%time);
		if(isObject(ServerConnection) || $Server::Dedicated == 1)
			$thirstTick = schedule(%time,0,thirstTick);
	}
}


function serverCmdCheckThirst(%client)
{
	if($Thirst::On == 1)
	{
	}
	else
	{
		messageClient(%client, "", "\c6Thirst is currently disabled.");
	}
}

function serverCmdGiveWater(%client, %am)
{
	if(%am <= 0)
	{
		messageClient(%client, '', "\c6Invalid Amount");
		return;
	}
	
	if(%am > $water[%client.bl_id])
	{
		messageClient(%client, '', "\c6You don't have that much water.");
		return;
	}
	
	%target = containerRayCast(%client.player.getEyePoint(), vectorAdd(vectorScale(vectorNormalize(%client.player.getEyeVector()), 8), %client.player.getEyePoint()),$typeMasks::playerObjectType).client;
	if(isObject(%target))
	{
		$water[%client.bl_id] = $water[%client.bl_id] - %am;
		$water[%target.bl_id] = $water[%target.bl_id] + %am;
		messageClient(%client, '', "\c6You gave \c3" @ %am @ "\c6 water to\c3 " @ %target.getPlayerName() @ "\c6. You now have \c3" @ $water[%client.bl_id] @ "\c6 total water.");
		messageClient(%target, '', "\c3" @ %client.getPlayerName() @ "\c6 has given  you \c3" @ %am @ "\c6 water. You now have \c3" @ $water[%target.bl_id] @ "\c6 total water.");
	}
	else
	{
		messageClient(%client, '', "\c6You must be looking at someone to give them water.");
	}
}

function thirstDecay(%client)
{
  if(isObject(%client.player)) 
  {
	if($Thirst::On == 0 || %client.hasSpawned == 0)
	{
		return;
	}

	%thirstl = %client.thirst;
	%client.player.EnergyConsumedThirst = %client.player.EnergyConsumedThirst / 20;
	%client.player.EnergyConsumedThirst = mCeil(%client.player.EnergyConsumedThirst);
    if(%client.player.EnergyConsumedThirst == 0)
	{
	  if(%client.bodyTemp <= 99)
	  {
	  %client.thirst = %thirstl - getRandom(3, 1);
	  }
	  if(%client.bodyTemp >= 100 && %client.bodyTemp < 101)
	  {
	  %client.thirst = %thirstl - getRandom(3, 2);
	  }
      if(%client.bodyTemp >= 101 && %client.bodyTemp < 102)
	  {
	  %client.thirst = %thirstl - getRandom(4, 2);
	  }
	  if(%client.bodyTemp >= 102 && %client.bodyTemp < 103)
	  {
	  %client.thirst = %thirstl - getRandom(5, 3);
	  }
      if(%client.bodyTemp >= 103 && %client.bodyTemp < 104)
	  {
	  %client.thirst = %thirstl - getRandom(6, 4);
	  }
	  if(%client.bodyTemp >= 104 && %client.bodyTemp < 105)
	  {
	  %client.thirst = %thirstl - getRandom(7, 5);
	  }
	  if(%client.bodyTemp >= 105 && %client.bodyTemp < 106)
	  {
	  %client.thirst = %thirstl - getRandom(8, 6);
	  }
      if(%client.bodyTemp >= 106 && %client.bodyTemp < 107)
	  {
	  %client.thirst = %thirstl - getRandom(9, 7);
	  }
	  if(%client.bodyTemp >= 107 && %client.bodyTemp < 108)
	  {
	  %client.thirst = %thirstl - getRandom(10, 8);
	  }
	  if(%client.bodyTemp >= 108 && %client.bodyTemp < 109)
	  {
	  %client.thirst = %thirstl - getRandom(11, 9);
	  }
	  if(%client.bodyTemp >= 109 && %client.bodyTemp < 110)
	  {
	  %client.thirst = %thirstl - getRandom(12, 10);
	  }
      if(%client.bodyTemp >= 110)
	  {
	  %client.thirst = %thirstl - getRandom(13, 11);
	  }
	}
	if(%client.player.EnergyConsumedThirst < 0)
	{
	  %client.player.EnergyConsumedThirst *= -1;
	  if(%client.bodyTemp <= 99)
	  {
	  %client.thirst = %thirstl - (getRandom(3, 1) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 100 && %client.bodyTemp < 101)
	  {
	  %client.thirst = %thirstl - (getRandom(3, 2) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 101 && %client.bodyTemp < 102)
	  {
	  %client.thirst = %thirstl - (getRandom(4, 2) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 102 && %client.bodyTemp < 103)
	  {
	  %client.thirst = %thirstl - (getRandom(5, 3) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 103 && %client.bodyTemp < 104)
	  {
	  %client.thirst = %thirstl - (getRandom(6, 4) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 104 && %client.bodyTemp < 105)
	  {
	  %client.thirst = %thirstl - (getRandom(7, 5) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 105 && %client.bodyTemp < 106)
	  {
	  %client.thirst = %thirstl - (getRandom(8, 6) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 106 && %client.bodyTemp < 107)
	  {
	  %client.thirst = %thirstl - (getRandom(9, 7) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 107 && %client.bodyTemp < 108)
	  {
	  %client.thirst = %thirstl - (getRandom(10, 8) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 108 && %client.bodyTemp < 109)
	  {
	  %client.thirst = %thirstl - (getRandom(11, 9) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 109 && %client.bodyTemp < 110)
	  {
	  %client.thirst = %thirstl - (getRandom(12, 10) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 110)
	  {
	  %client.thirst = %thirstl - (getRandom(13, 11) + %client.player.EnergyConsumedThirst);
	  }
	}
	if(%client.player.EnergyConsumedThirst > 0)
	{
	  if(%client.bodyTemp <= 99)
	  {
	  %client.thirst = %thirstl - (getRandom(3, 1) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 100 && %client.bodyTemp < 101)
	  {
	  %client.thirst = %thirstl - (getRandom(3, 2) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 101 && %client.bodyTemp < 102)
	  {
	  %client.thirst = %thirstl - (getRandom(4, 2) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 102 && %client.bodyTemp < 103)
	  {
	  %client.thirst = %thirstl - (getRandom(5, 3) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 103 && %client.bodyTemp < 104)
	  {
	  %client.thirst = %thirstl - (getRandom(6, 4) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 104 && %client.bodyTemp < 105)
	  {
	  %client.thirst = %thirstl - (getRandom(7, 5) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 105 && %client.bodyTemp < 106)
	  {
	  %client.thirst = %thirstl - (getRandom(8, 6) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 106 && %client.bodyTemp < 107)
	  {
	  %client.thirst = %thirstl - (getRandom(9, 7) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 107 && %client.bodyTemp < 108)
	  {
	  %client.thirst = %thirstl - (getRandom(10, 8) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 108 && %client.bodyTemp < 109)
	  {
	  %client.thirst = %thirstl - (getRandom(11, 9) + %client.player.EnergyConsumedThirst);
	  }
	  if(%client.bodyTemp >= 109 && %client.bodyTemp < 110)
	  {
	  %client.thirst = %thirstl - (getRandom(12, 10) + %client.player.EnergyConsumedThirst);
	  }
      if(%client.bodyTemp >= 110)
	  {
	  %client.thirst = %thirstl - (getRandom(13, 11) + %client.player.EnergyConsumedThirst);
	  }
	}
	echo(%client.player.EnergyConsumedThirst);
	%client.player.EnergyConsumedThirst = 0;
	
	if(%client.thirst <= 0)
	{
		//%client.Player.kill();
		//messageAll("Someone has died of thirst.");
		if(isObject(%client.player)) 
		{
			%client.player.damage(%client.player, %client.player.getTransform, 100, $DamageType::Thirst);
		}
		%client.thirst = 100;
		%client.thirst = 100;
	}
  }
}

//Shops

datablock TriggerDataTwo(Shop){
   tickPeriodMS = 100;
};

function shop::onEnterTrigger(%this, %trigger, %obj){
	if(!%obj.client.inshop){// if the enteree isnt already inside
	%obj.client.inshop = 1;
	if($Cash::CurrencyBefore)
	{
      	messageClient(%obj.client, "", "\c6Welcome to the water shop, type \c3/buyWater [amount]\c6 to buy water. The water price is \c3" @ $Cash::Currency @ $Thirst::WaterCost @ "\c6.");
	}
	else
	{
		messageClient(%obj.client, "", "\c6Welcome to the water shop, type \c3/buyWater [amount]\c6 to buy water. The water price is \c3" @ $Thirst::WaterCost @ $Cash::Currency @ "\c6.");
	}
}	
}

function shop::OnLeaveTrigger(%thid, %trigger, %obj){
	if(%obj.client.inshop){//make sure they're actually inside
	%obj.client.inshop = 0;//hes no longer inside
      messageClient(%obj.client, "", "\c6You have left the shop.");
  }
}

function serverCmdBuyWater(%client, %amount)
{
	if(!$Thirst::On)
	{
		messageClient(%client, "", "\c6Thirst is currently disabled.");
		return;
	}
	
	if(%amount < 0)
	{
		return;
	}
	
	if(!%amount)
	{
		%amount = 1;
	}
	
	%amount = mFloor(%amount);
	if(%client.inshop)
	{	
	%cost = $Thirst::WaterCost * %amount;
		if(%client.cashobj.cash >= %cost)
		{
			if(isObject(%client.cashobj))
			{
				%client.cashobj.mod("cash",0 - %cost);
			}
			$water[%client.bl_id] = $water[%client.bl_id] + %amount;
			messageClient(%client, "", "\c6You have bought \c3" @ %amount @ " \c6water. You now have \c3" @ $water[%client.bl_id] @ "\c6 total water.");
			messageClient(%client, "", "\c6Type \c3/drinkWater [amount]\c6 to drink it.");
		}
		else
		{
			messageclient(%client,"","\c6You Do not have enough money to buy that much water!");
		}

	}
	else
	{
		messageClient(%client, "", "\c0You are not in a water shop.");
	}
}

function serverCmdDrinkWater(%client, %amount)
{
	if(!$Thirst::On)
	{
		messageClient(%client, "", "\c6Thirst is currently disabled.");
		return;
	}
		
	if(%amount < 0)
	{
		return;
	}
	
	if(!%amount)
	{
		%amount = 1;
	}
	
	if($water[%client.bl_id] < 1)
	{
		messageclient(%client,"","\c6You do not have any water to drink!");
		return;
	}

	if($water[%client.bl_id] < %amount)
	{
		%amount = $water[%client.bl_id];
	}
		
	%minfull = 100 - $Thirst::WaterFill * %amount;
	if(%client.thirst <= %minfull)
	{
		%client.thirst = %client.thirst + $Thirst::WaterFill * %amount;
		$water[%client.bl_id] = $water[%client.bl_id] - %amount;
		commandToClient(%client, 'CenterPrint', "\c6You ate \c3" @ %amount @ "\c6 water. You have \c3" @ $water[%client.bl_id] @ "\c6 water remaining.", 4);
	}
	else
	{
		messageclient(%client,"","\c6You are not thirsty enough to drink that much water, please wait until your thirst level is \c3" @ %minfull @ " \c6or less");
	}	

}

function watershop(%brick)
{
	if(%brick.getGroup().client.isSuperAdmin || %brick.getGroup().client.isAdmin){
	%posx = getWord(%brick.position,0);
	%posy = getWord(%brick.position,1);
	%posz = getWord(%brick.position,2);
	%posx = %posx - 0.5;
	%posy = %posy + 0.5;
	
	%temp = new trigger() {
	Datablock = "Shop";
	position = %posx SPC  %posy SPC %posz;
	scale = "1 1 1";
	rotation = "0 0 0 0";
	polyhedron = "0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 -1.0000000 0.0000000 0.0000000 0.0000000 1.0000000";
	};
	%brick.trigger = %temp;
	MissionCleanup.add(%temp);
  	}
	else
	{
	messageClient(%brick.getGroup().client, "", "This brick is admin only!");
	%brick.killbrick();
	}

}

//Setting Commands

function serverCmdThirstHelp(%client)
{
	messageclient(%client,"","\c3/drinkWater [Amount]\c6 - Drink [Amount] water.");
	messageclient(%client,"","\c3/giveWater [Amount]\c6 - Give water to who you're looking at.");
	messageclient(%client,"","\c3/checkThirst \c6 - See your thirst level.");
	messageclient(%client,"","\c3/thirst\c6 - Turns thirst on/off. \c3(Admin Only)");
//	messageclient(%client,"","\c3/drinkPeople\c6 - Turns Cannibalism on/off. \c3(Admin Only)");
//	messageclient(%client,"","\c3/thirstTickTime [Seconds]\c6 - Sets the thirst tick time. \c3(Admin Only)");
//	messageclient(%client,"","\c3/thirstEvent\c6 - Turns the incThirst event on/off. \c3(Admin Only)");
//	messageclient(%client,"","\c3/waterCost [Price]\c6 - Sets the water cost. \c3(Admin Only)");
}

function serverCmdThirst(%client, %temp)
{
	if(%client.isSuperAdmin || %client.isAdmin)
	{
		if($Thirst::On == 1)
		{
			$Thirst::On = 0;
			messageall("","\c6Thirst has been turned \c3off\c6.");
			cancel($thirstTick);
		}
		else
		{
			$Thirst::On = 1;
			messageall("","\c6Thirst has been turned \c3on\c6.");
			thirstTick();
		}
	}		
}
//
//function serverCmdDrinkPeople(%client)
//{
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		if($Thirst::DrinkPeeps == 1)
//		{
//			$Thirst::DrinkPeeps = 0;
//			messageall("","\c6Cannibalism has been turned \c3off\c6.");
//		}
//		else
//		{
//			$Thirst::DrinkPeeps = 1;
//			messageall("","\c6Cannibalism has been turned \c3on\c6.");
//		}
//	}		
//}
//
//function serverCmdThirstTickTime(%client, %temp)
//{
//	if(%temp <= 0)
//	{
//		%temp = 1;
//	}
//	
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		$Thirst::TickTime = %temp;
//		messageAll("","\c6The thirst tick time is now \c3" @ %temp @ "\c6 seconds.");
//	}		
//}
//
//function serverCmdThirstEvent(%client)
//{
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		if($Thirst::Event == 1)
//		{
//			$Thirst::Event = 0;
//			messageall("","\c6The incThirst event has been disabled.");
//		}
//		else
//		{
//			$Thirst::Event = 1;
//			messageall("","\c6The incThirst event has been enabled.");
//		}
//	}		
//}
//
//function serverCmdWaterCost(%client, %temp)
//{
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		$Thirst::WaterCost = %temp;
//		messageAll("","\c6The water cost is now \c3" @ $Thirst::WaterCost @ "\c6.");
//	}		
//}


//Events
registerOutputEvent(GameConnection, "incThirst", "int -90 100 10", 0);
registerOutputEvent(GameConnection, "addWater", "int 0 100 1", 0);
registerOutputEvent(fxDTSBrick, "ifPlayerThirst", "list Equals 1 NotEquals 2 Grdrinker 3 Less 4 GrdrinkerEquals 5 LessEquals 6\tint 0 100 50", 1);

function GameConnection::incThirst(%client, %amount)
{
	if(!$Thirst::On)
	{
		messageClient(%client, "", "\c7incThirst: \c6Thirst is currently disabled.");
		return;
	}
	
	if($Thirst::Event == 1)
	{
		%client.thirst = %client.thirst + %amount;
		
		if(%client.thirst > 100)
			%client.thirst = 100;
		if(%client.thirst < 0)
			%client.thirst = 0;
	}
	else
	{
		messageClient(%client,"","\c7incThirst: \c6This event is disabled.");
	}
}

function GameConnection::addWater(%client, %amount)
{
	if(!$Thirst::On)
	{
		messageClient(%client, "", "\c7addWater: \c6Thirst is currently disabled.");
		return;
	}
	
	if($Thirst::Event == 1)
	{
		$water[%client.bl_id] = $water[%client.bl_id] + %amount;
		messageClient(%client, "", "\c6You have \c3" @ $water[%client.bl_id] @ "\c6 water.");
	}
	else
	{
		messageClient(%client,"","\c7addWater: \c6This event is disabled.");
	}
}

//DATABLOCK

datablock fxDTSBrickData(brickWaterShopData : brick2x2fdata)
{
 uiName = "Water Shop Point";
 Category = "Special";
 subCategory = "Water Script";
};

//datablock fxDTSBrickData(brick3x3flatData)
//{
//	brickFile = "./3x3f.blb";
//	category = "Special";
//	subCategory = "Water Script";
//	uiName = "Corn Plant";
//	//iconName = "Add-Ons/Brick_Large_Cubes/4x Cube";
//};