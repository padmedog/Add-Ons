
datablock ParticleData(PillsHereParticle)
{
   dragCoefficient      = 5.0;
   gravityCoefficient   = -0.2;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 500;
   useInvAlpha          = false;
   textureName          = "./pills";
   colors[0]     = "0.7 0.1 0.1";
   colors[1]     = "0.5 0.7 0.2";
   colors[2]     = "0.0 0.0 0.0 0";
   sizes[0]      = 0.4;
   sizes[1]      = 0.6;
   sizes[2]      = 0.4;
   times[0]      = 0.0;
   times[1]      = 0.2;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(PillsHereEmitter)
{
   ejectionPeriodMS = 35;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionOffset   = 1.0;
   velocityVariance = 0.49;
   thetaMin         = 0;
   thetaMax         = 120;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PillsHereParticle";

   uiName = "Emote - Pills Here";
};

datablock ShapeBaseImageData(PillsHereEImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = $HeadSlot;

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 0.350;
	stateEmitter[1]					= PillsHereEmitter;
	stateEmitterTime[1]				= 0.350;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function PillsHereEImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
datablock ItemData(PillsHereItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./pillsHere.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Pills Here";
	iconName = "./Icons/Icon_PillsHere";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = pillsHereImage;
	canDrop = true;
};

datablock ShapeBaseImageData(pillsHereImage)
{
   // Basic Item properties
   shapeFile = "./pillsHere.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0.08 -0.12";
   eyeOffset = "0 0 0"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 15" );

   className = "WeaponImage";
   item = PillsHereItem;

   //raise your arm up or not
   armReady = true;

   doColorShift = false;

   // Initial start up state
	stateName[0]                     = "Ready";
	stateTransitionOnTriggerDown[0]  = "Fire";
	stateAllowImageChange[0]         = true;

	stateName[1]                     = "Fire";
	stateTransitionOnTimeout[1]      = "Ready";
	stateAllowImageChange[1]         = true;
      stateScript[1]                   = "onFire";
	stateTimeoutValue[1]		   = 1;
};

function pillsHereImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamageLevel() > 0)
	{
		%obj.playthread(2,shiftaway);
		%obj.playaudio(1,"PillsUseSound");
		%currSlot = %obj.currTool;
		if(%obj.getDamageLevel() < 50)
		{
			%restored = %obj.getDamageLevel();
			%obj.temporaryHPSet += %obj.getDamageLevel();
			%obj.setHealth(%obj.dataBlock.maxDamage);
		}
		else
		{
			%restored = 50;
			%obj.temporaryHPSet += 50;
			%obj.addHealth(50);
		}
		
		%obj.emote(PillsHereEImage,1);
		%obj.tool[%currSlot] = 0;
		%obj.weaponCount--;
		
		cancel(%obj.temporaryHPBleed);
		%obj.temporaryHPBleed = %obj.schedule(3000,doHPBleed);
		
		if(isObject(%obj.client))
		{
			messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
			serverCmdUnUseTool(%obj.client);
			if(%obj.getWhiteOut() < 0.4*%restored/50)
				%obj.setWhiteOut(0.4*%restored/50);
			if(%obj.getDamageFlash() < 0.6*%restored/50)
				%obj.setDamageFlash(0.6*%restored/50);
		}
		else
			%obj.unMountImage(%slot);
		%obj.unmountimage(1);
		
	}
}
function Player::doHPBleed(%obj)
{
	if(%obj.temporaryHPSet > 1)
	{
		%damage = 1;
		%obj.temporaryHPSet -= 1;
		%obj.temporaryHPBleed = %obj.schedule(1000,doHPBleed);
	}
	else
	{
		%damage = %obj.temporaryHPSet;
		%obj.temporaryHPSet = 0;
	}
	
	if(%obj.getDamageLevel() + %damage >= %obj.dataBlock.maxDamage)
	{
		%obj.setHealth(1);
		cancel(%obj.temporaryHPBleed);
		%obj.temporaryHPSet = 0;
	}
	else
	{
		%obj.addHealth(-%damage);
		%flash = %obj.getDamagePercent() * 0.5;
		//%flash = ((%obj.getDamageFlash() + %flash) > 0.5 ? 0.5 : (%obj.getDamageFlash() + %flash));
		if(%obj.getDamageFlash() < %flash)
			%obj.setdamageflash(%flash);
	}
}


datablock DecalData(PillsHereIcon)
{
   textureName = "./pillshere";
};
datablock AudioProfile(PillsUseSound)
{
	filename = "./PillsUse.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock ShapeBaseImageData(pillsHereFrontImage)
{
   // Basic Item properties
   shapeFile = "./pillsHere.dts";
   emap = true;

   mountPoint = 7;
   offset = "-0.3 0.3 0.25";
   eyeOffset = "1 0 0"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   armReady = false;
   doColorShift = false;
};
function pillsHereImage::onMount(%this,%obj,%slot)
{
	%obj.playaudio(1,"PillsUseSound");
	if(isobject(%obj.getmountedimage(1)) && %obj.getmountedimage(1).getname() $= "pillsHereFrontImage")
	{
		%obj.unmountimage(1);
	}
	parent::onMount(%this,%obj,%slot);
}

function pillsHereImage::onUnMount(%this,%obj,%slot)
{
	Parent::onUnMount(%this,%obj,%slot);
		//%obj.playThread(1, root);
	if(!isobject(%obj.getmountedimage(1)))
	{
		%obj.mountimage(pillsHereFrontImage,1);
	}
}

function pillsHereItem::onPickup(%this,%obj,%col,%a)
{
	for(%i=0;%i<%col.getdatablock().maxTools;%i++)
	{
		%item = %col.tool[%i];
		if(%item $= 0 || %item $= "")
		{
			%freeSlot = 1;
			break;
		}
	}
	if(%obj.canpickup && !isobject(%col.getmountedimage(1)) && %freeSlot)
	{
		%col.mountimage(pillsHereFrontImage,1);
	}
	parent::onPickup(%this,%obj,%col,%a);
}

package L4BpillsHerePackage
{
	function servercmdDropTool(%this,%slot)
	{
		if(isobject(%this.player.tool[%slot]) && %this.player.tool[%slot].getname() $= "pillsHereItem")
		{
			parent::servercmdDropTool(%this,%slot);

			if(isobject(%this.player.getmountedimage(1)) && %this.player.getmountedimage(1).getname() $= "pillsHereFrontImage")
			{
				%this.player.schedule(5,unmountimage,1);
			}
			return;
		}
		parent::servercmdDropTool(%this,%slot);
	}
};
activatepackage(L4BpillsHerePackage);