package CountryDetectorPackage
{
   function gameConnection::AutoAdminCheck(%this)
	{
		schedule(500, %this, startCountryDetectorSearch, %this);
		Parent::autoAdminCheck(%this);
	}
};
activatepackage(CountryDetectorPackage);

function startCountryDetectorSearch(%client)
{
	%ip = %client.getrawIP();
	
	if(isObject($CountryFinderObject))
	{
		schedule(1000, %client, startCountryDetectorSearch, %client);
		//echo("Country search quota delayed");
		return;
	}
	
	$CountryFinderObject = new HTTPObject(CountryTraceIPClass)
	{
		ip = %ip;
		client = %client;
	};
	
	if(%ip !$= "local")
		$CountryFinderObject.get("ipinfo.io:80","/" @ %ip @ "/country");
		
	else
		$CountryFinderObject.get("ipinfo.io:80","/country");
	
	$CountryFinderObject.schedule(30000, delete);
}

function CountryTraceIPClass::onLine(%this, %line)
{
	%name = trim(%line);
	
	%country = matchCountrybyName(%name);
	%client = %this.client;
	
	if(%name $= "US")
	{
	$SurvivalMod::Data::ID[%client.bl_id,TempType] = "Fahrenheit";
	}
	else
	{
	$SurvivalMod::Data::ID[%client.bl_id,TempType] = "Celsius";
	}
		
	$countryCountry[%name]++;
	export("$countryCountry*", "config/server/countryStats.cs", 0);
		
	%this.schedule(0,delete);
}

function matchCountrybyName(%name)
{
	%datablock = "bitmapCountry" @ %name @ "data";
	%datablock = nameToID(%datablock);
	
	if(isObject(%datablock))
		%tex = %datablock.textureName;
		
	else
		%tex = "add-ons/Server_NationalCountrys/countrys/default";
		
	return %tex;
}