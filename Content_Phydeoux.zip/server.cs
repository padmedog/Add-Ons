%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("Content_Phydeoux: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/PressureDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/SlidingGLassDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/ElevatorDoors.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/AirlockSmallDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/BlastSmallDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/GateDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/Fan.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/GiantFan.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/GiantFanFlat.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/VerticalDialSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/horizontalDialSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/VerticalSlideSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/horizontalSlideSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/VerticalKeySwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/HorizontalKeySwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/SuperButton.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/TNTPlunger.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/LargeGarageDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeoux/types/BoomBarrier.cs");
}