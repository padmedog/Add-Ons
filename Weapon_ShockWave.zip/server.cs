//ShockWave.cs

//audio
datablock AudioProfile(ShockWaveFireSound)
{
   filename    = "./ShockWaveFire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(ShockWaveExplodeSound)
{
   filename    = "./ShockWaveHit.wav";
   description = AudioDefault3d;
   preload = true;
};


datablock ParticleData(ShockWaveSmokeParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 250;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   	colors[0]     = "0.10 0.10 0.10 0.2";
	colors[1]     = "0.10 0.10 0.10 0.5";
	colors[2]     = "0.03 0.03 0.03 0.0";

	sizes[0]      = 0.25;
   	sizes[1]      = 1.0;
	sizes[2]      = 1.75;

   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ShockWaveSmokeEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ShockWaveSmokeParticle";

   uiName = "ShockWave  Smoke";
};


//bullet trail effects
datablock ParticleData(ShockWaveTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 105;
	textureName          = "base/data/particles/thinring";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1 1 1 0.3";
	colors[1]     = "0.5 0.5 0.5 0.3";
 	colors[2]     = "1 1 1 0.2";
 	colors[3]     = "0 0 0 0.0";

	sizes[0]      = 0;
	sizes[1]      = 3;
  	sizes[2]      = 9;
 	sizes[3]      = 12;

  	times[0] = 0;
  	times[1] = 0.3;
  	times[2] = 0.7;
  	times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ShockWaveTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ShockWaveTrailParticle";

   uiName = "ShockWave Trail";
};


datablock ExplosionData(ShockwaveExplosion)
{
   explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
	soundProfile = ShockwaveExplodeSound;

   lifeTimeMS = 50;

   particleEmitter = ShockwaveSmokeEmitter;
   particleDensity = 10;
   particleRadius = 7;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "1 1 1 1";
   lightEndColor = "0 0 0 0";

   damageRadius = 3;
   radiusDamage = 5;

   impulseRadius = 4;
   impulseForce = 5000;
};


AddDamageType("ShockWaveDirect",   '<bitmap:add-ons/weapon_ShockWave/CI_ShockWave> %1',    '%2 <bitmap:add-ons/weapon_ShockWave/CI_ShockWave> %1',1,1);

datablock ProjectileData(ShockWaveProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 10;
   directDamageType = $DamageType::ShockWaveDirect;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;
   
   sound = ShockWaveFireSound;
   particleEmitter     = ShockWaveTrailEmitter;
   explosion           = ShockWaveExplosion;
   
   impactImpulse	     = 500;
   verticalImpulse	   = 500;

   brickExplosionRadius = 3;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   armingDelay         = 0;
   lifetime            = 210;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   uiName = "ShockWave";
};

//////////
// item //
//////////
datablock ItemData(ShockWaveItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./ShockWave.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "ShockWave";
	iconName = "./icon_ShockWave";
	doColorShift = false;
	colorShiftColor = "0.100 0.500 0.250 1.000";

	 // Dynamic properties defined by the scripts
	image = ShockWaveImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ShockWaveImage)
{
   // Basic Item properties
   shapeFile = "./ShockWave.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = ShockWaveProjectile;
   projectileType = Projectile;

	//casing = ShockWaveShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 700;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = false;
   colorShiftColor = ShockWaveItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.1;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
   stateTransitionOnNoAmmo[1]       = "NoAmmo";
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.1;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= tailNode;
	stateSound[2]					= ShockWaveFireSound;
   stateSequence[2]                = "Fire";
	//stateEjectShell[2]       = true;

	stateName[3] = "Smoke";
	stateEmitter[3]					= ShockWaveSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.1;
   stateSequence[3]                = "TrigDown";
	stateTransitionOnTimeout[3]     = "CoolDown";

   stateName[5] = "CoolDown";
   stateTimeoutValue[5]            = 0.5;
	stateTransitionOnTimeout[5]     = "Reload";
   stateSequence[5]                = "TrigDown";


	stateName[4]			= "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "TrigDown";

   stateName[6]   = "NoAmmo";
   stateTransitionOnAmmo[6] = "Ready";

};

function ShockWaveImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, plant);
	Parent::onFire(%this,%obj,%slot);	
}
