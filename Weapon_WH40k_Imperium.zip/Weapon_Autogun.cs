//audio
datablock AudioProfile(AutogunFireSound)
{
   filename    = "./Autogun_fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(AutogunTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 150;
	lifetimeVarianceMS	= 50;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 0.875 0.5 0.5";
	colors[1]	= "1.0 0.75 0.0 0.5";
	colors[2]	= "0.2 0.1 0 0.5";
	sizes[0]	= 0.25;
	sizes[1]	= 0.0;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(AutogunTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = AutogunTrailParticle;

};

datablock ParticleData(AutogunExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 450;
	lifetimeVarianceMS   = 200;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.9 0.3";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.5;
	sizes[1]      = 0.75;

	useInvAlpha = true;
};
datablock ParticleEmitterData(AutogunExplosionEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "AutogunExplosionParticle";

};

datablock ParticleData(AutogunExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 50;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.25 0.15 1";
	colors[1]     = "0.4 0.15 0.05 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.75;

	useInvAlpha = false;
};
datablock ParticleEmitterData(AutogunExplosionRingEmitter)
{
	lifeTimeMS = 300;

   ejectionPeriodMS = 12;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "AutogunExplosionRingParticle";

};

datablock ParticleData(AutogunFlashParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 15;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1.0 0.875 0.5 0.9";
	colors[1]     = "1.0 0.75 0.0 0.9";
	sizes[0]      = 1.0;
	sizes[1]      = 0.25;
	times[0]	= 0.0;
	times[1]	= 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(AutogunFlashEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 60.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "AutogunFlashParticle";

};

datablock ExplosionData(AutogunExplosion)
{
   //explosionShape = "";
	soundProfile = BoltpistolHitSound;

   lifeTimeMS = 100;

   particleEmitter = AutogunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = AutogunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 1.5;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 1;
   lightStartColor = "1.0 0.75 0.25";
   lightEndColor = "0 0 0";
};

AddDamageType("Autogun",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Autogun> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Autogun> %1',0.75,1);
datablock ProjectileData(AutogunProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::Autogun;
   radiusDamageType    = $DamageType::Autogun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 5;
   brickExplosionMaxVolume = 7;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 11;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = AutogunExplosion;
   particleEmitter     = "AutogunTrailEmitter";

   muzzleVelocity      = 150;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 8000;
   fadeDelay           = 7200;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.05;

   hasLight    = true;
   lightRadius = 1.0;
   lightColor  = "1 0.75 0";
   
   isBallistic         = true;
   gravityMod = 0.1;
   
   uiName = "Autogun Shot";
   
};

//////////
// item //
//////////
datablock ItemData(AutogunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Autogun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Autogun";
	iconName = "./Autogun";
	doColorShift = false;
	colorShiftColor = "0.7 0.7 0.72 1.000";

	 // Dynamic properties defined by the scripts
	image = AutogunImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 50;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(AutogunImage)
{

   // Basic Item properties
   shapeFile = "./Autogun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = AutogunItem;
   ammo = " ";
   projectile = AutogunProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = AutogunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.05;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.00;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= AutogunFlashEmitter;
	stateEmitterTime[2]		= 0.1;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= AutogunfireSound;
    stateEjectShell[2]       = true;
	
	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.01;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.001;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.08;
	stateTransitionOnTimeout[4]	= "Ready";
	
};

function AutogunImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, plant);

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0024;
	}
	else
	{
		%spread = 0.0024;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}
function AutogunImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
}


