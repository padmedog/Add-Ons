function modServerGUI()
{
	if($JSmod)
		return;
	$JSmod = true;

	if(!isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
	{

		JS_Window.extent = "740 480";
		JS_Window.getObject(1).extent = "720 372";
		JS_serverList.extent = "720 8";
		JS_serverList.columns = "0 37 100 340 385 404 415 445 510 610";
		JS_Window.getObject(11).command = "JS_sortList(2);";
		JS_Window.getObject(7).position = "610 440";

		JS_window.add( new GuiBitmapButtonCtrl(nameSortButton) {
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "638 34";
			extent = "47 19";
			minExtent = "8 2";
			visible = "1";
			command = "JS_sortList(9);";
			text = "Host";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "base/client/ui/button1";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			mKeepCached = "1";
			mColor = "255 255 255 255";
			wrap = "0";
		} );
	}
	else
	{
		
		JS_Window.extent = "820 480";
		JS_Window.getObject(1).extent = "800 372";
		JS_serverList.extent = "800 8";
		JS_serverList.columns = "0 34 125 340 385 404 415 445 510 9000 625 685";
		JS_Window.getObject(11).command = "JS_sortList(2);";
		JS_Window.getObject(7).position = "700 440";
		if(JS_Window.getObject(14).text $= "RTB")
			JS_Window.getObject(14).command = "JS_sortList(10);";

		JS_window.add( new GuiBitmapButtonCtrl(nameSortButton) {
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "700 34";
			extent = "47 19";
			minExtent = "8 2";
			visible = "1";
			command = "JS_sortList(9);";
			text = "Host";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "base/client/ui/button1";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			mKeepCached = "1";
			mColor = "255 255 255 255";
			wrap = "0";
		} );
	}
}

modServerGUI();

package separateNames
{
	function ServerSO::serialize(%this)
   	{
     		%serialized = Parent::serialize(%this);
		if(!isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
		{
			%pass = getField(%serialized,0);
			%ded = getField(%serialized,1);
			%name = getField(%serialized,2);
			%ping = getField(%serialized,3);
			%players = getField(%serialized,4);
			%slash = getField(%serialized,5);
			%maxplayers = getField(%serialized,6);
			%bricks = getField(%serialized,7);
			%gamemode = getField(%serialized,8);
			%ip = getField(%serialized,9);
			%othername = getField(%serialized,10);
			if(stripos(%name,"'s ") != -1)
			{
				%host = getSubStr(%name,0,stripos(%name,"'s "));
				%name = getSubStr(%name,stripos(%name,"'s ")+3,strLen(%name)-(stripos(%name,"'s ")+3));
				return %pass TAB %ded TAB %name TAB %ping TAB %players TAB %slash TAB %maxPlayers TAB %bricks TAB %gamemode TAB %host TAB %ip;
			}
			else if(stripos(%name,"s' ") != -1)
			{
				%host = getSubStr(%name,0,stripos(%name,"s' "));
				%name = getSubStr(%name,stripos(%name,"s' ")+3,strLen(%name)-(stripos(%name,"s' ")+3));
				return %pass TAB %ded TAB %name TAB %ping TAB %players TAB %slash TAB %maxPlayers TAB %bricks TAB %gamemode TAB %host TAB %ip;
			}
			else
				return %serialized;
		}
		else
		{
			%pass = getField(%serialized,0);
			%ded = getField(%serialized,1);
			%name = getField(%serialized,2);
			%ping = getField(%serialized,3);
			%players = getField(%serialized,4);
			%slash = getField(%serialized,5);
			%maxplayers = getField(%serialized,6);
			%bricks = getField(%serialized,7);
			%gamemode = getField(%serialized,8);
			%ip = getField(%serialized,9);
			%othername = getField(%serialized,10);
			%rtb = getField(%serialized,11);

			if(stripos(%name,"'s ") != -1)
			{
				%host = getSubStr(%name,0,stripos(%name,"'s "));
				%name = getSubStr(%name,stripos(%name,"'s ")+3,strLen(%name)-(stripos(%name,"'s ")+3));
				return %pass TAB %ded TAB %name TAB %ping TAB %players TAB %slash TAB %maxPlayers TAB %bricks TAB %gamemode TAB %othername TAB %rtb TAB %host TAB %ip;
			}
			else if(stripos(%name,"s' ") != -1)
			{
				%host = getSubStr(%name,0,stripos(%name,"s' ")+1);
				%name = getSubStr(%name,stripos(%name,"s' ")+3,strLen(%name)-(stripos(%name,"s' ")+3));
				return %pass TAB %ded TAB %name TAB %ping TAB %players TAB %slash TAB %maxPlayers TAB %bricks TAB %gamemode TAB %othername TAB %rtb TAB %host TAB %ip;
			}
			else
				return %serialized;
		}
	}
};
activatepackage(separateNames);
