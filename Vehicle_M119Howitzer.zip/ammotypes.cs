//######### Shells

//### Sound

datablock AudioProfile(gc_ExplosionSound)
{
  filename = "./explosion.wav";
  description = AudioDefault3d;
  preload = true;
};

datablock AudioProfile(gc_M119LoadSound)
{
  filename = "./m119load.wav";
  description = AudioClosest3d;
  preload = true;
};

//###Effects

datablock ParticleData(gc_M119ShellHEExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 50;
  textureName = "base/data/particles/star1";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 30;
  sizes[1] = 15;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_M119ShellHEExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119ShellHEExplosionParticle";
};

datablock ParticleData(gc_M119ShellHESmokeParticle)
{
  dragCoefficient = 15;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 10;
  sizes[1] = 20;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_M119ShellHESmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 100;
  velocityVariance = 100;
  ejectionOffset = 2.5;
  thetaMin = 75;
  thetaMax = 95;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119ShellHESmokeParticle";
};

datablock ExplosionData(gc_M119ShellHEExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_M119ShellHEExplosionEmitter;
  emitter[1] = gc_M119ShellHESmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 20;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 10;
  radiusDamage = 400;
  impulseRadius = 20;
  impulseForce = 400;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "10 10 10";
  camShakeDuration = 3;
  camShakeRadius = 40;
};

datablock ParticleData(gc_M119ShellClusterExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 50;
  textureName = "base/data/particles/star1";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 20;
  sizes[1] = 15;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_M119ShellClusterExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119ShellClusterExplosionParticle";
};

datablock ParticleData(gc_M119ShellClusterSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 10;
  sizes[1] = 20;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_M119ShellClusterSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 5;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 5;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119ShellClusterSmokeParticle";
};

datablock ExplosionData(gc_M119ShellClusterExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_M119ShellClusterExplosionEmitter;
  emitter[1] = gc_M119ShellClusterSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 10;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 5;
  radiusDamage = 100;
  impulseRadius = 10;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 20;
};

datablock ExplosionData(gc_M119ShellToxicExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_M119ShellClusterExplosionEmitter;
  emitter[1] = gc_M119ShellClusterSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 10;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 5;
  radiusDamage = 100;
  impulseRadius = 10;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 20;
};

datablock ParticleData(gc_M119ShellToxicStayParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 5000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = 0;
  spinRandomMax = 0;
  colors[0] = "1 0 0 0";
  colors[1] = "0.5 0 0 0.5";
  colors[2] = "0.25 0 0.25 0";
  sizes[0] = 10;
  sizes[1] = 15;
  sizes[2] = 20;
  times[0] = 0;
  times[1] = 0.3;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_M119ShellToxicStayEmitter)
{
  uiName = "";
  ejectionPeriodMS = 25;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 0;
  ejectionOffset = 20;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119ShellToxicStayParticle";
};

datablock ParticleData(gc_poisoningHeavyEffectParticle)
{
  dragCoefficient = 5;
  gravityCoefficient = -0.2;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  useInvAlpha = false;
  textureName = "base/data/particles/cloud";
  colors[0] = "1 0 0 0";
  colors[1] = "05 0 0 0.5";
  colors[2] = "0.25 0 0.25 0";
  sizes[0] = 0.8;
  sizes[1] = 1;
  sizes[2] = 0.8;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_poisoningHeavyEffectEmitter)
{
  uiName = "";
  ejectionPeriodMS = 25;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0.5;
  ejectionOffset = 1;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = true;
  useEmitterColors = false;
  orientParticles = false;
  particles = "gc_poisoningHeavyEffectParticle";
};

datablock ShapeBaseImageData(gc_poisoningHeavyEffectImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = $HeadSlot;

  stateName[0] = "Ready";
  stateTransitionOnTimeout[0] = "Fire";
  stateTimeoutValue[0] = 0.01;

  stateName[1] = "Fire";
  stateTransitionOnTimeout[1] = "Done";
  stateWaitForTimeout[1] = true;
  stateTimeoutValue[1] = 0.5;
  stateEmitter[1] = gc_poisoningHeavyEffectEmitter;
  stateEmitterTime[1] = 0.5;

  stateName[2] = "Done";
  stateScript[2] = "onDone";
};

function gc_poisoningHeavyEffectImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

//### Projectiles

AddDamageType("gc_M119",'<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119>%1','%2<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119>%1',1,1);

datablock ProjectileData(gc_M119ShellHEProjectile)
{
  uiName = "";
  name = "High-Explosive Shell";
  projectileShapeName = "./m119projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_M119;
  radiusDamageType = $DamageType::gc_M119;
  brickExplosionRadius = 5;
  brickExplosionImpact = true;
  brickExplosionForce = 100;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 100;
  particleEmitter = gc_M119ShellTrailEmitter;
  explosion = gc_M119ShellHEExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 60000;
  fadeDelay = 60000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = 1;
};

AddDamageType("gc_M119Cluster",'<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119cluster>%1','%2<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119cluster>%1',1,1);

datablock ProjectileData(gc_M119ShellClusterProjectile)
{
  uiName = "";
  name = "Cluster Shell";
  projectileShapeName = "./m119projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_M119Cluster;
  radiusDamageType = $DamageType::gc_M119Cluster;
  brickExplosionRadius = 5;
  brickExplosionImpact = true;
  brickExplosionForce = 100;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 100;
  particleEmitter = gc_M119ShellTrailEmitter;
  explosion = gc_M119ShellClusterExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 60000;
  fadeDelay = 60000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = 1;
};

datablock ProjectileData(gc_M119ShellClusterFragmentProjectile)
{
  uiName = "";
  projectileShapeName = "./m119projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_M119Cluster;
  radiusDamageType = $DamageType::gc_M119Cluster;
  brickExplosionRadius = 5;
  brickExplosionImpact = true;
  brickExplosionForce = 100;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 100;
  particleEmitter = gc_M119ShellTrailEmitter;
  explosion = gc_M119ShellClusterExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 5000;
  fadeDelay = 5000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = 1;
};

function gc_M119ShellClusterLoop(%obj)
{
  if(!isObject(%obj)) return;
  %vector = VectorScale(VectorNormalize(%obj.getVelocity()),250);
  %raycast = containerRayCast(VectorAdd(%obj.getPosition(),%vector),%obj.getPosition(),$TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType | $TypeMasks::fxBrickObjectType);
  if(isObject(firstWord(%raycast)))
  {
    for(%i=0;%i<10;%i++)
    {
      %x = (getRandom(-4,4) - 0.5) * 3.141592653;
      %y = (getRandom(-4,4) - 0.5) * 3.141592653;
      %z = (getRandom(-4,4) - 0.5) * 3.141592653;
      %p = new Projectile()
      {
        dataBlock = gc_M119ShellClusterFragmentProjectile;
        initialVelocity = VectorAdd(%obj.getVelocity(),%x SPC %y SPC %z);
        initialPosition = %obj.getPosition();
        sourceObject = %obj;
        client = %obj.client;
      };
    }
    MissionCleanup.add(%p);
    %obj.delete();
    return;
  }
  Schedule(500,0,"gc_M119ShellClusterLoop",%obj);
}

function gc_M119ShellClusterProjectile::onExplode(%this,%obj)
{
  parent::onExplode(%this,%obj);
  for(%i=0;%i<10;%i++)
  {
    %x = (getRandom(-5,5) - 0.5) * 3.141592653;
    %y = (getRandom(-5,5) - 0.5) * 3.141592653;
    %z = (getRandom(-5,5) - 0.5) * 3.141592653;
    %p = new Projectile()
    {
      dataBlock = gc_M119ShellClusterFragmentProjectile;
      initialVelocity = VectorAdd(%obj.getVelocity(),%x SPC %y SPC %z);
      initialPosition = %obj.getPosition();
      sourceObject = %obj;
      client = %obj.client;
    };
  }
  MissionCleanup.add(%p);
}

AddDamageType("gc_M119Napalm",'<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119napalm>%1','%2<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119napalm>%1',1,1);

datablock ProjectileData(gc_M119ShellNapalmProjectile)
{
  uiName = "";
  name = "Napalm Shell";
  projectileShapeName = "./m119projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_M119Napalm;
  radiusDamageType = $DamageType::gc_M119Napalm;
  brickExplosionRadius = 5;
  brickExplosionImpact = true;
  brickExplosionForce = 100;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 100;
  particleEmitter = gc_M119ShellTrailEmitter;
  explosion = gc_M119ShellClusterExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 60000;
  fadeDelay = 60000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = 1;
};

datablock ProjectileData(gc_M119ShellNapalmFragmentProjectile)
{
  uiName = "";
  projectileShapeName = "";
  directDamage = 10;
  radiusDamage = 10;
  damageRadius = 10;
  directDamageType = $DamageType::gc_M119Napalm;
  radiusDamageType = $DamageType::gc_M119Napalm;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 30000;
  lifetime = 30000;
  fadeDelay = 30000;
  bounceElasticity = 0;
  bounceFriction = 1;
  isBallistic = true;
  gravityMod = 1;
  particleEmitter = gc_fireEmitter;
  hasLight = 1;
  lightRadius = 10;
  lightColor = "1 0.6 0.2";
};

function gc_NapalmShellDamage(%sourceObject,%position,%radius,%damage,%damageType,%impulse,%duration)
{
  radiusDamage(%sourceObject,%position,%radius,%damage,%damageType,%impulse);
  if(%duration < 0) return;
  schedule(200,0,continuousDamage,%sourceObject,%position,%radius,%damage,%damagetype, %impulse,%duration-500);
}

function gc_M119ShellNapalmProjectile::onExplode(%this,%obj)
{
  parent::onExplode(%this,%obj);
  for(%i=0;%i<15;%i++)
  {
    %x = (getRandom(-3,3) - 0.5) * 3.141592653;
    %y = (getRandom(-3,3) - 0.5) * 3.141592653;
    %z = (getRandom(-3,3) - 0.5) * 3.141592653;
    %p = new Projectile()
    {
      dataBlock = gc_M119ShellNapalmFragmentProjectile;
      initialVelocity = %x SPC %y SPC %z;
      initialPosition = %obj.getPosition();
      sourceObject = %obj;
      client = %obj.client;
    };
    MissionCleanup.add(%p);
  }
}

function gc_M119ShellNapalmFragmentProjectile::Damage(%this,%obj,%col,%fade,%pos,%normal)
{
  %player = %obj;
  %client = %obj.client;
  if(%this.directDamage <= 0) return;
  %damageType = $DamageType::Direct;
  if(%this.DirectDamageType) %damageType = %this.DirectDamageType;
  %scale = getWord(%obj.getScale(),2);
  %directDamage = mClampF(%this.directDamage,-100,100) * %scale;
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
    %col.damage(%obj,%pos,%directDamage,%damageType);
    if(isObject(%player.client.minigame)) gc_NapalmShellDamage(%obj,%pos,%this.damageRadius,%this.radiusDamage,%this.radiusDamageType,0,10000); }
  else {
    %col.damage(%obj,%pos,%directDamage,%damageType);
    if(isObject(%player.client.minigame)) gc_NapalmShellDamage(%obj,%pos,%this.damageRadius,%this.radiusDamage,%this.radiusDamageType,0,10000); }
}

AddDamageType("gc_M119Toxic",'<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119toxic>%1','%2<bitmap:Add-Ons/Vehicle_M119Howitzer/CI_m119toxic>%1',1,1);

datablock ProjectileData(gc_M119ShellToxicProjectile)
{
  uiName = "";
  name = "Toxic Shell";
  projectileShapeName = "./m119projectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_M119Toxic;
  radiusDamageType = $DamageType::gc_M119Toxic;
  brickExplosionRadius = 5;
  brickExplosionImpact = true;
  brickExplosionForce = 100;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 100;
  particleEmitter = gc_M119ShellTrailEmitter;
  explosion = gc_M119ShellToxicExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 60000;
  fadeDelay = 60000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = 1;
};

datablock ProjectileData(gc_M119ShellToxicStayProjectile)
{
  uiName = "";
  projectileShapeName = "";
  directDamage = 0;
  particleEmitter = gc_M119ShellToxicStayEmitter;
  muzzleVelocity = 0;
  verInheritFactor = 0;
  armingDelay = 60000;
  lifetime = 60000;
  fadeDelay = 60000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
};

function gc_M119ShellToxicProjectile::onExplode(%this,%obj)
{
  parent::onExplode(%this,%obj);
  %p = new Projectile()
  {
    dataBlock = gc_M119ShellToxicStayProjectile;
    initialVelocity = 0;
    initialPosition = %obj.getPosition();
    sourceObject = %obj;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
  Schedule(1000,0,"gc_M119ToxicGas",%p);
}

function gc_M119ToxicGas(%obj)
{
  if(!isObject(%obj)) return;
  Schedule(500,0,"gc_M119ToxicGas",%obj);
  InitContainerRadiusSearch(%obj.getPosition(),40,$TypeMasks::PlayerObjectType);
  while((%target = containerSearchNext()) != 0)
  {
    if(getMiniGameFromObject(%obj.client) == -1) break;
    if(%target.getClassName() !$= "Player") continue;
    if(getMiniGameFromObject(%obj.client) != getMiniGameFromObject(%target.client)) continue;
    if(%target.isDisabled()) continue;
    if(isObject(%target.getMountedImage(2)))
      if(%target.getMountedImage(2).getName() $= "gc_GasMaskMountedImage" || %target.getMountedImage(2).getName() $= "GasmaskMaskImage")
        continue;
    if(%target.gc_poisoningHeavy) continue;
    gc_poisoningHeavy(%target,10);
  }
}

function gc_poisoningHeavy(%obj,%duration)
{
  if(!isObject(%obj)) return 0;
  if(%duration < 1) return 0;
  if(%obj.isDisabled()) return 0;
  %obj.damage(%obj,%obj.getPosition(),10,$DamageType::gc_M119Toxic);
  %duration--;
  %obj.gc_poisoningHeavy = schedule(2000,0,gc_poisoningHeavy,%obj,%duration);
  %obj.setDamageFlash(%obj.getDamageFlash()+0.1);
  %obj.emote(gc_poisoningHeavyEffectImage);
}

//### Ammo Items

//### HE Shell

datablock ItemData(gc_M119ShellHEItem)
{
  uiName = "M119 Shell HE";
  iconName = "./icon_shellhe";
  image = gc_M119ShellHEImage;
  category = "Tools";
  className = "Weapon";
  shapeFile = "./shell_he.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

datablock ShapeBaseImageData(gc_M119ShellHEImage)
{
  shapeFile = "./shell_he.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_M119ShellHEItem;
  melee = false;
  doReaction = false;
  armReady = false;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTimeOut[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

function gc_M119ShellHEImage::onFire(%this,%obj,%slot)
{
  %raycast = containerRayCast(%obj.getEyePoint(),vectorAdd(%obj.getEyePoint(),vectorScale(%obj.getEyeVector(),3)),$TypeMasks::PlayerObjectType,%obj);
  %thing = firstWord(%raycast);
  if(isObject(%thing) && %thing.dataBlock.getID() == gc_M119TurretPlayer.getID())
  {
    if(getSimTime() - %thing.lastShotTime < 4000) { centerPrint(%obj.client,"I have to wait!",1); return; }
    %thing.lastShotTime = getSimTime();
    %thing.loaded = "gc_m119ShellHEProjectile";
    serverPlay3D(gc_M119LoadSound,%obj.getTransform());
    centerPrint(%obj.client,"HE Shell loaded!",1);
    %currSlot = %obj.currTool;
    %obj.tool[%currSlot] = 0;
    %obj.weaponCount--;
    messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
    serverCmdUnUseTool(%obj.client);
  }
}

//### Cluster Shell

datablock ItemData(gc_M119ShellClusterItem : gc_M119ShellHEItem)
{
  uiName = "M119 Shell Cluster";
  iconName = "./icon_shellcluster";
  image = gc_M119ShellClusterImage;
  shapeFile = "./shell_cluster.dts";
};

datablock ShapeBaseImageData(gc_M119ShellClusterImage : gc_M119ShellHEImage)
{
  shapeFile = "./shell_cluster.dts";
  item = gc_m119ShellClusterItem;

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTimeOut[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

function gc_M119ShellClusterImage::onFire(%this,%obj,%slot)
{
  %raycast = containerRayCast(%obj.getEyePoint(),vectorAdd(%obj.getEyePoint(),vectorScale(%obj.getEyeVector(),3)),$TypeMasks::PlayerObjectType,%obj);
  %thing = firstWord(%raycast);
  if(isObject(%thing) && %thing.dataBlock.getID() == gc_M119TurretPlayer.getID())
  {
    if(getSimTime() - %thing.lastShotTime < 4000) { centerPrint(%obj.client,"I have to wait!",1); return; }
    %thing.lastShotTime = getSimTime();
    %thing.loaded = gc_m119ShellClusterProjectile;
    serverPlay3D(gc_M119LoadSound,%obj.getTransform());
    centerPrint(%obj.client,"Cluster Shell loaded!",1);
    %currSlot = %obj.currTool;
    %obj.tool[%currSlot] = 0;
    %obj.weaponCount--;
    messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
    serverCmdUnUseTool(%obj.client);
  }
}

//### Napalm Shell

datablock ItemData(gc_M119ShellNapalmItem : gc_M119ShellHEItem)
{
  uiName = "M119 Shell Napalm";
  iconName = "./icon_shellnapalm";
  image = gc_m119ShellNapalmImage;
  shapeFile = "./shell_napalm.dts";
};

datablock ShapeBaseImageData(gc_m119ShellNapalmImage : gc_m119ShellHEImage)
{
  shapeFile = "./shell_napalm.dts";
  item = gc_m119ShellNapalmItem;

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTimeOut[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

function gc_M119ShellNapalmImage::onFire(%this,%obj,%slot)
{
  %raycast = containerRayCast(%obj.getEyePoint(),vectorAdd(%obj.getEyePoint(),vectorScale(%obj.getEyeVector(),3)),$TypeMasks::PlayerObjectType,%obj);
  %thing = firstWord(%raycast);
  if(isObject(%thing) && %thing.dataBlock.getID() == gc_M119TurretPlayer.getID())
  {
    if(getSimTime() - %thing.lastShotTime < 4000) { centerPrint(%obj.client,"I have to wait!",1); return; }
    %thing.lastShotTime = getSimTime();
    %thing.loaded = "gc_M119ShellNapalmProjectile";
    serverPlay3D(gc_M119LoadSound,%obj.getTransform());
    centerPrint(%obj.client,"Napalm Shell loaded!",1);
    %currSlot = %obj.currTool;
    %obj.tool[%currSlot] = 0;
    %obj.weaponCount--;
    messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
    serverCmdUnUseTool(%obj.client);
  }
}

//### Toxic Shell

datablock ItemData(gc_M119ShellToxicItem : gc_M119ShellHEItem)
{
  uiName = "M119 Shell Toxic";
  iconName = "./icon_shelltoxic";
  image = gc_m119ShellToxicImage;
  shapeFile = "./shell_toxic.dts";
};

datablock ShapeBaseImageData(gc_m119ShellToxicImage : gc_m119ShellHEImage)
{
  shapeFile = "./shell_toxic.dts";
  item = gc_m119ShellToxicItem;

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTimeOut[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

function gc_M119ShellToxicImage::onFire(%this,%obj,%slot)
{
  %raycast = containerRayCast(%obj.getEyePoint(),vectorAdd(%obj.getEyePoint(),vectorScale(%obj.getEyeVector(),3)),$TypeMasks::PlayerObjectType,%obj);
  %thing = firstWord(%raycast);
  if(isObject(%thing) && %thing.dataBlock.getID() == gc_M119TurretPlayer.getID())
  {
    if(getSimTime() - %thing.lastShotTime < 4000) { centerPrint(%obj.client,"I have to wait!",1); return; }
    %thing.lastShotTime = getSimTime();
    %thing.loaded = "gc_M119ShellToxicProjectile";
    serverPlay3D(gc_M119LoadSound,%obj.getTransform());
    centerPrint(%obj.client,"Toxic Shell loaded!",1);
    %currSlot = %obj.currTool;
    %obj.tool[%currSlot] = 0;
    %obj.weaponCount--;
    messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
    serverCmdUnUseTool(%obj.client);
  }
}
