//########## Flintlock Handmortar

//### Sounds

datablock AudioProfile(gc_FLHandmortarFireSound)
{
  filename = "./handmortar.wav";
  description = AudioClose3d;
  preload = true;
};

//### Effects

datablock ExplosionData(gc_FLHandmortarExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_FLBazookaExplosionEmitter;
  emitter[1] = gc_FLBazookaSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 6;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 6;
  radiusDamage = 105;
  impulseRadius = 6;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 12;
};

//### Projectile

AddDamageType("gc_FLHandmortar",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_handmortar> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_handmortar> %1',0.2,1);

datablock ProjectileData(gc_FLHandmortarProjectile)
{
  uiName = "";
  projectileShapeName = "./grenadeprojectile.dts";
  directDamage = 100;
  directDamageType = $DamageType::gc_FLHandmortar;
  radiusDamageType = $DamageType::gc_FLHandmortar;
  brickExplosionRadius = 3;
  brickExplosionImpact = true;
  brickExplosionForce = 25;
  brickExplosionMaxVolume = 50;
  brickExplosionMaxVolumeFloating = 50;
  impactImpulse = 300;
  explosion = gc_FLHandmortarExplosion;
  particleEmitter = gc_FLBombTrailEmitter;
  muzzleVelocity = 40;
  armingDelay = 500;
  lifetime = 5000;
  fadeDelay = 5000;
  bounceElasticity = 0.9;
  bounceFriction = 0.1;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = true;
//  explodeOnPlayerImpact = true;
};

//### Item

datablock ItemData(gc_FLHandmortarItem)
{
  uiName = "Handmortar";
  iconName = "./icon_handmortar";
  image = gc_FLHandmortarImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./handmortar.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_FLHandmortarImage)
{
  shapeFile = "./handmortar.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_FLHandmortarItem;
  ammo = "";
  projectile = gc_FLHandmortarProjectile;
  projectilespread = 0.001;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Smoke";
  stateTimeoutValue[2] = "0.05";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_MusketMuzzleEmitter;
  stateEmitterTime[2] = 0.1;
  stateEmitterNode[2] = "muzzlePoint";
  stateSound[2] = gc_FLHandmortarFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Fire";

  stateName[3] = "Smoke";
  stateTransitionOnTimeout[3] = "AmmoCheck";
  stateTimeoutValue[3] = "0.15";
  stateAllowImageChange[3] = false;
  stateWaitForTimeout[3] = true;
  stateEmitter[3] = gc_MusketMuzzleEmitter;
  stateEmitterTime[3] = 0.02;
  stateEmitterNode[3] = "lockPoint";

  stateName[4] = "AmmoCheck";
  stateTransitionOnTimeout[4] = "Ready";
  stateAllowImageChange[4] = true;
  stateScript[4] = "onAmmoCheck";

  stateName[5] = "Reload";
  stateTimeoutValue[5] = 4;
  stateTransitionOnTimeout[5] = "Done";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReloadStart";
  stateSequence[5] = "Reload";

  stateName[6] = "Done";
  stateTransitionOnTimeout[6] = "Ready";
  stateTimeoutValue[6] = 0.1;
  stateAllowImageChange[6] = true;
  stateScript[6] = "onReload";
};

//### Functions

function gc_FLHandmortarImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %obj.spawnExplosion(gc_weaponRecoil,"1 1 1");
  %spread = %this.projectilespread;
  if(vectorLen(%obj.getVelocity()) >= 5 && !isObject(%obj.getObjectMount())) %spread += 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
}
function gc_FLHandmortarImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_FLHandmortarImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,shiftRight); serverPlay3D(gc_FLReloadStartSound,%obj.getPosition()); }
function gc_FLHandmortarImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(0,1); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }
