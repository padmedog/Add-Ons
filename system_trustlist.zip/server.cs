//##########################################
//##########################################
//####	Project Title:	Trust List Manager
//####	Author:		Clay Hanson
//####	Timestamp:	8:10 AM 7/26/2015
//##########################################
//##########################################
function reltrustlistserver() {
	exec("./server.cs");
}
if(!$TLS::LoadedGui::SCTRL) {
	exec("./TL_S_Ctrl.gui");
	$TLS::LoadedGui::SCTRL = 1;
}
//
//Start ADDUSER function readout
//
function TLS_AddServerAction(%name,%action,%id) {
	if(isObject("SABG"@%name)) {
		TL_Error("TLS_AddServerAction :: Two buttons cannot have the same name.");
		return;
	}
	if(!isFunction(%action)) {
		TL_Error("TLS_AddServerAction :: A server action button\'s command must be without () and ;.");
		return;
	}
	if(!$TL::SL::SAddOn::Pos) {
		$TL::SL::SAddOn::Pos = 1;
	}
	%obj = "SAB"@%id;
	new GuiButtonCtrl("SABG"@%name) {
		profile = "GuiButtonProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "0 "@$TL::SL::SAddOn::Pos;
		extent = "178 30";
		minExtent = "8 2";
		command = %action@"();";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
		text = %name;
		groupNum = "-1";
		buttonType = "PushButton";
		info = "SAB"@%id;

		new GuiBitmapButtonCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "157 6";
			extent = "16 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			command = "$TLS::SAB::SelName = \""@%obj.name@"\";$TLS::SAB::SelAuth = \""@%obj.author@"\";$TLS::SAB::SelDesc = \""@%obj.desc@"\";TLS_SAB_SetInfo();";
			text = " ";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "./images/buttons/info";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			mKeepCached = "0";
			mColor = "255 255 255 255";
		};
	};
	$TL::SL::SAddOn::Pos += 30;
	TLS_SAct.add("SABG"@%name);
	TL_Echo("[TLS_AddServerAction] :: Added server button named, \"SABG"@%name@"\".");
}
function TLS_SAB_SetInfo() {
	TLS_InfoTXT.setText("<font:Verdana:16>Name: "@$TLS::SAB::SelName@"\nAuthor: "@$TLS::SAB::SelAuth@"\nDescription:\n"@$TLS::SAB::SelDesc);
	TLS_InfoSAB.tangoMoveTo("0 40",1000,elastic);
}
function TLS_DeleteServerAction(%name) {
	if(!isObject("SABG"@%name)) {
		TL_Error("TLS_DeleteServerAction :: No such server action for SABG"@%name);
		return;
	}
	if($TL::SL::SAddOn::Pos != 1) {
		$TL::SL::SAddOn::Pos -= 30;
	}
	%gui = "SABG"@%name;
	%gui.delete();
}
//
//End
//
function TLSL_GetInfo() {
	if(isObject($TL::SL::CClient)) {
		%cl = $TL::SL::CClient;
		TLSL_I_Name.setText("<just:center><font:verdana bold:20>Actions for:\n<font:verdana:14>"@%cl.name@" (ID "@%cl.bl_id@")");
	} else {
		TLSL_Refresh();
	}
}
function TLSL_CurrentClient() {
	return $TL::SL::CClient;
}
function TLSL_SABClear() {
	for(%i=0;%i<1000;%i++) {
		if(isObject("SAB"@%i)) {
			%code = "SAB"@%i;
			%gui = "SABG"@%code.name;
			%gui.delete();
			%code.delete();
		}
	}
	$TL::SL::SAddOn::Pos = 1;
}
//LOAD SERVER ACTION BUTTONS (SAB)
function TLS_LoadSAB() {
	if(isObject(TLSABCheckDesc)) {
		TL_Echo("[TLS_LoadSAB] :: It seems there is already a FileObject! Deleting...");
		TLSABCheckDesc.delete();
	}
	if(strpos("123456789",$TLS::AddonCount) != -1) {
		for(%i=0;%i<$TLS::AddonCount;%i++) {
			if(isObject("SAB"@%i)) {
				%asdf = "SAB"@%i;
				%asdf.delete();
			}
		}
	}
	TLSL_SABClear();
	%SD = new FileObject(TLSABCheckDesc);
	$TLS::AddonCount = 0;
	TL_Echo("[TLS_LoadSAB] :: Loading add-ons...");
	for(%i=0;%i<50;%i++) {
		if(isFile("add-ons/system_trustlist/serveractions/"@%i@".cs")) {
			if(isFile("add-ons/system_Trustlist/serveractions/"@%i@".txt")) {
				exec("add-ons/system_trustlist/serveractions/"@%i@".cs");
				%SD.openforread("add-ons/system_Trustlist/serveractions/"@%i@".txt");
				%name = %SD.readline();
				%author = %SD.readline();
				%desc = %SD.readline();
				%function = %SD.readline();
				if(isObject("SABG"@%name)) {
					TLS_DeleteServerAction(%name);
				}
				new ScriptObject("SAB"@%i) {
					name = %name;
					author = %author;
					desc = %desc;
					func = %function;
				};
				TL_Echo("[TLS_LoadSAB] :: Loaded add-on \""@%i@".cs\"");
				$TLS::AddonCount += 1;
				%SD.close();
				TLS_AddServerAction(%name,%function,%i);
			} else {
				TL_Error("TLS_LoadSAB :: Add-On "@%i@".cs does not have a description file!");
			}
		}
	}
	new ScriptObject("SAB999") {
		name = "Refresh";
		author = "Trust List Manager";
		desc = "Clears the Server Action Button menu.";
		func = "TLS_LoadSAB";
	};
	TLS_AddServerAction("Refresh","TLS_LoadSAB",999);
	TL_Echo("[TLS_LoadSAB] :: Loaded a total of "@$TLS::AddonCount@" add-ons.");
	%SD.delete();
}
TLS_LoadSAB();