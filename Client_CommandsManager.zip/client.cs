if(!isObject(CommandManager))    //    This stops the GUI from being executed twice..
    exec("./CommandManager.gui");

$remapDivision[$remapCount] = "Dragonoid Command GUI";
$remapName[$remapCount] = "Toggle GUI";
$remapCmd[$remapCount] = "ToggleDragonGUI";
$remapCount++;

function CommandManager::onWake(%this)
{
    %res = getRes();
    %window = %this.getObject(0);
    %window.position = (getWord(%res, 0)/2)-(getWord(%window.extent, 0)/2) SPC (getWord(%res, 1)/2)-(getWord(%window.extent, 1)/2);
}

function ToggleDragonGUI(%toggle)
{
        if(%toggle)
        {
                if(CommandManager.isAwake())
                {
                        canvas.popDialog(CommandManager);
                }
                
                else
                {
                        canvas.pushDialog(CommandManager);
                }
        }
}





//Non-Admin commands

function b_clearbricks()
{	
    messageBoxYesNo("Clear Bricks?", "Are you sure you want to <color:880000>Clear Your Bricks?", "do_clearbricks();");
}

function do_clearbricks()
{
    CommandToServer('clearbricks');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Your Bricks have been cleared!");
}


function b_Avatar()
{
    Canvas.pushDialog(AvatarGui);
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Toggled Avatar GUI");
}



function b_love()
{
    CommandToServer('love');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Emote: <color:ff00ff>Love");
}


function b_alarm()
{
    CommandToServer('alarm');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Emote: <color:ffffff>Alarm");
}


function b_hate()
{
    CommandToServer('hate');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Emote: <color:ff0000>Hate");
}


function b_confusion()
{
    CommandToServer('wtf');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Emote: <color:ff00ff>Confusion / WTF?");
}

function b_Duplicator()
{
    CommandToServer('Duplicator');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Duplicator Equipped (If server has it)");
}


function b_Wand()
{
    CommandToServer('Wand');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Wand Equipped (If server has it)");
}


function b_Fillprinter()
{
    CommandToServer('Fillprinter');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Fill Printer Equipped (If server has it)");
}


function b_Fillcan()
{
    CommandToServer('Fillcan');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Fillcan Equipped (If server has it)");
}

//Admin Commands

function b_clearallbricks()
{
    messageBoxYesNo("Clear All Bricks?", "Are you sure you want to <color:880000>ClearAllbricks?", "do_clearAllBricks();");
}

function do_clearAllBricks()
{
    CommandToServer('clearAllBricks');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>All bricks have been Cleared! <color:ff0000>(Only if you are an admin)");
}




function b_clearspambricks()
{
    messageBoxYesNo("Clear Spam Bricks?", "Are you sure you want to <color:880000>ClearSpambricks?", "do_clearSpamBricks();");
}

function do_clearSpamBricks()
{
    CommandToServer('clearSpamBricks');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Spam bricks have been Cleared! <color:ff0000>(Only if you are an admin)");
}




function b_clearfloatingbricks()
{
    messageBoxYesNo("Clear Floating Bricks?", "Are you sure you want to <color:880000>ClearFloatingBricks?", "do_ClearFloatingBricks();");
}

function do_ClearFloatingBricks()
{
    CommandToServer('ClearFloatingBricks');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Floating have been Cleared! <color:ff0000>(Only if you are an admin)");
}




function b_ClearAllVehicles()
{	
    messageBoxYesNo("Clear All Vehicles?", "Are you sure you want to <color:880000>Clear All Vehicles?", "do_ClearVehicles();");
}

function do_ClearVehicles()
{
    CommandToServer('ClearVehicles');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>All Vehicles have been cleared! <color:ff0000>(Only if you are an admin)");
}




function b_ClearBots()
{	
    messageBoxYesNo("Clear All Bots?", "Are you sure you want to <color:880000>Clear All Bots?", "do_ClearAllBots();");
}

function do_ClearAllBots()
{
    CommandToServer('ClearBots');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>All bots have been Cleared! <color:ff0000>(Only if you are an admin)");
}




function b_ReloadBricks()
{	
    messageBoxYesNo("reload Bricks?", "Are you sure you want to <color:880000>Reload Bricks?", "do_reloadbricks();");
}

function do_ReloadBricks()
{
    CommandToServer('ReloadBricks');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Bricks have been reloaded! <color:ff0000>(Only if you are an admin)");
}




function b_ResetBots()
{
    CommandToServer('ResetAllBots');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>All bots have been reset! <color:ff0000>(Only if you are an admin)");
}





function b_ResetAllVehicles()
{
    CommandToServer('ResetVehicles');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>All Vehicles have been reset! <color:ff0000>(Only if you are an admin)");
}




function b_Dwand()
{
    CommandToServer('MagicWand');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Destructo Wand Equipped <color:ff0000>(Only if you are an admin)");
}



function b_cancelload()
{
    CommandToServer('CancelSaveFileUpload');
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>Save File Up load cancelled<color:ff0000> (Only if you are an admin, and if a save was being uploaded)");
}




function B_RTBprefs()
{
    RTBSC_ToggleSC(1);
    newChatHud_addLine("<color:888888>Command Manager GUI: <color:ffffff>RTB Server Settings Toggled!<color:ff0000> (Only if you are Super Admin, and have RTB settings)");
}