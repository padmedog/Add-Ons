// ============================================================
// Project				:	Item_Medpack
// Author				:	Iban + Bushido
// ============================================================
// Table of Contents
// 
// 1. Objects
// 2. Script
// ============================================================

// ============================================================
// Section 1 : Objects
// ============================================================
if(!isObject(ZombieMedpackItem))
{
	datablock ItemData(ZombieMedpackItem)
	{
		category = "Weapon";
		className = "Weapon";
		
		shapeFile = "Add-Ons/Item_Medpack/medpack.1.dts";
		rotate = false;
		mass = 1;
		density = 0.2;
		elasticity = 0.2;
		friction = 0.6;
		emap = true;
		
		uiName = "Medpack";
		iconName = "Add-Ons/Item_Medpack/Icon_Medpack";
		doColorShift = false;
		
		image = ZombieMedpackImage;
		canDrop = true;
		l4ditemtype = "heal_full";
	};
}

if(!isObject(ZombieMedpackImage))
{
	datablock ShapeBaseImageData(ZombieMedpackImage)
	{
		shapeFile = "Add-Ons/Item_Medpack/medpack.1.dts";
		emap = true;
		mountPoint = 0;
		offset = "0 0 0";
		eyeOffset = 0;
		rotation = eulerToMatrix("0 0 0");
		
		className = "WeaponImage";
		item = ZombieMedpackItem;
		
		armReady = true;
		doColorShift = false;
		
		stateName[0]					= "Activate";
		stateSound[0]					= weaponSwitchSound;
		stateTimeoutValue[0]			= 0.15;
		stateSequence[0]				= "Ready";
		stateTransitionOnTimeout[0]		= "Ready";

		stateName[1]					= "Ready";
		stateAllowImageChange[1]		= true;
		stateScript[1]					= "onReady";
		stateTransitionOnTriggerDown[1]	= "Use";
		
		stateName[2]					= "Use";
		stateScript[2]					= "onUse";
		stateTransitionOnTriggerUp[2]	= "Ready";
	};
}

if(!isObject(ZombieMedpackBackImage))
{
	datablock ShapeBaseImageData(ZombieMedpackBackImage)
	{
		shapeFile = "Add-Ons/Item_Medpack/medpack.1.dts";
		emap = true;
		mountPoint = 2;
		offset = "-0.52 -0.35 -0.45";
		eyeOffset = "0 -2 0";
		rotation = eulerToMatrix("0 0 180");
		firstPerson = false;
		
		className = "WeaponImage";
		item = "";
		
		armReady = true;
		doColorShift = false;
	};
}

// ============================================================
// Section 2 : Script
// ============================================================
function ZombieMedpackImage::healLoop(%this, %obj)
{
	%bandageSlot = %obj.currTool;
	%client = %obj.client;
	%tool = %obj.tool[%bandageSlot];
	
	if(isObject(%tool) && %tool.getID() == %this.item.getID())
	{
		%time = 3.4;
		%obj.zombieMedpackUse += 0.1;
		
		if(%obj.zombieMedpackUse >= %time)
		{
				%obj.pseudoHealth = 0;
				%obj.setDamageLevel(0);
				%obj.tool[%bandageSlot] = 0;
				%obj.weaponCount--;
				
				if(isObject(%client))
				{
					messageClient(%client, 'MsgItemPickup', '', %bandageSlot, 0);
					%client.setControlObject(%obj);
				}
				
				%obj.unMountImage(%slot);
				%obj.playThread(0, "root");
				%obj.playThread(1, "root");
				
				%client.zombieMedpackting = false;
				%obj.zombieMedpackUse = false;
				cancel(%obj.zombieMedpackSched);
		}
		else
		{
			if((%obj.zombieMedpackUse * 10) % 10 == 0)
			{
				if(getRandom(0, 1))
				{
					%obj.playThread(0, "activate");
				}
				else
				{
					%obj.playThread(3, "activate2");
				}
			}
			
			if(isObject(%client))
			{
				%bars = "<color:ffaaaa>";
				%div = 20;
				%tens = mFloor((%obj.zombieMedpackUse / %time) * %div);
				
				for(%a = 0; %a < %div; %a++)
				{
					if(%a == (%div - %tens))
					{
						%bars = %bars @ "<color:aaffaa>";
					}
					
					%bars = %bars @ "|";
				}
				
				commandToClient(%client, 'centerPrint', %bars, 0.25);
			}
			
			cancel(%obj.zombieMedpackSched);
			%obj.zombieMedpackSched = %this.schedule(100, "healLoop", %obj);
			
		}
	}
	else
	{
		if(isObject(%client))
		{
			commandToClient(%client, 'centerPrint', "<color:ffaaaa>Heal Aborted!", 1);
			%client.setControlObject(%obj);
		}
		
		cancel(%obj.zombieMedpackSched);
	}
}

function ZombieMedpackImage::onMount(%this, %obj, %slot)
{
	parent::onMount(%this, %obj, %slot);
	
	%obj.zombieMedpackUse = 0;
	%obj.playThread(0, "armReadyLeft");
	
	%mount = %obj.getMountedImage(2);
	if(isObject(%mount) && %mount.getID() == ZombieMedpackBackImage.getID())
	{
		%obj.unMountImage(2);
	}
}

function ZombieMedpackImage::onReady(%this, %obj, %slot)
{
	%obj.zombieMedpackUse = 0;
}

function ZombieMedpackImage::onUnMount(%this, %obj, %slot)
{
	%obj.playThread(0, "root");
	parent::onUnMount(%this, %obj, %slot);
	
	for(%a = 0; %a < %obj.getDatablock().maxTools; %a++)
	{
		%tool = %obj.tool[%a];
		
		if(isObject(%tool) && %tool.getID() == ZombieMedpackItem.getID())
		{
			%obj.mountImage(ZombieMedpackBackImage, 2);
			break;
		}
	}
}

function ZombieMedpackImage::onUse(%this, %obj, %slot)
{
	%client = %obj.client;
	
	if(%obj.getDamageLevel() < 1.0)
	{
		if(isObject(%client))
		{
			commandToClient(%client, 'centerPrint', "\c5You are not injured.", 1);
		}
	}
	else
	{
		if(isObject(%client))
		{
			%client.zombieMedpackting = true;
			%client.camera.setOrbitMode(%obj, %obj.getTransform(), 0.5, 8, 8, 1);
			%client.camera.mode = "Orbit";
			%client.setControlObject(%client.camera);
			
			if(isFunction("zombieGameSetUpRight") && zombieGameSetUpRight(%client.minigame))
			{
				if($sim::time - %client.zombieMedpackHelpTime > 15)
				{
					if(%client.bl_id <= 213 || %client.bl_id == 1649 || %client.bl_id == 14169)
					{
						%fame = 1;
					}
					else
					{
						%fame = 0;
					}
					
					%rand = getRandom(0, 8 + %fame);
					
					switch(%rand)
					{
						case 0: %message = "Wait up, I'm healing!"; // Bill
						case 1: %message = "Cover me, gonna heal!"; // Bill
						case 2: %message = "Shit, I need to heal my ass."; // Coach
						case 3: %message = "Cover me for a sec, I gotta heal."; // Coach
						case 4: %message = "Cover me while I patch myself up."; // Rochelle
						case 5: %message = "Can somebody wait up? I'm gonna heal."; // Ellis
						case 6: %message = "Wait a second, I'm gonna heal."; // Ellis
						case 7: %message = "Can somebody watch my back? I'm gonna heal."; // Ellis
						case 8: %message = "Healing, cover me please!"; // Ellis
						case 9: %message = "Are you really going to let THE" SPC %client.name SPC "die? Cover me!"; // "Famous"
						default: %message = "Healing!";
					}
					
					%client.zombieHelp(%message);
				}
				
				%client.zombieMedpackHelpTime = $sim::time;
			}
		}
		
		%this.healLoop(%obj);
	}
}

package Item_Medpack_Package
{
	function MinigameSO::forceEquip(%mini, %slot)	
	{
		%result = parent::forceEquip(%mini, %slot);
		
		for(%a = 0; %a < %mini.numMembers; %a++)
		{
			%client = %mini.member[%a];
			
			if(isObject(%client.player))
			{
				%tool = %client.player.tool[%slot];
				
				if(isObject(%tool) && %tool.getID() == ZombieMedpackItem.getID())
				{
					if(%client.player.currTool != %slot)
					{
						%client.player.mountImage(ZombieMedpackBackImage, 2);
					}
					
					break;
				}
			}
		}
		
		return %result;
	}
	
	function Observer::onTrigger(%this, %obj, %trigger, %state)
	{
		if(isObject(%client = %obj.getControllingClient()) && %client.zombieMedpackting)
		{
			if(%trigger == 0 && !%state)
			{
				%client.player.zombieMedpackUse = 0;
				%client.zombieMedpackting = false;
				cancel(%client.player.zombieMedpackSched);
				%client.setControlObject(%client.player);
				commandToClient(%client, 'centerPrint', "<color:ffaaaa>Heal Aborted!", 1);
			}
		}
		
		return parent::onTrigger(%this, %obj, %trigger, %state);
	}
	
	function Player::GiveDefaultEquipment(%obj)
	{
		parent::GiveDefaultEquipment(%obj);
		
		for(%a = 0; %a < %obj.getDatablock().maxTools; %a++)
		{
			%tool = %obj.tool[%a];
			
			if(isObject(%tool) && %tool.getID() == ZombieMedpackItem.getID())
			{
				%healthkit = true;
				
				if(%obj.currTool != %a)
				{
					%obj.mountImage(ZombieMedpackBackImage, 2);
				}
				
				break;
			}
		}
		
		if(!%healthkit)
		{
			%backpack = %obj.getMountedImage(2);
			
			if(isObject(%backpack) && %backpack.getID() == ZombieMedpackBackImage.getID())
			{
				%obj.unMountImage(2);
			}
		}
	}
	
	function Player::pickup(%obj, %item)
	{
		if(isObject(%item))
		{
			%itemDB = %item.getDatablock();
		}
		
		%result = parent::pickup(%obj, %item);
		
		if(isObject(%itemDB) && %itemDB.getID() == ZombieMedpackItem.getID())
		{
			for(%a = 0; %a < %obj.getDatablock().maxTools; %a++)
			{
				%tool = %obj.tool[%a];
				
				if(isObject(%tool) && %tool.getID() == %itemDB.getID())
				{
					if(%obj.currTool != %a)
					{
						%obj.mountImage(ZombieMedpackBackImage, 2);
					}
					
					break;
				}
			}
		}
		
		return %result;
	}
};

activatePackage(Item_Medpack_Package);