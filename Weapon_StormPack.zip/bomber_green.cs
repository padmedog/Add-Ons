datablock StaticShapeData(StormBomberGreenShape)
{
	shapeFile = "./BomberGreenBullet.dts";
};

datablock fxLightData(StormBomberGreenLight : StormBomberBlueLight)
{
	color  = "0 1 0.129412 1";
	uiName = "Storm Light - Green";
};

datablock ParticleData(StormBomberGreenExplosionParticle : StormBomberBlueExplosionParticle)
{
	colors[0]	  = "0.25 1 0.129412 0.9";
	colors[1]	  = "0.1 1 0.129412 0.8";
	colors[2]	  = "0 1 0.129412 0.6";
	colors[3]	  = "0 1 0.129412 0.4";
};

datablock ParticleEmitterData(StormBomberGreenExplosionEmitter : StormBomberBlueExplosionEmitter)
{
	particles = "StormBomberGreenExplosionParticle";
};

datablock ParticleData(StormBomberGreenExplosionRingParticle : StormBomberBlueExplosionRingParticle)
{
	colors[0]	  = "0.25 1 0.129412 0.9";
	colors[1]	  = "0 0.11 0.129412 0.8";
	colors[2]	  = "0 1 0.129412 0.6";
	colors[3]	  = "0 1 0.129412 0.4";
};

datablock ParticleEmitterData(StormBomberGreenExplosionRingEmitter : StormBomberBlueExplosionRingEmitter)
{
	particles = "StormBomberGreenExplosionRingParticle";
};

datablock ParticleEmitterData(StormBomberGreenExplosionDotEmitter : StormBomberBlueExplosionDotEmitter)
{
		particles = "StormBomberGreenExplosionDotParticle";
};

datablock ParticleData(StormBomberGreenExplosionDotParticle : StormBomberBlueExplosionDotParticle)
{
	colors[0]	  = "0.25 1 0.129412 0.9";
	colors[1]	  = "0 0.11 0.129412 0.8";
	colors[2]	  = "0 1 0.129412 0.6";
	colors[3]	  = "0 1 0.129412 0.4";
};

datablock ParticleData(StormBomberGreenExplosionChunkParticle : StormBomberBlueExplosionChunkParticle)
{
	colors[0]	  = "0.25 1 0.129412 0.9";
	colors[1]	  = "0.1 1 0.129412 0.8";
	colors[2]	  = "0 1 0.129412 0.6";
	colors[3]	  = "0 1 0.129412 0.4";
};

datablock ParticleEmitterData(StormBomberGreenExplosionChunkEmitter : StormBomberBlueExplosionChunkEmitter)
{
	particles = "StormBomberGreenExplosionChunkParticle";
};

datablock ExplosionData(StormBomberGreenExplosion : StormBomberBlueExplosion)
{
	particleEmitter = StormBomberGreenExplosionEmitter;

	emitter[0] = StormBomberGreenExplosionChunkEmitter;
	emitter[1] = StormBomberGreenExplosionRingEmitter;
	emitter[2] = StormBomberGreenExplosionDotEmitter;

	lightStartColor = "0 1 0.129412 1";
	lightEndColor = "0 1 0.129412 0";
};

datablock ProjectileData(StormBomberGreenStuckProjectile : StormBomberBlueStuckProjectile)
{
	explosion = StormBomberGreenExplosion;
};

datablock ProjectileData(StormBomberGreenProjectile : StormBomberBlueProjectile)
{
	projectileShapeName = "./BomberGreenBullet.dts";
	hasLight	 = true;
	lightColor  = "0 1 0.129412 1";
};

//////////
// item //
//////////

datablock ItemData(StormBomberGreenItem : StormBomberBlueItem)
{
	uiName = "Storm Bomber - Green";

	doColorShift = true;
	colorShiftColor = "0 1 0.129412 1";

	image = StormBomberGreenImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBomberGreenImage : StormBomberBlueImage)
{
	shapeFile = "./StormBomber.dts";
	item = StormBomberGreenItem;
	projectile = StormBomberGreenProjectile;
	colorShiftColor = StormBomberGreenItem.colorShiftColor;
};

//----------------------------------------------------------------------------

function StormBomberGreenImage::onFire(%this, %obj, %slot)
{
	if (!isObject(%bomb = %obj.stormBomb))
	{
		if ($Sim::Time - %obj.lastBomberShotTime >= 2)
		{
			ServerPlay3d(StormBomberShotSound, %obj.getPosition());

			%p = new Projectile()
			{
				dataBlock       = StormBomberGreenProjectile;
				initialPosition = %obj.getMuzzlePoint(0);
				initialVelocity = vectorScale(%obj.getMuzzleVector(0), 30);
				sourceObject    = %obj;
				client          = %client;
				sourceSlot      = 0;
				originPoint     = %obj.getMuzzlePoint(0);
				type 			= "Green";
			};
			MissionCleanup.add(%p);
			%obj.stormBomb = %p;

			schedule(1900, 0, SpawnBomberExplosion, %p, "Green");
			%p.schedule(1900, delete);

			%obj.lastBomberShotTime = $Sim::Time;
		}
	}
	else
	{
		SpawnBomberExplosion(%bomb, "Green");
		%obj.stormBomb = "";
	}
}

function StormBomberGreenProjectile::onCollision(%this, %obj, %col, %fade, %pos, %normal)
{
	if (isObject(%source = %obj.sourceObject) && isObject(%source) && %source.getMountedImage(0) == StormBomberGreenImage.getId() &&
		%col.getClassName() !$= "Player" && %col.getClassName() !$= "AiPlayer" && 
		%col.getClassName() !$= "Vehicle" && %col.getClassName() !$= "WheeledVehicle")
	{
		%light = new fxLight()
		{
			dataBlock = StormBomberGreenLight;
			position = vectorAdd(%pos, "0 0 0.3");
		};
		MissionCleanup.add(%light);

		%p = new StaticShape()
		{
			dataBlock = StormBomberGreenShape;
			position = %pos;
			type = "Green";
			objectAttachedTo = %col;
			client = %source.client;
			light = %light;
		};
		MissionCleanup.add(%p);

		if (%col.stormBombCount $= "")
			%col.stormBombCount = 0;

		%col.attachedStormBomb[%col.stormBombCount] = %p;
		%col.stormBombCount++;

		if (isObject(%source))
			%source.stormBomb = %p;

		%obj.delete();
	}
	else
	{
		%p = new Projectile()
		{
			dataBlock = StormBomberGreenStuckProjectile;
			initialPosition = %pos;
			client = %source.client;
			sourceObject = %source.client;
		};
		MissionCleanup.add(%p);
		%p.explode();
	}
}

function StormBomberGreenImage::onUnmount(%this, %obj, %slot)
{
	if (isObject(%bomb = %obj.stormBomb))
	{
		SpawnBomberExplosion(%bomb, "Green");
		%obj.stormBomb = "";
	}
}