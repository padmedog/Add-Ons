// ArmoredVan_spring.cs

datablock WheeledVehicleSpring(ArmoredVanSpring)
{
   // Wheel suspension properties
   length = 0.4;			 // Suspension travel
   force = 6000; //3000;		 // Spring force
   damping = 600; //600;		 // Spring damping
   antiSwayForce = 6; //6;		 // Lateral anti-sway force
};


