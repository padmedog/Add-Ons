package TimeMes
{
	function clientcmdChatMessage(%client,%b,%c,%taggedString,%PreTag,%name,%postTag,%msg)
	{
		%time = strReplace(getword(getDateTime(),1),":"," ");
		%time = getword(%time,0) SPC getword(%time,1);
		if(%time > 12)
		{
			%Hour = getword(%time,0) - 12;
			%minute = getword(%time,1);
			%time = %hour SPC %minute @ "pm";
		}
		else
		{
			%time = %time @ "am";
		}
		%time = strReplace(%time," ",":");
		%taggedString = getword(%taggedString,0) SPC "\c6[" @ %time @ "\c6]\c7" @ %preTag @ "\c3" @ %name @ "\c7" @ %postTag @ "\c6: " @ %msg;
		parent::clientcmdChatMessage(%client,%b,%c,%taggedString,%PreTag,%name,%postTag,%msg);
	}
};
ActivatePackage(TimeMes);