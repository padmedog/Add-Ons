datablock fxDTSBrickData(brick1x1WedgeRampCornerData)
{
	brickFile = "./1x1WedgeRampCorner.blb";
	category = "Wedges";
	subCategory = "Ramps";
	uiName = "45� Wedge Ramp Corner x1";
	iconName = "Add-Ons/Brick_WedgeRamps/1x1WedgeRampCorner";
	collisionShapeName = "./1x1WedgeRampCorner.dts";
};

datablock fxDTSBrickData(brick2x2WedgeRampData)
{
	brickFile = "./2x2WedgeRamp.blb";
	category = "Wedges";
	subCategory = "Ramps";
	uiName = "45� Wedge Ramp x2";
	iconName = "Add-Ons/Brick_WedgeRamps/2x2WedgeRamp";
	collisionShapeName = "./2x2WedgeRamp.dts";
};

datablock fxDTSBrickData(brick1x1WedgeRampData)
{
	brickFile = "./1x1WedgeRamp.blb";
	category = "Wedges";
	subCategory = "Ramps";
	uiName = "45� Wedge Ramp x1";
	iconName = "";
	collisionShapeName = "./1x1WedgeRampCorner.dts";
};

datablock fxDTSBrickData(brick3x3WedgeRampData)
{
	brickFile = "./3x3WedgeRamp.blb";
	category = "Wedges";
	subCategory = "Ramps";
	uiName = "25� Wedge Ramp x3";
	iconName = "";
	collisionShapeName = "./3x3WedgeRamp.dts";
};

datablock fxDTSBrickData(brick2x2WedgeRampUpData)
{
	brickFile = "./2x2WedgeRampUp.blb";
	category = "Wedges";
	subCategory = "Ramps";
	uiName = "45� Wedge Ramp Up x2";
	iconName = "";
	collisionShapeName = "./2x2WedgeRampUp.dts";
};

datablock fxDTSBrickData(brick1x1WedgeRampUpData)
{
	brickFile = "./1x1WedgeRampUp.blb";
	category = "Wedges";
	subCategory = "Ramps";
	uiName = "45� Wedge Ramp Up x1";
	iconName = "";
	collisionShapeName = "./1x1WedgeRampCornerUp.dts";
};