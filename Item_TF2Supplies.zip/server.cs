if (isFile("Add-Ons/System_ReturnToBlockland/server.cs")) //Checking for RTB.
{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	//Defining RTB prefs.
	RTB_registerPref("Small Respawn Time (ms)", "TF2 Supplies",  "$Pref::TF2S::RespawnSmall", "int 0 600000", "Item_TF2Supplies",  10000, true, false, "");
	RTB_registerPref("Medium Respawn Time (ms)", "TF2 Supplies",  "$Pref::TF2S::RespawnMedium", "int 0 600000", "Item_TF2Supplies",  10000, true, false, "");
	RTB_registerPref("Large Respawn Time (ms)", "TF2 Supplies",  "$Pref::TF2S::RespawnLarge", "int 0 600000", "Item_TF2Supplies",  10000, true, false, "");
	RTB_registerPref("Enable Spin", "TF2 Supplies", "$Pref::TF2S::Spin", "bool", "Item_TF2Supplies", false, true, false, "");
	RTB_registerPref("Heal Percentage", "TF2 Supplies", "$Pref::TF2S::Percentage", "bool", "Item_TF2Supplies", true, false, false, "");
	RTB_registerPref("Small Heal Amount", "TF2 Supplies", "$Pref::TF2S::HealSmall", "int 0 100000", "Item_TF2Supplies", "20", false, false, "callbackHealSmall");
	RTB_registerPref("Medium Heal Amount", "TF2 Supplies", "$Pref::TF2S::HealMedium", "int 0 100000", "Item_TF2Supplies", "50", false, false, "callbackHealMedium");
	RTB_registerPref("Large Heal Amount", "TF2 Supplies", "$Pref::TF2S::HealLarge", "int 0 100000", "Item_TF2Supplies", "100", false, false, "callbackHealLarge");
}
else //RTB not found.
{
	//Defining prefs for non-RTB users.
	$Pref::TF2S::RespawnSmall = 10000;
	$Pref::TF2S::RespawnMedium = 10000;
	$Pref::TF2S::RespawnLarge = 10000;
	$Pref::TF2S::Spin = 1;
	$Pref::TF2S::Percentage = 1;
	$Pref::TF2S::HealSmall = 20;
	$Pref::TF2S::HealMedium = 50;
	$Pref::TF2S::HealLarge = 100;
}

function callbackHealSmall(%oldValue, %newValue)
{
	healthKitSmallItem.healScale = ($Pref::TF2S::Percentage) ? %newValue / 100 : %newValue;
}
function callbackHealMedium(%oldValue, %newValue)
{
	healthKitMediumItem.healScale = ($Pref::TF2S::Percentage) ? %newValue / 100 : %newValue;
}
function callbackHealLarge(%oldValue, %newValue)
{
	healthKitLargeItem.healScale = ($Pref::TF2S::Percentage) ? %newValue / 100 : %newValue;
}

exec("./Item_TF2Supplies.cs");