

if(ForceRequiredAddOn("Vehicle_Jeep")== $Error::AddOn_NotFound)
{
   error("ERROR: Vehicle_Mustang- required add-on Vehicle_Jeep not found");
}
else
{ 
	exec("./vehicle.cs"); 
	
	exec("./Support_HandsOnVehicle.cs");  
}