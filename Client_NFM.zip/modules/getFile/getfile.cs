//NARG File Manager
//getFile Module
//Version 1.2 Full
//  By Nexus 4833
//=================

//dependencies
if($getname_version < 1.0)
{
	echo("Warning! Missing dependency: getFile Module is dependent on getName version 1.0 or newer.");
}

if($zoomimage_version < 1.0)
{
	echo("Warning! Missing dependency: getFile Module is dependent on zoomImage version 1.0 or newer.");
}

%nfm_version_major = "1.2"; //must be a value
%nfm_version_minor = "Full"; //allowed values are "Alpha", "Beta", "Full", "Modified" (in that order of precedence)

//initialize some stuff
if($nfm_version !$= "")
{
	if(getword($nfm_version, 0) > %nfm_version_major || (getword($nfm_version, 0) $= %nfm_version_major && stricmp(getword($nfm_version, 1), %nfm_version_minor) == 1))
	{
		echo("File Manager [" @ %nfm_version_major SPC %nfm_version_minor @ "] not needed, better version in place [" @ $nfm_version @ "]");
		return;
	}
	echo("Updating to File Manager [" @ %nfm_version_major SPC %nfm_version_minor @ "] from version [" @ $nfm_version @ "]");
}
$nfm_version = %nfm_version_major SPC %nfm_version_minor;
$nfm_debug = false;
$nfm_uipath = "";

//in case of re-execution
$nfm_initialized = false;

//promptUserFile is the only function your program should need to call
//%default - default directory, including a default file if you wish
//%callback - your function that takes arguments %path and %description
//%mode - modes accepted are "save", "load", "savebls", "loadbls", and ""
//%ext - file extension to use as a filter, including the period, wildcards accepted.
//	Default value is "" and input is ignored if %mode is "savebls" or "loadbls".

function promptUserFile(%default, %callback, %mode, %ext)
{
	if(!$nfm_initialized)
	{
		$nfm_initialized = true;
		nfm_initgui();
	}
	NFMGUI.callback = %callback;

	if(%default $= "")
	{
		if(%mode $= "savebls")
			%default = NFMGUI.savedirectory;
		else if(%mode $= "loadbls")
			%default = NFMGUI.loaddirectory;
		else
			%default = $NFM::Home;
	}
	nfmgui_filename.settext("");

	if(isfile(%default))
		NFMGUI.setcurrentfile(%default);
	else
		NFMGUI.setcurrentfile("");
	NFMGUI.copyfilepath = "";
	NFMGUI.selectedfilebg = "";
	NFMGUI.cutting = false;
	NFMGUI.setmode(%mode, %ext);
	NFMGUI.loadpath(%default);
	canvas.pushdialog(NFMGUI);

	if($nfm_firsttime)
	{
		$nfm_firsttime = false;
		export("$NFM::*", $NFM::PrefsPath);
		canvas.pushdialog(nfm_tutorial);
	}
}

//find out what folder this file is in
//maybe sort of hacky but if people want to use this module in arbitrary locations then it has to be done

function nfm_getUIPath()
{
	if($nfm_uipath $= "")
	{
		%fullpath = findfirstfile("./getfile.cs");
		$nfm_uipath = getsubstr(%fullpath, 0, strlen(%fullpath) - strlen(filename(%fullpath))) @ "ui/";
	}
	return $nfm_uipath;
}

//preferences
//----------
function nfm_defaults()
{
	$NFM::BrickCount = false;
	$NFM::Buffer = true;
	$NFM::Cache = true;
	$NFM::BufferCount = 50;
	$NFM::BufferTime = 1;
	$NFM::VersionCheck = true;

	$NFM::Home = "saves/";
	$NFM::ListSize = 1; //1 2 or 3
	$NFM::Font = "arial bold";

	$NFM::PrefsPath = "config/client/NARG File Manager/preferences.cs";

	$NFM::ItemColorIdle = "230 230 230 255";
	$NFM::ItemColorHighlight = "255 255 255 255";
	$NFM::ItemColorPress = "170 170 170 255";
	$NFM::ItemColorContext = "170 170 230 255";
	$NFM::ItemColorSelect = "170 230 170 255";

	//default defaults
	$pref::SaveExtendedBrickInfo = 1;
	$pref::SaveOwnership = 1;
	$LoadingBricks_Ownership = 1;
	$LoadingBricks_ColorMethod = 3;
	$LoadingBricks_PositionOffset = "0 0 0";

	//0 - name
	//1 - date
	$NFM::DefaultSort = 0; //0 or 1
}
nfm_defaults();

function nfm_restartfilemanager()
{
	$nfm_initialized = false;
	exec("./interface/interface.cs");
}

if(isfile($NFM::PrefsPath))
{
	exec($NFM::PrefsPath);
}
else
{
	$nfm_firsttime = true;
}

exec("./support/support.cs");
exec("./support/versioncheck.cs");
exec("./support/loader.cs");

exec("./interface/interface.cs");

nfm_initmanager();

