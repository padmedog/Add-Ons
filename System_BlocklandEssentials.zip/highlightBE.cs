package highlightBE
{
	function joinServerGui::queryWebMaster(%this)
	{
		parent::querywebmaster(%this);
		getBEIPs();
		echo("getting be ips");
	}
	function ServerSO::serialize(%this)
   	{
     		%serialized = Parent::serialize(%this);
		if(!isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
			return %serialized;			//sorry, i hope to fix this soon
		%ip = getField(%serialized,9);
		if(%ip $= "")
			return %serialized;
		else
		{
			%ip = getSubStr(%ip,0,strpos(%ip,":"));
			%isBE = 0;
			for(%a=0;%a<$beIPs;%a++)
				if($beIP[%a] $= %ip)
					%isBE = 1;

			if(%isBE)
			{
				%str = getField(%serialized,0) TAB "\c5" @ getField(%serialized,1) TAB getField(%serialized,2) TAB getField(%serialized,3) TAB getField(%serialized,4) TAB getField(%serialized,5) TAB getField(%serialized,6) TAB getField(%serialized,7) TAB getField(%serialized,8) TAB getField(%serialized,9) TAB getField(%serialized,10) TAB getField(%serialized,11) TAB getField(%serialized,12);
				return %str;
			}
			else
				return %serialized;
		}
	}
};

function getBEIPs()
{
	$beIPs = 0;
	new HTTPObject(beServerGetter);
	beServerGetter.get("syerjchep.org:80","/blrs/index.html");
}

function beServerGetter::onLine(%this,%line)
{
	if(%line $= "" || %line $= " " || %line $= "END")
	{
		if(isObject(beServerGetter))
			beServerGetter.delete();
		return;
	}
	else
	{
		%add = getField(%line,1);
		%ip = getSubStr(%add,0,strpos(%add,":"));
		$beIP[$beIPs] = %ip;
		$beIPs++;
	}
}
