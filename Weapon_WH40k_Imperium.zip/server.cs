//
//8==================================D
//warhamer wepons made by tigals
//specel thancs to busido
//8========================D
//


//we need the gun, rocketlauncher, and Tier+Tactical for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");
%error = ForceRequiredAddOn("Weapon_Rocket_Launcher");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have all this shit, so we're screwed
   error("ERROR: Weapon_wp_WH - required add-on Weapon_Gun, Weapon_Rocket_Launcher not found");
}
else
{
   
   exec("./Weapon_Lasrifle.cs"); 
   exec("./Weapon_Laspistol.cs"); 
   exec("./Weapon_Longlas.cs"); 
   exec("./Weapon_Boltpistol.cs");  
   exec("./Weapon_Boltgun.cs");     
   exec("./Weapon_Stormbolter.cs");     
   exec("./Weapon_Grenadelauncher.cs");     
   exec("./Weapon_Meltagun.cs");
   exec("./Weapon_Plasmagun.cs");
   exec("./Weapon_Plasmapistol.cs");
   exec("./Weapon_Flamer.cs");
   exec("./Weapon_Powersword.cs"); 
   exec("./Weapon_Powerfist.cs"); 
   exec("./Weapon_Chainsword.cs"); 
   exec("./Weapon_Hotshotlasgun.cs"); 
   exec("./Weapon_Hotshotlaspistol.cs"); 
   exec("./Weapon_Autogun.cs"); 
   exec("./Weapon_Autopistol.cs"); 
   exec("./Weapon_Stubgun.cs"); 
   exec("./Support_Heavyweapons.cs"); 
   exec("./Weapon_Heavybolter.cs"); 
   exec("./Weapon_Autocannon.cs"); 
   exec("./Weapon_Lascannon.cs"); 
   exec("./Weapon_Missilelauncher.cs"); 
   exec("./Weapon_Mortar.cs"); 
   exec("./Weapon_HeavyFlamer.cs"); 

}

//just incase T+T isnt enabled
 datablock ExplosionData(TTLittleRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "1 1 1";
  camShakeAmp = "0.1 0.3 0.2";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTLittleRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTLittleRecoilExplosion;

};

datablock ExplosionData(TTRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "2 2 2";
  camShakeAmp = "0.3 0.5 0.4";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTRecoilExplosion;

};

datablock ExplosionData(TTBigRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "3 3 3";
  camShakeAmp = "0.6 0.8 0.7";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTBigRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTBigRecoilExplosion;

};

datablock ExplosionData(TTHugeRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "1.1 1.3 1.2";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTHugeRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTHugeRecoilExplosion;

};
