This is a work around for a bug in TGE. If you wanna read a bit about it, go into playerShapes.cs.

Dont mess with it, or it could break.