exec("./NewZMG.gui");
exec("./Zombieclient.cs");

function RaddToMinigameGui(%target)
{
	//CMG_ScrollBox
	%ext = CMG_ScrollBox.extent;
	%extx = getword(CMG_ScrollBox.extent,0);
	%exty = getword(CMG_ScrollBox.extent,1);

	%tExt = %target.extent;
	%tExtx = getword(%target.extent,0);
	%tExty = getword(%target.extent,1);
	
	%FinExty = %exty+%tExty+3;

	CMG_ScrollBox.extent = %extx SPC %FinExty;
	
	//Group
	%count = CMG_ScrollBox.getcount();
	%last = CMG_ScrollBox.getobject(%count-1);

	%lPosX = getword(%last.position,0);
	%lPosY = getword(%last.position,1);

	%lExtX = getword(%last.extent,0);
	%lExtY = getword(%last.extent,1);
	
	%del = %target.getgroup();

	CMG_ScrollBox.add(%target);

	%target.position = %lPosX SPC %lPosY+%lExtY+3;
	%target.extent = %lExtX SPC %tExtY;

	//%del.schedule(500,delete);
}
function SetZombieDifficulty(%diff)
{
	$Minigame::Zombies::Difficulty = %diff;
	if(%diff $= "Easy")
	{
		$Minigame::Zombies::EasyDifficulty = 1;
		$Minigame::Zombies::NormalDifficulty = 0;
		$Minigame::Zombies::HardDifficulty = 0;
	}
	if(%diff $= "Normal")
	{
		$Minigame::Zombies::EasyDifficulty = 0;
		$Minigame::Zombies::NormalDifficulty = 1;
		$Minigame::Zombies::HardDifficulty = 0;
	}
	if(%diff $= "Hard")
	{
		$Minigame::Zombies::EasyDifficulty = 0;
		$Minigame::Zombies::NormalDifficulty = 0;
		$Minigame::Zombies::HardDifficulty = 1;
	}
}
RaddToMinigameGui(ZombieMinigameGui);
package MinigameZombieGuiAddPackage
{
	function CreateMinigameGUI::onWake(%this,%a,%b,%c)
	{
		Parent::onWake(%this,%a,%b,%c);
		if($SpaceMods::Client::TeamDM::serverHasMod && $zombies::adjustedTDM != 1)
		{
			$zombies::adjustedTDM = 1;
			ZombieMinigameGui.position = vectoradd(ZombieMinigameGui.position,"0 65");
		}
		//if(ZombieMinigameGui.getgroup().getname() $= "ZMGShell")
		//{
			
		//}
	}
};
activatePackage(MinigameZombieGuiAddPackage);