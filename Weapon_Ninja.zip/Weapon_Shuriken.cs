//Script by Aloshi, CI and ItemIcon and Model by Kaje.

//sound
datablock AudioProfile(ShurikenThrowSound)
{
   filename    = "./woosh_5.wav";
   description = AudioClosest3d;
   preload = true;
};

//Shuriken trail effects
datablock ParticleData(ShurikenTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 10;
	lifetimeVarianceMS   = 5;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.1 0.1 0.1 0.4";
	colors[1]     = "0.1 0.1 0.1 0.0";
	sizes[0]      = 0.5;
	sizes[1]      = 0.3;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ShurikenTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance  = false;
   particles = "ShurikenTrailParticle";
};

datablock ParticleData(ShurikenExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 200;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.6 0.9";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(ShurikenExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ShurikenExplosionParticle";
};

datablock ExplosionData(ShurikenExplosion)
{
   //explosionShape = "";

   lifeTimeMS = 150;

   particleEmitter = ShurikenExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};

AddDamageType("Shuriken",   '<bitmap:add-ons/Weapon_Ninja/Ci_Shuriken> %1',    '%2 <bitmap:add-ons/Weapon_Ninja/Ci_Shuriken> %1',0.5,1);
datablock ProjectileData(ShurikenProjectile)
{
   projectileShapeName = "./shuriken.dts";
   directDamage        = 5;
   directDamageType    = $DamageType::Shuriken;
   radiusDamageType    = $DamageType::Shuriken;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse       = 0;
   verticalImpulse     = 200;
   explosion           = ShurikenExplosion;
   particleEmitter     = ShurikenTrailEmitter;

   muzzleVelocity      = 70;
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   isBallistic         = true;
   gravityMod = 0.50;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Shuriken";
};

//////////
// item //
//////////
datablock ItemData(ShurikenItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Shuriken.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Basic Shuriken";
	iconName = "./Icon_Shuriken";
	doColorShift = true;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = ShurikenImage;
	canDrop = true;
	cost = 150;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ShurikenImage)
{
   // Basic Item properties
   shapeFile = "./Shuriken.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ShurikenItem;
   ammo = " ";
   projectile = ShurikenProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ShurikenItem.colorShiftColor;//"0.400 0.196 0 1.000";

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;

//______________________Fire_____________________
	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]	= "FireAkimbo";
	stateTransitionOnTriggerUp[2]   = "Ready";
	stateTimeoutValue[2]            = 0.09;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = true;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateSound[2]			= ShurikenThrowSound;

//______________________Fire2_____________________
	stateName[3] 			= "FireAkimbo";
	stateTimeoutValue[3] 		= 0.09;
	stateScript[3] 			= "onFireAkimbo";
	stateTransitionOnTimeout[3] 	= "Fire3";
	stateTransitionOnTriggerUp[3]   = "Reload";

//______________________Fire3_____________________
	stateName[4]                    = "Fire3";
	stateTransitionOnTriggerUp[4]   = "Reload2";
	stateTransitionOnTimeout[4]     = "FireAkimbo2";
	stateTimeoutValue[4]            = 0.12;
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = true;
	stateSequence[4]                = "Fire3";
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		= true;
	stateSound[4]			= ShurikenThrowSound;

//______________________Fire4______________________
	stateName[5]			= "FireAkimbo2";
	stateTimeoutValue[5]		= 0.09;
	stateScript[5]			= "onFireAkimbo";
	stateTransitionOnTimeOut[5]	= "Fire5";
	stateTransitionOnTriggerUp[5]   = "Reload3";

//______________________Fire5______________________
	stateName[6]                    = "Fire5";
	stateTransitionOnTimeout[6]     = "Reload4";
	stateTimeoutValue[6]            = 0.12;
	stateFire[6]                    = true;
	stateAllowImageChange[6]        = true;
	stateSequence[6]                = "Fire5";
	stateScript[6]                  = "onFire";
	stateWaitForTimeout[6]		= true;
	stateSound[6]			= ShurikenThrowSound;

//_____________________Reload_____________________
	stateName[7]			= "Reload";
	stateTimeoutValue[7]		= 0.2;
	stateSequence[7]		= "reload";
	stateTransitionOnTimeout[7]	= "Ready";
	stateWaitForTimeout[7]		= true;

//_____________________Reload2_____________________
	stateName[8]			= "Reload2";
	stateTimeoutValue[8]		= 0.4;
	stateSequence[8]		= "reload";
	stateTransitionOnTimeout[8]	= "Ready";
	stateWaitForTimeout[8]		= true;

//_____________________Reload3_____________________
	stateName[9]			= "Reload3";
	stateTimeoutValue[9]		= 0.6;
	stateSequence[9]		= "reload";
	stateTransitionOnTimeout[9]	= "Ready";
	stateWaitForTimeout[9]		= true;

//_____________________Reload4_____________________
	stateName[10]			= "Reload4";
	stateTimeoutValue[10]		= 0.8;
	stateSequence[10]		= "reload";
	stateTransitionOnTimeout[10]	= "Ready";
	stateWaitForTimeout[10]		= true;

};
function ShurikenImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.addVelocity("0 0 1");
		%obj.playThread(2, spearthrow);
	Parent::onFire(%this,%obj,%slot);	
}

function ShurikenImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}

function ShurikenImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftShurikenImage, 1);
   //%obj.playThread(0, armreadyboth);
}
function ShurikenImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount lefthanded gun
   %obj.unMountImage(1);
   //%obj.playThread(0, root);
}

datablock ShapeBaseImageData(LeftShurikenImage)
{
   // Basic Item properties
   shapeFile = "./shuriken.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = ShurikenProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = ShurikenItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			  = weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;

	stateName[2]                    = "Fire";
	stateSound[2]			  = ShurikenThrowSound;
	stateTransitionOnTimeout[2]	  = "Ready";
	stateTimeoutValue[2]            = 0.2;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = true;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
};

function LeftShurikenImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.addVelocity("0 0 1");
		%obj.playThread(2, leftrecoil);
	Parent::onFire(%this,%obj,%slot);	
}
function LeftShurikenImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function LeftShurikenImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
}