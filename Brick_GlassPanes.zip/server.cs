datablock fxDTSBrickData(brick1x1_GlassPaneData)
{
	brickFile = "./1x1_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "1x1 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/1x1_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x2_GlassPaneData)
{
	brickFile = "./1x2_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "1x2 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/1x2_GlassPane";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x3_GlassPaneData)
{
	brickFile = "./1x3_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "1x3 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/1x3_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x4_GlassPaneData)
{
	brickFile = "./1x4_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "1x4 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/1x4_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick3x4_GlassPaneData)
{
	brickFile = "./3x4_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "3x4 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/3x4_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick5x1_GlassPaneData)
{
	brickFile = "./5x1_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "5x1 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/5x1_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick5x2_GlassPaneData)
{
	brickFile = "./5x2_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "5x2 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/5x2_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick5x3_GlassPaneData)
{
	brickFile = "./5x3_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "5x3 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/5x3_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick5x4_GlassPaneData)
{
	brickFile = "./5x4_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "5x4 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/5x4_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick5x6_GlassPaneData)
{
	brickFile = "./5x6_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "5x6 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/5x6_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick5x12_GlassPaneData)
{
	brickFile = "./5x12_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "5x12 Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/5x12_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick2x2F_GlassPaneData)
{
	brickFile = "./2x2F_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "2x2F Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/2x2F_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick3x3F_GlassPaneData)
{
	brickFile = "./3x3F_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "3x3F Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/3x3F_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick4x4F_GlassPaneData)
{
	brickFile = "./4x4F_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "4x4F Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/4x4F_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick6x6F_GlassPaneData)
{
	brickFile = "./6x6F_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "6x6F Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/6x6F_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick8x8F_GlassPaneData)
{
	brickFile = "./8x8F_GlassPane.blb";
	category = "Special";
	subCategory = "Panes";
	uiName = "8x8F Glass Pane";
	iconName = "Add-Ons/Brick_GlassPanes/8x8F_GlassPane";
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};