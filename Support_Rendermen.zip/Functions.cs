// FUNCTIONS //
// cansee function courtesy of Jimmg - thanks
function Player::canSeeObject(%player,%object)
{
	if(!isObject(%object))
	{
		//announce("Object doesn't exist!");
		return 0;
	}
    
    if(%player == %object)
	{
		//announce("That's you!");
		return 0;
	}


	//The eye point is the position of the players camera
	%eye = %player.getEyePoint();
	//The position of the object
	//%to = posFromTransform(%object.getTransform());
	%to = %object.getEyePoint();
	// if(vectorDist(%eye,%to) < %range)
	// 	return 0;

	//Cast a raycast to try and collide with the object
	%ray = containerRaycast(%eye,%to,$TypeMasks::StaticShapeObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType,%player);
	%col = getWord(%ray,0);
	//announce(%col);
	if(isObject(%col) && %col == %object)
	{
		//The position of the collision
		%pos = posFromRaycast(%ray);

		//Super Maths C skills go B)
		%resultant = vectorSub(%pos,%eye);
		%normal = vectorNormalize(%resultant);

		//Find the yaw from the resultant
		%resultRadians = mAtan(getWord(%normal,1),getWord(%normal,0));
		
		//Find the yaw from the eye vector
		%eyeVec = %player.getEyeVector();
		%eyeRadians = mAtan(getWord(%eyeVec,1),getWord(%eyeVec,0));

		//Convert both of them to degrees for easier understanding
		%resultDegrees = mRadToDeg(%resultRadians);
		%eyeDegrees = mRadToDeg(%eyeRadians);

		//Now the tricky part. In order for the object to be in sight, lets say that the object needs to be within 90 degrees of the players view
		//Change 90 to something smaller if you don't like how wide the view is
		if(%resultDegrees >= %eyeDegrees - 50 && %resultDegrees <= %eyeDegrees + 50)
			//announce("Should be returning 1 right here!");
			return 1;
	}
	//No object hit, or not the target object, return 0/false
	//announce("No object hit, or not the target object, return 0/false");
	return 0;
}

// Create some basic "Check" functions to save space later
function Player::RenderCheck(%this)
{
	InitContainerRadiusSearch(%this.getPosition(),9999,$TypeMasks::PlayerObjectType);
    %seen1 = 0;
    %seen2 = 0;
    %seen3 = 0;
    %seen4 = 0;
    %seen5 = 0; // only 5 rendermen can spawn at once - seeing all of them at once is hardly likley but we'll use 5 slots anyway
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.isRenderman == 1) {
            if(%this.canSeeObject(%targetObject)) {
                if(%seen1 == 0) {
                    %seen1 = %targetObject;
                } else if(%seen2 == 0) {
                    %seen2 = %targetObject;
                } else if(%seen3 == 0) {
                    %seen3 = %targetObject;
                } else if(%seen4 == 0) {
                    %seen4 = %targetObject;
                } else if(%seen5 == 0) {
                    %seen5 = %targetObject;
                }
            }
        }
    }
    return %seen1 SPC %seen2 SPC %seen3 SPC %seen4 SPC %seen5;
}

function Player::ShrineCheck(%this)
{
	InitContainerRadiusSearch(%this.getPosition(),20,$TypeMasks::FxBrickObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.getDatablock().getName() $= "brickRenderSafe" && %targetObject.isRayCasting() == 1) {
            return 1;
        }
    }
    return 0;
}

function addRenderman(%pos) { // usage: "addRenderman(pos);"
    if($rendermeninmap >= $Pref::Rendermen::Limit) {
        echo("ERROR: Too many rendermen exist in the map to add another!");
        return 0;
    }
    %this = new aiplayer(Renderman) {
		datablock = PlayerStandardArmor;
		position = %pos;
	};
	missionCleanup.add(%this);
	hideAllNodes(%this);
    $rendermeninmap = $rendermeninmap + 1;
    %type = getRandom(0,10);
    if(%type <= 6) { // Type A
        %this.unhidenode(chest);
        %this.unhidenode(pants);
        %this.unhidenode(LShoe);
        %this.unhidenode(RShoe);
        %this.unhidenode(LArm);
        %this.unhidenode(LHand);
        %this.unhidenode(RArm);
        %this.unhidenode(RHand);
        %this.setnodecolor(chest, "0 0 0 1");
        %this.setnodecolor(headskin, "0 0 0 1");
        %this.setnodecolor(pants, "0 0 0 1");
        %this.setnodecolor(LShoe, "0 0 0 1");
        %this.setnodecolor(RShoe, "0 0 0 1");
        %this.setnodecolor(LArm, "0 0 0 1");
        %this.setnodecolor(LHand, "0 0 0 1");
        %this.setnodecolor(RArm, "0 0 0 1");
        %this.setnodecolor(RHand, "0 0 0 1");
        %this.setdecalname("AAA-None");
        %this.setScale("1 1 1.4");
        %this.type = "A";
    } else if(%type <= 8) { // Type B
        %this.unhidenode(chest);
        %this.unhidenode(pants);
        %this.unhidenode(LPeg);
        %this.unhidenode(RPeg);
        %this.unhidenode(LArm);
        %this.unhidenode(LHook);
        %this.unhidenode(RArm);
        %this.unhidenode(RHook);
        %this.setnodecolor(chest, "0 0 0 1");
        %this.setnodecolor(headskin, "0 0 0 1");
        %this.setnodecolor(pants, "0 0 0 1");
        %this.setnodecolor(LPeg, "0 0 0 1");
        %this.setnodecolor(RPeg, "0 0 0 1");
        %this.setnodecolor(LArm, "0 0 0 1");
        %this.setnodecolor(LHook, "0 0 0 1");
        %this.setnodecolor(RArm, "0 0 0 1");
        %this.setnodecolor(RHook, "0 0 0 1");
        %this.setdecalname("AAA-None");
        %this.setScale("1 1 1.4");
        %this.type = "B";
    } else if(%type >= 9) { // Type T
        %this.unhidenode(chest);
        %this.unhidenode(pants);
        %this.unhidenode(LShoe);
        %this.unhidenode(LPeg);
        %this.unhidenode(RShoe);
        %this.unhidenode(RPeg);
        %this.unhidenode(LArm);
        %this.unhidenode(LHand);
        %this.unhidenode(RArm);
        %this.unhidenode(RHand);
        %this.setnodecolor(chest, "0 0 0 1");
        %this.setnodecolor(headskin, "0 0 0 1");
        %this.setnodecolor(pants, "0 0 0 1");
        %this.setnodecolor(LShoe, "0 0 0 1");
        %this.setnodecolor(RShoe, "0 0 0 1");
        %this.setnodecolor(LPeg, "0 0 0 1");
        %this.setnodecolor(RPeg, "0 0 0 1");
        %this.setnodecolor(LArm, "0 0 0 1");
        %this.setnodecolor(LHand, "0 0 0 1");
        %this.setnodecolor(RArm, "0 0 0 1");
        %this.setnodecolor(RHand, "0 0 0 1");
        %this.setdecalname("AAA-None");
        %this.setScale("0.5 0.5 1.4");
        %this.type = "T";
    }
    
    if($Pref::Rendermen::OwnLights == 1) {
        %this.light = new fxlight()
		{
			dataBlock = playerLight;
			enable = true;
			iconsize = 1;
			player = %this;
		};
		%this.light.attachToObject(%this);
    }
    
    // set face
    if($Pref::Rendermen::Faces == 1) {
        %this.setfacename("rendermanStaring");
    } else {
        %this.setfacename("memeGrinMan");
    }
    
    // Define vars
    %this.isRenderman = 1;
    %this.RendermanTarget = 0;
    %this.canbreaklights = 1;
    %this.RendermanType = "A";
    %this.RendermanLifetime = getRandom(900, 10000); // lifetime (in renderticks or 100 ms)
    %this.growled = 0;
    
    // Finally, start the new AI
    %this.RendermanLoop();
    
    // also return the renderman we just created
    return %this;
}

function removeRenderman(%this) { // DO NOT remove rendermen ingame with %this.delete(); - use this command instead
    if(isObject(%this)) {
        $rendermeninmap = $rendermeninmap - 1;
        %this.delete();
    }
}

// Player loop
function Player::CanSeeLoop(%this)
{
    // reset playervars
    %this.canSeeRender = 0;
    %this.safe = 0;
    
    if(%this.getMountedImage(0) $= nameToID("RenderDetectorImage")) { // trying to detect rendermen are we
        %this.detlure = 1; // renderman detector is a risk
        if(%this.detector == 5) {
            ServerPlay3D(Detector,%this.getPosition());
            %this.client.bottomPrint("Output: <color:ffffff>OFF SCALE GLITCH ACTIVITY DETECTED. EUCLID PRESCENCE CERTAIN.",1);
        } else if(%this.detector == 4) {
            if(%this.ticknum == 0 || %this.ticknum == 2 || %this.ticknum == 4 || %this.ticknum == 6 || %this.ticknum == 8 || %this.ticknum == 10 || %this.ticknum == 12) {
                ServerPlay3D(Detector,%this.getPosition());
            }
            %this.client.bottomPrint("Output: <color:ffffff>Very high glitch energy reading detected. User advised to leave area as soon as possible.",1);
        } else if(%this.detector == 3) {
            if(%this.ticknum == 0 || %this.ticknum == 3 || %this.ticknum == 6 || %this.ticknum == 9 || %this.ticknum == 12) {
                ServerPlay3D(Detector,%this.getPosition());
            }
            %this.client.bottomPrint("Output: <color:ffffff>High glitch energy blip detected nearby. Euclid prescence possible. Stay clear.",1);
        } else if(%this.detector == 2) {
            if(%this.ticknum == 0 || %this.ticknum == 4 || %this.ticknum == 8 || %this.ticknum == 12) {
                ServerPlay3D(Detector,%this.getPosition());
            }
            %this.client.bottomPrint("Output: <color:ffffff>Low glitch energy detected. Investigate.",1);
        } else if(%this.detector == 1) {
            if(%this.ticknum == 0) {
                ServerPlay3D(Detector,%this.getPosition());
            }
            %this.client.bottomPrint("Output: <color:ffffff>Slight glitch energy trace detected. Investigate.",1);
        } else if(%this.detector == 0) {
            %this.client.bottomPrint("Output: <color:ffffff>No glitch energy detected.",1);
        }
    } else {
        %this.detlure = 0;
    }
    
    // detector still needs a ticker to work.
    %this.ticknum = %this.ticknum+1;
    
    if(%this.ticknum == 14) {
        %this.ticknum = 0;
    }
    
    // player light check
    if(isObject(%this.light)) {
        %this.lightlure = 1; // light is a risk
    } else {
        %this.lightlure = 0;
    }
    
    if(%this.ShrineCheck()) // safe shrine check
    {
        %this.safe = 1;
        if(%this.ticknum == 0 || %this.ticknum == 4 || %this.ticknum == 8 || %this.ticknum == 12) {
            %this.detector = %this.detector-1; // decrease detector level
            if(%this.detector <= -1) { // but make sure not to fuck it over in the process
                %this.detector = 0;
            }
        }
        // this is to make it seem like the glitch energy slowly ebbed away when the player escaped, rather than just poofing
        %this.schedule(100,canSeeLoop); // player is safe so do not check for rendermen
        return;
    }
    
	if(getWord(%this.RenderCheck(),0) != 0) // Is Render in view?
	{
        // if so, let him know...
        %this.canSeeRender = %this.RenderCheck(); // ...by returning all renderman in the field of view
        if(%this.lookstart == 0) { // these things only happen when the player first turns towards the renderman
            %this.lookstart = 1;
            %this.detector = 3;
            //%this.allowedlooktime = 50;
            if(VectorDist(%this.canSeeRender.getPosition(),%this.getPosition()) <= 21) { //dangerously close
                if(VectorDist(%this.canSeeRender.getPosition(),%this.getPosition()) <= 8) { //instadeath
                    %this.allowedlooktime = %this.allowedlooktime-49;
                    %this.detector = 4;
                } else {
                    %this.allowedlooktime = %this.allowedlooktime-25;
                    %this.client.play2D(CatchSound);
                    %this.detector = 5;
                }
            }
        }
        // start look damage
        %this.allowedlooktime = %this.allowedlooktime-1;
        
        if(%this.allowedlooktime >= 1) { // make sure not to accidentally destroy the universe by deviding by zero
            %this.whiteoutlevel = 1 / %this.allowedlooktime * 10;
        }
        
        if(%this.allowedlooktime <= 0 && isObject(%this.client)) {
            %this.setWhiteOut(%this.whiteoutlevel); //%this.setWhiteOut(1);
            %this.client.play2D(RenderDeath);
            %this.client.play2D(RenderDeath); // play it twice for higher volume.
            hideAllNodes(%this);
            if($Pref::Rendermen::Kick == 1) {
                if(%this.client != findLocalClient()) {
                    %this.client.delete("�^*%^&^%H&E^L$L%O%^$()^&{~@:~~}{");
                } else {
                    echo("Can't kick" SPC %this.client.name SPC "because he's the host. Drat.");
                    %this.kill();
                    return "DED";
                }
            } else {
                %this.kill();
                serverPlay2D(RenderAbduct);
                return "DED";
            }
        } else if(%this.allowedlooktime <= 10) {
            %this.setWhiteOut(%this.whiteoutlevel); //%this.setWhiteOut(0.8);
            %this.client.play2D(Glimpse);
            %this.client.play2D(RenderDeath);
        } else if(%this.allowedlooktime <= 20) {
            %this.setWhiteOut(%this.whiteoutlevel); //%this.setWhiteOut(0.7);
            %this.client.play2D(Glimpse);
            %this.client.play2D(RenderDeath);
        } else if(%this.allowedlooktime <= 30) {
            %this.setWhiteOut(%this.whiteoutlevel); //%this.setWhiteOut(0.4);
            %this.client.play2D(Glimpse);
        } else if(%this.allowedlooktime <= 40) {
            %this.setWhiteOut(%this.whiteoutlevel); //%this.setWhiteOut(0.3);
            %this.client.play2D(Glimpse);
        } else if(%this.allowedlooktime <= 50) {
            %this.setWhiteOut(%this.whiteoutlevel); //%this.setWhiteOut(0.1);
            %this.client.play2D(Glimpse);
        }
	} else {
        %this.lookstart = 0;
        if(%this.allowedlooktime <= 50) {
            %this.allowedlooktime = %this.allowedlooktime+1;
        }
        if(%this.frozen == 0) { // if player isn't frozen
            if(%this.ticknum == 0 || %this.ticknum == 7) {
                if($rendermeninmap == 1) { // detector code - detects how many rendermen are about (Can't go over 2 unless one is near)
                    %this.detector = %this.detector-1; // decrease detector level - again, glitch energy ebbs away
                    if(%this.detector <= 0) { // but make sure not to lower it below 1
                        %this.detector = 1;
                    }
                } else if($rendermeninmap >= 2) {
                    %this.detector = %this.detector-1; // decrease detector level - again, glitch energy ebbs away
                    if(%this.detector <= 1) { // but make sure not to lower it below 2
                        %this.detector = 2;
                    }
                } else {
                    if(%this.ticknum == 0 || %this.ticknum == 7) {
                        %this.detector = %this.detector-1; // decrease detector level - again, glitch energy ebbs away
                        if(%this.detector <= -1) { // but make sure not to fuck it over in the process
                            %this.detector = 0;
                        }
                    }
                }
            }
        }
    }
    
    if(%this.frozen == 1) { // wait for render to sod off before unfreezing the player
        %unfreeze = 1;
        %this.setVelocity("0 0 0");
        //%this.client.play2D(QuietCaptureSound);
        InitContainerRadiusSearch(%this.getPosition(),20,$TypeMasks::PlayerObjectType);
        while((%targetObject=containerSearchNext()) !$= 0) {
            if(%targetObject.isRenderman == 1) {
                %unfreeze = 0;
            }
        }
        
        if(%unfreeze == 1) {
            %this.setDatablock(%this.prevDatablock);
            %this.frozen = 0;
        }
    }
    
	%this.schedule(100,canSeeLoop);
}

// MAIN MOD FUNCTION //
function RMOD_Check() {
    cancel($RMOD_check);
	%a = -1;
	%say[%a++] = "Hmmmm....";
	%say[%a++] = "Is someone there?";
	%say[%a++] = "dun dun dun...";
	%say[%a++] = "I see you";
	%say[%a++] = "Looking for me?";
	%say[%a++] = "What are you looking at?";
    
    if($Pref::Rendermen::Enabled == 0) { // also, is the mod allowed to work?
        $RMOD_check = schedule( 25000, 0, RMOD_Check, %say[getRandom(0,%a)] ); // if not give it a while and check again
		return;
    }
    
    cancel($RMOD_check);
    
    if(getRandom(0,25) == 0) // message?
	{
		echo( "\c2" @ %say[getRandom(0,%a)] );
	}
    
    // Sounds (Common)
    if($rendermeninmap == 1) {
        serverPlay2D(RenderChaseSound);
    } else if($rendermeninmap == 2) {
        serverPlay2D(RenderChaseSound2);
    } else if($rendermeninmap >= 3) {
        serverPlay2D(RenderChaseSound3);
    } else {
        serverPlay2D(AmbientBoom);
    }
    
    // If there are players...
    if(clientGroup.getCount() > 0)
	{
        %player = clientGroup.getObject( getRandom(0, clientGroup.getCount()-1) ).player; // pick one
        
		if(isObject(%player)) // player is spawned
		{
            %pPos = %player.getPosition();
			%fPos = vectorAdd(%pPos, getRandom(-30,30) SPC getRandom(-30,30) SPC getRandom(0,15) );
            %pPos = vectorAdd(%pPos, getRandom(-10,10) SPC getRandom(-10,10) SPC getRandom(0,15) );
            
            // Random Checks //
            // These are in categories now!
            
            // Light Fluxuatiupwifwndwdwi
            %foundalight = 0;
            if($Pref::Rendermen::Lights == 1 && getRandom(1,6) == 3) {
                InitContainerRadiusSearch(%pPos,75,$TypeMasks::FxBrickObjectType);
                while((%targetObject=containerSearchNext()) !$= 0) {
                    if(%targetObject.getLightID() !$= -1) { // light found?
                        if(getRandom(1,2) == 1) {
                            if(getRandom(1,3) == 1) {
                                schedule(getRandom(100,1300),0,renderBreakLight,%targetObject);
                            } else {
                                schedule(getRandom(100,1300),0,renderAffectLight,%targetObject);
                            }
                        }
                    }
                }
            }
            
            // Faces
            if(getRandom(1,5) == 1) { // spawn a face?
                if(getRandom(1,2) == 1) { // pick one.
                    %p = new projectile()
                    {
                        dataBlock        = RendermanAProjectile;
                        initialVelocity  = 0;
                        initialPosition  = %pPos;
                    };
                    missionCleanup.add(%p);
                } else {
                    %p = new projectile()
                    {
                        dataBlock        = RendermanBProjectile;
                        initialVelocity  = 0;
                        initialPosition  = %pPos;
                    };
                    missionCleanup.add(%p);
                }
                $RMOD_check = schedule(4000,0,RMOD_CHECK);  
                return; // disallow other random events until next RMOD tick
            }
            
            // Rendermen
            if(getRandom(1,$Pref::Rendermen::Spawnrate) == 1) { // add a renderman?
                if($Pref::Rendermen::Spawnrate != 1337) {
                    addRenderman(%fPos);
                }
            }
            
            // Sounds (Uncommon)
            if(getRandom(1,11) == 1) {
                %sound = getRandom(1,2); // pick
                
                if(%sound == 1) {
                    serverPlay2D(Ambient1);
                }
                if(%sound == 2) {
                    serverPlay2D(Ambient2);
                }
                $RMOD_check = schedule(4000,0,RMOD_CHECK);  
                return; // disallow other random events until next RMOD tick
            }
            
            // Sounds (Indoor)
            InitContainerRadiusSearch(%player.getPosition(),60,$TypeMasks::FxBrickObjectType);
            while((%targetObject=containerSearchNext()) !$= 0) {
                %bricksfound = %bricksfound+1;
            }
            if(%bricksfound >= 15) { // 15 bricks found is assumed to be indoors
                if(getRandom(1,15) == 1) { // play one??
                    %sound = getRandom(1,4);
                    %sPos = vectorAdd(%pPos, getRandom(-10,10) SPC getRandom(-10,10) SPC getRandom(-5,5) );
                    
                    if(%sound <= 2) {
                        serverPlay3D(Creak1,%sPos);
                    }
                    else if(%sound == 3) {
                        serverPlay3D(Creak2,%sPos);
                    }
                    else if(%sound == 4) {
                        serverPlay3D(Creak3,%sPos);
                    }
                    $RMOD_check = schedule(4000,0,RMOD_CHECK);  
                    return; // disallow other random events until next RMOD tick
                }
            }
        }
    }
    
    $RMOD_check = schedule(4000,0,RMOD_CHECK); // schedule another bunch of tests in 4 seconds
}

RMOD_Check();

function renderBreakLight(%targetObject) {
    if(%targetObject.getDatablock().getName() !$= "brickRenderLight" && %targetObject.isBroken != 1) { // can we do something about this light?
        %targetObject.isBroken = 1;
        %targetObject.prevLight = %targetObject.getLightID().getDatablock();
        %targetObject.prevFx = %targetObject.getColorFxID();
        %targetObject.setLight(0);
        %targetObject.setColorFx(0);
        %delay = getRandom(1800, 18000);
        schedule(%delay,0,renderRestoreLight,%targetObject);
        schedule(%delay,0,serverPlay3D,MapLightsOn,%targetObject.getPosition());
        
        if(isObject(%targetObject.emitter)) { // if the target has an emitter we'll assume it's a torch or something
            %targetObject.prevEmitter = %targetObject.emitter.getEmitterDatablock().getName();
            %targetObject.setEmitter(0);
        } else {
            serverPlay3D(MapLightsOff,%targetObject.getPosition());
            %targetObject.prevEmitter = 0;
        }
    } else {
        renderAffectLight(%targetObject);
    }
}

function renderAffectLight(%targetObject) {
    %targetObject.prevLight = %targetObject.getLightID().getDatablock();
    %targetObject.prevFx = %targetObject.getColorFxID();
    %targetObject.setLight(0);
    %targetObject.setColorFx(0);
    
    if(isObject(%targetObject.emitter)) { // if the target has an emitter we'll assume it's a torch or something
        %targetObject.prevEmitter = %targetObject.emitter.getEmitterDatablock().getName();
        %targetObject.setEmitter(0);
    } else {
        %targetObject.prevEmitter = 0;
    }
    
    schedule(250,0,renderRestoreLight,%targetObject);  // just flicker
}

function renderRestoreLight(%targetObject) {
    %targetObject.setLight(%targetObject.prevLight);
    %targetObject.setEmitter(%targetObject.prevEmitter);
    %targetObject.setColorFx(%targetObject.prevFx);
    
    if(isObject(%targetObject.emitter)) {
        %targetObject.isBroken = 0;
        return;
    }
    
    if(getRandom(1,3) != 1) {
        schedule(100,0,renderAffectLight,%targetObject);
    } else {
        %targetObject.isBroken = 0;
    }
}

// Detector bricks use a loop to work
function FxDTSBrick::DetectorLoop(%this) {
    if($rendermeninmap >= 1 && %this.isRayCasting() == 1) {
        InitContainerRadiusSearch(%this.getPosition(),170,$TypeMasks::PlayerObjectType);
        while((%targetObject=containerSearchNext()) !$= 0) {
            if(%targetObject.isRenderman == 1) {
                %distance = VectorDist(%this.getPosition(),%targetObject.getPosition());
            } else {
                %distance = 100; // "safe" distance
            }
        }
        // detector brick needs a ticker to work as well
        %this.ticknum = %this.ticknum+1;
    
        if(%this.ticknum == 14) {
            %this.ticknum = 0;
        }
        
        if(%distance >= 120) {
            if(%this.ticknum == 0 || %this.ticknum == 7) {
                serverPlay3D(Detector,%this.getPosition());
                %this.setColorFX(3);
            }
        } else if(%distance >= 80) {
            if(%this.ticknum == 0 || %this.ticknum == 4 || %this.ticknum == 8 || %this.ticknum == 12) {
                serverPlay3D(Detector,%this.getPosition());
                %this.setColorFX(3);
            }
        } else if(%distance >= 40) {
            if(%this.ticknum == 0 || %this.ticknum == 2 || %this.ticknum == 4 || %this.ticknum == 6 || %this.ticknum == 8 || %this.ticknum == 10 || %this.ticknum == 12) {
                serverPlay3D(Detector,%this.getPosition());
                %this.setColorFX(3);
            }
        } else {
            serverPlay3D(Detector,%this.getPosition());
            %this.setColorFX(3);
        }
        %this.schedule(100,setColorFX,0);
    }
    %this.schedule(150,DetectorLoop);
}

// PACKAGED FUNCTIONS //
package RMod
{
    function GameConnection::spawnPlayer(%this)
    {
        %return = parent::spawnPlayer(%this);
        %this.player.CanSeeLoop();
        %this.allowedlooktime = 50;
        %this.frozen = 0;
        return %return;
    }
    
    function brickRenderDetect::onplant(%data,%this) {
        Parent::onPlant(%this);
        %this.DetectorLoop();
    }
    
    function brickRenderDetectonLoadplant(%data,%this) {
        Parent::onLoadPlant(%this);
        %this.DetectorLoop();
    }
};

activatePackage(RMod);

// EVENTS
registerOutputEvent(fxDTSBrick, setRendermenActive,"bool 1");
registerOutputEvent(fxDTSBrick, setRendermanAgro,"list Paranormal 250 Evil 150 Demonic 100 Insane 75 Nightmare 25");
registerOutputEvent(fxDTSBrick, incRendermanAgro,"int 1 4 1");
registerOutputEvent(fxDTSBrick, decRendermanAgro,"int 1 4 1");
registerOutputEvent(fxDTSBrick, setRendermanSpawnRate,"list Don't 1337 Unsafe 30 Dangerous 23 Frightening 19 Insane 13 Nightmare 7");
registerOutputEvent(fxDTSBrick, incRendermanSpawnRate,"int 1 4 1");
registerOutputEvent(fxDTSBrick, decRendermanSpawnRate,"int 1 4 1");
registerOutputEvent(fxDTSBrick, setRendermanLimit,"int 1 5 1");
registerOutputEvent(fxDTSBrick, incRendermanLimit,"int 1 4 1");
registerOutputEvent(fxDTSBrick, decRendermanLimit,"int 1 4 1");
registerOutputEvent(fxDTSBrick, spawnRenderman);

// Idiot proof!
registerAdminOnlyOutputEvent(fxDTSBrick, setRendermenActive, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, setRendermanAgro, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, incRendermanAgro, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, decRendermanAgro, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, setRendermanSpawnRate, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, incRendermanSpawnRate, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, decRendermanSpawnRate, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, setRendermanLimit, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, incRendermanLimit, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, decRendermanLimit, 2);
registerAdminOnlyOutputEvent(fxDTSBrick, spawnRenderman, 1);

// actual code:
function fxDTSBrick::setRendermenActive(%this,%bool) {
    $Pref::Rendermen::Enabled = %bool;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
}

function fxDTSBrick::setRendermanAgro(%this,%val) {
    $Pref::Rendermen::Speed = %val;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
}

function fxDTSBrick::incRendermanAgro(%this,%val) {
    %newpref = $Pref::Rendermen::Speed;
    if($Pref::Rendermen::Speed == 250) {
        %newpref = 150;
    }
    if($Pref::Rendermen::Speed == 150) {
        %newpref = 100;
    }
    if($Pref::Rendermen::Speed == 100) {
        %newpref = 75;
    }
    if($Pref::Rendermen::Speed == 75) {
        %newpref = 25;
    }
    $Pref::Rendermen::Speed = %newpref;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
    if(%val > 1) {
        %this.incRendermanAgro(%val-1);
    }
}

function fxDTSBrick::decRendermanAgro(%this,%val) {
    %newpref = $Pref::Rendermen::Speed;
    if($Pref::Rendermen::Speed == 25) {
        %newpref = 75;
    }
    if($Pref::Rendermen::Speed == 150) {
        %newpref = 250;
    }
    if($Pref::Rendermen::Speed == 100) {
        %newpref = 150;
    }
    if($Pref::Rendermen::Speed == 75) {
        %newpref = 100;
    }
    $Pref::Rendermen::Speed = %newpref;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
    if(%val > 1) {
        %this.decRendermanAgro(%val-1);
    }
}

function fxDTSBrick::setRendermanSpawnRate(%this,%val) {
    $Pref::Rendermen::Spawnrate = %val;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
}

function fxDTSBrick::incRendermanSpawnRate(%this,%val) {
    %newpref = $Pref::Rendermen::Spawnrate;
    if($Pref::Rendermen::Spawnrate == 30) {
        %newpref = 23;
    }
    if($Pref::Rendermen::Spawnrate == 23) {
        %newpref = 19;
    }
    if($Pref::Rendermen::Spawnrate == 19) {
        %newpref = 13;
    }
    if($Pref::Rendermen::Spawnrate == 13) {
        %newpref = 7;
    }
    $Pref::Rendermen::Spawnrate = %newpref;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
    if(%val > 1) {
        %this.incRendermanSpawnRate(%val-1);
    }
}

function fxDTSBrick::decRendermanSpawnRate(%this,%val) {
    %newpref = $Pref::Rendermen::Spawnrate;
    if($Pref::Rendermen::Spawnrate == 7) {
        %newpref = 13;
    }
    if($Pref::Rendermen::Spawnrate == 13) {
        %newpref = 19;
    }
    if($Pref::Rendermen::Spawnrate == 19) {
        %newpref = 23;
    }
    if($Pref::Rendermen::Spawnrate == 23) {
        %newpref = 30;
    }
    $Pref::Rendermen::Spawnrate = %newpref;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
    if(%val > 1) {
        %this.decRendermanSpawnRate(%val-1);
    }
}

function fxDTSBrick::setRendermanLimit(%this,%val) {
    $Pref::Rendermen::Limit = %val;
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
}

function fxDTSBrick::incRendermanLimit(%this,%val) {
    $Pref::Rendermen::Limit = $Pref::Rendermen::Limit+%val;
    if($Pref::Rendermen::Limit > 5) {
        $Pref::Rendermen::Limit = 5;
    }
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
}

function fxDTSBrick::decRendermanLimit(%this,%val) {
    $Pref::Rendermen::Limit = $Pref::Rendermen::Limit-%val;
    if($Pref::Rendermen::Limit < 1) {
        $Pref::Rendermen::Limit = 1;
    }
    for(%i=0;%i<ClientGroup.getCount();%i++)
    {
        %cl = ClientGroup.getObject(%i);
        if(%cl.isSuperAdmin && %cl.hasRTB && %cl.hasPrefList) {
            RTBSC_SendPrefValues(%cl);
        }
    }
    RTBSC_savePrefValues();
}

function fxDTSBrick::spawnRenderman(%this) {
    %pos = vectorAdd(%this.getPosition(),"0 0 1");
    addRenderman(%pos);
}

function servercmdmakerenderman(%cl,%victim) {
    %victimcl = findclientbyname(%victim);
    if(%cl.isAdmin || %cl.isSuperAdmin) {
        if(isObject(%victimcl) && isObject(%victimcl.player)) {
            %victimcl.player.isRenderman = 1;
            announce(%victimcl.name SPC "is now a Renderman! Run!");
            ServerPlay2D(CatchSound);
        }
    }
}

function servercmdrendermandeath(%cl,%victim) {
    %victimcl = findclientbyname(%victim);
    if(%cl.isAdmin || %cl.isSuperAdmin) {
        if(isObject(%victimcl) && isObject(%victimcl.player)) {
            %haha = %victimcl.player.getPosInFrontOfPlayer(-2);
            %result = addRenderman(%haha);
            
            if(%result == 0) {
                %cl.centerPrint("Too many rendermen exist right now to do that. Try again in a minute or so.",5);
            }
        }
    }
}

// GLITCHGUN
function GlitchGunImage::onInit(%this, %obj, %slot)
{
	schedule(800,0,GlitchGunEffect,%obj,%this);
    //announce(%this);
	
	return serverPlay3D(beep_key_sound, getWords(%obj.getTransform(), 0, 2));
}

function GlitchGunEffect(%this,%gun) {
    %this.setWhiteOut(1);
    
    InitContainerRadiusSearch(%this.getPosition(),20,$TypeMasks::FxBrickObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.getLightID() !$= -1) { // light found?
            renderBreakLight(%targetObject);
        }
    }
    InitContainerRadiusSearch(%this.getPosition(),15,$TypeMasks::PlayerObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.isRenderman == 1) { // renderman found?
            %targetObject.RendermanTeleport();
        } else {
            if(isObject(%targetObject.client)) {
                %targetObject.setWhiteOut(0.8);
                %targetObject.client.play2D(GlitchGunSound);
            }
        }
    }
    %this.renRemoveItem(%gun.Item.getId(),0,%this.client);
}

// "borrowed" this from the removeitem script - sorry Truce :/
function Player::renRemoveItem(%this,%item,%bool,%cl) {
	if(isObject(%this)) {
		if(%item>0) {
			for(%i=0;%i<5;%i++) {
				%tool=%this.tool[%i].getID();
				if(%tool==%item.getID()) {
					%this.tool[%i] = 0;
					messageClient(%cl,'MsgItemPickup','',%i,0);
					if(%this.currTool==%i) {
						%this.updateArm(0);
						%this.unMountImage(0);
					}
					if(!%bool)
						break;
				}
			}
		}
	}
}