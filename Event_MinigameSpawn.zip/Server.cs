// +---------------------------------------------------------------------------+
// |  onMinigameSpawn Event                                                    |
// +---------------------------------------------------------------------------+
// |  Server.cs                                                                |
// |  Version 2.0                                                              |
// +---------------------------------------------------------------------------+
// |  Greek2me                                                                 |
// |  ID 11902                                                                 |
// +---------------------------------------------------------------------------+

// +---------------------------------+
// | Input Event                     |
// +---------------------------------+

registerInputEvent(fxDtsBrick,"onMinigameSpawn","Self fxDtsBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");

$MinigameSpawn::List = inputEvent_GetInputEventIdx("onMinigameSpawn");

// +---------------------------------+
// | Packaged Functions              |
// +---------------------------------+

package MinigameSpawn
{
	function GameConnection::SpawnPlayer(%client)
	{
		parent::SpawnPlayer(%client);

		for(%i=0;%i<getWordCount($MinigameSpawn::List2);%i++)
		{
			%brick = getWord($MinigameSpawn::List2,%i);
			%minigame = getMinigameFromObject(%client);
			if(isObject(%brick) && isObject(%minigame))
			{
				$inputTarget_Self = %brick;
				$inputTarget_Player = %client.player;
				$inputTarget_Client = %client;
				$inputTarget_Minigame = %minigame;
				%brick.processInputEvent("onMinigameSpawn",%client);
			}
		}
	}

	function serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4)
	{
		if(%input == $MinigameSpawn::List)
		{
			$MinigameSpawn::List2 = addItemToList($MinigameSpawn::List2,%client.wrenchBrick);
		}
		return Parent::serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4);
	}

	function serverCmdClearEvents(%client)
	{
		if(hasItemOnList($MinigameSpawn::List2,%client.wrenchBrick))
		{
			$MinigameSpawn::List2 = removeItemFromList($MinigameSpawn::List2,%client.wrenchBrick);
		}
		Parent::serverCmdClearEvents(%client);
	}

	function fxDtsBrick::onDeath(%brick)
	{
		if(hasItemOnList($MinigameSpawn::List2,%brick))
		{
			$MinigameSpawn::List2 = removeItemFromList($MinigameSpawn::List2,%brick);
		}
		Parent::onDeath(%brick);
	}
};
activatepackage(MinigameSpawn);

// +---------------------------------+
// | Various Functions (By Ephialtes)|
// +---------------------------------+

function addItemToList(%string,%item)
{
	if(hasItemOnList(%string,%item))
		return %string;

	if(%string $= "")
		return %item;
	else
		return %string SPC %item;
}
function hasItemOnList(%string,%item)
{
	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
			return 1;
	}
	return 0;
}
function removeItemFromList(%string,%item)
{
	if(!hasItemOnList(%string,%item))
		return %string;

	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
		{
			if(%i $= 0)
				return getWords(%string,1,getWordCount(%string));
			else if(%i $= getWordCount(%string)-1)
				return getWords(%string,0,%i-1);
			else
				return getWords(%string,0,%i-1) SPC getWords(%string,%i+1,getWordCount(%string));
		}
	}
}