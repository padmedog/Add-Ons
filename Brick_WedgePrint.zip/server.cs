datablock fxDTSBrickData(brick1x1PrintWedgeData)
{
	brickFile = "./1x1printwedge.blb";
	category = "Wedges";
	subCategory = "Prints";
	uiName = "1x1 Wedge Print";
	iconName = "base/client/ui/brickIcons/Unknown";
	collisionShapeName = "./1x1printwedge.dts";
	
		hasPrint = 1;
	printAspectRatio = "1x1";
};

datablock fxDTSBrickData(brick2x2PrintWedgeData)
{
	brickFile = "./2x2printwedge.blb";
	category = "Wedges";
	subCategory = "Prints";
	uiName = "2x2 Wedge Print";
	iconName = "base/client/ui/brickIcons/Unknown";
	collisionShapeName = "./2x2printwedge.dts";
	
		hasPrint = 1;
	printAspectRatio = "1x1";
};

datablock fxDTSBrickData(brick4x4PrintWedgeData)
{
	brickFile = "./4x4printwedge.blb";
	category = "Wedges";
	subCategory = "Prints";
	uiName = "4x4 Wedge Print";
	iconName = "base/client/ui/brickIcons/Unknown";
	collisionShapeName = "./4x4printwedge.dts";
	
		hasPrint = 1;
	printAspectRatio = "1x1";
};

