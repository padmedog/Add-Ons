exec("./antiall.cs");
exec("./antired.cs");
exec("./antigreen.cs");
exec("./antiblue.cs");
exec("./special.cs");