//audio
datablock AudioProfile(MeltagunFireSound)
{
   filename    = "./Meltagun_fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(MeltagunHitSound)
{
   filename    = "./Meltagun_hit.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(MeltagunSmokeParticle)
{
	dragCoefficient      = 1.5;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 525;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	= "0 0.5 1 0.5";
	colors[1]	= "1 0.875 5 0.5";
	colors[2]	= "1 0.25 0 0.0";
	sizes[0]	= 0.4;
	sizes[1]	= 0.7;
	sizes[2]	= 0.8;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1;

	useInvAlpha = false;
};

datablock ParticleEmitterData(MeltagunSmokeEmitter)
{
   ejectionPeriodMS = 12;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 0.5;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MeltagunSmokeParticle";
};

datablock ParticleData(MeltagunTrailParticle)
{
	dragCoefficient		= 1;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0625;
	constantAcceleration	= 0.0;
	lifetimeMS		= 700;
	lifetimeVarianceMS	= 200;
	spinRandomMin		= -1500.0;
	spinRandomMax		= 1500.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "0 0.5 1 0.5";
	colors[1]	= "1 0.875 5 0.5";
	colors[2]	= "1 0.25 0 0.0";
	sizes[0]	= 4.0;
	sizes[1]	= 1.0;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.25;
	times[2]	= 1;
};

datablock ParticleEmitterData(MeltagunTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = MeltagunTrailParticle;

   useEmitterColors = true;
};

datablock ParticleData(MeltagunExplosionParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 500;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 50.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]	= "0 0.5 1 0.5";
	colors[1]	= "1 0.875 5 0.5";
	colors[2]	= "1 0.25 0 0.0";
	sizes[0]      = 2.5;
	sizes[1]      = 5.0;
	sizes[2]      = 7.5;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1;	

	useInvAlpha = false;
};
datablock ParticleEmitterData(MeltagunExplosionEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MeltagunExplosionParticle";

   useEmitterColors = true;
};

datablock ParticleData(MeltagunExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 50;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	= "0 0.5 1 0.5";
	colors[1]	= "1 0.875 5 0.5";
	colors[2]	= "1 0.25 0 0.0";
	sizes[0]      = 3.3;
	sizes[1]      = 6.6;
	sizes[2]	  = 10;
	times[0]	= 0.0;
	times[1]	= 0.25;
	times[2]	= 1;	
	
	useInvAlpha = false;
};
datablock ParticleEmitterData(MeltagunExplosionRingEmitter)
{
	lifeTimeMS = 300;

   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MeltagunExplosionRingParticle";

   useEmitterColors = true;
};

datablock ExplosionData(MeltagunExplosion)
{
   //explosionShape = "";
	soundProfile = MeltagunHitSound;

   lifeTimeMS = 100;

   particleEmitter = MeltagunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = MeltagunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 2.5;
   
   damageRadius = 3; 
   radiusDamage = 0;                                           
   impulseRadius = 2;  
   impulseForce = 100;    
   playerBurnTime = 2000;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "1 0.875 0.75 1";
   lightEndColor = "1 0.25 0 0";
};

AddDamageType("Meltagun",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Meltagun> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Meltagun> %1',0.75,1);
datablock ProjectileData(MeltagunProjectile)
{
   //projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 200;
   directDamageType    = $DamageType::Meltagun;
   radiusDamageType    = $DamageType::Meltagun;

   brickExplosionRadius = 2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;
   brickExplosionMaxVolume = 76;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 96;  //max volume of bricks that we can destroy if they aren't connected to the ground

   sound = rocketLoopSound;
   
   impactImpulse	     = 1200;
   verticalImpulse	  = 400;
   explosion           = MeltagunExplosion;
   particleEmitter     = "MeltagunTrailEmitter";

   muzzleVelocity      = 140;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 275;
   fadeDelay           = 7200;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = true;
   lightRadius = 6.0;
   lightColor  = "0.75 0.75 1";
   
   uiName = "Meltagun shot";
};

datablock ProjectileData(MeltagunHalfrangeProjectile)
{
   //projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 200;
   directDamageType    = $DamageType::Meltagun;
   radiusDamageType    = $DamageType::Meltagun;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground

   //sound = rocketLoopSound;
   
   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   //explosion           = MeltagunExplosion;
   particleEmitter     = "";

   muzzleVelocity      = 150;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 135;
   fadeDelay           = 7200;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 6.0;
   lightColor  = "0.75 0.75 1";
   
   //uiName = "Meltagun shot";
};

//////////
// item //
//////////
datablock ItemData(MeltagunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Meltagun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Meltagun";
	iconName = "./Meltagun";
	doColorShift = false;
	colorShiftColor = "0.7 0.7 0.72 1.000";

	 // Dynamic properties defined by the scripts
	image = MeltagunImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 5;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MeltagunImage)
{

   // Basic Item properties
   shapeFile = "./Meltagun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = MeltagunItem;
   ammo = " ";
   projectile = MeltagunProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = MeltagunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.55;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateSound[2]			= MeltagunFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= MeltagunSmokeEmitter;
	stateEmitterTime[3]		= 1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.55;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 1.5;
	stateTransitionOnTimeout[4]	= "Ready";
	
};

function MeltagunImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, plant);

	%obj.spawnExplosion(TTLargeRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0008;
	}
	else
	{
		%spread = 0.0008;
	}
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	
	%projectile = "MeltagunHalfrangeProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;
}


function MeltagunProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = mClampF(%this.directDamage, -1000, 1000) * %scale;

   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }	
}

function MeltagunHalfrangeProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = mClampF(%this.directDamage, -1000, 1000) * %scale;

   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }	
}
