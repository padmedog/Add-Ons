$TL::Version = "2.2.0";
function reltrust() {
	exec("./client.cs");
}
exec("./MainMenu.cs");
$TL::FileName = $pref::TLFile;
if($TL::Tango == 0) {
	if(isFile("./tango.cs")) {
		exec("./tango.cs");
	} else {
		$TL::NoTango = 1;
	}
	$TL::Tango = 1;
}
exec("./access.gui");
if($TRUSTLIST::GUIs::TL_List::isGuiLoaded != 1) {
	exec("./TL_List.gui");
	exec("./TL_Update.gui");
	$TRUSTLIST::GUIs::TL_List::isGuiLoaded = 1;
}
TL_VersionInfo.setText("<font:verdana bold:14><color:ffff00>v"@$TL::Version);
function TL::Toggleinfo() {
	if($TL::TInfo == 0) {
		$TL::TInfo = 1;
		TL_InfoP.tangoMoveTo("0 0",1000,elastic);
	} else {
		$TL::TInfo = 0;
		TL_InfoP.tangoMoveTo("0 -200",1000,elastic);
	}
}
if(!$TLBinding) {
	$remapDivision[$remapCount] = "Trust List Manager";
	$remapName[$remapCount] = "Open GUI";
	$remapCmd[$remapCount] = "TLOpenMainGUI";
	$remapCount++;
	$TLBinding = true;
}
function TLOpenMainGUI() {
	if(TL_List.isVisible == 1) {
		canvas.popdialog(TL_List);
	} else {
		canvas.pushdialog(TL_List);
	}
}
function TL_SetNickname() {
	if(TL_Name_editb.getText() !$= "") {
		if($TL::Selected::TrustLevel == 1) {
			if(isFile("add-ons/system_trustlist/Avatars/"@$TL::Selected::Name@"_avatar.png") == 1) {
				TL_TrustList.setRowById($TL::Selected::Index,$TL::Selected::BLID@"\tBuild\t"@$TL::Selected::Name@"\tYes\t\c1"@TL_Name_editb.getText());
			} else {
			TL_TrustList.setRowById($TL::Selected::Index,$TL::Selected::BLID@"\tBuild\t"@$TL::Selected::Name@"\tNo\t\c1"@TL_Name_editb.getText());
			}
		} else {
			if(isFile("add-ons/system_trustlist/Avatars/"@$TL::Selected::Name@"_avatar.png") == 1) {
				TL_TrustList.setRowById($TL::Selected::Index,$TL::Selected::BLID@"\tFull\t"@$TL::Selected::Name@"\tYes\t\c1"@TL_Name_editb.getText());
			} else {
				TL_TrustList.setRowById($TL::Selected::Index,$TL::Selected::BLID@"\tFull\t"@$TL::Selected::Name@"\tNo\t\c1"@TL_Name_editb.getText());
			}
		}
		$pref::TL::Nickname[$TL::Selected::Name] = TL_Name_editb.getText();
		TL_Name_editb.setText("");
	} else {
		TL_DeleteNickname();
	}
}
function TL_DeleteNickname() {
	if(TL_TrustList.getSelectedId() != -1) {
		if($pref::TL::Nickname[$TL::Selected::Name] !$= "") {
			messageboxok("Nickname Deletion","Deleted "@$TL::Selected::Name@"\'s nickname.");
			TL_Echo("Deleted "@$TL::Selected::Name@"\'s nickname ("@$pref::TL::Nickname[$TL::Selected::Name]@")");
			$pref::TL::Nickname[$TL::Selected::Name] = "";
		} else {
			messageboxok("Error when attempting to delete nickname","Cannot delete "@$TL::Selected::Name@"\'s nickname as there is no nickname set.");
		}
		TL_Load();
	} else {
		messageboxok("Error","Please select someone to delete their nickname.");
	}
}
if(isFile("add-ons/client_addons/hook_loadaddons.cs")) {
	exec("add-ons/client_addons/hook_loadaddons.cs");
	%count = 50;
	for(%i=1;%i<%count;%i++) {
		if($Level::Addonsystem::ID[%i] $= "") {
			LVLA_regaddon("Trust Editor","Clay Hanson","1.3a",%i,"cog","The trust list addon allows you to edit your trusts.");
			break;
		}
	}
	//LVL_regprefs(%id,%prefid,%prefname,%variable,%preftype);
}
function TL_Load() {
	//TL_b_remove.enabled = false;
	//TL_d_rem_tick.setBitmap("add-ons/system_trustlist/images/tickGray.png");
	//TL_d_trst_tick.setBitmap("add-ons/system_trustlist/images/tickGray.png");
	TL_I_Name.setText("<font:verdana bold:16><color:ffffff>N/A");
	TL_I_BLID.setText("<font:verdana bold:16><color:ffffff>N/A");
	TL_I_trustlevel.setText("<font:verdana bold:16><color:ffffff>N/A");
	TL_TrustList.clear();
	%counta = $Pref::Trustlistcount;
	for(%a=0;%a<%counta;%a++) {
		$Pref::TrustList::Entry[%i] = "";
	}
	$Pref::Trustlistcount = 0;
	%b = isFile("config/client/"@$TL::FileName);
	
	if(%b == 1)
	{
		%SD = new FileObject();
		%SD.openforread("config/client/"@$TL::FileName);
		%count = 300;
		for(%i=0;%i<%count;%i++) {
			%line[%i] = %SD.readLine();
			if(getWord(%line[%i], 1)) {
				$Pref::TrustList::Entry[%i] = getWord(%line[%i], 0)@" "@getWord(%line[%i], 1)@" "@getWord(%line[%i], 2)@" "@%i;
				$Pref::Trustlistcount++;
				if(getWord(%line[%i],1) == 1) {
					if(isFile("add-ons/system_trustlist/Avatars/"@getWord(%line[%i], 2)@"_avatar.png") == 1) {
						if($pref::TL::Nickname[getWord(%line[%i], 2)] !$= "") {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tBuild\t"@getWord(%line[%i], 2)@"\tYes\t\c1"@$pref::TL::Nickname[getWord(%line[%i], 2)],0);
						} else {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tBuild\t"@getWord(%line[%i], 2)@"\tYes\t\c3N/A",0);
						}
					} else {
						if($pref::TL::Nickname[getWord(%line[%i], 2)] !$= "") {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tBuild\t"@getWord(%line[%i], 2)@"\tNo\t\c1"@$pref::TL::Nickname[getWord(%line[%i], 2)],0);
						} else {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tBuild\t"@getWord(%line[%i], 2)@"\tNo\t\c3N/A",0);
						}
					}
				} else if(getWord(%line[%i],1) == 2) {
					if(isFile("add-ons/system_trustlist/Avatars/"@getWord(%line[%i], 2)@"_avatar.png") == 1) {
						if(!$pref::TL::Nickname[getWord(%line[%i], 2)]) {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tFull\t"@getWord(%line[%i], 2)@"\tYes\t\c3N/A",0);
						} else {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tFull\t"@getWord(%line[%i], 2)@"\tYes\t\c1"@$pref::TL::Nickname[getWord(%line[%i], 2)],0);
						}
					} else {
						if(!$pref::TL::Nickname[getWord(%line[%i], 2)]) {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tFull\t"@getWord(%line[%i], 2)@"\tNo\t\c3N/A",0);
						} else {
							TL_TrustList.addrow(%i,getWord(%line[%i], 0)@"\tFull\t"@getWord(%line[%i], 2)@"\tNo\t\c1"@$pref::TL::Nickname[getWord(%line[%i], 2)],0);
						}
					}
				}
				$Pref::TrustList::Enabled = 1;
			}
		}
		$Pref::Trustlistcount--;
		TL_echo("Got a total of "@$Pref::Trustlistcount@" trust entries.");
		%SD.close();
		%SD.delete();
	} else {
		$Pref::TrustList::Enabled = 0;
		TL_TrustList.addrow(0,"We could not find your Trust List file. Please restart your game.",0);
		TL_TrustList.addrow(1," Or, you could try any of these following steps:",1);
		TL_TrustList.addrow(2,"   + Add someone to your Trust List: This will force the game to write to the file that stores your trusts.",2);
		TL_TrustList.addrow(3,"   + Change the filename in Options",3);
		TL_TrustList.addrow(4,"If this keeps happening, please send a PM (Personal Message) to RTBARCHIVE at http://forum.blockland.us",4);
	}
}
function TL_GUI_Close() {
	$TL::Optionpanel = 0;
	TL_Options.tangoMoveTo("0 603",1000,elastic);
	TL_optionsb.tangoMoveTo("0 572",1000,elastic);
	schedule(600,0,TL_GUI_Closept);
}
function TL_GUI_Closept() {
	TL_optionsb.setVisible(false);
	TL_closec.tangoMoveTo("-17 571",1000,elastic);
	TL_closeb.tangoMoveTo("-138 572",1000,elastic);
	TL_togclose.tangoMoveTo("0 571",1000,elastic);
}
function TL_GUI_Open() {
	TL_closec.tangoMoveTo("139 571",1000,elastic);
	TL_closeb.tangoMoveTo("0 572",1000,elastic);
	TL_togclose.tangoMoveTo("-17 571",1000,elastic);
	schedule(500,0,TL_GUI_Open_ptwo);
}
function TL_togop() {
	if($TL::Optionpanel == 0) {
		$TL::Optionpanel = 1;
		TL_Options.tangoMoveTo("0 303",1000,elastic);
	} else {
		$TL::Optionpanel = 0;
		TL_Options.tangoMoveTo("0 603",1000,elastic);
	}
}
function TL_GUI_Open_ptwo() {
	TL_optionsb.visible = true;
	TL_optionsb.tangoMoveTo("0 543",1000,elastic);
}
function TL_OptionsSaved() {
	if(isFile("Add-ons/system_returntoblockland.zip")) {
		TL_Info("Trust List","saved settings.","wrench");
		TL_o_saved.visible = true;
		schedule(2000,0,"TL_hideoptsaved");
	} else {
		TL_o_saved.visible = true;
		schedule(2000,0,"TL_hideoptsaved");
	}
}
function TL_hideoptsaved() {
	TL_o_saved.visible = false;
}
function TL_bpin_password() {
	if(TL_betapass.getValue() == 1554) {
		TL_au_betablckr.visible = false;
		TL_rff_betablck.visible = false;
	}
}
function TL_GetInfo() {
	if($Pref::TrustList::Enabled == 1) {
		//TL_b_remove.enabled = true;
		//TL_d_rem_tick.setBitmap("add-ons/system_trustlist/images/tick.png");
		%id = TL_TrustList.getSelectedId();
		%info = $Pref::TrustList::Entry[%id];
		TL_I_Name.setText("<font:verdana bold:16><color:ffffff>"@getWord(%info, 2));
		TL_I_BLID.setText("<font:verdana bold:16><color:ffffff>"@getWord(%info, 0));
		if(getWord(%info,1) == 1) {
			TL_I_trustlevel.setText("<font:verdana bold:16><color:ffffff>Build");
		} else if(getWord(%info, 1) == 2) {
			TL_I_trustlevel.setText("<font:verdana bold:16><color:ffffff>Full");
		} else if(getWord(%info, 1) == 3) {
			TL_I_trustlevel.setText("<font:verdana bold:16><color:ffffff>You");
		}
		//Load profile picture
		if(isFile("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@"_avatar.png")) {
			TL_Pic.setBitmap("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@"_avatar.png");
		} else if(isFile("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@" "@getWord(%info,3)@"_avatar.png")) {
			TL_Pic.setBitmap("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@" "@getWord(%info,3)@"_avatar.png");
		} else if(isFile("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@"_avatar.jpg")) {
			TL_Pic.setBitmap("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@"_avatar.jpg");
		} else if(isFile("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@" "@getWord(%info,3)@"_avatar.jpg")) {
			TL_Pic.setBitmap("add-ons/system_trustlist/Avatars/"@getWord(%info,2)@" "@getWord(%info,3)@"_avatar.jpg");
		} else {
			TL_Pic.setBitmap("add-ons/system_trustlist/images/Prof_NA.png");
		}
		$TL::Selected::Name = getWord(%info,2);
		$TL::Selected::BLID = getWord(%info,0);
		$TL::Selected::TrustLevel = getWord(%info,1);
		$TL::Selected::Index = getWord(%info,3);
	}
}
function TL_SwitchTab(%tab) {
	if(%tab) {
		if(%tab == 1) {
			TL_t_Server.visible = false;
			TL_t_mylist.visible = true;
			TL_ListCat.setText("<color:ffffff>BLID        Trust    Name                        Profile Picture?          Nickname");
			TL_Toggle_Disable.visible = false;
			if($TL::Cache::Tab::TInfo == 1) {
				TL_TINFO_B.performclick();
			}
		} else if(%tab == 2) {
			TL_t_Server.visible = true;
			TL_t_mylist.visible = false;
			TL_ListCat.setText("<color:ffffff>Admin   Name                                           Score         BLID              Trust");
			TL_Server_Load();
			if($TL::TInfo == 1) {
				$TL::Cache::Tab::TInfo = 1;
				TL_TINFO_B.performclick();
			} else {
				$TL::Cache::Tab::TInfo = 0;
			}
			TL_Toggle_Disable.visible = true;
		}
	}
}
function TL_findtext(%string) {
	for(%i=0;%i<500;%i++) {
		if(strpos(TL_TrustList.getRowTextById(%i),%string) != -1) {
			return 1;
		}
	}
	return 0;
}
function TL_echo(%msg) {
	echo("\c5(\c3TrustList\c5)\c6: \c4"@%msg);
}
function TL_error(%msg) {
	echo("\c5(\c2TrustList\c5)\c6: \c2"@%msg);
}
function TL_CheckConnection() {
	if($TL::Connected == 0) {
		TLUpdator::onConnectFailed();
	}
}
function TL_setmsgbox(%pos) {
	if(%pos) {
		if(%pos == 1) {
			TL_msgbox.canClose = false;
			TL_m_yesno.visible = true;
		} else if(%pos == 2) {
			TL_msgbox.canClose = true;
			TL_m_yesno.visible = false;
		}
	}
}
NPL_Window.add(TL_button);
function TL_Server_Load() {
	TL_S_I_Name.setText("<font:verdana bold:18><just:center>N/A");
	TL_S_I_Pos.setText("<font:verdana:16><just:center>N/A");
	TL_S_I_Sco.setText("<font:verdana:16><just:left>Score:<just:center>N/A");
	TL_S_I_TLVL.setText("<font:verdana:16><just:left>Trust Level:<just:center>N/A");
	TL_S_I_BLID.setText("<font:verdana:16><just:left>Blockland ID:<just:center>N/A");
	TL_ServerList.clear();
	if(NPL_List.getRowText(0) !$= "") {
		for(%i=0;%i<NPL_List.rowCount();%i++) {
			TL_ServerList.addrow(NPL_List.getRowID(%i),NPL_List.getRowText(%i),%i);
		}
	} else {
		TL_ServerList.addrow(0,"Connect to a server first.",0);
	}
	TL_a_BLID.settext("");
}
function strIsNum(%str) {
	%table = "-.1234567890";  
	%len = strlen(%str);  
	for(%i = 0; %i < %len; %i ++)  
	{  
		if(strPos(%table, getSubStr(%str, %i, 1)) == -1) {
			return 0;  
   		}
	}
	return 1;  
} 
function TL_DeleteTrustList() {
	if(isFile("config/client/"@$TL::FileName)) {
		%file = new fileObject();
		%file.openForWrite("config/client/"@$TL::FileName);
		%file.writeLine("");
		%file.close();
		%file.delete();
	} else {
		error("ERROR: No trust list file to delete.");
	}
}
function opentrustlistmenu() {
	if($TL::NoTango) {
		messageboxok("An error has occured!","We're sorry, but the 'tango.cs' file does not exist within 'system_trustlist'. Please reinstall the add-on.");
		TL_Info("Trust List","failed to load.","exclamation");
	} else {
		canvas.pushdialog(TL_List);
		TL_Load();
	}
}
function TL_S_GetInfo() {
	if(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()) !$= "Connect to a server first.") {
		TL_S_GetInfoA();
	}
}
function TL_S_GetInfoA() {
	if(strIsNum(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),2)) == 0) {
		//a spaced name
		$TL::S::Selected::Name = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),1) SPC getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),2);
		$TL::S::Selected::BLID = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),4);
		if(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),0) $= "S") {
			$TL::S::Selected::Position = "Super Administrator";
		} else if(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),0) $= "A") {
			$TL::S::Selected::Position = "Administrator";
		} else if(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),0) $= "-") {
			$TL::S::Selected::Position = "Regular Player";
		}
		$TL::S::Selected::Score = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),3);
		$TL::S::Selected::TLevel = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),5);
	} else {
		$TL::S::Selected::Name = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),1);
		$TL::S::Selected::BLID = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),3);
		if(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),0) $= "S") {
			$TL::S::Selected::Position = "Super Administrator";
		} else if(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),0) $= "A") {
			$TL::S::Selected::Position = "Administrator";
		} else if(getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),0) $= "-") {
			$TL::S::Selected::Position = "Player";
		} else {
			$TL::S::Selected::Position = "In Minigame";
		}
		$TL::S::Selected::Score = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),2);
		$TL::S::Selected::TLevel = getword(TL_ServerList.getRowTextById(TL_ServerList.getSelectedId()),4);
	}
	TL_S_SetInfo();
}
function TL_S_SetInfo() {
	if($TL::S::Selected::BLID == 15144) {
		TL_S_I_Name.setText("<bitmap:add-ons/system_trustlist/images/addondev> <font:verdana bold:17><just:center><color:0000ff>"@$TL::S::Selected::Name);
	} else {
		if($TL::S::Selected::Position $= "Administrator") {
			TL_S_I_Name.setText("<bitmap:add-ons/system_trustlist/images/admin> <font:verdana bold:17><just:center>"@$TL::S::Selected::Name);
		} else if($TL::S::Selected::Position $= "Super Administrator") {
			TL_S_I_Name.setText("<bitmap:add-ons/system_trustlist/images/sadmin> <font:verdana bold:17><just:center>"@$TL::S::Selected::Name);
		} else {
			TL_S_I_Name.setText("<font:verdana bold:17><just:center>"@$TL::S::Selected::Name);
		}
	}
	TL_S_I_Pos.setText("<font:verdana:16><just:center>"@$TL::S::Selected::Position);
	TL_S_I_Sco.setText("<font:verdana:16><just:left>Score:<just:center>"@$TL::S::Selected::Score);
	TL_S_I_TLVL.setText("<font:verdana:16><just:left>Trust Level:<just:center>"@$TL::S::Selected::TLevel);
	TL_S_I_BLID.setText("<font:verdana:16><just:left>Blockland ID:<just:center>"@$TL::S::Selected::BLID);
	TL_a_BLID.setText($TL::S::Selected::BLID);
}
//EXTRAS
function TL_Info(%name,%condition,%icon) {
	if(isFile("add-ons/system_returntoblockland.zip")) {
		TL_Echo("\'"@%name@"\' "@%condition);
	} else {
		TL_Echo("\'"@%name@"\' "@%condition);
	}
}
if(isFile("./tango.cs")) {
	if($TL::StartMessage::AlreadyPlayed == 0) {
		TL_Info("Trust List","started.","plugin");
		TL_Echo("Trust List started.");
		$TL::StartMessage::AlreadyPlayed = 1;
	}
} else {
	TL_Info("Trust List","failed to load.","exclamation");
}
//
//Trust Sending
//
function TL_Checkadd() {
	if(TL_a_blid.getValue() $= "") {
		messageboxok("An error occured!","<just:left><bitmap:add-ons/system_trustlist/images/warning><just:center>Select someone from the server list.");
	} else {
		if(TL_a_tst.getValue() $= "Build") {
			commandtoserver('Trust_invite',TL_ServerList.getSelectedID(),TL_a_BLID.getValue(),1);
		} else if(TL_a_tst.getValue() $= "Full") {
			commandtoserver('Trust_invite',TL_ServerList.getSelectedID(),TL_a_BLID.getValue(),2);
		} else if(TL_a_tst.getValue() $= "Remove") {
			if(getNumKeyID() == TL_a_BLID.getValue()) {
				messageboxok("Error","You cannot remove trust from yourself.");
			} else {
				commandtoserver('Trust_Demote',TL_a_BLID.getValue(),0);
				TL_B_Ref.schedule(100,performclick);
			}
		}
	}
}
package checkforaccept {
	function clientCmdTrustInviteAccepted(%a,%b,%b,%c) {
		TL_B_Ref.schedule(100,performclick);
		parent::clientCmdTrustInviteAccepted(%a,%b,%b,%c);
	}
};
activatepackage(checkforaccept);
//function clientcmdrecievetrustinformation(%data,%level) {
	//0 means the player left during validating
	//1 means that someone on the server has already sent a trust invite. The server can only handle 1 trust invite at a time.
	//2 means that the player rejected it. Pretty simple.
	//3 means that the player accepted it. Pretty simple. In this instance, %level will be used for the client info. FORMAT BELOW::
	//%cl.bl_id (SPC) [Trust Level] (SPC) %cl.name
	//For example, if it sent my info with a build request, it would recieve...
	//15144 1 Clay Hanson
	//4 means that an error occured. In this instance, %level will be used as the error printout.
	//5 means that you removed the client you wanted to remove successfully. In this instance, %level will be used for the %client's 
	//name
	//if(%data $= "0") {
	//	messageboxok("Trust Information","ERROR!\nThe player you specified is not currently on the server.");
	//} else if(%data $= "1") {
	//	messageboxok("Trust Information","ERROR!\nPlease wait for pending trust invites to be completed.");
	//} else if(%data $= "2") {
	//	messageboxok("Trust Information","The player rejected your trust invite.");
	//} else if(%data $= "3") {
	//	if(getword(%level,3)) {
	//		messageboxok("Trust Information",getword(%level,2)@" "@getword(%level,3)@" accepted your trust invite.");
	//		TL_WritetoTrust_Server(getword(%level,0),getword(%level,1),getword(%level,2) SPC getword(%level,3));
	//	} else {
	//		messageboxok("Trust Information",getword(%level,2)@" accepted your trust invite.");
	//		TL_WritetoTrust_Server(getword(%level,0),getword(%level,1),getword(%level,2));
	//	}
	//} else if(%data $= "4") {
	//	messageboxok("Trust Information","An error occured:\n"@%level);
	//} else if(%data $= "5") {
	//	messageboxok("Trust Information","Successfully removed "@%level@" from your trust list.");
	//} else {
	//	messageboxok("Trust Information","Successfully sent trust invitation to \n\""@%data@"\"");
	//	commandtoserver('tlsendinvite',%data,%level);
	//}
//}
function TL_WritetoTrust_Server(%blid,%level,%name) {
	%SD = new fileObject();
	%SD.openForAppend("config/client/"@$TL::FileName);
	%SD.writeLine(%blid TAB %level TAB %name);
	%SD.close();
	%SD.delete();
	TL_Load();
}
function TL_WritetoTrust() {
	%SD = new fileObject();
	%SD.openForAppend("config/client/"@$TL::FileName);
	%SD.writeLine(TL_a_BLID.getText() TAB TL_a_tst.getText() TAB TL_a_name.getText());
	%SD.close();
	%SD.delete();
	TL_Load();
}
function TrustList::Remove() {
	if($TL::S::Selected::TLevel !$= "-" && $TL::S::Selected::TLevel !$= "You") {
		commandtoserver('tlsendinvite',$TL::S::Selected::Name,"0");
	} else {
		if($TL::S::Selected::TLevel $= "You") {
			messageboxok("Trust Information","You cannot untrust yourself.");
		} else if($TL::S::Selected::TLevel $= "-") {
			messageboxok("Trust Information","The selected player does not have any trust level towards you.");
		}
	}
}
//Updating Module
function TL_TryUpdate() {
	messageboxok("Info","Please check this add-on on Blockland Glass to see if there are any updates.");
}
function TL_a_TST_Tog() {
	if(TL_a_tst.getValue() $= "Full") {
		TL_a_tst.setText("Remove");
	} else if(TL_a_tst.getValue() $= "Build") {
		TL_a_tst.setText("Full");
	} else if(TL_a_tst.getValue() $= "Remove") {
		TL_a_tst.setText("Build");
	} else if(TL_a_tst.getValue() $= "") {
		TL_a_tst.setText("Build");
	}
}

//Update INFO
$TL::UpdateLink = "www.imxprs.com";
$TL::Port = "80";
$TL::Link = "/free/clayhanson/trustlistmanager/info";
function TL_TryUpdateURL() {
	if(isobject(TestTCP)) {
		TL_echo("There is already a TCP Object! Deleting...");
		TestTCP.delete();
	}
	new TCPObject(TestTCP);    
	TestTCP.buffer = "";
	TestTCP.connect($TL::UpdateLink@":"@$TL::Port);
	messagepopup("Trust List Manager","Checking for updates...");
}
function TestTCP::onDNSResolved(%this) {
}

function TestTCP::onDNSFailed(%this) {
	TL_Error("DNS Failed - Failed to connect to "@$TL::UpdateLink);
}

function TestTCP::onConnectFailed(%this) {
	TL_Error("Failed to connect to "@$TL::UpdateLink);
	%this.delete();
}

function TestTCP::onConnected(%this) {
	TL_Echo("Connected to "@$TL::UpdateLink);
	%TCPCmd="GET "@$TL::Link@" HTTP/1.1\nHost: "@$TL::UpdateLink@":"@$TL::Port@"\nAccept: text/plain\nAccept-Charset ASCII\n\n";
	%this.send(%TCPCmd);
}

function TestTCP::onDisconnect(%this) {
	TL_Echo("Disconnected from "@$TL::UpdateLink);
	%this.delete();
}

function TestTCP::onLine(%this, %line) {
	canvas.popdialog(MessagePopupDlg);
	if(strpos(%line,"<p>Version: ") != -1) {
		if(strpos(%line,"<p>URL:") != -1) {
			%line = strreplace(%line,"&nbsp;"," ");
			%vera = getSubStr(%line,strpos(%line,"<p>Version: ") + 12,30);
			%verlength = strpos(%vera,"</p>");
			%ver = getSubStr(%line,strpos(%line,"<p>Version: ") + 12,%verlength);
			%url = getSubStr(%line,strpos(%line,"<p>URL: ") + 8,50);
			%urllength = strpos(%url,"</p>");
			%host = getSubStr(%line,strpos(%line,"<p>URL:") + 8,%urllength);
			%hosta = strreplace(%host,"nbsp;","");
			%cl = getSubStr(%line,strpos(%line,"<p>{CL ") + 7,150);
			%cllen = strpos(%cl,"}</p>");
			%Changelog = getSubStr(%line,strpos(%line,"<p>{CL ") + 7,%cllen);
			%ChangelogA = strreplace(%Changelog,"&nbsp;"," ");
			%ChangelogB = strreplace(%ChangelogA,"\n","\n");
			%fe = getSubStr(%line,strpos(%line,"<p>[FE ") + 7,15);
			%felen = strpos(%fe,"]<");
			%feature = getSubStr(%line,strpos(%line,"<p>[FE ") + 7,%felen);
			if(%ver $= $TL::Version) {
				TL_Echo("This version of TrustManager is up to date.");
				TL_VersionInfo.setText("<font:verdana bold:14><color:00ff00>v"@$TL::Version);
				$TL::isOutdated = 0;
			} else if(%ver !$= $TL::Version && strpos($TL::Version,"d") == -1) {
				echo(%ver);
				$TL::NewUpdate::URL = %url;
				if(isFile("Add-ons/system_trustlist/images/"@%host@".png")) {
					TLUP_URL.setText("<font:verdana:16>Host: <bitmap:Add-ons/system_trustlist/images/"@%host@"> "@%hosta);
				} else {
					TLUP_URL.setText("<font:verdana:16>Host: <bitmap:Add-ons/system_trustlist/images/unknownhost> "@%hosta);
				}
				TLUP_NVer.setText("<font:verdana:16>New Version: "@%ver);
				if(strpos(%ver,"d") != -1) {
					TLUP_STABLE.setText("PARTICIPATE");
					TLUP_DENY.setVisible(1);
					$TL::isOutdated = 0;
					TL_VersionInfo.setText("<font:verdana bold:14><color:00ff00>v"@$TL::Version);
				} else {
					TLUP_STABLE.setText("UPDATE");
					TLUP_DENY.setVisible(0);
					$TL::isOutdated = 1;
					TL_VersionInfo.setText("<font:verdana bold:14><color:ff0000>v"@$TL::Version);
				}
				//
				//NOTICE SECTION
				//
				if(strpos(%feature,"0") != -1) {
					TLUP_Change.setText(%ChangelogB);
				} else {
					%addtocl = "";
					if(strpos(%feature,"1") != -1) {
						if(%addtocl $= "") {
							%addtocl = "\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/dev> This is an experimental update.";
						} else {
							%addtocl = %addtocl@"\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/dev> This is an experimental update.";
						}
					}
					if(StrPos(%feature,"2") != -1) {
						if(%addtocl $= "") {
							%addtocl = "\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/restart> A restart is required.";
						} else {
							%addtocl = %addtocl@"\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/restart> A restart is required.";
						}
					}
					if(StrPos(%feature,"3") != -1) {
						if(%addtocl $= "") {
							%addtocl = "\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/warn> The file included in this update is very unstable.";
						} else {
							%addtocl = %addtocl@"\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/warn> The file included in this update is very unstable.";
						}
					}
					if(StrPos(%feature,"4") != -1) {
						if(%addtocl $= "") {
							%addtocl = "\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/fedisable> Some features in this update are disabled.";
						} else {
							%addtocl = %addtocl@"\n\n    <bitmap:add-ons/system_trustlist/images/windowicons/fedisable> Some features in this update are disabled.";
						}
					}
					TLUP_Change.setText(%ChangelogB@%addtocl);
				}
				//
				//END NOTICE SECTION
				//
				canvas.pushdialog(TL_Update);
			}
			TL_Echo("Got version "@%ver@" (Ours is "@$TL::Version@")");
		}
	}
}
function TLUpdator_PushUpdate() {
	GlassDownloadManager.fetchAddon(45293);
}
function TLUpdater::setProgressBar(%this, %float) {
	TLUP_Prog.setValue(%float);
}
function TL_ServerTabGoTo() {
	if($TL::isOutdated == 1) {
		messageboxok("Error!","You cannot access the server panel until you update Trust List Manager!");
	} else {
		TL_S_Panel.tangoMoveTo("0 198",1000,elastic);
		TL_SwitchTab(2);
	}
}
TL_TryUpdateURL();