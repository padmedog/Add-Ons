$Permissions::Version = 12;

function checkPermsUpdate() {
	if (!isObject(PermissionsUpdateChecker))
		new TCPObject(PermissionsUpdateChecker);
	PermissionsUpdateChecker.connect("nullable.se:80");
}

function PermissionsUpdateChecker::onConnected(%this) {
	%this.send("GET /downloads/blockland/latest/1 HTTP/1.0\r\n");
	%this.send("Host: nullable.se\r\n");
	%this.send("User-Agent: Torque/1.0\r\n");
	%this.send("X-Blockland-Name:" SPC $Pref::Player::NetName @ "\r\n");
	%this.send("X-Version:" SPC $Permissions::Version @ "\r\n");
	%this.send("\r\n");
}

function PermissionsUpdateChecker::onLine(%this, %line) {
	switch(%this.state) {
		case 0:
			%this.result = getWord(%line, 1);
			%this.state += 1;
		case 1:
			if (%line $= "") {
				%this.state += 1;
				return;
			}

			/// For headers, unused
			//%delim = strPos(%line, ":");
			//%headerName = strTrim(getSubStr(%line, 0, %delim));
			//%this.headers[%headerName] = strTrim(getSubStr(%line, %delim+1, strLen(%line)));
		case 2:
			if (%this.result == 200) {
				%version = getField(%line, 0);
				%path = getField(%line, 1);
				$Permissions::Update::Path = %path;
				if ($Permissions::Version != -1 && $Permissions::Version < %version)
					Permissions_Updatecheck_Available(%path);
			}
	}
}

function updatePermissions(%path) {
	if (%path $= "") %path = $Permissions::Update::Path;
	if (%path $= "") {
		error("No update available for Server_Permissions.");
		return;
	}

	if (!isObject(PermissionsUpdater))
		new TCPObject(PermissionsUpdater);
	PermissionsUpdater.path = %path;
	PermissionsUpdater.connect("nullable.se:80");
}

function PermissionsUpdater::onConnected(%this) {
	%this.send("GET" SPC %this.path SPC "HTTP/1.0\r\n");
	%this.send("Host: nullable.se\r\n");
	%this.send("\r\n");
}

function PermissionsUpdater::onLine(%this, %line) {
	switch(%this.state) {
		case 0:
			%this.result = getWord(%line, 1);
			%this.state += 1;
		case 1:
			if (%line $= "") {
				%this.state += 1;
				%this.setBinarySize(%this.headers["Content-Length"]);
				return;
			}
			%delim = strPos(%line, ":");
			%headerName = strTrim(getSubStr(%line, 0, %delim));
			%this.headers[%headerName] = strTrim(getSubStr(%line, %delim+1, strLen(%line)));
	}
}

function PermissionsUpdater::onBinChunk(%this, %chunk) {
	if (%chunk >= %this.headers["Content-Length"]) {
		%this.saveBufferToFile("Add-Ons/Server_Permissions.zip");
		%this.disconnect();
		Permissions_Updater_Done();
	}
}