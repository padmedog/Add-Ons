$mRadio::Channels = 9;
$mRadio::useChannels = false;
datablock ItemData(mRadioItem)
{
   category = "Tools";
   className = "Weapon";
   shapeFile = "./mRadio.dts";
   uiName = "Radio";
   image = mRadioImage;
};
datablock ShapeBaseImageData(mRadioImage)
{
   className = "WeaponImage";
   projectileType = "Projectile";
   projectile = "";
   item = "mRadioItem";
   mountpoint = 0;
   shapefile = "./mRadio.dts";
   stateName[0] = "Activate";
   stateTimeoutValue[0] = "0";
   stateTransitionOnTimeout[0] = "Ready";   
   
   stateName[1] = "Ready";
   stateTimeoutValue[1] = 0;
   stateTransitionOnTriggerDown[1] = "Change";
   
   stateName[2] = "Change";
   stateTransitionOnTimeout[2] = "Check";
   stateScript[2] = "onRadioChange";
   stateTimeoutvalue[2] = 0.5;
   
   stateName[3] = "Check";
   stateSequence[3] = "Check";
   stateTransitionOnTriggerUp[3] = "Ready";
   stateSequence[3] = "Ready";
};
function mRadioImage::onRadioChange(%t,%o,%s)
{
   if($mRadio::useChannels)
   {
      %o.mRadioChannel = (mFloor(%o.mRadioChannel)+1) % ($mRadio::Channels+1);
      if(isObject(%o.client))
         %o.client.centerPrint("\c5Connected to channel\c3 "@%o.mRadioChannel,3);
   }
}
function mRadioImage::onMount(%t,%o,%s)
{
   Parent::onMount(%t,%o,%s);
   %o.mRadioOn = true;
   if($mRadio::useChannels)
   {
      %o.mRadioChannel = mFloor(%o.mRadioChannel);
      if(isObject(%o.client))
         %o.client.centerPrint("\c5Connected to channel\c3 "@%o.mRadioChannel,3);
   }
   %o.playThread(0,"armReadyRight");
}
function mRadioImage::onUnMount(%t,%o,%s)
{
   Parent::onUnMount(%t,%o,%s);
   %o.mRadioOn = false;
   if($mRadio::useChannels)
   {
      %o.mRadioChannel = mFloor(%o.mRadioChannel);
      if(isObject(%o.client))
         %o.client.centerPrint("\c5Disconnected from channel\c3 "@%o.mRadioChannel,3);
   }
   %o.playThread(0, "root");
}
function servercmdmRadioChannel(%cl)
{
   if(!%cl.isSuperAdmin)
      return;
   $mRadio::useChannels = !$mRadio::useChannels;
   if($mRadio::useChannels)
      announce("Radios now use channels");
   else
      announce("Radios no longer use channels");
}
package mRadioPackage
{
	function ServerCmdTeamMessageSent(%client, %message)
	{
	   if($mRadio::useChannels)
	   {
         if(isObject(%client.player))
         {
            if(!%client.player.mRadioOn)
               Parent::ServerCmdTeamMessageSent(%client, %message);
            else
            {
               for(%i = 0; %i < clientGroup.getCount(); %i++)
               {
                  %cl = clientGroup.getObject(%i);
                  if(isObject(%cl.player))
                     if(%cl.player.mRadioChannel $= %client.player.mRadioChannel && %cl.player.mRadioOn) 
                     {
                        MessageClient(%cl, '',"\c4[Radio "@%client.player.mRadioChannel@"]\c3"@%client.name@"\c6: " @ %message);
                        %playersHeard++;
                     }
               }
               if(%playersHeard < 2) messageclient(%client, '', "\c7No one heard you.");
            }
         }
         else
            Parent::ServerCmdTeamMessageSent(%client, %message);
	   }
	   else
	   {
	      if(isObject(%client.player))
         {
            if(!%client.player.mRadioOn)
               return;
            else
            {
               for(%i = 0; %i < clientGroup.getCount(); %i++)
               {
                  %cl = clientGroup.getObject(%i);
                  if(isObject(%cl.player))
                     if(%cl.player.mRadioOn) 
                     {
                        MessageClient(%cl, '',"\c4[Radio]\c3"@%client.name@"\c6: " @ %message);
                        %playersHeard++;
                     }
               }
               if(%playersHeard < 2) messageclient(%client, '', "\c7No one heard you.");
            }
         }
	   }
	}
};
activatePackage(mRadioPackage);