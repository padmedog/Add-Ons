// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

Slayer.Prefs.addNonNetworkedPref("Bricks","Create Team Bot Holes","$Slayer::Server::Preload::Bricks::CreateTeamBotHoles","bool",1);
Slayer.Prefs.addNonNetworkedPref("Bricks","Organization","$Slayer::Server::Preload::Bricks::CreateSlayerTab","bool",1);

if($Slayer::Server::Preload::Bricks::CreateSlayerTab)
{
	$Slayer::Server::Bricks::Category = "Slayer";
	$Slayer::Server::Bricks::SubCategory = "";
}
else
{
	$Slayer::Server::Bricks::Category = "Special";
	$Slayer::Server::Bricks::SubCategory = "Slayer - ";
}


if($Slayer::Server::DatablocksLoaded)
	return;

$Slayer::Server::DatablocksLoaded = true;

datablock TriggerData(Slayer_CPTriggerData)
{
	tickPeriodMS = 150;
};

datablock TriggerData(Slayer_NodeTriggerData)
{
	tickPeriodMS = 1000;
};

datablock fxDtsBrickData(brickSlyrSpawnPointData : brickSpawnPointData)
{
	uiName = "Team Spawn Point";
	category = $Slayer::Server::Bricks::Category;
	subCategory = $Slayer::Server::Bricks::SubCategory @ "General";

	isSlyrBrick = 1;
	slyrType = "TeamSpawn";
	setOnceOnly = 0;
};

datablock fxDtsBrickData(brickSlyrVehicleSpawnData : brickVehicleSpawnData)
{
	uiName = "Team Vehicle Spawn";
	category = $Slayer::Server::Bricks::Category;
	subCategory = $Slayer::Server::Bricks::SubCategory @ "General";

	isSlyrBrick = 1;
	slyrType = "TeamVehicle";
	setOnceOnly = 0;
};

datablock fxDtsBrickData(brickSlyrCPData : brick8x8FData)
{
	uiName = "8x8 Capture Point";
	category = $Slayer::Server::Bricks::Category;
	subCategory = $Slayer::Server::Bricks::SubCategory @ "General";
	indestructable = 1;

	isSlyrBrick = 1;
	slyrType = "CP";
	setOnceOnly = 1;
	CPMaxTicks = 40;
};

datablock fxDtsBrickData(brickSlyrLrgCPData : brick16x16FData)
{
	uiName = "16x16 Capture Point";
	category = $Slayer::Server::Bricks::Category;
	subCategory = $Slayer::Server::Bricks::SubCategory @ "General";
	indestructable = 1;

	isSlyrBrick = 1;
	slyrType = "CP";
	setOnceOnly = 1;
	CPMaxTicks = 66;
};

datablock fxDtsBrickData(brickSlyrBotPathNodeData)
{
	uiName = "Path Node";
	category = $Slayer::Server::Bricks::Category;
	subCategory = $Slayer::Server::Bricks::SubCategory @ "Bot Holes";
	brickFile = $Slayer::Server::Path @ "/resources/shapes/brickSlyrBotPathNode.blb";
	indestructable = 1;

	isSlyrBrick = 1;
	slyrType = "BotPathNode";
	setOnceOnly = 1;
};

datablock fxDtsBrickData(brickSlyrBotRallyNodeData : brickSlyrBotPathNodeData)
{
	isRallyNode = true;
	uiName = "Rally Point";
};

function Slayer_loadHoleBotDatablocks()
{
	%count = datablockGroup.getCount();
	for(%i = 0; %i < %count; %i ++)
	{
		%db = datablockGroup.getObject(%i);
		if(%db.isBotHole && !%db.isSlyrBrick)
		{
			%dbName = %db.getName();
			%db.setName("Slayer_BotHole");
			datablock fxDtsBrickData(Slayer_TeamBotHole : Slayer_BotHole)
			{
				category = $Slayer::Server::Bricks::Category;
				subCategory = $Slayer::Server::Bricks::SubCategory @ "Bot Holes";
				uiName = "Team" SPC %db.uiName;

				isSlyrBrick = 1;
				slyrType = "TeamBotHole";
				setOnceOnly = 0;
			};
			Slayer_TeamBotHole.setName("Slayer_Team" @ %dbName);
			%db.setName(%dbName);
		}
	}

	$Slayer::Server::Bricks::HoleBotDatablocksLoaded = 1;
}
//if($Slayer::Server::Preload::Bricks::CreateTeamBotHoles)
//	scheduleNoQuota(0,0,"Slayer_loadHoleBotDatablocks");

Slayer_Support::Debug(2,"Datablocks Loaded","Main");