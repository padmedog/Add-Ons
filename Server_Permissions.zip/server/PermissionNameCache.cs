function PermissionNameCache::getNameForBL_ID(%this, %blid) {
	%this.load();

	if ((%ref = %this.refLookup[%blid]) !$= "")
		return %this.nameByRef[%ref];
}

function PermissionNameCache::add(%this, %blid, %name) {
	%this.load();

	if ((%ref = %this.refLookup[%blid]) $= "") {
		%ref = %this.count;
		%this.count++;
		%this.refLookup[%blid] = %ref;
	}

	%this.blidByRef[%ref] = %blid;
	%this.nameByRef[%ref] = %name;
}

function PermissionNameCache::load(%this) {
	if (%this.loaded)
		return;

	%path = $Permissions::Config::PathBase @ "namecache.txt";

	%this.count = 0;
	%this.loaded = true;

	if (isFile(%path)) {
		%fo = new FileObject();
		%fo.openForRead(%path);
		while (!%fo.isEOF()) {
			%line = %fo.readLine();
			%sepPos = strPos(%line, "=");
	        if (%sepPos == -1) {
	            error("Malformed data for name cache file, culprit line:" SPC %line);
	            continue;
	        }
	        %blid = getSubStr(%line, 0, %sepPos);
	        %name = getSubStr(%line, %sepPos + 1, strLen(%line));
	        %this.add(%blid, %name);
		}
		%fo.close();
		%fo.delete();
	}
}

function PermissionNameCache::doSave(%this) {
	if (!%this.loaded)
		return;

	%fo = new FileObject();
	%fo.openForWrite($Permissions::Config::PathBase @ "namecache.txt");
	for (%i = 0 ; %i < %this.count ; %i++) {
		%blid = %this.blidByRef[%i];
		%name = %this.nameByRef[%i];
		%fo.writeLine(%blid @ "=" @ %name);
	}
	%fo.close();
	%fo.delete();
}