 datablock PlayerData(RotSlowZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;
	maxDamage = 150;
	runforce = 100 * 90;
	maxForwardSpeed = 4;
	maxBackwardSpeed = 4;
	maxSideSpeed = 4;
	attackpower = 15;
	jumpsound = "ZombieJumpSound";
	
	BrickDestroyMaxVolume = 250;
	BrickMaxJumpHeight = 20;
	uiName = "Zombie Slow";
	rideable = true;
	canRide = true;
	BrickKillRadius = 2;
	skinColor = "0.29 0.43 0.29 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
};
function RotSlowZombie::ondisabled(%this,%obj)
{
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotSlowZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotSlowZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotSlowZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotSlowZombie::onAdd(%this,%obj)
{
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
}