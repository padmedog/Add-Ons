//########## Burn Statuseffect

//### Sounds

datablock AudioProfile(gc_fireSound)
{
  filename = "./flame.wav";
  description = AudioClosestLooping3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_burningParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = -1;
  inheritedVelFactor = 0.5;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.2 0.2 0.6 0.1";
  colors[1] = "1 0.5 0 1";
  colors[2] = "1 0 0 0";
  sizes[0] = 0;
  sizes[1] = 1;
  sizes[2] = 0.5;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_burningEmitter)
{
  uiName = "";
  ejectionPeriodMS = 5;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0; 
  ejectionOffset = 0.7;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_burningParticle";
};

datablock ShapeBaseImageData(gc_burningImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 7;

  stateName[0] = "Fire";
  stateTransitionOnTimeout[0] = "End";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 3;
  stateEmitter[0] = gc_burningEmitter;
  stateEmitterTime[0] = 3;
  stateSound[0] = gc_fireSound;

  stateName[1] ="End";
  stateScript[1] = "onEnd";
};
function gc_burningImage::onEnd(%this,%obj,%slot) { %obj.unMountImage(%slot); }

AddDamageType("gc_burning",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_burn> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_burn> %1',0.2,1);

function gc_burning(%obj,%duration,%source,%stay)
{
  if(!isObject(%obj)) return 0;
  cancel(%obj.gc_burning);
  // Check if its a player or a turret
  if(%obj.dataBlock.maxForwardSpeed == 0 && %obj.dataBlock.maxBackwardSpeed == 0 && %obj.dataBlock.maxSideSpeed == 0 && %obj.dataBlock.PainLowImage $= "") return 0;
  if(%duration < 1) { if(isObject(%obj.getMountedImage(3)) && %obj.getMountedImage(3).getName() $= "gc_burningImage") { %obj.unmountImage(3); } return 0; }
  if(!%stay && %obj.getwatercoverage() > 0.4) { if(isObject(%obj.getMountedImage(3)) && %obj.getMountedImage(3).getName() $= "gc_burningImage") { %obj.unmountImage(3); } return 0; }
  %duration--;
  %obj.damage(%source,%obj.getPosition(),5,$DamageType::gc_burning);
  %obj.gc_burning = schedule(1000,0,gc_burning,%obj,%duration);
  if(isObject(%obj.getMountedImage(3)) && %obj.getMountedImage(3).getName() !$= "gc_burningImage") { %obj.unmountImage(3); %obj.mountImage(gc_burningImage,3); }
  else
    { %obj.unmountImage(3); %obj.mountImage(gc_burningImage,3); }
}
