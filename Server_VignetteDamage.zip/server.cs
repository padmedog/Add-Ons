// Type deactivatePackage(vignetteDamagePackage); in console to disable this while running a server.

package vignetteDamagePackage
{
	function player::setDamageFlash( %this, %value )
	{
		if ( !isObject( %cl = %this.getControllingClient() ) )
		{
			return;
		}

		if ( %value < 0 )
		{
			%value = 0;
		}

		if ( %value > 1 )
		{
			%value = 1;
		}

		%cl.fadeOutVignetteDamage( %value );
	}
};

activatePackage( "vignetteDamagePackage" );

function gameConnection::fadeOutVignetteDamage( %this, %value )
{
	cancel( %this.fadeOutVignetteDamage );

	if ( %value < 0 )
	{
		commandToClient( %this, 'SetVignette', $EnvGuiServer::VignetteMultiply, $EnvGuiServer::VignetteColor );
		return;
	}

	commandToClient( %this, 'SetVignette', false, "1 0 0" SPC %value );
	%this.fadeOutVignetteDamage = %this.schedule( 50, "fadeOutVignetteDamage", %value - 0.02 );
}