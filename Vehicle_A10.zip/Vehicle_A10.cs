
datablock ProjectileData(A10CannonFireProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   muzzleVelocity      = 120;
   particleEmitter     = A10CannonEmitter;
   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 0;

   armingDelay         = 0;
   lifetime            = 100;
};
datablock ProjectileData(A10flareProjectile)
{
   projectileShapeName = "";
   directDamage        = 0;

   explosion           = "";
   particleEmitter     = A10FlareEmitter;
	muzzleVelocity      = 100;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 0;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 1 1";


};
AddDamageType("A10Cannon",   '<color:FFFF00>[A-10 GAU/8 Minigun]<color:FF0000> %1',    '%2 <color:FFFF00>[A-10 GAU/8 Minigun]<color:FF0000> %1',0.2,1);
datablock ProjectileData(A10CannonProjectile)
{
   projectileShapeName = "";
   directDamage        = 70;

   directDamageType    = $DamageType::A10cannon;
   radiusDamageType    = $DamageType::A10cannon;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = Gunexplosion;
   particleEmitter     = A10tracerTrailEmitter;

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 1000;
   fadeDelay           = 500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";


};
datablock ExplosionData(A10RocketExplosion)
{
   //explosionShape = "";
   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";
	soundProfile = rocketExplodeSound;

   lifeTimeMS = 150;

   particleEmitter = rocketExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = rocketExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 20;
   lightStartColor = "1 1 1 1";
   lightEndColor = "0 0 0 0";

   damageRadius = 20;
   radiusDamage = 220;

   impulseRadius = 6;
   impulseForce = 4000;
};
AddDamageType("A10Rocket",   '<color:FFFF00>[A-10 Rocket Pod]<color:FF0000> %1',    '%2 <color:FFFF00>[A-10 Rocket Pod]<color:FF0000> %1',0.2,1);
datablock ProjectileData(RocketPodProjectile)
{
    projectileShapeName = "./Shapes/rocketpodmissile.dts";
   directDamage        = 70;
   directDamageType = $DamageType::A10Rocket;
   radiusDamageType = $DamageType::A10Rocket;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = A10RocketExplosion;
   particleEmitter     = A10MissileABEmitter;

   brickExplosionRadius = 30;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = rocketLoopSound;

   muzzleVelocity      = 20;
   velInheritFactor    = 0.0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

};
datablock WheeledVehicleTire(A10Tire)
{
	shapeFile = "add-ons/item_skis/emptywheel.dts";

	mass = 10;
	radius = 3;
	staticFriction = 5;
	kineticFriction = 5;
	restitution = 0.5;	

	// Spring that generates lateral tire forces
	lateralForce = 18000;
	lateralDamping = 4000;
	lateralRelaxation = 0.01;

	// Spring that generates longitudinal tire forces
	longitudinalForce = 14000;
	longitudinalDamping = 2000;
	longitudinalRelaxation = 0.01;
};
datablock WheeledVehicleSpring(A10Spring)
{
   // Wheel suspension properties
   length = 1;        // Suspension trave 0.2
   force = 10000;        // Spring force
   damping = 5000;      // Spring damping
   antiSwayForce =0;   // Lateral anti-sway force
};

datablock WheeledVehicleTire(A10fakeTire)
{
   shapeFile = "";
	
	mass = 0;
   radius = 0;
   staticFriction = 0;
   kineticFriction = 0;
   restitution = 0.0;	

   // Spring that generates lateral tire forces
   lateralForce = 10;
   lateralDamping = 10;
   lateralRelaxation = 0.01;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 10;
   longitudinalDamping = 10;
   longitudinalRelaxation = 0.01;
};
datablock WheeledVehicleSpring(A10fakeSpring)
{
   length = -20.2;        // Suspension trave 0.2
   force = 10;        // Spring force
   damping = 10;      // Spring damping
   antiSwayForce = 1.1;   // Lateral anti-sway force
};

//Frozen propeller

datablock ShapeBaseImageData(A10EngineImage)
{
    shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 2;
   rotation = "1 0 0 0";
   
   	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "FireB";
	stateWaitForTimeout[1]			= true;
	statesound[1]					= A10StartSound;
	stateTimeoutValue[1]			= 7.9;
	
	
	stateName[2]					= "FireB";
	stateTransitionOnTimeout[2]		= "FireC";
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= A10AmbSound;
	stateTimeoutValue[2]			= 1.9;
	
	stateName[3]					= "FireC";
	stateTransitionOnTimeout[3]		= "FireB";
	stateSound[3]					= A10AmbSound;
	stateWaitForTimeout[3]			= true;
	stateTimeoutValue[3]			= 1.9;
};

datablock WheeledVehicleData(A10Vehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./shapes/A10.dts"; //"~/data/shapes/skivehicle.dts"; //
	emap = true;
	minMountDist = 3;
   
    numMountPoints = 1;
    mountThread[0] = "sit";



	
	maxDamage = 200.00;
	destroyedLevel =  300.00;
	extradamagethreshold = 200;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 1 0";


	maxSteeringAngle = 0.9;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 33;         // Far distance from vehicle
	cameraOffset = 4.5;        // Vertical offset from camera mount point
	cameraLag = 1.0;           // Velocity lag of camera
	cameraDecay = 0.5;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.0;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

	defaultTire	  = A10Tire;
	defaultSpring = A10Spring;
	//flatTire	     = jeepFlatTire;
	//flatSpring	  = jeepFlatSpring;

   numWheels = 3;

	// Rigid Body
	mass = 200;
	density = 5.0;
	drag = 0.2;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 20;       // Play SoftImpact Sound
	hardImpactSpeed = 35;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 0; //4000;       // Engine power
	engineBrake = 200;         // Braking when throttle is 050
	brakeTorque = 2000;        // When brakes are applied
	maxWheelSpeed = 60;        // Engine scale by current speed / max speed




	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

   isSled = false;

   forwardThrust		= 7000;
	reverseThrust		= 2000;
	lift			= 35;
	maxForwardVel		= 80;
	maxReverseVel		= 80;//2
	horizontalSurfaceForce	= 200;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 200; 

	rollForce		= 40500;
	yawForce		= 10000;
	pitchForce		=20000;
	rotationalDrag		= 2;
	stallSpeed		= 30;
	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
	burntime=10000;
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";

	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

	uiName = "A-10 Thunderbolt II";
	rideable = true;
		lookUpLimit = 0.5;
		lookDownLimit = 0.5;

	paintable = true;

	damageEmitter[0] = A10DamageEmitter;
	damageEmitterOffset[0] = "0.0 -3.0 0.0 ";
	damageLevelTolerance[0] = 0.50;

	damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "6.0 0.0 0.0 ";
	damageLevelTolerance[1] = 0.99;

	numDmgEmitterAreas = 1;

	initialExplosionProjectile = "";
	initialExplosionOffset = 0;         //offset only uses a z value for now


	finalExplosionProjectile = A10finalExplosionProjectile1;
	finalExplosionOffset = 0;          //offset only uses a z value for now


	minRunOverSpeed    = 2;   //how fast you need to be going to run someone over (do damage)
	runOverDamageScale = 5;   //when you run over someone, speed * runoverdamagescale = damage amt
	runOverPushScale   = 1.2; //how hard a person you're running over gets pushed

	steeringUseStrafeSteering = false; //this vehicle has pitch control, so we can't use strafe steering

	minContrailSpeed = 50;
	mincollisionSpeed = 20;
	tempRegenTime = 150; // ms that it takes to regenerate a shot of missiles, yeah!
    maxtemp = 100; // Total missiles that can be held
	
   	A10ShootOnClick=1;
	A10ShootOnClick_Hold[0]=1;
	A10ShootOnClick_Alternate[0]=false;
	A10ShootOnClick_ShootDelay[0]=30;
	A10ShootOnClick_ReShootDelay[0]=30;
	A10ShootOnClick_RequiredSlot[0]=0;
	A10ShootOnClick_ProjectileCount[0] = 1;
	A10ShootOnClick_Projectile[0,0]=A10cannonprojectile;
	A10ShootOnClick_FlashProjectile[0,0] =A10CannonFireProjectile;
	A10ShootOnClick_fireSound[0]=gunshot1sound;
	A10ShootOnClick_Position[0,0]="15 0 -0.4";//4
	A10ShootOnClick_Velocity[0,0]="500 0 5";
	A10ShootOnClick_Scale[0,0]="2 2 2";
	A10ShootOnClick_FlashVelocity[0,0]="10 0 -10";
	A10ShootOnClick_Spread[0,0]=0.0002;
	A10ShootOnClick_ReqLock[0]=0;
	
	A10ShootOnClick_Hold[1]=1;
	A10ShootOnClick_Alternate[1]=true;
	A10ShootOnClick_ShootDelay[1]=150;
	A10ShootOnClick_ReShootDelay[1]=150;
	A10ShootOnClick_RequiredSlot[1]=0;
	A10ShootOnClick_ProjectileCount[1] = 1;
	A10ShootOnClick_Ammo[1]=12;
	A10ShootOnClick_ReloadTime[1]=5000;
	A10ShootOnClick_fireSound[1]=A10Rocketfiresound;
	A10ShootOnClick_Projectile[0,1]=RocketPodProjectile;
	A10ShootOnClick_FlashProjectile[0,1] =A10CannonFireProjectile;
	A10ShootOnClick_Position[0,1]="-3 5.5 -1";//4
	A10ShootOnClick_PositionB[0,1]="-3 -5.5 -1";//4
	A10ShootOnClick_Velocity[0,1]="500 -8 5";
	A10ShootOnClick_VelocityB[0,1]="500 8 5";
	A10ShootOnClick_Scale[0,1]="0.7 0.7 0.7";
	A10ShootOnClick_FlashVelocity[0,1]="10 0 -10";
	A10ShootOnClick_Spread[0,1]=0.0001;

	
	A10ShootOnClick_Hold[2]=0;//TV MIssile
	A10ShootOnClick_Alternate[2]=true;
	A10ShootOnClick_ShootDelay[2]=1500;
	A10ShootOnClick_ReShootDelay[2]=1500;
	A10ShootOnClick_RequiredSlot[2]=0;
	A10ShootOnClick_ProjectileCount[2] = 1;
	A10ShootOnClick_fireSound[2]=A10Rocketfiresound;
	A10ShootOnClick_Projectile[0,2]="";
	A10ShootOnClick_FlashProjectile[0,2] ="";
	A10ShootOnClick_Position[0,2]="-1 3.5 -3";//4
	A10ShootOnClick_PositionB[0,2]="-1 -3.5 -3";//4
	A10ShootOnClick_Velocity[0,2]="500 0 5";
	A10ShootOnClick_Scale[0,2]=".2 1 .2";
	A10ShootOnClick_FlashVelocity[0,2]="10 0 -10";
	A10ShootOnClick_Spread[0,2]=0.0002;
	
	//flares
	A10ShootOnClick_Hold[3]=0;
	A10ShootOnClick_Raycast[3]=0;
	A10ShootOnClick_ShootDelay[3]=40;
	A10ShootOnClick_ReShootDelay[3]=40;
	A10ShootOnClick_RequiredSlot[3]=0;
	A10ShootOnClick_ProjectileCount[3] = 3;
	A10ShootOnClick_fireSound[3]=A10flarefiresound;
	A10ShootOnClick_ReqLock[3]=0;
	
	A10ShootOnClick_Projectile[0,3]=A10FlareProjectile;
	A10ShootOnClick_FlashProjectile[0,3] = "";
	A10ShootOnClick_Position[0,3]="0 0 -2";//4
	A10ShootOnClick_Velocity[0,3]="bomb 20 -10";
	A10ShootOnClick_Scale[0,3]="1 1 1";
	A10ShootOnClick_FlashVelocity[0,3]="0 0 0";
	A10ShootOnClick_Spread[0,3]=0.000001;
	
	A10ShootOnClick_Projectile[1,3]=A10FlareProjectile;
	A10ShootOnClick_FlashProjectile[1,3] = "";
	A10ShootOnClick_Position[1,3]="0 0 -2";//4
	A10ShootOnClick_Velocity[1,3]="bomb 0 -10";
	A10ShootOnClick_Scale[1,3]="1 1 1";
	A10ShootOnClick_FlashVelocity[1,3]="0 0 0";
	A10ShootOnClick_Spread[1,3]=0.000001;
	
	A10ShootOnClick_Projectile[2,3]=A10FlareProjectile;
	A10ShootOnClick_FlashProjectile[2,3] = "";
	A10ShootOnClick_Position[2,3]="0 0 -2";//4
	A10ShootOnClick_Velocity[2,3]="bomb -20 -10";
	A10ShootOnClick_Scale[2,3]="1 1 1";
	A10ShootOnClick_FlashVelocity[2,3]="0 0 0";
	A10ShootOnClick_Spread[2,3]=0.000001;
	
	


};

function A10vehicle::onAdd(%this,%obj)
{	
	%obj.ammo[1]=%this.A10ShootOnClick_Ammo[1];
	%obj.left=true;
	%obj.temp = A10Vehicle.maxtemp;
	%obj.brake=false;

   for(%i = 0; %i < %this.numWheels; %i++)
   {
      %obj.setWheelTire(%i, %this.defaultTire);
      %obj.setWheelSpring(%i, %this.defaultSpring);
   }


	%obj.mountimage(A10PropellerF, 2);
	%obj.A10gear = 2;
	%obj.weapon="GAU-8/A Minigun";
	
	%obj.weaponi=0;
   
     %obj.hitcounter=0;
	
	
	%t = new AIPlayer()
	{
		dataBlock = A10minigunturretplayer;
	};
	%obj.mountObject(%t, 1);
	%obj.turret = %t;
	MissionCleanup.add(%t);
	A10SpeedCheck(%this, %obj);
	
	
}

function A10Vehicle::onRemove(%this,%obj)
{
	if(isobject(%obj.turret))
		%obj.turret.delete();
}
function A10SpeedCheck(%this, %obj)
{	

	if(!isObject(%obj))
		return;
	%vehicle = %obj;
	
	%speed = vectorLen(%obj.getVelocity());
	%obj.speed = %speed;
	//%speed = %obj.getControlObjectSpeed();
	%transform= %obj.gettransform();
	switch (%obj.A10gear)
		{
		case 1:
			%geart = "Up";
			%stat = "<color:00FF00>";
			%statnum = 1;
		case 2:
			%geart = "Down";
			%stat = "<color:FF0000>";
			%statnum = 0;
		 default:
			%geart = "Down";
			%stat = "<color:FF0000>";
			%statnum = 0;
		}
	
	//A10 HUD
	commandToClient(%obj.getMountedObject(0).client,'bottomprint',
	"<just:left><font:Impact:24pt>\c3Speed <font:Impact:24pt>\c6: " @mFloor(%speed+0.5) @
	"<just:right><font:Impact:24pt>\c3[ L ] Gears <font:Impact:24pt>\c6: " @ %geart @
	"<just:center><font:Impact:24pt>\c3[ > ] Armament <font:Impact:24pt>\c6: " @ %stat @ " " @ %obj.weapon , 1, 2, 3, 4);

	commandToclient(%obj.getMountedObject(0).client,'centerprint',"<just:left><font:Impact:24pt>" @ %obj.lockstat @ 
	"<just:center><font:Impact:24pt>" @ %obj.ECM @ 
	"<just:right><font:Impact:24pt>\c3Health\c6: " @ -1*((%obj.getDamageLevel()/%this.maxdamage)*100)+100 @ "%" @
	"\n\n\n\n<just:center>[          ]",1,2,3,4);
	// @ -1*((%obj.getDamageLevel()/%this.maxdamage)*100)+100 @ "%"
	//A10 after burners

	%pos = %obj.getposition();

	if(%obj.islocked==true)
	{
		serverPlay3d(A10targetSound,%pos);
		%obj.ECM="<color:f00000>[ WARNING : LOCKED ]";
	}
	else
		%obj.ECM="";
		
	if(%obj.missilefired==true)
	{
			if(!isobject(%obj.missile))
			{
			//echo("true");
			%obj.mountobject(%obj.getmountedobject(0),0);
			%obj.getmountedobject(0).setcontrolobject(%obj);
			%obj.missilefired=false;
			}
			//%mpos = %obj.missile.getposition();
			//echo(msqrt((mpow(getword(%pos,0)-getword(%mpos,0),2) + mpow(getword(%pos,1)-getword(%mpos,1),2) + mpow(getword(%pos,2)-getword(%mpos,2),2))));
	}


	if(%obj.brake==true)
	{
		if (mFloor(%speed+0.5) > %this.maxforwardvel-30)
			%obj.setVelocity(vectorScale(%obj.getVelocity(),0.80));
		else if (mFloor(%speed+0.5) < %this.stallspeed)
			%obj.setVelocity(vectorScale(%obj.getVelocity(),1.01));

	}

		
	schedule(500,0,"A10SpeedCheck",%this,%obj);
}
function A10Vehicle::onTrigger(%this,%obj,%trigNum,%val)
{
	
	//echo(%trigNum SPC %val);
	
	if(%val)
	{
		%obj.setVelocity(vectorScale(%obj.getVelocity(),0.99));
		%obj.playthread(1,flapopen);
		%obj.brake=true;
	}
	else
	{
		%obj.unmountimage(0);
		%obj.playthread(1,flapclose);
		%obj.brake=false;
	}
	
}
function A10vehicle::onDriverLeave(%this,%obj)
{
	%obj.unmountimage(2);

		
}
package A10
{
	function armor::onMount(%this,%obj,%col,%slot)
	{
		Parent::onMount(%this,%obj,%col,%slot);
		if(%col.getDataBlock() == A10Vehicle.getId() && %slot==0)
		{
			%col.unmountimage(0);
			%col.mountimage(A10EngineImage, 2);
			
		}

	}
	function servercmdLight(%client)
	{

	
		%p = %client.player;
		if(!isobject(%p.getobjectmount()))
			return Parent::servercmdLight(%client);

		

		if(%p.getobjectmount().getdatablock() == A10vehicle.getid())
		{
			if($Sim::Time<%client.delay)
			{
				return;
			}
			%obj = %p.getobjectmount().getid();
			%client=%client;
			switch (%obj.A10gear)
			{
				case 1:
				
					for(%i = 0; %i < A10vehicle.numWheels; %i++)
					{
						%obj.schedule(1400,setWheelTire,%i, A10tire);
						%obj.schedule(1400,setWheelspring,%i, A10spring);
					}
					%obj.playThread(0,"geardown");
						
					%obj.A10gear = 2;
				case 2:
				for(%i = 0; %i < A10vehicle.numWheels; %i++)
				{
					%obj.setWheelTire(%i, A10faketire);
					%obj.setWheelSpring(%i, A10fakespring);
				}
				%obj.playThread(0,"gearup");
			
				%obj.A10gear = 1;
				default:
				for(%i = 0; %i < A10vehicle.numWheels; %i++)
				{
				
					%obj.setWheelTire(%i, A10faketire);
					%obj.setWheelSpring(%i, A10fakespring);
				}
				%obj.playThread(0,"gearup");
				
				%obj.A10gear = 1;
			}
			%client.delay=$Sim::Time+2000/1000;
		}
		else
		Parent::servercmdLight(%client);
							
			
	}


 
   		

	
};
activatePackage(A10);

function A10Vehicle::onImpact(%this,%obj,%data)
{
	%speed = vectorLen(%obj.getVelocity());
	//echo(%obj.speed);
	//Lets the pilot have an easy landing
	if(%obj.a10gear == 2)
		%obj.speedlimit = 50;
	else
		%obj.speedlimit = 5;
	
	if(%obj.speed > %obj.speedlimit )
	{
		if(%obj.destroyed)
            return;
		%obj.setDamageLevel(0);
		%obj.destroyed = 1;
		//final explosion gets the host as the last killer so I have to make my own

		%trans = %obj.getTransform();
		%p = new Projectile()
		{
			dataBlock = A10finalExplosionProjectile1;
			initialVelocity  = "0 0 0";
			initialPosition  = %trans;
			 client = %obj.lastDamageClient;
               sourceClient = %obj.lastDamageClient;
			scale = "3 3 3";
		};
		MissionCleanup.add(%p);

		%obj.target.islocked=false;
		%obj.schedule(10,"delete");
		if(isObject(%obj.spawnBrick.client.minigame))
			%respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
		%obj.spawnBrick.schedule(%respawn+1000,"spawnVehicle");
	}
	else if(%obj.speed < %obj.speedlimit)
	{
	%obj.applydamage(10);
	}
	
}

function A10Vehicle::Damage(%this,%obj,%source,%pos,%amm,%type)
   {
	if((%obj.getDamageLevel()) == %this.maxDamage)
      {
	  //if sustained an extra extradamagethreshold damage when burning then instantly destroy it
		if(%obj.hitcounter>=100)
		{
			if(%obj.fdestroyed)
            return;
		
			%trans = %obj.getTransform();
			%p = new Projectile()
			{
				dataBlock = A10finalExplosionProjectile1;
				initialVelocity  = "0 0 0";
				initialPosition  = %trans;
				 client = %obj.lastDamageClient;
               sourceClient = %obj.lastDamageClient;
				scale = "3 3 3";
			};
			MissionCleanup.add(%p);
			%obj.fdestroyed = 1;
			%obj.target.islocked=false;
			%obj.schedule(10,"delete");
			if(isObject(%obj.spawnBrick.client.minigame))
				%respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
			%obj.spawnBrick.schedule(%respawn+1000,"spawnVehicle");
		}
		else
			%obj.hitcounter=%obj.hitcounter+%amm;
      }
      else
     Parent::Damage(%this,%obj,%source,%pos,%amm,%type);
}
function A10finalExplosionProjectile1::onExplode(%this,%obj)
{
		%trans = %obj.getTransform();
  		for(%i=2;%i<=4;%i++)
		{
			%p[%i] = new Projectile()
			{
				dataBlock = "A10finalExplosionProjectile" @ %i;
				initialVelocity  = "0 0 0";
				initialPosition  = %trans;
				sourceObject     = %obj;
				sourceSlot       = 0;
				client           = %obj.client;
				scale = "1.3 1.3 1.3";
			};
			MissionCleanup.add(%p[%i]);
		}  

}

