exec("./support/timeBomb.cs");

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
	{
		if(isFile("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs"))
			exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");
		else
			exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	}
	
	RTB_registerPref("File name","Auto Saver","$AutoSaver::SaveFile","string 255","Server_AutoSaver","autosave,0);
	RTB_registerPref("Save every","Auto Saver","$AutoSaver::SaveTime","int 1 1440","Server_AutoSaver",10,0,0,AutoSaver_adjustTime);
	RTB_registerPref("Save ownership","Auto Saver","$AutoSaver::SaveOwnership","bool","Server_AutoSaver",1,0,0);
	RTB_registerPref("Save events","Auto Saver","$AutoSaver::SaveEvents","bool","Server_AutoSaver",1,0,0);
}
//else
{
	$AutoSaver::SaveFile = "autosave";
	$AutoSaver::SaveTime = 30;
	$AutoSaver::SaveOwnership = 1;
	$AutoSaver::SaveEvents = 1;
}

if(!isObject(AutoSaver_Bomb))
{
	new ScriptObject(AutoSaver_Bomb)
	{
		class = "timeBomb";
		tickMinutes = 1;
		requiredTicks = $AutoSaver::SaveTime;
		go = true;
	};
}

function AutoSaver_adjustTime()
{
	AutoSaver_Bomb.end();
	
	AutoSaver_Bomb.requiredTicks = $AutoSaver::SaveTime;
	
	AutoSaver_Bomb.start();
}
function AutoSaver_Bomb::onTick(%this,%time)
{
	if($AutoSaver::SaveFile $= "")
		$AutoSaver::SaveFile = "autosave";
		
	AutoSaver_saveBricks(fileBase($AutoSaver::SaveFile),!!$AutoSaver::SaveEvents,!!$AutoSaver::SaveOwnership);
}
function serverCmdAutoSave(%client)
{
	if(%client.isSuperAdmin)
	{
		AutoSaver_saveBricks(fileBase($AutoSaver::SaveFile),!!$AutoSaver::SaveEvents,!!$AutoSaver::SaveOwnership);
		messageAll('',%client.getPlayerName() @ "\c6 has manually saved.");
	}
	else
	{
		messageClient(%client,'',"\c6Only \c0Super Admins\c6 may manually save.");
	}
	
}

function AutoSaver_saveBricks(%name,%events,%ownership)
{
	messageAll('',"\c6Saving bricks...");
	if(%name $= "" || %events $= "" || %ownership $= "" || (%events !$= 1 && %events !$= 0) || (%ownership !$= 1 && %ownership !$= 0))
		return warn("Auto Saver: Incorrect usage.");
	
	//%path = "base/server/temp/" @ MissionInfo.saveName @ "/" @ %name @ ".bls";
	%path = "base/server/temp/temp.bls";
	
	if(!isWriteableFileName(%path))
		return warn("Auto Saver: Cannot save to file: " @ %path);
	
	%file = new FileObject();
	
	%file.openForWrite(%path);
	%file.writeLine("This is a Blockland save file.  You probably shouldn't modify it cause you'll screw it up.");
	%file.writeLine("1");
	%file.writeLine("Autosaved at " @ getDateTime() @ ".");
	
	for(%i=0;%i<64;%i++)
		%file.writeLine(getColorIDTable(%i));
	
	%bricks = 0;
	
	for(%i=0;%i<mainBrickGroup.getCount();%i++)
		%bricks += mainBrickGroup.getObject(%i).getCount();
	
	%file.writeLine("Linecount " @ %bricks);
	
	for(%d=0;%d<2;%d++)
	{
		for(%i=0;%i<mainBrickGroup.getCount();%i++)
		{
			%group = mainBrickGroup.getObject(%i);
			
			for(%a=0;%a<%group.getCount();%a++)
			{
				%brick = %group.getObject(%a);
				
				if(!(%d ^ %brick.isBasePlate()))
					continue;
					
				if(%brick.getDataBlock().hasPrint)
				{
					%texture = getPrintTexture(%brick.getPrintId());
					%printPath = filePath(%texture);
					%underscorePos = strPos(%printPath,"_");
					%name = getSubStr(%printPath,%underscorePos + 1,strPos(%printPath,"_",14) - 14) @ "/" @ fileBase(%texture);
					
					if($printNameTable[%name] !$= "")
						%print = %name;
				}
				
				%file.writeLine(%brick.getDataBlock().uiName @ "\" " @ %brick.getPosition() SPC %brick.getAngleID() SPC %brick.isBasePlate() SPC %brick.getColorID() SPC %print SPC %brick.getColorFXID() SPC %brick.getShapeFXID() SPC %brick.isRayCasting() SPC %brick.isColliding() SPC %brick.isRendering());
				
				if(%ownership && %brick.isBasePlate() && !$Server::LAN)
					%file.writeLine("+-OWNER " @ getBrickGroupFromObject(%brick).bl_id);
				if(%events)
				{
					if(%brick.getName() !$= "")
						%file.writeLine("+-NTOBJECTNAME " @ %brick.getName());
					
					for(%b=0;%b<%brick.numEvents;%b++)
					{
						%targetClass = %brick.eventTargetIdx[%b] >= 0 ? getWord(getField($InputEvent_TargetListfxDTSBrick_[%brick.eventInputIdx[%b]],%brick.eventTargetIdx[%b]),1) : "fxDtsBrick";
						%paramList = $OutputEvent_parameterList[%targetClass,%brick.eventOutputIdx[%b]];
						%params = "";
						
						for(%c=0;%c<4;%c++)
						{
							if(firstWord(getField(%paramList,%c)) $= "dataBlock" && isObject(%brick.eventOutputParameter[%b,%c + 1]))
								%params = %params TAB %brick.eventOutputParameter[%b,%c + 1].getID();
							else
								%params = %params TAB %brick.eventOutputParameter[%b,%c + 1];
						}
						
						%file.writeLine("+-EVENT" TAB %b TAB %brick.eventEnabled[%b] TAB %brick.eventInput[%b] TAB %brick.eventDelay[%b] TAB %brick.eventTarget[%b] TAB %brick.eventNT[%b] TAB %brick.eventOutput[%b] @ %params);
					}
				}
				
				if(isObject(%brick.emitter))
					%file.writeLine("+-EMITTER " @ %brick.emitter.emitter.uiName @ "\" " @ %brick.emitterDirection);
				if(%brick.getLightID() >= 0)
					%file.writeLine("+-LIGHT " @ %brick.getLightID().getDataBlock().uiName @ "\" "); // Not sure if something else comes after the name
				if(isObject(%brick.item))
					%file.writeLine("+-ITEM " @ %brick.item.getDataBlock().uiName @ "\" " @ %brick.iautosaveosition SPC %brick.itemDirection SPC %brick.itemRespawnTime);
				if(isObject(%brick.audioEmitter))
					%file.writeLine("+-AUDIOEMITTER " @ %brick.audioEmitter.getProfileID().uiName @ "\" "); // Not sure if something else comes after the name
				if(isObject(%brick.vehicleSpawnMarker))
					%file.writeLine("+-VEHICLE " @ %brick.vehicleSpawnMarker.uiName @ "\" " @ %brick.reColorVehicle);
			}
		}
	}
	
	%file.close();
	%file.delete();
	echo("Auto Saver: " @ %bricks @ " bricks saved to " @ %path @ " successfully.");
	messageAll('',"\c6Saved " @ %bricks @ " bricks.");
}
function serverCmdStartAutoSaver(%client)
{
	if(%client.isSuperAdmin)
	{
		AutoSaver_Bomb.start();
		messageAll('',%client.getPlayerName() @ "\c6 has started the auto saver.");
	}
	else
		messageClient(%client,'',"\c6Only \c0Super Admins\c6 may start the auto saver.");
}
function serverCmdStopAutoSaver(%client)
{
	if(%client.isSuperAdmin)
	{
		AutoSaver_Bomb.end();
		messageAll('',%client.getPlayerName() @ "\c6 has stopped the auto saver.");
	}
	else
		messageClient(%client,'',"\c6Only \c0Super Admins\c6 may stop the auto saver.");
}
