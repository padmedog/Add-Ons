addDamageType("MedSwordsPack",'<bitmap:add-ons/Weapon_Sword/CI_sword> %1','%2 <bitmap:add-ons/Weapon_Sword/CI_sword> %1',0.75,1);
if(!isObject(toolExplosionParticle))
{
datablock ParticleData(toolExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/star1.png";
   colors[0]     = "0.7 0.7 0.9 0.9";
   colors[1]     = "0.9 0.9 0.9 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};
}

if(!isObject(toolExplosionEmitter))
{
datablock ParticleEmitterData(toolExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "toolExplosionParticle";
};
}
if(!isObject(toolExplosion))
{
datablock ExplosionData(toolExplosion)
{
   soundProfile = hammerHitSound;
   lifeTimeMS = 500;
   particleEmitter = toolExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;
   faceViewer     = true;
   explosionScale = "1 1 1";
   shakeCamera = false;
   lightStartRadius = 3;
   lightEndRadius = 0;
   lightStartColor = "00.0 0.2 0.6";
   lightEndColor = "0 0 0";
};
}
if(!isObject(bronzeDaggerProjectile))
{
datablock ProjectileData(bronzeDaggerProjectile)
{
   directDamage        = 5;
   explosion           = toolExplosion;
   muzzleVelocity      = 50;
   velInheritFactor    = 1;
   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;directDamageType=$DamageType::MedSwordsPack;
};
}
if(!isObject(bronzeDaggerItem))
{
datablock ItemData(bronzeDaggerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./shapes/Dagger.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Bronze Dagger";
	iconName = "";
	doColorShift = true;
	colorShiftColor = "0.4 0.2 0 1";
	image = bronzeDaggerImage;
	canDrop = true;
};
}
if(!isObject(bronzeDaggerImage))
{
datablock ShapeBaseImageData(bronzeDaggerImage)
{
   shapeFile = "./shapes/Dagger.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0"; 
   correctMuzzleVector = false;
   className = "WeaponImage";
   item = bronzeDaggerItem;
   ammo = " ";
   projectile = bronzeDaggerProjectile;
   projectileType = Projectile;
   MedSwordsPack = true;
   doRetraction = false;
   armReady = true;
   doColorShift = true;
   colorShiftColor = "0.4 0.2 0 1";
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "Fire";

	
	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";
};
}
function bronzeDaggerImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function bronzeDaggerImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
}

if(!isObject(ironDaggerProjectile))
{
datablock ProjectileData(ironDaggerProjectile)
{
   directDamage        = 9;
   explosion           = toolExplosion;
   muzzleVelocity      = 50;
   velInheritFactor    = 1;
   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;directDamageType=$DamageType::MedSwordsPack;
};
}
if(!isObject(ironDaggerItem))
{
datablock ItemData(ironDaggerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./shapes/Dagger.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Iron Dagger";
	iconName = "";
	doColorShift = true;
	colorShiftColor = "0.73 0.62 0.52 1";
	image = ironDaggerImage;
	canDrop = true;
};
}
if(!isObject(ironDaggerImage))
{
datablock ShapeBaseImageData(ironDaggerImage)
{
   shapeFile = "./shapes/Dagger.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0"; 
   correctMuzzleVector = false;
   className = "WeaponImage";
   item = ironDaggerItem;
   ammo = " ";
   projectile = ironDaggerProjectile;
   projectileType = Projectile;
   MedSwordsPack = true;
   doRetraction = false;
   armReady = true;
   doColorShift = true;
   colorShiftColor = "0.73 0.62 0.52 1";
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "Fire";

	
	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";
};
}
function ironDaggerImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function ironDaggerImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
}

if(!isObject(steelDaggerProjectile))
{
datablock ProjectileData(steelDaggerProjectile)
{
   directDamage        = 12;
   explosion           = toolExplosion;
   muzzleVelocity      = 50;
   velInheritFactor    = 1;
   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;directDamageType=$DamageType::MedSwordsPack;
};
}
if(!isObject(steelDaggerItem))
{
datablock ItemData(steelDaggerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./shapes/Dagger.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Steel Dagger";
	iconName = "";
	doColorShift = true;
	colorShiftColor = "0.8 0.8 0.8 1";
	image = steelDaggerImage;
	canDrop = true;
};
}
if(!isObject(steelDaggerImage))
{
datablock ShapeBaseImageData(steelDaggerImage)
{
   shapeFile = "./shapes/Dagger.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0"; 
   correctMuzzleVector = false;
   className = "WeaponImage";
   item = steelDaggerItem;
   ammo = " ";
   projectile = steelDaggerProjectile;
   projectileType = Projectile;
   MedSwordsPack = true;
   doRetraction = false;
   armReady = true;
   doColorShift = true;
   colorShiftColor = "0.8 0.8 0.8 1";
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "Fire";

	
	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";
};
}

function steelDaggerImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function steelDaggerImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
}