//Add a Replacer variable for the values on wire bricks.
registerSpecialVar(fxDTSbrick,"Power","%this.GetWirePower()");




