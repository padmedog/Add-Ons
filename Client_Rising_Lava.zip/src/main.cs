//	RLC_SyncClientCache() takes all the files in cache/ and adds them to cache.db.
//	This means any files on the Rising Lava server with the same CRC will not be downloaded (this is faster).

function RLC_SyncClientCache(%echo)
{
	%pattern = "Add-Ons/Client_Rising_Lava/cache/*.*";
	%file = findFirstFile(%pattern);

	while(isFile(%file))
	{
		addFileToCache(%file);

		if(%echo)
			echo("Rising Lava caching file ( " @ fileName(%file) @ " )");

		%file = findNextFile(%pattern);
	}

	echo("Loaded Rising Lava client cache.");
}

schedule(200, 0, RLC_SyncClientCache, 0);

function RLC_Shop_SetMoney(%val)
{
	%val = mFloor(%val);
	$RLC::Shop::Money = %val;

	RLC_Shop_MoneyText.setValue( "<font:Arial Bold Italic:14>" @ $RLC::Shop::Money );
}

function clientCmdRLC_Shop_SetMoney(%val)
{
	RLC_Shop_SetMoney(%val);
}

function RLC_Shop_Open()
{
	commandToServer('RLCRequestMoney');
	Canvas.pushDialog(RisingLavaShop);
}

function clientCmdRLC_Shop_Open()
{
	RLC_Shop_Open();
}

function RLC_Shop_SetTab(%tab)
{
	%tabs[0] = "Powerups";
	%tabs[1] = "Trails";
	%tabs[2] = "Hats";

	for(%a = 0; %a <= 2; %a++)
	{
		%obj = "RLC_ShopTab_" @ %tabs[%a];

		%obj.setVisible(%tabs[%a] $= %tab);
	}
}

function RLC_Shop_BuyPowerup(%powerup)
{
	if(!isObject(ServerConnection))
	{
		RLC_MessageBoxOK("Rising Lava Shop", "Error: <font:Arial Bold Italic:14>NO_SERVER_CONNECTION<font:Arial:14>\n\nNo server connection found.");
		return;
	}
	commandToServer('powerup', %powerup);
}

function RLC_Shop_BuyTrail(%trail)
{
	if(!isObject(ServerConnection))
	{
		RLC_MessageBoxOK("Rising Lava Shop", "Error: <font:Arial Bold Italic:14>NO_SERVER_CONNECTION<font:Arial:14>\n\nNo server connection found.");
		return;
	}
	commandToServer('trail', %trail);
}

function RLC_Shop_BuyHat(%hat)
{
	if(!isObject(ServerConnection))
	{
		RLC_MessageBoxOK("Rising Lava Shop", "Error: <font:Arial Bold Italic:14>NO_SERVER_CONNECTION<font:Arial:14>\n\nNo server connection found.");
		return;
	}
	commandToServer('hat', %hat);
}

function RLC_Shop_SetTrail(%trail)
{
	if(!isObject(ServerConnection))
	{
		RLC_MessageBoxOK("Rising Lava Shop", "Error: <font:Arial Bold Italic:14>NO_SERVER_CONNECTION<font:Arial:14>\n\nNo server connection found.");
		return;
	}
	commandToServer('settrail', %trail);
}

function RLC_Shop_SetHat(%hat)
{
	if(!isObject(ServerConnection))
	{
		RLC_MessageBoxOK("Rising Lava Shop", "Error: <font:Arial Bold Italic:14>NO_SERVER_CONNECTION<font:Arial:14>\n\nNo server connection found.");
		return;
	}
	commandToServer('sethat', %hat);
}

function RLC_ShopPowerups_SetCover(%val, %name)
{
	%pus[%puc=0] = "Swiftness";
	%pus[%puc++] = "Regaining";
	%pus[%puc++] = "HighJump";
	%pus[%puc++] = "Strength";

	for(%a = 0; %a <= %puc; %a++)
	{
		if(%name !$= "" && %pus[%a] !$= %name)
		{
			continue;
		}

		%obj = "RLC_Shop_PowerupBlock_" @ %pus[%a];

		%obj.setVisible(%val);
	}
}

function clientCmdRLC_ShopPowerups_SetCover(%val, %name)
{
	RLC_ShopPowerups_SetCover(%val, %name);
}

//"Rainbow", "Rainbow", "An awesome looking color spectrum, and a classic!", "Add-Ons/Client_Rising_Lava/res/images/rainbow-thumb", "1 1 1", 3000
//"Flame", "Flame", "Have you ever wanted to be Ghost Rider? Too bad. But at least you can have his awesome flames!", "Add-Ons/Client_Rising_Lava/res/images/flame-thumb", "1 1 1", 2600
//"LaserBlue", "Laser - Blue", "A blue-tinted laser to follow your path. Also a real classic trail!", "Add-Ons/Client_Rising_Lava/res/images/laserblue-thumb", "1 1 1", 2500
//"LaserGreen", "Laser - Green", "A green-tinted laser variant.", "Add-Ons/Client_Rising_Lava/res/images/lasergreen-thumb", "1 1 1", 2500
//"LaserRed", "Laser - Red", "A red-tinted laser variant.", "Add-Ons/Client_Rising_Lava/res/images/laserred-thumb", "1 1 1", 2500
//"LaserGold", "Laser - Gold", "A green-tinted laser variant; VIP Only.", "Add-Ons/Client_Rising_Lava/res/images/lasergold-thumb", "1 1 1", "VIP"

function RLC_addNoneTrail()
{
	%swatch = new GuiSwatchCtrl()
	{
   	position = "1 0";
   	extent = "368 101";
   	color = "0 116 80 3";
   	new GuiSwatchCtrl()
		{
      	position = "1 1";
      	extent = "368 100";
      	color = "200 200 200 255";
      	new GuiSwatchCtrl()
			{
         	position = "1 1";
         	extent = "98 98";
         	color = "250 250 250 255";
         	new GuiBitmapCtrl()
				{
            	horizSizing = "center";
            	vertSizing = "center";
            	position = "17 17";
            	extent = "64 64";
            	bitmap = "base/client/ui/avatarIcons/None";
            	mColor = "255 255 255 255";
         	};
      	};
      	new GuiSwatchCtrl()
			{
         	position = "100 1";
         	extent = "266 98";
         	color = "242 241 240 255";
         	new GuiTextCtrl()
				{
            	profile = "RLC_HeaderText";
            	position = "10 8";
            	extent = "261 18";
            	text = "None";
            	maxLength = "255";
         	};
         	new GuiMLTextCtrl()
				{
            	profile = "RLC_CheckBoxProfile";
            	position = "10 30";
            	extent = "261 14";
            	text = "Disables the current trail, if any.";
            	selectable = false;
         	};
         	new GuiBitmapButtonCtrl()
				{
            	profile = "RLC_ButtonText";
            	position = "7 67";
            	extent = "91 21";
            	command = "RLC_Shop_SetTrail(None);";
            	text = "Use";
            	bitmap = "Add-Ons/Client_Rising_Lava/res/images/button";
            	mColor = "5 255 255 255";
         	};
         	new GuiSwatchCtrl(RLC_Shop_TrailBlock_Buy_None)
				{
            	position = "167 67";
            	extent = "91 21";
            	visible = false;
            	color = "242 241 240 200";
         	};
         	new GuiSwatchCtrl(RLC_Shop_TrailBlock_Set_None)
				{
            	position = "7 67";
            	extent = "91 21";
            	color = "242 241 240 200";
         	};
      	};
   	};
	};

	RLC_TrailsSwatch.add(%swatch);

	RLC_doTrailsScale();
}

function RLC_addNoneHat()
{
	%swatch = new GuiSwatchCtrl()
	{
   	position = "1 0";
   	extent = "368 101";
   	color = "0 116 80 3";
   	new GuiSwatchCtrl()
		{
      	position = "1 1";
      	extent = "368 100";
      	color = "200 200 200 255";
      	new GuiSwatchCtrl()
			{
         	position = "1 1";
         	extent = "98 98";
         	color = "250 250 250 255";
         	new GuiBitmapCtrl()
				{
            	horizSizing = "center";
            	vertSizing = "center";
            	position = "17 17";
            	extent = "64 64";
            	bitmap = "base/client/ui/avatarIcons/None";
            	mColor = "255 255 255 255";
         	};
      	};
      	new GuiSwatchCtrl()
			{
         	position = "100 1";
         	extent = "266 98";
         	color = "242 241 240 255";
         	new GuiTextCtrl()
				{
            	profile = "RLC_HeaderText";
            	position = "10 8";
            	extent = "261 18";
            	text = "None";
            	maxLength = "255";
         	};
         	new GuiMLTextCtrl()
				{
            	profile = "RLC_CheckBoxProfile";
            	position = "10 30";
            	extent = "261 14";
            	text = "Unequips the current hat, if any.";
            	selectable = false;
         	};
         	new GuiBitmapButtonCtrl()
				{
            	profile = "RLC_ButtonText";
            	position = "7 67";
            	extent = "91 21";
            	command = "RLC_Shop_SetHat(None);";
            	text = "Use";
            	bitmap = "Add-Ons/Client_Rising_Lava/res/images/button";
            	mColor = "5 255 255 255";
         	};
         	new GuiSwatchCtrl(RLC_Shop_HatBlock_Buy_None)
				{
            	position = "167 67";
            	extent = "91 21";
            	visible = false;
            	color = "242 241 240 200";
         	};
         	new GuiSwatchCtrl(RLC_Shop_HatBlock_Set_None)
				{
            	position = "7 67";
            	extent = "91 21";
            	color = "242 241 240 200";
         	};
      	};
   	};
	};

	RLC_HatsSwatch.add(%swatch);

	RLC_doHatsScale();
}

function clientCmdRLC_TrailsRTS()
{
	RLC_clearTrails();
	RLC_addNoneTrail();
}

function clientCmdRLC_HatsRTS()
{
	RLC_clearHats();
	RLC_addNoneHat();
}

function RLC_clearTrails()
{
	RLC_TrailsSwatch.deleteAll();

	RLC_doTrailsScale();
}

function RLC_clearHats()
{
	RLC_HatsSwatch.deleteAll();

	RLC_doHatsScale();
}

function RLC_doTrailsScale()
{
	%this = RLC_TrailsSwatch;

	%count = %this.getCount();

	%x = 368;
	%y = (99 * %count) + 2;

	%this.resize(0, 1, %x, %y);
}

function RLC_doHatsScale()
{
	%this = RLC_HatsSwatch;

	%count = %this.getCount();

	%x = 368;
	%y = (99 * %count) + 2;

	%this.resize(0, 1, %x, %y);
}

function clientCmdRLC_AddTrail(%uid, %title, %description, %img, %imgcolor, %price)
{
	%btn = "5 255 5 255";

	if(%price !$= mFloor(%price))
	{
		%vip = true;
		%btn = "5 255 255 255";
		%pack = %price;

		if(%pack $= "Sponsor")
		{
			%btn = "255 5 255 255";
		}
	}

	for(%i = 0; %i < 3; %i++)
	{
		%c = mFloor(getWord(%imgcolor, %i) * 255);

		%newcolor = trim(%newcolor SPC %c);
	}

	%price = mFloor(%price);

	%y = RLC_TrailsSwatch.getCount() * 99;

	%swatch = new GuiSwatchCtrl()
	{
   	position = 1 SPC %y;
   	extent = "368 101";
   	color = "0 116 80 3";
   	new GuiSwatchCtrl()
		{
      	position = "1 1";
      	extent = "368 100";
      	color = "200 200 200 255";
      	new GuiSwatchCtrl()
			{
         	position = "1 1";
         	extent = "98 98";
         	color = "250 250 250 255";
         	new GuiBitmapCtrl()
				{
            	position = "1 1";
            	extent = "96 96";
            	bitmap = %img;
            	mColor = %newcolor;
         	};
      	};
      	new GuiSwatchCtrl()
			{
         	position = "100 1";
         	extent = "266 98";
         	color = "242 241 240 255";
         	new GuiTextCtrl()
				{
            	profile = "RLC_HeaderText";
            	position = "10 8";
            	extent = "261 18";
            	text = %title;
         	};
         	new GuiMLTextCtrl()
				{
            	profile = "RLC_CheckBoxProfile";
            	position = "10 30";
            	extent = "261 14";
            	text = %description;
					selectable = false;
         	};
         	new GuiBitmapButtonCtrl()
				{
            	profile = "RLC_ButtonText";
            	position = "167 67";
            	extent = "91 21";
            	command = "RLC_Shop_BuyTrail(" @ %uid @ ");";
            	text = "$" @ %price;
            	bitmap = "Add-Ons/Client_Rising_Lava/res/images/button";
            	mColor = "255 255 255 255";
					visible = !%vip;
         	};
         	new GuiSwatchCtrl("RLC_Shop_TrailBlock_Buy_" @ %uid)
				{
            	position = "167 67";
            	extent = "91 21";
            	color = "242 241 240 200";
					visible = false;
         	};
         	new GuiBitmapButtonCtrl()
				{
            	profile = "RLC_ButtonText";
            	position = "7 67";
            	extent = "91 21";
            	command = "RLC_Shop_SetTrail(" @ %uid @ ");";
            	text = %vip ? %pack : "Use";
            	bitmap = "Add-Ons/Client_Rising_Lava/res/images/button";
            	mColor = %btn;
         	};
         	new GuiSwatchCtrl("RLC_Shop_TrailBlock_Set_" @ %uid)
				{
            	position = "7 67";
            	extent = "91 21";
            	color = "242 241 240 200";
         	};
      	};
   	};
	};

	RLC_TrailsSwatch.add(%swatch);

	RLC_doTrailsScale();
}

function clientCmdRLC_AddHat(%uid, %title, %description, %dts, %price)
{
	%btn = "5 255 5 255";

	if(%price !$= mFloor(%price))
	{
		%vip = true;
		%btn = "5 255 255 255";
		%pack = %price;

		if(%pack $= "Sponsor")
		{
			%btn = "255 5 255 255";
		}
	}

	%shape = "Add-Ons/Client_Rising_Lava/cache/" @ %dts;

	%price = mFloor(%price);

	%y = RLC_HatsSwatch.getCount() * 99;

	%swatch = new GuiSwatchCtrl()
	{
   	position = 1 SPC %y;
   	extent = "368 101";
   	color = "0 116 80 3";
   	new GuiSwatchCtrl()
		{
      	position = "1 1";
      	extent = "368 100";
      	color = "200 200 200 255";
      	new GuiSwatchCtrl()
			{
         	position = "1 1";
         	extent = "98 98";
         	color = "250 250 250 255";
				new GuiObjectView("RLC_HatPreview_" @ %uid)
				{
   				position = "0 -66";
   				extent = "96 192";
   				cameraZRot = "0";
   				forceFOV = "10";
   				lightDirection = "-0.57735 -0.57735 -0.57735";
   				lightColor = "1.000000 1.000000 1.000000 1.000000";
   				ambientColor = "0.800000 0.800000 0.800000 1.000000";
				};
      	};
      	new GuiSwatchCtrl()
			{
         	position = "100 1";
         	extent = "266 98";
         	color = "242 241 240 255";
         	new GuiTextCtrl()
				{
            	profile = "RLC_HeaderText";
            	position = "10 8";
            	extent = "261 18";
            	text = %title;
         	};
         	new GuiMLTextCtrl()
				{
            	profile = "RLC_CheckBoxProfile";
            	position = "10 30";
            	extent = "261 14";
            	text = %description;
					selectable = false;
         	};
         	new GuiBitmapButtonCtrl()
				{
            	profile = "RLC_ButtonText";
            	position = "167 67";
            	extent = "91 21";
            	command = "RLC_Shop_BuyHat(" @ %uid @ ");";
            	text = "$" @ %price;
            	bitmap = "Add-Ons/Client_Rising_Lava/res/images/button";
            	mColor = "255 255 255 255";
					visible = !%vip;
         	};
         	new GuiSwatchCtrl("RLC_Shop_HatBlock_Buy_" @ %uid)
				{
            	position = "167 67";
            	extent = "91 21";
            	color = "242 241 240 200";
					visible = false;
         	};
         	new GuiBitmapButtonCtrl()
				{
            	profile = "RLC_ButtonText";
            	position = "7 67";
            	extent = "91 21";
            	command = "RLC_Shop_SetHat(" @ %uid @ ");";
            	text = %vip ? %pack : "Use";
            	bitmap = "Add-Ons/Client_Rising_Lava/res/images/button";
            	mColor = %btn;
         	};
         	new GuiSwatchCtrl("RLC_Shop_HatBlock_Set_" @ %uid)
				{
            	position = "7 67";
            	extent = "91 21";
            	color = "242 241 240 200";
         	};
      	};
   	};
	};

	%objview = nameToID("RLC_HatPreview_" @ %uid);

	if(isObject(%objview))
	{
		%objview.setEmpty();

		%objview.setObject("", %shape, "", 0);
	}

	RLC_HatsSwatch.add(%swatch);

	RLC_doHatsScale();
}

function RLC_ShopTrails_SetCover(%val, %name, %set)
{
	%obj = "RLC_Shop_TrailBlock_" @ (%set ? "Set" : "Buy") @ "_" @ %name;

	if(isObject(%obj))
		%obj.setVisible(%val);
}

function clientCmdRLC_ShopTrails_SetCover(%val, %name, %set)
{
	RLC_ShopTrails_SetCover(%val, %name, %set);
}

function RLC_ShopHats_SetCover(%val, %name, %set)
{
	%obj = "RLC_Shop_HatBlock_" @ (%set ? "Set" : "Buy") @ "_" @ %name;

	if(isObject(%obj))
		%obj.setVisible(%val);
}

function clientCmdRLC_ShopHats_SetCover(%val, %name, %set)
{
	RLC_ShopHats_SetCover(%val, %name, %set);
}

function RLC_MessageBoxOK(%title, %body)
{
	RLCMessageFrame.setValue(%title);
	RLCMessageText.setValue(%body);

	canvas.pushDialog(RisingLavaMessage);
}

function clientCmdRLC_MessageBoxOK(%title, %body)
{
	RLC_MessageBoxOK(%title, %body);
}

function RLC_DisconnectMessageBoxOK(%title, %body)
{
	disconnect();
	RLC_MessageBoxOK(%title, %body);
}

function clientCmdRLC_DisconnectMessageBoxOK(%title, %body)
{
	RLC_DisconnectMessageBoxOK(%title, %body);
}

function clientCmdRLC_VoteInit()
{
	RLC_ClearVoteDlg();
	Canvas.pushDialog(RisingLavaVote);
}

function clientCmdRLC_VoteEnd()
{
	Canvas.popDialog(RisingLavaVote);
}

function RLC_ClearVoteDlg()
{
	deleteVariables("$RLC::Vote*");
	RLC_VoteGroup.deleteAll();
}

function clientCmdRLC_AddVoteMap(%index, %name)
{
	if(%index $= "" || %name $= "")
	{
		return;
	}

	%index *= 1;

	%name = StripMLControlChars(%name);

	%pos = ($RLC::Vote::Column ? 439 : 0) SPC ($RLC::Vote::Row * 28);

	%this = new GuiBitmapCtrl()
	{
		position = %pos;
		extent = "435 24";
		bitmap = "Add-Ons/Client_Rising_Lava/res/images/voteItem";

		new GuiMLTextCtrl()
		{
			profile = "RLC_VoteButtonText";
			position = "8 5";
			extent = "425 14";
			text = "<shadow:1:1><shadowcolor:000000>" @ %name;
			selectable = "0";
		};

		new GuiSwatchCtrl()
		{
			position = "0 0";
			extent = "435 24";
			color = "0 0 0 0";
			isEmoticonSwatch = true;
		};

		new GuiBitmapButtonCtrl()
		{
			profile = "RLC_VoteButtonText";
			position = "0 0";
			extent = "435 24";
			text = " ";
			bitmap = "Add-Ons/Client_Rising_Lava/res/images/voteItem";
			command = "RLC_VoteMap(" @ %index @ ");";
			isRLCVote = true;
		};
	};

	%this.emoticonSwatch = %swatch;
	RLC_VoteGroup.add(%this);

	for(%a = 0; %a < %this.getCount(); %a++)
	{
		%obj = %this.getObject(%a);

		if(%obj.isEmoticonSwatch)
		{
			%this.emoticonSwatch = %obj;
			break;
		}
	}

	$RLC::Vote::Item[%index] = %this;

	$RLC::Vote::Column = !$RLC::Vote::Column;

	if(!$RLC::Vote::Column)
	{
		$RLC::Vote::Row++;
	}
}

function clientCmdRLC_AddVoteEmoticon(%index, %cid)
{
	%this = $RLC::Vote::Item[%index].emoticonSwatch;

	if(!isObject(%this) || %cid $= "" || $RLC::Vote::CIDLocation[%cid])
	{
		return;
	}

	%obj = new GuiBitmapCtrl()
	{
		vertSizing = "center";
		position = 415 SPC 4;
		extent = "16 16";
		bitmap = "Add-Ons/Client_Rising_Lava/res/images/emoticon_smile";
		voteCID = %cid;
	};

	%x = 415 - (%this.getCount() * 17);
	%this.add(%obj);

	$RLC::Vote::CIDLocation[%cid] = %this;

	%obj.tangoMoveTo(%x SPC 4, 500, expo);

	alxPlay( alxCreateSource(AudioGui, "Add-Ons/Client_Rising_Lava/res/sounds/ui_click.wav") );
}

function clientCmdRLC_RemoveVoteEmoticon(%cid)
{
	%this = $RLC::Vote::CIDLocation[%cid];

	if(!isObject(%this) || %cid $= "")
	{
		return;
	}

	for(%a = 0; %a < %this.getCount(); %a++)
	{
		%obj = %this.getObject(%a);

		if(%obj.voteCID == %cid)
		{
			%emoticon = %obj;
			break;
		}
	}

	%x = getWord( %emoticon.getPosition(), 0 );

	for(%a = 0; %a < %this.getCount(); %a++)
	{
		%obj = %this.getObject(%a);
		%xx = getWord( %obj.getPosition(), 0 );

		if(%xx < %x)
		{
			%obj.tangoMoveTo( getWords( VectorAdd( %obj.getPosition(), "17 0" ), 0, 1 ), 500, expo );
		}
	}

	%emoticon.delete();

	$RLC::Vote::CIDLocation[%cid] = false;
}

function clientCmdRLC_SetVoteTime(%time)
{
	%time = mFloor(%time);

	RLC_VoteTime.setValue("<just:center><font:Arial:40><color:FFFFFF><shadow:1:1>" @ %time SPC "seconds");
}

function RLC_VoteMap(%index)
{
	commandToServer('VoteMap', %index);
}

if(isPackage(RLCVotePackage))
{
	deactivatePackage(RLCVotePackage);
}

package RLCVotePackage
{
	function GuiBitmapButtonCtrl::onMouseEnter(%this)
	{
		if(%this.isRLCVote)
		{
			alxPlay( alxCreateSource(AudioGui, "Add-Ons/Client_Rising_Lava/res/sounds/ui_hover.wav") );
		}
	}
};

activatePackage(RLCVotePackage);
