// server.cs for godzilla/rampage mode

// $gamemodearg
// $defaultMinigame
// serverDirectSaveFileLoad(%fileName, %colorMethod, %dirName, %ownership);
// minigame.reset( 0 );
// saveEnvironment( "Filename" );
// $GameModeArg

// for now let's not execute the mod unless we run it through the gamemode, to make things easier to work with
// eventualy this will be available as a stock weapon, well possibly
if( $GameModeArg !$= "Add-Ons/GameMode_Rampage/gamemode.txt" )
{
	error( "Error: GameMode_Rampage cannot be used in custom games" );
	return;
}
	
// sounds
datablock AudioProfile( godzillaBreakSound1 )
{
	filename = "./break1.wav";
	description = AudioClose3d;
	preload = false;
};

datablock AudioProfile( godzillaBreakSound2 )
{
	filename = "./break2.wav";
	description = AudioClose3d;
	preload = false;
};

datablock AudioProfile( godzillaPowerUpSound )
{
	filename = "./powerup.wav";
	description = AudioClose3d;
	preload = false;
};

// returns true if on dedicated server
// function isDedicated()
// {
	// return $Server::Dedicated;
// }

exec( "./weapon.cs" );
exec( "./player.cs" );

function execGodzillaThing()
{
	exec( "Add-Ons/Gamemode_Rampage/server.cs" );
}

// this contains all the levels we have
$RampageModeLevels = new scriptObject( RampageModeLevels )
{
	levelCount = 3;
	
	level[ 1 ] = "Add-Ons/GameMode_Rampage/Map_Beta.bls";
	levelName[ 1 ] = "Beta City";
	levelCam[ 1 ] = "-44.5949 -89.0925 21.4696 0.25952 -0.10295 0.960235 0.783533";
	levelTime[ 1 ] = 180;
	levelScore[ 1 ] = 200;
	
	level[ 2 ] = "Add-Ons/GameMode_Rampage/Map_AMC.bls";
	levelName[ 2 ] = "ACM City";
	levelCam[ 2 ] = "-118.271 33.8294 19.519 0.0773955 -0.179861 0.980643 2.34298";
	levelTime[ 2 ] = 210;
	levelScore[ 2 ] = 300;
	
	level[ 3 ] = "Add-Ons/GameMode_Rampage/Map_Afghan.bls";
	levelName[ 3 ] = "Afghanistan";
	levelCam[ 3 ] = "-86.9817 -79.5348 27.3395 0.471675 -0.184942 0.86216 0.853649";
	levelTime[ 3 ] = 270;
	levelScore[ 3 ] = 250;
};

$godzilla::score = 400;

// functions that determine how to start the player during the mode

// put them in end camera mode
function GameConnection::gPhase3( %client, %minigame )
{
	%camera = %client.camera;
	// since they joined late inform them that a new round will start soon
	%camera.setTransform( $RampageModeLevels.levelCam[ %minigame.gMap ] );
	%client.setControlObject( %camera );
	%camera.setControlObject( %client.player );

	%topText = "<font:impact:50><color:FFFF00><just:center>A new round will start soon!";
	
	%client.centerPrint( %topText, 0 );
}

// with this you do nothing I don't believe
function GameConnection::gPhase2( %client, %minigame )
{
	// this is only really called when you join late
	
	// if we don't have level information yet, set it
	%scoreInc = $RampageModeLevels.levelScore[ %client.minigame.gMap ];
	
	if( !%client.nextLevel )
		%client.nextLevel = %scoreInc;
	
	if( !%client.curLevel )
		%client.curLevel = 1;
		
	// if we're in free mode and someone joins late, supersize them as well
	if( !%minigame.gFreeMode )
		return;
	
	%client.gFreeMode = 1;
	
	// make them huge so they can have fun
	%client.player.setScale( "5 5 5" );
}

// pre game
function GameConnection::gPhase1( %client, %minigame )
{
	// get the position from the map list
	%pos = $RampageModeLevels.levelCam[ %minigame.gMap ];
	
	// set their camera to the position in the map list
	%client.camera.setTransform( %pos );

	// remote control our player from the camera
	%client.setControlObject( %client.camera );
	%client.camera.setControlObject( %client.player );
	
	// right now we don't want the user to see his player, so let's set their transform somewhere far off
	// we do this to keep the camera frozen, probably a better way to do this
	%client.player.setTransform( "0 0 -20" );
	%client.player.setScale( "1 1 1" );
	
	// display the level we're on while everyone loads the bricks
	%level = %minigame.gMap;
	%name = $RampageMOdeLevels.levelName[ %level ];
	
	%text = "<font:impact:50><color:FFFF00><just:center>Level" SPC %level SPC %name;
	
	%client.centerPrint( %text, 0 );
	
	// reset nextLevel
	%client.nextLevel = $RampageModeLevels.levelScore[ %client.minigame.gMap ];
}

// minigame functions : start game/game over functions/stats
function MiniGameSO::gStartPhase3( %minigame )
{
	// clear bricks then restart things
	%minigame.gPhase = 3;
	
	// message everyone
	%font = "<font:impact:50>";
	%color = "<color:FFFF00>";	
	
	%minigame.centerPrintAll( %font @ %color @ "Clearing bricks...", 0 );
	
	// clear bricks, add callback
	BrickGroup_888888.chaindeletecallback = %minigame @ ".gStartPhase1();";
	BrickGroup_888888.chaindeleteall();
	// BrickGroup_888888
	// temp hax
	//serverCmdClearAllBricks( findClientByName( rot ) );
	

	
	//%minigame.schedule( 15000, gStartPhase1 );
}

// start the actual game
function MiniGameSO::gStartPhase2( %minigame )
{
	%minigame.gPhase = 2;
	%minigame.reset( 0 );
	
	// start timer
	%minigame.gStartTimer( $RampageModeLevels.levelTime[ %minigame.gMap ] );//300 );
}

function MiniGameSO::gPreGameCountdown( %minigame, %sec )
{
	if( !isObject( %minigame ) )
		return;
	
	cancel( %minigame.gPreGameClock );

	if( %sec <= 0 )
	{
		%minigame.gStartPhase2();
		return;
	}

	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
			
		%font = "<font:impact:50>";
		%color = "<color:FFFF00>";	
		
		%text = %font @ %color @ "<just:center>Game starting in" SPC %sec SPC "seconds.";
		
		%client.bottomPrint( %text, 0, 1 );
	}
	
	%minigame.gPreGameClock = %minigame.schedule( 1000, gPreGameCountdown, %sec-- );
}

// set them free...
function GameConnection::gFreeMode( %client, %minigame )
{
	// winner message
	%text = "<font:impact:50><color:FFFF00><just:center>Congratulations a Winner is You!";
	
	%text = %text @ "\n\nFree Mode Unlocked!";
	
	%text = %text @ "\n<font:impact:40>Load any save you wish to destroy";
	
	%client.centerPrint( %text, 10 );
	
	// clear bottom text
	%client.bottomPrint( "", 0, 1 );
	//commandToClient( %client, 'BottomPrint', %text, 10, 1 );
	
	// set free mode on the client
	%client.gFreeMode = 1;
	
	// make them huge so they can have fun
	%client.player.setScale( "5 5 5" );
}

// generic timer, minigame, seconds, function for eval
function MiniGameSO::gGenericTimer( %minigame, %sec, %message, %function )
{
	if( !isObject( %minigame ) )
		return;
	
	cancel( %minigame.gPreGameClock );

	if( %sec <= 0 )
	{	
		// run the function we were sent
		
		eval( %function );
		
		return;
	}
	
	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
			
		%font = "<font:impact:50>";
		%color = "<color:FFFF00>";	
		
		%text = %font @ %color @ "<just:center>" @ %message SPC %sec SPC "seconds.";
		
		%client.bottomPrint( %text, 0, 1 );
	}
	
	%minigame.gPreGameClock = %minigame.schedule( 1000, gGenericTimer, %sec--, %message, %function );
}

// initiate pre game mode
function MiniGameSO::gStartPhase1( %minigame )
{
	// reset destroyed brickcount
	%minigame.gScoreTotal = 0;
	
	if( %minigame.gMap > $RampageModeLevels.levelCount )
	{
		// if we're on a dedicated server just loop continuously for now
		if( !isListenServer() )
		{
			%minigame.gMap = 1;
			
			// winner message
			%text = "<font:impact:50><color:FFFF00><just:center>Congratulations a Winner is You!";

			// %text = %text @ "\n\nThe GameMode will restart";

			// %text = %text @ "\n<font:impact:40>Load any save you wish to destroy";

			%minigame.centerPrintAll( %text, 10 );

			// clear bottom text
			%minigame.bottomPrintAll( "", 0, 1 );
			
			%func = %minigame @ ".gStartPhase1();";
			
			%minigame.gGenericTimer( 10, "Rampage will restart in", %func );
			return;
		}
		else
		{
			%minigame.gPhase = 2;
			
			%minigame.gFreeMode = 1;
			
			%minigame.reset( 0 );
			
			// go through all the players in the minigame and set them to initial spectator mode
			for( %a = 0; %a < %minigame.numMembers; %a++ )
			{
				%client = %minigame.member[ %a ];
				
				%client.gFreeMode( %minigame );
			}

			return;
		}
	}
	
	// set phasers to 1
	// this will allow us to tell the users who join late how to spawn
	%minigame.gPhase = 1;
	
	// increase the level we're on
	// %minigame.gMap++;
	
	// load the new level
	%fileName = $RampageModeLevels.level[ %minigame.gMap ];
	
	// load as public bricks so we can clear them easily
	schedule( 500, %minigame, serverDirectSaveFileLoad, %fileName, 3, "", 2 );
	// serverDirectSaveFileLoad( %fileName, 3, "", 2 );
	
	// go through all the players in the minigame and set them to initial spectator mode
	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
		
		%client.gPhase1( %minigame );
	}
	
	// for some reason isListenServer doesn't work right away, so we have to use $Server::Dedicated
	// if we're on a dedicated and there are no players, don't start the countdown
	//if( !isListenServer() && ClientGroup.getCount() == 0 )
	if( $Server::Dedicated && ClientGroup.getCount() == 0 )
	{
		echo( "GameMode_Rampage No players present, waiting..." );
		%minigame.gIsWaiting = 1;
		return;
	}
	else
		%minigame.gPreGameCountdown( 20 );
}

function miniGameSO::gAddMember( %minigame, %client )
{
	// determine what phase we're in then do it
	%phase = %minigame.gPhase;
	
	switch( %phase )
	{
		case 1: %client.gPhase1( %minigame );
		
		case 2: %client.gPhase2( %minigame );
		
		case 3: %client.gPhase3( %minigame );
	}
}

function miniGameSO::gGameOver( %minigame )
{
	// end rampage/godzilla minigame
	// i don't know what to call it...
	%minigame.gGameOver = 1;
	%minigame.gPhase = 3;
	
	// %bricksKilled = 0;
	
	// calculate total bricks destroyed
	// for( %b = 0; %b < %minigame.numMembers; %b++ )
	// {
		// %client = %minigame.member[ %b ];
		
		// %bricksKilled = %bricksKilled + %client.score;
	// }
	
	%bricksKilled = %minigame.gScoreTotal;
	
	// get brick count, subtract unbreakable spawns
	%brickcount = getBrickCount()-10;
	
	// calculate percentage of bricks destroyed
	%perDest = mFloatLength( %bricksKilled/%brickcount * 100, 0 );
	
	%font = "<font:impact:40>";
	%color = "<color:FFFF00>";
		
	if( %perDest > 100 )
		%perDest = 100;
	
	// 90, 80, 60
	if( %perDest >= 90 )
	{
		%color = "<color:ffd420>";
		%medal = %font @ "<color:ffd420>Gold Medal Awarded";
	}
	else if( %perDest >= 75 )
	{
		%color = "<color:afafaf>";
		%medal = %font @ "<color:afafaf>Silver Medal Awarded";
	}
	else if( %perDest >= 50 )
	{
		%color = "<color:CD7F32>";
		%medal = %font @ "<color:CD7F32>Bronze Medal Awarded";
	}
	else if( %perDest < 50 )
	{
		%color = "<color:ff0000>";
		%medal = %font @ "<color:ff0000>No Medal Awarded";
	}
	
	// check if we won
	if( %perDest >= 50 )
		%levelComplete = 1;
	else
		%levelComplete = 0;
	
	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
		%camera = %client.camera;
		
		// switch to the observer camera, and set control to our player from camera, for rc like effect
		// first set cameras position, this needs to be set per level as each level is placed differently
		%camera.setTransform( $RampageModeLevels.levelCam[ %minigame.gMap ] );//"0.120688 -0.279499 0.952531 135.285" );
		%client.setControlObject( %camera );
		%camera.setControlObject( %client.player );
		
		// update centerPrint and bottomPrint, display end game things
		
		if( %levelComplete )
			%topText = "<font:impact:50><color:FFFF00><just:center>Level Complete!";
		else
			%topText = %color @ "<font:impact:50><just:center>Level Failed!";
		
		%botText = "<font:impact:40><just:center>" @ %color;
		
		%botText = %botText @ %medal;//@ "Medal wtf awarded";
		%botText = %botText @ "\n" @ %perDest @ "% of Bricks Destroyed";
		%botText = %botText  @ %color @ "\n<just:center>Final Score: " @ %client.score;
		
		// %text = %font @ %color @ "<just:center>High Score: 12513, Rotondo\n<just:center>93% of Bricks Destroyed";
		//%text = %font @ %color @ "\n<just:center>Final Score: " @ %client.score;//"\n<just:left>Time: " @ %time @ "<just:right>Score: " @ %client.score;
		
		commandToClient( %client, 'CenterPrint', %topText, 0 );
		commandToClient( %client, 'BottomPrint', %botText, 0, 1 );
		
		// play an end game jingle depending if we won or not
		
	}
	
	// if we beat that level, let's go to the next one
	if( %levelComplete )
		%minigame.gMap++;
		
	%minigame.schedule( 15000, gStartPhase3 );
		
}

// timer functions

function miniGameSO::gUpdateClientTime( %minigame )
{
	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
		
		%client.updateGodzillaScore();
	}
}

function miniGameSO::gTimer( %minigame )
{
	// cancel old timer
	cancel( %minigame.gTimerSchedule );
	
	// decrement time
	%minigame.timer--;
	
	// update all clients
	%minigame.gUpdateClientTime();
	
	// if we're at zero return and do game over thing
	if( %minigame.timer <= 0 )
	{
		%minigame.gGameOver();
		return;
	}
	
	// loop it
	%minigame.gTimerSchedule = %minigame.schedule( 1000, gTimer );
}

function miniGameSO::gStartTimer( %minigame, %seconds )
{
	// cancel old timer
	cancel( %minigame.gTimerSchedule );
	
	// set the time
	%minigame.timer = %seconds;
	
	// update all clients
	%minigame.gUpdateClientTime();
	
	// loop it
	%minigame.gTimerSchedule = %minigame.schedule( 1000, gTimer );
}

// function miniGameSO::gGetTimeLeft( %minigame )
// {
	// return %minigame.timer;
// }

function gGetDisplayTime( %time )
{
	%minutes = mFloor( %time/60 );
	
	%seconds = %time - ( %minutes * 60 );
	
	if( %seconds < 10 )
		%seconds = "0" @ %seconds;
	
	%final = %minutes @ ":" @ %seconds;
	return %final;
}

// this projectile is used when you level up, to clear ALL bricks around you
// this is done to prevent the user from getting stuck as they levels up
datablock ProjectileData( godzillaLevelUpProjectile )
{
   directDamage        = 0;
   directDamageType  = 0;
   radiusDamageType  = 0;
   explosion           = "";

   brickExplosionRadius = 1.6;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 1;             
   brickExplosionMaxVolume = 512;//50;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 512;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)
   
   muzzleVelocity      = 0;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;
   explodeOnDeath = 0;

   hasLight    = false;

   uiName = "";
};

function godzillaLevelUpProjectile::onExplode( %this, %obj, %pos )
{
	%count = parent::onExplode( %this, %obj, %pos );
	
	%client = %obj.client;
	
	// this calculates what sound we should play if any
	gCalculateBreakSound( %client, %count, %pos );
}

function GameConnection::updateGodzillaScore( %client )
{
	%minigame = %client.minigame;
	
	// update score on bottom
	%font = "<font:impact:50>";
	%color = "<color:FFFF00>";
	
	%time = gGetDisplayTime( %minigame.timer );
	
	if( %client.curLevel < 7 )
		%text = %font @ %color @ "\n<just:left>Time: " @ %time @ "<just:right>Score: " @ %client.score @ "/" @ %client.nextLevel;
	else
		%text = %font @ %color @ "\n<just:left>Time: " @ %time @ "<just:right>Score: " @ %client.score;
		
	commandToClient( %client, 'BottomPrint', %text, 0, 1 );
}

function calculateGodzillaSize( %client )
{
	// if the game is over, then we should stop checking for things
	// unsure if I should move this to the updatescore function, and allow people to level up once the finale camera has activated
	if( %client.minigame.gPhase != 2 )
		return;
	
	// if we're in free mode don't do any scoring
	if( %client.gFreeMode )
		return;
	
	// if( %client.player.getScale() >= 5 )
		// return;
	
	// if we don't have a level set, set it to 1
	if( !%client.curLevel )
		%client.curLevel = 1;
	
	// kind of an odd way to do it, but this way i have absolute control over it
	%level[ 1 ] = 1;
	%level[ 2 ] = 1.5;
	%level[ 3 ] = 2;
	%level[ 4 ] = 2.5;
	%level[ 5 ] = 3;
	%level[ 6 ] = 4;
	%level[ 7 ] = 5;
	
	%scoreInc = $RampageModeLevels.levelScore[ %client.minigame.gMap ];//$godzilla::score;

	// if next level isn't set, set it to default
	if( !%client.nextLevel )
		%client.nextLevel = %scoreInc;
	
	// increase size based upon score
	//%client.nextLevel = %client.nextLevel + %scoreInc * %level[ %client.curLevel ];//%scoreInc * mPow( 2 , %client.curLevel-1 );
	
	if( %client.score >= %client.nextLevel && %client.curLevel < 7 )
	{
		%client.curLevel++;
		
		%sca = %level[ %client.curLevel ];
		%client.player.setScale( %sca SPC %sca SPC %sca );
		
		// now that we're scaled up, spawn an explosion the size of the new player to unstuck us
		%obj = %client.player;
		
		%pos = %obj.getHackPosition();

		// spawn explosion to destroy bricks when we impact
		%p = new Projectile()
		{
			dataBlock = godzillaLevelUpProjectile;
			initialPosition = %pos;
			initialVelocity = 0;
			client = %obj.client;
			scale = %obj.getScale();
		};
		missionCleanup.add( %p );

		%p.setTransform( %pos );

		%p.explode();
		
		// play effects
		
		// center text
		%font = "<font:impact:50>";
		%color = "<color:FFFF00>";
		
		%text = %font @ %color @ "\n\n\n<just:center>Size Up!";
			
		%client.centerPrint( %text, 3 );
		
		// sound and emote
		%client.playSound( godzillaPowerUpSound );
		%client.player.emote( winStarProjectile );
		
		// finally increase next level
		%client.nextLevel = %client.nextLevel + %scoreInc * %level[ %client.curLevel ];
	}
	
	// %client.nextLevel = %scoreInc * mPow( 2 , %client.curLevel-1 );
	
	%client.updateGodzillaScore();
}

// free mode load helper functions
function MiniGameSO::gFreeModeLoadTimer( %minigame, %sec )
{
	if( !isObject( %minigame ) )
		return;
	
	cancel( %minigame.gPreGameClock );

	if( %sec <= 0 )
	{	
		// reset minigame and clear bottomprint
		%minigame.reset( 0 );
		
		for( %a = 0; %a < %minigame.numMembers; %a++ )
		{
			%client = %minigame.member[ %a ];
			
			%client.bottomPrint( "", 0, 1 );
			
			%client.player.setScale( "5 5 5" );
		}
		
		return;
	}
	
	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
			
		%font = "<font:impact:50>";
		%color = "<color:FFFF00>";	
		
		%text = %font @ %color @ "<just:center>Game starting in" SPC %sec SPC "seconds.";
		
		%client.bottomPrint( %text, 0, 1 );
	}
	
	%minigame.gPreGameClock = %minigame.schedule( 1000, gFreeModeLoadTimer, %sec-- );
}

function GameConnection::gFreeModeLoadCam( %client, %minigame )
{
	// get the position from the map list
	%pos = "-44.5949 -89.0925 21.4696 0.25952 -0.10295 0.960235 0.783533"; //$RampageModeLevels.levelCam[ %minigame.gMap ];
	
	// set their camera to the position in the map list
	%client.camera.setTransform( %pos );

	// remote control our player from the camera
	%client.setControlObject( %client.camera );
	%client.camera.setControlObject( %client.player );
	
	// right now we don't want the user to see his player, so let's set their transform somewhere far off
	// we do this to keep the camera frozen, probably a better way to do this
	%client.player.setTransform( "0 0 -20" );
	%client.player.setScale( "1 1 1" );
	
	// display the level we're on while everyone loads the bricks
	// %level = %minigame.gMap;
	// %name = $RampageMOdeLevels.levelName[ %level ];
	
	%text = "<font:impact:50><color:FFFF00><just:center>Loading...";
	
	%client.centerPrint( %text, 0 );
	
	// reset nextLevel
	// %client.nextLevel = $RampageModeLevels.levelScore[ %client.minigame.gMap ];
}

// called when a file is loaded in free mode, puts players in free cam mode for 20 seconds
function MiniGameSO::gFreeModeLoad( %minigame )
{
	%minigame.gFreeModeLoadTimer( 20 );
	
	for( %a = 0; %a < %minigame.numMembers; %a++ )
	{
		%client = %minigame.member[ %a ];
		
		%client.gFreeModeLoadCam( %minigame );
	}
}

//package that allows us to smash bricks with our hands
package godzillaModePackage
{
	// minigame packages
	// if you want to modify the MiniGame when it's created this is the way to do it
	function MiniGameSO::onAdd( %obj )
	{
		parent::onAdd( %obj );
		
		// make sure we're the default minigame
		// default minigame will always have owner as 0
		if( %obj.owner != 0 )
			return;
		
		// set the level to 1
		%obj.gMap = 1;
		
		// initiate phase 1
		%obj.gStartPhase1();
	}
	
	function MiniGameSO::addMember( %minigame, %client )
	{	
		parent::addMember( %minigame, %client );
		
		// kind of a hack, but some things are delayed when the player is added
		%minigame.schedule( 70, gAddMember, %client );
	}
	
	// function GameConnection::onDrop( %this, %a, %b, %c, %d, %e )
	// {
		// return parent::onDrop( %this, %a, %b, %c, %d, %e );
	// }
	
	// GameConnection packages
	
	function GameConnection::startLoad( %this )
	{
		// echo( "DEAR GOD WTF, startLoad" );
		// echo( ClientGroup.getCount() );
		
		// restart the gamemode if we were at zero players before
		if( !isListenServer() && $defaultMinigame.gIsWaiting && ClientGroup.getCount()-1 == 0 )
		{
			// restarting
			$defaultMinigame.gIsWaiting = 0;
			
			echo( "GameMode_Rampage restarting" );
			$defaultMinigame.gPreGameCountdown( 30 );
		}
		
		parent::startLoad( %this );
	}
	
	function GameConnection::onClientLeaveGame( %this, %a, %b, %c, %d, %e )
	{
		// echo( "client leaving one" SPC ClientGroup.getCount() );
		
		// check if we should shutdown
		if( !isListenServer() && ClientGroup.getCount()-1 == 0 )
		{
			// shutting down the gamemode for now
			echo( "GameMode_Rampage no players remaining, will go into waiting state at end of round" );
		}
		
		return parent::onClientLeaveGame( %this, %a, %b, %c, %d, %e );
	}
	
	// function GameConnection::incScore( %client, %score )
	// {
		
		// return parent::incScore( %client, %score );
	// }
	
	// overwrite suicide so they can't do it
	function serverCmdSuicide( %client )
	{
		if( $GameModeArg $= "Add-Ons/GameMode_Rampage/gamemode.txt" )
			return;
		
		parent::serverCmdSuicide( %client );
	}
	
	// save overwrites to put people into observer cam
	function serverCmdEndSaveFileUpload( %client, %a, %b, %c )
	{
		%minigame = $defaultMinigame;
		
		// if we're in free mode, do free load camera
		if( %minigame.gFreeMode )
			%minigame.gFreeModeLoad();
		
		return parent::serverCmdEndSaveFileUpload( %client, %a, %b, %c );
	}
	
	function serverDirectSaveFileLoad( %fileName, %colorMethod, %dirName, %ownership )
	{
		%minigame = $defaultMinigame;
		
		// if we're in free mode, do free load camera
		if( %minigame.gFreeMode )
			%minigame.gFreeModeLoad();
		
		return parent::serverDirectSaveFileLoad( %fileName, %colorMethod, %dirName, %ownership );
	}
};
activatePackage( godzillaModePackage );
