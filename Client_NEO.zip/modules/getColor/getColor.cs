//getColor.cs
//by Nexus 4833

if($narg_promptcolor_version >= 1)
{
	echo("NARG PromptColor [v" @ $narg_promptcolor_version @ "] already in place, no need to execute.");
	return;
}
$narg_promptcolor_version = 1;

while(isobject(narg_promptcolor))
	narg_promptcolor.delete();
exec("./getColor.gui");

//promptUserColor - the only function your program needs to call.
//%default - the color that the selector will be set to by default
 //   if left empty, the default is white
//%callback - the name of a function that will be called when the user has selected a color
//    the callback function will be given that color as the argument
//%alpha - a boolean determining if the color should be RGBA or RGB
//%forcevec4 - if true, the return color will have an alpha value of 1 even if %alpha is false
//%range255 - if true, the return color will be formatted with values from 0-255 instead of decimals from 0 to 1
//    it will be assumed that the input color will match this boolean

function promptUserColor(%default, %callback, %alpha, %forcevec4, %range255)
{
	%gui = narg_promptcolor;
	%gui.alphaEnabled = %alpha;
	%gui.callback = %callback;
	%gui.forcevec4 = %forcevec4;
	%gui.range255 = %range255;

	narg_alphacolortext.setVisible(%alpha);
	narg_alphacolorslider.setVisible(%alpha);

	if(%default !$= "")
	{
		//echo("default color: " @ %default);

		if(%range255)
			%default = narg_vectorscale(%default, (1/255));
		//echo("adj color: " @ %default);
		%gui.setcolorfromtext(%default);
	}
	else
		%gui.setcolorfromtext("1 1 1 1");

	canvas.pushdialog(%gui);
}

//wtf why does default vectorscale only work with vec3's
function narg_vectorscale(%vec, %val)
{
	%ret = "";
	%max = getwordcount(%vec);

	for(%i=0; %i<%max; %i++)
	{
		if(%ret $= "")
			%ret = getword(%vec, %i)*%val;
		else
			%ret = %ret SPC getword(%vec, %i)*%val;
	}
	return %ret;
}

function narg_colorwheelmctrl::onmousedragged(%this, %a, %pos, %b)
{
	%this.managerecolor(%pos);
}

function narg_colorwheelmctrl::onmousedown(%this, %a, %pos, %b)
{
	%this.managerecolor(%pos);
}

function narg_colorwheelmctrl::managerecolor(%this, %pos)
{
	%center = vectoradd(%this.nfm_getscreenpos(), "68 68");
	//I did the math in a standard (x, y) system and was too lazy to flip an axis
	%offsetx = getword(%center, 0) - getword(%pos, 0);
	%offsety = getword(%pos, 1) - getword(%center, 1);
	%this.pickcolor(%offsetx SPC %offsety);
}

function narg_colorwheelmctrl::pickcolor(%this, %offset)
{
	%x = getword(%offset, 0)/(-64);
	%y = getword(%offset, 1)/(-64);
	%pi = matan(0,-1);
	%angle = matan(%y, %x); //range pi to negative pi
	%r = msqrt(mpow(%x,2) + mpow(%y,2));

	if(%r > 1)
		%r = 1;

	for(%i=0; %i<3; %i++)
	{
		%mangle = %angle - mfloor(%angle/(2*%pi)) * (2*%pi); //locks onto 0 to 2pi range

		if(%mangle > %pi*(1.5))
			%mangle -= 2*%pi;
		else if(%mangle > %pi/2)
		{
			%mangle -= %pi;
			%mangle *= -1;
		}
		%min = (%mangle + %pi/6)/(%pi/3);

		if(%min > 1)
			%min = 1;
		else if(%min < 0)
			%min = 0;
		%col = 1 - ((1-%min)*%r);

		if(%col < 0.00001) //god damn exponential notation fucking things up
			%col = 0;

		if(%color $= "")
			%color = %col;
		else
			%color = %color SPC %col;
		%angle += %pi*(2/3);
	}
	narg_promptcolor.setselectorcolor(%color);
}

function narg_promptcolor::setselectorcolor(%this, %color)
{
	if(%color !$= "")
		%this.rawcolor = %color;
	%shade = narg_colorslider.getValue();
	%alpha = narg_alphacolorslider.getValue();

	if(%shade > 1 || %shade $= "")
		%shade = 1;
	else if(%shade < 0)
		%shade = 0;
	%fullcol = narg_vectorscale(%this.rawcolor, %shade);

	if(!%this.alphaEnabled)
		%alpha = 1;
	else if(%alpha < 0)
		%alpha = 0;

	narg_colorpreview.setcolor(%fullcol SPC %alpha);

	if(%this.alphaEnabled)
		narg_colortext.settext(%fullcol SPC %alpha);
	else
		narg_colortext.settext(%fullcol);
	%this.coloroverride = 1;

	if(%this.rawcolor $= "0 0 0")
		%shade = 1;
	narg_colorslider.setvalue(%shade);
	narg_alphacolorslider.setvalue(%alpha);
	%this.coloroverride = 0;
}

function narg_promptcolor::nudgeslider(%this)
{
	if(%this.coloroverride)
		return;
	%this.setselectorcolor();
}

function narg_promptcolor::setcolorfromtext(%this, %color)
{
	//echo("set color from text: " @ %color);

	for(%a=0; %a<3; %a++)
	{
		%col[%a] = getword(%color, %a);

		if(%hcol $= "" || %col[%a] > %hcol)
			%hcol = %col[%a];
	}

	if(%hcol > 2 || getword(%color, 3) > 2) //assume 0-255 values in this case
	{
		//echo("needs a second round: " @ %color);
		return %this.setcolorfromtext(narg_vectorscale(%color, (1/255)));
	}

	for(%a=0; %a<3; %a++)
	{
		if(%hcol != 0)
			%col[%a] *= 1/%hcol; //will also lock the highest color to 1

		if(%col[%a] > 1) //in case of rounding error
			%col[%a] = 1;
		else if(%col[%a] < 0) //in case of user input blargtarded
			%col[%a] = 0;
	}
	%this.coloroverride = 1;

	if(%this.alphaEnabled)
	{
		//echo("doing thing: " @ getword(%color, 3));
		narg_alphacolorslider.setvalue(getword(%color, 3));
	}
	narg_colorslider.setvalue(%hcol);
	%this.coloroverride = 0;
	%this.setselectorcolor(%col0 SPC %col1 SPC %col2);
}

function narg_promptcolor::clickok(%this)
{
	%color = narg_colortext.getValue();

	if(%this.alphaEnabled)
		%max = 4;
	else
		%max = 3;

	for(%i=0; %i<%max; %i++)
	{
		%col[%i] = getword(%color, %i) * 1.0;

		if(%col[%i] > 1)
			%col[%i] = 1;
		else if(%col[%i] < 0)
			%col[%i] = 0;
	}

	if(%this.alphaEnabled)
		%color = %col0 SPC %col1 SPC %col2 SPC %col3;
	else
	{
		if(%this.forcevec4)
			%color = %col0 SPC %col1 SPC %col2 SPC "1";
		else
			%color = %col0 SPC %col1 SPC %col2;
	}

	if(%this.range255)
	{
		//echo("adjusting " @ %color @ " to be in range255");
		%deccolor = narg_vectorscale(%color, 255);
		%color = "";

		for(%i = 0; %i < getwordcount(%deccolor); %i++)
		{
			if(%color $= "")
				%color = mfloor(getword(%deccolor, %i));
			else
				%color = %color SPC mfloor(getword(%deccolor, %i));
		}
	}
	canvas.popdialog(%this);

	//echo("final color: " @ %color);
	call(%this.callback, %color);
}

