
datablock TSShapeConstructor(A10MinigunTurretDts)
{
	baseShape  = "./shapes/a10minigun.dts";
	sequence0  = "./shapes/A10_root.dsq root";

	sequence1  = "./shapes/A10_root.dsq run";
	sequence2  = "./shapes/A10_root.dsq walk";
	sequence3  = "./shapes/A10_root.dsq back";
	sequence4  = "./shapes/A10_root.dsq side";

	sequence5  = "./shapes/A10_root.dsq crouch";
	sequence6  = "./shapes/A10_root.dsq crouchRun";
	sequence7  = "./shapes/A10_root.dsq crouchBack";
	sequence8  = "./shapes/A10_root.dsq crouchSide";

	sequence9  = "./shapes/A10_root.dsq look";
	sequence10 = "./shapes/A10_root.dsq headside";
	sequence11 = "./shapes/A10_root.dsq headUp";

	sequence12 = "./shapes/A10_root.dsq jump";
	sequence13 = "./shapes/A10_root.dsq standjump";
	sequence14 = "./shapes/A10_root.dsq fall";
	sequence15 = "./shapes/A10_root.dsq land";

	sequence16 = "./shapes/A10_root.dsq armAttack";
	sequence17 = "./shapes/A10_root.dsq armReadyLeft";
	sequence18 = "./shapes/A10_root.dsq armReadyRight";
	sequence19 = "./shapes/A10_root.dsq armReadyBoth";
	sequence20 = "./shapes/A10_root.dsq spearready";  
	sequence21 = "./shapes/A10_root.dsq spearThrow";

	sequence22 = "./shapes/A10_root.dsq talk";  

	sequence23 = "./shapes/A10_root.dsq death1"; 
	
	sequence24 = "./shapes/A10_root.dsq shiftUp";
	sequence25 = "./shapes/A10_root.dsq shiftDown";
	sequence26 = "./shapes/A10_root.dsq shiftAway";
	sequence27 = "./shapes/A10_root.dsq shiftTo";
	sequence28 = "./shapes/A10_root.dsq shiftLeft";
	sequence29 = "./shapes/A10_root.dsq shiftRight";
	sequence30 = "./shapes/A10_root.dsq rotCW";
	sequence31 = "./shapes/A10_root.dsq rotCCW";

	sequence32 = "./shapes/A10_root.dsq undo";
	sequence33 = "./shapes/A10_root.dsq plant";

	sequence34 = "./shapes/A10_root.dsq sit";

	sequence35 = "./shapes/A10_root.dsq wrench";
	

	sequence36 = "./shapes/A10_fire.dsq fire";
};

datablock PlayerData(A10MinigunTurretPlayer)
{
   renderFirstPerson = true;
   emap = false;
   
   className = Armor;
   shapeFile = "./shapes/a10minigun.dts";
   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;


   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 0.5;
   maxFreelookAngle = 3.0;

   mass = 200000;
   drag = 1;
   density = 5;
   maxDamage = 250;
   maxEnergy =  10;
   repairRate = 0.33;

   rechargeRate = 0.4;

   runForce = 1000;
   runEnergyDrain   = 0;
   minRunEnergy     = 0;
   maxForwardSpeed  = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed     = 0;

   maxForwardCrouchSpeed  = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed     = 0;

   maxUnderwaterForwardSpeed  = 0;
   maxUnderwaterBackwardSpeed = 0;
   maxUnderwaterSideSpeed     = 0;

   jumpForce       = 0; 
   jumpEnergyDrain = 0;
   minJumpEnergy   = 0;
   jumpDelay       = 0;

   minJetEnergy   = 0;
	jetEnergyDrain = 0;
	canJet         = 0;

   minImpactSpeed   = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("2.5 2.5 1.7", 1); 
   crouchBoundingBox	= vectorScale("2.5 2.5 1.7", 1); 
   
   pickupRadius = 0.75;

	
   jetEmitter        = "";
   jetGroundEmitter  = "";
   jetGroundDistance = 4;

   footPuffNumParts = 10;
   footPuffRadius = 0.25;


   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   runSurfaceAngle  = 85;
   jumpSurfaceAngle = 86;

   minJumpSpeed = 20;
   maxJumpSpeed = 30;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;
   
   footstepSplashHeight = 0.35;

   JumpSound = "";
   
	groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "";
	rideable = true;
   lookUpLimit = 0.6;
   lookDownLimit = 0.4;

	canRide = false;
	showEnergyBar = false;
	paintable = true;

	brickImage = horseBrickImage;	//the imageData to use for brick deployment

   numMountPoints = 1;
   mountThread[0] = "root";

   //protection for passengers
   protectPassengersBurn   = true;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = false; //protect passengers from direct damage (bullets) ?

   useCustomPainEffects = true;
   PainHighImage = "";
   PainMidImage  = "";
   PainLowImage  = "";
   painSound     = "";
   deathSound    = "";
};