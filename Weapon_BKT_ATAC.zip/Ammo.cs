//=================================PISTOL AMMO===============
datablock ItemData(PistolAmmostaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "base/data/shapes/brickweapon.dts";
	mass = 2;
	density = 1.4;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Ammo, Pistol Rounds";
	doColorShift = false;
	colorShiftColor = "1 1 1 1";
	canDrop = true;
	ammocount = 5*9;
};
package PistolAmmoStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "PistolAmmostaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
			%obj.client.quantity["9mmrounds"] += 30;
			if(%obj.client.quantity["9mmrounds"] > 30*10)
			{
				%obj.client.quantity["9mmrounds"] = 30*10;
			}
			%obj.client.quantity["500rounds"] += 5;
			if(%obj.client.quantity["500rounds"] > 5*5)
			{
				%obj.client.quantity["500rounds"] = 5*5;
			}
			%obj.client.quantity["45Caliber"] += 30;
			if(%obj.client.quantity["45Caliber"] > 30*6)
			{
			%obj.client.quantity["45Caliber"] = 30*6;
			}
			%obj.client.quantity["40SWrounds"] += 30;
			if(%obj.client.quantity["40SWrounds"] > 30*8)
			{
			%obj.client.quantity["40SWrounds"] = 30*8;
			}
			%obj.client.quantity["46mmrounds"] += 40;
			if(%obj.client.quantity["46mmrounds"] > 20*6)
			{
			%obj.client.quantity["46mmrounds"] = 20*6;
			}
			%obj.client.quantity["44Prounds"] += 12;
			if(%obj.client.quantity["44Prounds"] > 12*4)
			{
			%obj.client.quantity["44Prounds"] = 12*4;
			}
			%obj.client.quantity["57rounds"] += 50;
			if(%obj.client.quantity["57rounds"] > 50*5)
			{
			%obj.client.quantity["57rounds"] = 50*5;
			}
			//serverPlay3D(AmmoGetSound,%obj.getPosition());
			if(isObject(%col.spawnbrick))
			{
				%col.fadeOut();
				%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}
			else
			{
				%col.schedule(10, delete);
			}
			%this.onPickup(%obj, %player);
			return;
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(PistolAmmoStaticPackage);

//=================================RIFLE AMMO===============
datablock ItemData(RifleAmmostaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "base/data/shapes/brickweapon.dts";
	mass = 2;
	density = 1.4;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Ammo, Rifle Rounds";
	doColorShift = false;
	colorShiftColor = "1 1 1 1";
	canDrop = true;
	ammocount = 30*2;
};
package RifleAmmoStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "RifleAmmostaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["556rounds"] += 30;
	if(%obj.client.quantity["556rounds"] > 30*15)
	{
	%obj.client.quantity["556rounds"] = 30*15;
	}
	%obj.client.quantity["762mmrounds"] += 30;
	if(%obj.client.quantity["762mmrounds"] > 30*10)
	{
	%obj.client.quantity["762mmrounds"] = 30*10;
	}
	%obj.client.quantity["545rounds"] += 45;
	if(%obj.client.quantity["545rounds"] > 15*8)
	{
	%obj.client.quantity["545rounds"] = 15*8;
	}
	%obj.client.quantity["300AProunds"] += 20;
	if(%obj.client.quantity["300AProunds"] > 20*5)
	{
	%obj.client.quantity["300AProunds"] = 20*5;
	}
	%obj.client.quantity["akrounds"] += 30;
	if(%obj.client.quantity["akrounds"] > 30*10)
	{
	%obj.client.quantity["akrounds"] = 30*10;
	}
	//serverPlay3D(somePickupSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(RifleAmmoStaticPackage);

//=================================BIG RIFLE AMMO===============
datablock ItemData(SniperAmmostaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "base/data/shapes/brickweapon.dts";
	mass = 2;
	density = 1.4;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Ammo, Big Rifle Rounds";
	doColorShift = false;
	colorShiftColor = "1 1 1 1";
	canDrop = true;
	ammocount = 5*2;
};
package SniperAmmoStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "SniperAmmostaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["408rounds"] += 7;
	if(%obj.client.quantity["408rounds"] > 7*3)
	{
	%obj.client.quantity["408rounds"] = 7*3;
	}
	%obj.client.quantity["50Cal"] += %col.getdatablock().ammocount;
	if(%obj.client.quantity["50Cal"] > 5*4)
	{
	%obj.client.quantity["50Cal"] = 5*4;
	}
	%obj.client.quantity["338rounds"] += %col.getdatablock().ammocount;
	if(%obj.client.quantity["338rounds"] > 4*7)
	{
	%obj.client.quantity["338rounds"] = 4*7;
	}
//	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(SniperAmmoStaticPackage);

//=================================SHOTGUN AMMO===============
datablock ItemData(ShotgunAmmostaticItem)
{
	category = "Weapon";
	className = "Weapon";
	shapeFile = "base/data/shapes/brickweapon.dts";
	mass = 2;
	density = 1.4;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Ammo, Shotgun Rounds";
	doColorShift = false;
	colorShiftColor = "1 1 1 1";
	canDrop = true;
	ammocount = 5*3;
};
package ShotgunAmmoStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "ShotgunAmmostaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["shotgunrounds"] += %col.getdatablock().ammocount;
	if(%obj.client.quantity["shotgunrounds"] > 6*14)
	{
	%obj.client.quantity["shotgunrounds"] = 6*14;
	}
//	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(ShotgunAmmoStaticPackage);
//=================================EXPLOSIVES AMMO===============
datablock ItemData(ExploAmmostaticItem)
{
	category = "Weapon";
	className = "Weapon";
	shapeFile = "base/data/shapes/brickweapon.dts";
	mass = 2;
	density = 1.4;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "Ammo, Explosives";
	doColorShift = false;
	colorShiftColor = "1 1 1 1";
	canDrop = true;
	ammocount = 2;
};
package ExploAmmoStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "ExploAmmostaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["20x42mmRounds"] += %col.getdatablock().ammocount;
	if(%obj.client.quantity["20x42mmRounds"] > 14)
	{
	%obj.client.quantity["20x42mmRounds"] = 14;
	}
//	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(ExploAmmoStaticPackage);
//=================================SHELL DEBRIS===============
datablock DebrisData(gunShell2Debris)
{
	shapeFile = "add-ons/weapon_gun/gunShell.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 4;
};
datablock DebrisData(bktShotgunShellDebris)
{
	shapeFile = "./shell shotgun.dts";
	lifetime = 3.5;
	minSpinSpeed = -100.0;
	maxSpinSpeed = 100.0;
	elasticity = 0.6;
	friction = 0.25;
	numBounces = 4;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;
	gravModifier = 5;
};