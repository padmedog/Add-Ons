AddDamageType("ClassicShotgun",   '<bitmap:add-ons/Weapon_Skins_Shotgun/CI_Classic_shotgun> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Shotgun/CI_Classic_shotgun> %1',0.75,1);
datablock ProjectileData(ClassicShotgunProjectile : PumpShotgunProjectile)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 9+2; //14;
   directDamageType    = $DamageType::ClassicShotgun;
};

//////////
// item //
//////////
datablock ItemData(ClassicShotgunItem : PumpShotgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	 // Basic Item Properties
	shapeFile = "./Classic_Shotgun.3.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	//gui stuff
	uiName = "Classic Shotgun";
	iconName = "./icon_Classic_shotgun";
	doColorShift = true;
	colorShiftColor = "0.41 0.33 0.26 1";
	 // Dynamic properties defined by the scripts
	image = ClassicShotgunImage;
	canDrop = true;
	maxAmmo = 7;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ClassicShotgunImage : PumpShotgunImage)
{
   // Basic Item properties
   shapeFile = "./Classic_Shotgun.1.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
   correctMuzzleVector = true;
   className = "WeaponImage";
   item = ClassicShotgunItem;
   ammo = " ";
   projectile = ClassicShotgunProjectile;
   projectileType = Projectile;
   casing = PumpShotgunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;
   doColorShift = true;
   colorShiftColor = ClassicShotgunItem.colorShiftColor;
};


function classicShotgunImage::onFire(%this,%obj,%slot)
{
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{

  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
            serverPlay3D(PumpShotgunfireSound,%obj.getPosition());
	%obj.playThread(2, activate);
	%obj.toolAmmo[%obj.currTool]--;

	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 

	%projectile = %this.projectile;
	%spread = 0.0032;
	%shellcount = 9;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	
	//shotgun blast projectile: only effective at point blank, sends targets flying off into the distance
	//
	//more or less represents the concussion blast. i can only assume such a thing exists because
	// i've never stood infront of a fucking shotgun before
	///////////////////////////////////////////////////////////

	%projectile = "shotgunBlastProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;

	//just the muzzleflash
	//
	//nothing really special about this
	///////////////////////////////////////////////////////////

	%projectile = "shotgunFlashProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;
}
	else
	{
            serverPlay3D(PumpShotgunJamSound,%obj.getPosition());
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}
}

function classicShotgunImage::onEject(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
	%obj.playThread(2, plant);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
}

function classicShotgunImage::onReloadStart(%this,%obj,%slot)
{
    if(%obj.client.quantity["shotgunrounds"] >= 1)
	{
	%obj.playThread(2, shiftto);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
}

function classicShotgunImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["shotgunrounds"] >= 1)
	{
		%obj.client.quantity["shotgunrounds"]--;
		%obj.toolAmmo[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}
}