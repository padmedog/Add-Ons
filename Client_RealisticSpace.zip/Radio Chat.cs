if($Pref::RSClient::AllowTag_Color $= "")
	$Pref::RSClient::AllowTag_Color = 2;

$RSC::Revision += 10;
package RSC_RadioChat
{
	function NMH_type::send(%this)
	{
		if(!$RSC::RealSpaceServer)
		{ Parent::send(%this); return; }
		if(NMH_Channel.getValue() !$= "\c1\c0SAY:")
		{ Parent::send(%this); return; }
		//Feel free to use team chat as an encrypted faction channel.
		//To save you some pain, no, it's not "\c1\c0TEAM:" - it's "\c1TEAM:".
		//If you make your own channels, here's the color list:
		//\c0 and \c3 are both white.
		//\c1 is magenta - seemingly the same as \c5 magenta.
		//\c2 is red, but not the same as \c0 red in chat.
		//\c4 is blue, but again, not the same as \c1 blue.
		//\c5 is purple, which doesn't map well to any of chat \c codes.
		//All four of the other color codes are \c8 black.
		if(strLen(%this.getValue()) == 0)
		{ Canvas.popDialog(NewMessageHUD); %this.setValue(""); return; }
		if(getSubStr(%this.getValue(), 0, 1) $= "/")
		{ Parent::send(%this); return; }
		%buffer = new ScriptObject() { class = "ByteArraySO"; };
		%array = new ScriptObject() { class = "ByteArraySO"; };
		%buffer.FromString($Pref::Player::ClanPrefix);
		for(%i=0;%i<3;%i++) %array.byte[-1+%array.bytes++] = %buffer.bytes;
		for(%i=0;%i<%buffer.bytes;%i++) %array.byte[-1+%array.bytes++] = %buffer.byte[%i];
		%buffer.FromString($Pref::Player::NetName);
		for(%i=0;%i<3;%i++) %array.byte[-1+%array.bytes++] = %buffer.bytes;
		for(%i=0;%i<%buffer.bytes;%i++) %array.byte[-1+%array.bytes++] = %buffer.byte[%i];
		%buffer.FromString($Pref::Player::ClanSuffix);
		for(%i=0;%i<3;%i++) %array.byte[-1+%array.bytes++] = %buffer.bytes;
		for(%i=0;%i<%buffer.bytes;%i++) %array.byte[-1+%array.bytes++] = %buffer.byte[%i];
		%buffer.FromString(%this.getValue());
		for(%i=0;%i<%buffer.bytes;%i++) %array.byte[-1+%array.bytes++] = %buffer.byte[%i];
		commandToServer('SendCommMessage', "00", %array.ToBase64());
		%buffer.delete(); %array.delete();
		Canvas.popDialog(NewMessageHUD);
		%this.setValue("");
	}
};
activatePackage("RSC_RadioChat");

//Yes. The way that names can be forged is entirely deliberate.
//Feel free to make a secured channel on, say, Channel 0xF0.

//Note: Channels 0x00 through 0x07 are reserved for official use.
//If you use these channels and your mod later breaks, it's your own fault.

function clientcmdReceiveCommMessage(%channel, %base64Data, %relativeMotion)
{
	if(%channel $= "00")
	{
		%buffer = new ScriptObject() { class = "ByteArraySO"; };
		%array = new ScriptObject() { class = "ByteArraySO"; };
		%array.FromBase64(%base64Data);
		%buffer.bytes = RSC_getTRC(%array);
		for(%i=0;%i<%buffer.bytes;%i++) %buffer.byte[%i] = %array.byte[-1+%array.pointer++];
		%clanPrefix = %buffer.ToString();
		if(%buffer.bytes > 4) %clanPrefix = getSubStr(%clanPrefix, 0, 4);
		%buffer.bytes = RSC_getTRC(%array);
		for(%i=0;%i<%buffer.bytes;%i++) %buffer.byte[%i] = %array.byte[-1+%array.pointer++];
		%name = %buffer.ToString();
		if(%buffer.bytes > 32) %name = getSubStr(%name, 0, 32);
		%buffer.bytes = RSC_getTRC(%array);
		for(%i=0;%i<%buffer.bytes;%i++) %buffer.byte[%i] = %array.byte[-1+%array.pointer++];
		%clanSuffix = %buffer.ToString();
		if(%buffer.bytes > 4) %clanSuffix = getSubStr(%clanSuffix, 0, 4);
		%buffer.bytes = %array.bytes - %array.pointer;
		for(%i=0;%i<%buffer.bytes;%i++) %buffer.byte[%i] = %array.byte[-1+%array.pointer++];
		%message = %buffer.ToString();
		%fullName = (%clanPrefix$=""?"":"\c7"@%clanPrefix)@"<color:F0F000>"@RSC_StripMLTags(%name)@(%clanSuffix$=""?"":"\c7"@%clanSuffix);
		NewChatHud_addLine("<spush><color:808080>[COMM] "@%fullName@"<color:FFFFFF>: "@ParseLinks(RSC_StripMLTags(%message))@"<spop>");
		%buffer.delete(); %array.delete();
	}
	else if(%channel $= "01")
	{
		if(!isObject(%cl = ServerConnection)) return;
		if(!isObject(%pl = %cl.getControlObject())) return;
		if(!(%pl.getType() & $Typemasks::PlayerObjectType)) return;
		
		if(!isObject(RSC_PlayerList))
			new ScriptObject(RSC_PlayerList);
		
		%array = new ScriptObject() { class = "ByteArraySO"; };
		%buffer = new ScriptObject() { class = "ByteArraySO"; };
		
		%array.FromBase64(%relativeMotion);
		%xPos = FromFloat16((%array.byte0 << 8) | %array.byte1);
		%yPos = FromFloat16((%array.byte2 << 8) | %array.byte3);
		%zPos = FromFloat16((%array.byte4 << 8) | %array.byte5);
		%xVel = FromFloat16((%array.byte6 << 8) | %array.byte7);
		%yVel = FromFloat16((%array.byte8 << 8) | %array.byte9);
		%zVel = FromFloat16((%array.byte10 << 8) | %array.byte11);
		
		%array.FromBase64(%base64Data);
		%rows = NPL_List.rowCount();
		for(%i=0;%i<%rows;%i++)
		{
			%name = getField(NPL_List.getRowText(%i), 1);
			if(%checked[%name]) continue;
			%hash = sha1(%name);
			%checked[%name] = 1;
			%buffer.FromHexadecimal(%hash);
			%dist = %array.HammingDistance(%buffer);
			if(%least $= "" || %dist < %least)
			{ %least = %dist; %final = %name; }
			else if(%dist == %least) { %final = ""; }
		}
		if(%final !$= "")
		{
			if(RSC_PlayerList.indexOf[%final] $= "")
			{
				%pos = -1+RSC_PlayerList.players++;
				RSC_PlayerList.indexOf[%final] = %pos;
				RSC_PlayerList.playerName[%pos] = %final;
			}
			else %pos = RSC_PlayerList.indexOf[%final];
			RSC_PlayerList.lastKnownTime[%pos] = getSimTime();
			%loc = vectorAdd(%pl.getPosition(), (%pl.isCrouched() ? "0 0 0.627" : "0 0 2.156"));
			RSC_PlayerList.lastKnownPos[%pos] = vectorAdd(%loc, %xPos SPC %yPos SPC %zPos);
			RSC_PlayerList.lastKnownVel[%pos] = vectorAdd(%pl.getVelocity(), %xVel SPC %yVel SPC %zVel);
		}
	}
}

function RSC_StripMLTags(%text)
{
	%foundTags = 1;
	while(%foundTags)
	{
		%foundTags = 0;
		%pos = strPos(%text, "<");
		while(%pos != -1)
		{
			%end = strPos(%text, ">", %pos);
			if(%end == -1) break;
			%tagEnd = strPos(%text, ":", %pos);
			%start = %pos + 1;
			if(%tagEnd == -1) %tag = getSubStr(%text, %start, %end - %start);
			else %tag = getSubStr(%text, %start, %tagEnd - %start);
			%pre = getSubStr(%text, 0, %pos);
			%post = getSubStr(%text, %end + 1, strLen(%text) - (%end + 1));
			if($Pref::RSClient::AllowTag_[%tag] == 1)
			{
				%foundTags = 1; %pos--;
				%text = %pre @ %post;
			}
			%pos = strPos(%text, "<", %pos + 1);
		}
	}
	%pos = strPos(%text, "<");
	%currColor = "FFFFFF";
	while(%pos != -1)
	{
		%end = strPos(%text, ">", %pos);
		if(%end == -1) break;
		%tagEnd = strPos(%text, ":", %pos);
		%start = %pos + 1;
		if(%tagEnd == -1) %tag = getSubStr(%text, %start, %end - %start);
		else %tag = getSubStr(%text, %start, %tagEnd - %start);
		%pre = getSubStr(%text, 0, %pos);
		%post = getSubStr(%text, %end + 1, strLen(%text) - (%end + 1));
		if($Pref::RSClient::AllowTag_[%tag] != 2)
		{
			%tagData = getSubStr(%text, %pos + 1, %end - %pos); %pos++;
			%text = %pre @ "<<color:"@%currColor@">" @ %tagData @ %post;
		}
		else if(%tag $= "color")
		{
			%validColor = 1;
			%tagData = getSubStr(%text, %pos + 1, %end - (%pos + 1));
			%color = restWords(strReplace(%tagData, ":", " "));
			if(mAbs(strLen(%color) - 7) == 1)
			{
				%len = strLen(%color);
				%hexMap = "0123456789ABCDEF";
				for(%i=0;%i<%len;%i++)
					if(striPos(%hexMap, getSubStr(%color, %i, 1)) == -1)
						%validColor = 0;
				if(%validColor) %currColor = %color;
			}
		}
		%pos = strPos(%text, "<", %pos + 1);
	}
	return %text;
}

function ParseLinks(%msg)
{
	%words = getWordCount(%msg);
	for(%i=0;%i<%words;%i++)
	{
		%word = getWord(%msg, %i);
		if(getSubStr(%word, 0, 7) $= "http://")
			%msg = setWord(%msg, %i, "<a:"@(%word=strReplace(%word, "http://", ""))@">"@%word@"</a>");
		else if(getSubStr(%word, 0, 8) $= "https://")
			%msg = setWord(%msg, %i, "<a:"@(%word=strReplace(%word, "https://", ""))@">"@%word@"</a>");
		else if(getSubStr(%word, 0, 6) $= "ftp://")
			%msg = setWord(%msg, %i, "<a:"@(%word=strReplace(%word, "ftp://", ""))@">"@%word@"</a>");
	}
	return trim(%msg);
}

//Triple Repetition Code. A quick way to retain information in case of partial corruption.
function RSC_getTRC(%array)
{
	for(%i=0;%i<3;%i++) %byte[%i] = %array.byte[-1+%array.pointer++];
	for(%i=0;%i<8;%i++)
	{
		%mask = 128 >> %i;   //Get the current bit mask.
		%votes = (%byte0 & %mask) + (%byte1 & %mask) + (%byte2 & %mask);   //Tally up the 'votes'.
		if(%votes >= %mask << 1) %out |= %mask;   //If the 'votes' say the bit is on, turn it on.
	}
	return %out;   //Return the final (possibly still distorted) value.
}


function RSC_TransponderPing()
{
	cancel($RSC::TransponderPing);
	if(!isObject(%cl = ServerConnection)) return;
	if(!isObject(%pl = %cl.getControlObject()) || !(%pl.getType() & $Typemasks::PlayerObjectType) || $Pref::RSClient::SilentMode)
	{ $RSC::TransponderPing = schedule(1000, 0, "RSC_TransponderPing"); return; }
	%name = $Pref::Player::NetName;
	
	%name = sha1(%name);   //Why am I using sha1?
	//Because when the name comes back, there can be distortion - so we check its Hamming distance
	//against recent hashes to see if they're within some margin of error.
	//This works better with hashes than raw names because hashes are designed to be close to statistically random.
	//Names, on the other hand, have artifacts where names can often be close together. For example:
	//xXxsonicfan1234xXx (SHA1: 521356524d902ed5d9d0f14fdea349006cc7e0af)
	//xXxsonicfan1235xXx (SHA1: 0830f7619f9cbed3a15b80fcb079d5fd9b0c3116)
	//Hamming distance of xXxsonicfan1234xXx --> xXxsonicfan1235xXx = 1 bit (0x34 [4] > 0x35 [5])
	//Hamming distance of the equivalent hashes: 83 bits, a vast improvement.
	
	%array = new ScriptObject() { class = "ByteArraySO"; };
	commandToServer('SendCommMessage', "01", %array.FromHexadecimal(%name).ToBase64());
	%array.delete(); $RSC::TransponderPing = schedule(15000, 0, "RSC_TransponderPing");
	//I chose a ping time of 15 seconds because every ping costs 0.25 battery charge.
	//Thus, a reasonable tradeoff between update time and battery consumption was necessary.
	//From 100% charge, this ping rate would deplete someone's battery completely in 1h 40m.
	//Thus, it's a slow enough drain to easily be counteracted by anyone with access to electricity
	//but accurate enough to mount a rescue mission for anyone without.
}

function RSC_UpdatePlayerMarkers()
{
	cancel($RSC_UpdatePlayerMarkers);
	$RSC_UpdatePlayerMarkers = schedule(16, 0, "RSC_UpdatePlayerMarkers");
	if(!isObject(%cl = ServerConnection)) return;
	if(!isObject(%pl = %cl.getControlObject())) return;
	if(!(%pl.getType() & $Typemasks::PlayerObjectType)) return;
	%loc = vectorSub(%pl.getPosition(), (%pl.isCrouched() ? "0 0 0.627" : "0 0 2.156"));
	%rows = NPL_List.rowCount(); %now = getSimTime();
	for(%i=0;%i<%rows;%i++)
	{
		%index = RSC_PlayerList.indexOf[getField(NPL_List.getRowText(%i), 1)];
		if(%index $= "") continue;
		%pos = RSC_PlayerList.lastKnownPos[%index]; %vel = RSC_PlayerList.lastKnownVel[%index];
		%time = vectorDist(RSC_PlayerList.lastKnownTime[%index], %now) / 1000;
		%indPos = vectorAdd(%pos, vectorScale(%vel, %time));
		%name = RSC_PlayerList.playerName[%index];
		if(%name $= $Pref::Player::NetName)
		{ %indPos = %loc; %name = ""; }
		RSC_UpdateDirMarker("Player_"@%index, %indPos, "1 1 0 "@getMin(vectorDist(%loc, %indPos) / 100, 1), %name, 0.9975);
		%updatedMarker[%index] = 1;
	}
	for(%i=0;%i<RSC_PlayerList.players;%i++)
	{
		if(!%updatedMarker[%i])
		{
			RSC_PlayerList.indexOf[RSC_PlayerList.playerName[%i]] = ""; %shift++;
			RSC_UpdateDirMarker("Player_"@%i, "DELETE");
		}
		else
		{
			RSC_PlayerList.player[%i - %shift] = RSC_PlayerList.player[%i];
			RSC_PlayerList.lastKnownPos[%i - %shift] = RSC_PlayerList.lastKnownPos[%i];
			RSC_PlayerList.lastKnownVel[%i - %shift] = RSC_PlayerList.lastKnownVel[%i];
			RSC_PlayerList.lastKnownTime[%i - %shift] = RSC_PlayerList.lastKnownTime[%i];
			RSC_PlayerList.playerName[%i - %shift] = RSC_PlayerList.playerName[%i];
			RSC_PlayerList.indexOf[RSC_PlayerList.playerName[%i]] = %i - %shift;
			RSC_PlayerList.dirMarker[%i - %shift] = RSC_PlayerList.dirMarker[%i];
			$RSC_DirMarker_Player_[%i - %shift] = $RSC_DirMarker_Player_[%i];
			RSC_PlayerList.dirMarker[%i].markerName = "Player_"@(%i - %shift);
		}
	}
	RSC_PlayerList.players -= %shift;
}
RSC_UpdatePlayerMarkers();