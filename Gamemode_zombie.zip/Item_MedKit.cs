//pill.cs

datablock ParticleData(RHealParticle)
{
   dragCoefficient      = 5.0;
   gravityCoefficient   = -0.2;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 500;
   useInvAlpha          = false;
   textureName          = "./heal";
   colors[0]     = "1.0 1.0 1.0 1";
   colors[1]     = "1.0 1.0 1.0 1";
   colors[2]     = "0.0 0.0 0.0 0";
   sizes[0]      = 0.4;
   sizes[1]      = 0.6;
   sizes[2]      = 0.4;
   times[0]      = 0.0;
   times[1]      = 0.2;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(RHealEmitter)
{
   ejectionPeriodMS = 35;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionOffset   = 1.0;
   velocityVariance = 0.49;
   thetaMin         = 0;
   thetaMax         = 120;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "RHealParticle";

   uiName = "Emote - Heal";
};

datablock ShapeBaseImageData(RHealImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = $HeadSlot;

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 0.350;
	stateEmitter[1]					= RHealEmitter;
	stateEmitterTime[1]				= 0.350;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function RHealImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

datablock ItemData(RMedKitItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./MedKit1.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "MedKit";
	iconName = "./Icons/Icon_Medkit";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = RMedKitImage;
	canDrop = true;
};

datablock ShapeBaseImageData(RMedKitImage)
{
   // Basic Item properties
   shapeFile = "./MedKit1.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "-0.55 -0.075 0.04";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "170 90 90" );

   className = "WeaponImage";
   item = RMedKitItem;

   //raise your arm up or not
   armReady = false;

   doColorShift = false;

   // Initial start up state
	stateName[0]                     = "Ready";
	stateTransitionOnTriggerDown[0]  = "Fire";
	stateAllowImageChange[0]         = true;

	stateName[1]                     = "Fire";
	stateTransitionOnTimeout[1]      = "Ready";
	stateAllowImageChange[1]         = true;
    stateScript[1]                   = "onFire";
	stateTimeoutValue[1]		   = 1;
};

datablock ShapeBaseImageData(RMedKitBackImage)
{
   // Basic Item properties
   shapeFile = "./MedKit1.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 7;
   offset = "0 -0.25 0.8";
   eyeOffset = 1; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "90 0 0" );
   armReady = false;
   doColorShift = false;
};
function RMedKitImage::onMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
	%obj.playThread(2, armreadyboth);
	if(%obj.isdowned != 1 && isobject(%obj.getmountedimage(2)) && %obj.getmountedimage(2).getname() $= "RMedKitBackImage")
	{
		%obj.unmountimage(2);
	}
}

function RMedKitImage::onUnMount(%this,%obj,%slot)
{
	Parent::onUnMount(%this,%obj,%slot);
	if(%obj.client.pack > 0)
	{
		%obj.client.pack = 0;
		%obj.client.applybodyparts();
	}
		%obj.playThread(2, root);
	if(%obj.isdowned != 1 && !isobject(%obj.getmountedimage(2)))
	{
		%obj.mountimage(RMedkitBackImage,2);
	}
	if(%obj.imHealing)
	{
		cancel(%obj.RMedKitS);
		%obj.playthread(3,undo);
		%obj.playaudio(1,errorSound);
		%obj.client.setcontrolobject(%obj);
	}
}
function RMedKitImage::onFire(%this,%obj,%slot)
{

}
function RMedKitImage::onFire2(%this,%obj,%slot)
{
	if(%obj.getDamageLevel() > 0)
	{
		for(%i=0;%i<5;%i++)
		{
			%toolDB = %obj.tool[%i];
			if(%toolDB $= %this.item.getID())
			{
				cancel(%obj.temporaryHPBleed);
				%obj.setDamageLevel(0);
				%obj.emote(RHealImage);
				%obj.tool[%i] = 0;
				%obj.weaponCount--;
				messageClient(%obj.client,'MsgItemPickup','',%i,0);
				serverCmdUnUseTool(%obj.client);
				if(%obj.isdowned != 1)
				{
					%obj.unmountimage(2);
				}
				break;
			}
		}
	}
}

function RMedKitItem::onPickup(%this,%obj,%col,%a)
{
	for(%i=0;%i<%col.getdatablock().maxTools;%i++)
	{
		%item = %col.tool[%i];
		if(%item $= 0 || %item $= "")
		{
			%freeSlot = 1;
			break;
		}
	}
	if(%obj.canpickup && %col.isdowned != 1  && !isobject(%col.getmountedimage(2)) && %freeSlot)
	{
		if(%col.client.pack > 0)
		{
			%col.client.pack = 0;
			%col.client.applybodyparts();
		}
		%col.mountimage(RMedkitBackImage,2);
	}
	parent::onPickup(%this,%obj,%col,%a);
}

package L4BMedkitPackage
{
	function servercmdDropTool(%this,%slot)
	{
		if(isobject(%this.player.tool[%slot]) && %this.player.tool[%slot].getname() $= "RMedKitItem"  && %this.player.isdowned != 1)
		{
			parent::servercmdDropTool(%this,%slot);

			if(isobject(%this.player.getmountedimage(2)) && %this.player.getmountedimage(2).getname() $= "RMedKitBackImage")
			{
				%this.player.schedule(5,unmountimage,2);
			}
			return;
		}
		parent::servercmdDropTool(%this,%slot);
	}
};
activatepackage(L4BMedkitPackage);


function RotTestFive(%client)
{
	%rot = %client.player.gettransform();
	%pos = %client.player.getposition();

	%rotf = getwords(%rot,3,5);
	%rotl = getword(%rot,6);
	%fin = %pos SPC %rotf SPC %rotl+3.14159;

	return %fin;
}

function RMedKitHealDelay(%obj)
{
	%obj.imHealing = 0;
	if(isobject(%obj) && %obj.getstate() !$= "Dead")
	{
		%obj.getmountedimage(0).onFire2(%obj);
		cancel(%obj.RMedKitS);
		%obj.playaudio(1,WeaponSwitchSound);
		%obj.playthread(3,shiftup);//%obj.client.camera.mode = "Observer";
		%obj.client.setcontrolobject(%obj);
	}
}

datablock AudioProfile(RBandageSound)
{
	filename = "./Bandage.wav";
	description = AudioClosest3d;
	preload = true;
};