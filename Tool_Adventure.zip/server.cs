%error = ForceRequiredAddOn("Weapon_Sword");

if(%error == $Error::AddOn_Disabled)
{
	swordItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
	error("ERROR: Tool_Adventure - required add-on Weapon_Sword not found");
}
else
{
	exec("./Tool_Utilize.cs");
	exec("./Tool_Pickup.cs");
	exec("./Tool_Place.cs");
	exec("./Tool_Examine.cs");
	registerInputEvent(fxDTSBrick,onUtilize,"Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");
	registerInputEvent(fxDTSBrick,onPickup,"Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");
	registerInputEvent(fxDTSBrick,onPlace,"Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");
	registerInputEvent(fxDTSBrick,onExamine,"Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");
	}