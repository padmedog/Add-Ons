datablock fxDTSBrickData ( brickPlainDoor2OpenCWData )
{
	brickFile = "./PlainDoor2openCW.blb";
	uiName = "Simple Door 2";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickPlainDoor2CWData";
	openCW = "brickPlainDoor2OpenCWData";
	
	closedCCW = "brickPlainDoor2CWData";
	openCCW = "brickPlainDoor2OpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickPlainDoor2OpenCCWData : brickPlainDoor2OpenCWData )
{
	brickFile = "./PlainDoor2openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickPlainDoor2CWData : brickPlainDoor2OpenCWData )
{
	brickFile = "./PlainDoor2closed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/SimpleDoor2";
	
	isOpen = 0;
};