$ColorSub["Unu"]=0;

$LSGTypes=0;

function GenerateLandscapeData(%xm,%ym)
{
	%SO=new ScriptObject() {class=LandScapeSO;};
	%SO.X=%xm;
	%SO.Y=%ym;
	
	for(%y=0;%y<%ym;%y++)
	{
		for(%x=0;%x<%xm;%x++)
		{
			%SO.Scape[%x,%y]=0;
		}
	}
	
	return %SO;
}

function LandscapeSO::FillLandscape(%this,%a)
{
	for(%y=0;%y<%this.y;%y++)
	{
		for(%x=0;%x<%this.x;%x++)
		{
			%this.Scape[%x,%y]=%a;
		}
	}
}

//%amt : Ammount of random spots
//%a : Changes to this
//[%b : Placed on this color]

function LandScapeSO::PlaceRandom(%this,%amt,%a,%b)
{
	%allowederrors=%amt*2;
	if(%b$="") {%ce=0;} else {%ce=1;}
	for(%i=0;%i<%amt;%i++)
	{
		%x=getRandom(0,%this.X-1);
		%y=getRandom(0,%this.Y-1);
		if(%ce)
		{
			if(%this.Scape[%x,%y]!=%b)
			{
				%i-=1;
				%errors++;
				if(%errors>%allowederrors)
				{
					break;
					echo("Error in landscape generation");
				}
				continue;
			}
		}
		%this.Scape[%x,%y]=%a;
	}
}

//%a : Changed from this
//%b : Changed to this
//%c : Should be near this
//[%d : Should be this if surrounded by %c]

function LandScapeSO::BuildAround(%this,%a,%b,%c,%d,%seed)
{
	if(%seed$="") {%seed=100;}
	for(%y=0;%y<%this.Y;%y++)
	{
		for(%x=0;%x<%this.X;%x++)
		{
			if(%this.Scape[%x,%y]!=%a) {%Scape[%x,%y]=%this.Scape[%x,%y];continue;}
			
			%up=%this.Scape[%x,%y+1];
			%down=%this.Scape[%x,%y-1];
			%left=%this.Scape[%x-1,%y];
			%right=%this.Scape[%x+1,%y];
			
			if(%d!=-1)
			{
				if(%up==%c&&%down==%c&&%left==%c&&%right==%c)
				{
					%Scape[%x,%y]=%d;
					continue;
				}
			}
			
			if(%up==%c)
			{
				if(getRandom(0,100)<=%seed)
				{
					%Scape[%x,%y]=%b;
					continue;
				}
			}
			
			if(%down==%c)
			{
				if(getRandom(0,100)<=%seed)
				{
					%Scape[%x,%y]=%b;
					continue;
				}
			}
			
			if(%left==%c)
			{
				if(getRandom(0,100)<=%seed)
				{
					%Scape[%x,%y]=%b;
					continue;
				}
			}
			
			if(%right==%c)
			{
				if(getRandom(0,100)<=%seed)
				{
					%Scape[%x,%y]=%b;
					continue;
				}
			}
			%Scape[%x,%y]=%this.Scape[%x,%y];
		}
	}
	
	for(%y=0;%y<%this.Y;%y++)
	{
		for(%x=0;%x<%this.X;%x++)
		{
			%this.Scape[%x,%y]=%Scape[%x,%y];
		}
	}
}

function LandScapeSO::PreviewLandscape(%this)
{
	LSG_Preview.clear();
	if($LSG_PM==0)
	{
		for(%y=0;%y<%this.Y;%y++)
		{
			for(%x=0;%x<%this.X;%x++)
			{
				%b=new GuiBitmapButtonCtrl("LSG_Scape_"@%x@"_"@%y)
				{
					profile = "GuiDefaultProfile";
					horizSizing = "left";
					vertSizing = "top";
					position = %x*16 SPC %y*16;
					extent = 16 SPC 16;
					minExtent = "8 2";
					visible = "1";
					command = "EditPreviewColor(\""@%x SPC %y@"\");";
					text = " ";
					groupNum = "-1";
					buttonType = "PushButton";
					bitmap = "./Buttons/Button";
					lockAspectRatio = "0";
					alignLeft = "0";
					overflowImage = "0";
					mKeepCached = "0";
				};
				%b.setColor($ColorTable[$ColorSub[%this.Scape[%x,%y]]]);
				LSG_Preview.add(%b);
			}
		}
	}
	else if($LSG_PM==1)
	{
		for(%y=0;%y<%this.Y;%y++)
		{
			for(%x=0;%x<%this.X;%x++)
			{
				LSG_Preview.addPixel(%x*16 SPC %y*16,$ColorTable[$ColorSub[%this.Scape[%x,%y]]]);
			}
		}
	}
	LSG_Preview.resize(5,30,%this.X*16,%this.Y*16);
}

function BBZ(%count,%o)
{
	for(%i=0;%i<%count;%i++)
	{
		commandtoserver('plantbrick');
		commandtoserver('shiftbrick',0,0,%o);
	}
	commandtoserver('shiftbrick',0,0,-%count*%o);
}

function LandScapeSO::BuildLandscape(%this,%sx,%sy,%sz,%zcnt,%zo)
{
	if(%zcnt*1<=0) {%zcnt=1;%zo=0;}
	for(%y=0;%y<%this.Y;%y++)
	{
		for(%x=0;%x<%this.X;%x++)
		{
			commandtoserver('useSprayCan',$ColorSub[%this.Scape[%x,%y]]);
			commandToServer('useInventory',0);
			for(%i=0;%i<$HSub[%this.Scape[%x,%y]];%i++)
			{
				BBZ(%zcnt,%zo);
				commandtoserver('shiftbrick',0,0,%sz);
			}
			commandToServer('useInventory',$BSub[%this.Scape[%x,%y]]);
			commandtoserver('useSprayCan',$ColorSub[%this.Scape[%x,%y]]);
			BBZ(%zcnt,%zo);
			commandtoserver('shiftbrick',%sx,0,-$HSub[%this.Scape[%x,%y]]*%sz);
		}
		commandtoserver('shiftbrick',-%this.X*%sx,%sy,0);
	}
}

function LandScapeSO::SaveLandscape(%this,%file)
{
	%fo=new FileObject();
	%fo.openForWrite(%file);
	%fo.writeLine(%this.x SPC %this.y);
	for(%y=0;%y<%this.Y;%y++)
	{
		%str="";
		for(%x=0;%x<%this.X;%x++)
		{
			%str=%str@$LandSub[%this.Scape[%x,%y]];
		}
		%fo.writeLine(%str);
	}
	%fo.close();
	%fo.delete();
}

function LSG_LoadLandscape(%file)
{
	%fo=new FileObject();
	%fo.openForRead(%file);
	%dim=%fo.readLine();
	%x=getWord(%dim,0);
	%y=getWord(%dim,1);
	%scape=GenerateLandscapeData(%x,%y);
	%yv=0;
	while(!%fo.isEOF())
	{
		%line=%fo.readLine();
		for(%i=0;%i<strLen(%line);%i++)
		{
			%char=getSubStr(%line,%i,1);
			%scape.Scape[%i,%yv]=$ILandSub[%char];
		}
		%yv++;
	}
	%fo.close();
	%fo.delete();
	return %scape;
}

function LandscapeSO::Process(%this,%data)
{
	%cnt=getRecordCount(%data);
	for(%i=0;%i<%cnt;%i++)
	{
		%curLine=SubLSGVar(getRecord(%data,%i));
		switch$(getWord(%curLine,0))
		{
			case "Repeat":
				%PC=getWord(%curLine,1);
				%i++;
				%ln=0;
				%str="";
				while(1)
				{
					%wrd=getWord(%curLine=getRecord(%data,%i),0);
					if(%wrd$="Repeat")
					{
						%ln++;
					}
					if(%wrd$="Finish")
					{
						%ln--;
						if(%ln<0)
						{
							%i++;
							break;
						}
					}
					
					if(%str$="")
					{
						%str=%curLine;
					}
					else
					{
						%str=%str NL %curLine;
					}
					%i++;
				}
				for(%e=0;%e<%PC;%e++)
				{
					%this.Process(%str);
				}
			case "FillMap":
				%this.FillLandscape(getWord(%curLine,1));
			case "PlaceRandom":
				%this.PlaceRandom(getWord(%curLine,1),getWord(%curLine,2),getWord(%curLine,3));
			case "PlaceAround":
				%this.BuildAround(getWord(%curLine,1),getWord(%curLine,2),getWord(%curLine,3),getWord(%curLine,4),getWord(%curLine,5));
			case "Echo":
				echo(getWords(%curLine,1));
		}
	}
}

function SubLSGVar(%var)
{
	for(%i=0;%i<$LSGMethodVars;%i++)
	{
		%var=strReplace(%var,$LSGMethodRepStr[%i],("LSG_M_"@$LSGMethodVars[%i]).getValue());
	}
	return %var;
}

//GUI
if (!$LSGM)
{
	$remapDivision[$remapCount] = "Landscape Generator";
	$remapName[$remapCount] = "Open GUI";
	$remapCmd[$remapCount] = "LSG_OG";
	$remapCount++;
	$LSGM = true;
}

function LSG_OG()
{
	canvas.pushdialog(LSG_Gui);
}

function LSG_Gui::OnWake(%this)
{
	LSG_ReloadSettings();
}

function LSG_ReloadSettings()
{
	//Method Settings
	if($LSGMethod$="") {LSG_LoadMethod("");}
	
	//Color Settings
	for(%i=0;%i<65&&1+0*(%a=getColorIDTable(%i));%i++)
	{
		$ColorTable[%i]=%a;
	}
	
	LSG_CS.clear();
	for(%i=0;%i<$LSGTypes;%i++)
	{
		%t=LSG_AddGuiText(5 SPC %i*20,"["@$LandSub[%i]@"] "@$LSGTypeName[%i]);
		LSG_CS.add(%t);
		%b=LSG_AddColorButton(155 SPC %i*20,"18 18",$ColorTable[$ColorSub[%i]],"LSGGui_EditColor(\""@155 SPC %i*20@"\","@%i@");");
		LSG_CS.add(%b);
		%te=new GuiTextEditCtrl("LSG_BS_"@%i)
		{
			profile = "GuiTextEditProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "120 "@%i*20;
			extent = "30 18";
			minExtent = "8 2";
			visible = "1";
			text = $BSub[%i];
			Command="$BSub["@%i@"]=LSG_BS_"@%i@".getValue();";
			maxLength = "255";
			historySize = "0";
			password = "0";
			tabComplete = "0";
			sinkAllKeyEvents = "0";
		};
		%te.setValue($BSub[%i]);
		LSG_CS.add(%te);
		
		%te=new GuiTextEditCtrl("LSG_HS_"@%i)
		{
			profile = "GuiTextEditProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "85 "@%i*20;
			extent = "30 18";
			minExtent = "8 2";
			visible = "1";
			text = $HSub[%i];
			Command="$HSub["@%i@"]=LSG_HS_"@%i@".getValue();";
			maxLength = "255";
			historySize = "0";
			password = "0";
			tabComplete = "0";
			sinkAllKeyEvents = "0";
		};
		%te.setValue($HSub[%i]);
		LSG_CS.add(%te);
	}
	LSG_RCS();
	
}

function LSG_AddColorButton(%pos,%ext,%col,%cmd)
{
	%n=new GuiSwatchCtrl()
	{
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = %pos;
		extent = %ext;
		minExtent = "8 2";
		visible = "1";
		color = %col;

		new GuiBitmapButtonCtrl()
		{
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "0 0";
			extent = %ext;
			minExtent = "8 2";
			visible = "1";
			command = %cmd;
			text = " ";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "base/client/ui/btnColor";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			mKeepCached = "0";
			mColor = "255 255 255 255";
		};
	};
	%n.setColor(%col);
	return %n;
}

function LSG_AddGuiText(%pos,%text)
{
	%t=new GuiTextCtrl()
	{
		profile = "GuiTextProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = %pos;
		extent = "0 18";
		minExtent = "8 2";
		visible = "1";
		text = %text;
		maxLength = "255";
	};
	return %t;
}

function LSG_RCS()
{
	%maxx=0;
	%maxy=0;
	
	%cnt=LSG_CS.getCount();
	for(%i=0;%i<%cnt;%i++)
	{
		%obj=LSG_CS.getObject(%i);
		
		%pos=%obj.getPosition();
		%ext=%obj.getExtent();
		
		%x=getWord(%pos,0)+getWord(%ext,0);
		%y=getWord(%pos,1)+getWord(%ext,1);
		
		if(%x>%maxX) {%maxX=%x;}
		if(%y>%maxY) {%maxY=%y;}
	}
	
	LSG_CS.resize(0,0,%maxX,%maxY);
}

function LSGPreviewGui::onWake(%this)
{
	$Scape.previewLandScape();
	if($LSG_PM==1)
	{
		LSG_Palette.clear();
	}
	else
	{
		LSG_ReloadSymbols();
	}
	$Palette=0;
}

function GuiSwatchCtrl::addPixel(%this,%pos,%col)
{
	%n=new GuiSwatchCtrl()
	{
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = %pos;
		extent = "16 16";
		minExtent = "8 2";
		visible = "1";
		color = %col;
	};%this.add(%n);
	%n.setColor(%col);
}

function LSGGui_Create(%x,%y)
{
	$Scape=GenerateLandscapeData(%x,%y);
}

function LSGGui_Generate()
{
	$Scape.Process($LSGMethodE);
}

function LSGGui_Save(%file)
{
	$Scape.saveLandScape("config/LSG/Land/"@%file);
}

function LSGGui_Load(%file)
{
	$Scape=LSG_LoadLandscape("config/LSG/Land/"@%file);
}

function LSGGui_Build()
{
	$Scape.BuildLandscape(LSG_XO.getValue(),LSG_YO.getValue(),LSG_ZO.getValue(),LSG_ZIC.getValue(),LSG_ZIO.getValue());
}

function LSGGui_EditColor(%pos,%ind)
{
	ShowLSGColorDlg(%ind,%pos);
}

function ShowLSGColorDLG(%ind)
{
	canvas.pushDialog(LSGCGui);
	LSGC_ReloadColors(%ind);
}

function LSGC_ReloadColors(%ind)
{
	LSGC_ColorList.clear();
	LSGC_ColorList.resize(0,0,128,128);
	%x=0;
	%y=0;
	for(%i=0;%i<64;%i++)
	{
		if(%x>7) {%x=0;%y++;}
		%b=LSG_AddColorButton(%x*16 SPC %y*16,"16 16",$ColorTable[%i],"CloseLSGColorDlg(\""@%ind@"\",\""@%i@"\");");
		LSGC_ColorList.add(%b);
		%x++;
	}
}

function LSG_ReloadSymbols()
{
	LSG_Palette.clear();
	%x=0;
	%y=0;
	for(%i=0;%i<$LSGTypes;%i++)
	{
		if(%x>((360/16)-1)) {%x=0;%y++;}
		%b=LSG_AddColorButton(%x*16 SPC %y*16,"16 16",$ColorTable[$ColorSub[%i]],"$Palette="@%i@";");
		LSG_Palette.add(%b);
		%x++;
	}
}

function CloseLSGColorDlg(%ind,%col)
{
	canvas.popDialog(LSGCGui);
	$ColorSub[%ind]=%col;
	LSG_ReloadSettings();
}

function CloseLSGColorDlgB(%ind,%col)
{
	%x=getWord(%ind,0);
	%y=getWord(%ind,1);
	$Scape.Scape[%x,%y]=%col;
	("LSG_Scape_"@%x@"_"@%y).setColor($ColorTable[$ColorSub[%col]]);
}

function EditPreviewColor(%xy)
{
	CloseLSGColorDlgB(%xy,$Palette);
}

//Methods
function LSG_LoadMethod(%f)
{
	%f="Add-ons/Client_LandscapeGenerator/Methods/"@%f;
	
	if(!isFile(%f)){%f="Add-ons/Client_LandscapeGenerator/Methods/Main.txt";}
	
	$LSGMethod=%f;LSG_Method.setValue("<color:FFFFFF>Method:" SPC fileName(%f));
	
	DATA_ReadFile(%f,"LSG_Method",0);
	
	LSG_MethodSW.clear();
	
	for(%i=0;%i<$LSGMethodVars;%i++)
	{
		%b=new GuiTextEditCtrl("LSG_M_"@$LSGMethodVars[%i])
		{
			profile = "GuiTextEditProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "80 "@%i*20;
			extent = "80 18";
			minExtent = "8 2";
			visible = "1";
			text = $LSGMethodVar[%i];
			maxLength = "255";
			historySize = "0";
			password = "0";
			tabComplete = "0";
			sinkAllKeyEvents = "0";
		};
		%t=LSG_AddGuiText(1 SPC %i*20,$LSGMethodVars[%i]);
		
		LSG_MethodSW.add(%t);
		LSG_MethodSW.add(%b);
	}
	LSG_SWR();
}

function LSG_Method_addCAT(%cat)
{
	//Nothing
}

function LSG_Method_addVAL(%var,%val)
{
	//Nothing
}

function LSG_Method_addMAP(%var,%val)
{
	switch$(%var)
	{
		case "Var":
			$LSGMethodVars=0;
			%cnt=getRecordCount(%val);
			for(%i=0;%i<%cnt;%i++)
			{
				$LSGMethodVars[$LSGMethodVars]=getWord(getRecord(%val,%i),0);
				$LSGMethodVar[$LSGMethodVars]=getWord(getRecord(%val,%i),1);
				$LSGMethodRepStr[$LSGMethodVars]=getWord(getRecord(%val,%i),2);
				$LSGMethodVars++;
			}
		case "Method":
			$LSGMethodE=%val;
		case "Types":
			$LSGTypes=0;
			%cnt=getRecordCount(%val);
			for(%i=0;%i<%cnt;%i++)
			{
				$LSGTypeName[$LSGTypes]=getWord(getRecord(%val,%i),0);
				$ColorSub[$LSGTypes]=getWord(getRecord(%val,%i),1);
				$LandSub[$LSGTypes]=getWord(getRecord(%val,%i),2);
				$ILandSub[getWord(getRecord(%val,%i),2)]=$LSGTypes;
				$HSub[$LSGTypes]=getWord(getRecord(%val,%i),3);
				$BSub[$LSGTypes]=getWord(getRecord(%val,%i),4);
				$LSGTypes++;
			}
	}
}

function LSG_SWR()
{
	%maxx=0;
	%maxy=0;
	
	%cnt=LSG_MethodSW.getCount();
	for(%i=0;%i<%cnt;%i++)
	{
		%obj=LSG_MethodSW.getObject(%i);
		
		%pos=%obj.getPosition();
		%ext=%obj.getExtent();
		
		%x=getWord(%pos,0)+getWord(%ext,0);
		%y=getWord(%pos,1)+getWord(%ext,1);
		
		if(%x>%maxX) {%maxX=%x;}
		if(%y>%maxY) {%maxY=%y;}
	}
	
	LSG_MethodSW.resize(0,0,%maxX,%maxY);
}

function LSGGui_LoadMethod(%f)
{
	LSG_LoadMethod(%f);
	LSG_ReloadSettings();
}

function LSG_TempBrickSize()
{
	%datablock=$BSD_InvData[$CurrScrollBrickSlot];
	LSG_XO.setValue(%datablock.brickSizeX);
	LSG_YO.setValue(%datablock.brickSizeY);
	LSG_ZO.setValue(%datablock.brickSizeZ);
}

function LSG_searchFile::onWake(%t)
{
	LSG_ListMethods();
}

function LSG_SelectMethod(%val)
{
	LSG_File.setValue(%val);
	canvas.popDialog(LSG_searchFile);
}

function LSG_ListMethods()
{
	%mask="Add-ons/Client_LandscapeGenerator/Methods/*";
	LSG_MList.clear();
	%f=findFirstFile(%mask);
	%i=0;
	while(isFile(%f))
	{
		LSG_MList.addRow(%i,fileName(%f));
		%i++;
		%f=findNextFile(%mask);
	}
}