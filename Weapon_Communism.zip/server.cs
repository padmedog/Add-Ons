datablock AudioProfile(Dual_CommieShot1Sound)
{
	filename	 = "./sound/commieShot.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(Dual_CommieSickleHitSound)
{
	filename	 = "./sound/commieHit.wav";
	description = AudioClose3d;
	preload = true;
};

datablock DebrisData(Dual_CommieShellDebris)
{
	shapeFile = "./shapes/sickleDebris.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ParticleData(Dual_CommieFireParticle)
{
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	constantAcceleration = 0.0;
	lifetimeMS			  = 40;
	lifetimeVarianceMS	= 0;
	textureName			 = "base/data/particles/star1";
	spinSpeed		  = 9000.0;
	spinRandomMin		  = -5000.0;
	spinRandomMax		  = 5000.0;

	colors[0]	  = "1.0 0.5 0 0.9";
	colors[1]	  = "0.9 0.4 0 0.8";
	colors[2]	  = "1 0.5 0.2 0.6";
	colors[3]	  = "1 0.5 0.2 0.4";

	sizes[0]		= 1.5;
	sizes[1]		= 0.3;
	sizes[2]		= 0.1;
	sizes[3]		= 0.0;

	times[0] = 0.0;
	times[1] = 0.1;
	times[2] = 0.5;
	times[3] = 1.0;

	 useInvAlpha = false;
};

datablock ParticleEmitterData(Dual_CommieFireEmitter)
{
	ejectionPeriodMS = 1;
	periodVarianceMS = 0;
	ejectionVelocity = 74.0;
	velocityVariance = 0.0;
	ejectionOffset	= 0.0;
	thetaMin			= 0;
	thetaMax			= 1;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;

	particles = "Dual_CommieFireParticle";
};

datablock ParticleData(Dual_CommieExplosionParticle)
{
	dragCoefficient		= 8;
	gravityCoefficient	= -0.5;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 50;
	lifetimeVarianceMS	= 35;
	textureName			 = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	  = "1 1 0.0 0.9";
	colors[1]	  = "0.9 0.0 0.0 0.0";
	sizes[0]		= 2;
	sizes[1]		= 0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(Dual_CommieExplosionEmitter)
{
	lifeTimeMS = 50;

	ejectionPeriodMS = 3;
	periodVarianceMS = 0;
	ejectionVelocity = 0;
	velocityVariance = 0.0;
	ejectionOffset	= 0.0;
	thetaMin			= 89;
	thetaMax			= 90;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "Dual_CommieExplosionParticle";

	useEmitterColors = true;
};

datablock ExplosionData(Dual_CommieExplosion)
{
	//explosionShape = "";
	soundProfile = Dual_CommieSickleHitSound;

	lifeTimeMS = 150;
	
	debris = Dual_CommieShellDebris;
	debrisNum = 1;
	debrisNumVariance = 0;
	debrisPhiMin = 0;
	debrisPhiMax = 360;
	debrisThetaMin = 45;
	debrisThetaMax = 115;
	debrisVelocity = 18;
	debrisVelocityVariance = 8;

	particleEmitter = Dual_CommieExplosionEmitter;
	particleDensity = 5;
	particleRadius = 0.2;


	faceViewer	  = true;
	explosionScale = "1 1 1";

	shakeCamera = false;
	camShakeFreq = "10.0 11.0 10.0";
	camShakeAmp = "1.0 1.0 1.0";
	camShakeDuration = 0.5;
	camShakeRadius = 10.0;

	// Dynamic light
	lightStartRadius = 2;
	lightEndRadius = 2;
	lightStartColor = "0.5 0.8 0.9";
	lightEndColor = "0 0 0";
};

AddDamageType("Dual_Commie",	'<bitmap:add-ons/Weapon_Communism/shapes/CI_Russian> %1',	 '%2 <bitmap:add-ons/Weapon_Communism/shapes/CI_Russian> %1',0.05,1);
datablock ProjectileData(Dual_CommieProjectile)
{
	projectileShapeName = "./shapes/sickle.dts";
	directDamage		  = 30;
	directDamageType	 = $DamageType::Dual_Commie;
	radiusDamageType	 = $DamageType::Dual_Commie;

	brickExplosionRadius = 0;
	brickExplosionImpact = false;
	brickExplosionForce  = 10;
	brickExplosionMaxVolume = 1;
	brickExplosionMaxVolumeFloating = 2;

	impactImpulse		  = 0;
	verticalImpulse	  = 0;
	explosion			  = Dual_CommieExplosion;
	particleEmitter	  = "";

	muzzleVelocity		= 90;
	velInheritFactor	 = 1;

	armingDelay			= 00;
	lifetime				= 4000;
	fadeDelay			  = 3500;
	bounceElasticity	 = 0.5;
	bounceFriction		= 0.20;
	isBallistic			= false;
	gravityMod = 0.0;

	hasLight	 = false;
	lightRadius = 3.0;
	lightColor  = "0 0 0.5";

	uiName = "Russain Sickle";
};

//////////
// item //
//////////
datablock ItemData(Dual_CommieItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./shapes/COMMUNISM.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "DUAL COMMUNISM";
	iconName = "./shapes/dualcommie";
	doColorShift = true;
	colorShiftColor = "0.7 0.8 0.7 1.000";

	 // Dynamic properties defined by the scripts
	image = Dual_CommieImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(Dual_CommieImage)
{
	shapeFile = "./shapes/COMMUNISM.dts";
	emap = true;
	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );
	correctMuzzleVector = true;
	className = "WeaponImage";
	item = BowItem;
	ammo = " ";
	projectile = Dual_CommieProjectile;
	projectileType = Projectile;
	melee = false;
	armReady = true;

	doColorShift = true;
	colorShiftColor = Dual_CommieItem.colorShiftColor;
	
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
	stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.09;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = Dual_CommieShot1Sound;
	stateEmitter[2]					= Dual_CommieFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

	stateName[3] = "Smoke";
	stateTransitionOnTimeout[3]	  = "Reload";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "FireAkimbo";
	stateSequence[4] = "ready";

	stateName[5] = "FireAkimbo";
	stateTimeoutValue[5] = 0.09;
	stateScript[5] = "onFireAkimbo";
	stateTransitionOnTimeOut[5] = "ready";
};


function Dual_CommieImage::onFireAkimbo(%this,%obj,%slot)
{
	%obj.setImageTrigger(1,1);
}

datablock ShapeBaseImageData(Left_Dual_CommieImage)
{
	shapeFile = "./shapes/COMMUNISM.dts";
	emap = true;
	mountPoint = 1;
	offset = "0 0 0";
	eyeOffset = 0; 
	rotation = eulerToMatrix( "0 0 0" );
	correctMuzzleVector = true;
	className = "WeaponImage";
	item = BowItem;
	ammo = " ";
	projectile = Dual_CommieProjectile;
	projectileType = Projectile;
	melee = false;
	armReady = false;
	doColorShift = true;
	colorShiftColor = Dual_CommieItem.colorShiftColor;

	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";
	stateSound[0]		= weaponSwitchSound;

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
	stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.09;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = Dual_CommieShot1Sound;
	stateEmitter[2]					= Dual_CommieFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

	stateName[3] = "Smoke";
	stateTransitionOnTimeout[3]	  = "Reload";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "Ready";
	stateSequence[4] = "ready";
};

function Left_Dual_CommieImage::onFire(%this, %obj, %slot)
{
	Parent::onFire(%this,%obj,%slot);
	if(%obj.getDamagePercent() < 1.0)
	{
		%obj.playThread(2, leftrecoil);
		%obj.playThread(0, plant);
	}
}

function Dual_CommieImage::onMount(%this, %obj, %slot)
{
	Parent::onMount(%this, %obj, %slot);
	%obj.mountImage(Left_Dual_CommieImage, 1);
}

function Dual_CommieImage::onUnMount(%this, %obj, %slot)
{
	Parent::onUnMount(%this, %obj, %slot);
	%obj.unMountImage(1);
}

function Left_Dual_CommieImage::onMount(%this, %obj, %slot)
{
	Parent::onMount(%this, %obj, %slot);
	%obj.playThread(1, armreadyboth);
}

function Left_Dual_CommieImage::onUnMount(%this, %obj, %slot)
{
	Parent::onUnMount(%this, %obj, %slot);
}

function Dual_CommieImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
	{
		%obj.playThread(2, shiftAway);
		%obj.playThread(0, plant);
	}
	Parent::onFire(%this,%obj,%slot);	
}
