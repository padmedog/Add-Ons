This module is dependent on getName and zoomImage
To load this module, execute getfile.cs
