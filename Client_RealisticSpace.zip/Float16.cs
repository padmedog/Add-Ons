function ToFloat16(%val)
{
	if(%val == 0) return 0;
	if(%val $= "1.#INF") return 31744;   //Positive Infinity
	if(%val $= "-1.#INF") return 64512;   //Negative Infinity
	if(%val $= "-1.#IND") return 65535;   //Not a Number
	%val *= %sign = (%val < 0 ? -1 : 1);
	%exp = mFloor(mLog(%val) / mLog(2)) + 15;
	if(%exp >= 31) return (%sign == -1 ? 64512 : 31744);   //�Infinity
	%dec = mPow(2, %exp - 15);
	%val -= %dec; %dec /= 2;
	for(%i=0;%i<10;%i++)
	{
		if(%val >= %dec)
		{
			%val -= %dec;
			%mant |= 512 >> %i;
		}
		%dec /= 2;
	}
	if(%val >= %dec)
	{
		%mant = (%mant + 1) & 1023; if(%mant == 0) %exp++;
		if(%exp >= 31)  return (%sign == -1 ? 64512 : 31744);   //�Infinity
	}
	return (%sign == -1 ? 32768 : 0) | (%exp << 10) | %mant;
}

function FromFloat16(%val)
{
	%sign = %val & 32768 ? -1 : 1;
	%exp = (%val & 31744) >> 10;
	if(%exp == 31)
	{
		if(%val & 1023) return "-1.#IND";
		else if(%sign == -1) return "-1.#INF";
		else return "1.#INF";
	}
	if(%exp == 0) %mant = (%val & 1023) / 512;
	else %mant = (1024 | (%val & 1023)) / 1024;
	return %sign * %mant * mPow(2, %exp - 15);
}