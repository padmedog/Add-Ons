//zombie spawn brick

datablock fxDTSBrickData (ZombieSpawnData)
{
	brickFile = "./zombiespawn.blb";
	category = "Special";
	subCategory = "Zombie Bricks";
	uiName = "Zombie Spawn";
	iconName = "add-ons/gamemode_zombie/Icons/Icon_ZombieSpawn";

	bricktype = 2;
	cancover = 0;
	orientationfix = 1;
	specialbricktype = "VehicleSpawn";
	indestructable = 1;
};
function RotVehicleDelay(%obj)
{
	%obj.mountingrotdelay =0;
}

$zombie::ammo::Listcount = 0;
$zombie::ammo::Gun[$zombie::ammo::Listcount++] = GunProjectile;
$zombie::ammo::AmmoGunProjectile = 60;
$zombie::ammo::Gun[$zombie::ammo::Listcount++] = AkimboGunProjectile;
$zombie::ammo::AmmoAkimboGunProjectile = 100;
$zombie::ammo::Gun[$zombie::ammo::Listcount++] = RocketLauncherProjectile;
$zombie::ammo::AmmoRocketLauncherProjectile = 20;
$zombie::ammo::Gun[$zombie::ammo::Listcount++] = SniperRifleProjectile;
$zombie::ammo::AmmoSniperRifleProjectile = 40;
$zombie::ammo::Gun[$zombie::ammo::Listcount++] = MiniGunProjectile;
$zombie::ammo::AmmoMiniGunProjectile = 200;
$zombie::ammo::Gun[$zombie::ammo::Listcount++] = ShotgunProjectile;
$zombie::ammo::AmmoShotgunProjectile = 40;

registerInputEvent("fxDTSBrick", "onZombieDeath",  "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");


function fxDTSBrick::onZombieDeath(%obj, %client)
{
   //setup targets
   //player = person who destroyed it
   $InputTarget_["Self"]   = %obj;
   $InputTarget_["Player"] = %client.player;
   $InputTarget_["Client"] = %client;

   if($Server::LAN)
   {
      $InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
   }
   else
   {
      if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
         $InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
      else
         $InputTarget_["MiniGame"] = 0;
   }
   //process the event
   %obj.processInputEvent("onZombieDeath", %client);
}

registerOutputEvent("Minigame", "ZombieDirector", "list Start 0 Stop 1 Panic_Start 2 Panic_Stop 3 Tank_Event 4 Witch_Event 5");

function MiniGameSO::ZombieDirector(%minigame,%a,%b,%c)
{	
	if(%a == 0)
	{
		cancel(%minigame.ZSS);
		%minigame.ZSS = schedule(2000,0,ZombieSpawnSearchLoop,%minigame);
	}
	if(%a == 1)
	{
		cancel(%minigame.ZSS);
	}
	if(%a == 2)
	{
		%minigame.play2dSoundAll("HordeIncoming" @ getrandom(1,4) @ "Sound");
		%minigame.ZombieIsPanic = 1;
		cancel(%minigame.ZPS);
		%minigame.LastDirectorEvent = getsimtime();
	}
	if(%a == 3)
	{
		ZombiePanicSchedule(%minigame);
		//%minigame.ZombieIsPanic = 0;
	}
	if(%a == 4)
	{
		TankEvent(%minigame);
	}
	if(%a == 5)
	{
		WitchEvent(%minigame);
	}
	//cancel(%minigame.ZSSP);
	//%minigame.ZombieIsPanic = %a;
	//%minigame.ZSSP = schedule(%a*1000,0,ZombiePanicSchedule,%minigame);
	//cancel(%minigame.ZSS);
	//%minigame.ZSS = schedule(2000,0,ZombieSpawnSearchLoop,%minigame);
}


datablock AudioProfile(NoAmmoClickSound)
{
   filename    = "./GunNoAmmoClick.wav";
   description = AudioClose3d;
   preload = true;
};
datablock ShapeBaseImageData(gunImageNoFire)
{
   shapeFile = "add-ons/weapon_gun/pistol.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
   correctMuzzleVector = true;
   className = "WeaponImage";
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = gunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   RWep = "gunImage";
   // Initial start up state
   stateName[0]                    		= "Ready";
   stateTransitionOnTriggerDown[0] 		= "Fire";
   stateAllowImageChange[0]             = true;

   stateName[1]                    		= "Fire";
   stateSound[1]			  	= NoAmmoClickSound;
   stateScript[1]                  = "onFire";
   stateTransitionOnTimeout[1]     		= "Ready";
   stateTimeoutValue[1]            		= 0.5;

};

datablock ShapeBaseImageData(AkimbogunImageNoFire : gunImageNoFire)
{
	shapeFile = "Add-Ons/Weapon_Gun/pistol.dts";
	RWep = "AkimbogunImage";
	projectile = AkimbogunProjectile;
	doColorShift = true;
    colorShiftColor = AkimboGunItem.colorShiftColor;//"0.400 0.196 0 1.000";
};
datablock ShapeBaseImageData(LeftHandedGunImageNoFire : gunImageNoFire)
{
	shapeFile = "Add-Ons/Weapon_Gun/pistol.dts";
	RWep = "AkimbogunImage";
	mountPoint = 1;
	projectile = AkimbogunProjectile;
	doColorShift = true;
    colorShiftColor = AkimboGunItem.colorShiftColor;//"0.400 0.196 0 1.000";
};
function AkimboGunImageNoFire::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftHandedGunImageNoFire, 1);
   //%obj.playThread(0, armreadyboth);
}
function AkimboGunImageNoFire::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.unmountimage(1);
   //%obj.playThread(0, armreadyboth);
}
datablock ShapeBaseImageData(RocketLauncherImageNoFire : gunImageNoFire)
{
	shapeFile = "Add-Ons/Weapon_Rocket Launcher/RocketLauncher.dts";
	RWep = "RocketLauncherImage";
	projectile = RocketLauncherProjectile;
	doColorShift = RocketLauncherItem.doColorShift;
    colorShiftColor = RocketLauncherItem.colorShiftColor;//"0.400 0.196 0 1.000";
};

function HideZombieSpawns(%client)
{
	%ccount = %client.brickgroup.getcount(); 
	for(%a = 0; %a <= %ccount; %a++)
	{
		if(%client.brickgroup.getobject(%a).getdatablock().Getname() $= "ZombieSpawnData")
		{ 
			%client.brickgroup.getobject(%a).disappear(-1);
		}
	}
}
function servercmdHideZombieSpawns(%client)
{
	if(%client.isadmin || %client.isSuperAdmin)
	{
		HideZombieSpawns(%client);
	}
}