//weapon_hookshot.cs
//bow and arrow weapon stuff
$hsinstall = 1;
datablock AudioProfile(hookshotExplosionSound)
{
   filename    = "./sound/arrowHit.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(hookshotFireSound)
{
   filename    = "./sound/TP_Clawshot_Fire.wav";
   description = AudioClosest3d;
   preload = true;
};


//arrow trail
datablock ParticleData(hookshotTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 2000;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/ring";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 1 0.2";
	colors[1]	= "1 1 1 0.0";
	sizes[0]	= 0.2;
	sizes[1]	= 0.01;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(hookshotTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = hookshotTrailParticle;
};

//effects
datablock ParticleData(hookshotExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "base/data/particles/chunk";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.6 0.9";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(hookshotExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "hookshotExplosionParticle";
};

datablock ExplosionData(hookshotExplosion)
{
   //explosionShape = "";
	soundProfile = hookshotExplosionSound;

   lifeTimeMS = 150;

   particleEmitter = hookshotExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};


//projectile
AddDamageType("HookshotDirect",   '<bitmap:add-ons/Weapon_Loz_Hookshot/ci/arrow> %1',    '%2 <bitmap:add-ons/Weapon_Loz_Hookshot/ci/arrow> %1',1,1);

datablock ProjectileData(hookshotProjectile)
{
   projectileShapeName = "./hookshotprojectile.dts";

   directDamage        = 100;
   directDamageType    = $DamageType::HookshotDirect;

   radiusDamage        = 0;
   damageRadius        = 0;
   radiusDamageType    = $DamageType::HookshotDirect;

   explosion           = hookshotExplosion;
   particleEmitter     = hookshotTrailEmitter;

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 2000;
   fadeDelay           = 3500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(HookshotItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./hookshot.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Hookshot";
	iconName = "./ItemIcons/Hookshot";
	doColorShift = true;
	colorShiftColor = "0.2 0.2 1 1.000";

	 // Dynamic properties defined by the scripts
	image = HookshotImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(hookshotImage)
{
   // Basic Item properties
   shapeFile = "./hookshot.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 10" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = hookshotItem;
   ammo = " ";
   projectile = hookshotProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = hookshotItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateSequence[1]                = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= hookshotFireSound;

	stateName[3]			= "Reload";
	stateSequence[3]                = "Reload";
	stateAllowImageChange[3]        = false;
	stateTimeoutValue[3]            = 0.5;
	stateWaitForTimeout[3]		= true;
	stateTransitionOnTimeout[3]     = "Check";

	stateName[4]			= "Check";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "Fire";

	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	//stateSequence[5]                = "Reload";
	stateScript[5]                  = "onStopFire";


};

function hookshotProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal) 
{
%player = %obj.client.player;
%pmount = %player.getObjectMount();

if(isObject(%pmount))
{
	if(%pmount.getClassName() $= "WheeledVehicle" || %pmount.getClassName() $= "AIplayer")
	{
		if(%col.getClassName() $= "Player" || %col.getClassName() $= "WheeledVehicle" || %col.getClassName() $= "FlyingVehicle" ||  %col.getClassName() $= "AIplayer")
		{
			pushPlayerToObj2(%pmount, %col);
		}else{
			pushPlayerToObj(%ppmount, %pos);
		}
	return;
	}
}

if(%col.getClassName() $= "Player" || %col.getClassName() $= "WheeledVehicle" || %col.getClassName() $= "FlyingVehicle" ||  %col.getClassName() $= "AIplayer")
{
pushPlayerToObj2(%player, %col);
}else{
pushPlayerToObj(%player, %pos);
}
}


function pushPlayerToObj(%player, %cpos)
{
if (!isObject(%player)) return; //make sure these are still objects, get rid of checking if the collision is an object
%ppos = getWords(%player.getTransform(), 0, 2);
%vec = VectorSub(%cpos, %ppos); //This automatically subtracts the positions
%len = VectorLen(%vec); //find the distance between the two coordinates
if (%len < 5)
{
return;
} //we don't check the same position because they won't be the same, just close to each other
%vec = VectorNormalize(%vec); //makes it small
if (%len < 15)
{
%vec = VectorScale(%vec, 30);
}
if(%len > 16)
{
%vec = VectorScale(%vec, 50);
}
%player.setVelocity(%vec); //and we might wanna make this keep on going so...
cancel(%player.pptoTick); //this cancels schedules from happening, this will prevent more than one happening at a time
 %player.pptoTick = schedule(100, 0, "pushPlayerToObj", %player, %cpos); //make the schedule send the collision position now//assign this to .ppTo
}


function pushPlayerToObj2(%player, %cpos)
{
if (!isObject(%player)) return; //make sure these are still objects, get rid of checking if the collision is an object
%ppos = getWords(%player.getTransform(), 0, 2);
%cpos2 = getWords(%cpos.getTransform(), 0, 2);
if(%cpos.getClassName() $= "FlyingVehicle"){
%cpos2 = VectorAdd(%cpos2, "0 0 1");
}
if(%cpos.getclassname() $= "WheeledVehicle")
{
%cpos2 = VectorAdd(%cpos2, "0 0 2");
}
%vec = VectorSub(%cpos2, %ppos); //This automatically subtracts the positions
%len = VectorLen(%vec); //find the distance between the two coordinates
if (%len < 5){

return; //we don't check the same position because they won't be the same, just close to each other
}
%vec = VectorNormalize(%vec); //makes it smallif (%len < 15)
if (%len < 15)
{
%vec = VectorScale(%vec, 30);
}
if(%len > 16)
{
%vec = VectorScale(%vec, 50);
}
%player.setVelocity(%vec); //and we might wanna make this keep on going so...
cancel(%player.pptoTick); //this cancels schedules from happening, this will prevent more than one happening at a time
 %player.pptoTick = schedule(100, 0, "pushPlayerToObj2", %player, %cpos); //make the schedule send the collision position now//assign this to .ppTo
}

function ServerCmddegrapple(%client)
{
cancel(%client.player.pptoTick);
}
