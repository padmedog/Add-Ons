%error = ForceRequiredAddOn("Weapon_Sword"); //for the Kukri and Fire Axe
%error2 = ForceRequiredAddOn("Emote_Critical"); //TF2 Wrench

if(%error == $Error::AddOn_Disabled)
{
   SwordItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2BasicMelee - required add-on Weapon_Sword not found");
}
else if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2BasicMelee - required add-on Emote_Critical not found");
}
else
{
   exec("./Support_RaycastingWeapons.cs");
   exec("./Support_TF2BasicMelee.cs");
   exec("./Weapon_TF2Shovel.cs");
   exec("./Weapon_TF2Kukri.cs");
   exec("./Weapon_TF2Axe.cs");
   exec("./Weapon_TF2Bottle.cs");
   exec("./Weapon_TF2Bonesaw.cs");
   exec("./Weapon_TF2Fists.cs");
   exec("./Weapon_TF2Wrench.cs");
}