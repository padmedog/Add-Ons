// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

// +-------------+
// | Preferences |
// +-------------+
Slayer.Prefs.addPref("Teams","Ally Same Colors","%mini.Teams.allySameColors","bool",0,0,1,-1);
Slayer.Prefs.addPref("Teams","Auto Sort","%mini.Teams.autoSort","bool",1,0,1,-1);
Slayer.Prefs.addPref("Teams","Balance New Teams","%mini.Teams.balanceOnNew","bool",1,0,1,3);
Slayer.Prefs.addPref("Teams","Balance Teams","%mini.Teams.balanceTeams","bool",1,0,1,-1);
Slayer.Prefs.addPref("Teams","Display Join/Leave Messages","%mini.Teams.notifyMemberChanges","bool",1,0,0,-1,"Advanced");
Slayer.Prefs.addPref("Teams","Friendly Fire","%mini.Teams.friendlyFire","bool",0,0,1,-1);
Slayer.Prefs.addPref("Teams","Lock Teams","%mini.Teams.lock","bool",0,0,1,-1);
Slayer.Prefs.addPref("Teams","Punish Friendly Fire","%mini.Teams.punishFF","bool",1,0,1,3,"Advanced");
Slayer.Prefs.addPref("Teams","Rounds Between Shuffle","%mini.Teams.roundsBetweenShuffles","int 1 999",1,0,1,-1);
Slayer.Prefs.addPref("Teams","Shuffle Teams","%mini.Teams.shuffleTeams","bool",0,0,1,-1);
Slayer.Prefs.addPref("Teams","Shuffle Mode","%mini.Teams.shuffleMode","list" TAB "0 Random" TAB "1 New Team Every Time",1,0,1,-1,"Advanced");
Slayer.Prefs.addPref("Teams","Swap/Join Mode","%mini.Teams.swapMode","list" TAB "0 Regulated" TAB "1 Unregulated (always join)",0,0,1,-1,"Advanced");
Slayer.Prefs.addPref("Teams","Team-Only DeadCam","%mini.Teams.teamOnlyDeadCam","bool",0,0,1,-1,"Advanced");
Slayer.Prefs.addNonNetworkedPref("Teams","Max Teams","$Slayer::Server::Teams::maxTeams","int 0 200",100);

// +--------------------------+
// | Slayer_TeamPrefHandlerSO |
// +--------------------------+
function Slayer_TeamPrefHandlerSO::onAdd(%this)
{
	//USAGE //(category,title,variable,type,defaultValue,notify,editRights,list,callback)
	%this.addPref("Bots","Preferred Player Count","botFillLimit","int -1 99",-1,1,2,"","%team.updateBotFillLimit(%1);");
	%this.addPref("Chat","Enable Team Chat","enableTeamChat","bool",1,1,-1,"Advanced");
	%this.addPref("Chat","Hide Kills","hideKillMsgs","bool",0,1,-1,"Advanced");
	%this.addPref("Chat","Name Color","chatColor","string 6","",0,-1,"Advanced");
	%this.addPref("Team","Auto Sort Weight","sortWeight","int 0 99",1,1,-1);
	%this.addPref("Team","Auto Sort","sort","bool",1,1,-1);
	%this.addPref("Team","Color","color","colorID",0,0,-1,"","%team.updateColor(%1);");
	%this.addPref("Team","Lives","lives","int -1 999",-1,1,-1,"Advanced","%team.updateLives(%1,%2);");
	%this.addPref("Team","Lock Team","lock","bool",0,1,-1);
	%this.addPref("Team","Max Players","maxPlayers","int -1 99",-1,1,-1);
	%this.addPref("Team","Name","name","string 50","New Team",1,-1,"","%team.updateName(%1);");
	%this.addPref("Team","Player Scale","playerScale","slide 0 5 4 1",1,1,-1,"Advanced","%team.updatePlayerScale(%1);");
	%this.addPref("Team","Playertype","playerDatablock" TAB "PlayerData" TAB 1,"list",nameToID(playerStandardArmor),0,-1,"","%team.updateDatablock(%1);");
	%this.addPref("Team","Respawn Time","respawnTime_Player","int -1 999",-1,1,-1,"Advanced","%team.updateRespawnTime(player,%1,%2);");
	%this.addPref("Team","Spectator Team","spectate","bool",0,1,-1);
	%this.addPref("Team","Start Equip 0","startEquip0" TAB "ItemData","list",nameToID(hammerItem),0,-1,"","%team.updateEquip(0,%1,%2);");
	%this.addPref("Team","Start Equip 1","startEquip1" TAB "ItemData","list",nameToID(wrenchItem),0,-1,"","%team.updateEquip(1,%1,%2);");
	%this.addPref("Team","Start Equip 2","startEquip2" TAB "ItemData","list",nameToID(printGun),0,-1,"","%team.updateEquip(2,%1,%2);");
	%this.addPref("Team","Start Equip 3","startEquip3" TAB "ItemData","list",0,0,-1,"","%team.updateEquip(3,%1,%2);");
	%this.addPref("Team","Start Equip 4","startEquip4" TAB "ItemData","list",0,0,-1,"","%team.updateEquip(4,%1,%2);");
	%this.addPref("Team","Sync w/ Minigame Loadout","syncLoadout","bool",1,0,-1);
	%this.addPref("Team","Uni Update Trigger","uni_updateTrigger","int 0 999999",0,0,-1,"","%team.updateUniform();");
	%this.addPref("Team","Uniform","uniform","list" TAB "0 NONE" TAB "1 Shirt Only" TAB "2 Full" TAB "3 Custom",2,1,-1,"","%team.updateUniform();");
	%this.addPref("Team","Win on Time Up","winOnTimeUp","bool",0,1,-1,"Advanced");
	%this.addPref("Uniform","Accent","uni_accent","string 100","0",0,-1);
	%this.addPref("Uniform","AccentColor","uni_accentColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","Chest","uni_chest","string 100","0",0,-1);
	%this.addPref("Uniform","ChestColor","uni_chestColor","string 100","",0,-1);
	%this.addPref("Uniform","DecalColor","uni_decalColor","string 100","0",0,-1);
	%this.addPref("Uniform","DecalName","uni_decalName","string 100","AAA-None",0,-1);
	%this.addPref("Uniform","FaceColor","uni_faceColor","string 100","0",0,-1);
	%this.addPref("Uniform","FaceName","uni_faceName","string 100","smiley",0,-1);
	%this.addPref("Uniform","Hat","uni_hat","string 100","1",0,-1);
	%this.addPref("Uniform","HatColor","uni_hatColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","HeadColor","uni_headColor","string 100","1 0.878431 0.611765 1",0,-1);
	%this.addPref("Uniform","Hip","uni_hip","string 100","0",0,-1);
	%this.addPref("Uniform","HipColor","uni_hipColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","LArm","uni_lArm","string 100","0",0,-1);
	%this.addPref("Uniform","LArmColor","uni_lArmColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","LHand","uni_lHand","string 100","0",0,-1);
	%this.addPref("Uniform","LHandColor","uni_lHandColor","string 100","1 0.878431 0.611765 1",0,-1);
	%this.addPref("Uniform","LLeg","uni_lLeg","string 100","0",0,-1);
	%this.addPref("Uniform","LLegColor","uni_lLegColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","Pack","uni_pack","string 100","0",0,-1);
	%this.addPref("Uniform","PackColor","uni_packColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","RArm","uni_rArm","string 100","0",0,-1);
	%this.addPref("Uniform","RArmColor","uni_rArmColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","RHand","uni_rHand","string 100","0",0,-1);
	%this.addPref("Uniform","RHandColor","uni_rHandColor","string 100","1 0.878431 0.611765 1",0,-1);
	%this.addPref("Uniform","RLeg","uni_rLeg","string 100","0",0,-1);
	%this.addPref("Uniform","RLegColor","uni_rLegColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","SecondPack","uni_secondPack","string 100","0",0,-1);
	%this.addPref("Uniform","SecondPackColor","uni_secondPackColor","string 100","TEAMCOLOR",0,-1);
	%this.addPref("Uniform","TorsoColor","uni_torsoColor","string 100","TEAMCOLOR",0,-1);
}

function Slayer_TeamPrefHandlerSO::addPref(%this,%category,%title,%variable,%type,%defaultValue,%notify,%editRights,%list,%callback)
{
	%p = %this.getPrefSO(%category,%title);
	if(isObject(%p))
	{
		%p.delete();
		Slayer_Support::Debug(1,"Overwriting Team Pref",%category TAB %title);
	}

	%className = getField(%variable,1);

	%pref = new scriptObject()
	{
		class = Slayer_TeamPrefSO;

		title = %title;
		category = %category;
		type = %type;
		variable = getField(%variable,0);
		defaultValue = %defaultValue;
		notify = %notify;
		editRights = %editRights;
		isObject = (%className !$= "0" && %className !$= "");
		objectClassName = %className;
		objectCannotBeNull = getField(%variable,2);
		list = %list;
		callback = %callback;
	};
	%this.add(%pref);
	if(isObject(missionCleanup) && missionCleanup.isMember(%pref))
		missionCleanup.remove(%pref);
}

function Slayer_TeamPrefHandlerSO::setPref(%this,%team,%category,%title,%value)
{
	if(!isObject(%team))
		return;

	%pref = %this.getPrefSO(%category,%title);
	if(!isObject(%pref))
		return;

	return %pref.setValue(%team,%value);
}

function Slayer_TeamPrefHandlerSO::getPref(%this,%team,%category,%title) //get the value of a pref
{
	if(!isObject(%team))
		return;

	%pref = %this.getPrefSO(%category,%title);
	if(!isObject(%pref))
		return;

	return %pref.getValue(%team);
}

function Slayer_TeamPrefHandlerSO::getPrefSO(%this,%category,%title) //get the SO of a pref
{
	for(%i=0; %i < %this.getCount(); %i++)
	{
		%pref = %this.getObject(%i);
		if(%pref.category $= %category && %pref.title $= %title)
		{
			return %pref;
		}
	}

	return 0;
}

function Slayer_TeamPrefHandlerSO::resetPrefs(%this,%team)
{
	if(!isObject(%team))
		return;

	for(%i=0; %i < %this.getCount(); %i++)
	{
		%pref = %this.getObject(%i);
		%pref.setValue(%team,%pref.defaultValue);
	}
}

//THIS IS USED FOR SENDING BLANK TEAM DATA ON MINIGAME CREATION
function Slayer_TeamPrefHandlerSO::SendBlankTeamData(%this,%client)
{
	Slayer_Support::Debug(2,"Sending Blank Team Data",%client.getSimpleName());

	//START THE TEAM TRANSFER
	commandToClient(%client,'Slayer_getTeams_Start',0);

	//END THE TEAM TRANSFER
	commandToClient(%client,'Slayer_getTeams_End');

	//START THE TEAM PREF TRANSFER
	commandToClient(%client,'Slayer_getTeamPrefs_Start',%this.getCount());

	for(%i=0; %i < %this.getCount(); %i++)
	{
		%p = %this.getObject(%i);

		if(%p.editRights <= 2)
			%canEdit = (%p.editRights <= %client.getAdminLvl());
		else
			%canEdit = 1;

		commandToClient(%client,'Slayer_getTeamPrefs_Tick',%p.category,%p.title,%p.type,%p.objectClassName,%p.defaultValue,%canEdit,%p.list,"");
	}

	//END THE TEAM PREF TRANSFER
	commandToClient(%client,'Slayer_getTeamPrefs_End');
}


// +-------------------+
// | Slayer_TeamPrefSO |
// +-------------------+
function Slayer_TeamPrefSO::setValue(%this,%team,%value)
{
	if(!isObject(%team))
		return false;

	%proof = %this.idiotProof(%value);
	if(getField(%proof,0))
		%value = getField(%proof,1);
	else
		return false;

	if(%this.callback !$= "")
	{
		%callback = strReplace(%this.callback,"%1","\"" @ %value @ "\"");
		%callback = strReplace(%callback,"%2","\"" @ %this.getValue(%team) @ "\"");
		%callback = striReplace(%callback,"%team",%team);
		%callback = striReplace(%callback,"%mini",%team.minigame);
	}

	Slayer_Support::setDynamicVariable(%team @ "." @ %this.variable,%value);

	Slayer_Support::Debug(2,"Team Preference Set",%team TAB %this.category TAB %this.title TAB %value);

	if(%callback !$= "")
		eval(%callback);

	return true;
}

function Slayer_TeamPrefSO::getValue(%this,%team)
{
	return Slayer_Support::getDynamicVariable(%team @ "." @ %this.variable);
}

function Slayer_TeamPrefSO::idiotProof(%this,%value)
{
	if(%this.isObject)
	{
		if(!isObject(%value))
		{
			if(%this.objectCannotBeNull)
				return false;
			%value = 0;
		}
		else
		{
			%className = %value.getClassName();
			if(%this.objectClassName !$= %className && %this.objectClassName !$= "ALL")
				return false;
		}
	}

	%type = %this.type;
	switch$(getWord(%type,0))
	{
		case bool:
			if(%value !$= false && %value !$= true)
				return false;

		case string:
			%value = getSubStr(%value,0,getWord(%type,1));

		case int:
			if(!Slayer_Support::isFloat(%value))
				return false;
			%value = Slayer_Support::StripTrailingZeros(%value);
			%value = Slayer_Support::mRestrict(%value,getWord(%type,1),getWord(%type,2));

		case slide:
			if(!Slayer_Support::isFloat(%value))
				return false;
			%value = Slayer_Support::StripTrailingZeros(%value);
			%value = Slayer_Support::mRestrict(%value,getWord(%type,1),getWord(%type,2));

		case list:
			%count = getFieldCount(%type);
			if(%count > 1)
			{
				for(%i = 1; %i < %count; %i ++)
				{
					%f = getField(%type,%i);
					%w = firstWord(%f);
					if(%w == %value)
					{
						%ok = true;
						break;
					}
				}
				if(!%ok)
					return false;
			}
	}

	return true TAB %value;
}

// +----------------------+
// | Slayer_TeamHandlerSO |
// +----------------------+
function Slayer_TeamHandlerSO::onAdd(%this)
{
	//team preferences
	%this.Prefs = Slayer.TeamPrefs;
}

function Slayer_TeamHandlerSO::addTeam(%this,%isSpecialTeam)
{
	if(%this.getCount() >= $Slayer::Server::Teams::maxTeams)
		return Slayer_Support::Error("Slayer_TeamHandlerSO::addTeam","Team limit reached!");

	%mini = %this.minigame;

	%team = new scriptObject()
	{
		class = Slayer_TeamSO;
		minigame = %mini;
		isSpecialTeam = %isSpecialTeam;

		numMembers = 0;
		wins = 0;
		score = 0;
	};
	%this.add(%team);
	if(isObject(missionCleanup) && missionCleanup.isMember(%team))
		missionCleanup.remove(%team);

	//apply default settings
	%team.resetPrefs();

	if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onAdd"))
		call("Slayer_" @ %mini.mode @ "_Teams_onAdd",%mini,%this,%team);

	return %team;
}

function Slayer_TeamHandlerSO::removeTeam(%this,%team)
{
	if(!isObject(%team))
		return;
	if(!%this.isMember(%team))
		return;

	%mini = %this.minigame;

	if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onRemove"))
		call("Slayer_" @ %mini.mode @ "_Teams_onRemove",%mini,%this,%team);

	//We will recycle all bots in Slayer_TeamSO::onRemove
	%team.removeAllMembers("GameConnection");

	%team.delete();
}

function Slayer_TeamHandlerSO::onMinigameStart(%this)
{
//	for(%i = 0; %i < %this.getCount(); %i ++)
//		%this.getObject(%i).botFillTeam();
}

function Slayer_TeamHandlerSO::onMinigameRoundEnd(%this)
{
	//team shuffling
	if(%this.shuffleTeams)
		%this.shuffleCount ++;
	else
		%this.shuffleCount = 0;
}

function Slayer_TeamHandlerSO::onMinigameReset(%this)
{
	if(%this.shuffleTeams)
	{
		if(%this.shuffleCount >= %this.roundsBetweenShuffles)
		{
			%this.shuffleTeams(%this.shuffleMode,1);
			%this.shuffleCount = 0;
		}
	}

	for(%i=0; %i < %this.getCount(); %i++)
		%this.getObject(%i).onMinigameReset();
}

function Slayer_TeamHandlerSO::onNewTeam(%this,%team)
{
	%mini = %this.minigame;

	if(%this.balanceOnNew)
	{
		for(%i=0; %i < %mini.numMembers["GameConnection"]; %i++)
		{
			%cl = %mini.member["GameConnection",%i];
			%t = %cl.slyrTeam;
			if(!isObject(%t))
				%this.autoSort(%cl);
		}

		while(!%team.isTeamBalanced())
		{
			%team.balanceTeam(1); //forced team balance
		}
	}
}

function Slayer_TeamHandlerSO::removeAllMembers(%this,%class)
{
	for(%i=0; %i < %this.getCount(); %i++)
		%this.getObject(%i).removeAllMembers(%class);
}

function Slayer_TeamHandlerSO::messageAllByColor(%this,%color,%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p)
{
	for(%index = 0; %index < %this.getCount(); %index ++)
	{
		%t = %this.getObject(%index);
		if(%t.color == %color)
			%t.messageAll(%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p);
	}
}

function Slayer_TeamHandlerSO::messageAllDeadByColor(%this,%color,%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p)
{
	for(%index = 0; %index < %this.getCount(); %index ++)
	{
		%t = %this.getObject(%index);
		if(%t.color == %color)
			%t.messageAllDead(%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p);
	}
}

//Shuffles players between teams. This has two modes and is used between rounds to mix up teams.
//
//@param	shuffleMode	[int 0|1] 0 players have chance of not changing to new team. 1, new team is guaranteed
//@param	doNotRespawn	[bool] When true, players will not be respawned.
function Slayer_TeamHandlerSO::shuffleTeams(%this,%shuffleMode,%doNotRespawn)
{
	%mini = %this.minigame;

	if(%this.getShuffleTeamCount() < 2)
		return;
	else if(%shuffleMode == 1 && %this.getAutoSortTeamCount() == 0)
	{
		Slayer_Support::Error("Slayer_TeamHandlerSO::shuffleTeams","Teams full, fall back to method 0.");
		%shuffleMode = 0;
	}

	for(%i = 0; %i < %mini.numMembers["GameConnection"]; %i ++)
	{
		%cl = %mini.member["GameConnection",%i];
		if(!isObject(%cl.slyrTeam))
			%noTeam = %noTeam TAB %cl;
	}
	%noTeam = %noTeam @ "\t";

	//disable team join messages
	%oldNotify = %this.notifyMemberChanges;
	%this.notifyMemberChanges = false;

	//set the flag
	%this.shufflingTeams = 1;

	if(%shuffleMode == 0) //remove everybody from their teams and then just autosort
	{
		for(%i = 0; %i < %this.getCount(); %i ++)
		{
			%t = %this.getObject(%i);
			if(%t.sort && %t.sortWeight > 0 && %t.maxPlayers != 0)
				%t.removeAllMembers("GameConnection");
		}
		for(%i=0; %i < %mini.numMembers["GameConnection"]; %i++)
		{
			%cl = %mini.member["GameConnection",%i];
			if(!isObject(%cl.slyrTeam) && strPos(%noTeam,"\t" @ %cl @ "\t") < 0)
			{
				%team = %this.pickTeam(%cl);
				if(isObject(%team))
					%team.addMember(%cl,"Team Shuffle",%doNotRespawn);
			}
		}
	}
	else if(%shuffleMode == 1) //autosort without removing people from teams
	{
		for(%i=0; %i < %mini.numMembers["GameConnection"]; %i++)
		{
			%cl = %mini.member[%i];
			if(strPos(%noTeam,"\t" @ %cl @ "\t") < 0)
			{
				%team = %this.pickTeam(%cl,1);
				if(isObject(%team))
					%team.addMember(%cl,"Team Shuffle",%doNotRespawn);
			}
		}
	}

	%this.balanceTeams(0);

	%this.shufflingTeams = 0;

	%this.notifyMemberChanges = %oldNotify;

	if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onShuffle"))
		call("Slayer_" @ %mini.mode @ "_Teams_onShuffle",%mini,%this,%shuffleMode,%doNotRespawn);
}

//Evenly distributes members across all teams, factoring in auto-sort weightings.
//
//@param	force	[bool] When set to true, all members will be immediately distributed. When set to false, members will be balanced on death.
//@see	Slayer_TeamSO::balanceTeam
function Slayer_TeamHandlerSO::balanceTeams(%this,%force)
{
	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		%team = %this.getObject(%i);
		if(%team.sort && %team.sortWeight > 0)
		{
			while(!%team.isTeamBalanced())
			{
				%team.balanceTeam(%force);
				if(!%force)
					break;
			}
		}
	}
}

//Switches two clients between their teams.
//
//@param	clientA
//@param	clientB
//@see	Slayer_TeamHandlerSO::onTeamMemberSwap
function Slayer_TeamHandlerSO::swapTeamMembers(%this,%clientA,%clientB)
{
	%mini = %this.minigame;
	%resetting = %mini.isResetting();

	%teamA = %clientA.getTeam();
	%teamB = %clientB.getTeam();
	if(!isObject(%teamA) || !isObject(%teamB))
		return;

	if(%teamA.swapPending == %teamB)
	{
		cancel(%teamA.swapTime);
		%teamB.swapOffer = "";
		%teamA.swapPending = "";
		%teamA.swapClient = "";
	}
	else if(%teamB.swapPending == %teamA)
	{
		cancel(%teamB.swapTime);
		%teamA.swapOffer = "";
		%teamB.swapPending = "";
		%teamB.swapClient = "";
	}

	%teamA.addMember(%clientB,"Team Swap",%resetting);
	%teamB.addMember(%clientA,"Team Swap",%resetting);

	%this.onTeamMemberSwap(%this,%clientA,%clientB);
}

//Called when two players swap teams.
//
//@param	clientA
//@param	clientB
function Slayer_TeamHandlerSO::onTeamMemberSwap(%this,%clientA,%clientB)
{
	if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onTeamMemberSwap"))
		call("Slayer_" @ %mini.mode @ "_Teams_onTeamMemberSwap",%mini,%this,%clientA,%clientB);
}

//Finds the number of teams that are available for auto-sorting.
//
//@return	[int]	The number of available teams.
function Slayer_TeamHandlerSO::getAutosortTeamCount(%this)
{
	%count = 0;
	for(%i=0; %i < %this.getCount(); %i++)
	{
		%t = %this.getObject(%i);

		if((%t.maxPlayers <= 0 || %t.numMembers["GameConnection"] < %t.maxPlayers) && %t.sort && %t.sortWeight > 0)
			%count ++;
	}

	return %count;
}

//Finds the number of teams that are available for team shuffling.
//
//@return	[int]	The number of available teams.
function Slayer_TeamHandlerSO::getShuffleTeamCount(%this)
{
	%count = 0;
	for(%i=0; %i < %this.getCount(); %i++)
	{
		%t = %this.getObject(%i);

		if(%t.sort && %t.sortWeight > 0 && %t.maxPlayers != 0)
			%count ++;
	}

	return %count;
}

//Selects the best candidate team for a client to join.
//@param	GameConnection client	The client to select a team for.
//@param	bool skipCurrentTeam	If the client already has a team, don't consider it.
//@return	int	0, no suitable team was found; objID, the object ID of the team that was selected.
//@see	Slayer_TeamHandlerSO::autoSort
function Slayer_TeamHandlerSO::pickTeam(%this,%client,%skipCurrentTeam)
{
	%mini = %this.minigame;

	if(!isObject(%client))
		return 0;

	for(%i=0; %i < %this.getCount(); %i++)
	{
		%t = %this.getObject(%i);
//		if(%skipCurrentTeam && %t == %client.slyrTeam)
//			continue;
		if(!%t.sort || %t.sortWeight <= 0 || (%t.numMembers["GameConnection"] >= %t.maxPlayers && %t.maxPlayers >= 0))
			continue;

		%sumWeights += %t.sortWeight;
	}

	%sortRatio = %mini.numMembers["GameConnection"] / %sumWeights;

	%greatest = -1;
	for(%i=0; %i < %this.getCount(); %i++)
	{
		%t = %this.getObject(%i);
		if(%skipCurrentTeam && %t == %client.slyrTeam)
			continue;
		if(!%t.sort || %t.sortWeight <= 0 || (%t.numMembers["GameConnection"] >= %t.maxPlayers && %t.maxPlayers >= 0))
			continue;

		%weight = (%t.sortWeight * %sortRatio) - %t.numMembers["GameConnection"];

		if(%weight > %greatest)
		{
			%greatest = %weight;
			%teams = %t;
		}
		else if(%weight >= %greatest)
		{
			%teams = setField(%teams,getFieldCount(%teams),%t);
		}
	}

	if(getFieldCount(%teams) <= 0)
		return 0;

	%r = getRandom(0,getFieldCount(%teams)-1);
	if(%r < 0)
		%r = 0;
	%team = getField(%teams,%r);

	if(!isObject(%team))
		return 0;

	if(%client.slyrTeam == %team)
		return 0;

	return %team;
}

//Selects a team for the client and causes them to join it automatically.
//
//@param	client
//@param	doNotRespawn	[bool] If true, the client will not respawn during the process.
//@return	0	No suitable team was found.
//@return	objID	The object ID of the team that was selected.
//@see	Slayer_TeamHandlerSO::pickTeam
function Slayer_TeamHandlerSO::autoSort(%this,%client,%doNotRespawn)
{
	%team = %this.pickTeam(%client);
	if(!isObject(%team))
		return;

	%team.addMember(%client,"",%doNotRespawn);

	return %team;
}

//Determines whether two teams can damage each other.
//
//@return	[int -1 invalid | 0 no | 1 yes]
//@see minigameCanSlayerDamage
function Slayer_TeamHandlerSO::canDamage(%this,%teamA,%teamB)
{
	if(%teamA.spectate || %teamB.spectate)
		return 0;
	if(!isObject(%teamA) || !isObject(%teamB))
		return -1;
	if(!%this.friendlyFire && %teamA.isAlliedTeam(%teamB))
		return 0;

	return 1;
}

//Auto-sorts all members of the minigame into teams.
//
//@param	doNotRespawn	[bool] Whether players will not respawn during the process.
//see	Slayer_TeamHandlerSO::autoSort
function Slayer_TeamHandlerSO::autoSortAll(%this,%doNotRespawn)
{
	%mini = %this.minigame;

	for(%i = 0; %i < %mini.numMembers["GameConnection"]; %i ++)
		%this.autoSort(%mini.member["GameConnection",%i],%doNotRespawn);
}

//@param	name	The name of a team.
//@return	Returns the objID of the team, if any.
//@see	Slayer_TeamHandlerSO::getTeamsFromColor
function Slayer_TeamHandlerSO::getTeamFromName(%this,%name)
{
	for(%i=0; %i < %this.getCount(); %i++)
	{
		%t = %this.getObject(%i);
		if(%t.name $= %name)
			return %t;
	}

	return 0;
}

//Returns a list of teams that match a specified color.
//
//@param	color	The colorID of team to search for.
//@param	mode	[string "TAB" | "COM"] The type of list to return, tab or comma delimited.
//@param	returnColor	[bool] Whether TML color tags should be included in the returned string.
//@param	inverse	[bool] Return teams that do not match the color.
//@param	exclude	A tab-delimited list of teams to exlude from the list.
//@return	Returns a tab or comma delimited list, according to the mode paramater.
//@see	Slayer_TeamHandlerSO::getTeamFromName
function Slayer_TeamHandlerSO::getTeamsFromColor(%this,%color,%mode,%returnColor,%inverse,%exclude)
{
	if(%mode $= "")
		%mode = "TAB";

	for(%i=0; %i < %this.getCount(); %i++)
	{
		%t = %this.getObject(%i);

		if((%t.color != %color && !%inverse) || (%t.color == %color && %inverse))
			continue;

		if(strPos(%exclude,%t) >= 0)
			continue;

		if(%mode $= "TAB")
		{
			if(%teams $= "")
				%teams = %t;
			else
				%teams = %teams TAB %t;
		}
		else
		{
			if(%returnColor)
			{
				if(%teams $= "")
					%teams = "<spush>" @ %t.getColoredName() @ "<spop>";
				else
					%teams = %teams @ "," SPC "<spush>" @ %t.getColoredName() @ "<spop>";
			}
			else
			{
				if(%teams $= "")
					%teams = %t.name;
				else
					%teams = %teams @ "," SPC %t.name;
			}
		}
	}

	return %teams;
}

//Generates a list of teams, sorted from greatest to least by score.
//@return	Tab-delimited list of teams.
function Slayer_TeamHandlerSO::getTeamListSortedScore(%this)
{
	%count = %this.getCount();
	for(%i = 0; %i < %count; %i ++)
		%list = setField(%list,getFieldCount(%list),%this.getObject(%i));
	while(!%done)
	{
		%done = 1;
		for(%i = 0; %i < %count; %i ++)
		{
			%e = %i + 1;
			if(%e >= %count)
				continue;
			%f1 = getField(%list,%i);
			%f2 = getField(%list,%e);
			if(%f1.getScore() < %f2.getScore())
			{
				%list = Slayer_Support::swapItemsInList(%list,%i,%e);
				%done = 0;
			}
		}
		%count --;
	}

	return %list;
}

//Determines if a color is used by any teams.
//@param	color	The colorID to check.
//@return [bool]
function Slayer_TeamHandlerSO::isNeutralColor(%this,%color)
{
	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		if(%this.getObject(%i).color == %color)
			return 0;
	}

	return 1;
}

//Sends team pref and team data to clients using the GUI.
//@see	Slayer::sendData
function Slayer_TeamHandlerSO::sendTeams(%this,%client)
{
	%mini = %this.minigame;

	Slayer_Support::Debug(2,"Sending Teams",%client.getSimpleName());

	//START THE TEAM PREF TRANSFER
	commandToClient(%client,'Slayer_getTeamPrefs_Start',Slayer.TeamPrefs.getCount());

	for(%i=0; %i < Slayer.TeamPrefs.getCount(); %i++)
	{
		%p = Slayer.TeamPrefs.getObject(%i);

		%canEdit = %mini.canEdit(%client,%p.editRights);

		commandToClient(%client,'Slayer_getTeamPrefs_Tick',%p.category,%p.title,%p.type,%p.objectClassName,%p.defaultValue,%canEdit,%p.list);
	}

	//END THE TEAM PREF TRANSFER
	commandToClient(%client,'Slayer_getTeamPrefs_End');

	//START THE TEAM TRANSFER
	commandToClient(%client,'Slayer_getTeams_Start',%this.getCount());

	for(%i=0; %i < %this.getCount(); %i++)
	{
		%team = %this.getObject(%i);

		if(%team.isSpecialTeam)
			continue;

		commandToClient(%client,'Slayer_getTeams_Tick',%team,%team.name);

		Slayer_Support::Debug(2,"Sending Team",%team TAB %team.name);

		for(%e=0; %e < Slayer.TeamPrefs.getCount(); %e++)
		{
			%p = Slayer.TeamPrefs.getObject(%e);

			%val = %p.getValue(%team);

			commandToClient(%client,'Slayer_getTeams_PrefTick',%team,%p.category,%p.title,%val);
		}
	}

	//END THE TEAM TRANSFER
	commandToClient(%client,'Slayer_getTeams_End');
}

//Displays team information in the console.
function Slayer_TeamHandlerSO::dumpTeams(%this)
{
	%count = %this.getCount();
	for(%i = 0; %i < %count; %i ++)
	{
		%team = %this.getObject(%i);
		echo("\c5Team" SPC %team.name @ ":" NL
			"   Members:" SPC %team.numMembers NL
			"    \c3Humans:" SPC %team.numMembers["GameConnection"] NL
			"    \c3Bots:  " SPC %team.numMembers["AiConnection"] NL
			"   Score:  " SPC %team.getScore());
	}
}

// +---------------+
// | Slayer_TeamSO |
// +---------------+
function Slayer_TeamSO::onAdd(%this)
{

}

function Slayer_TeamSO::onRemove(%this)
{
	for(%i = %this.numMembers["AiConnection"] - 1; %i >= 0; %i --)
		%this.member["AiConnection",%i].recycle();
}

function Slayer_TeamSO::onMinigameReset(%this)
{
	%mini = %this.minigame;

	if(%mini.clearScores || %mini.points > 0)
		%this.setArtificialScore(0);

	if(!%this.getGroup().shuffleTeams)
		%this.botFillTeam();
}

//Adds minigame member to the team.
//
//@param	client
//@param	reason	A short description of why they were added. (example: "Team Swap")
//@param	doNotRespawn	[bool]
//@return	[bool] If the client was correctly added.
function Slayer_TeamSO::addMember(%this,%client,%reason,%doNotRespawn)
{
	%mini = getMinigameFromObject(%client);
	%teamHandler = %this.getGroup();

	if(%mini != %this.minigame)
		return 0;
	if(%client.slyrTeam == %this)
		return 0;

	//REMOVE FROM OLD TEAM
	if(isObject(%client.slyrTeam))
		%client.slyrTeam.removeMember(%client);

	%class = %client.getClassName();
	if(%this.numMembers[%class] $= "")
		%this.numMembers[%class] = 0;

	%client.slyrTeam = %this;
	%client.slyrTeamJoinTime = getSimTime();

	%this.member[%this.numMembers] = %client;
	%this.numMembers ++;
	%this.member[%class,%this.numMembers[%class]] = %client;
	%this.numMembers[%class] ++;

	//SET LIVES
	if((%client.getLives() > %this.lives || %client.getLives() == %mini.lives) && %this.lives >= 0)
		%client.setLives(%this.lives);

	//ARE THEY HUMAN OR BOT?
	if(%class $= "GameConnection")
	{
		//HUMAN - ANNOUNCEMENT
		%msgA = '\c5You have joined %1 %2';
		%msgB = '\c3%1 \c5has joined %2 %3';
		%clName = %client.getPlayerName();
		%teamName = %this.getColoredName();
		%reason = (%reason $= "" ? "" : "\c5(\c3" @ %reason @ "\c5)");
		messageClient(%client,'',%msgA,%teamName,%reason);
		if(%teamHandler.notifyMemberChanges)
			%mini.messageAllExcept(%client,'',%msgB,%clName,%teamName,%reason);

		clearBottomPrint(%client);
		clearCenterPrint(%client);
	}

	//SPAWN
	if((isObject(%client.player) || %mini.isResetting() || !%client.hasSpawnedOnce) && !%doNotRespawn)
		%client.spawnPlayer();

	%this.onAddMember(%client);

	return 1;
}

function Slayer_TeamSO::onAddMember(%this,%client)
{
	%mini = %this.minigame;
	%teamHandler = %this.getGroup();

	if(%client.getClassName() $= "GameConnection")
	{
		//TEAM BALANCE
		if(%teamhandler.balanceTeams)
			%this.balanceTeam();

		//TEAM FILLING
		if(%this.botFillLimit > 0)
			%this.botFillTeam();
	}

	if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onJoin"))
		call("Slayer_" @ %mini.mode @ "_Teams_onJoin",%mini,%this,%client);
}

//Removes a member from a team.
//
//@param	client
//@param	respawn	Whether to respawn the client after they leave.
//@return [bool]	Whether the client was successfully removed.
function Slayer_TeamSO::removeMember(%this,%client,%respawn)
{
	%mini = %this.minigame;
	%teamHandler = %this.getGroup();

	if(%client.slyrTeam != %this)
	{
		Slayer_Support::Error("Member not on" SPC %this.name,%client.getSimpleName());
		return 0;
	}

	%this.onRemoveMember(%client);

	//cancel any team swap requests
	if(%client == %this.swapClient)
	{
		%this.swapPending.swapOffer = "";
		%this.swapPending = "";
		%this.swapClient = "";
		cancel(%this.swapTime);
		%this.swapTime = "";
	}

	//REMOVE FROM MEMBER ARRAY
	%start = -1;
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		if(%this.member[%i] == %client) //find the member to be removed
		{
			%this.member[%i] = "";
			%start = %i;
			break;
		}
	}
	if(%start >= 0)	
	{
		for(%i = %start + 1; %i < %this.numMembers; %i++)
			%this.member[%i-1] = %this.member[%i];

		%this.member[%this.numMembers-1] = "";
		%this.numMembers --;
	}

	%class = %client.getClassName();

	//REMOVE FROM CLASS MEMBER ARRAY
	%start = -1;
	for(%i = 0; %i < %this.numMembers[%class]; %i ++)
	{
		if(%this.member[%class,%i] == %client) //find the member to be removed
		{
			%this.member[%class,%i] = "";
			%start = %i;
			break;
		}
	}
	if(%start >= 0)	
	{
		for(%i = %start + 1; %i < %this.numMembers[%class]; %i ++)
			%this.member[%class,%i - 1] = %this.member[%class,%i];

		%this.member[%class,%this.numMembers[%class] - 1] = "";
		%this.numMembers[%class] --;
	}

	%client.slyrTeam = "";

	if(%respawn)
		%client.spawnPlayer();
	else if(isObject(%client.player))
	{
		%client.applyBodyParts();
		%client.applyBodyColors();
		%client.player.setShapeNameColor($MiniGameColorF[%mini.colorIdx]);

		%playerDatablock = %mini.playerDatablock;
		%client.player.changeDatablock(%playerDatablock);
		for(%i=0; %i < %playerDatablock.maxTools; %i++)
			%client.forceEquip(%i,%mini.startEquip[%i]);
	}
	if(%client.getLives() >= %this.lives)
		%client.setLives(%mini.lives);

	return 1;
}

function Slayer_TeamSO::onRemoveMember(%this,%client)
{
	%mini = %this.minigame;
	%teamHandler = %this.getGroup();

	if(%client.getClassName() $= "GameConnection")
	{
		//TEAM BALANCE
		if(%teamhandler.balanceTeams)
			%this.scheduleNoQuota(0, "balanceTeam");
	
		//TEAM FILLING
		if(%this.botFillLimit > 0)
			%this.scheduleNoQuota(0, "botFillTeam");
	}

	if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onLeave"))
		call("Slayer_" @ %mini.mode @ "_Teams_onLeave",%mini,%this,%client);
}

//Removes all members from their teams.
//@param	class	Optional. If specified, only members of that class will be removed.
//@see	Slayer_TeamSO::removeMember
function Slayer_TeamSO::removeAllMembers(%this,%class)
{
	if(%class $= "")
	{
		for(%i = %this.numMembers - 1; %i >= 0; %i --)
			%this.removeMember(%this.member[%i]);
	}
	else
	{
		for(%i = %this.numMembers[%class] - 1; %i >= 0; %i --)
			%this.removeMember(%this.member[%class,%i]);
	}
}

//Checks whether a client is on the team.
function Slayer_TeamSO::isMember(%this,%client)
{
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		if(%this.member[%i] == %client)
			return 1;
	}
	return 0;
}

//Represents the client's value to the team as an integer.
//@param	GameConnection client
//@param	bool includeScore	Whether the client's score is taken into consideration. Otherwise, only kills/deaths are considered.
//@return	int
function Slayer_TeamSO::getMemberValue(%this, %client, %includeScore)
{
	%value = 0;
	%value += %client.score;
	%value += %client.slyr_kills;
	%value -= %client.slyr_deaths;
	return %value;
}

//Finds the best candidate for balancing another team. Considers points, kills, deaths, and (optionally) time spent on the team.
//If there are multiple potential candidates, a random one will be chosen.
//@param	bool valueTime	Whether the amount of time spent on the team is taken into consideration. Less time equates to lower rank.
//@return	GameConnection
function Slayer_TeamSO::getBalanceCandidate(%this, %valueTime)
{
	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
	{
		%cl = %this.member["GameConnection", %i];
		%value = %this.getMemberValue(%cl, true);
		if(%valueTime)
			%value += %i;
		if(%value < %lowestValue || %i == 0)
		{
			%lowestValue = %value;
			%candidate[0] = %cl;
			%candidateCount = 1;
		}
		else if(%value == %lowestValue)
		{
			%candidate[%candidateCount] = %cl;
			%candidateCount ++;
		}
	}
	if(%candidateCount > 0)
	{
		%index = getRandom(0, %candidateCount - 1);
		return %candidate[%index];
	}
	else
	{
		return 0;
	}
}

//Checks whether a client is a balance candidate.
//@param	GameConnection client
//@param	bool valueTime	Whether the amount of time spent on the team is taken into consideration. Less time equates to lower rank.
//@return	bool
function Slayer_TeamSO::isBalanceCandidate(%this, %client, %valueTime)
{
	%member = 0;
	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
	{
		%cl = %this.member["GameConnection", %i];
		%value = %this.getMemberValue(%cl, true);
		if(%valueTime)
			%value += %i;
		if(%value < %lowestValue || %i == 0)
		{
			%lowestValue = %value;
			%candidate[0] = %cl;
			%candidateCount = 1;
		}
		else if(%value == %lowestValue)
		{
			%candidate[%candidateCount] = %cl;
			%candidateCount ++;
		}
	}
	for(%i = 0; %i < %candidateCount; %i ++)
	{
		if(%candidate[%i] == %client)
		{
			return true;
		}
	}
	return false;
}

function Slayer_TeamSO::balanceTeam(%this,%force)
{
	%mini = %this.minigame;
	%teamHandler = %this.getGroup();

	%this.balanceSource.balanceTeam = "";
	%this.balanceSource = "";

	if(!%this.sort || %this.sortWeight <= 0)
		return 0;
	if(%this.numMembers["GameConnection"] >= %this.maxPlayers && %this.maxPlayers >= 0)
		return 0;

	%ratio = %this.numMembers["GameConnection"] / %this.sortWeight;

	//find the most suitable source
	%highest = 0;
	for(%i=0; %i < %teamHandler.getCount(); %i++)
	{
		%t = %teamHandler.getObject(%i);
		if(!%t.sort || %t.sortWeight <= 0 || %t.maxPlayers == 0)
			continue;
		%r = %t.numMembers["GameConnection"] / %t.sortWeight;
		%ratioSum += %r;
		%ratioCount ++;
		if(%t != %this && %r > %highest)
		{
			%highest = %r;
			%source = %t;
			%sourceRatio = %r;
		}
	}

	if(%ratioCount > 1)
	{
		%ratioAvg = %ratioSum / %ratioCount;

		if(%ratio < %ratioAvg)
		{
			//we can no longer give away members
			//the other team needs a new donor
			if(isObject(%this.balanceTeam))
			{
				%this.balanceTeam.balanceTeam(false);
			}
		}
	}

	if(!isObject(%source))
		return 0;

	%ratioDif = %sourceRatio - %ratio;

	if(%ratioDif > 1)
	{
		//is this team completely out of members?
		if(%force || (%this.numMembers["GameConnection"] < 1 && %teamHandler.getCount() == 2 && %teamhandler.swapMode != 1))
		{
			//yes - we need to move someone immediately
			%cl = %source.getBalanceCandidate(true);
			%this.addMember(%cl,"Team Balance");
		}
		else
		{
			//no - wait until someone dies
			%source.balanceTeam = %this;
			%this.balanceSource = %source;
		}

		return %source;
	}

	return 0;
}

function Slayer_TeamSO::isTeamBalanced(%this)
{
	%mini = %this.minigame;
	%teamHandler = %this.getGroup();

	if(!%this.sort || %this.sortWeight <= 0)
		return -1;
	if(%this.numMembers["GameConnection"] >= %this.maxPlayers && %this.maxPlayers >= 0)
		return 1;

	%ratio = %this.numMembers["GameConnection"] / %this.sortWeight;

	//find the most suitable source
	%highest = 0;
	for(%i=0; %i < %teamHandler.getCount(); %i++)
	{
		%t = %teamHandler.getObject(%i);
		if(!%t.sort || %t.sortWeight <= 0 || %t.maxPlayers == 0)
			continue;

		%r = %t.numMembers["GameConnection"] / %t.sortWeight;
		%ratioSum += %r;
		%ratioCount ++;

		if(%t == %this)
			continue;

		if(%r > %highest)
		{
			%highest = %r;

			%source = %t;
			%sourceRatio = %r;
		}
	}

	%ratioDif = %sourceRatio - %ratio;

	return (%ratioDif <= 1);
}

function Slayer_TeamSO::botFillTeam(%this)
{
	//we don't want to do anything if the minigame is paused
	if(%this.minigame.isSuspended)
		return;

	%limit = %this.botFillLimit;
	if(%limit $= "")
	{
		Slayer_Support::Error("Slayer_TeamSO::botFillTeam","Limit undefined!");
		return;
	}

	//REMOVE UNNEEDED BOTS
	while(%this.numMembers > %limit && %this.numMembers["AiConnection"] > 0)
	{
		%bot = %this.member["AiConnection",0];

		if(%lastBot == %bot)
		{
			Slayer_Support::Error("Slayer_TeamSO::botFillTeam","Bot not removed!" SPC %lastBot);
			break;
		}
		%lastBot = %bot;

		%bot.recycle();
	}

	//ADD EXTRA BOTS
	while(%this.numMembers < %limit)
	{
		%bot = %this.minigame.addBotToGame();
		if(!isObject(%bot))
		{
			Slayer_Support::Error("Slayer_TeamSO::botFillTeam","Bot not created!");
			break;
		}
		%this.addMember(%bot);
	}
}

function Slayer_TeamSO::isAlliedTeam(%this,%team)
{
	if(%this == %team)
		return 1;

	%handler = %this.getGroup();
	if(%handler.allySameColors)
	{
		if(%this.color == %team.color)
			return 1;
	}

	return 0;
}

function Slayer_TeamSO::messageAll(%this,%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q)
{
	for(%index = 0; %index < %this.numMembers["GameConnection"]; %index ++)
		messageClient(%this.member["GameConnection",%index],%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q);
}

function Slayer_TeamSO::messageAllDead(%this,%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q)
{
	for(%index = 0; %index < %this.numMembers["GameConnection"]; %index ++)
	{
		%cl = %this.member["GameConnection",%index];
		if(%cl.dead())
			messageClient(%cl,%cmd,%msg,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q);
	}
}

//for events
function Slayer_TeamSO::chatMsgAll(%this,%msg,%client)
{
	if(isObject(%client))
		%msg = strReplace(%msg,"%1",%client.getPlayerName());

	for(%i=0; %i < %this.numMembers["GameConnection"]; %i++)
		%this.member["GameConnection",%i].chatMessage(%msg);
}

//for events
function Slayer_TeamSO::centerPrintAll(%this,%msg,%time,%client)
{
	if(isObject(%client))
		%msg = strReplace(%msg,"%1",%client.getPlayerName());

	for(%i=0; %i < %this.numMembers["GameConnection"]; %i++)
		%this.member["GameConnection",%i].centerPrint(%msg,%time);
}

//for events
function Slayer_TeamSO::bottomPrintAll(%this,%msg,%time,%hideBar,%client)
{
	if(isObject(%client))
		%msg = strReplace(%msg,"%1",%client.getPlayerName());

	for(%i=0; %i < %this.numMembers["GameConnection"]; %i++)
		%this.member["GameConnection",%i].bottomPrint(%msg,%time,%hideBar);
}

//for events
function Slayer_TeamSO::respawnAll(%this,%client)
{
	for(%i=0; %i < %this.numMembers; %i++)
		%this.member[%i].spawnPlayer();
}

//for events
function Slayer_TeamSO::incScore(%this,%flag,%client)
{
	%this.incArtificialScore(%flag);
}

function Slayer_TeamSO::incArtificialScore(%this,%flag) //this adds points to the team itself
{
	%this.setArtificialScore(%this.score + %flag);

	return %this.score;
}

function Slayer_TeamSO::setArtificialScore(%this,%flag)
{
	%this.score = %flag;

	%mini = %this.minigame;
	%winner = %mini.victoryCheck_Points();
	if(%winner >= 0)
		%mini.endRound(%winner);

	return %this.score;
}

function Slayer_TeamSO::getArtificialScore(%this)
{
	return %this.score;
}

function Slayer_TeamSO::getScore(%this)
{
	%score = %this.getArtificialScore();
	for(%i=0; %i < %this.numMembers; %i++)
	{
		%score += %this.member[%i].score;
	}
	return %score;
}

function Slayer_TeamSO::getKills(%this)
{
	%kills = 0;
	for(%i=0; %i < %this.numMembers; %i++)
	{
		%kills += %this.member[%i].slyr_kills;
	}
	return %kills;
}

function Slayer_TeamSO::getDeaths(%this)
{
	%deaths = 0;
	for(%i=0; %i < %this.numMembers; %i++)
	{
		%deaths += %this.member[%i].slyr_deaths;
	}
	return %deaths;
}

function Slayer_TeamSO::getSpawned(%this)
{
	%spawned = 0;
	for(%i=0; %i < %this.numMembers; %i++)
	{
		if(isObject(%this.member[%i].player))
			%spawned ++;
	}
	return %spawned;
}

function Slayer_TeamSO::getLiving(%this)
{
	%living = 0;
	for(%i=0; %i < %this.numMembers; %i++)
	{
		if(!%this.member[%i].dead())
			%living ++;
	}
	return %living;
}

function Slayer_TeamSO::isTeamDead(%this)
{
	return (%this.getLiving() <= 0);
}

function Slayer_TeamSO::getColorHex(%this)
{
	return "<color:" @ %this.colorHex @ ">";
}

function Slayer_TeamSO::getColoredName(%this)
{
	return %this.getColorHex() @ %this.name;
}

function Slayer_TeamSO::forceEquip(%this,%slot,%item)
{
	for(%i=0; %i < %this.numMembers; %i++)
		%this.member[%i].forceEquip(%slot,%item);
}

function Slayer_TeamSO::updateEquip(%this,%slot,%new,%old)
{
	for(%i=0; %i < %this.numMembers; %i++)
		%this.member[%i].updateEquip(%slot,%new,%old);
}

function Slayer_TeamSO::updateDatablock(%this,%db)
{
	if(!isObject(%db))
		return;
	if(%db.getClassName() !$= "PlayerData")
		return;

	for(%i=0; %i < %this.numMembers; %i++)
	{
		%cl = %this.member[%i];
		%pl = %cl.player;
		if(isObject(%pl))
			%pl.changeDatablock(%db);
	}
}

function Slayer_TeamSO::updateName(%this,%name)
{
	%this.name = "";

	%name = trim(%name);
	%name = getWords(%name,0,12); //names are limited to 12 words
	if(isObject(%this.getGroup().getTeamFromName(%name)))
		%name = %name SPC getRandom(0,999999);
	%this.name = %name;
}

function Slayer_TeamSO::updateColor(%this,%color)
{
	%this.colorRGB = getColorIDTable(%color);
	%this.colorHex = Slayer_Support::RgbToHex(%this.colorRGB);

	%this.updateUniform();
}

function Slayer_TeamSO::updateUniform(%this)
{
	for(%i=0; %i < %this.numMembers; %i++)
		%this.member[%i].applyUniform();
}

function Slayer_TeamSO::updateBotFillLimit(%this,%flag)
{
	if(%this.minigame.isStarting)
		return;
	if(%flag < 1 || ($AddOnLoaded__["Bot_Hole"] && $AddOnLoaded__["Bot_Blockhead"]))
	{
		%this.botFillTeam();
	}
	else
	{
		%this.botFillLimit = -1;
		if(isObject(%client = %this.minigame.editClient))
			commandToClient(%client, 'MessageBoxOK', "Slayer | Error", "You must enable the Bot_Hole and Bot_Blockhead add-ons to use the Preferred Players setting.");
	}
}

function Slayer_TeamSO::updateRespawnTime(%this,%type,%flag,%old)
{
	%oldTime = %old * 1000;
	%time = %flag * 1000;
	if(%flag != -1)
		%time = Slayer_Support::mRestrict(%time,1000,999999);

	switch$(%type)
	{
		case player:
			%this.respawnTime = %time;

			for(%i=0; %i < %this.numMembers["GameConnection"]; %i++)
			{
				%cl = %this.member["GameConnection",%i];
				if(%cl.respawnTime == %oldTime || %old == -1)
					%cl.setRespawnTime(%time);
			}
	}
}

function Slayer_TeamSO::updateLives(%this,%new,%old)
{
	%mini = %this.minigame;

	for(%i=0; %i < %this.numMembers; %i++)
	{
		%cl = %this.member[%i];

		if(%new == 0)
		{
			%cl.setLives(0);
			return;
		}
		else if(%new < 0)
		{
			%cl.setLives(%mini.lives);
			return;
		}

		if(%old $= "" || %old < 0)
			%cl.setLives(%new);
		else
			%cl.addLives(%new-%old);

		%lives = %cl.getLives();
		if(%lives <= 0 && !%cl.dead())
		{
			%cl.setDead(1);
			if(isObject(%cl.player))
			{
				%cl.camera.setMode(observer);
				%cl.setControlObject(%cl.camera);
				%cl.player.delete();
			}
			%cl.centerPrint("\c5The number of lives was reduced. You are now out of lives.",5);

			%check = 1;
		}
		else if(%lives > 0 && %cl.dead())
		{
			%cl.setDead(0);
			if(!isObject(%cl.player))
				%cl.spawnPlayer();
		}
	}

	if(%check)
	{
		%win = %mini.victoryCheck_Lives();
		if(%win >= 0)
			%mini.endRound(%win);
	}
}

function Slayer_TeamSO::updatePlayerScale(%this,%flag)
{
	for(%i=0; %i < %this.numMembers; %i++)
	{
		%cl = %this.member[%i];
		if(isObject(%cl.player))
			%cl.player.setScale(%flag SPC %flag SPC %flag);
	}
}

function Slayer_TeamSO::setPref(%this,%category,%title,%value)
{
	return Slayer.TeamPrefs.setPref(%this,%category,%title,%value);
}

function Slayer_TeamSO::getPref(%this,%category,%title)
{
	return Slayer.TeamPrefs.getPref(%this,%category,%title);
}

function Slayer_TeamSO::resetPrefs(%this)
{
	Slayer.TeamPrefs.resetPrefs(%this);
}

// +------------+
// | serverCmds |
// +------------+
function serverCmdTeams(%client,%cmd,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l)
{
	if(%client.isSpamming())
		return;

	%mini = getMinigameFromObject(%client);

	if(!isSlayerMinigame(%mini))
		return;

	if(!%mini.Gamemode.teams)
		return;

	%clTeam = %client.getTeam();

	switch$(%cmd)
	{
		case addMember:
			if(isSlayerMinigame(%client.editingMinigame))
				%mini = %client.editingMinigame;

			if(!%mini.canEdit(%client))
				return;

			if(%a $= "")
			{
				messageClient(%client,'',"\c5Incorrect usage. Please enter a player name, then a team name.");
				return;
			}

			if(isObject(%a) && %a.getClassName() $= "GameConnection")
				%victim = %a;
			else
				%victim = findClientByName(%a);

			if(!isObject(%victim))
			{
				messageClient(%client,'',"\c5Couldn't find player:\c3" SPC %a);
				return;
			}

			if(%victim.minigame != %mini)
			{
				messageClient(%client,'',"\c3" @ %victim.getPlayerName() SPC "\c5is not in the\c3" SPC %mini.Title SPC "\c5minigame.");
				return;
			}

			%name = trim(%b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m);
			%team = %mini.Teams.getTeamFromName(%name);
			if(!isObject(%team))
			{
				messageClient(%client,'',"\c5Couldn't find team:\c3" SPC %name);
				return;
			}

			%tb = %mini.Teams.balanceTeams;
			%mini.Teams.balanceTeams = 0;

			%team.addMember(%victim);

			%mini.Teams.balanceTeams = %tb;

		case removeMember:
			if(isSlayerMinigame(%client.editingMinigame))
				%mini = %client.editingMinigame;

			if(!%mini.canEdit(%client))
				return;

			if(%a $= "")
			{
				messageClient(%client,'',"\c5Incorrect usage. Please enter a player name, then a team name.");
				return;
			}

			if(isObject(%a) && %a.getClassName() $= "GameConnection")
				%victim = %a;
			else
				%victim = findClientByName(%a);

			if(!isObject(%victim))
			{
				messageClient(%client,'',"\c5Couldn't find player:\c3" SPC %a);
				return;
			}
			if(%victim.minigame != %mini)
			{
				messageClient(%client,'',"\c3" @ %victim.getPlayerName() SPC "\c5is not in the\c3" SPC %mini.Title SPC "\c5minigame.");
				return;
			}

			%name = trim(%b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m);
			%team = %mini.Teams.getTeamFromName(%name);
			if(!isObject(%team))
			{
				messageClient(%client,'',"\c5Couldn't find team:\c3" SPC %name);
				return;
			}

			%team.removeMember(%victim,1);

		case "balance": //MANUAL TEAM BALANCE
			if(!%mini.canEdit(%client))
				return;

			%mini.Teams.balanceTeams(1);
			%mini.messageAll('',"\c3" @ %client.getPlayerName() SPC "\c5balanced \c3all \c5teams.");

		case Join: //TEAM SWAPPING & JOINING
			if(%mini.Teams.lock && isObject(%clTeam))
			{
				messageClient(%client,'',"\c5Teams are locked, you cannot change teams.");
				return;
			}

			%name = trim(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l);
			if(%name $= "")
			{
				messageClient(%client,'',"\c5Please enter a team to join. Type \c3/joinTeam Team Name \c5 to join a team. Type \c3/listTeams \c5to view a list of teams.");
				return;
			}

			%team = %mini.Teams.getTeamFromName(%name);
			if(!isObject(%team))
			{
				messageClient(%client,'',"\c5Couldn't find team:\c3" SPC %name);
				return;
			}

			if(%clTeam.lock || %team.lock)
			{
				messageClient(%client,'',"\c5Team is locked.");
				return;
			}

			if(%clTeam == %team)
			{
				messageClient(%client,'',"\c5You're already on" SPC %team.getColoredName() @ "\c5.");
				return;
			}

			if(isObject(%clTeam.swapPending))
			{
				messageClient(%client,'',"\c5Someone on your team is already trying to swap teams.");
				return;
			}
			if(isObject(%team.swapOffer))
			{
				messageClient(%client,'',"\c5Someone is already trying to swap to that team.");
				return;
			}
			if(%team.maxPlayers == 0)
			{
				messageClient(%client,'',"\c5That team is not accepting any new members.");
				return;
			}
			if(isObject(%clTeam))
			{
				if(%team.swapPending == %clTeam)
				{
					%mini.Teams.swapTeamMembers(%client,%team.swapClient);
					return;
				}

				%teamMembers = %team.numMembers["GameConnection"];
				%clTeamMembers = %clTeam.numMembers["GameConnection"];

				if(%mini.Teams.swapMode == 1 || (%clTeamMembers > %teamMembers && %team.maxPlayers == -1) || (%clTeamMembers > %teamMembers && %teamMembers < %team.maxPlayers && %team.maxPlayers != -1))
					%team.addMember(%client,"Team Swap",%mini.isResetting());
				else
				{
					%team.messageAll('',%clTeam.getColorHex() @ %client.name SPC "\c5wants to swap with someone on" SPC %team.getColorHex() @ %team.name @ "\c5. Type \c3/acceptSwap \c5to swap teams.");
					%team.swapOffer = %clTeam;
					messageClient(%client,'',"\c5The members of" SPC %team.getColorHex() @ %team.name SPC "\c5have been asked if they want to swap with you.");
					%clTeam.swapPending = %team;
					%clTeam.swapClient = %client;
					%clTeam.swapTime = schedule(20000,0,serverCmdTeams,%client,"cancelSwap");
				}	
			}
			else if(%team.maxPlayers < 0 || %team.numMembers["GameConnection"] < %team.maxPlayers)
				%team.addMember(%client,"",%mini.isResetting());
			else
				messageClient(%client,'',"\c5That team is not accepting any new members.");

		case Leave:
			if(!isObject(%clTeam))
			{
				messageClient(%client,'',"\c5You aren't on a team.");
				return;
			}
			if((%mini.Teams.lock || %mini.Teams.autoSort) && !%mini.canEdit(%client))
			{
				messageClient(%client,'',"\c5You cannot leave your team.");
				return;
			}

			messageClient(%client,'',"\c5You have left" SPC %clTeam.getColoredName());
			if(%mini.Teams.notifyMemberChanges)
				%mini.messageAllExcept(%client,'',"\c3" @ %client.getPlayerName() SPC "\c5has left" SPC %clTeam.getColoredName());
			%clTeam.removeMember(%client,1);

		case AcceptSwap:
			if(!isObject(%clTeam))
				return;
			if(!isObject(%clTeam.swapOffer))
			{
				messageClient(%client,'',"\c5No one is trying to swap teams right now.");
				return;
			}

			%mini.Teams.swapTeamMembers(%client,%clTeam.swapOffer.swapClient);

		case cancelSwap:
			if(%client != %clTeam.swapClient)
				return;
			messageClient(%client,'',"\c5No one swapped teams.");
			%clTeam.swapPending.swapOffer = "";
			%clTeam.swapPending = "";
			%clTeam.swapClient = "";

		case List:
			if(%mini.Teams.getCount() <= 0)
			{
				messageClient(%client,'',"\c5There are no teams.");
				return;
			}
			for(%i=0; %i < %mini.Teams.getCount(); %i++)
			{
				%team = %mini.Teams.getObject(%i);
				messageClient(%client,'',%team.getColorHex() @ %team.name);
			}

		case Count:
			if(%mini.Teams.getCount() <= 0)
			{
				messageClient(%client,'',"\c5There are no teams.");
				return;
			}
			for(%i=0; %i < %mini.Teams.getCount(); %i++)
			{
				%team = %mini.Teams.getObject(%i);
				messageClient(%client,'',"\c3(" @ %team.numMembers @ ")" SPC %team.getColorHex() @ %team.name);
			}

		case Score:
			if(%mini.Teams.getCount() <= 0)
			{
				messageClient(%client,'',"\c5There are no teams.");
				return;
			}
			for(%i=0; %i < %mini.Teams.getCount(); %i++)
			{
				%team = %mini.Teams.getObject(%i);
				messageClient(%client,'',"\c3(" @ %team.getScore() @ ")" SPC %team.getColorHex() @ %team.name);
			}

		case Living:
			if(%mini.Teams.getCount() <= 0)
			{
				messageClient(%client,'',"\c5There are no teams.");
				return;
			}
			for(%i=0; %i < %mini.Teams.getCount(); %i++)
			{
				%team = %mini.Teams.getObject(%i);
				messageClient(%client,'',"\c3(" @ %team.getLiving() @ ")" SPC %team.getColorHex() @ %team.name);
			}

		case listMembers:
			%name = trim(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l);
			%team = %mini.Teams.getTeamFromName(%name);
			if(!isObject(%team))
			{
				messageClient(%client,'',"\c5Couldn't find team:\c3" SPC %name);
				return;
			}

			messageClient(%client,'',%team.getColoredName() SPC "\c3(" @ %team.numMembers @ ")\c5:");
			for(%i=0; %i < %team.numMembers["GameConnection"]; %i++)
			{
				%cl = %team.member["GameConnection",%i];
				messageClient(%client,''," \c5+ \c3" @ %cl.getPlayerName());
			}
			if(%team.numMembers["AiConnection"] > 1)
				messageClient(%client,''," \c5+ \c3" @ %team.numMembers["AiConnection"] SPC "\c5" @ (%team.numMembers["AiConnection"] == 1 ? "bot" : "bots"));

		default:
			messageClient(%client,'',"\c5Please enter a valid command.");
	}
}

function serverCmdSlayer_removeTeams(%client,%removeTeamList)
{
	%mini = %client.editingMinigame;
	if(!isObject(%mini))
		%mini = getMinigameFromObject(%client);

	if(!isSlayerMinigame(%mini))
		return;
	if(!%mini.canEdit(%client))
		return;

	for(%i=0; %i < getFieldCount(%removeTeamList); %i++) //remove teams
	{
		%t = getField(%removeTeamList,%i);

		if(isObject(%t) && %t.class $= "Slayer_TeamSO")
			%mini.Teams.removeTeam(%t);
	}
}

function serverCmdSlayer_getTeamPrefs_Start(%client,%team,%count)
{
	%mini = %client.editingMinigame;
	if(!isObject(%mini))
		%mini = getMinigameFromObject(%client);

	if(!isSlayerMinigame(%mini))
		return;
	if(!%mini.canEdit(%client))
		return;
	if(%team < -1) //check if it's a new team
	{
		%team = %mini.Teams.addTeam(0);
		%mini.Teams.TEMP = %team;
	}
	if(!isObject(%team))
		return;

	if(%team != %mini.Teams.TEMP && %count > 0 && %mini.notifyOnChange)
	{
		%message = '\c3 + \c5Updated %1 \c5(team).';
		%mini.messageAll('',%message,%team.getColoredName());
	}
}

function serverCmdSlayer_getTeamPrefs_Tick(%client,%team,%category,%title,%value)
{
	%mini = %client.editingMinigame;
	if(!isObject(%mini))
		%mini = getMinigameFromObject(%client);

	if(!isSlayerMinigame(%mini))
		return;
	if(!%mini.canEdit(%client))
		return;

	if(%team < -1)
		%team = %mini.Teams.TEMP;
	if(!isObject(%team))
		return;

	if(!%mini.Teams.isMember(%team))
		return;

	%pref = Slayer.TeamPrefs.getPrefSO(%category,%title);

	if(!%mini.canEdit(%client,%pref.editRights))
		return;

	Slayer_Support::Debug(2,"Recieved Team Pref",%client SPC %team SPC %category SPC %title SPC %value);

	if(%pref.getValue(%team) $= %value)
		return;

	%success = %pref.setValue(%team,%value);

	if(%success)
	{
		if(%team != %mini.Teams.TEMP && %pref.notify && %mini.notifyOnChange)
		{
			%type = %pref.type;
			switch$(getWord(%type,0))
			{
				case bool:
					if(%value)
						%val = "True";
					else
						%val = "False";

				case list:
					for(%i=0; %i < getFieldCount(%type); %i++)
					{
						%f = getField(%type,%i);
						if(firstWord(%f) $= %value)
						{
							%val = restWords(%f);
							break;
						}
					}

				default:
					%val = %value;
			}
			%message = '\c3 + + \c5[\c3%1\c5|\c3%2\c5] is now \c3%3';
			%mini.messageAll('',%message,%category,%title,%val);
		}
	}
}

function serverCmdSlayer_getTeamPrefs_End(%client,%team)
{
	%mini = %client.editingMinigame;
	if(!isObject(%mini))
		%mini = getMinigameFromObject(%client);

	if(!isSlayerMinigame(%mini))
		return;
	if(!%mini.canEdit(%client))
		return;

	if(%team < -1)
		%team = %mini.Teams.TEMP;
	if(!isObject(%team))
		return;

	if(!%mini.Teams.isMember(%team))
		return;

	if(%team == %mini.Teams.TEMP)
	{
		%mini.Teams.onNewTeam(%team);
		%mini.Teams.TEMP = "";
		%mini.notifyNewTeam ++;
	}
}

// +--------------------+
// | Packaged Functions |
// +--------------------+
package Slayer_Dependencies_Teams
{
	function GameConnection::onDeath(%client,%obj,%killer,%type,%area)
	{
		parent::onDeath(%client,%obj,%killer,%type,%area);

		%mini = getMinigameFromObject(%client);
		if(!isSlayerMinigame(%mini))
			return;

		%team = %client.getTeam();
		if(!isObject(%team))
			return;

		if(	%mini.Teams.balanceTeams &&
			isObject(%balanceTeam = %team.balanceTeam) &&
			%team.isBalanceCandidate(%client) )
		{
				
			%balanceTeam.addMember(%client,"Team Balance");
		}
	}

	function serverCmdTeamMessageSent(%client,%msg)
	{
		%mini = getMinigameFromObject(%client);
		if(!isSlayerMinigame(%mini))
			return parent::servercmdTeamMessageSent(%client,%msg);

		serverCmdStopTalking(%client);

		%team = %client.getTeam();

		if(!isObject(%team))
		{
			return parent::servercmdTeamMessageSent(%client,%msg);
		}
		else if(!%team.enableTeamChat || !%mini.chat_enableTeamChat)
		{
			messageClient(%client,'',"\c5Team chat disabled.");
			return;
		}

		%msg = stripMLControlChars(trim(%msg));

		%length = strLen(%msg);
		if(!%length)
			return;

		%time = getSimTime();

		if(!%client.isSpamming)
		{
			//did they repeat the same message recently?
			if(%msg $= %client.lastMsg && %time - %client.lastMsgTime < $SPAM_PROTECTION_PERIOD)
			{
				messageClient(%client,'',"\c5Do not repeat yourself.");
				if(!%client.isAdmin)
				{

					%client.isSpamming = true;
					%client.spamProtectStart = %time;
					%client.schedule($SPAM_PENALTY_PERIOD,spamReset);
				}
			}

			//are they sending messages too quickly?
			if(!%client.isAdmin)
			{
				if(%client.spamMessageCount >= $SPAM_MESSAGE_THRESHOLD)
				{
					%client.isSpamming = true;
					%client.spamProtectStart = %time;
					%client.schedule($SPAM_PENALTY_PERIOD,spamReset);
				}
				else
				{
					%client.spamMessageCount ++;
					%client.schedule($SPAM_PROTECTION_PERIOD,spamMessageTimeout);
				}
			}
		}

		//tell them they're spamming and block the message
		if(%client.isSpamming)
		{
			spamAlert(%client);
			return;
		}

		//eTard Filter, which I hate, but have to include
		if($Pref::Server::eTardFilter)
		{
			%list = strReplace($Pref::Server::eTardList,",","\t");

			for(%i = 0; %i < getFieldCount(%list); %i ++)
			{
				%wrd = trim(getField(%list,%i));
				if(%wrd $= "")
					continue;
				if(striPos(" " @ %msg @ " "," " @ %wrd @ " ") >= 0)
				{
					messageClient(%client,'',"\c5This is a civilized game. Please use full words.");
					return;
				}
			}
		}

		//URLs
		for(%i = 0; %i < getWordCount(%msg); %i ++)
		{
			%word = getWord(%msg, %i);
			%pos = strPos(%word, "://") + 3;
			%pro = getSubStr(%word, 0, %pos);
			%url = getSubStr(%word, %pos, strLen(%word));

			if((%pro $= "http://" || %pro $= "https://") && strPos(%url, ":") == -1)
			{
				%word = "<sPush><a:" @ %url @ ">" @ %url @ "</a><sPop>";
				%msg = setWord(%msg, %i, %word);
			}
		}

		//get the names and clan tags
		%name = %client.getPlayerName();
		%pre  = %client.clanPrefix;
		%suf  = %client.clanSuffix;

		//let people know what team they're on
		%tColor = %team.getPref("Chat","Name Color");
		if(%tColor $= "" || strLen(%tColor) != 6)
			%color = %team.getColorHex();
		else
			%color = "<color:" @ %tColor @ ">";

		switch(%mini.chat_teamDisplayMode)
		{
			case 1:
				%all  = '%5%1\c3%2%5%3%7: %4';

			case 2:
				%all  = '\c7%1%5%2\c7%3%7: %4';

			case 3:
				%all  = '\c7[%5%6\c7] %1\c3%2\c7%3%7: %4';
		}

		if(%all $= "")
			%all  = '\c7%1\c3%2\c7%3%7: %4';

		if(%client.dead() && (%mini.chat_deadChatMode == 0 || %mini.chat_deadChatMode == 2) && !%mini.isResetting())
		{
			if(%mini.Teams.allySameColors)
			{
				%mini.Teams.messageAllDeadByColor(%team.color,'chatMessage',%all,%pre,%name,%suf,%msg,%color,%team.name," \c7[DEAD]<color:00ffff>");
			}
			else
			{
				%team.messageAllDead('chatMessage',%all,%pre,%name,%suf,%msg,%color,%team.name," \c7[DEAD]<color:00ffff>");
			}
		}
		else
		{
			if(%mini.Teams.allySameColors)
			{
				%mini.Teams.messageAllByColor(%team.color,'chatMessage',%all,%pre,%name,%suf,%msg,%color,%team.name,"<color:00ffff>");
			}
			else
			{
				%team.messageAll('chatMessage',%all,%pre,%name,%suf,%msg,%color,%team.name,"<color:00ffff>");
			}
		}

		echo("(T" SPC %team.name @ ")" @ %client.getSimpleName() @ ":" SPC %msg);

		%client.lastMsg = %msg;
		%client.lastMsgTime = %time;

		if(isObject(%client.player))
		{
			%client.player.playThread(3,"talk");
			%client.player.schedule(%length * 50,playThread,3,"root");
		}

		if(isFunction("Slayer_" @ %mini.mode @ "_Teams_onChat"))
			call("Slayer_" @ %mini.mode @ "_Teams_onChat",%mini,%client,%msg);
	}

	//The below functions are packaged for TDM compatibilty
	function serverCmdJoinTeam(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l)
	{
		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Join,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
		else
			parent::serverCmdJoinTeam(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
	}

	function serverCmdSwapTeam(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l)
	{
		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Join,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
		else
			parent::serverCmdSwapTeam(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
	}

	function serverCmdSwapTeams(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l)
	{
//		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Join,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
//		else
//			parent::serverCmdSwapTeams(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
	}

	function serverCmdAcceptSwap(%client)
	{
		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,AcceptSwap);
		else
			parent::serverCmdAcceptSwap(%client);
	}

	function serverCmdLeaveTeam(%client)
	{
		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Leave);
		else
			parent::serverCmdLeaveTeam(%client);
	}

	function serverCmdTeamList(%client)
	{
		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,List);
		else
			parent::serverCmdTeamList(%client);
	}

	function serverCmdListTeams(%client)
	{
//		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,List);
//		else
//			parent::serverCmdListTeams(%client);
	}

	function serverCmdTeamCount(%client)
	{
		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Count);
		else
			parent::serverCmdTeamCount(%client);
	}

	function serverCmdTeamScore(%client)
	{
//		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Score);
//		else
//			parent::serverCmdTeamScore(%client);
	}

	function serverCmdTeamLiving(%client)
	{
//		if(isSlayerMinigame(%client.minigame) || $Addon__Gamemode_TeamDeathMatch != 1)
			serverCmdTeams(%client,Living);
//		else
//			parent::serverCmdTeamScore(%client);
	}
};
activatePackage(Slayer_Dependencies_Teams);

// +-------------------------------------+
// | Initialize Slayer_TeamPrefHandlerSO |
// +-------------------------------------+
if(!isObject(Slayer.TeamPrefs))
{
	Slayer.TeamPrefs = new scriptGroup(Slayer_TeamPrefHandlerSO);
	Slayer.add(Slayer.TeamPrefs);
}

$Slayer::Server::Dependencies::Teams = 1;
Slayer_Support::Debug(2,"Dependency Loaded","Teams");