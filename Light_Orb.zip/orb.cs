datablock fxLightData(Orb)
{
	uiName = "White Orb";

	LightOn = true;
	radius = 2;
	brightness = 2;
	color = "1 1 1 1";

	flareOn = true;
	flarebitmap = "Add-Ons/Light_Orb/orb";
	ConstantSizeOn = true;
	ConstantSize = 1;
	NearSize = 1;
	FarSize = 1;
};
datablock fxLightData(OrbRed : Orb)
{
	uiName = "Red Orb";
	color = "1 0 0 1";
};
datablock fxLightData(OrbPurple : Orb)
{
	uiName = "Purple Orb";
	color = "1 0 1 1";
};
datablock fxLightData(OrbBlue : Orb)
{
	uiName = "Blue Orb";
	color = "0 0 1 1";
};
datablock fxLightData(OrbCyan : Orb)
{
	uiName = "Cyan Orb";
	color = "0 1 1 1";
};
datablock fxLightData(OrbGreen : Orb)
{
	uiName = "Green Orb";
	color = "0 1 0 1";
};
datablock fxLightData(OrbYellow : Orb)
{
	uiName = "Yellow Orb";
	color = "1 1 0 1";
};
datablock fxLightData(OrbOrange : Orb)
{
	uiName = "Orange Orb";
	color = "1 0.5 0 1";
};