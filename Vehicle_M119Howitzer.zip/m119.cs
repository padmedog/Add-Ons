//########## M119 Howitzer

//### Sound

datablock AudioProfile(gc_M119FireSound)
{
  filename = "./m119fire.wav";
  description = AudioDefault3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_fireParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = -1;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.2 0.2 0.6 0.1";
  colors[1] = "1 0.8 0.4 1";
  colors[2] = "0.5 0 0 0";
  sizes[0] = 0;
  sizes[1] = 2;
  sizes[2] = 1;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = false;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_fireEmitter)
{
  uiName = "";
  ejectionPeriodMS = 6;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0; 
  ejectionOffset = 2;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_fireParticle";
};

datablock ParticleData(gc_M119ShellTrailParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  colors[0] = "1 1 1 0.2";
  colors[1] = "1 1 1 0";
  sizes[0] = 1;
  sizes[1] = 0.1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_M119ShellTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 8;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119ShellTrailParticle";
};

datablock ParticleData(gc_M119FlashParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  spinSpeed = 50;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "1 0.5 0 1";
  colors[1] = "1 0.8 0.6 1";
  colors[2] = "1 0.3 0.1 0";
  sizes[0] = 1;
  sizes[1] = 10;
  sizes[2] = 5;
  times[9] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_M119FlashEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 250;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 10;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119FlashParticle";
};

datablock ParticleData(gc_M119SmokeParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = -0.2;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 3000;
  lifetimeVarianceMS = 1000;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.8 0.8 0.8 1";
  colors[1] = "0.8 0.8 0.8 0.3";
  colors[2] = "0.6 0.6 0.6 0";
  sizes[0] = 2;
  sizes[1] = 10;
  sizes[2] = 25;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_M119SmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 5;
  periodVarianceMS = 0;
  ejectionVelocity = 100;
  velocityVariance = 50;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 45;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_M119SmokeParticle";
};

datablock ShapeBaseImageData(gc_M119FireImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 1;

  stateName[0] = "FireA";
  stateTransitionOnTimeout[0] = "FireB";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 0.05;
  stateEmitter[0] = gc_M119FlashEmitter;
  stateEmitterTime[0] = 0.05;

  stateName[1] = "FireB";
  stateTransitionOnTimeout[1] = "Done";
  stateWaitForTimeout[1] = true;
  stateTimeoutValue[1] = 0.1;
  stateEmitter[1] = gc_M119SmokeEmitter; 
  stateEmitterTime[1] = 0.1;

  stateName[2] = "Done";
  stateScript[2] = "onDone";
};

function gc_M119FireImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

datablock ExplosionData(gc_M119RecoilExplosion)
{
  lifeTimeMS = 250;
  explosionScale = "1 1 1";
  shakeCamera = true;
  camShakeFreq = "1 1 1";
  camShakeAmp = "5 5 5";
  camShakeDuration = 3;
  camShakeRadius = 32;
  lightStartRadius = 32;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
};

datablock ProjectileData(gc_M119Recoil)
{
  uiName = "";
  explosion = gc_M119RecoilExplosion;
  lifetime = 1;
  fadeDelay = 1;
  explodeOnDeath = true;
};

//### Vehicle

datablock TSShapeConstructor(m119Dts)
{
  baseShape = "./m119.dts";
  sequence0 = "./root.dsq root";
  sequence1 = "./look.dsq look";
  sequence2 = "./fire.dsq fire";
};

datablock PlayerData(gc_M119TurretPlayer)
{
  renderFirstPerson = true;
  emap = false;
  className = Armor;
  shapeFile = "./m119.dts";
  cameraMaxDist = 8;
  cameraTilt = 0.261;
  cameraVerticalOffset = 2;
  cameraDefaultFov = 90;
  cameraMinFov = 5;
  cameraMaxFov = 120;
  aiAvoidThis = true;
  minLookAngle = -1.5708;
  maxLookAngle = 0.5;
  maxFreelookAngle = 3;
  mass = 200000;
  drag = 1;
  density = 5;
  maxDamage = 400;
  maxEnergy = 10;
  repairRate = 0.33;
  rechargeRate = 0.4;
  runForce = 1000;
  runEnergyDrain = 0;
  minRunEnergy = 0;
  maxForwardSpeed = 0;
  maxBackwardSpeed = 0;
  maxSideSpeed = 0;
  maxForwardCrouchSpeed = 0;
  maxBackwardCrouchSpeed = 0;
  maxSideCrouchSpeed = 0;
  maxUnderwaterForwardSpeed = 0;
  maxUnderwaterBackwardSpeed = 0;
  maxUnderwaterSideSpeed = 0;
  jumpForce = 0;
  jumpEnergyDrain = 0;
  minJumpEnergy = 0;
  jumpDelay = 0;
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
  minImpactSpeed = 250;
  speedDamageScale = 3.8;
  boundingBox = "12 12 9";
  crouchBoundingBox = "12 12 9";
  pickupRadius = 0.75;
  jetEmitter = "";
  jetGroundEmitter = "";
  jetGroundDistance = 4;
  splash = PlayerSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 0.1;
  splashEmitter[0] = PlayerFoamDropletsEmitter;
  splashEmitter[1] = PlayerFoamEmitter;
  splashEmitter[2] = PlayerBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  runSurfaceAngle = 85;
  jumpSurfaceAngle = 86;
  minJumpSpeed = 20;
  maxJumpSpeed = 30;
  horizMaxSpeed = 68;
  horizResistSpeed = 33;
  horizResistFactor = 0.35;
  upMaxSpeed = 80;
  upResistSpeed = 25;
  upResistFactor = 0.3;
  footstepSplashHeight = 0.35;
  JumpSound = "";
  groundImpactMinSpeed = 10;
  groundImpactShakeFreq = "4 4 4";
  groundImpactShakeAmp = "1 1 1";
  groundImpactShakeDuration = 0.8;
  groundImpactShakeFalloff = 10;
  maxItems = 10;
  maxWeapons = 5;
  maxTools = 5;
  uiName = "M119 Howitzer";
  rideable = true;
  lookUpLimit = 0.6;
  lookDownLimit = 0.4;
  canRide = false;
  showEnergyBar = false;
  paintable = true;
  brickImage = horseBrickImage;
  numMountPoints = 1;
  mountThread[0] = "root";
  protectPassengersBurn = false;
  protectPassengersRadius = false;
  protectPassengersDirect = false;
  useCustomPainEffects = true;
  PainHighImage = "";
  PainMidImage = "";
  PainLowImage = "";
  painSound = "";
  deathSound = "";
};

//### Functions

function gc_M119TurretPlayer::onAdd(%this,%obj)
{
  %obj.lastShotTime = getSimTime() + 4000;
  %obj.loaded = -1;
  gc_M119TurretStatus(%obj);
  parent::onAdd(%this,%obj);
}

function gc_M119TurretStatus(%obj)
{
  if(!isObject(%obj)) return;
  schedule(500,0,gc_M119TurretStatus,%obj);
  if(!isObject(%obj.getMountNodeObject(0))) return;
  %azimuth = gc_horizontalRotation(%obj);
  %V = MatrixMulVector(%obj.getSlotTransform(1),"0 0 1");
  %mag2 = VectorLen(%V);
  %x = (getWord(%obj.getSlotTransform(1),0) - getWord(%obj.getSlotTransform(1),0));
  %y = (getWord(%obj.getSlotTransform(1),1) - getWord(%obj.getSlotTransform(1),1));
  %z = (getWord(%obj.getSlotTransform(1),2) - (getWord(%obj.getSlotTransform(1),2)-2));
  %U = %x @ " " @ %y @ " " @ %z;
  %mag1 = VectorLen(%U);
  %result = VectorDot(%V,%U) / (%mag1*%mag2);
  %angle = mRadtoDeg(mACos(%result));
//  %impactdist = ((200*200)*(2*msin(%angle)*mcos(%angle)))/10;
//  %airtime = 2*(200*msin(%angle))/10;
  if(%obj.loaded == -1) %load = "None";
  else
    %load = %obj.loaded.name;
  bottomPrint(%obj.getMountNodeObject(0).client,"\c0Azimuth: \c3" @ %azimuth @ "�\c0 Elevation: \c3 " @ %angle @ "�\c0<br>\c0Loaded: \c3" @ %load,2);
}

package gc_M119Package
{
  function Player::Burn(%obj,%time) { if(%obj.dataBlock $= gc_M119TurretPlayer) return; parent::Burn(%obj,%time); }
  function Player::emote(%obj,%emote) { if(%obj.dataBlock $= gc_M119TurretPlayer) return; parent::emote(%obj,%emote); }
  function gc_M119TurretPlayer::onDisabled(%this,%obj,%state)
  {
    %p = new Projectile()
    {
      dataBlock = vehicleFinalExplosionProjectile;
      initialPosition = %obj.getPosition();
      initialVelocity = "0 0 1";
      client = %obj.lastDamageClient;
      sourceClient = %obj.lastDamageClient;
    };
    MissionCleanup.add(%p);
    %obj.schedule(10,"delete");
    if(isObject(%obj.spawnBrick))
    {
      %mg = getMiniGameFromObject(%obj);
      if(isObject(%mg)) %obj.spawnBrick.spawnVehicle(%mg.vehicleReSpawnTime);
      else
        %obj.spawnBrick.spawnVehicle(0);
    }
    parent::onDisabled(%this,%obj,%state);
  }
  function armor::onMount(%this,%obj,%col,%slot) { parent::onMount(%this,%obj,%col,%slot); if(isObject(%obj.client)) { if(%col.getDataBlock() == gc_M119TurretPlayer.getId()) ServerCmdUnUseTool(%obj.client); }
  }
  function armor::onTrigger(%this,%obj,%triggerNum,%val)
  {
    %mount = %obj.getObjectMount();
    if(%obj.getDataBlock().getID() == gc_M119TurretPlayer.getID()) %mount = %obj;
    if(isObject(%mount))
    {
      if(%mount.getDataBlock() == gc_M119TurretPlayer.getId() && %triggerNum == 0 && %val)
      {
        if(%mount.loaded == -1) { centerPrint(%obj.client,"No shell loaded!",1); parent::onTrigger(%this,%obj,%triggerNum,%val); return; }
        %client = %obj.client;
        if(isObject(%client)) ServerCmdUnUseTool(%client);
        if(getSimTime() - %mount.lastShotTime < 4000) { centerPrint(%obj.client,"Not ready to fire!",1); return; }
        %scaleFactor = getWord(%mount.getScale(),2);
        if(%mount.loaded $= gc_M119ShellLaserVehicle) {
        %p = new WheeledVehicle()
        {
          dataBlock = %mount.loaded;
          position = %mount.getSlotTransform(1);
          client = %client;
        };
        %p.setTransform(%mount.getSlotTransform(1));
        %p.setVelocity(vectorScale(%mount.getMuzzleVector(1),100));
        %obj.client.setControlObject(%p); }
        else {
        %p = new Projectile()
        {
          dataBlock = %mount.loaded;
          initialPosition = %mount.getSlotTransform(1);
          initialVelocity = vectorScale(%mount.getMuzzleVector(1),200);
          sourceObject = %obj;
          client = %obj.client;
          sourceSlot = 0;
          originPoint = %mount.getSlotTransform(1);
        };
        if(%mount.loaded $= gc_M119ShellClusterProjectile) Schedule(500,0,"gc_M119ShellClusterLoop",%p); }
        MissionCleanup.add(%p);
        %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
        %p = new Projectile()
        {
          dataBlock = gc_M119Recoil;
          initialPosition = %mount.getSlotTransform(1);
          initialVelocity = 0;
          sourceObject = %obj;
          client = %obj.client;
          sourceSlot = 0;
          originPoint = %mount.getSlotTransform(1);
        };
        MissionCleanup.add(%p);
        %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
        %mount.mountImage(gc_M119FireImage,1);
        serverPlay3D(gc_M119FireSound,%obj.getPosition());
        %mount.playThread(0,fire);
        %mount.lastShotTime = getSimTime();
        %mount.loaded = -1;
        return;
      }
    }
    parent::onTrigger(%this,%obj,%triggerNum,%val);
  }
};
activatepackage(gc_M119Package);

function gc_horizontalRotation(%obj)
{
  if(!isObject(%obj)) return;
  return (45*mcos((2*3.14159-(getword(%obj.getTransform(),5)*getword(%obj.getTransform(),6)))+3.14159*1.5));
}
