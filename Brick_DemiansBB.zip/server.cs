datablock fxDTSBrickData (brick1x5x5Data)
{
	brickFile = "./1x5x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x5x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x5x5";
};

datablock fxDTSBrickData (brick1x7x5Data)
{
	brickFile = "./1x7x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x7x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x7x5";
};

datablock fxDTSBrickData (brick1x8x5Data)
{
	brickFile = "./1x8x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x8x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x8x5";
};

datablock fxDTSBrickData (brick1x9x5Data)
{
	brickFile = "./1x9x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x9x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x9x5";
};

datablock fxDTSBrickData (brick1x10x5Data)
{
	brickFile = "./1x10x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x10x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x10x5";
};

datablock fxDTSBrickData (brick1x11x5Data)
{
	brickFile = "./1x11x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x11x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x11x5";
};

datablock fxDTSBrickData (brick1x13x5Data)
{
	brickFile = "./1x13x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x13x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x13x5";
};

datablock fxDTSBrickData (brick1x14x5Data)
{
	brickFile = "./1x14x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x14x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x14x5";
};

datablock fxDTSBrickData (brick1x15x5Data)
{
	brickFile = "./1x15x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x15x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x15x5";
};

datablock fxDTSBrickData (brick1x16x5Data)
{
	brickFile = "./1x16x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x16x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x16x5";
};

datablock fxDTSBrickData (brick1x32x5Data)
{
	brickFile = "./1x32x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x32x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x32x5";
};

datablock fxDTSBrickData (brick1x5x1Data)
{
	brickFile = "./1x5x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x5";
	iconName = "Add-Ons/Brick_DemiansBB/1x5x1";
};

datablock fxDTSBrickData (brick1x7x1Data)
{
	brickFile = "./1x7x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x7";
	iconName = "Add-Ons/Brick_DemiansBB/1x7x1";
};

datablock fxDTSBrickData (brick1x9x1Data)
{
	brickFile = "./1x9x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x9";
	iconName = "Add-Ons/Brick_DemiansBB/1x9x1";
};

datablock fxDTSBrickData (brick1x11x1Data)
{
	brickFile = "./1x11x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x11";
	iconName = "Add-Ons/Brick_DemiansBB/1x11x1";
};

datablock fxDTSBrickData (brick1x13x1Data)
{
	brickFile = "./1x13x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x13";
	iconName = "Add-Ons/Brick_DemiansBB/1x13x1";
};

datablock fxDTSBrickData (brick1x14x1Data)
{
	brickFile = "./1x14x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x14";
	iconName = "Add-Ons/Brick_DemiansBB/1x14x1";
};

datablock fxDTSBrickData (brick1x15x1Data)
{
	brickFile = "./1x15x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x15";
	iconName = "Add-Ons/Brick_DemiansBB/1x15x1";
};

datablock fxDTSBrickData (brick1x32x1Data)
{
	brickFile = "./1x32x1.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x32";
	iconName = "Add-Ons/Brick_DemiansBB/1x32x1";
};

datablock fxDTSBrickData (brick1x5fData)
{
	brickFile = "./1x5f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x5F";
	iconName = "Add-Ons/Brick_DemiansBB/1x5f";
};

datablock fxDTSBrickData (brick1x7fData)
{
	brickFile = "./1x7f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x7F";
	iconName = "Add-Ons/Brick_DemiansBB/1x7f";
};

datablock fxDTSBrickData (brick1x9fData)
{
	brickFile = "./1x9f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x9F";
	iconName = "Add-Ons/Brick_DemiansBB/1x9f";
};

datablock fxDTSBrickData (brick1x11fData)
{
	brickFile = "./1x11f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x11F";
	iconName = "Add-Ons/Brick_DemiansBB/1x11f";
};

datablock fxDTSBrickData (brick1x13fData)
{
	brickFile = "./1x13f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x13F";
	iconName = "Add-Ons/Brick_DemiansBB/1x13f";
};

datablock fxDTSBrickData (brick1x14fData)
{
	brickFile = "./1x14f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x14F";
	iconName = "Add-Ons/Brick_DemiansBB/1x14f";
};

datablock fxDTSBrickData (brick1x15fData)
{
	brickFile = "./1x15f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x15F";
	iconName = "Add-Ons/Brick_DemiansBB/1x15f";
};

datablock fxDTSBrickData (brick1x32fData)
{
	brickFile = "./1x32f.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x32F";
	iconName = "Add-Ons/Brick_DemiansBB/1x32f";
};
