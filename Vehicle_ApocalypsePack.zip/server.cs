datablock AudioProfile(MGShot)
{
   filename    = "./MGShot.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock AudioProfile(HeavyMGShot)
{
   filename    = "./HeavyMGShot.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock ParticleData(ApocCriticalDamageParticle)
{

  textureName = "base/data/particles/cloud";
	dragCoefficient      = 5;
	gravityCoefficient   = -2;
	inheritedVelFactor   = 0.9;
	constantAcceleration = 0.0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 100;
	
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.1 0.1 0.1 0.12";
	colors[1]     = "0.2 0.2 0.2 0.1";
	colors[1]     = "0.3 0.3 0.3 0.0";
	
	sizes[0]      = 3.0;
	sizes[1]      = 1.5;
	sizes[2]      = 1.0;
useInvAlpha = true;
};

datablock ParticleEmitterData(ApocCriticalDamageEmitter)
{
   ejectionPeriodMS = 9;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = ApocCriticalDamageParticle;   

};

%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Vehicle_ApocalypsePack - required add-on Weapon_Gun not found");
}
else
{
   exec("./Vehicle_ApocHeavyMG.cs"); 
}
   exec("./Vehicle_ApocFordor.cs");
   exec("./Vehicle_ApocPickup.cs");
   exec("./ApocHeavyMG.cs");  
   exec("./SideGuns.cs"); 
   exec("./support_shootonclick.cs"); 
