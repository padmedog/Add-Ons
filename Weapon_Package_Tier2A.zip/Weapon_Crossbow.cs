//audio
datablock AudioProfile(TCrossbowFire1Sound)
{
   filename    = "./cross.WAV";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(TCrossbowFireSound)
{
   filename    = "./cross_prime.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(TCrossbowClickSound)
{
   filename    = "./cross_click.WAV";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(TCrossbowTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.001;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 400;
	lifetimeVarianceMS	= 200;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "0.8 0.8 1 0.3";
	colors[1]	= "0.8 0.8 1 0.17";
	colors[2]	= "0.8 0.8 1 0.0";
	sizes[0]	= 0.15;
	sizes[1]	= 0.25;
	sizes[2]	= 0.01;
	times[0]	= 0.0;
	times[1]	= 0.1;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(TCrossbowTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0.003;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = TCrossbowTrailParticle;

   useEmitterColors = true;
};

AddDamageType("TCrossbow",   '<bitmap:add-ons/Weapon_Package_Tier2a/cross_ci> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2a/cross_ci> %1',0.75,1);
AddDamageType("TCrossbowHeadshot",   '<bitmap:add-ons/Weapon_Package_Tier2a/cross_ci> <bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot>%1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2a/cross_ci> <bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot>%1',0.75,1);
datablock ProjectileData(TCrossbowProjectile1)
{
   projectileShapeName = "./bolt.dts";
   directDamage        = 15;
   directDamageType    = $DamageType::TCrossbow;
   radiusDamageType    = $DamageType::TCrossbow;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1800;
   verticalImpulse     = 400;
   explosion           = gunExplosion;
   stickExplosion           = gunExplosion;


   muzzleVelocity      = 120;
   velInheritFactor    = 0;
   particleEmitter     = "TCrossbowTrailEmitter";

   armingDelay         = 8000;
   lifetime            = 8000;
   fadeDelay           = 7500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0.1;

   bounceAngle         = 170;
   minStickVelocity    = 10;

   explodeOnPlayerImpact = false;
   explodeOnDeath        = false; 

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "Arrow, Crossbow";
};
//////////
// item //
//////////
datablock ItemData(TCrossbowItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./hunting_crossbow.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Crossbow";
	iconName = "./crossbow";
	doColorShift = true;
	colorShiftColor = "0.32 0.31 0.3 1";

	 // Dynamic properties defined by the scripts
	image = TCrossbowImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TCrossbowImage)
{
   // Basic Item properties
	shapeFile = "./hunting_crossbow.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = TCrossbowItem;
   ammo = " ";
   projectile = TCrossbowProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = TCrossbowItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.05;
	stateSequence[0]                = "Reload";
	stateTransitionOnTimeout[0]       = "FireLoadCheckA";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnNoAmmo[1]		= "ReloadStart";
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Delay";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                  = "Fire";
	stateScript[2]                  = "onFire";
	stateSound[2]					= TCrossbowFire1Sound;
	stateWaitForTimeout[2]			= true;

	stateName[3]			= "Delay";
	stateTransitionOnTimeout[3]     = "ReloadStart";
	stateTimeoutValue[3]            = 0.1;
	stateSequence[3]                  = "Reload";
	stateEmitterTime[3]				= 0.03;
	stateEmitterNode[3]				= "muzzleNode";
	
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 0.8;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.4;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadStart";
	
	stateName[10] 				= "Smoke";
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Halt";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
	
	stateName[12]				= "Reloaded";
	stateTimeoutValue[12]			= 0.04;
	stateScript[12]				= "onReloaded";
	stateTransitionOnTimeout[12]		= "Ready";

	stateName[13]			= "Halt";
	stateTransitionOnTimeout[13]     = "Ready";
	stateTimeoutValue[13]            = 0.9;
	stateEmitterTime[13]				= 0.48;
	stateEmitterNode[13]				= "muzzleNode";
	stateScript[13]                  = "onHalt";

	stateName[14]                    = "Charge";
	stateTransitionOnTimeout[14]	= "Armed";
	stateTimeoutValue[14]            = 0.8;
	stateWaitForTimeout[14]		= false;
	stateScript[14]                  = "onCharge";
	stateAllowImageChange[14]        = false;
	stateSound[14]					= TCrossbowFireSound;

	stateName[15]			= "Armed";
	stateTransitionOnTriggerUp[15]	= "Fire";
	stateAllowImageChange[15]	= false;
	stateScript[15]                  = "onArmed";
	stateSound[15]				= Block_PlantBrick_Sound;

	stateName[16]                     = "ReloadStart";
	stateTransitionOnTimeout[16]  = "ReloadStartB";
	stateTimeoutValue[16]            = 0.1;
	stateAllowImageChange[16]         = false;

	stateName[17]                     = "ReloadStartB";
	stateTransitionOnTimeout[17]  = "LoadCheckA";
	stateTimeoutValue[17]            = 0.01;
	stateAllowImageChange[17]         = true;
};

function TCrossbowImage::onFire(%this,%obj,%slot)
{
	Parent::onFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;

	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.playThread(2, plant);
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
	}
}

function TCrossbowImage::onReloadStart(%this,%obj,%slot)
{
	%obj.pushDatablock(TCrossbowDawdleArmor.getID());
            		serverPlay3D(TcrossbowFireSound,%obj.getPosition());
	%obj.toolAmmo[%obj.currTool] = 0;commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
	%obj.playThread(2, shiftleft);
}

function TCrossbowImage::onReloadWait(%this,%obj,%slot)
{
	%obj.playThread(2,plant);
	   //%obj.popDatablock(TCrossbowDawdleArmor.getID());
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
}

function TCrossbowImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["boltrounds"] >= 1)
	{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
		%obj.client.quantity["boltrounds"]--;
	}
		%obj.toolAmmo[%obj.currTool]++;
            		serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function TCrossbowImage::onCharge(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
	}
}

function TCrossbowImage::onArmed(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
	}
}

function TCrossbowImage::onReady(%this,%obj,%slot)
{
	   //%obj.popDatablock(TCrossbowDawdleArmor.getID());
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Standard Steel Bolt <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["boltrounds"] @ "", 4, 2, 3, 4); 
	}
}


function TCrossbowImage::onUnMount(%this,%obj,%slot)
{
   Parent::onUnMount(%this,%obj,%slot);

//%obj.popDatablock(TCrossbowDawdleArmor.getID());
}

function TCrossbowProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 20;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 6;
         %damageType = $DamageType::TCrossbowHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}