%error1 = ForceRequiredAddOn("Support_Garage");
%error2 = ForceRequiredAddOn("Vehicle_Jeep");

if(%error1 == $Error::AddOn_NotFound || %error2 == $Error::AddOn_NotFound)
{
   if(%error1 == $Error::AddOn_NotFound)
      error("ERROR: Vehicle_MicroCar - required add-on Support_Garage not found");
   if(%error2 == $Error::AddOn_NotFound)
      error("ERROR: Vehicle_MicroCar - required add-on Vehicle_Jeep not found");
}
else
{
   exec("./MicroCar_Tire.cs");
	exec("./MicroCar_Explosion.cs");
	exec("./MicroCar_FinalExplosion.cs");
	exec("./MicroCar_Spring.cs");  
	
	exec("./MicroCar.cs"); 
	exec("./MicroCar2.cs"); 
	exec("./MicroCar3.cs"); 
	
	exec("./Support_HandsOnVehicle.cs");  
}