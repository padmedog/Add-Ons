exec("./Updater.cs");

package Server_Perms_Updater {
	function authTCPobj_Server::onDisconnect(%this) {
		checkPermsUpdate();
		return parent::onDisconnect(%this);
	}
}; activatePackage(Server_Perms_Updater);

function Permissions_Updatecheck_Available(%path) {
	echo("There is an update available for Server_Permissions, enter updatePermissions(); into the console to update.");
}

function Permissions_Updater_Done() {
	echo("The update was downloaded. Please restart Blockland.");
}