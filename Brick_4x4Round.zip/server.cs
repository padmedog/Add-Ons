datablock fxDTSBrickData(brick4x4roundData)
{
	brickFile = "./4x4round.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "4x4 Round";
	iconName = "Add-Ons/Brick_4x4Round/4x4round.png";
	collisionShapeName = "./4x4round.dts";
};