//Inverted Corner Ramp Bricks - by Space Guy

datablock fxDTSBrickData (brickRampInv45data)
{
	brickFile = "./2x2InvCorner.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "45� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_InvertedCorners/45 Inv Ramp";
	
	brickSizeX = 2;
	brickSizeY = 2;
	brickSizeZ = 3;
	canCoverTop = 1;
	canCoverBottom = 1;
	canCoverNorth = 1;
	canCoverSouth = 0;
	canCoverEast = 0;
	canCoverWest = 1;
	
	eastArea = 3;
	southArea = 3;
	
	orientationFix = 1;
};

datablock fxDTSBrickData (brickRampInvMinus45data)
{
	brickFile = "./2x2InvUpCorner.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_InvertedCorners/-45 Inv Ramp";
	
	brickSizeX = 2;
	brickSizeY = 2;
	brickSizeZ = 3;
	canCoverTop = 1;
	canCoverBottom = 1;
	canCoverNorth = 1;
	canCoverSouth = 0;
	canCoverEast = 0;
	canCoverWest = 1;
	
	eastArea = 3;
	southArea = 3;
	
	orientationFix = 1;
};