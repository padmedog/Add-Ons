//////////
// item //
//////////
datablock ItemData(L4BNailbatItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Nailbat.1.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Nailbat";
	iconName = "./nailbat";
	doColorShift = false;
	colorShiftColor = "0.7 0.1 0.1 1.000";

	 // Dynamic properties defined by the scripts
	image = L4BNailbatImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
AddDamageType("L4BNailbat",   '<bitmap:Add-Ons/weapon_melee_extended_ii/bat> %1',    '%2 <bitmap:Add-Ons/weapon_melee_extended_ii/bat> %1',0.75,1);
datablock ShapeBaseImageData(L4BNailbatImage)
{
   shapeFile = "./Nailbat.1.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 0.0 0.5";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "TF2MeleeWeaponImage";

   // Projectile && Ammo.
   item = L4BNailbatItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = false;
   colorShiftColor = L4BNailbatItem.colorShiftColor;
   
   raycastWeaponRange = 3.5;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = L4BBatonHitSoundA;
   raycastExplosionPlayerSound = L4BBatonHitSoundB;
   raycastDirectDamage = 55;
   raycastDirectDamageType = $DamageType::L4BNailbat;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateTransitionOnTimeout[0]      = "Ready";
	stateScript[0]                  = "onActivate";
	stateSequence[0]                 = "Activate";
	stateSound[0]                    = weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.05;
	stateTransitionOnTimeout[2]     = "FireA";
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "FireB";
	stateTimeoutValue[3]            = 0.10;
	stateSequence[3]                 = "Swing";
	stateAllowImageChange[3]        = false;
	stateSound[3]			= tf2MeleeSwingSound;
	stateScript[3]                  = "onFireB";
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "FireB";
	stateTransitionOnTimeout[4]     = "Wait";
	stateTimeoutValue[4]            = 0.15;
	stateSequence[4]                 = "Activate";
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		= true;
	
	stateName[5]			= "Wait";
	stateTransitionOnTimeout[5]	= "CheckFire";
	stateTimeoutValue[5]		= 0.1;
	stateScript[5]			= "onStopFire";
	stateAllowImageChange[5]	= false;
	stateWaitForTimeout[5]		= true;

	stateName[6]			= "CheckFire";
	stateTransitionOnTriggerUp[6]	= "StopFire";
	stateTransitionOnTriggerDown[6]	= "PreFire";
	
	stateName[7]                    = "StopFire";
	stateTransitionOnTimeout[7]     = "Ready";
	stateTimeoutValue[7]            = 0.2;
	stateAllowImageChange[7]        = false;
	stateWaitForTimeout[7]		= true;
	stateSequence[7]                = "StopFire";
	stateScript[7]                  = "onStopFire";
};

function L4BNailbatImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);

	if(getRandom(0,1))
	{
		%this.raycastExplosionBrickSound = L4BMacheteHitSoundA;
		%this.raycastExplosionPlayerSound =meleeHammerSound;
	}
	else
	{
		%this.raycastExplosionBrickSound = L4BMacheteHitSoundB;
		%this.raycastExplosionPlayerSound =meleeHammerSound;
	}

	WeaponImage::onFire(%this, %obj, %slot);
}

function L4BNailbatImage::onFireB(%this, %obj, %slot)
{
	//%obj.playthread(2, shiftaway);
}

function L4BNailbatImage::onActivate(%this, %obj, %slot)
{
	%obj.playthread(2, plant);
}
