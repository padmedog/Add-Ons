//================================================================
// Client_DevTools
// Development Tools
//
// Jincux (BL_ID 9789)
//================================================================

$DevTools::Version = "1.3.0";
$DevTools::Debug = false;

echo("DevTools v" @ $DevTools::Version);

if(!$DevTools::LoadedGui) {
  exec("./ConsoleDlg.gui");
  %id = ConsoleDlg.getId();

  ConsoleDlg_New.setName(ConsoleDlg);
  testArrayTemp.delete();
  ConsoleWindow.getObject(0).add(testArrayCtrl);

  %id.deleteAll();
  %id.delete();

  $DevTools::LoadedGui = true;
}

function DevTools::addFile(%file) {
  if(trim(%file) $= "" || !isFile(%file)) {
    return;
  }

  $DevTools::Files++;
  $DevTools::File[$DevTools::Files-1] = %file;
  $DevTools::Modified[%file] = getFileModifiedTime(%file);
  DevTools_ScriptList.addRow($DevTools::Files-1, %file);
  ConsoleEntry.makeFirstResponder(true);
}

function DevTools::checkFiles() {
  for(%i = 0; %i < $DevTools::Files; %i++) {
    %file = $DevTools::File[%i];
    %mod = getFileModifiedTime(%file);
    if(%mod !$= $DevTools::Modified[%file]) {
      DevTools_ScriptList.setRowById(%i, "\c4" @ %file);
    } else {
      DevTools_ScriptList.setRowById(%i, %file);
    }
  }
}

function DevTools::loadFromSave() {
  if(isfile("config/client/devtools.cs")) {
    exec("config/client/devtools.cs");
  }

  DevTools_ScriptList.clear();

  %newCount = 0;
  for(%i = 0; %i < $DevTools::Files; %i++) {
    %file = $DevTools::File[%i];
    if(isFile(%file) && !%fileLoaded[%file]) {
      $DevTools::File[%newCount] = %file;
      DevTools_ScriptList.addRow(%newCount, %file);
      %newCount++;
      %fileLoaded[%file] = true;
      $DevTools::Modified[%file] = getFileModifiedTime(%file);
    }
  }
  $DevTools::Files = %newCount;
}

function DevTools::loadSelectedScript() {
  %id = DevTools_ScriptList.getSelectedId();
  if(%id != -1) {
    %file = $DevTools::File[%id];
    discoverFile("*");
    exec(%file);
    $DevTools::Modified[%file] = getFileModifiedTime(%file);
    DevTools::checkFiles();
  }
}

function DevTools::initalizeGui() {
  DevTools_ConsoleEntry.position = DevTools_Image.position;
  DevTools_ConsoleEntry.extent = DevTools_Image.extent;
  DevTools_ConsoleEntry.click = "";
}

function DevTools_Mouse::onMouseDragged(%this, %a, %pos, %c, %d) {
  if(%this.dragPos $= "")
    return;
  %this.dragging = true;

  %move = vectorSub(%this.dragPos, %pos);

  if(getWord(ConsoleDlg.extent, 1) < getWord(ConsoleEntry.extent, 1)+getWord(ConsoleEntry.position, 1) && getWord(%move, 1) < 0) {
    %move = 0 SPC getWord(ConsoleEntry.extent, 1)+getWord(ConsoleEntry.position, 1)-getWord(ConsoleDlg.extent, 1)-1;
  }

  if(100 > getWord(ConsoleEntry.extent, 1)+getWord(ConsoleEntry.position, 1) && getWord(%move, 1) > 0) {
    %move = 0 SPC getWord(ConsoleEntry.extent, 1)+getWord(ConsoleEntry.position, 1)-99;
  }


  ConsoleEntry.position = 0 SPC (getWord(ConsoleEntry.position, 1)-getWord(%move, 1));

  %scroll = ConsoleWindow.getObject(0);
  %scroll.extent = getWord(%scroll.extent, 0) SPC getWord(ConsoleEntry.position, 1)+1;
  %scroll.resize(0, 0, getWord(%scroll.extent, 0), getWord(%scroll.extent, 1));

  if(%this.lockToBottom) {
    %scroll.scrollToBottom();
  }

  DevTools_Image.position = getWord(%scroll.extent, 0)-14 SPC getWord(%scroll.extent, 1)-14;

  ConsoleWindow.extent = getWord(ConsoleWindow.extent, 0) SPC (getWord(ConsoleWindow.extent, 1)-getWord(%move, 1));

  %this.dragPos = %pos;
}

function DevTools_ConsoleEntry::onMouseDown(%this, %a, %pos, %c, %d) {
  if(getSimTime() - %this.click < 250 && %this.click !$= "") {
    %this.onDoubleClick();
    DevTools_Mouse.dragPos = "";
    %this.click = getSimTime();
    return;
  }

  ConsoleEntry.makeFirstResponder(true);

  %this.click = getSimTime();

  if(getWord(testArrayCtrl.position, 1)+getWord(testArrayCtrl.extent, 1)-getWord(testArrayCtrl.getGroup().extent, 1) == -16) {
    DevTools_Mouse.lockToBottom = true;
  } else {
    DevTools_Mouse.lockToBottom = false;
  }

  DevTools_Mouse.dragPos = %pos;
  DevTools_Mouse.position = "0 0";
  DevTools_Mouse.extent = ConsoleDlg.extent;
  ConsoleDlg.pushToBack(DevTools_Mouse);
}

function DevTools_ConsoleEntry::onDoubleClick() {
  ConsoleDlg.bringToFront(DevTools_Mouse);
  ConsoleEntry.makeFirstResponder(true);

  MessageBoxYesNo("Clipboard", "Copy entry to clipboard?", "setClipboard(ConsoleEntry.getValue());");
}

function DevTools_Mouse::onMouseUp(%this) {
  DevTools_ConsoleEntry.position = DevTools_Image.position;
  DevTools_ConsoleEntry.extent = DevTools_Image.extent;
  %this.dragging = false;
  %this.dragPos = "";
  DevTools_Mouse.position = "0 0";
  DevTools_Mouse.extent = "0 0";
  ConsoleDlg.bringToFront(DevTools_Mouse);
  ConsoleEntry.makeFirstResponder(true);
}

package DevTools {
  function toggleConsole(%tog) {
    parent::toggleConsole(%tog);

    if(%tog)
      DevTools::checkFiles();

    ConsoleDlg.pushToBack(DevTools_ConsoleEntry);
    ConsoleEntry.makeFirstResponder(true);
  }

  function onWindowReactivate() {
    parent::onWindowReactivate();

    DevTools::checkFiles();
    ConsoleDlg.pushToBack(DevTools_ConsoleEntry);
    ConsoleEntry.makeFirstResponder(true);
  }

  function onExit() {
    export("$DevTools::File*", "config/client/devtools.cs");
    parent::onExit();
  }
};
activatePackage(DevTools);
DevTools::initalizeGui();
DevTools::loadFromSave();
