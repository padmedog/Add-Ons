/////////////////////////////////////////////////////////////////////////////////////////////////
//Prop_Buttons
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
//Made by Jaydee
/////////////////////////////////////////////////////////////////////////////////////////////////


//ButtonA
/////////////////////////////////////////////////////////////////////////////////////////////////

	datablock decalData(BAIcon)
	{
		textureName = "add-ons/prop_buttons/A";
		preload = true;
	};

	datablock StaticShapeData(BAShape)
	{
		shapefile="add-ons/prop_buttons/buttonA.dts";
	};

	datablock fxDtsBrickData(BABrickData)
	{
		category="Props";
		subCategory="Jaydee's Buttons";
		uiName="Button A";
		iconName = "add-ons/prop_buttons/A";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=1;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=BAShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

//ButtonB
/////////////////////////////////////////////////////////////////////////////////////////////////

	datablock decalData(BBIcon)
	{
		textureName = "add-ons/prop_buttons/B";
		preload = true;
	};

	datablock StaticShapeData(BBShape)
	{
		shapefile="add-ons/prop_buttons/buttonB.dts";
	};

	datablock fxDtsBrickData(BBBrickData)
	{
		category="Props";
		subCategory="Jaydee's Buttons";
		uiName="Button B";
		iconName = "add-ons/prop_buttons/B";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=1;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=BBShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

//ButtonC
/////////////////////////////////////////////////////////////////////////////////////////////////

	datablock decalData(BCIcon)
	{
		textureName = "add-ons/prop_buttons/C";
		preload = true;
	};

	datablock StaticShapeData(BCShape)
	{
		shapefile="add-ons/prop_buttons/buttonC.dts";
	};

	datablock fxDtsBrickData(BCBrickData)
	{
		category="Props";
		subCategory="Jaydee's Buttons";
		uiName="Light Switch";
		iconName = "add-ons/prop_buttons/C";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=3;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=1;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=BCShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

//ButtonD
/////////////////////////////////////////////////////////////////////////////////////////////////

	datablock decalData(BDIcon)
	{
		textureName = "add-ons/prop_buttons/D";
		preload = true;
	};

	datablock StaticShapeData(BDShape)
	{
		shapefile="add-ons/prop_buttons/buttonD.dts";
	};

	datablock fxDtsBrickData(BDBrickData)
	{
		category="Props";
		subCategory="Jaydee's Buttons";
		uiName="Elevator Switch A";
		iconName = "add-ons/prop_buttons/D";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=3;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=1;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=BDShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

//ButtonE
/////////////////////////////////////////////////////////////////////////////////////////////////

	datablock decalData(BEIcon)
	{
		textureName = "add-ons/prop_buttons/E";
		preload = true;
	};

	datablock StaticShapeData(BEShape)
	{
		shapefile="add-ons/prop_buttons/buttonE.dts";
	};

	datablock fxDtsBrickData(BEBrickData)
	{
		category="Props";
		subCategory="Jaydee's Buttons";
		uiName="Elevator Switch B";
		iconName = "add-ons/prop_buttons/E";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=3;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=1;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=BEShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

//ButtonF
/////////////////////////////////////////////////////////////////////////////////////////////////

	datablock decalData(BFIcon)
	{
		textureName = "add-ons/prop_buttons/F";
		preload = true;
	};

	datablock StaticShapeData(BFShape)
	{
		shapefile="add-ons/prop_buttons/buttonF.dts";
	};

	datablock fxDtsBrickData(BFBrickData)
	{
		category="Props";
		subCategory="Jaydee's Buttons";
		uiName="Elevator Switch C";
		iconName = "add-ons/prop_buttons/F";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=3;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=1;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=BFShape;
		modelOffset="0 0 0";
		modelScale="1 1 1";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};