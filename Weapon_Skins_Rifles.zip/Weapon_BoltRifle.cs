datablock AudioProfile(LeverRifleClickSound)
{
   filename    = "./leverrifle_click.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("BoltRifle",   '<bitmap:add-ons/Weapon_Skins_Rifles/CI_replica_rifle> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Rifles/ci_replica_rifle> %1',0.75,1);
AddDamageType("BoltRifleHeadshot",   '<bitmap:add-ons/Weapon_Skins_Rifles/ci_replica_rifle> <bitmap:add-ons/Weapon_Package_Tier1/CI_tactheadshot>%1',    '%2 <bitmap:add-ons/Weapon_Skins_Rifles/ci_replica_rifle> <bitmap:add-ons/Weapon_Package_Tier1/CI_tactheadshot>%1',0.75,1);

////////////////////////////////////////////////////////////////////////////////////////////////projectile
datablock ProjectileData(BoltRifleProjectile : SportRifleProjectile)
{
   directDamage        = sportrifleprojectile.directdamage; //90
   directDamageType    = $DamageType::BoltRifle;
};

datablock ProjectileData(BoltRifleWeakProjectile : SportRifleWeakProjectile)
{
   directDamageType    = $DamageType::BoltRifle;
};


////////////////////////////////////////////////////////////////////////////////////////////////item
datablock ItemData(BoltRifleItem : SportRifleItem)
{
	shapeFile = "./LEVER_RIFLE.dts";
	uiName = "Lever Rifle";
	iconName = "./leverrifle";
	colorShiftColor = "0.35 0.35 0.35 1.000";
	image = BoltRifleImage;
   maxAmmo = 8;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(BoltRifleImage : SportRifleImage)
{
	shapeFile = "./LEVER_RIFLE.dts";
   item = BoltRifleItem;
   projectile = BoltRifleProjectile;
   projectileType = Projectile;
   doColorShift = true;
   colorShiftColor = BoltRifleItem.colorShiftColor;

	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.25;
	stateSequence[0]			  = "Activate";
	stateTransitionOnTimeout[0]     = "Smoke";
	stateSound[0]			  = weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1] = "Reload";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.42;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
	stateEmitter[2]			  = gunFlashEmitter;
	stateEmitterTime[2]		  = 0.05;
	stateEmitterNode[2]		  = "muzzleNode";
	stateSound[2]			  = SportRiflefireSound;

	stateName[3] 			  = "Smoke";
	stateSequence[3]			  = "fire";
	stateScript[3]				= "onSmoke";
	stateTimeoutValue[3]            = 0.3;
	stateSound[3]			  = LeverRifleClickSound;
	stateTransitionOnTimeout[3]     = "LoadCheckA";

	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 1.4;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.5;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadSmoke";
	
	stateName[10] 				= "ReloadSmoke";
	stateEmitter[10]			= gunSmokeEmitter;
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Reload";
	
	stateName[11]				= "Reloaded";
	stateTimeoutValue[11]			= 0.1;
	stateScript[11]				= "onReloaded";
	stateTransitionOnTimeout[11]		= "Ready";
};


function BoltRifleImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, shiftAway);

	//Parent::onFire(%this,%obj,%slot);
	
	if(vectorLen(%obj.getVelocity()) < 4 && (getSimTime() - %obj.lastShotTime) > 1000)
	{
		%projectile = BoltRifleProjectile;
		%spread = 0.0000;
	}
	else
	{
		%projectile = BoltRifleWeakProjectile;
		%spread = 0.0004;
	}
	
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);	
}

function BoltRifleImage::onSmoke(%this,%obj,%slot)
{
	%obj.playThread(2, shiftRight);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
}


function BoltRifleImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
}

function BoltRifleImage::onReloadStart(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, shiftRight);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function BoltRifleImage::onReloadWait(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, plant);
            serverPlay3D(magazineOutSound,%obj.getPosition());
	}
}

function BoltRifleImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.client.quantity["556rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["556rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["556rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["556rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["556rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["556rounds"] = 0;

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

function BoltRifleProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 24;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 2;
         %damageType = $DamageType::BoltRifleHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}

function BoltRifleWeakProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 24;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 2;
         %damageType = $DamageType::BoltRifleHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}