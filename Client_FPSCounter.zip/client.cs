$fpscounter = new GuiMLTextCtrl()
{
	profile = "GuiMLTextProfile";
	horizSizing = "right";
	vertSizing = "bottom";
	position = "0 0";
	extent = "64 15";
	minExtent = "8 2";
	visible = "1";
	lineSpacing = "2";
	allowColorChars = "0";
	maxChars = "-1";
	text = "<color:ffff00><font:arial:15>999";
	maxBitmapHeight = "-1";
	selectable = "0";
	noCursor = "1";
};

playGui.add($fpscounter);

$fpsc_pos	= 0;
$fpsc_tick	= 100;
$fpsc_color	= "ffffff";
$fpsc_font	= "impact";
$fpsc_size	= 24;

$remapDivision[$remapCount] = "FPS Counter";
$remapName[$remapCount] = "Toggle FPS Display";
$remapCmd[$remapCount] = "togFPSDisp";
$remapCount++;

$fpscounterisopen = 1;
function togFPSdisp(%a)
{
	if(!%a)
		return;
	if($fpscounterisopen)
	{
		$fpscounter.visible = 0;
		$fpscounterisopen = 0;
		//fpsdisptog.setText(0);
	}
	else
	{
		$fpscounter.visible = 1;
		$fpscounterisopen = 1;
		//fpsdisptog.setText(1);
	}
}

function FPSTick()
{
	if($fpsticking)
	{
		if($fpslowest $= "")
			$fpslowest = $fps::real;
		if($fpslowest <= 1)
			$fpslowest = 50;
		if($fpshighest $= "")
			$fpshighest = $fps::real;
		if($fps::real < $fpslowest)
			$fpslowest = $fps::real;
		if($fps::real > $fpshighest)
			$fpshighest = $fps::real;
		$fpscounter.setText("<just:center><color:" @ $fpsc_color @ "><font:" @ $fpsc_font @ ":" @ $fpsc_size @ ">" @ "<shadow:1:1><shadowcolor:000000>" @ mFloor($fps::real) @ "" NL "" @ "<color:ff0000><font:arial:13>" @ mFloor($fpslowest) @ "   <color:ffff00><font:arial:15>" @ mFloor($fpsaverage) @ "<color:00ff00><font:arial:13>   " @ mFloor($fpshighest));
		$Pref::FPSCounter::posadd = $fps_x SPC $fps_y;
		$fpscounter.position = (getWord(getRes(),0) - 75) + getWord($Pref::FPSCounter::posadd,0) SPC (getWord(getRes(),1) - 58) + getWord($Pref::FPSCounter::posadd,1);
		
		if($fpsavgcount >= 1000)
			$fpsavgcount = 0;
		else
			$fpsavgcount++;
		$fpsavg[$fpsavgcount] = $fps::real;
		
		cancel($FPSTick);
		schedule($fpsc_tick,0,"FPSTick",1);
	}
}

function FPSAVGTick()
{
	if($fpsavgticking)
	{
		for(%i=0;%i<=1000;%i++)
			%total += $fpsavg[%i];
		$fpsaverage = %total / 1000;
		
		cancel($FPSAVGTick);
		schedule(5000,0,"FPSAVGTick");
	}
}

$fpsticking = 1;
FPSTick();
$fpsavgticking = 1;
FPSAVGTick();