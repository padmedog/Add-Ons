//gun.cs

datablock AudioProfile(quakeLauncherReloadSound)
{
   filename    = "./reload_4.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(quakeLauncherFireSound)
{
   filename    = "./rotary_fire.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(quakeLauncherBlastSound)
{
   filename    = "./grenade_blast_2.wav";
   description = AudioClose3d;
   preload = true;
};


datablock ParticleData(quakeLauncherFireParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 40;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/star1";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "1.0 0.5 0 0.9";
    colors[1]     = "0.9 0.4 0 0.8";
    colors[2]     = "1 0.5 0.2 0.6";
    colors[3]     = "1 0.5 0.2 0.4";

    sizes[0]      = 2.95;
   sizes[1]      = 0.3;
    sizes[2]      = 0.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(quakeLauncherFireEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 74.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "quakeLauncherFireParticle";
};

datablock ParticleData(quakeLauncherTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 350;
	lifetimeVarianceMS	= 150;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 0 0.26";
	colors[1]	= "1 1 1 0.14";
	colors[2]	= "0.7 0.7 0.7 0";
	sizes[0]	= 1.8;
	sizes[1]	= 0.65;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.02;
	times[2]	= 1.0;
};
datablock ParticleEmitterData(quakeLauncherTrailEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 2;
   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;
   ejectionOffset = 0;
   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = quakeLauncherTrailParticle;
};

datablock ParticleData(quakeLauncherSmokeParticle)
{
    dragCoefficient      = 3;
    gravityCoefficient   = -8;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 100;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/cloud";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "0.6 0.6 0.6 0.4";
    colors[1]     = "0.7 0.7 0.7 0.3";
    colors[2]     = "1 1 1 0.2";
    colors[3]     = "1 1 1 0";

    sizes[0]      = 0.55;
   sizes[1]      = 0.4;
    sizes[2]      = 0.10;
    sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(quakeLauncherSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 22.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "quakeLauncherSmokeParticle";
};

datablock ParticleData(quakeLauncherExplosionParticle)
{
	dragCoefficient		= 3.5;
	windCoefficient		= 3.5;
	gravityCoefficient	= -1;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 800;
	lifetimeVarianceMS	= 00;
	spinSpeed		= 25.0;
	spinRandomMin		= -25.0;
	spinRandomMax		= 25.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
   colors[0]     = "1 1 1 0.1";
   colors[1]     = "0.9 0.5 0.0 0.3";
   colors[2]     = "0.1 0.05 0.025 0.1";
   colors[3]     = "0.1 0.05 0.025 0.0";

	sizes[0]	= 4.0;
	sizes[1]	= 6.3;
   sizes[2]	= 6.5;
   sizes[3]	= 4.5;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 0.8;
   times[3]	= 1.0;
};

datablock ParticleData(quakeLauncherFlashParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 60;
	lifetimeVarianceMS   = 40;
	textureName          = "./blastflash2";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

	colors[0]     = "1 1 1 1";
	colors[1]     = "0.9 0.5 0.0 0.9";

	sizes[0]      = 10.55;
	sizes[1]      = 18.55;

	useInvAlpha = false;
};
datablock ParticleEmitterData(quakeLauncherFlashEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   lifeTimeMS	   = 121;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 2.0;
   thetaMin         = 00;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakeLauncherFlashParticle";
};

datablock ParticleEmitterData(quakeLauncherExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 4;
   velocityVariance = 3.0;
   ejectionOffset   = 2.0;
   thetaMin         = 00;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakeLauncherExplosionParticle";
};

datablock ParticleData(quakeLauncherExplosionParticle2)
{
	dragCoefficient		= 5.0;
	windCoefficient		= 1.0;
	gravityCoefficient	= -0.50;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 400;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 5.0;
	spinRandomMin		= -5.0;
	spinRandomMax		= 5.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
   colors[0]     = "0.95 0.9 0.8 0.6";
   colors[1]     = "0.1 0.05 0.025 0.4";
   colors[2]     = "0.1 0.05 0.025 0.0";

	sizes[0]	= 7.0;
	sizes[1]	= 10.0;
   sizes[2]	= 10.5;

	times[0]	= 0.0;
	times[1]	= 0.02;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(quakeLauncherExplosionEmitter2)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 8;
   velocityVariance = 2.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 30;
   phiVariance      = 32;
   overrideAdvance = false;
   particles = "quakeLauncherExplosionParticle2";
};


datablock ExplosionData(quakeLauncherExplosion : gunExplosion)
{
   //explosionShape = "";

   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";

   particleEmitter = quakeLauncherFlashEmitter;
   soundProfile = quakeLauncherBlastSound;

   emitter[0] = quakeLauncherFlashEmitter;
   emitter[1] = quakeLauncherExplosionEmitter2;
   emitter[2] = quakeLauncherExplosionEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 10;
   lightEndRadius = 25;
   lightStartColor = "1 1 1 1";
   lightEndColor = "0 0 0 1";

   damageRadius = 4;
   radiusDamage = 80;

   impulseRadius = 5;
   impulseForce = 1000;
};

AddDamageType("quakeLauncher",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_rotarygrenade> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_rotarygrenade> %1',0.2,1);
datablock ProjectileData(quakeLauncherProjectile : gunProjectile)
{
   projectileShapeName = "./quake_grenade.dts";

   directDamage        = 40;
   directDamageType    = $DamageType::quakeLauncher;
   radiusDamageType    = $DamageType::quakeLauncher;

   impactImpulse	     = 100;
   verticalImpulse	  = 200;
   explosion           = quakeLauncherExplosion;
   particleEmitter     = quakeLauncherTrailEmitter; //bulletTrailEmitter;

   muzzleVelocity      = 50;
   velInheritFactor    = 0;

   armingDelay         = 300;
   lifetime            = 600;
   fadeDelay           = 500;
   bounceElasticity    = 0.9;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 1;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(quakeLauncherItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./rotary_launcher.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Rotary Grenade";
	iconName = "./rotarygrenade";
	doColorShift = true;
	colorShiftColor = "0.65 0.65 0.65 1.000";

	 // Dynamic properties defined by the scripts
	image = quakeLauncherImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(quakeLauncherImage)
{
   // Basic Item properties
	shapeFile = "./rotary_launcher.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = quakeLauncherProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = quakeLauncherItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.07;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakeLauncherFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= quakeLauncherFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakeLauncherSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateScript[3]                  = "onSmoke";
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.38;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "reload";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.5;
	stateTransitionOnTimeout[5]     = "Wait";
	stateSound[5]					= quakeLauncherReloadSound;

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.04;
	stateTransitionOnTimeout[6]     = "Ready";
};

function quakeLauncherImage::onFire(%this,%obj,%slot)
{
	%projectile = quakeLauncherProjectile;
	%spread = 0.0005;
	%shellcount = 1;

	%obj.playThread(2, plant);
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}

function quakeLauncherImage::onSmoke(%this,%obj,%slot)
{
	%obj.playThread(2, shiftaway);	
}
function quakeLauncherImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, plant);	
	%obj.playThread(0, shiftright);
}
