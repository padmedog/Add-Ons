datablock fxDTSBrickData (brickChristmasTreeData){
	brickFile = "Add-Ons/Brick_Christmas_Tree/christmasTree.blb";
   collisionShapeName = "base/data/shapes/bricks/pineTree.dts";

	canCover = false;

	category = "Special";
	subCategory = "Misc";
	uiName = "Christmas Tree";
	iconName = "Add-Ons/Brick_Christmas_Tree/Christmas Tree";
};
