registerOutputEvent(GameConnection,playSound,"dataBlock Sound",0);
function GameConnection::playSound(%this,%sound)
{
 if(!isObject(%sound) || %sound.getClassName() !$= "AudioProfile")
  return;
 
 if(%sound.description.isLooping)
  return;
 
 %this.play2d(%sound);
}