//////////
// Blue //
//////////


datablock ParticleData(StormBlasterBlueExplosionParticle)
{
	dragCoefficient		= 1;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.2;
	constantAcceleration = 0.0;
	lifetimeMS			  = 200;
	lifetimeVarianceMS	= 100;
	textureName			 = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]	  = "0.157 0.44 1 0.9";
	colors[1]	  = "0.157 0.44 1 0.8";
	colors[2]	  = "0.057 0.34 1 0.6";
	colors[3]	  = "0.057 0.34 1 0.4";

	sizes[0]		= 0.1;
	sizes[1]		= 0.1;
	sizes[2]		= 0.15;
	sizes[3]		= 0.2;

	times[0] = 0.0;
	times[1] = 0.3;
	times[2] = 0.6;
	times[3] = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(StormBlasterBlueExplosionEmitter)
{
	ejectionPeriodMS = 10;
	periodVarianceMS = 0;
	ejectionVelocity = 10;
	velocityVariance = 0.0;
	ejectionOffset	= 0.0;
	thetaMin			= 40;
	thetaMax			= 100;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "StormBlasterBlueExplosionParticle";

	uiName = "Storm Blaster Explosion - Blue";
};

datablock ExplosionData(StormBlasterBlueExplosion)
{
	explosionShape = "";
	soundProfile = StormHitSound;

	lifeTimeMS = 100; //400

	particleEmitter = StormBlasterBlueExplosionEmitter;
	particleDensity = 200;
	particleRadius = 0.1;

	emitter[0] = StormBlasterBlueExplosionEmitter;

	//subExplosion[0] = "";
	//subExplosion[1] = StormBlasterBlueSubExplosion1;

	faceViewer	  = true;
	explosionScale = "0.1 0.1 0.1";

	shakeCamera = false;
	camShakeFreq = "1.0 11.0 10.0";
	camShakeAmp = "3.0 10.0 3.0";
	camShakeDuration = 0.5;
	camShakeRadius = 20.0;

	// Dynamic light
	lightStartRadius = 10;
	lightEndRadius = 20;
	lightStartColor = "0.157 0.44 1 1";
	lightEndColor = "0.157 0.44 1 0";

	damageRadius = 0;
	radiusDamage = 0;

	impulseRadius = 2;
	impulseForce = 1000;

	playerBurnTime = 0;
};

datablock ParticleData(StormBlasterBlueTrailParticle)
{
	dragCoefficient		= 0.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 300;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	  = "0.157 0.44 1 1";
	colors[1]	  = "0.157 0.44 1 1";
	colors[2]	  = "0.057 0.34 1 1";
	colors[3]	  = "0.075 0.212 0.4667 1";

	sizes[0]	= 0.4;
	sizes[1]	= 0.25;
	sizes[2]	= 0.1;
	sizes[3]	= 0.0;

	times[0]	= 0.2;
	times[1]	= 0.4;
	times[2]	= 0.5;
	times[3]	= 0.8;
};

datablock ParticleEmitterData(StormBlasterBlueTrailEmitter)
{
	ejectionPeriodMS = 1;
	periodVarianceMS = 0;

	ejectionVelocity = 0; //0.25;
	velocityVariance = 0; //0.10;

	ejectionOffset = 0;

	thetaMin			= 0.0;
	thetaMax			= 90.0;  

	particles = StormBlasterBlueTrailParticle;

	useEmitterColors = true;
	uiName = "Storm Blaster Trail - Blue";
};

datablock ProjectileData(StormBlasterBlueProjectile)
{
	projectileShapeName = "";
	directDamage		  = 15;
	directDamageType	 = $DamageType::StormBlaster;
	radiusDamageType	 = $DamageType::StormBlaster;
	impactImpulse		 	= 800;
	verticalImpulse	  	= 800;
	explosion			 	  = StormBlasterBlueExplosion;
	particleEmitter	 	  = StormBlasterBlueTrailEmitter;

	brickExplosionRadius = 2;
	brickExplosionImpact = false;			 //destroy a brick if we hit it directly?
	brickExplosionForce  = 10;
	brickExplosionMaxVolume = 10;			 //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground  

	muzzleVelocity		= 120;
	velInheritFactor	 = 1;

	armingDelay			= 0;
	lifetime				= 4000;
	fadeDelay			  = 6000;
	bounceElasticity	 = 0.5;
	bounceFriction		= 0.20;
	isBallistic			= true;
	gravityMod = 0;
	ProjectileScale = "1 1 1";

	hasLight	 = true;
	lightRadius = 20;
	lightColor  = "0.157 0.44 1 1";
	
	uiName = "Storm Blaster - Blue";
};

//////////
// item //
//////////

datablock ItemData(StormBlasterBlueItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./StormBlaster.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Storm Blaster - Blue";
	iconName = "./icon_StormBlaster";

	doColorShift = true;

	colorShiftColor = "0.157 0.44 1 1";

	 // Dynamic properties defined by the scripts
	image = StormBlasterBlueImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBlasterBlueImage)
{
	// Basic Item properties
	shapeFile = "./StormBlaster.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	// When firing from a point offset from the eye, muzzle correction
	// will adjust the muzzle vector to point to the eye LOS point.
	// Since this weapon doesn't actually fire from the muzzle point,
	// we need to turn this off.  
	correctMuzzleVector = true;

	// Add the WeaponImage namespace as a parent, WeaponImage namespace
	// provides some hooks into the inventory system.
	className = "WeaponImage";

	// Projectile && Ammo.
	item = StormBlasterBlueItem;
	ammo = " ";
	projectile = StormBlasterBlueProjectile;
	projectileType = Projectile;

	//casing = StormBlasterBlueShellDebris;
	//shellExitDir		  = "1.0 -1.3 1.0";
	//shellExitOffset	  = "0 0 0";
	//shellExitVariance	= 15.0;	
	//shellVelocity		 = 7.0;

	//melee particles shoot from eye node for consistancy
	melee = false;
	//raise your arm up or not
	armReady = true;
	minShotTime = 200;
	doColorShift = true;
	colorShiftColor = StormBlasterBlueItem.colorShiftColor;

	//casing = "";

	// Images have a state system which controls how the animations
	// are run, which sounds are played, script callbacks, etc. This
	// state system is downloaded to the client so that clients can
	// predict state changes and animate accordingly.  The following
	// system supports basic ready->fire->reload transitions as
	// well as a no-ammo->dryfire idle state.

	// Initial start up state
	stateName[0]					 = "Activate";
	stateTimeoutValue[0]			 = 0.5;
	stateTransitionOnTimeout[0]		 = "Ready";
	stateSound[0] 					 = StormEquipSound;

	stateName[1]					 = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]		 = true;
	stateSequence[1]				 = "Ready";

	stateName[2]					 = "Fire";
	stateTransitionOnTimeout[2]	     = "Smoke";
	stateTimeoutValue[2]			 = 0.14;
	stateFire[2]					 = true;
	stateAllowImageChange[2]		 = false;
	stateSequence[2]				 = "Fire";
	stateScript[2]					 = "onFire";
	stateWaitForTimeout[2]			 = true;
	stateEmitterTime[2]				 = 0.05;
	stateEmitterNode[2]				 = "muzzleNode";
	stateSound[2]					 = StormBlasterShotSound;
	stateEjectShell[2]			 	 = false;

	stateName[3] = "Smoke";
	stateEmitterTime[3]				 = 0.2;
	stateEmitterNode[3]				 = "muzzleNode";
	stateTimeoutValue[3]			 = 0.2;
	stateTransitionOnTimeout[3]	     = "Ready";

	stateName[4]					 = "Reload";
	stateSequence[4]				 = "Reload";
	stateTransitionOnTriggerUp[4]	 = "Ready";
	stateSequence[4]				 = "Ready";
};



/////////
// Red //
/////////


datablock ParticleData(StormBlasterRedExplosionParticle : StormBlasterBlueExplosionParticle)
{
	colors[0]	  = "1 0.25 0.25 0.9";
	colors[1]	  = "1 0.0 0.0 0.8";
	colors[2]	  = "1 0 0 0.6";
	colors[3]	  = "1 0 0 0.4";
};

datablock ParticleEmitterData(StormBlasterRedExplosionEmitter : StormBlasterBlueExplosionEmitter)
{
	particles = "StormBlasterRedExplosionParticle";
	uiName = "Storm Blaster Explosion - Red";
};

datablock ExplosionData(StormBlasterRedExplosion : StormBlasterBlueExplosion)
{
	particleEmitter = StormBlasterRedExplosionEmitter;
	emitter[0] = StormBlasterRedExplosionEmitter;

	lightStartColor = "1 0 0 1";
	lightEndColor = "1 0 0 0";
};

datablock ParticleData(StormBlasterRedTrailParticle : StormBlasterBlueTrailParticle)
{
	colors[0]	  = "1 0.25 0.25 1";
	colors[1]	  = "1 0.1 0.1 1";
	colors[2]	  = "1 0 0 1";
	colors[3]	  = "0.3 0.1 0.1 1";
};

datablock ParticleEmitterData(StormBlasterRedTrailEmitter : StormBlasterBlueTrailEmitter)
{
	particles = StormBlasterRedTrailParticle;
	useEmitterColors = true;
	uiName = "Storm Blaster Trail - Red";
};

datablock ProjectileData(StormBlasterRedProjectile : StormBlasterBlueProjectile)
{
	projectileShapeName = "";
	explosion			 	  = StormBlasterRedExplosion;
	particleEmitter	 	  = StormBlasterRedTrailEmitter;

	hasLight	 = true;
	lightColor  = "1 0 0 1";

	uiName = "Storm Blaster - Red";
};

//////////
// item //
//////////

datablock ItemData(StormBlasterRedItem : StormBlasterBlueItem)
{
	uiName = "Storm Blaster - Red";
	iconName = "./icon_StormBlaster";

	doColorShift = true;

	colorShiftColor = "1 0 0 1";
	image = StormBlasterRedImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBlasterRedImage : StormBlasterBlueImage)
{
	item = StormBlasterRedItem;
	projectile = StormBlasterRedProjectile;

	doColorShift = true;
	colorShiftColor = StormBlasterRedItem.colorShiftColor;
};



////////////
// Yellow //
////////////


datablock ParticleData(StormBlasterYellowExplosionParticle : StormBlasterBlueExplosionParticle)
{
	colors[0]	  = "1 0.733333 0.25 0.9";
	colors[1]	  = "1 0.733333 0.1 0.8";
	colors[2]	  = "1 0.733333 0 0.6";
	colors[3]	  = "1 0.733333 0 0.4";
};

datablock ParticleEmitterData(StormBlasterYellowExplosionEmitter : StormBlasterBlueExplosionEmitter)
{
	particles = "StormBlasterYellowExplosionParticle";
	uiName = "Storm Blaster Explosion - Yellow";
};

datablock ExplosionData(StormBlasterYellowExplosion : StormBlasterBlueExplosion)
{
	particleEmitter = StormBlasterYellowExplosionEmitter;
	emitter[0] = StormBlasterYellowExplosionEmitter;

	lightStartColor = "1 0.733333 0 1";
	lightEndColor = "1 0.733333 0 0";
};

datablock ParticleData(StormBlasterYellowTrailParticle : StormBlasterBlueTrailParticle)
{
	colors[0]	  = "1 0.733333 0.25 1";
	colors[1]	  = "1 0.733333 0.1 1";
	colors[2]	  = "1 0.733333 0 1";
	colors[3]	  = "1 0.733333 0 1";
};

datablock ParticleEmitterData(StormBlasterYellowTrailEmitter : StormBlasterBlueTrailEmitter)
{
	particles = StormBlasterYellowTrailParticle;
	useEmitterColors = true;
	uiName = "Storm Blaster Trail - Yellow";
};

datablock ProjectileData(StormBlasterYellowProjectile : StormBlasterBlueProjectile)
{
	projectileShapeName = "";
	explosion			 	  = StormBlasterYellowExplosion;
	particleEmitter	 	  = StormBlasterYellowTrailEmitter;

	hasLight	 = true;
	lightColor  = "1 0.733333 0 1";

	uiName = "Storm Blaster - Yellow";
};

//////////
// item //
//////////

datablock ItemData(StormBlasterYellowItem : StormBlasterBlueItem)
{
	uiName = "Storm Blaster - Yellow";
	iconName = "./icon_StormBlaster";

	doColorShift = true;

	colorShiftColor = "1 0.733333 0 1";
	image = StormBlasterYellowImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBlasterYellowImage : StormBlasterBlueImage)
{
	item = StormBlasterYellowItem;
	projectile = StormBlasterYellowProjectile;

	doColorShift = true;
	colorShiftColor = StormBlasterYellowItem.colorShiftColor;
};



///////////
// Green //
///////////


datablock ParticleData(StormBlasterGreenExplosionParticle : StormBlasterBlueExplosionParticle)
{
	colors[0]	  = "0.25 1 0.129412 0.9";
	colors[1]	  = "0.1 1 0.129412 0.8";
	colors[2]	  = "0 1 0.129412 0.6";
	colors[3]	  = "0 1 0.129412 0.4";
};

datablock ParticleEmitterData(StormBlasterGreenExplosionEmitter : StormBlasterBlueExplosionEmitter)
{
	particles = "StormBlasterGreenExplosionParticle";
	uiName = "Storm Blaster Explosion - Green";
};

datablock ExplosionData(StormBlasterGreenExplosion : StormBlasterBlueExplosion)
{
	particleEmitter = StormBlasterGreenExplosionEmitter;
	emitter[0] = StormBlasterGreenExplosionEmitter;

	lightStartColor = "0 1 0.129412 1";
	lightEndColor = "0 1 0.129412 0";
};

datablock ParticleData(StormBlasterGreenTrailParticle : StormBlasterBlueTrailParticle)
{
	colors[0]	  = "0.25 1 0.129412 1";
	colors[1]	  = "0.1 1 0.129412 1";
	colors[2]	  = "0 1 0.129412 1";
	colors[3]	  = "0 1 0.129412 1";
};

datablock ParticleEmitterData(StormBlasterGreenTrailEmitter : StormBlasterBlueTrailEmitter)
{
	particles = StormBlasterGreenTrailParticle;
	useEmitterColors = true;
	uiName = "Storm Blaster Trail - Green";
};

datablock ProjectileData(StormBlasterGreenProjectile : StormBlasterBlueProjectile)
{
	projectileShapeName = "";
	explosion			 	  = StormBlasterGreenExplosion;
	particleEmitter	 	  = StormBlasterGreenTrailEmitter;

	hasLight	 = true;
	lightColor  = "0 1 0.129412 1";
	uiName = "Storm Blaster - Green";
};

//////////
// item //
//////////
datablock ItemData(StormBlasterGreenItem : StormBlasterBlueItem)
{
	uiName = "Storm Blaster - Green";
	iconName = "./icon_StormBlaster";

	doColorShift = true;

	colorShiftColor = "0 1 0.129412 1";
	image = StormBlasterGreenImage;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(StormBlasterGreenImage : StormBlasterBlueImage)
{
	item = StormBlasterGreenItem;
	projectile = StormBlasterGreenProjectile;

	doColorShift = true;
	colorShiftColor = StormBlasterGreenItem.colorShiftColor;
};