function saveEnvironment_Init()//Modifies the load and save bricks guis to make room for and add checkboxes for loading environment
{
	if($saveEnvironment_Init)
		return;
		
	$saveEnvironment_Init = 1;
	
	//Modify Load Bricks gui
	if(!isObject(LoadBricks_Environment))
	{
		//Get all the objects we need to modify
		%loadButton = LoadBricks_LoadButton;
		%description = LoadBricks_Description;
		//Some objects we need to move don't have a name, so we have to find them
		%count = LoadBricks_Window.getCount();
		for(%i=0;%i<%count;%i++)
		{
			%obj = LoadBricks_Window.getObject(%i);
			if(%obj.text $= "Cancel") //Cancel Button
				%cancelButton = %obj;
			if(%obj.getClassName() $= "GuiSwatchCtrl" && %obj.color $= "255 255 255 192") //Description Swatch
				%descriptionSwatch = %obj;
		}
		
		//Modify some elements
		%loadButton.shift("0 10");
		%cancelButton.shift("0 10");
		%descriptionSwatch.shift("0 15");
		%description.shift("0 15");
		
		//Create a new checkbox
		new GuiCheckBoxCtrl(LoadBricks_Environment)
		{
			profile = "GuiCheckBoxProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "429 276";
			extent = "150 30";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			text = "Load Environment Settings";
			groupNum = "-1";
			buttonType = "ToggleButton";
		};
		LoadBricks_Window.add(LoadBricks_Environment);
	}

	//Modify Save Bricks gui
	if(!isObject(SaveBricks_Environment))
	{
		//Get all the objects we need to modify
		%description = SaveBricks_Description;
		//Some objects we need to move don't have a name, so we have to find them
		%count = SaveBricks_Window.getCount();
		for(%i=0;%i<%count;%i++)
		{
			%obj = SaveBricks_Window.getObject(%i);
			if(%obj.text $= "Cancel") //Cancel Button
				%cancelButton = %obj;
			if(%obj.getClassName() $= "GuiSwatchCtrl" && %obj.color $= "255 255 255 192") //Description Swatch
				%descriptionSwatch = %obj;
			if(%obj.text $= "Save") //Save button
				%saveButton = %obj;
			if(%obj.text $= "Description : ") //Description Header
				%descriptionHeader = %obj;
			if(%obj.text $= "Clear") //Clear Button
				%clearButton = %obj;
		}
		
		//Modify some elements
		%saveButton.shift("0 7");
		%cancelButton.shift("0 7");
		%descriptionSwatch.shift("0 15");
		%descriptionHeader.shift("0 15");
		%clearButton.shift("0 15");
		
		//Create a new checkbox
		new GuiCheckBoxCtrl(SaveBricks_Environment)
		{
			profile = "GuiCheckBoxProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "14 298";
			extent = "140 30";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			text = "Save Environment";
			groupNum = "-1";
			buttonType = "ToggleButton";
		};
		SaveBricks_Window.add(SaveBricks_Environment);
	}
}

//Support for Siba's Save Delete Extension
package Env_LoadSaveGuiMod
{
	function LoadBricks_Window::onWake(%this)
	{
		Parent::onWake(%this);
		if($Env_LoadSave_SibaButtonsMoved || !isFile("Add-Ons/Client_SaveDelete/client.cs"))
			return;
		
		$Env_LoadSave_SibaButtonsMoved = 1;
		LoadBricks_CancelButton.shift("0 10");
		LoadBricks_DeleteButton.shift("0 10");
		LoadBricks_LoadButton.shift("0 10");
	}
	
	function SaveBricks_Window::onWake(%this)
	{
		Parent::onWake(%this);
		if($Env_LoadSave_SibaSaveButtonsMoved || !isFile("Add-Ons/Client_SaveDelete/client.cs"))
			return;
		
		$Env_LoadSave_SibaSaveButtonsMoved = 1;
		SaveBricks_DeleteButton.shift("0 7");
	}
};
ActivatePackage(Env_LoadSaveGuiMod);

saveEnvironment_Init();