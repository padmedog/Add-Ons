

datablock ParticleData(ImpactGrenadeTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 300;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "0.1 0.1 0.1 0";
	colors[1]	= "0.1 0.1 0.1 0.20";
	colors[2]	= "0.1 0.1 0.1 0";
	sizes[0]	= 0.6;
	sizes[1]	= 0.4;
	sizes[2]	= 0.1;
	times[0]	= 0.0;
	times[1]	= 0.1;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(ImpactGrenadeTrailEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 2;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = ImpactGrenadeTrailParticle;
};

datablock ParticleData(ImpactGrenadeExplosionParticle)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 1500;
	lifetimeVarianceMS	= 500;
	spinSpeed		= 5.0;
	spinRandomMin		= -5.0;
	spinRandomMax		= 5.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
   colors[0]     = "0.9 0.5 0.0 0.7";
   colors[1]     = "0.4 0.4 0.4 0.3";
   colors[2]     = "0.9 0.9 0.9 0.1";

	sizes[0]	= 10.0;
	sizes[1]	= 7.0;
   sizes[2]	= 5.5;

	times[0]	= 0.0;
	times[1]	= 0.28;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(ImpactGrenadeExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0; //90
   thetaMax         = 180; //360
   phiReferenceVel  = 0;
   phiVariance      = 360; //180
   overrideAdvance = false;
   particles = "ImpactGrenadeExplosionParticle";
};


datablock ParticleData(ImpactGrenadeExplosionRingParticle)
{
   dragCoefficient      = 8;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 10;
   textureName          = "base/data/particles/star1";
   spinSpeed        = 10.0;
   spinRandomMin        = -500.0;
   spinRandomMax        = 500.0;
   colors[0]     = "1.0 1.0 0.6 1";
   colors[1]     = "1.0 1.0 0.6 1";
   sizes[0]      = 13;
   sizes[1]      = 7;

   useInvAlpha = false;
};

datablock ParticleEmitterData(ImpactGrenadeExplosionRingEmitter)
{
   lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ImpactGrenadeExplosionRingParticle";
};

datablock ParticleData(ImpactGrenadeExplosionRing2Particle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1350;
	lifetimeVarianceMS   = 135;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 25.0;
	spinRandomMin		= -25.0;
	spinRandomMax		= 25.0;
   colors[0]     = "0.1 0.05 0.025 0.3";
   colors[1]     = "0.1 0.05 0.025 0.0";
	sizes[0]      = 8;
	sizes[1]      = 6;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ImpactGrenadeExplosionRing2Emitter)
{
	lifeTimeMS = 90;

   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 22;
   velocityVariance = 1.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ImpactGrenadeExplosionRing2Particle";
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ExplosionData(ImpactGrenadeExplosion)
{
   explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
   lifeTimeMS = 150;

   soundProfile = ImpactGrenadeExplosionSound;
   
   emitter[0] = ImpactGrenadeExplosionRingEmitter;
   emitter[1] = ImpactGrenadeExplosionEmitter;
   emitter[2] = ImpactGrenadeExplosionRing2Emitter;
   //emitter[1] = "";
   //emitter[2] = "";
   //emitter[0] = "";


   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 3;
   impulseForce = 100;

   damageRadius = 4;
   radiusDamage = 100;

	uiName = "Impact Grenade Explosion";
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

AddDamageType("ImpactGrenadeDirect",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactGrenade> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactGrenade> %1',1,1);
AddDamageType("ImpactGrenadeRadius",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactGrenadeRadius> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_ImpactGrenadeRadius> %1',1,0);
datablock ProjectileData(ImpactGrenadeProjectile)
{
   projectileShapeName = "./ImpactGrenadeThrown.dts";
   directDamage        = 25;
   directDamageType = $DamageType::ImpactGrenadeDirect;
   radiusDamageType = $DamageType::ImpactGrenadeRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = ImpactGrenadeExplosion;
   particleEmitter     = ImpactGrenadeTrailEmitter;

   brickExplosionRadius = 2;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10; //30             
   brickExplosionMaxVolume = 5;  //30         //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 20;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 38; //50
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 8000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod          = 1.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "1 0 0.0";

   uiName = "Impact Grenade";
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////
// item //
//////////
datablock ItemData(ImpactGrenadeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./ImpactGrenadeHand.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Impact Grenade";
	iconName = "./icon_ImpactGrenade";
	l4ditemtype = "grenade";

	 // Dynamic properties defined by the scripts
	image = ImpactGrenadeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(ImpactGrenadeImage)
{
   // Basic Item properties
   shapeFile = "./ImpactGrenadeHand.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ImpactGrenadeItem;
   ammo = " ";
   projectile = ImpactGrenadeProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = false;
   colorShiftColor = "0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state

	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]	= true;

	stateName[2]			= "SKIPPEDPindrop";
	stateTransitionOnTimeout[2]	= "SKIPPEDPinfallen";
	stateAllowImageChange[2]	= false;
	stateTimeoutValue[2]		= 0.2;
	stateEjectShell[2]       = true;

	stateName[3]			= "SKIPPEDPinfallen";
	stateTransitionOnTriggerDown[3]	= "Charge";
	stateAllowImageChange[3]	= false;
	
	stateName[4]                    = "Charge";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.1;
	stateWaitForTimeout[4]		= false;
	stateTransitionOnTriggerUp[4]	= "AbortCharge";
	stateScript[4]                  = "onCharge";
	stateAllowImageChange[4]        = false;
	
	stateName[5]			= "AbortCharge";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.1;
	stateWaitForTimeout[5]		= true;
	stateScript[5]			= "onAbortCharge";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Armed";
	stateScript[6]			= "onArmed";
	stateTransitionOnTriggerUp[6]	= "Fire";
	stateAllowImageChange[6]	= false;

	stateName[7]			= "Fire";
	stateTransitionOnTimeout[7]	= "Done";
	stateTimeoutValue[7]		= 0.5;
	stateFire[7]			= true;
	stateSound[7]				= tierfraggrenadetossSound;
	stateSequence[7]		= "fire";
	stateScript[7]			= "onFire";
	stateWaitForTimeout[7]		= true;
	stateAllowImageChange[7]	= false;

	stateName[8]					= "Done";
	stateScript[8]					= "onDone";
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


package ImpactGrenadePackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "ImpactGrenadeItem" && %col.canPickup)
		{
			for(%i=0;%i<%this.maxTools;%i++)
			{
				%item = %obj.tool[%i];
				if(%item $= 0 || %item $= "")
				{
					%freeSlot = 1;
					break;
				}
			}

			if(%freeSlot)
			{
				%obj.pickup(%col);
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(ImpactGrenadePackage);

function ImpactGrenadeImage::onArmed(%this, %obj, %slot)
{
	%obj.playthread(1, spearready);
	%obj.playthread(2, spearready);
	%obj.playthread(3, activate);
	%obj.lasttierfragslot = %obj.currTool;
}

function ImpactGrenadeImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function ImpactGrenadeImage::onFire(%this, %obj, %slot)
{
	Parent::OnFire(%this, %obj, %slot);

	%currSlot = %obj.lasttierfragslot;
	%obj.tool[%currSlot] = 0;
	%obj.weaponCount--;
	messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
	serverCmdUnUseTool(%obj.client);
	%obj.playThread(1, activate);
	%obj.playThread(2, spearthrow);


}

function ImpactGrenadeImage::onCharge(%this, %obj, %slot)
{
		%obj.playThread(2, jump);
}

//function ImpactGrenadeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
//{
//	serverPlay3D(ImpactGrenadeBounceSound,%obj.getTransform());
//}

function ImpactGrenadeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
