%errorA = ForceRequiredAddOn("Weapon_Package_Tier1");
%errorB = ForceRequiredAddOn("Weapon_Skins_Pistol");

if(%errorA == $Error::AddOn_NotFound)
   error("Dualies skins didn't exec, because Tier 1 wasn't found.");
else if(%errorB == $Error::AddOn_NotFound)
   error("Dualies skin didn't exec, because Skins_Pistol wasn't found.");
else
{
   exec("./Weapon_Classic_Pistol.cs"); 
   exec("./Weapon_Modern_Pistol.cs");  
   //exec("./Weapon_Covert_Pistol.cs"); 
   exec("./Weapon_Silenced_Pistol.cs"); 
}
