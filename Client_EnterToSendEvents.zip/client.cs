WrenchEvents_Window.getobject(1).accelerator = "enter";

Wrench_Name.altCommand = "wrenchDlg.send();";
Wrench_ItemRespawnTime.altCommand = "wrenchDlg.send();";
Wrench_Window.getobject(4).accelerator = "enter";

wrenchBot_Name.altCommand = "wrenchBotDlg.send();";
wrenchBot_ItemRespawnTime.altCommand = "wrenchBotDlg.send();";

WrenchSound_Name.altCommand = "wrenchSoundDlg.send();";
WrenchSound_Window.getobject(1).accelerator = "enter";

WrenchVehicleSpawn_Name.altCommand = "wrenchVehicleSpawnDlg.send();";
WrenchVehicleSpawn_Window.getobject(1).accelerator = "enter";