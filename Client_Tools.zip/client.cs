exec("./Toolgui.gui");
if (!$ToolguiBinds)
{
	$remapDivision[$remapCount] = "Tool Gui";
	$remapName[$remapCount] = "Open Tool gui";
	$remapCmd[$remapCount] = "Toolgui_Open";
	$remapCount++;
	$ToolguiBinds = 1;
}

function Toolgui_Open()
{
	canvas.pushDialog(Toolgui);

}
