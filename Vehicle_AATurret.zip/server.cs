%errorB = ForceRequiredAddOn("Weapon_Gun");


if(%errorB == $Error::AddOn_Disabled)
   gunItem.uiName = "";


if(%errorB == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_GunAPC - required add-on Weapon_Gun not found");
else
   exec("./support_shootonclick.cs"); 
   exec("./Vehicle_AATurret.cs"); 