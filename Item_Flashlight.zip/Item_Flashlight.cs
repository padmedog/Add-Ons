datablock ParticleData(FlashlightParticleB)
{
   dragCoefficient      = 0;
   gravityCoefficient   = -0.0;
   inheritedVelFactor   = 1.0;
   constantAcceleration = 0;
   lifetimeMS           = 30;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/dot";
   spinSpeed           = 0.0;
   spinRandomMin        = 0.0;
   spinRandomMax        = 0.0;
   colors[0]     = "1 1 1 0.1";
   colors[1]     = "1 1 1 0.1";
   colors[2]     = "1 1 1 0.1";

   sizes[0]      = 0.1;
   sizes[1]      = 0.4;
   sizes[2]      = 0.6;

   times[0] = 0.0;
   times[1] = 0.3;
   times[2] = 1.0;

   useInvAlpha = false;
};

datablock ParticleEmitterData(FlashlightEmitterB)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 50;
   velocityVariance = 0.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "FlashlightParticleB";

   useEmitterColors = false;

   uiName = "Flashlight Trace";
};

datablock ProjectileData(FlashlightProjectileA)
{
   projectileShapeName = "base/data/shapes/empty.dts";

   particleEmitter = FlashlightEmitterA;
   
   soundProfile = NONE;

   brickExplosionRadius = 0;
   brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   collideWithPlayers = true;

   muzzleVelocity      = 10;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 2000;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0.00;
   isBallistic         = true;
   gravityMod          = 0.0;

   hasLight    = true;
   lightRadius = 30;
   lightColor = "0.9 0.9 0.9";
   
   uiName = "Flashlight FX";
};

//////////
// item //
//////////
datablock ItemData(FlashlightItem)
{
	category = "Item";  // Mission editor category
	className = "Item"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Flashlight.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Flashlight";
	iconName = "./FlashlightUI.png";
	doColorShift = true;
	colorShiftColor = "0.2 0.2 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = FlashlightImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(FlashlightImage)
{
   // Basic Item properties
   shapeFile = "./Flashlight.dts";
   emap = true;

   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0;
   rotation = "1 0 0 0";
   correctMuzzleVector = true;
   className = "WeaponImage";

   // Projectile && Ammo.
   item = FlashlightItem;
   ammo = " ";
   projectile = FlashlightProjectileA;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   //raise your arm up or not
   armReady = true;

   doRetraction = false;
   
   raycastWeaponRange = 7000;
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = FlashlightProjectileA;
   raycastExplosionBrickSound = "";
   raycastExplosionPlayerSound = "";

   doColorShift = true;
   colorShiftColor = FlashlightItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTransitionOnTriggerDown[0]  = "Fire";
	stateAllowImageChange[0]	   = true;
	stateSound[0]			   = NONE;
	stateTransitionOnTimeout[0]	   = "Ready";
	stateTimeoutValue[0]		   = 0.3;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]	   = true;
	
	//stateName[2]			= "PreFire";
	//stateSound[2]			= "";
	//stateTimeoutValue[2]		= 0.01;
	//stateTransitionOnTimeout[2]	= "Fire";

	stateName[2]                     = "Fire";
	stateTransitionOnTriggerUp[2]	   = "StopFire";
	stateTransitionOnTimeout[2]	   = "Fire";
	stateTimeoutValue[2]		   = 0.01;
	stateWaitForTimeout[2]		   = true;
	stateFire[2]			   = true;
	stateAllowImageChange[2]	   = true;
	stateSound[2]			   = NONE;
	stateScript[2]			   = "onFire";
	stateEmitter[2]			   = FlashlightEmitterB;
	stateEmitterTime[2]		   = 0.07;
	stateSequence[2]			   = "fire";

	stateName[3] 			   = "StopFire";
	stateTransitionOnTimeout[3]	   = "Ready";
	stateWaitForTimeout[3]		   = true;
	stateAllowImageChange[3]	   = true;
	stateSequence[3]			   = "stopfire";
};

function FlashlightImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   if(isObject(%this.raycastExplosionProjectile))
   {
      %scaleFactor = getWord(%obj.getScale(), 2);
      %p = new Projectile()
      {
         dataBlock = %this.raycastExplosionProjectile;
         initialPosition = vectorAdd(%pos,vectorScale(%normal,1));
         initialVelocity = "0 0 0";
         sourceObject = %obj;
         client = %obj.client;
         sourceSlot = 0;
         originPoint = %pos;
      };
      MissionCleanup.add(%p);
      %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
      //%p.explode();
   }
}
