// Init RTB (Required mod)
$Pref::Rendermen::Faces = 0;

RTB_registerPref("Enabled", "Rendermen", "Pref::Rendermen::Enabled", "bool", "Support_Rendermenv3Prototype", 1, 0, 0); // implamented
RTB_registerPref("Kick Players?", "Rendermen", "Pref::Rendermen::Kick", "bool", "Support_Rendermenv3Prototype", 1, 0, 0); // implamented
RTB_registerPref("Renderman Lights?", "Rendermen", "Pref::Rendermen::OwnLights", "bool", "Support_Rendermenv3Prototype", 1, 0, 0); // implamented
RTB_registerPref("Renderman Agro", "Rendermen", "Pref::Rendermen::Speed","list Paranormal 250 Evil 150 Demonic 100 Insane 75 Nightmare 25","Support_Rendermenv3Prototype", 150, 0, 0); // implamented
RTB_registerPref("Renderman Spawnrate", "Rendermen", "Pref::Rendermen::Spawnrate","list Unsafe 30 Dangerous 23 Frightening 19 Insane 13 Nightmare 7","Support_Rendermenv3Prototype", 19, 0, 0); // implamented 
RTB_registerPref("Allow Hordes", "Rendermen", "Pref::Rendermen::Lights", "bool", "Support_Rendermenv3Prototype", 0, 0, 0); // buggy but implamented
// RTB_registerPref("Use Special Faces?", "Rendermen", "Pref::Rendermen::Faces", "bool", "Support_Rendermen", 1, 0, 0); // NOT implamented properly

// define main vars
$rendermeninmap = 0;

// load code
exec("./Functions.cs");
exec("./Datablocks.cs");
exec("./AI.cs");

// annoying preload announcement
package RMOD_Preview_Inform
{
	function GameConnection::onClientEnterGame(%client)
	{
	messageClient(%client,'',"This server is running the Renderman Mod v3 preview 4. Please inform Chrisbot6 of bugs in the Modification Discussion topic!");
	Parent::onClientEnterGame(%client);
	}
};
activatepackage(RMOD_Preview_Inform);