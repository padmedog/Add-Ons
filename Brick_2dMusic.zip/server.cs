datablock AudioDescription(AudioMusicLooping2d : AudioMusicLooping3d)
{
	maxDistance = 999999;
	referenceDistance = 2;
	is3D = 0;
};

datablock fxDtsBrickData(brickHalfMusicData : brickMusicData)
{
	uiName = "Music (Server-Wide)";
	musicRange = 999999;
	musicDescription = AudioMusicLooping2d;
};
exec("Add-ons/Brick_2dMusic/Support_CustomRangeMusic.cs");