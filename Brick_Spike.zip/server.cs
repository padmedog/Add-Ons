datablock fxDTSBrickData (brick1x1x5spikedata)
{
	brickFile = "./1x1x5spike.blb";
	collisionShapeName = "./spike.dts";
	category = "Rounds";
	subCategory = "Spike";
	uiName = "Spike";
	iconName = "Add-Ons/Brick_Spike/spike";
};
datablock fxDTSBrickData (brick1x1x5spikerdata)
{
	brickFile = "./1x1x5spiker.blb";
	collisionShapeName = "./spike.dts";
	category = "Rounds";
	subCategory = "Spike";
	uiName = "Ceiling Spike";
	iconName = "Add-Ons/Brick_Spike/spiker";
};