exec("./chaseCam.gui");
if (!$chaseCamBinds)
{
	$remapDivision[$remapCount] = "Chase Cam";
	$remapName[$remapCount] = "Toggle GUI";
	$remapCmd[$remapCount] = "chaseCam_Open";
	$remapCount++;
	$chaseCamBinds = 1;
}

function chaseCam_Open(%x)
{
	if(%x)
	{	if(!chaseCam.isAwake())
		{
			canvas.pushDialog(chaseCam);
		}
		else
		{
			canvas.popDialog(chaseCam);
		}
	}

}

function getAbsoluteValue($ChaseCam::delay) {
      if($ChaseCam::delay < 0 ){
            $ChaseCam::delay = -1 * $ChaseCam::delay;
      }
      if($ChaseCam::delay > 1800000){
            $ChaseCam::delay = 1800000;
      }
return $ChaseCam::delay;
}