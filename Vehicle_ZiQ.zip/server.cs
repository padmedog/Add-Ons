//we need the jeep add-on for this, so force it to load
%error = ForceRequiredAddOn("Vehicle_Jeep");

if(%error == $Error::AddOn_Disabled)
{
   //A bit of a hack:
   //  we just forced the jeep to load, but the user had it disabled
   //  so lets make it so they can't select it
   JeepVehicle.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   //we don't have the jeep, so we're screwed
   error("ERROR: Vehicle_ZiQ - required add-on Vehicle_Jeep not found");
}
else
{
	exec("./Vehicle_ZiQ.cs");
	exec("./ZiQ_Tire.cs");
	exec("./ZiQ_Explosion.cs");
	exec("./ZiQ_FinalExplosion.cs");
	exec("./ZiQ_Spring.cs");   
}