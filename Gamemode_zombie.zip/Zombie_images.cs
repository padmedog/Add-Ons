datablock ShapeBaseImageData(ZombieJumpImage)
{
    shapeFile = "base/data/shapes/empty.dts";
	emap = false;
	mountPoint = 2;
};
datablock ShapeBaseImageData(ZombieCrouchImage)
{
    shapeFile = "base/data/shapes/empty.dts";
	emap = false;
	mountPoint = 3;
};
datablock ShapeBaseImageData(SaveMeRedImage)
{
    shapeFile = "./Exclamation.dts";
	emap = false;

	mountPoint = 8;
    doColorShift = true;
    //colorShiftColor = "0.100 0.500 0.250 0.8";
	colorShiftColor = "1 0 0 1";
	offset = "0 -0.45 2.5";
   //rotation = "1 0 0 -90";
};
datablock ShapeBaseImageData(SaveMeMiddleImage)
{
    shapeFile = "./Exclamation.dts";
	emap = false;

	mountPoint = 8;
    doColorShift = true;
    //colorShiftColor = "0.100 0.500 0.250 0.8";
	colorShiftColor = "1 1 0 1";
	offset = "0 -0.45 2.5";
   //rotation = "1 0 0 -90";
};
datablock ShapeBaseImageData(SaveMeGreenImage)
{
    shapeFile = "./Exclamation.dts";
	emap = false;

	mountPoint = 8;
    doColorShift = true;
    colorShiftColor = "0.100 0.500 0.250 1";
	//colorShiftColor = "1 0 0 1";
	offset = "0 -0.45 2.5";
   //rotation = "1 0 0 -90";
};
datablock ShapeBaseImageData(DeathXImage)
{
    shapeFile = "./DeathX.dts";
	emap = false;

	mountPoint = 8;
    doColorShift = true;
    //colorShiftColor = "0.100 0.500 0.250 0.8";
	colorShiftColor = "1 0 0 1";
	offset = "0 -0.5 2.5";
   //rotation = "1 0 0 -90";
};

datablock ShapeBaseImageData(SandwichImage)
{
    shapeFile = "./sandwich.dts";
	emap = false;

	mountPoint = 0;
    doColorShift = false;
    //colorShiftColor = "0.100 0.500 0.250 0.8";
	rotation = eulerToMatrix( "60 -90 0" );
	eyeoffset = "0.5 1 -0.2";
	eyerotation = eulerToMatrix( "60 -90 0" );
	offset = "0.05 0.14 0.07";
   //rotation = "1 0 0 -90";
};

