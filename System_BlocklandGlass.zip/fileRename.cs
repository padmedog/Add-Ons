if(isfile("Add-Ons/Support_Playtime.zip")) { fileCopy("Add-Ons/Support_Playtime.zip", "Add-Ons/Server_Playtime.zip"); filedelete("Add-Ons/Support_Playtime.zip"); }
