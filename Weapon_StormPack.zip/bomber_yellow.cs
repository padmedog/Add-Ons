datablock StaticShapeData(StormBomberYellowShape)
{
	shapeFile = "./BomberYellowBullet.dts";
};

datablock fxLightData(StormBomberYellowLight : StormBomberBlueLight)
{
	color  = "1 0.733333 0 1";
	uiName = "Storm Light - Yellow";
};

datablock ParticleData(StormBomberYellowExplosionParticle : StormBomberBlueExplosionParticle)
{
	colors[0]	  = "1 0.733333 0.25 0.9";
	colors[1]	  = "1 0.733333 0.1 0.8";
	colors[2]	  = "1 0.733333 0 0.6";
	colors[3]	  = "1 0.733333 0 0.4";
};

datablock ParticleEmitterData(StormBomberYellowExplosionEmitter : StormBomberBlueExplosionEmitter)
{
	particles = "StormBomberYellowExplosionParticle";
};

datablock ParticleData(StormBomberYellowExplosionRingParticle : StormBomberBlueExplosionRingParticle)
{
	colors[0]	  = "1 0.733333 0.25 0.9";
	colors[1]	  = "1 0.733333 0.1 0.8";
	colors[2]	  = "1 0.733333 0 0.6";
	colors[3]	  = "1 0.733333 0 0.4";
};

datablock ParticleEmitterData(StormBomberYellowExplosionRingEmitter : StormBomberBlueExplosionRingEmitter)
{
	particles = "StormBomberYellowExplosionRingParticle";
};

datablock ParticleData(StormBomberYellowExplosionChunkParticle : StormBomberBlueExplosionChunkParticle)
{
	colors[0]	  = "1 0.733333 0.25 0.9";
	colors[1]	  = "1 0.733333 0.1 0.8";
	colors[2]	  = "1 0.733333 0 0.6";
	colors[3]	  = "1 0.733333 0 0.4";
};

datablock ParticleEmitterData(StormBomberYellowExplosionChunkEmitter : StormBomberBlueExplosionChunkEmitter)
{
	particles = "StormBomberYellowExplosionChunkParticle";
};


datablock ParticleEmitterData(StormBomberYellowExplosionDotEmitter : StormBomberBlueExplosionDotEmitter)
{
		particles = "StormBomberYellowExplosionDotParticle";
};

datablock ParticleData(StormBomberYellowExplosionDotParticle : StormBomberBlueExplosionDotParticle)
{
	colors[0]	  = "1 0.733333 0.25 0.9";
	colors[1]	  = "1 0.733333 0.1 0.8";
	colors[2]	  = "1 0.733333 0 0.6";
	colors[3]	  = "1 0.733333 0 0.4";
};


datablock ExplosionData(StormBomberYellowExplosion : StormBomberBlueExplosion)
{
	particleEmitter = StormBomberYellowExplosionEmitter;

	emitter[0] = StormBomberYellowExplosionChunkEmitter;
	emitter[1] = StormBomberYellowExplosionRingEmitter;
	emitter[2] = StormBomberYellowExplosionDotEmitter;

	lightStartColor = "1 0.733333 0 1";
	lightEndColor = "1 0.733333 0 0";
};

datablock ProjectileData(StormBomberYellowStuckProjectile : StormBomberBlueStuckProjectile)
{
	explosion = StormBomberYellowExplosion;
};

datablock ProjectileData(StormBomberYellowProjectile : StormBomberBlueProjectile)
{
	projectileShapeName = "./BomberYellowBullet.dts";
	hasLight	 = true;
	lightColor  = "1 0.733333 0 1";
};

//////////
// item //
//////////

datablock ItemData(StormBomberYellowItem : StormBomberBlueItem)
{
	uiName = "Storm Bomber - Yellow";

	doColorShift = true;
	colorShiftColor = "1 0.733333 0 1";

	image = StormBomberYellowImage;
};

////////////////
//weapon image//
////////////////

datablock ShapeBaseImageData(StormBomberYellowImage : StormBomberBlueImage)
{
	shapeFile = "./StormBomber.dts";
	item = StormBomberYellowItem;
	projectile = StormBomberYellowProjectile;
	colorShiftColor = StormBomberYellowItem.colorShiftColor;
};

//----------------------------------------------------------------------------

function StormBomberYellowImage::onFire(%this, %obj, %slot)
{
	if (!isObject(%bomb = %obj.stormBomb))
	{
		if ($Sim::Time - %obj.lastBomberShotTime >= 2)
		{
			ServerPlay3d(StormBomberShotSound, %obj.getPosition());

			%p = new Projectile()
			{
				dataBlock       = StormBomberYellowProjectile;
				initialPosition = %obj.getMuzzlePoint(0);
				initialVelocity = vectorScale(%obj.getMuzzleVector(0), 30);
				sourceObject    = %obj;
				client          = %client;
				sourceSlot      = 0;
				originPoint     = %obj.getMuzzlePoint(0);
				type 			= "Yellow";
			};
			MissionCleanup.add(%p);
			%obj.stormBomb = %p;

			schedule(1900, 0, SpawnBomberExplosion, %p, "Yellow");
			%p.schedule(1900, delete);

			%obj.lastBomberShotTime = $Sim::Time;
		}
	}
	else
	{
		SpawnBomberExplosion(%bomb, "Yellow");
		%obj.stormBomb = "";
	}
}

function StormBomberYellowProjectile::onCollision(%this, %obj, %col, %fade, %pos, %normal)
{
	if (isObject(%source = %obj.sourceObject) && isObject(%source) && %source.getMountedImage(0) == StormBomberYellowImage.getId() &&
		%col.getClassName() !$= "Player" && %col.getClassName() !$= "AiPlayer" && 
		%col.getClassName() !$= "Vehicle" && %col.getClassName() !$= "WheeledVehicle")
	{
		%light = new fxLight()
		{
			dataBlock = StormBomberYellowLight;
			position = vectorAdd(%pos, "0 0 0.3");
		};
		MissionCleanup.add(%light);

		%p = new StaticShape()
		{
			dataBlock = StormBomberYellowShape;
			position = %pos;
			type = "Yellow";
			objectAttachedTo = %col;
			client = %source.client;
			light = %light;
		};
		MissionCleanup.add(%p);

		if (%col.stormBombCount $= "")
			%col.stormBombCount = 0;

		%col.attachedStormBomb[%col.stormBombCount] = %p;
		%col.stormBombCount++;

		if (isObject(%source))
			%source.stormBomb = %p;

		%obj.delete();
	}
	else
	{
		%p = new Projectile()
		{
			dataBlock = StormBomberYellowStuckProjectile;
			initialPosition = %pos;
			client = %source.client;
			sourceObject = %source.client;
		};
		MissionCleanup.add(%p);
		%p.explode();
	}
}

function StormBomberYellowImage::onUnmount(%this, %obj, %slot)
{
	if (isObject(%bomb = %obj.stormBomb))
	{
		SpawnBomberExplosion(%bomb, "Yellow");
		%obj.stormBomb = "";
	}
}