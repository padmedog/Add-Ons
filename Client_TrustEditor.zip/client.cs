if(!isObject(Swol_TrustEditorGui))
exec("./trustEdit.gui");
if(!isObject(Swol_RemapKeyGui))
exec("./keyBinding.gui");

package swol_TrustEdit
{
	function Swol_TE_KeyBind::onInputEvent(%this,%type,%key)
	{
		if(%key $= "escape")
		{
			canvas.popDialog(Swol_RemapKeyGui);
			return;
		}
		if(%type !$= "keyboard" || %key $= "w" || %key $= "a" || %key $= "s" || %key $= "d" || %key $= "f")
		return;
		
		if(getSubStr(%key,0,4) $= "ctrl" || getSubStr(%key,0,1) $= "f" || getSubStr(%key,0,5) $= "shift")
		%okay = 1;
		
		if(!%okay)
		return;
		%curBind = globalActionMap.getBinding("SwolTEbind");
		globalActionMap.unbind(getField(%curBind,0),getField(%curBind,1));
		GlobalActionMap.bind(%type,%key,SwolTEbind);
		messageBoxOK("Trust Editor Keybind", "Trust Editor Keybind has been set to \'" @ getMapDisplayName(%type,%key) @ "\'");
		Swol_TEsaveBind(%type,%key);
		GlobalActionMap.bind(%type,%key,SwolTEbind);
		canvas.popDialog(Swol_RemapKeyGui);
	}
	function Swol_TEsaveBind(%type,%key)
	{
		%f = new fileObject();
		%f.openForWrite("config/client/trustEditorBind.cs");
		%f.writeLine("GlobalActionMap.bind(" @ %type @ ",\"" @ %key @ "\",SwolTEbind);");
		%f.close();
		%f.delete();
	}
	function Swol_TEloadBind()
	{
		if(isFile("config/client/trustEditorBind.cs"))
		exec("config/client/trustEditorBind.cs");
	}
	function Swol_TEopenBind()
	{
		canvas.pushDialog(Swol_RemapKeyGui);
	}
	function Swol_TEbuildList()
	{
		Swol_TextEditor_UndoButton.setActive(0);
		Swol_TextEditor_UndoButton.setColor("0.5 1 0.5 0.5");
		Swol_TEreset();
		%f = new fileObject();
		%f.openForRead("config/client/prefs-trustList.txt");
		%text = 0;
		while(%text !$= "")
		{
			%text = %f.readLine();
			if(%text !$= "")
			Swol_TEaddElement(%text,0);
		}
		%f.close();
		%f.delete();
		Swol_TextEditor_List.sort(0,1);
	}
	function Swol_TEinjectPlayerList()
	{
		%gui = new GuiControl() {
		   profile = "GuiDefaultProfile";
		   horizSizing = "right";
		   vertSizing = "bottom";
		   position = "374 2";
		   extent = "84 25";
		   minExtent = "8 2";
		   enabled = "1";
		   visible = "1";
		   clipToParent = "1";
			new GuiBitmapButtonCtrl(Swol_TrustEditor_Injected) {
			   profile = "BlockButtonProfile";
			   horizSizing = "right";
			   vertSizing = "bottom";
			   position = "0 0";
			   extent = "83 20";
			   minExtent = "8 2";
			   enabled = "1";
			   visible = "1";
			   clipToParent = "1";
			   command = "Swol_TEopen();";
			   text = "Trust Editor";
			   groupNum = "-1";
			   buttonType = "PushButton";
			   bitmap = "base/client/ui/button1";
			   lockAspectRatio = "0";
			   alignLeft = "0";
			   alignTop = "0";
			   overflowImage = "0";
			   mKeepCached = "0";
			   mColor = "255 255 255 255";
			};
		};
		NPL_Window.add(%gui);
	}
	function Swol_TEopen()
	{
		canvas.pushDialog(Swol_TrustEditorGui);
		if(isObject(serverConnection))
		Swol_TextEditor_WarningText.setText("<color:ff0000>Warning: trust list will not update until you reconnect to the server");
		else
		Swol_TextEditor_WarningText.setText("");
	}
	function Swol_TEreset()
	{
		Swol_TextEditor_List.count = 0;
		Swol_TextEditor_List.clear();
	}
	function Swol_TErefresh()
	{
		cancel($Swol_TeSched);
		Swol_TextEditor_WarningText.setText("Refreshing...");
		$Swol_TeSched = schedule(500,0,Swol_TEclearWarning);
		Swol_TEbuildList();
	}
	function Swol_TEclearWarning()
	{
		cancel($Swol_TeSched);
		Swol_TextEditor_WarningText.setText("");
	}
	function Swol_TEnumToTrust(%num)
	{
		if(%num == 3)
		return "You";
		if(%num == 2)
		return "Full";
		if(%num == 1)
		return "Build";
		if(%num == 0)
		return "None";
		
		return -1;
	}
	function Swol_TEtrustToNum(%trust)
	{
		if(%trust $= "You")
		return 3;
		if(%trust $= "Full")
		return 2;
		if(%trust $= "Build")
		return 1;
		if(%trust $= "None")
		return 0;
		
		return -1;
	}
	function Swol_TEundoDelete()
	{
		if(Swol_TextEditor_WarningText.undid == 0)
		{
			cancel($Swol_TeSched);
			Swol_TextEditor_WarningText.setText("<color:009900>Undid Removal of " @ getField(Swol_TextEditor_List.undo,0) @ " from trust list");
			$Swol_TeSched = schedule(2500,0,Swol_TEclearWarning);
			Swol_TEaddElement(Swol_TextEditor_List.undo,1);
			Swol_TextEditor_UndoButton.setActive(0);
			Swol_TextEditor_UndoButton.setColor("0.5 1 0.5 0.5");
			Swol_TEwriteToTrustList();
			Swol_TextEditor_WarningText.undid = 1;
		}
		else
		{
			Swol_TextEditor_UndoButton.setActive(0);
			Swol_TextEditor_UndoButton.setColor("0.5 1 0.5 0.5");			
		}
	}
	function Swol_TEsortList(%id)
	{
		if(Swol_TextEditor_List.sortDir[%id])
		{
			Swol_TextEditor_List.sortDir[%id] = 0;
			Swol_TextEditor_List.sort(%id,1);
		}
		else
		{
			Swol_TextEditor_List.sortDir[%id] = 1;
			Swol_TextEditor_List.sort(%id,0);			
		}
	}
	function Swol_TEsortListNum(%id)
	{
		if(Swol_TextEditor_List.sortDir[%id])
		{
			Swol_TextEditor_List.sortDir[%id] = 0;
			Swol_TextEditor_List.sortNumerical(%id,1);
		}
		else
		{
			Swol_TextEditor_List.sortDir[%id] = 1;
			Swol_TextEditor_List.sortNumerical(%id,0);			
		}
	}
	function Swol_TEwriteToTrustList()
	{
		%f = new fileObject();
		%f.openForWrite("config/client/prefs-trustList.txt");
		for(%i=0;%i<Swol_TextEditor_List.count;%i++)
		{
			%text = Swol_TextEditor_List.getRowText(%i);
			if(Swol_TextEditor_List.getRowText(%i) $= "")
			continue;
			
			%name = getField(%text,0);
			%blid = getField(%text,1);
			%trust = getField(%text,2);
			%f.writeLine(%blid TAB Swol_TEtrustToNum(%trust) TAB %name);
		}
		%f.close();
		%f.delete();
	}
	function Swol_TEmainButton()
	{
		if(Swol_TextEditor_List.curSelectNum != -1)
		Swol_TEremoveElement(Swol_TextEditor_List.getRowNumById(Swol_TextEditor_List.curSelectNum));
	}
	function Swol_TEremoveElement(%num)
	{
		cancel($Swol_TeSched);
		Swol_TextEditor_WarningText.setText("<color:cc0000>Removed " @ getField(Swol_TextEditor_List.getRowText(%num),0) @ " from trust list");
		$Swol_TeSched = schedule(2500,0,Swol_TEclearWarning);
		Swol_TextEditor_List.undo = Swol_TextEditor_List.getRowText(%num);
		Swol_TextEditor_List.removeRow(%num);
		Swol_TextEditor_UndoButton.setActive(1);
		Swol_TextEditor_UndoButton.setColor("0.5 1 0.5 1");
		Swol_TEwriteToTrustList();
		Swol_TextEditor_List.curSelectNum = -1;
		Swol_TextEditor_MainButton.setActive(0);
		Swol_TextEditor_MainButton.setColor("1 0.5 0.5 0.5");
		Swol_TextEditor_WarningText.undid = 0;
	}
	function Swol_TEaddElement(%text,%typ)
	{
		if(%typ)
		{
			%name = getField(%text,0);
			%blid = getField(%text,1);
			%trust = getField(%text,2);
		}
		else
		{
			%blid = getField(%text,0);
			%trust = getField(%text,1);
			%name = getField(%text,2);	
			%trust = Swol_TEnumToTrust(%trust);
		}
		
		Swol_TextEditor_List.addRow(Swol_TextEditor_List.count,%name TAB %blid TAB %trust,Swol_TextEditor_List.count);
		Swol_TextEditor_List.count++;
	}
	function Swol_TextEditor_List::onSelect(%this,%selected)
	{
		Swol_TextEditor_List.curSelectNum = %selected;
		Swol_TextEditor_MainButton.setActive(1);
		Swol_TextEditor_MainButton.setColor("1 0.5 0.5 1");
	}
	function SwolTEbind(%x)
	{
		if(%x)
		{
			Swol_TEopen();
		}
	}
};
ActivatePackage(swol_TrustEdit);
Swol_TEloadBind();
if(!isFile("config/client/trustEditorBind.cs"))
{
	GlobalActionMap.bind(keyboard,"ctrl 0",SwolTEbind);
}
Swol_TEinjectPlayerList();
Swol_TEbuildList();
Swol_TextEditor_WarningText.undid = 1;