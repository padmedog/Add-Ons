datablock fxDTSBrickData(brick1x1FPoleFullData)
{
	brickFile = "./1x1FPoleFull.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole plus";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FPoleFull";
};
//corner
datablock fxDTSBrickData(brick1x1FHorizCornerData)
{
	brickFile = "./1x1FHorizCorner.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole Corner";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FHorizCorner";
};
datablock fxDTSBrickData(brick1x1FVertCornerData)
{
	brickFile = "./1x1FVertCorner.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole Corner up";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FVertCorner";
};
datablock fxDTSBrickData(brick1x1FVertCornerDData)
{
	brickFile = "./1x1FVertCornerD.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole Corner down";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FVertCornerD";
};
//T
datablock fxDTSBrickData(brick1x1FVertTData)
{
	brickFile = "./1x1FHorizT.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole T";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FHorizT";
};
datablock fxDTSBrickData(brick1x1FVertTDData)
{
	brickFile = "./1x1FVertTD.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole T down";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FVertTD";
};
datablock fxDTSBrickData(brick1x1FVertTUData)
{
	brickFile = "./1x1FVertTU.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole T up";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FVertTU";
};
//+
datablock fxDTSBrickData(brick1x1FHorizPlusData)
{
	brickFile = "./1x1FHorizPlus.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole X";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FHorizPlus";
};
datablock fxDTSBrickData(brick1x1FVertPlusData)
{
	brickFile = "./1x1FVertPlus.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole X Vert";
	iconName = "Add-ons/Brick_PoleAdapters/1x1FVertPlus";
};
//Tophius's original pole bricks are a little too large in width
//The lines on them would also not look very good stacked on our adapters 
//thus, we have to make our own and replace his

datablock fxDTSBrickData(brick1x1x3poleData)
{
	brickFile = "./1x1x3pole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1x3 Pole";
	iconName = "Add-Ons/Brick_PoleAdapters/1x1x3pole";
	collisionShapeName = "./1x1x3pole.dts";
};

datablock fxDTSBrickData(brick1x1poleData)
{
	brickFile = "./1x1pole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1 Pole";
	iconName = "Add-Ons/Brick_PoleAdapters/1x1pole";
	collisionShapeName = "./1x1pole.dts";
};

datablock fxDTSBrickData(brick1x1fpoleData)
{
	brickFile = "./1x1fpole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1F Pole";
	iconName = "Add-Ons/Brick_PoleAdapters/1x1fpole";
	collisionShapeName = "./1x1fpole.dts";
};