//audio
datablock AudioProfile(PlasmagunFireSound)
{
   filename    = "./Plasmagun_fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(PlasmagunSmokeParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 525;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 1 1 0.25";
	colors[1]     = "0 0.5 1 0.0";
	sizes[0]      = 0.6;
	sizes[1]      = 1.2;

	useInvAlpha = false;
};

datablock ParticleEmitterData(PlasmagunSmokeEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 0.5;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlasmagunSmokeParticle";

};

datablock ParticleData(PlasmagunTrailParticle)
{
	dragCoefficient		= 1;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.5;
	constantAcceleration	= 0.0;
	lifetimeMS		= 300;
	lifetimeVarianceMS	= 100;
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 1 0.5";
	colors[1]	= "1 1 1 0.5";
	colors[2]	= "0 0.5 1 0.0";
	sizes[0]	= 0.0;
	sizes[1]	= 1.25;
	sizes[2]	= 0.25;
	times[0]	= 0.0;
	times[1]	= 0.125;
	times[2]	= 1;
};

datablock ParticleEmitterData(PlasmagunTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = PlasmagunTrailParticle;

   useEmitterColors = true;
};

datablock ParticleData(PlasmagunExplosionParticle)
{
	dragCoefficient      = 9;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 375;
	lifetimeVarianceMS   = 300;
	textureName          = "./power";
	spinSpeed		= 50.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1.0 1.0 1.0 0.9";
	colors[1]     = "0.0 0.5 0.9 0.0";
	sizes[0]      = 3;
	sizes[1]      = 6;
    times[0] = 0.0;
    times[1] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(PlasmagunExplosionEmitter)
{
   lifetimeMS = 100;
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 10.0;
   velocityVariance = 5.0;
   ejectionOffset   = 1.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 360;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "PlasmagunExplosionParticle";

   useEmitterColors = false;
};


datablock ParticleData(PlasmagunExplosionRingParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 1;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 375;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 50.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0 0.5 1.0 0.5";
	colors[1]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 4;
	sizes[1]      = 8;

	useInvAlpha = false;
};
datablock ParticleEmitterData(PlasmagunExplosionRingEmitter)
{
	lifeTimeMS = 150;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlasmagunExplosionRingParticle";

   useEmitterColors = true;
};

datablock ParticleData(PlasmagunFlashParticle)
{
	dragCoefficient      = 10;
	gravityCoefficient   = -2.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 500;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.2 0.6 1.0 0.9";
	colors[1]     = "0.5 0.5 0.5 0.125";
	colors[2]	  = "0.5 0.5 0.5 0.0";
	sizes[0]      = 1.0;
	sizes[1]      = 1.25;
	sizes[2]      = 3.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(PlasmagunFlashEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 15.0;
   velocityVariance = 10.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlasmagunFlashParticle";

};

datablock ExplosionData(PlasmagunExplosion)
{
   //explosionShape = "";
	soundProfile = MeltagunHitSound;

   lifeTimeMS = 100;

   particleEmitter = PlasmagunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = PlasmagunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 2.5;
   
   damageRadius = 0; 
   radiusDamage = 0;                                           
   impulseRadius = 2;  
   impulseForce = 2000;    

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0 0.5 1 1";
   lightEndColor = "0 0.25 0.5 0";
};

AddDamageType("Plasmagun",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Plasmagun> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Plasmagun> %1',0.75,1);
datablock ProjectileData(PlasmagunProjectile)
{
   //projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 75;
   directDamageType    = $DamageType::Plasmagun;
   radiusDamageType    = $DamageType::Plasmagun;

   brickExplosionRadius = 1;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 16;
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground
   
   impactImpulse	     = 1200;
   verticalImpulse	  = 400;
   explosion           = PlasmagunExplosion;
   particleEmitter     = "PlasmagunTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 8000;
   fadeDelay           = 7200;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = true;
   lightRadius = 6.0;
   lightColor  = "0.75 1 1";
   
   uiName = "Plasma Bolt";
};

//////////
// item //
//////////
datablock ItemData(PlasmagunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Plasmagun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Plasma Gun";
	iconName = "./Plasmagun";
	doColorShift = false;
	colorShiftColor = "0.7 0.7 0.72 1.000";

	 // Dynamic properties defined by the scripts
	image = PlasmagunImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 10;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(PlasmagunImage)
{

   // Basic Item properties
   shapeFile = "./Plasmagun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = PlasmagunItem;
   ammo = " ";
   projectile = PlasmagunProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = PlasmagunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.55;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.2;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= PlasmagunFlashEmitter;
	stateEmitterTime[2]		= 0.25;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= PlasmagunFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= PlasmagunSmokeEmitter;
	stateEmitterTime[3]		= 0.15;
	stateEmitterNode[3]		= "muzzleNode";
	//stateTimeoutValue[3]            = 0.05;
	stateTransitionOnTriggerup[3]     = "Wait";
	//stateTransitionOnTriggerDown[3] = "Explode";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.175;
	stateTransitionOnTimeout[4]	= "Ready";
	
	statename[10]				= "Explode";
	statesequence[10]			= "Explode";
	stateTimeoutValue[10]		= 2.0;
	stateScript[10]				= "onExplode";
	stateTransitionOnTimeout[10] = "Wait";
	stateEmitter[10]			= PlasmagunSmokeEmitter;
	stateEmitterTime[10]		= 0.250;
	stateEmitterNode[10]		= "muzzleNode";
};

function PlasmagunImage::onExplode(%this,%obj,%slot)
{
	%obj.spawnExplosion(PlasmagunProjectile,"2 2 2");
	%obj.client.player.addhealth("-35");
}
//shits broke, yo
//actually works now

function PlasmagunImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, plant);


	%obj.spawnExplosion(TTLargeRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0018;
	}
	else
	{
		%spread = 0.0009;
	}
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}

