datablock ExplosionData(MortarExplosion : GrenaderExplosion)
{
   //explosionShape = "";

   explosionShape = "./explosionSphere1.dts";

   damageRadius = 15;
   radiusDamage = 90;

   impulseRadius = 16;
   impulseForce = 5000;
};

AddDamageType("MortarDirect",   '<bitmap:add-ons/Weapon_Package_Explosive2/CI_Grenade_launcher> %1',    '%2 <bitmap:add-ons/Weapon_Package_Explosive2/CI_Grenade_launcher> %1',1,1);
datablock ProjectileData(MortarProjectile : GrenaderProjectile)
{
   projectileShapeName = "add-ons/weapon_package_tier1/ammo_grenade.dts";
   directDamage        = 10;
   directDamageType = $DamageType::MortarDirect;
   radiusDamageType = $DamageType::MortarDirect;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = MortarExplosion;
   particleEmitter     = GrenadeSmokeEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;             
   brickExplosionMaxVolume = 76;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 98;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity = 65;
   velInheritFactor    = 0.0;

   armingDelay         = 1000;
   lifetime            = 10000;
   fadeDelay           = 10000;
   bounceElasticity    = 0.2;
   bounceFriction      = 1.00;
   isBallistic         = true;
   gravityMod = 1;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "Howitzer Grenade";
};

//////////
// item //
//////////
datablock ItemData(MortarItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
   shapeFile = "./howitzer.DTS";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Howitzer";
	iconName = "./icon_Grenade_launcher";
	doColorShift = true;
	colorShiftColor = "0.40 0.40 0.42 1.000";
	l4ditemtype = "grenade";

	 // Dynamic properties defined by the scripts
	image = MortarImage;
	canDrop = true;

	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MortarImage)
{
   // Basic Item properties
   shapeFile = "./howitzer.DTS";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = MortarItem;
   ammo = " ";
   projectile = MortarProjectile;
   projectileType = Projectile;

	casing = MortarDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 700;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = true;
   colorShiftColor = MortarItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.35;
	stateSequence[0]                = "Reload";
	stateTransitionOnTimeout[0]       = "FireLoadCheckA";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnNoAmmo[1]		= "ReloadStart";
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Delay";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                  = "Fire";
	stateScript[2]                  = "onFire";
	stateSound[2]					= GrenaderFireSound;
	stateWaitForTimeout[2]			= true;

	stateName[3]			= "Delay";
	stateTransitionOnTimeout[3]     = "ReloadStart";
	stateTimeoutValue[3]            = 0.1;
	stateSequence[3]                  = "Reload";
	stateEmitterTime[3]				= 0.03;
	stateEmitterNode[3]				= "muzzleNode";
	
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 1.2;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.4;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadStart";
	
	stateName[10] 				= "Smoke";
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Halt";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
	
	stateName[12]				= "Reloaded";
	stateTimeoutValue[12]			= 0.1;
	stateScript[12]				= "onReloaded";
	stateTransitionOnTimeout[12]		= "Activate";

	stateName[13]			= "Halt";
	stateTransitionOnTimeout[13]     = "Ready";
	stateTimeoutValue[13]            = 0.9;
	stateEmitterTime[13]				= 0.48;
	stateEmitterNode[13]				= "muzzleNode";
	stateScript[13]                  = "onHalt";

	stateName[14]                     = "ReloadStart";
	stateTransitionOnTimeout[14]  = "ReloadStartB";
	stateTimeoutValue[14]            = 0.1;
	stateAllowImageChange[14]         = false;

	stateName[15]                     = "ReloadStartB";
	stateTransitionOnTriggerDown[15]  = "LoadCheckA";
	stateAllowImageChange[15]         = true;
};

function MortarImage::onFire(%this,%obj,%slot)
{
	%dist = 100;
	%range = 300*getWord(%obj.getScale(),2);
	%start = %obj.getEyePoint();
	%fvec = %obj.getForwardVector();
	%fX = getWord(%fvec,0);
	%fY = getWord(%fvec,1);
	%evec = %obj.getEyeVector();
	%eX = getWord(%evec,0);
	%eY = getWord(%evec,1);
	%eZ = getWord(%evec,2);
	%eXY = mSqrt(%eX*%eX+%eY*%eY);
	%aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%end = vectorAdd(%start,vectorScale(%aimVec,%range));
	%ray = containerRayCast(%start,%end,$TypeMasks::All,%obj);
	%target = firstWord(%ray);
	if(isObject(%target))
	{
		%pos = posFromRaycast(%ray);
		%dist = vectorDist(%obj.getPosition(),%pos);
	}
	%initVelocity = vectorScale(%obj.getMuzzleVector(%slot),18.25);
	%initVelocity = vectorAdd(%initVelocity,getRandom(0,3) / 6 SPC getRandom(0,3) / 6 SPC %dist/3.75);
	%p = new (%this.projectileType)()
	{
		dataBlock = %this.projectile;
		initialVelocity = %initVelocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 

	%obj.playThread(2, plant);
	%obj.toolAmmo[%obj.currTool]--;
}

function MortarImage::onReloadStart(%this,%obj,%slot)
{
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
	
	%obj.playThread(2, shiftdown);
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
}

function MortarImage::onHalt(%this,%obj,%slot)
{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
}


function MortarImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function MortarImage::onActivate(%this,%obj,%slot)
{
	
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
            		serverPlay3D(RPGClickSound,%obj.getPosition());
	}
}

function MortarImage::onReady(%this,%obj,%slot)
{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
}

function MortarImage::onReloadWait(%this,%obj,%slot)
{
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
		%obj.playThread(2,plant);
            		serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
}

function MortarImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["bombrounds"] >= 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Explosive Rounds <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["bombrounds"] @ "", 4, 2, 3, 4); 
		%obj.client.quantity["bombrounds"]--;
		%obj.toolAmmo[%obj.currTool]++;
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
}