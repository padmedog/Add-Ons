//====================================
//Title: Tactical Player
//Author: Swollow
//Version: 4
//Player_Tactical.cs
//====================================

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
	{
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	}
	RTB_registerPref("Heal Delay", "Tactical Player", "$TACPLAYER::HealDelay", "int 100 5000", "Player_Tactical", 2750, 0, 0);
	RTB_registerPref("Heal Speed", "Tactical Player", "$TACPLAYER::HealSpeed", "int 50 1000", "Player_Tactical", 300, 0, 0);
	RTB_registerPref("Fall Damage Amount", "Tactical Player", "$TACPLAYER::FallDamageDampener", "list Original 1 Better 2 Bouncy 3", "Player_Tactical", 2, 0, 0);
	RTB_registerPref("Can Cripple Legs", "Tactical Player", "$TACPLAYER::CrippledLegs", "bool", "Player_Tactical", 1, 0, 0, "TacPlayer_tick");
	RTB_registerPref("Can Heal", "Tactical Player", "$TACPLAYER::Healable", "bool", "Player_Tactical", 1, 0, 0, "TacPlayer_tick");
}
else
{
	$TACPLAYER::HealDelay = 2750;
	$TACPLAYER::HealSpeed = 300;
	$TACPLAYER::FallDamageDampener = 2;
	$TACPLAYER::CrippledLegs = 1;
	$TACPLAYER::Healable = 1;
}
//---------------------------
// Sounds
//---------------------------

datablock AudioProfile(Tactical_HeartBeatSound)
{
	filename    = "./HeartBeat.wav";
	description = Audio2d;
	preload = true;
};

datablock AudioProfile(Tactical_HeartBeatFaintSound)
{
	filename    = "./HeartBeatFaint.wav";
	description = Audio2d;
	preload = true;
};

datablock AudioProfile(Tactical_FallDamageSound)
{
	filename    = "./FallDamage.wav";
	description = AudioClose3d;
	preload = true;
};

//---------------------------
// Explosions
//---------------------------

datablock ExplosionData(TacticalExplosion)
{
	explosionShape = "";
	soundProfile = Tactical_FallDamageSound;
	lifeTimeMS = 150;

	faceViewer = true;
	explosionScale = "1 1 1";

	shakeCamera = true;
	camShakeFreq = "5 8 5";
	camShakeAmp = "1.1 1.3 1.2";
	camShakeDuration = 0.5;
	camShakeRadius = 10.0;
};

datablock ProjectileData(TacticalProjectile)
{
	lifetime = 10;
	explodeondeath = true;
	explosion = TacticalExplosion;
};

//---------------------------
// Playertypes
//---------------------------

datablock PlayerData(TacticalPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
 	runForce = 100 * 60;
  	runEnergyDrain = 0;
   	minRunEnergy = 0;
   	
	maxForwardSpeed = 8;
   	maxBackwardSpeed = 5;
   	maxSideSpeed = 5;

	maxForwardCrouchSpeed = 5;
   	maxBackwardCrouchSpeed = 3;
   	maxSideCrouchSpeed = 2;
   	
	jumpForce = 12 * 90;
   	jumpEnergyDrain = 0;
   	minJumpEnergy = 0;
   	jumpDelay = 0;

	jumpsound = "";
	uiName = "Tactical Player";
	showEnergyBar = false;
};
datablock PlayerData(TacticalPlayerMed : TacticalPlayer)
{
	maxForwardSpeed = 6;
   	maxBackwardSpeed = 4;
   	maxSideSpeed = 4;

	maxForwardCrouchSpeed = 2;
   	maxBackwardCrouchSpeed = 1;
   	maxSideCrouchSpeed = 1;
   	
	jumpForce = 8 * 90;
   	jumpDelay = 25;

	uiName = "";
};
datablock PlayerData(TacticalPlayerLow : TacticalPlayer)
{
	maxForwardSpeed = 4;
   	maxBackwardSpeed = 3;
   	maxSideSpeed = 3;

	maxForwardCrouchSpeed = 2;
   	maxBackwardCrouchSpeed = 1;
   	maxSideCrouchSpeed = 1;
   	
	jumpForce = 6 * 90;
   	jumpDelay = 45;

	uiName = "";
};

datablock PlayerData(TacticalPlayerCrippled : TacticalPlayer)
{
	maxForwardSpeed = 0;
   	maxBackwardSpeed = 0;
   	maxSideSpeed = 0;

	maxForwardCrouchSpeed = 1;
   	maxBackwardCrouchSpeed = 1;
   	maxSideCrouchSpeed = 1;
   	
	jumpForce = 90;
   	jumpDelay = 100;

	uiName = "";
};

datablock PlayerData(TacticalPlayerCrippledHealed : TacticalPlayer)
{
	maxForwardSpeed = 1;
   	maxBackwardSpeed = 1;
   	maxSideSpeed = 1;

	maxForwardCrouchSpeed = 2;
   	maxBackwardCrouchSpeed = 1;
   	maxSideCrouchSpeed = 1;
   	
	jumpForce = 2 * 90;
   	jumpDelay = 89;

	uiName = "";
};

//---------------------------
// Damage
//---------------------------
package Tactical_Player
{
	function TacticalPlayer::onDamage(%this,%obj,%am)
	{
		parent::onDamage(%this,%obj,%am);
		
		if(%am > 0 && $TACPLAYER::Healable)
		{
			if(isEventPending(%obj.Tac_Repair))
			cancel(%obj.Tac_Repair);
				
			if(%obj.getState() !$= "Dead")
			%obj.Tac_Repair = %obj.schedule($TacPlayer::HealDelay,TacticalRepair);
		}
		if(%Obj.GetDamageLevel() >= 80)
		{
			%Obj.SetDataBlock("TacticalPlayerLow");
			TacticalPlayer_HeartBeat(%Obj,1);
			return;
		}
		if(%Obj.GetDamageLevel() >= 60)
		{
			%Obj.SetDataBlock("TacticalPlayerMed");
			TacticalPlayer_HeartBeat(%Obj,0);
			return;
		}
	}
	function TacticalPlayerMed::OnDamage(%This,%Obj,%Am)
	{
		parent::OnDamage(%This,%Obj,%Am);
		if(%Obj.GetDamageLevel() <= 60)
		{
			%Obj.SetDataBlock("TacticalPlayer");
			return;
		}
		if(%Obj.GetDamageLevel() >= 80)
		{
			%Obj.SetDataBlock("TacticalPlayerLow");
			TacticalPlayer_HeartBeat(%Obj.client,1);
			return;
		}
	}
	function TacticalPlayerLow::OnDamage(%This,%Obj,%Am)
	{
		parent::OnDamage(%This,%Obj,%Am);
		if(%Obj.GetDamageLevel() <= 60)
		{
			%Obj.SetDataBlock("TacticalPlayer");
			return;
		}
		if(%Obj.GetDamageLevel() <= 80)
		{
			%Obj.SetDataBlock("TacticalPlayerMed");
			TacticalPlayer_HeartBeat(%Obj,0);
			return;
		}
	}
	function TacticalPlayerCrippled::OnDamage(%This,%Obj,%Am)
	{
		if(%Obj.GetDamageLevel() <= 50)
		{
			%Obj.SetDataBlock("TacticalPlayerCrippledHealed");
			%obj.setCrippledMsg=0;
			TacticalPlayer_HeartBeat(%Obj,0);
			return;
		}
	}
	function TacticalPlayerCrippledHealed::OnDamage(%This,%Obj,%Am)
	{
		if(%Obj.GetDamageLevel() <= 20)
		{
			%obj.setCrippledMsg=0;
			%Obj.SetDataBlock("TacticalPlayer");
			return;
		}
	}
//---------------------------
// HeartBeat
//---------------------------
	function TacticalPlayer_HeartBeat(%Obj,%Type)
	{
		cancel(%Obj.Tac_HeartBeatSchedule);
		if(isObject(%Obj.player))
		%Obj=%Obj.Player;
		if(!isobject(%obj))
		return;
		if(%obj.getstate() $= "Dead")
		return;
		
		if(%obj.getdatablock().getname() $= "TacticalPlayerLow" || %obj.getdatablock().getname() $= "TacticalPlayerMed" || %obj.getdatablock().getname() $= "TacticalPlayerCrippled" || %obj.getdatablock().getname() $= "TacticalPlayerCrippledHealed")
		{
			%Client = %Obj.Client;

			if(%obj.getdatablock().getname() $= "TacticalPlayerMed" || %obj.getdatablock().getname() $= "TacticalPlayerCrippledHealed")
			{

				commandToClient( %Client,'SetVignette',false,"1 0 0" SPC 0.5);

				%Client.Play2d(Tactical_HeartBeatFaintSound);
				%Obj.Tac_HeartBeatSchedule = schedule(750,0,TacticalPlayer_HeartBeat,%Obj,%Am);
				%Obj.setdamageflash(0.2);
				TacticalPlayer_HeartBeatFade(%Obj.client,0.5);
			}
			if(%obj.getdatablock().getname() $= "TacticalPlayerLow" || %obj.getdatablock().getname() $= "TacticalPlayerCrippled")
			{
				commandToClient( %Client,'SetVignette',false,"1 0 0" SPC 1);

					
				%Client.Play2d(Tactical_HeartBeatSound);
				if(%Obj.GetDamageLevel() >= 90)
				{
					if(%obj.setCrippledMsg > 0)
					{
						%obj.setCrippledMsg--;
						centerPrint(%Client,"<br><br><br><br>\c6Your legs have been crippled<br>\c0Seek cover!", 1);
					} else {
						if($TACPLAYER::Healable)
						centerPrint(%Client,"<br><br><br><br><br>\c0You are injured seek cover!", 1);
						if(!$TACPLAYER::Healable)
						centerPrint(%Client,"<br><br><br><br><br>\c0You are injured!", 1);
					}


					%Obj.setdamageflash(0.6);
				}
				if(%Obj.GetDamageLevel() < 89)
				{
					%obj.setCrippledMsg=0;
					%Obj.setdamageflash(0.3);
				}

				%Obj.Tac_HeartBeatSchedule = schedule(600,0,TacticalPlayer_HeartBeat,%Obj,%Am);
				TacticalPlayer_HeartBeatFade(%Obj.client,1);
			}
		}
	}

	function TacticalPlayer_HeartBeatFade(%Client,%Am,%Val)
	{
		cancel(Tac_HeartFadeSchedule);
		
		if(%Am < 0)
		{
			commandToClient(%Client,'SetVignette',$EnvGuiServer::VignetteMultiply,$EnvGuiServer::VignetteColor);
			return;
		}

		commandToClient( %Client,'SetVignette',false,"1 0 0" SPC %Am);
		%Client.Tac_HeartFadeSchedule = schedule(50,0,"TacticalPlayer_HeartBeatFade",%Client,%Am-0.1);
		

	}
//---------------------------
// Fall Damage
//---------------------------
	function TacticalPlayer::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
	{
		if(%damageType == $DamageType::Fall || %damageType == $DamageType::Impact)
		{
			if(%obj.getDatablock().maxDamage - %obj.getDamageLevel() > %damage/$TacPlayer::FallDamageDampener + 0.2)
			{
				%obj.addhealth(-%damage/$TacPlayer::FallDamageDampener + 0.2);
				%p = new Projectile()
       				{
            				datablock = TacticalProjectile;
            				scale = "1 1 1";
            				initialVelocity = "0 0 0";
            				initialPosition = %obj.position;
            				sourceObject = %obj;
            				sourceSlot = 0;
            				client = %obj.client;
         			};
				if($TacPlayer::FallDamageDampener == 3)
				{
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 30)
				%boost = 5;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 40)
				%boost = 10;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 50)
				%boost = 15;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 60)
				%boost = 20;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 70)
				%boost = 25;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 80)
				%boost = 30;
					%Obj.addvelocity("0 0" SPC %boost);
				}
				if(!$TACPLAYER::CrippledLegs)
				{
					return parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType);
				}
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 0)
				%crippleamt = 10;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 60)
				%crippleamt = 6;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 70)
				%crippleamt = 4;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 80)
				%crippleamt = 2;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 90)
				%crippleamt = 1;
				if(%damage/$TACPLAYER::FallDamageDampener + 0.2 > 95)
				%crippleamt = 0;

				%random = getrandom(0,%crippleamt);

				switch(%random)
				{
					case 0:
					%obj.sethealth(1);
					%obj.setCrippledMsg = 10;
					centerPrint(%Obj.Client,"");
					%obj.setdatablock("TacticalPlayerCrippled");
					return;
				}

				return;
			} else {
				return parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType);
			}
		} else {
			return parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType);
		}
	}
//---------------------------
// Healing
//---------------------------
	function Player::TacticalRepair(%obj)
	{
		if(%obj.getdamagelevel() > 0)
        	{
        		%obj.addhealth(1);
        		%obj.Tac_Repair = %obj.schedule($TacPlayer::HealSpeed+%obj.getDamageLevel(),TacticalRepair);
	  	}
	}
};
ActivatePackage(Tactical_Player);