//The auto reloader will ignore this file, so only put things that should only be loaded once in here. Otherwise use main.cs

$BRPG::Client::onMouseEnter = isFunction("GuiMouseEventCtrl", "onMouseEnter");
$BRPG::Client::onMouseLeave = isFunction("GuiMouseEventCtrl", "onMouseLeave");

$BRPG::Client::onMouseDown = isFunction("GuiMouseEventCtrl", "onMouseDown");
$BRPG::Client::onMouseUp = isFunction("GuiMouseEventCtrl", "onMouseUp");

$BRPG::Client::onMouseDragged = isFunction("GuiMouseEventCtrl", "onMouseDragged");

$BRPG::Client::onRightMouseDown = isFunction("GuiMouseEventCtrl", "onRightMouseDown");
$BRPG::Client::onRightMouseUp = isFunction("GuiMouseEventCtrl", "onRightMouseUp");

new GuiControlProfile(InventorySlotProfile : BlockButtonProfile) {
	fontColor = "255 255 255 255";
};


exec("./main.cs");

exec("./battleMembers_once.cs");

exec("./controls_once.cs");