%error = forceRequiredAddOn("Weapon_MedPack2");
if(%error $= $Error::AddOn_NotFound)
{
	error("ERROR: Weapon_MedPack3 - required add-on Weapon_MedPack2 not found");
}
else
{
	exec("./Maul.cs");
	exec("./BladedBow.cs");
	exec("./Dagger.cs");
	exec("./Rapier.cs");
	exec("./HiddenBlade.cs");
	exec("./MagicWand.cs");

}