//Default Settings
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
   if(!$RTB::RTBR_ServerControl_Hook)
      exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
      
  // RTB_registerPref("Hunger","Hunger Mod","Hunger::On","bool","Script_Hunger",1,0,0);
   RTB_registerPref("Hunger Tick (seconds)","Hunger Mod","Hunger::TickTime","int 3 480","Script_Hunger",60,0,0);
   RTB_registerPref("Cannibalism","Hunger Mod","Hunger::EatPeeps","bool","Script_Hunger",0,0,0);
   RTB_registerPref("Food Cost","Hunger Mod","Hunger::FoodCost","int 0 100","Script_Hunger",10,0,0);
   RTB_registerPref("Events","Hunger Mod","Hunger::Event","bool","Script_Hunger",1,0,0);
   RTB_registerPref("Food in Horses","Hunger Mod","hunger::FoodHorse","int 0 100","Script_Hunger",5,0,0);
}
else
{
	$Hunger::FoodCost = 10;
	$Hunger::TickTime = 30;
	$Hunger::FoodFill = 10;
	$Hunger::EatPeeps = 0;
	$Hunger::Event = 1;
	$hunger::FoodHorse = 5;
}
$Hunger::On = 1;
$Hunger::FoodFill = 10;

AddDamageType("Hunger",   '',    '%2 lol how can you kill someone else of hunger? %1',1,1);
AddDamageType("Eat",   '%1 ate of himeself.',    '%2 has eaten %1.',1,1);

RegisterSpecialVar(GameConnection,"hunger","%this.hunger");
RegisterSpecialVar(GameConnection,"food","$food[%this.bl_id]");
	
//Package for joining and leaving game
package Hunger
{
   	function GameConnection::autoAdminCheck(%client)
   	{   
   	Parent::autoAdminCheck(%client);
	%client.hunger = 100;
	schedule(200,0,ShowHungerBTick);
	schedule(1000,0,EnergyConsumption);
	schedule(2000,0,HTBAlerts);
	schedule(2000,0,HTBWarn);
	//$decay[%client] = schedule($Hunger::TickTime,0,"hungerdecay",%client);
	if(!$food[%client.bl_id])
	{
		$food[%client.bl_id] = 2;
	}
	%client.canBuyFood = 0;
   	}
   	
   	function GameConnection::OnClientEnterGame(%client)
	{
		Parent::OnClientEnterGame(%client);
		%client.hasSpawned = 1;
		
		if(!$hungerTick && $Hunger::On == 1)
			hungerTick();
	}

	function player::activateStuff(%obj)
	{
		Parent::activateStuff(%obj);
		if($Hunger::On == 1 && $Hunger::EatPeeps == 1)
		{
			%client = %obj.client;
				%target = containerRayCast(%client.player.getEyePoint(), vectorAdd(vectorScale(vectorNormalize(%client.player.getEyeVector()), 8), %client.player.getEyePoint()),$typeMasks::playerObjectType).client;
				if(isObject(%target))
				{
					if(%client.hunger >= 100)
					{
						commandToClient(%client, 'CenterPrint', "\c6You're full!!", 2);
						return;
					}
					
					if(getRandom(0, 100) >= 85)
					{
						return;
					}
				
					commandToClient(%target, 'CenterPrint', %client.getPlayerName() @ " is eating you!", 1);
					%target.player.damage(%client.player, %target.player.getTransform, 3, $DamageType::Eat);
					
					%client.hunger = %client.hunger + 5;
					if(%client.hunger > 100)
					{
						%client.hunger = 100;
					}
					commandToClient(%client, 'CenterPrint', "\c6You ate a peice of \c3" @ %target.getPlayerName() @ "\c6.", 1);
			}
		}
				
	}

	function brickFoodShopData::onPlant(%this,%brick)
	{
 				
		Parent::onPlant(%this,%brick);
 		schedule(100,0,"foodshop",%brick);

	}

	function brickFoodShopData::onRemove(%this,%brick)
	{
 		Parent::onRemove(%this,%brick);
 		if(isObject(%brick.trigger)){%brick.trigger.delete();}
	}	
	
	function HorseArmor::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
	{
		parent::damage(%this, %obj, %pos, %damage, %damageType);
		%obj.LastAttacker = %sourceObject.CLient;
		//echo(%obj.LastAttacker);
	}
	
	function GameConnection::spawnPlayer(%this)
	{
		%p = parent::spawnPlayer(%this);
	    
		%this.hunger = 100;
		%this.thirst = 100;
		%this.maxhunger = 100;
		%this.maxthirst = 100;
		
		return %p;
	}
	
	function HorseArmor::ondisabled(%this,%obj)
	{
		parent::ondisabled(%this,%obj);
		if($Hunger::On == 1 && $hunger::FoodHorse > 0)
		{
			%r = getRandom(-2, 2);
			%food = %r + $hunger::FoodHorse;
			if(%food < 1)
				%food = 1;
			
			$food[%obj.LastAttacker.bl_id] = $food[%obj.LastAttacker.bl_id] + %food;	
			messageClient(%obj.LastAttacker, '', "\c6You get \c3" @ %food @ "\c6 food from the horse. You now have\c3 " @ $food[%obj.LastAttacker.bl_id]  @ "\c6 food.");

		}
	}
};
activatePackage(Hunger);

function hungerTick()
{
	cancel($hungerTick);
	
	if($Hunger::On == 1)
	{
		for(%i=0;%i<ClientGroup.getCount();%i++)
		{
			%cl = ClientGroup.getObject(%i);
			hungerDecay(%cl);
		}	
			
		%time = $Hunger::TickTime * 1000;
		//echo(%time);
		if(isObject(ServerConnection) || $Server::Dedicated == 1)
			$hungerTick = schedule(%time,0,hungerTick);
	}
}

function serverCmdCheckHunger(%client)
{
	if($Hunger::On == 1)
	{
	}
	else
	{
		messageClient(%client, "", "\c6Hunger is currently disabled.");
	}
}

function serverCmdGiveFood(%client, %am)
{
	if(%am <= 0)
	{
		messageClient(%client, '', "\c6Invalid Amount");
		return;
	}
	
	if(%am > $food[%client.bl_id])
	{
		messageClient(%client, '', "\c6You don't have that much food.");
		return;
	}
	
	%target = containerRayCast(%client.player.getEyePoint(), vectorAdd(vectorScale(vectorNormalize(%client.player.getEyeVector()), 8), %client.player.getEyePoint()),$typeMasks::playerObjectType).client;
	if(isObject(%target))
	{
		$food[%client.bl_id] = $food[%client.bl_id] - %am;
		$food[%target.bl_id] = $food[%target.bl_id] + %am;
		messageClient(%client, '', "\c6You gave \c3" @ %am @ "\c6 food to\c3 " @ %target.getPlayerName() @ "\c6. You now have \c3" @ $food[%client.bl_id] @ "\c6 total food.");
		messageClient(%target, '', "\c3" @ %client.getPlayerName() @ "\c6 has given  you \c3" @ %am @ "\c6 food. You now have \c3" @ $food[%target.bl_id] @ "\c6 total food.");
	}
	else
	{
		messageClient(%client, '', "\c6You must be looking at someone to give them food.");
	}
}

function hungerDecay(%client)
{
    if(isObject(%client.player)) 
    {
	  if($Hunger::On == 0 || %client.hasSpawned == 0)
	  {
		return;
	  }

	  %hungerl = %client.hunger;
	  %client.player.EnergyConsumedHunger = %client.player.EnergyConsumedHunger / 20;
	  %client.player.EnergyConsumedHunger = mCeil(%client.player.EnergyConsumedHunger);
	  if(%client.player.EnergyConsumedHunger == 0)
	  {
	  %client.hunger = %hungerl - getRandom(3, 1);
	  }
	  if(%client.player.EnergyConsumedHunger < 0)
	  {
	  %client.player.EnergyConsumedHunger *= -1;
	  %client.hunger = %hungerl - (getRandom(3, 1) + %client.player.EnergyConsumedHunger);
	  }
	  if(%client.player.EnergyConsumedHunger > 0)
	  {
	  %client.hunger = %hungerl - (getRandom(3, 1) + %client.player.EnergyConsumedHunger);
	  }
	  echo(%client.player.EnergyConsumedHunger);
	  %client.player.EnergyConsumedHunger = 0;
	  
  	  if(%client.hunger <= 0)
	  {
		if(isObject(%client.player)) 
		{
			%client.player.damage(%client.player, %client.player.getTransform, 100, $DamageType::Hunger);
		}
	    %client.hunger = 100;
		%client.thirst = 100;
	    %client.maxhunger = 100;
		%client.maxthirst = 100;
	  }
	}
}

function ShowHungerBTick()
	{
		for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
			%c = clientGroup.getObject(%i);
			%c.bodyTempCelsiusOne = %c.bodyTemp - 32;
			%c.bodyTempCelsiusTwo = %c.bodyTempCelsiusOne * 5;
			%c.bodyTempCelsiusThree = %c.bodyTempCelsiusTwo / 9;
		  if($BottomPrintShown == 1)
		  {
			if($SurvivalMod::Data::ID[%c.bl_id,TempType] $= "Celsius")
			{
			%c.bottomPrint("\n\n\n\n" @ "<just:center><font:impact:26><color:FFFFFF>Hunger: " @ %c.hunger @ "/" @ %c.maxhunger @ "<color:666666>  -  <color:FFFFFF>Body Temp: " @ mFloatLength(%c.bodyTempCelsiusThree, 1) @ "�C" @ "  <color:666666>-  <color:FFFFFF>Thirst: " @ %c.thirst @ "/" @ %c.maxthirst @ " \n \n ", -1, 1);
			}
			if($SurvivalMod::Data::ID[%c.bl_id,TempType] $= "Fahrenheit")
			{
			%c.bottomPrint("\n\n\n\n" @ "<just:center><font:impact:26><color:FFFFFF>Hunger: " @ %c.hunger @ "/" @ %c.maxhunger @ "<color:666666>  -  <color:FFFFFF>Body Temp: " @ mFloatLength(%c.bodyTemp, 1) @ "�F" @ "  <color:666666>-  <color:FFFFFF>Thirst: " @ %c.thirst @ "/" @ %c.maxthirst @ " \n \n ", -1, 1);
			}
		  }
		}
		schedule(200,0,ShowHungerBTick);
	}
	
	function HTBAlerts()
	{ 
		for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
		  %c = clientGroup.getObject(%i);
		  if(isObject(%c.player))
	      {
			if(%c.hunger <= 10 && %c.thirst > 10 && %c.bodyTemp > 95)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your Starving!", 3);
			}
			if(%c.thirst <= 10 && %c.hunger > 10 && %c.bodyTemp > 95)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your De-Hydrated!", 3);
			}
			if(%c.bodyTemp <= 95 && %c.hunger > 10 && %c.thirst > 10 && %c.inHeatZone == 0)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>You need <color:C80000>Warmth<color:FFFFFF>!", 3);
			}
			if(%c.hunger <= 10 && %c.thirst <= 10 && %c.bodyTemp > 95)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your Starving and De-Hydrated!", 3);
			}
			if(%c.hunger <= 10 && %c.bodyTemp <= 95 && %c.thirst > 10 && %c.inHeatZone == 0)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your Starving and need <color:C80000>Warmth<color:FFFFFF>!", 3);
			}
			if(%c.thirst <= 10 && %c.bodyTemp <= 95 && %c.hunger > 10 && %c.inHeatZone == 0)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your De-Hydrated and need <color:C80000>Warmth<color:FFFFFF>!", 3);
			}
			if(%c.hunger <= 10 && %c.thirst <= 10 && %c.bodyTemp <= 95 && %c.inHeatZone == 0)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your Starving, De-Hydrated, and need <color:C80000>Warmth<color:FFFFFF>!", 3);
			}
			if(%c.hunger > 10 && %c.thirst > 10 && %c.bodyTemp >= 103)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>You need <color:235EB3>Cooling<color:FFFFFF>!", 3);
			}
			if(%c.hunger <= 10 && %c.thirst <= 10 && %c.bodyTemp >= 103)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your Starving, De-Hydrated, and need <color:235EB3>Cooling<color:FFFFFF>!", 3);
			}
			if(%c.hunger > 10 && %c.thirst <= 10 && %c.bodyTemp >= 103)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your De-Hydrated and need <color:235EB3>Cooling<color:FFFFFF>!", 3);
			}
		    if(%c.thirst > 10 && %c.hunger <= 10 && %c.bodyTemp >= 103)
			{
			%c.centerPrint("<color:FFFFFF>\n\n\n\n\n\n\n<just:center><font:arial bold:30>Your Starving and need <color:235EB3>Cooling<color:FFFFFF>!", 3);
			}
		  }
		}
		schedule(2000,0,HTBAlerts);
	}
	
		function HTBWarn()
	{ 
		for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
			%c = clientGroup.getObject(%i);
		  if(isObject(%c.player))
	      {
			if(%c.hunger <= 10)
			{
			%c.player.addhealth(-1);
			}
			if(%c.thirst <= 10)
			{
			%c.player.addhealth(-1);
			}
			if(%c.hunger <= 10 && %c.thirst <= 10)
			{
			%c.player.addhealth(-2);
			}
			if(%c.hunger <= 10 || %c.thirst <= 10 || %c.bodyTemp <= 95)
			{
			%c.playsound(HTBWarn);
			}
		  }
		}
		schedule(2000,0,HTBWarn);
	}
	
			function EnergyConsumption()
	{ 
		for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
		  %c = clientGroup.getObject(%i);
		  if(isObject(%c.player))
	      {
          %c.player.EnergyConsumedHunger = (%c.player.EnergyConsumedHunger + %c.player.getVelocity());
		  %c.player.EnergyConsumedThirst = (%c.player.EnergyConsumedThirst + %c.player.getVelocity());
		  }
		}
		schedule(1000,0,EnergyConsumption);
	}

//Shops

datablock TriggerData(Shop){
   tickPeriodMS = 100;
};

function shop::onEnterTrigger(%this, %trigger, %obj){
	if(!%obj.client.inshop){// if the enteree isnt already inside
	%obj.client.inshop = 1;
	if($Cash::CurrencyBefore)
	{
      	messageClient(%obj.client, "", "\c6Welcome to the food shop, type \c3/buyFood [amount]\c6 to buy food. The food price is \c3" @ $Cash::Currency @ $Hunger::FoodCost @ "\c6.");
	}
	else
	{
		messageClient(%obj.client, "", "\c6Welcome to the food shop, type \c3/buyFood [amount]\c6 to buy food. The food price is \c3" @ $Hunger::FoodCost @ $Cash::Currency @ "\c6.");
	}
}	
}

function shop::OnLeaveTrigger(%thid, %trigger, %obj){
	if(%obj.client.inshop){//make sure they're actually inside
	%obj.client.inshop = 0;//hes no longer inside
      messageClient(%obj.client, "", "\c6You have left the shop.");
  }
}

function serverCmdBuyFood(%client, %amount)
{
	if(!$Hunger::On)
	{
		messageClient(%client, "", "\c6Hunger is currently disabled.");
		return;
	}
	
	if(%amount < 0)
	{
		return;
	}
	
	if(!%amount)
	{
		%amount = 1;
	}
	
	%amount = mFloor(%amount);
	if(%client.inshop)
	{	
	%cost = $Hunger::FoodCost * %amount;
		if(%client.cashobj.cash >= %cost)
		{
			if(isObject(%client.cashobj))
			{
				%client.cashobj.mod("cash",0 - %cost);
			}
			$food[%client.bl_id] = $food[%client.bl_id] + %amount;
			messageClient(%client, "", "\c6You have bought \c3" @ %amount @ " \c6food. You now have \c3" @ $food[%client.bl_id] @ "\c6 total food.");
			messageClient(%client, "", "\c6Type \c3/eatFood [amount]\c6 to eat it.");
		}
		else
		{
			messageclient(%client,"","\c6You Do not have enough money to buy that much food!");
		}

	}
	else
	{
		messageClient(%client, "", "\c0You are not in a food shop.");
	}
}

function serverCmdEatFood(%client, %amount)
{
	if(!$Hunger::On)
	{
		messageClient(%client, "", "\c6Hunger is currently disabled.");
		return;
	}
		
	if(%amount < 0)
	{
		return;
	}
	
	if(!%amount)
	{
		%amount = 1;
	}
	
	if($food[%client.bl_id] < 1)
	{
		messageclient(%client,"","\c6You do not have any food to eat!");
		return;
	}

	if($food[%client.bl_id] < %amount)
	{
		%amount = $food[%client.bl_id];
	}
		
	%minfull = 100 - $Hunger::FoodFill * %amount;
	if(%client.hunger <= %minfull)
	{
		%client.hunger = %client.hunger + $Hunger::FoodFill * %amount;
		$food[%client.bl_id] = $food[%client.bl_id] - %amount;
		commandToClient(%client, 'CenterPrint', "\c6You ate \c3" @ %amount @ "\c6 food. You have \c3" @ $food[%client.bl_id] @ "\c6 food remaining.", 4);
	}
	else
	{
		messageclient(%client,"","\c6You are not hungery enough to eat that much food, please wait until your hunger level is \c3" @ %minfull @ " \c6or less");
	}	

}

function foodshop(%brick)
{
	if(%brick.getGroup().client.isSuperAdmin || %brick.getGroup().client.isAdmin){
	%posx = getWord(%brick.position,0);
	%posy = getWord(%brick.position,1);
	%posz = getWord(%brick.position,2);
	%posx = %posx - 0.5;
	%posy = %posy + 0.5;
	
	%temp = new trigger() {
	Datablock = "Shop";
	position = %posx SPC  %posy SPC %posz;
	scale = "1 1 1";
	rotation = "0 0 0 0";
	polyhedron = "0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 -1.0000000 0.0000000 0.0000000 0.0000000 1.0000000";
	};
	%brick.trigger = %temp;
	MissionCleanup.add(%temp);
  	}
	else
	{
	messageClient(%brick.getGroup().client, "", "This brick is admin only!");
	%brick.killbrick();
	}

}

//Setting Commands

function serverCmdHungerHelp(%client)
{
	messageclient(%client,"","\c3/eatFood [Amount]\c6 - Eat [Amount] food.");
	messageclient(%client,"","\c3/giveFood [Amount]\c6 - Give food to who you're looking at.");
	messageclient(%client,"","\c3/checkHunger \c6 - See your hunger level.");
	messageclient(%client,"","\c3/hunger\c6 - Turns hunger on/off. \c3(Admin Only)");
//	messageclient(%client,"","\c3/eatPeople\c6 - Turns Cannibalism on/off. \c3(Admin Only)");
//	messageclient(%client,"","\c3/hungerTickTime [Seconds]\c6 - Sets the hunger tick time. \c3(Admin Only)");
//	messageclient(%client,"","\c3/hungerEvent\c6 - Turns the incHunger event on/off. \c3(Admin Only)");
//	messageclient(%client,"","\c3/foodCost [Price]\c6 - Sets the food cost. \c3(Admin Only)");
}

function serverCmdHunger(%client, %temp)
{
	if(%client.isSuperAdmin || %client.isAdmin)
	{
		if($Hunger::On == 1)
		{
			$Hunger::On = 0;
			messageall("","\c6Hunger has been turned \c3off\c6.");
			cancel($hungerTick);
		}
		else
		{
			$Hunger::On = 1;
			messageall("","\c6Hunger has been turned \c3on\c6.");
			hungerTick();
		}
	}		
}
//
//function serverCmdEatPeople(%client)
//{
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		if($Hunger::EatPeeps == 1)
//		{
//			$Hunger::EatPeeps = 0;
//			messageall("","\c6Cannibalism has been turned \c3off\c6.");
//		}
//		else
//		{
//			$Hunger::EatPeeps = 1;
//			messageall("","\c6Cannibalism has been turned \c3on\c6.");
//		}
//	}		
//}
//
//function serverCmdHungerTickTime(%client, %temp)
//{
//	if(%temp <= 0)
//	{
//		%temp = 1;
//	}
//	
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		$Hunger::TickTime = %temp;
//		messageAll("","\c6The hunger tick time is now \c3" @ %temp @ "\c6 seconds.");
//	}		
//}
//
//function serverCmdHungerEvent(%client)
//{
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		if($Hunger::Event == 1)
//		{
//			$Hunger::Event = 0;
//			messageall("","\c6The incHunger event has been disabled.");
//		}
//		else
//		{
//			$Hunger::Event = 1;
//			messageall("","\c6The incHunger event has been enabled.");
//		}
//	}		
//}
//
//function serverCmdFoodCost(%client, %temp)
//{
//	if(%client.isSuperAdmin || %client.isAdmin)
//	{
//		$Hunger::FoodCost = %temp;
//		messageAll("","\c6The food cost is now \c3" @ $Hunger::FoodCost @ "\c6.");
//	}		
//}


//Events
registerOutputEvent(GameConnection, "incHunger", "int -90 100 10", 0);
registerOutputEvent(GameConnection, "addFood", "int 0 100 1", 0);
registerOutputEvent(fxDTSBrick, "ifPlayerHunger", "list Equals 1 NotEquals 2 Greater 3 Less 4 GreaterEquals 5 LessEquals 6\tint 0 100 50", 1);

function GameConnection::incHunger(%client, %amount)
{
	if(!$Hunger::On)
	{
		messageClient(%client, "", "\c7incHunger: \c6Hunger is currently disabled.");
		return;
	}
	
	if($Hunger::Event == 1)
	{
		%client.hunger = %client.hunger + %amount;
		
		if(%client.hunger > 100)
			%client.hunger = 100;
		if(%client.hunger < 0)
			%client.hunger = 0;
	}
	else
	{
		messageClient(%client,"","\c7incHunger: \c6This event is disabled.");
	}
}

function GameConnection::addFood(%client, %amount)
{
	if(!$Hunger::On)
	{
		messageClient(%client, "", "\c7addFood: \c6Hunger is currently disabled.");
		return;
	}
	
	if($Hunger::Event == 1)
	{
		$food[%client.bl_id] = $food[%client.bl_id] + %amount;
		messageClient(%client, "", "\c6You have \c3" @ $food[%client.bl_id] @ "\c6 food.");
	}
	else
	{
		messageClient(%client,"","\c7addFood: \c6This event is disabled.");
	}
}

//DATABLOCK

datablock fxDTSBrickData(brickFoodShopData : brick2x2fdata)
{
 uiName = "Food Shop Point";
 Category = "Special";
 subCategory = "Food Script";
};

//datablock fxDTSBrickData(brick3x3flatData)
//{
//	brickFile = "./3x3f.blb";
//	category = "Special";
//	subCategory = "Food Script";
//	uiName = "Corn Plant";
//	//iconName = "Add-Ons/Brick_Large_Cubes/4x Cube";
//};