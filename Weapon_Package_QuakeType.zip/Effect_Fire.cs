
datablock AudioProfile(afterburnSound)
{
   filename    = "./burn.wav";
   description = AudioClosest3d;
   preload = false;
};

	datablock ParticleData(afterburnParticle)
	{
		textureName				= "base/data/particles/cloud";
		dragCoefficient			= 0.0;
		gravityCoefficient		= -5.0;
		inheritedVelFactor		= 0.5;
		windCoefficient			= 0;
		constantAcceleration	= 3.0;
		lifetimeMS				= 400;
		lifetimeVarianceMS		= 200;
		spinSpeed				= 0;
		spinRandomMin			= -90.0;
		spinRandomMax			=  90.0;
		useInvAlpha				= false;
		
		colors[0]	= "1 1 1 0.1";
		colors[1]	= "1.0 1.0 0.3 0.3";
		colors[2]	= "0.6 0.0 0.0 0.0";
		
		sizes[0]	= 4.0;
		sizes[1]	= 1.7;
		sizes[2]	= 0.8;
		
		times[0]	= 0.0;
		times[1]	= 0.2;
		times[2]	= 1.0;
	};

	datablock ParticleEmitterData(afterburnEmitter)
	{
		ejectionPeriodMS	= 5;
		periodVarianceMS	= 4;
		ejectionVelocity	= 0;
		ejectionOffset		= 0.50;
		velocityVariance	= 0.0;
		thetaMin			= 89;
		thetaMax			= 90;
		phiReferenceVel		= 0;
		phiVariance			= 360;
		overrideAdvance		= false;
		
		particles = afterburnParticle;  
	};

datablock ExplosionData(afterburnExplosion)
{
   lifeTimeMS = 150;

   particleEmitter = afterburnEmitter;
   particleDensity = 10;
//   particleDensity = 0;
   particleRadius = 1.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   //impulse
   impulseRadius = 0;

   damageRadius = 0;
};

datablock ProjectileData(afterburnProjectile)
{
//   projectileShapeName = "./nailgrenadedeployed.dts";
   directDamageType  = $DamageType::TstickGrenadeDirect;
   radiusDamageType  = $DamageType::TstickGrenadeDirect;
   //particleEmitter     = lightspeedSparkEmitter;
   explosion           = afterburnExplosion;
   muzzleVelocity      = 0;
   velInheritFactor    = 0;
   explodeOnDeath = true;

   brickExplosionRadius = 1;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   explodeOnDeath = true;
   armingDelay         = 00; 
   lifetime            = 33;
   fadeDelay           = 33;
   bounceElasticity    = 0.6;
   bounceFriction      = 0.1;
   isBallistic         = true;
   gravityMod = 0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(afterburnImage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/empty.dts";
   emap = true;

   mountPoint = 3;
offset = "-0.2 0 1";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = afterburnItem;
   ammo = " ";
   projectile = afterburnProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = afterburngunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateScript[0]                  = "onZappedA";
	stateTransitionOnTimeout[0]       = "zappedA";

	stateName[1]                     = "zappedA";
	stateTimeoutValue[1]             = 0.25;
	stateScript[1]                  = "onzappedA";
	stateTransitionOnTimeout[1]       = "ZappedC";

	stateName[2]                     = "ZappedC";
	stateTimeoutValue[2]             = 0.25;
	stateScript[2]                  = "onzappedB";
	stateTransitionOnTimeout[2]       = "ZappedD";

	stateName[3]                     = "ZappedD";
	stateScript[3]                  = "onzappedB";
	stateTimeoutValue[3]             = 0.25;
	stateTransitionOnTimeout[3]       = "ZappedE";

	stateName[4]                     = "ZappedE";
	stateTimeoutValue[4]             = 0.25;
	stateScript[4]                  = "onzappedB";
	stateTransitionOnTimeout[4]       = "ZappedF";

	stateName[5]                     = "ZappedF";
	stateTimeoutValue[5]             = 0.25;
	stateScript[5]                  = "onzappedB";
	stateTransitionOnTimeout[5]       = "ZappedG";

	stateName[6]                     = "ZappedG";
	stateTimeoutValue[6]             = 0.25;
	stateScript[6]                  = "onzappedB";
	stateTransitionOnTimeout[6]       = "zappedA";
};
function afterburnImage::onMount(%this,%obj,%slot)
{
	%pos = %obj.getPosition();
	%obj.spawnExplosion(afterburnProjectile,"0.7 0.7 0.7"); //not sure of arguments :V
            serverPlay3D(afterburnBurnSound,%obj.getPosition());
	%obj.damage(%obj, %pos, 1, $DamageType::gun);
	%obj.playThread(2, plant);
	%obj.burnhits = 2;
}

function afterburnImage::onZappedA(%this,%obj,%slot)
{
	if (%obj.burnhits >= 0)
	{
	%obj.burnhits -= 1;
	%pos = %obj.getPosition();
	%obj.spawnExplosion(afterburnProjectile,"1 1 1"); //not sure of arguments :V
            serverPlay3D(afterburnBurnSound,%obj.getPosition());
	%obj.damage(%obj, %pos, 5, $DamageType::gun);
	%obj.playThread(2, plant);
	}
	else
	{
	%obj.burnhits = 0;
	%obj.unMountImage(2);
		if (%obj.getDatablock().isZombie)
		{
		%obj.mountImage(zombieGhostSmogImage,2);
		}
		if (%obj.getDatablock().isZombieBoss)
		{
		%obj.mountImage(zombieGhostBossSmogImage,2);
		}
	}
}
function afterburnImage::onZappedB(%this,%obj,%slot)
{
	%pos = %obj.getPosition();
	%obj.spawnExplosion(afterburnProjectile,"0.7 0.7 0.7"); //not sure of arguments :V
            serverPlay3D(afterburnBurnSound,%obj.getPosition());
	%obj.damage(%obj, %pos, 1, $DamageType::gun);
	%obj.playThread(2, plant);
}

function afterburnImage::onDone(%this,%obj,%slot)
{
	%pos = %obj.getPosition();
	%obj.spawnExplosion(afterburnProjectile,"0.7 0.7 0.7"); //not sure of arguments :V
            serverPlay3D(afterburnBurnSound,%obj.getPosition());
	%obj.damage(%obj, %pos, 6, $DamageType::gun);
	%obj.playThread(2, plant);
}
