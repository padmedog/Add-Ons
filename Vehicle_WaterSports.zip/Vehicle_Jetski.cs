datablock TSShapeConstructor(JetskiDts)
{
	baseShape  = "./Jetski.dts";
	sequence0  = "./Jets_root.dsq root";

	sequence1  = "./Jets_root.dsq run";
	sequence2  = "./Jets_root.dsq walk";
	sequence3  = "./Jets_root.dsq back";
	sequence4  = "./Jets_root.dsq side";

	sequence5  = "./Jets_root.dsq crouch";
	sequence6  = "./Jets_root.dsq crouchRun";
	sequence7  = "./Jets_root.dsq crouchBack";
	sequence8  = "./Jets_root.dsq crouchSide";

	sequence9  = "./Jets_root.dsq look";
	sequence10 = "./Jets_root.dsq headside";
	sequence11 = "./Jets_root.dsq headUp";

	sequence12 = "./Jets_root.dsq jump";
	sequence13 = "./Jets_root.dsq standjump";
	sequence14 = "./Jets_root.dsq fall";
	sequence15 = "./Jets_root.dsq land";

	sequence16 = "./Jets_root.dsq armAttack";
	sequence17 = "./Jets_root.dsq armReadyLeft";
	sequence18 = "./Jets_root.dsq armReadyRight";
	sequence19 = "./Jets_root.dsq armReadyBoth";
	sequence20 = "./Jets_root.dsq spearready";  
	sequence21 = "./Jets_root.dsq spearThrow";

	sequence22 = "./Jets_root.dsq talk";  

	sequence23 = "./Jets_root.dsq death1"; 
	
	sequence24 = "./Jets_root.dsq shiftUp";
	sequence25 = "./Jets_root.dsq shiftDown";
	sequence26 = "./Jets_root.dsq shiftAway";
	sequence27 = "./Jets_root.dsq shiftTo";
	sequence28 = "./Jets_root.dsq shiftLeft";
	sequence29 = "./Jets_root.dsq shiftRight";
	sequence30 = "./Jets_root.dsq rotCW";
	sequence31 = "./Jets_root.dsq rotCCW";

	sequence32 = "./Jets_root.dsq undo";
	sequence33 = "./Jets_root.dsq plant";

	sequence34 = "./Jets_root.dsq sit";

	sequence35 = "./Jets_root.dsq wrench";

   sequence36 = "./Jets_root.dsq activate";
   sequence37 = "./Jets_root.dsq activate2";

   sequence38 = "./Jets_root.dsq leftrecoil";
};    

datablock ParticleEmitterData(JetskiFoamEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 80;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlayerFoamParticle";

   useEmitterColors = true;

   uiName = "";
};

datablock PlayerData(JetskiArmor : PlayerStandardArmor)
{
	cameraVerticalOffset = 3;
	shapefile = "./Jetski.dts";
	canJet = 0;
	mass = 50;
   drag = 0.015;
   density = 0.6;
   runSurfaceAngle = 1;
   jumpSurfaceAngle = 1;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxForwardCrouchSpeed = 0;
   maxSideSpeed = 0;
   maxSideCrouchSpeed = 0;
   maxStepHeight = 0;
   maxUnderwaterSideSpeed = 0;
    maxUnderwaterForwardSpeed = 80;
    maxUnderwaterBackwardSpeed = 2;

	uiName = "Jetski";
	showEnergyBar = false;
	
   jumpForce = 0;
   jumpEnergyDrain = 10000;
   minJumpEnergy = 10000;
   jumpDelay = 127;
   minJumpSpeed = 0;
   maxJumpSpeed = 0;
	
	rideable = true;
	canRide = false;
	paintable = true;
	
   boundingBox			= vectorScale("2.5 2.5 1", 4); 
   crouchBoundingBox	= vectorScale("2.5 2.5 1", 4);
	
   lookUpLimit = 0.65;
	lookDownLimit = 0.45;
	
   numMountPoints = 2;
   mountThread[0] = "sit";
   mountThread[1] = "sit";

   splashEmitter[0] = JetskiFoamEmitter;
   splashEmitter[1] = JetskiFoamEmitter;
   splashEmitter[2] = JetskiFoamEmitter;
   
   upMaxSpeed = 1;
   upResistSpeed = 1;
   upResistFactor = 1;
   maxdamage = 300;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   useCustomPainEffects = true;
   PainHighImage = "";
   PainMidImage  = "";
   PainLowImage  = "";
   painSound     = "";
   deathSound    = "";
};
