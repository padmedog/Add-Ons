
datablock AudioProfile(butterflyknifeactivateSound)
{
   filename    = "./activate.wav";
   description = AudioClose3d;
   preload = true;
};


//butterflyknife trail





//projectile
AddDamageType("butterflyknifeDirect",   '<bitmap:add-ons/Weapon_butterflyknife/CI_butterflyknife> %1',       '%2 <bitmap:add-ons/Weapon_butterflyknife/CI_butterflyknife> %1',1,1);

datablock ProjectileData(butterflyknifeProjectile)
{

   directDamage        = 30;
   directDamageType  = $DamageType::butterflyknifeDirect;

   explosion           = swordExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};
datablock ProjectileData(butterflyknifekillProjectile)
{
   backstab		= 180;
   directDamage        = 100;
   directDamageType  = $DamageType::butterflyknifeDirect;
   radiusDamageType  = $DamageType::butterflyknifeRadius;
   explosion           = swordExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(butterflyknifeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./bknife2.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Butterfly Knife";
	iconName = "./knife";
	doColorShift = false;
	colorShiftColor = "0.400 0.196 0 1.000";

	 // Dynamic properties defined by the scripts
	image = butterflyknifeImage;
	canDrop = true;
};

//function butterflyknife::onUse(%this,%user)
//{
//	//mount the image in the right hand slot
//	%user.mountimage(%this.image, $RightHandSlot);
//}

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(butterflyknifeImage)
{
   // Basic Item properties
   shapeFile = "./bknife2.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = butterflyknifeItem;
   ammo = " ";
   projectile = butterflyknifekillProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.5;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "activate";
	stateSound[0]					= ButterflyknifeactivateSound;

	stateName[1]			= "Ready";
		stateSequence[1]		= "ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]	= true;
	
	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.7;
	stateScript[2]			= "oncharge";
	stateSequence[2]		= "ready";
	stateWaitForTimeout[2]		= false;//f
	stateTransitionOnTriggerUp[2]	= "AbortChargefire";
	stateAllowImageChange[2]        = false;
	
	stateName[3]			= "AbortChargefire";
	stateTransitionOnTimeout[3]	= "stopfire";
	//stateTransitionOntriggerup[3]	= "stopfire";
	stateTimeoutValue[3]		= 0.2;
	stateFire[3]			= true;
	stateSequence[3]		= "ready";
	stateScript[3]			= "onFiretwo";
	stateWaitForTimeout[3]		= true;
	stateAllowImageChange[3]	= true;
	stateSound[3]				= ButterflyknifeFireSound;
	
	
	stateName[4]                    = "StopFire";
	stateTransitionOnTimeout[4]     = "Ready";
	stateTimeoutValue[4]            = 0.2;
	stateAllowImageChange[4]        = false;
	stateWaitForTimeout[4]		= true;

	stateScript[4]                  = "onStopFire";

	
	stateName[5]			= "Armed";
	stateTransitionOnTriggerUp[5]	= "Fire";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Fire";
	stateTransitionOnTimeout[6]	= "Ready";
	stateTimeoutValue[6]		= 0.2;
	stateFire[6]			= true;
	stateSequence[6]		= "ready";
	stateScript[6]			= "onFire";
	stateWaitForTimeout[6]		= true;
	stateAllowImageChange[6]	= false;
	stateSound[6]				= ButterflyknifeFireSound;
};

function butterflyknifeImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
}
function butterflyknifeImage::onfiretwo(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
	return;
}
function butterflyknifeImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}



function butterflyknifeImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, spearThrow);
	Parent::onFire(%this, %obj, %slot);
}
function butterflyknifeImage::onFiretwo(%this,%obj,%slot)
{

	

	%projectile = butterflyknifeprojectile;
	%spread = 0.00001;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
