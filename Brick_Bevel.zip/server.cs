datablock fxDTSBrickData (brick1x1fBevelData)
{
	brickFile = "./1x1fBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x1F Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x1FBevel";
};

datablock fxDTSBrickData (brick1x1ffBevelData)
{
	brickFile = "./1x1ffBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x1FF Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x1FFBevel";
};

datablock fxDTSBrickData (brick1x2fBevelData)
{
	brickFile = "./1x2fBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x2F Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x2FBevel";
};

datablock fxDTSBrickData (brick1x2ffBevelData)
{
	brickFile = "./1x2ffBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x2FF Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x2FFBevel";
};

datablock fxDTSBrickData (brick1x1BevelData)
{
	brickFile = "./1x1Bevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x1 Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x1Bevel";
};

datablock fxDTSBrickData (brick1x1x2BevelData)
{
	brickFile = "./1x1x2Bevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x1x2 Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x1x2Bevel";
};

datablock fxDTSBrickData (brick1x2BevelData)
{
	brickFile = "./1x2Bevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "1x2 Beveled";
	iconName = "Add-Ons/Brick_Bevel/1x2Bevel";
};

datablock fxDTSBrickData (brick2x2fBevelData)
{
	brickFile = "./2x2fBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "2x2F Beveled";
	iconName = "Add-Ons/Brick_Bevel/2x2FBevel";
};

datablock fxDTSBrickData (brick2x4fBevelData)
{
	brickFile = "./2x4fBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "2x4F Beveled";
	iconName = "Add-Ons/Brick_Bevel/2x4FBevel";
};

datablock fxDTSBrickData (brick2x4ffBevelData)
{
	brickFile = "./2x4ffBevel.blb";
	canCover = true;
	category = "Special";
	subCategory = "Beveled";
	uiName = "2x4FF Beveled";
	iconName = "Add-Ons/Brick_Bevel/2x4FFBevel";
};