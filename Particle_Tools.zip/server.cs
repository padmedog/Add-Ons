//give the default tool particle emitters uinames so we can use them on bricks

wandExplosionEmitter.uiName = "Wand Explosion";
WandEmitterA.uiName = "Wand Idle";
WandEmitterB.uiName = "Wand Attack";

AdminWandExplosionEmitter.uiName = "Destructo Wand Explosion";
AdminWandEmitterA.uiName = "Destructo Wand Idle";
AdminWandEmitterB.uiName = "Destructo Wand Attack";

wrenchSparkEmitter.uiName = "Wrench Oil";
wrenchExplosionEmitter.uiName = "Wrench Nut";

hammerSparkEmitter.uiName = "Hammer Spark";
hammerExplosionEmitter.uiName = "Hammer Smoke";

printGunEmitter.uiName = "Print Gun";
//printGunEmitter.useEmitterColors = true;

brickTrailEmitter.uiName = "Brick Trail";
brickDeployExplosionEmitter.uiName = "Brick Explosion";