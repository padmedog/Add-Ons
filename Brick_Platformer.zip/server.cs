exec("./grinding.cs");
exec("./bumper.cs");
exec("./booster.cs");

datablock AudioProfile(MessageBlockSound)
{
	description = "AudioClosest3D";
	fileName = "./resources/msgblock.wav";
	preload = false;
};