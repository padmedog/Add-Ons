//########## Humvee

//### Sound

datablock AudioProfile(gc_HumveeFireSound)
{
  filename = "./humveefire.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_bulletBySound)
{
  filename = "./bulletby.wav";
  description = AudioClosestLooping3d;
  preload = true;
};

datablock AudioProfile(gc_bulletHit1Sound)
{
  filename = "./bulletImpact1.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_beepoffSound)
{
  filename = "./beepoff.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_AvengerFireSound)
{
  filename = "./avengerfire.wav";
  description = AudioDefault3d;
  preload = true;
};

datablock AudioProfile(gc_AvengerLoopSound)
{
  filename = "./avengerloop.wav";
  description = AudioCloseLooping3d;
  preload = true;
};

datablock AudioProfile(gc_ExplosionSound)
{
  filename = "./explosion.wav";
  description = AudioDefault3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_tireParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.4 0.4 0.4 0.3";
  colors[1] = "0.2 0.2 0.2 0";
  sizes[0] = 2;
  sizes[1] = 6;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_tireEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 25;
  ejectionVelocity = 2;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_tireParticle";
  useEmitterColors = true;
};

datablock ParticleData(gc_vehicleDamageParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = -2;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0 0 0 0";
  colors[1] = "0 0 0 0.5";
  colors[2] = "0 0 0 0";
  sizes[0] = 3;
  sizes[1] = 4;
  sizes[2] = 6;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_vehicleDamageEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 25;
  ejectionVelocity = 2;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_vehicleDamageParticle";
  useEmitterColors = true;
};

datablock ParticleData(gc_bulletDebrisExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/chunk";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 0.2;
  sizes[1] = 0.2;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_bulletDebrisExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 16;
  velocityVariance = 8;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 30;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_bulletDebrisExplosionParticle";
};

datablock ParticleData(gc_bulletExplosionSmokeParticle)
{
  dragCoefficient = 6;
  gravityCoefficient = 0.2;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1400;
  lifetimeVarianceMS = 200;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.4 0.4 0.4 1";
  colors[1] = "0.2 0.2 0.2 0.2";
  colors[2] = "0 0 0 0";
  sizes[0] = 0.5;
  sizes[1] = 0.6;
  sizes[2] = 5;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_bulletExplosionSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 8;
  periodVarianceMS = 0;
  ejectionVelocity = 9;
  velocityVariance = 8;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 30;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_bulletExplosionSmokeParticle";
};

datablock ExplosionData(gc_mgBulletExplosion)
{
  lifeTimeMS = 50;
  emitter[0] = gc_bulletExplosionSmokeEmitter;
  emitter[1] = gc_bulletDebrisExplosionEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "1 1 1";
  camShakeDuration = 0.5;
  camShakeRadius = 1;
  soundProfile = gc_bulletHit1Sound;
};

datablock ParticleData(gc_HumveeFlashParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 50;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  spinSpeed = 50;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "1 0.5 0 1";
  colors[1] = "1 0.8 0.6 1";
  colors[2] = "1 0.3 0.1 0";
  sizes[0] = 0.1;
  sizes[1] = 1.5;
  sizes[2] = 0;
  times[9] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_HumveeFlashEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 100;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 10;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_HumveeFlashParticle";
};

datablock ShapeBaseImageData(gc_HumveeTurretFireImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 1;

  stateName[0] = "FireA";
  stateTransitionOnTimeout[0] = "Done";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 0.05;
  stateEmitter[0] = gc_HumveeFlashEmitter;
  stateEmitterTime[0] = 0.05;

  stateName[2] = "Done";
  stateScript[2] = "onDone";
};

function gc_HumveeTurretFireImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

datablock ParticleData(gc_StingerTrailParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 2000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.8 0.8 0.8 1";
  colors[1] = "0.8 0.8 0.8 0.5";
  colors[2] = "0.8 0.8 0.8 0";
  sizes[0] = 0.5;
  sizes[1] = 1;
  sizes[2] = 3;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_StingerTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 6;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_StingerTrailParticle";
};

datablock ParticleData(gc_StingerExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/star1";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 12;
  sizes[1] = 6;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_StingerExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 1;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_StingerExplosionParticle";
};

datablock ParticleData(gc_StingerSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 6;
  sizes[1] = 12;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_StingerSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 1;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_StingerSmokeParticle";
};

datablock ExplosionData(gc_StingerExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_StingerExplosionEmitter;
  emitter[1] = gc_StingerSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 10;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 3;
  radiusDamage = 100;
  impulseRadius = 6;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 12;
};

datablock ParticleData(gc_HumveeAmbulanceParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = -0.2;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 0;
  textureName = "./cross";
  spinSpeed = 0;
  colors[0] = "1 0 0 0";
  colors[1] = "0 1 0 1";
  colors[2] = "1 0 0 0";
  sizes[0] = 0.5;
  sizes[1] = 1;
  sizes[2] = 1;
  times[0] = 0;
  times[1] = 0.5;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_HumveeAmbulanceEmitter)
{
  uiName = "";
  ejectionPeriodMS = 1;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  ejectionOffset = 10;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_HumveeAmbulanceParticle";
};

datablock ShapeBaseImageData(gc_HumveeAmbulanceImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 2;

  stateName[0] = "FireA";
  stateTransitionOnTimeout[0] = "FireA";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 1000;
  stateEmitter[0] = gc_HumveeAmbulanceEmitter;
  stateEmitterTime[0] = 1000;
};

//### Projectile

AddDamageType("gc_Humvee",'<color:ff0000>[Humvee Machinegun] %1','%2 <color:ff0000>[Humvee Machinegun] %1',1,1);

datablock ProjectileData(gc_HumveeTurretProjectile)
{
  uiName = "";
  projectileShapeName = "";
  directDamage = 25;
  directDamageType = $DamageType::gc_Humvee;
  radiusDamageType = $DamageType::gc_Humvee;
  brickExplosionRadius = 0;
  brickExplosionImpact = true;
  brickExplosionForce = 25;
  brickExplosionMaxVolume = 8;
  brickExplosionMaxVolumeFloating = 8;
  impactImpulse = 75;
  explosion = gc_mgBulletExplosion;
  muzzleVelocity = 150;
  verInheritFactor = 1;
  lifetime = 4000;
  fadeDelay = 4000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 0.25;
  sound = gc_bulletBySound;
};

AddDamageType("gc_Avenger",'<color:ff0000>[Humvee Avenger] %1','%2 <color:ff0000>[Humvee Avenger] %1',1,1);

datablock ProjectileData(gc_StingerProjectile)
{
  uiName = "";
  projectileShapeName = "./stingermissile.dts";
  directDamage = 300;
  directDamageType = $DamageType::gc_Avenger;
  radiusDamageType = $DamageType::gc_Avenger;
  brickExplosionRadius = 3;
  brickExplosionImpact = true;
  brickExplosionForce = 25;
  brickExplosionMaxVolume = 50;
  brickExplosionMaxVolumeFloating = 50;
  impactImpulse = 300;
  explosion = gc_StingerExplosion;
  particleEmitter = gc_StingerTrailEmitter;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 5000;
  fadeDelay = 5000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  sound = gc_AvengerLoopSound;
  explodeOnDeath = true;
  turningLength = 12;
  turningDelay = 1;
};

//### Turrets

datablock TSShapeConstructor(humveeturretDts)
{
  baseShape = "./humveeturret.dts";
  sequence0 = "./root.dsq root";
  sequence1 = "./look.dsq look";
  sequence2 = "./fire.dsq fire";
};

datablock TSShapeConstructor(humveeavengerturretDts)
{
  baseShape = "./humveeavengerturret.dts";
  sequence0 = "./avenger_root.dsq root";
  sequence1 = "./avenger_look.dsq look";
};

datablock PlayerData(gc_HumveeTurretPlayer)
{
  renderFirstPerson = true;
  emap = false;
  className = Armor;
  shapeFile = "./humveeturret.dts";
  cameraMaxDist = 4;
  cameraTilt = 0.261;
  cameraVerticalOffset = 2.3;
  cameraDefaultFov = 90;
  cameraMinFov = 5;
  cameraMaxFov = 120;
  aiAvoidThis = true;
  minLookAngle = -1.5708;
  maxLookAngle = 0.5;
  maxFreelookAngle = 3;
  mass = 200000;
  drag = 1;
  density = 5;
  maxDamage = 300;
  maxEnergy = 10;
  repairRate = 0.33;
  rechargeRate = 0.4;
  runForce = 1000;
  runEnergyDrain = 0;
  minRunEnergy = 0;
  maxForwardSpeed = 0;
  maxBackwardSpeed = 0;
  maxSideSpeed = 0;
  maxForwardCrouchSpeed = 0;
  maxBackwardCrouchSpeed = 0;
  maxSideCrouchSpeed = 0;
  maxUnderwaterForwardSpeed = 0;
  maxUnderwaterBackwardSpeed = 0;
  maxUnderwaterSideSpeed = 0;
  jumpForce = 0;
  jumpEnergyDrain = 0;
  minJumpEnergy = 0;
  jumpDelay = 0;
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
  minImpactSpeed = 250;
  speedDamageScale = 3.8;
  boundingBox = "10 10 2.5";
  crouchBoundingBox = "10 10 2.5";
  pickupRadius = 0.75;
  jetEmitter = "";
  jetGroundEmitter = "";
  jetGroundDistance = 4;
  splash = PlayerSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 0.1;
  splashEmitter[0] = PlayerFoamDropletsEmitter;
  splashEmitter[1] = PlayerFoamEmitter;
  splashEmitter[2] = PlayerBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  runSurfaceAngle = 85;
  jumpSurfaceAngle = 86;
  minJumpSpeed = 20;
  maxJumpSpeed = 30;
  horizMaxSpeed = 68;
  horizResistSpeed = 33;
  horizResistFactor = 0.35;
  upMaxSpeed = 80;
  upResistSpeed = 25;
  upResistFactor = 0.3;
  footstepSplashHeight = 0.35;
  JumpSound = "";
  groundImpactMinSpeed = 10;
  groundImpactShakeFreq = "4 4 4";
  groundImpactShakeAmp = "1 1 1";
  groundImpactShakeDuration = 0.8;
  groundImpactShakeFalloff = 10;
  maxItems = 10;
  maxWeapons = 5;
  maxTools = 5;
  uiName = "";
  rideable = true;
  lookUpLimit = 0.6;
  lookDownLimit = 0.4;
  canRide = false;
  showEnergyBar = false;
  paintable = true;
  brickImage = horseBrickImage;
  numMountPoints = 1;
  mountThread[0] = "root";
  protectPassengersBurn = true;
  protectPassengersRadius = true;
  protectPassengersDirect = false;
  useCustomPainEffects = true;
  PainHighImage = "";
  PainMidImage = "";
  PainLowImage = "";
  painSound = "";
  deathSound = "";
};

datablock PlayerData(gc_HumveeAvengerTurretPlayer : gc_HumveeTurretPlayer)
{
  uiName = "Avenger Turret";
  renderFirstPerson = true;
  emap = false;
  className = Armor;
  shapeFile = "./humveeavengerturret.dts";
  mountThread[0] = "sit";
  lookUpLimit = 0.5;
  lookDownLimit = 0.5;
  protectPassengersDirect = true;
  boundingBox = "10 10 8";
  crouchBoundingBox = "10 10 8";
};

//### Vehicle

datablock WheeledVehicleTire(gc_HumveeTire)
{
  shapeFile = "./tire.dts";
  mass = 5;
  radius = 1;
  staticFriction = 5;
  kineticFriction = 5;
  restitution = 0.5;
  lateralForce = 18000;
  lateralDamping = 4000;
  lateralRelaxation = 0.01;
  longitudinalForce = 14000;
  longitudinalDamping = 2000;
  longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleSpring(gc_HumveeSpring)
{
  length = 0.3;
  force = 5000;
  damping = 500;
  antiSwayForce = 20;
};

datablock DebrisData(gc_HumveeTireDebris)
{
  shapeFile = "./tire.dts";
  lifetime = 2;
  minSpinSpeed = -400;
  maxSpinSpeed = 200;
  elasticity = 0.5;
  friction = 0.2;
  numBounces = 3;
  staticOnMaxBounce = true;
  snapOnMaxBounce = false;
  fade = true;
  gravModifier = 2;
};

datablock ExplosionData(gc_HumveeExplosion : vehicleExplosion)
{
  debris = gc_HumveeTireDebris;
  debrisNum = 4;
  debrisNumVariance = 0;
  debrisPhiMin = 0;
  debrisPhiMax = 360;
  debrisThetaMin = 40;
  debrisThetaMax = 85;
  debrisVelocity = 14;
  debrisVelocityVariance = 3;
};

datablock ProjectileData(gc_HumveeExplosionProjectile : vehicleExplosionProjectile)
{
  uiName = "";
  explosion = gc_HumveeExplosion;
};

datablock WheeledVehicleData(gc_HumveeVehicle)
{
  uiName = "Humvee - Standard";
  category = "Vehicles";
  displayName = "";
  shapeFile = "./humvee.dts";
  emap = true;
  minMountDist = 3;
  numMountPoints = 4;
  mountThread[0] = "sit";
  mountThread[1] = "sit";
  mountThread[2] = "sit";
  mountThread[3] = "sit";
  maxDamage = 300;
  destroyedLevel = 300;
  speedDamageScale = 1.04;
  collDamageThresholdVel = 20;
  collDamageMultiplier = 0.02;
  massCenter = "0 0 -1";
  maxSteeringAngle = 0.9;
  integration = 4;
  tireEmitter = gc_tireEmitter;
  cameraRoll = false;
  cameraMaxDist = 13;
  cameraOffset = 6;
  cameraLag = 0.0;
  cameraDecay = 0.75;
  cameraTilt = 0.4;
  collisionTol = 0.1;
  contactTol = 0.1;
  useEyePoint = false;
  defaultTire = gc_HumveeTire;
  defaultSpring = gc_HumveeSpring;
  numWheels = 4;
  mass = 300;
  density = 5;
  drag = 1.6;
  bodyFriction = 0.6;
  bodyRestitution = 0.6;
  minImpactSpeed = 10;
  softImpactSpeed = 10;
  hardImpactSpeed = 15;
  groundImpactMinSpeed = 10;
  engineTorque = 4000;
  engineBrake = 500;
  brakeTorque = 3000;
  maxWheelSpeed = 40;
  rollForce = 900;
  yawForce = 600;
  pitchForce = 1000;
  rotationalDrag = 0.2;
  maxEnergy = 100;
  jetForce = 3000;
  minJetEnergy = 30;
  jetEnergyDrain = 2;
  splash = vehicleSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 1.4;
  splashEmitter[0] = vehicleFoamDropletsEmitter;
  splashEmitter[1] = vehicleFoamEmitter;
  splashEmitter[2] = vehicleBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  softImpactSound = slowImpactSound;
  hardImpactSound = fastImpactSound;
  justcollided = 0;
  rideable = true;
  lookUpLimit = 0.55;
  lookDownLimit = 0.45;
  paintable = true;
  damageEmitter[0] = gc_vehicleDamageEmitter;
  damageEmitterOffset[0] = "0 3 0";
  damageLevelTolerance[0] = 0.5;
  damageEmitter[1] = VehicleBurnEmitter;
  damageEmitterOffset[1] = "0 3 0";
  damageLevelTolerance[1] = 0.9;
  numDmgEmitterAreas = 1;
  initialExplosionProjectile = gc_HumveeExplosionProjectile;
  initialExplosionOffset = 0;
  burnTime = 4000;
  finalExplosionProjectile = vehicleFinalExplosionProjectile;
  finalExplosionOffset = 0;
  minRunOverSpeed = 4;
  runOverDamageScale = 25;
  runOverPushScale = 1.2;
  protectPassengersBurn = true;
  protectPassengersRadius = true;
  protectPassengersDirect = true;

  dismountOffset[0] = "-3 0.5 0";
  dismountOffset[1] = "3 0.5 0";
  dismountOffset[2] = "-3 -1 0";
  dismountOffset[3] = "3 -1 0";
};

datablock WheeledVehicleData(gc_HumveeMGVehicle : gc_HumveeVehicle)
{
  uiName = "Humvee - MG";
  shapeFile = "./humveemg.dts";
  numMountPoints = 3;
  mountThread[0] = "sit";
  mountThread[1] = "sit";
  mountThread[2] = "root";
};

datablock WheeledVehicleData(gc_HumveePickupVehicle : gc_HumveeVehicle)
{
  uiName = "Humvee - Pickup";
  shapeFile = "./humveepickup.dts";
  numMountPoints = 6;
  mountThread[0] = "sit";
  mountThread[1] = "sit";
  mountThread[2] = "sit";
  mountThread[3] = "sit";
  mountThread[4] = "sit";
  mountThread[5] = "sit";

  dismountOffset[4] = "-3 -3 0";
  dismountOffset[5] = "3 -3 0";
};

datablock WheeledVehicleData(gc_HumveeAvengerVehicle : gc_HumveeVehicle)
{
  uiName = "Humvee - Avenger";
  shapeFile = "./humveeavenger.dts";
  numMountPoints = 3;
  mountThread[0] = "sit";
  mountThread[1] = "sit";
  mountThread[2] = "sit";
  lookDownLimit = 0.25;

  dismountOffset[2] = "-3 -2 0";

};

datablock WheeledVehicleData(gc_HumveeAmbulanceVehicle : gc_HumveeVehicle)
{
  uiName = "Humvee - Ambulance";
  shapeFile = "./humveeambulance.dts";
  numMountPoints = 2;
  mountThread[0] = "sit";
  mountThread[1] = "sit";
};

//### Functions

function gc_HumveeMGVehicle::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  %t = new AIPlayer() { dataBlock = gc_HumveeTurretPlayer; };
  MissionCleanup.add(%t);
  %obj.mountObject(%t,2);
  %obj.turret = %t;
}

function gc_HumveeMGVehicle::onRemove(%this,%obj) { if(isObject(%obj.turret)) %obj.turret.delete(); }

function gc_HumveeAvengerVehicle::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  %obj.lastShotTime = getSimTime() - 5000;
  %obj.barrel = 1;
  %t = new AIPlayer() { dataBlock = gc_HumveeAvengerTurretPlayer; };
  MissionCleanup.add(%t);
  %obj.mountObject(%t,2);
  %obj.turret = %t;
}

function gc_HumveeAvengerVehicle::onRemove(%this,%obj) { if(isObject(%obj.turret)) %obj.turret.delete(); }

function gc_HumveeAmbulanceVehicle::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  gc_HumveeAmbulanceLoop(%obj);
}

function gc_HumveeAmbulanceLoop(%obj)
{
  if(!isObject(%obj)) return;
  schedule(1000,0,"gc_HumveeAmbulanceLoop",%obj);
  %speed = mCeil(VectorLen(%obj.getVelocity()));
  if(%speed > 1 || %obj.getMountedObjectCount() < 1)
  {
    %obj.unMountImage(1);
  }
  else
  {
    %obj.mountImage(gc_HumveeAmbulanceImage,1);
    InitContainerRadiusSearch(%obj.getPosition(),10,$TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
      if(!isObject(%target)) continue;
      if(%target.getDamageLevel() > 0)
      {
        cancel(%target.gc_bleed);
        %target.setDamageFlash(0);
        %target.setDamageLevel(%target.getDamageLevel() - 5);
      }
    }
  }
}

package gc_HumveePackage
{
  function Player::Burn(%obj,%time)
  {
    if(%obj.dataBlock $= gc_HumveeTurretPlayer) return;
    if(%obj.dataBlock $= gc_HumveeAvengerTurretPlayer) return;
    parent::Burn(%obj,%time);
  }
  function ShapeBase::setNodeColor(%obj,%node,%color)
  {
    parent::setnodecolor(%obj,%node,%color);
    if(isObject(%obj.turret)) %obj.turret.setNodeColor("ALL",%color);
  }
  function gc_HumveeMGVehicle::Damage(%this,%obj,%source,%pos,%amout,%type)
  {
    if((%obj.getDamageLevel()+%amout) >= %this.maxDamage)
    {
      if(%obj.destroyed) return;
      for(%i=0;%i<%this.numWheels;%i++) { %obj.setWheelTire(%i,emptyTire); }
      %obj.setNodeColor("ALL","0 0 0 1");
      if(isObject(%obj.turret)) %obj.turret.delete();
      %p = new Projectile()
      {
        dataBlock = gc_HumveeExplosionProjectile;
        initialPosition = vectorAdd(%obj.getPosition(),"0 0" SPC %this.initialExplosionOffset);
        initialVelocity = "0 0 1";
        client = %obj.lastDamageClient;
        sourceClient = %obj.lastDamageClient;
      };
      MissionCleanup.add(%p);
      if(%obj.destroyed) return;
      %obj.setDamageLevel(%this.maxDamage);
      %obj.destroyed = 1;
      %obj.schedule(%this.burnTime,"finalExplosion");
      if(isObject(%obj.spawnBrick.client.minigame)) %respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
      %obj.spawnBrick.schedule(%respawn,"spawnVehicle");
    }
    else
      parent::Damage(%this,%obj,%source,%pos,%amout,%type);
  }
  function gc_HumveeAvengerVehicle::Damage(%this,%obj,%source,%pos,%amout,%type)
  {
    if((%obj.getDamageLevel()+%amout) >= %this.maxDamage)
    {
      if(%obj.destroyed) return;
      for(%i=0;%i<%this.numWheels;%i++) { %obj.setWheelTire(%i,emptyTire); }
      %obj.setNodeColor("ALL","0 0 0 1");
      if(isObject(%obj.turret)) %obj.turret.delete();
      %p = new Projectile()
      {
        dataBlock = gc_HumveeExplosionProjectile;
        initialPosition = vectorAdd(%obj.getPosition(),"0 0" SPC %this.initialExplosionOffset);
        initialVelocity = "0 0 1";
        client = %obj.lastDamageClient;
        sourceClient = %obj.lastDamageClient;
      };
      MissionCleanup.add(%p);
      if(%obj.destroyed) return;
      %obj.setDamageLevel(%this.maxDamage);
      %obj.destroyed = 1;
      %obj.schedule(%this.burnTime,"finalExplosion");
      if(isObject(%obj.spawnBrick.client.minigame)) %respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
      %obj.spawnBrick.schedule(%respawn,"spawnVehicle");
    }
    else
      parent::Damage(%this,%obj,%source,%pos,%amout,%type);
  }
  function Player::emote(%obj,%emote)
  {
    if(%obj.dataBlock $= gc_HumveeTurretPlayer) return;
    if(%obj.dataBlock $= gc_HumveeAvengerTurretPlayer) return;
    parent::emote(%obj,%emote);
  }
  function gc_HumveeTurretPlayer::onDisabled(%this,%obj,%state)
  {
    %tank = %obj.getObjectMount();
    if(isObject(%tank)) %pos = vectorAdd(%obj.getObjectMount().getPosition(),"0 0" SPC %obj.getObjectMount().dataBlock.initialExplosionOffset);
    else
      %pos = %obj.getHackPosition();
    %p = new Projectile()
    {
      dataBlock = vehicleFinalExplosionProjectile;
      initialPosition = %pos;
      initialVelocity = "0 0 1";
      client = %obj.lastDamageClient;
      sourceClient = %obj.lastDamageClient;
    };
    MissionCleanup.add(%p);
    %obj.schedule(10,"delete");
    if(isObject(%tank))
    {
      %player = %obj.getMountedObject(0);
      if(isObject(%player)) %obj.getObjectMount().schedule(10,"mountObject",%player,2);
    }
    parent::onDisabled(%this,%obj,%state);
  }
  function gc_HumveeAvengerTurretPlayer::onDisabled(%this,%obj,%state)
  {
    %tank = %obj.getObjectMount();
    if(isObject(%tank)) %pos = vectorAdd(%obj.getObjectMount().getPosition(),"0 0" SPC %obj.getObjectMount().dataBlock.initialExplosionOffset);
    else
      %pos = %obj.getHackPosition();
    %p = new Projectile()
    {
      dataBlock = vehicleFinalExplosionProjectile;
      initialPosition = %pos;
      initialVelocity = "0 0 1";
      client = %obj.lastDamageClient;
      sourceClient = %obj.lastDamageClient;
    };
    MissionCleanup.add(%p);
    %obj.schedule(10,"delete");
    if(isObject(%tank))
    {
      %player = %obj.getMountedObject(0);
      if(isObject(%player)) %obj.getObjectMount().schedule(10,"mountObject",%player,2);
    }
    parent::onDisabled(%this,%obj,%state);
  }
  function armor::onMount(%this,%obj,%col,%slot)
  {
    parent::onMount(%this,%obj,%col,%slot);
    if(isObject(%obj.client))
    {
      if(%col.getDataBlock() == gc_HumveeTurretPlayer.getId()) ServerCmdUnUseTool(%obj.client);
      if(%col.getDataBlock() == gc_HumveeAvengerTurretPlayer.getId()) ServerCmdUnUseTool(%obj.client);
    }
  }
  function armor::onTrigger(%this,%obj,%triggerNum,%val)
  {
    %mount = %obj.getObjectMount();
    if(isObject(%mount))
    {
      if(!%val) cancel(%obj.gc_HumveeTurretLoop);
      if(%mount.getDataBlock() == gc_HumveeTurretPlayer.getId() && %triggerNum == 0 && %val)
      %obj.gc_HumveeTurretFire(%val);
    }
    if(%obj.getDataBlock().getID() == gc_HumveeAvengerTurretPlayer.getID()) %mount = %obj;
    if(isObject(%mount))
    {
      if(%mount.getDataBlock() == gc_HumveeAvengerTurretPlayer.getId() && %triggerNum == 0 && %val)
      {
        %target = gc_searchTargetCone(%obj,%mount.getEyeVector(),5,1000,%mount,$TypeMasks::VehicleObjectType);
        if(!isObject(%target)) { serverPlay3D(gc_BeepOffSound,%obj.getTransform()); return; }
        if(%target.getClassName() !$= "FlyingVehicle")
          if(%target.getClassName() $= "WheeledVehicle") {
            %raycast = containerRayCast(%target.getPosition(),vectorAdd(%target.getPosition(),"0 0 -1"),$TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType | $TypeMasks::fxBrickObjectType);
            if(isObject(firstWord(%raycast))) {  serverPlay3D(gc_BeepOffSound,%obj.getTransform()); return; } }
        %client = %obj.client;
        if(isObject(%client)) ServerCmdUnUseTool(%client);
        if(getSimTime() - %obj.lastShotTime < 5000) return;
        if(%mount.barrel == 1) { %mount.barrel = 2; %i = 1; }
        else
        { %mount.barrel = 1; %i = 2; }
        %scaleFactor = getWord(%mount.getScale(),2);
        %p = new Projectile()
        {
          dataBlock = gc_StingerProjectile;
          initialPosition = %mount.getSlotTransform(%i);
          initialVelocity = vectorScale(%mount.getMuzzleVector(%i),gc_StingerProjectile.muzzleVelocity);
          sourceObject = %obj;
          client = %obj.client;
          sourceSlot = 0;
          originPoint = %mount.getSlotTransform(%i);
        };
        MissionCleanup.add(%p);
        %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
        serverPlay3D(gc_AvengerFireSound,%obj.getPosition());
        %tank = %mount.getObjectMount();
        %obj.lastShotTime = getSimTime();
        return;
      }
    }
    parent::onTrigger(%this,%obj,%triggerNum,%val);
  }
  function Player::gc_HumveeTurretFire(%obj,%val)
  {
    if(!%val) { cancel(%obj.gc_HumveeTurretLoop); return; }
    if(!isObject(%obj.getObjectMount())) { cancel(%obj.gc_HumveeTurretLoop); return; }
    if(%obj.getObjectMount().getDataBlock() != gc_HumveeTurretPlayer.getId()) { cancel(%obj.gc_HumveeTurretLoop); return; }
    %client = %obj.client;
    if(isObject(%client)) ServerCmdUnUseTool(%client);
    %mount = %obj.getObjectMount();
    %scaleFactor = getWord(%mount.getScale(),2);
    %p = new Projectile()
    {
      dataBlock = gc_HumveeTurretProjectile;
      initialPosition = %mount.getSlotTransform(1);
      initialVelocity = MatrixMulVector(MatrixCreateFromEuler(((getRandom()-0.5)*0.02) SPC ((getRandom()-0.5)*0.02) SPC ((getRandom()-0.5)*0.02)),VectorScale(%mount.getMuzzleVector(1),200));
      sourceObject = %obj;
      client = %client;
      sourceSlot = 0;
      originPoint = %mount.getSlotTransform(1);
    };
    MissionCleanup.add(%p);
    %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
    %mount.mountImage(gc_HumveeTurretFireImage,1);
    %mount.playThread(0,fire);
    serverPlay3D(gc_HumveeFireSound,%obj.getPosition());
    %obj.gc_HumveeTurretLoop = %obj.schedule(150,gc_HumveeTurretFire,%val);
    return;
  }
  function projectile::onAdd(%obj,%a,%b)
  {
    parent::onAdd(%obj,%a,%b);
    if(%obj.dataBlock.getID() == gc_StingerProjectile.getID())
    {
      if(!%obj.doneHoming)
      {
        %obj.target = gc_searchTargetCone(%obj,6);
        %obj.doneHoming = 1;
      }
      if(%obj.target) %obj.schedule(100,gc_spawnHomingRocket);
    }
  }
};
activatepackage(gc_HumveePackage);
