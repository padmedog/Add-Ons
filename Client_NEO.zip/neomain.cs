//neomain.cs

function neomain::loaddefaults(%this)
{
	%command = new scriptobject(neocommand)
	{
		name = "Disconnect";
		icon = "add-ons/client_neo/ui/disconnect.png";
		cmd = "escapeFromGame();";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Quit";
		icon = "add-ons/client_neo/ui/quit.png";
		cmd = "quitGame();";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Options";
		icon = "add-ons/client_neo/ui/options.png";
		cmd = "Canvas.pushDialog(optionsDlg);";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Minigames";
		icon = "add-ons/client_neo/ui/minigames.png";
		cmd = "escapeMenu::clickMinigames();";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Players";
		icon = "add-ons/client_neo/ui/players.png";
		cmd = "canvas.pushDialog(NewPlayerListGui);";
		prefclose = true;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Admin";
		icon = "add-ons/client_neo/ui/admin.png";
		cmd = "escapeMenu::clickAdmin();";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Save Bricks";
		icon = "add-ons/client_neo/ui/save.png";
		cmd = "escapeMenu::clickSaveBricks();";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Load Bricks";
		icon = "add-ons/client_neo/ui/load.png";
		cmd = "escapeMenu::clickLoadBricks();";
		prefclose = false;
		isdefault = true;
	};
	%this.addCommand(%command);

	%command = new scriptobject(neocommand)
	{
		name = "Add New";
		icon = "add-ons/client_neo/ui/add.png";
		cmd = "neo_clickadd();";
		prefclose = false;
		isdefault = true;
		addbutton = true;
	};
	%this.addCommand(%command);
}

function neomain::loadCustoms(%this)
{
	for(%i=0; %i<$neo::data::saveCount; %i++)
	{
		if($neo::data::saveCustom[%i])
		{
			%command = new scriptobject(neocommand)
			{
				name = $neo::data::saveName[%i];
				icon = $neo::data::saveIcon[%i];
				cmd = $neo::data::saveCmd[%i];
				prefclose = $neo::data::savePrefClose[%i];
				custom = true;
			};
			%this.addCommand(%command);
		}
	}
}

function neomain::addCommand(%this, %command)
{
	//check if command already exists
	//commands are identified by name and function

	for(%i=0; %i<%this.commandCount; %i++)
	{
		if(%this.commandObj[%i].name $= %command.name && %this.commandObj[%i].cmd $= %command.cmd)
		{
			neo_debug("Command already exists: " @ %command.name);
			%command.delete();
			return;
		}
	}
	%this.modified = true;
	%this.commandObj[%this.commandCount] = %command;
	%this.commandLookup[%command.name, %command.cmd] = %this.commandCount;
	%this.commandCount++;

	//force add button to be last
	if(%this.commandCount >= 2)
	{
		if(%this.commandObj[%this.commandCount - 2].addbutton)
		{
			neo_debug("forcing add button to be last");
			%this.swapCommands(%this.commandCount-2, %this.commandCount-1);
		}
	}
}

function neomain::removeCommand(%this, %command)
{
	%id = %this.commandLookup[%command.name, %command.cmd];

	if(%id $= "")
	{
		neo_debug("Command to remove not found: " @ %command.name);
		return;
	}

	for(%i=%id; %i<%this.commandCount-1; %i++)
	{
		%this.swapCommands(%i, %i+1);
	}
	%this.commandCount--;
	%this.commandLookup[%command.name, %command.cmd] = "";
	%this.commandObj[%this.commandCount] = "";
	%command.delete();
	%this.modified = true;
}

function neomain::swapCommands(%this, %a, %b)
{
	if(%a == %b)
		return;
	neo_debug("swap: " @ %a SPC %b);
	%this.modified = true;
	%cmda = %this.commandObj[%a];
	%cmdb = %this.commandObj[%b];
	%this.commandObj[%a] = %cmdb;
	%this.commandObj[%b] = %cmda;
	%this.commandLookup[%cmda.name, %cmda.cmd] = %b;
	%this.commandLookup[%cmdb.name, %cmdb.cmd] = %a;
}

function neomain::useCommand(%this, %command)
{
	if(%command.prefclose)
	{
		canvas.popdialog(EscapeMenu);
	}
	eval(%command.cmd);
}

function neomain::forcedraw(%this)
{
	%this.modified = true;

	if(NARGEscapeOverlay.isAwake())
		%this.draw();
}

function neomain::maintain(%this)
{
	%this.loadNewCommands();
	%this.applySaveData();
}

function neomain::loadNewCommands(%this)
{
	//load new commands
	for(%this.lastLoaded=%this.lastLoaded; %this.lastLoaded<$neoCount; %this.lastLoaded++)
	{
		neo_debug("loading new commands");
		%this.modified = true;

		%command = new scriptobject(neocommand)
		{
			name = $neoName[%this.lastLoaded];
			cmd = $neoCmd[%this.lastLoaded];
			icon = $neoIcon[%this.lastLoaded]; //defaults to a question mark otherwise
			prefclose = $neoPrefClose[%this.lastLoaded]; //whether we want to overlay to close when this button is pressed
		};

		if(!isfile(%command.icon))
			%command.icon = $neo::pref::defaulticon;
		%this.addCommand(%command);
	}
}

function neomain::applySaveData(%this)
{
	//organize commands
	%current = 0;

	for(%i=0; (%i<$neo::data::saveCount && %current<%this.commandCount); %i++)
	{
		%id = %this.commandLookup[$neo::data::saveName[%i], $neo::data::saveCmd[%i]];

		if(%id $= "")
		{
			continue;
		}

		if($neo::data::saveModified[%i])
		{
			if(%this.commandObj.icon !$= $neo::data::saveIcon[%i])
			{
				%this.commandObj[%id].icon = $neo::data::saveIcon[%i];
				%this.commandObj[%id].modified = true;
				%this.modified = true;
			}

			if(%this.commandObj[%id].prefClose !$= $neo::data::savePrefClose[%i])
			{
				%this.commandObj[%id].prefClose = $neo::data::savePrefClose[%i];
				%this.commandObj[%id].modified = true;
				%this.modified = true;
			}
		}

		//swap id and current
		//if current is greater than id, something weird is going on
		if(%current > %id)
		{
			neo_debug("possible double entry?");
			continue;
		}
		%this.swapCommands(%current, %id);
		%current++;
	}

	//while it is not possible to get the add button out of position normally
	//it is possible that someone edits the save data to cause this
	if(!%this.commandObj[%this.commandCount-1].addButton)
	{
		neo_debug("Add button is not last!");

		for(%i=0; %i<%this.commandCount; %i++)
		{
			if(%this.commandObj[%i].addButton)
			{
				%this.swapCommands(%i, %this.commandCount-1);
				return;
			}
		}
		neo_debug("Add Button not found!");
	}
}

function neomain::draw(%this)
{
	neo_debug("redrawing overlay");

	if(%this.modified)
	{
		neo_debug("It's a full redraw");
		%this.modified = false;

		%gui = EscapeOverlay_List;
		%gui.clear();
		%width = getword(%gui.getextent(), 0);

		%row = 0;
		%column = 0;

		for(%i=0; %i<%this.commandCount; %i++)
		{
			if($neo::pref::buttonsize + 12 + ($neo::pref::buttonsize + 8)*%column > %width && %column > 0)
			{
				%row++;
				%column = 0;
			}
			%gui.newButton(%row, %column, %this.commandObj[%i]);
			%column++;
		}
		%gui.resize(getword(%gui.getposition(), 0), getword(%gui.getposition(), 1), %width, $neo::pref::buttonsize + 12 + ($neo::pref::buttonsize + 8)*%row);
	}
}

function neomain::savedata(%this)
{
	for($neo::data::saveCount=0; $neo::data::saveCount<%this.commandCount; $neo::data::saveCount++)
	{
		%obj = %this.commandObj[$neo::data::saveCount];
		$neo::data::saveName[$neo::data::saveCount] = %obj.name;
		$neo::data::saveCmd[$neo::data::saveCount] = %obj.cmd;

		if(%obj.custom)
		{
			$neo::data::saveModified[$neo::data::saveCount] = 0;
			$neo::data::saveCustom[$neo::data::saveCount] = 1;
			$neo::data::saveIcon[$neo::data::saveCount] = %obj.icon;
			$neo::data::savePrefClose[$neo::data::saveCount] = %obj.prefclose;
		}
		else if(%obj.modified)
		{
			$neo::data::saveModified[$neo::data::saveCount] = 1;
			$neo::data::saveCustom[$neo::data::saveCount] = 0;
			$neo::data::saveIcon[$neo::data::saveCount] = %obj.icon;
			$neo::data::savePrefClose[$neo::data::saveCount] = %obj.prefclose;
		}
		else
		{
			$neo::data::saveModified[$neo::data::saveCount] = 0;
			$neo::data::saveCustom[$neo::data::saveCount] = 0;
			$neo::data::saveIcon[$neo::data::saveCount] = "";
			$neo::data::savePrefClose[$neo::data::saveCount] = "";
		}
	}
	export("$neo::data::*", $neo::pref::datapath);
}

