datablock ExplosionData(HeavyFlamerExplosion)
{
   //explosionShape = "";

   lifeTimeMS = 2500;

   particleEmitter = WHFlamerExplosionEmitter;
   particleDensity = 7;
   particleRadius = 0.4;

   emitter[0] = WHFlamerExplosionSmokeEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 2.5;
   
   damageRadius = 4.5; 
   radiusDamage = 22.5;                                           
   impulseRadius = 0;  
   impulseForce = 0;    

   playerBurnTime = 5000;  
   
   // Dynamic light
   lightStartRadius = 6;
   lightEndRadius = 0;
   lightStartColor = "1 0.81 0.25 1";
   lightEndColor = "1 0.25 0 0";
};

datablock ProjectileData(HeavyFlamerProjectile)
{
   //projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::WHFlamer;
   radiusDamageType    = $DamageType::WHFlamer;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground
   
   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = HeavyFlamerExplosion;
//   particleEmitter     = "HeavyFlamerTrailEmitter";

   muzzleVelocity      = 50;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 750;
   fadeDelay           = 250;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 6.0;
   lightColor  = "1 0.75 0";
};

//////////
// item //
//////////
datablock ItemData(HeavyFlamerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./HeavyFlamer.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Heavy Flamer";
	iconName = "./HeavyFlamer";
	doColorShift = false;
	colorShiftColor = "0.375 0.375 0.375 1.000";

	 // Dynamic properties defined by the scripts
	image = HeavyFlamerImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 200;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(HeavyFlamerImage)
{

   // Basic Item properties
   shapeFile = "./HeavyFlamer.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = HeavyFlamerItem;
   ammo = " ";
   projectile = HeavyFlamerProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = HeavyFlamerItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTimeout[1]	   = "Ready";
	stateTimeoutValue[1]            = 0.2;
	stateWaitForTimeout[1]		   = true;
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";
	stateEmitter[1]			   = WHFlamerLighterEmitter;
	stateEmitterTime[1]		   = 0.025;
	stateEmitterNode[1]		= "lighter";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.0025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= WHFlamerFireEmitter;
	stateEmitterTime[2]		= 0.25;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= WHFlamerFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= WHFlamerSmokeEmitter;
	stateEmitterTime[3]		= 0.05;
	stateEmitterNode[3]		= "smoke";
	stateTimeoutValue[3]            = 0.0025;
	stateTransitionOnTimeout[3]     = "Ready";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.0;
	stateTransitionOnTimeout[4]	= "Ready";

};
	
function HeavyFlamerImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
//	%obj.playThread(2, plant);


	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0036;
	}
	else
	{
		%spread = 0.0036;
	}
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}
