datablock fxDTSBrickData(brick1x2VerticalRampTOPData)
{
	brickFile = "./1x2VerticalRampTOP.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2 Vertical TOP Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2VerticalRampTOP";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2VerticalRampBOTTOMData)
{
	brickFile = "./1x2VerticalRampBOTTOM.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2 Vertical BOTTOM Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2VerticalRampBOTTOM";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1VerticalRampTOPData)
{
	brickFile = "./1x1VerticalRampTOP.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1 Vertical TOP Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1VerticalRampTOP";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1VerticalRampBOTTOMData)
{
	brickFile = "./1x1VerticalRampBOTTOM.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1 Vertical BOTTOM Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1VerticalRampBOTTOM";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2SmallRampData)
{
	brickFile = "./1x2SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1SmallRampData)
{
	brickFile = "./1x1SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x1SmallRampData)
{
	brickFile = "./2x1SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x1 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x1SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2SmallRampData)
{
	brickFile = "./2x2SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x2 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x2SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2SmallRampLeftData)
{
	brickFile = "./2x2SmallRampLeft.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x2 Left Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x2SmallRampLeft";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2SmallRampRightData)
{
	brickFile = "./2x2SmallRampRight.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x2 Right Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x2SmallRampRight";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x1SmallRampLeftData)
{
	brickFile = "./2x1SmallRampLeft.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x1 Left Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x1SmallRampLeft";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x1SmallRampRightData)
{
	brickFile = "./2x1SmallRampRight.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x1 Right Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x1SmallRampRight";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1SmallRampDownsideData)
{
	brickFile = "./1x1SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1 Inverted Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2SmallRampDownsideData)
{
	brickFile = "./2x2SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x2 Inverted Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x2SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2SmallRampDownsideData)
{
	brickFile = "./1x2SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2 Inverted Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x1SmallRampDownsideData)
{
	brickFile = "./2x1SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x1 Inverted Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x1SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1FSmallRampLeftData)
{
	brickFile = "./1x1FSmallRampLeft.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1F Left Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1FSmallRampLeft";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1FSmallRampRightData)
{
	brickFile = "./1x1FSmallRampRight.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1F Right Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1FSmallRampRight";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1SmallRampRightData)
{
	brickFile = "./1x1SmallRampRight.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1 Right Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1SmallRampRight";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x1SmallRampLeftData)
{
	brickFile = "./1x1SmallRampLeft.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x1 Left Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x1SmallRampLeft";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2FSmallRampLeftData)
{
	brickFile = "./1x2FSmallRampLeft.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2F Left Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2FSmallRampLeft";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2FSmallRampRightData)
{
	brickFile = "./1x2FSmallRampRight.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2F Right Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2FSmallRampRight";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2SmallRampRightData)
{
	brickFile = "./1x2SmallRampRight.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2 Right Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2SmallRampRight";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x2SmallRampLeftData)
{
	brickFile = "./1x2SmallRampLeft.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x2 Left Side Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x2SmallRampLeft";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2VerticalRampTOPData)
{
	brickFile = "./2x2VerticalRampTOP.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x2 Vertical TOP Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x2VerticalRampTOP";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2VerticalRampBOTTOMData)
{
	brickFile = "./2x2VerticalRampBOTTOM.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x2 Vertical BOTTOM Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x2VerticalRampBOTTOM";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x1VerticalRampTOPData)
{
	brickFile = "./2x1VerticalRampTOP.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x1 Vertical TOP Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x1VerticalRampTOP";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x1VerticalRampBOTTOMData)
{
	brickFile = "./2x1VerticalRampBOTTOM.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x1 Vertical BOTTOM Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x1VerticalRampBOTTOM";

	orientationFix = 3;
};
//-------------------------------------------------------------------------------------------------
datablock fxDTSBrickData(brick1x4_SmallRampData)
{
	brickFile = "./1x4_SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x4 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x4_SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x8_SmallRampData)
{
	brickFile = "./1x8_SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x8 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x8_SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4_SmallRampData)
{
	brickFile = "./2x4_SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x4 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x4_SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x8_SmallRampData)
{
	brickFile = "./2x8_SmallRamp.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x8 Small Ramp";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x8_SmallRamp";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x4_SmallRampDownsideData)
{
	brickFile = "./1x4_SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x4 Small Ramp Downside";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x4_SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick1x8_SmallRampDownsideData)
{
	brickFile = "./1x8_SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "1x8 Small Ramp Downside";
	iconName = "Add-Ons/Brick_SmallRampsPack/1x8_SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4_SmallRampDownsideData)
{
	brickFile = "./2x4_SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x4 Small Ramp Downside";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x4_SmallRampDownside";

	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x8_SmallRampDownsideData)
{
	brickFile = "./2x8_SmallRampDownside.blb";
	category = "Ramps";
	subCategory = "Small Ramps";
	uiName = "2x8 Small Ramp Downside";
	iconName = "Add-Ons/Brick_SmallRampsPack/2x8_SmallRampDownside";

	orientationFix = 3;
};
