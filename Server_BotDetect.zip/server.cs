if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$botdetectset)
	{
		if(!$RTB::RTBR_ServerControl_Hook)
			exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
		RTB_registerPref("Timeout (milliseconds)", "BotDetect", "pref::botdetect::timeout", "int 0 99999", "Server_BotDetect", 5000, 0, 0);
		RTB_registerPref("Botting Limit", "BotDetect", "pref::botdetect::limit", "int 0 99999", "Server_BotDetect", 800, 0, 0);
		RTB_registerPref("BlockTime(minutes)", "BotDetect", "pref::botdetect::blocktime", "int 0 999", "Server_BotDetect", 5, 0, 0);
		RTB_registerPref("Enabled", "BotDetect", "pref::botdetect::enabled", "bool", "Server_BotDetect", 1, 0, 0);
		$botdetectset = 1;
	}
}
else
{
	$pref::botdetect::timeout = 5000;
	$pref::botdetect::limit = 800;
	$pref::botdetect::blocktime = 5;
	$pref::botdetect::enabled = true;
}

package botdetect
{
	function servercmdplantbrick(%client)
	{
		%client.botdetect(1);

		if($botdetected[%client.bl_id] && $pref::botdetect::enabled)
			return 0;
		parent::servercmdplantbrick(%client);
	}

	function servercmdshiftbrick(%client, %x, %y, %z)
	{
		if(%x)
		{
			if(%y || %z)
				%client.botdetect(10);
			else
				%client.botdetect(1);
		}
		else if(%y)
		{
			if(%z)
				%client.botdetect(10);
			else
				%client.botdetect(1);
		}
		else
			%client.botdetect(1);

		if($botdetected[%client.bl_id] && $pref::botdetect::enabled)
			return 0;
		parent::servercmdshiftbrick(%client, %x, %y, %z);
	}

	function servercmdbuybrick(%client, %slot, %dtb)
	{
		if(%slot == 0)
		{
			if(%client.lastbrickslot != 9)
				%client.botdetect(10);
			else
				%client.botdetect(1);
			%delay = getsimtime() - %client.lastbuytime;

			if(%delay < 2000)
				%client.botdetect((2000-%delay)/50);
			%client.lastbuytime = getsimtime();
		}
		else
			%client.botdetect(1);
		%client.lastbrickslot = %slot;

		if($botdetected[%client.bl_id] && $pref::botdetect::enabled)
			return 0;
		parent::servercmdbuybrick(%client, %slot, %dtb);
	}

	function servercmdinstantusebrick(%client, %dtb)
	{
		%client.botdetect(4);

		if($botdetected[%client.bl_id] && $pref::botdetect::enabled)
			return 0;
		parent::servercmdinstantusebrick(%client, %dtb);
	}

	function servercmdmessagesent(%client, %msg)
	{
		if($botdetected[%client.bl_id] && $pref::botdetect::enabled)
			return 0;
		parent::servercmdmessagesent(%client, %msg);
	}

	function gameconnection::botdetect(%client, %x)
	{
		if(!$pref::botdetect::enabled || %client.isadmin)
			return;
		$botdetectbricks[%client.bl_id]+=%x;
		schedule($pref::botdetect::timeout, 0, eval, "$botdetectbricks["@%client.bl_id@"]-="@%X@";");

		if($botdetectbricks[%client.bl_id] > $pref::botdetect::limit && !$botdetected[%client.bl_id])
		{
			messageall('', %client.name SPC "Has been detected botting.");
			$botdetected[%client.bl_id] = true;
			schedule($pref::botdetect::blocktime*60000, 0, eval, "$botdetected["@%client.bl_id@"]=false;");
		}
	}
};
activatepackage(botdetect);