//Base Blockhead guy

// only load bots if bot_hole is enabled
// people are going to have a lot of bot add-ons, you don't want them to all force bot_hole on
if(LoadRequiredAddOn("Bot_Hole") == $Error::None)
	exec("./bot_base.cs");