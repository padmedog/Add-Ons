//Tezuni's IP Logger Changelog
//v.1
// - Logs all IP addresses and BL_ID's of those who join your server
// - Each BL_ID and IP address is logged once, and once only to prevent spam
//

exec("./IPLog.cs");
