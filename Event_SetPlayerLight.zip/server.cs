package toglightevent
{
	function serverCmdLight(%client)
	{
		if((%client.player.togLight == 1 && isObject(%client.player.light)) || (%client.player.togLight == 2 && !isObject(%client.Player.light)) || (!%client.player.togLight))
			Parent::serverCmdLight(%client);
	}
	function Player::SetPlayerLight(%this,%val)
	{
		if(isObject(%this.client))
		{
			%this.togLight = %val;
			if(%val != 0)
				serverCmdLight(%this.client);
		}
	}
};

ActivatePackage(toglightevent);
RegisterOutputEvent(Player,SetPlayerLight,"list Dynamic 0 AlwaysOn 2 AlwaysOff 1",0);