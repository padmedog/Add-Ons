//================================================================
//=	Title: 	Blockland Glass (i3)								 =
//=	Author:	Jincux (9789)										 =
//=	If you're looking at this, go you. either that, or you're a  =
//=	little skiddy trying to 'troll'								 =
//================================================================
// DISCLAIMER: Through majority of production, I was drunk

//Object-based structure, for data's sake

new ScriptObject(BLG) {
	version = "0.1";
	address = "blockland.jincux.tk";
	netAddress = "blockland.jincux.tk";
};

function BLG::fuckBitches(%this) {
	echo(" === Blockland Glass v" @ %this.version @ " suiting up. ===");
	exec("./auth.cs");
	exec("./BLG_VerifyAccount.gui");
	echo(" ===                   Sticking it in                   ===");
	BLG_Con.pollServer();
	echo(" ===            Drunkenly staggering forward            ===");
}

BLG.fuckBitches();