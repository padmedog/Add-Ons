function undoBrick(%val)
{
	if(%val)
	{
		startUndoing();
	}else{
		stopUndoing();
	}
}
function startUndoing()
{
	if(isEventPending($Undoing))
		return;
	commandtoserver('undoBrick');
	$ConsideringUndo = schedule(1000, 0, "DoUndo");
}
function DoUndo()
{
	commandtoserver('undoBrick');
	$Undoing = schedule(75, 0, "DoUndo");
}

function stopUndoing()
{
	if(isEventPending($ConsideringUndo))
		cancel($ConsideringUndo);
	
	if(isEventPending($Undoing))
		cancel($Undoing);
}