function Player::Tumble(%this,%int)
{
	tumble(%this,%int);
}
registerOutputEvent("Player", "Tumble", "int 1000 5000 2500", 0);