datablock ParticleData(shieldLIOOParticle)
{
	dragCoefficient      = 6;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	spinRandomMin = -90;
	spinRandomMax = 90;
	lifetimeMS           = 80;
	lifetimeVarianceMS   = 60;
	textureName          = "add-ons/weapon_package_support2/shield_fx";
   	colors[0]     = "1 1 1 0.1";
	colors[1]     = "1 1 0.5 0.2";
	colors[2]     = "1 1 1 0.1";
	colors[3]     = "0.0 0.0 0.0 0.0";
	sizes[0]      = 7;
	sizes[1]      = 6.2;
	sizes[2]      = 6.2;
	sizes[3]      = 6.20;
};

datablock ParticleEmitterData(shieldLIOOEmitter)
{
	ejectionPeriodMS = 60;
	periodVarianceMS = 0;
	ejectionVelocity = 0;
	velocityVariance = 0;
	ejectionOffset   = 0.5;
	thetaMin         = -180;
	thetaMax         = 180;
	phiReferenceVel  = -180;
	phiVariance      = 180;
	overrideAdvance = false;
	particles = "shieldLIOOParticle";
};

datablock ExplosionData(shieldLIOOExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 100;

   emitter[0] = shieldLIOOEmitter;
   emitter[1] = LaserPistolFlashEmitter;
   emitter[2] = shockDebuffExplosionEmitter;

   soundProfile = electrocuteHitSound;

   faceViewer     = true;
   explosionScale = "1 1 1";

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 1;
   lightStartColor = "00.0 0.6 0.9";
   lightEndColor = "0 0 0";
};
datablock ProjectileData(shieldLIOOProjectile : gunProjectile)
{
   explosion           = shieldLIOOExplosion;
   projectileShapeName = "";

   armingDelay         = 100;
   lifetime            = 100;
   fadeDelay           = 100;
};

//////////
// item //
//////////
datablock ItemData(shieldLIOOItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./energy_shield.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "50-HP Shield";
	iconName = "./icon_shield50";
	doColorShift = false;
	colorShiftColor = "0.61 0.61 0.65 1.000";

	 // Dynamic properties defined by the scripts
	image = dummyshieldimage;
	canDrop = true;

	 // Shield variables; 'light' shield.
	is_dmshield = 1;
	dmshield_amount = 50;
	dmshield_rechargeincrement = 5;

	dmshield_rechargerate = 100;
	dmshield_hurtrechargerate = 5000;
	dmshield_explosiontype = shieldLIOOProjectile;

	dmshield_startsound = shieldLrechargeSound;
	dmshield_endsound = shieldLfinishSound;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(dummyshieldimage)
{
   // Basic Item properties
	shapeFile = "./energy_shield.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = shieldLIOOItem;
   ammo = " ";
   projectile = shieldLIOOProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   minShotTime = 1450;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = true;
   colorShiftColor = shieldLIOOItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.2;
	stateSequence[0]			  = "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateScript[0]                  = "onActivate";
	stateSound[0]			  = weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";
};