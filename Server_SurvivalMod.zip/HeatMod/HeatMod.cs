%error = ForceRequiredAddOn("Brick_Large_Cubes");if(%error == $Error::AddOn_NotFound)return;
exec("./Overwrites.cs");
//------------------------
// Variables
//------------------------
$HeatMod_Mode = 1; //0 1  Normal, DayCycle
$HeatMod_MinigameOnly = 1;
//------------------------
// Rtb
//------------------------
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
	{
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	}
	RTB_registerPref("Day Heat Gain/Loss", "Heat Mod", "$HeatMod_DayHeat", "num -1000 1000", "Server_HeatMod", 1, 0, 0);
	RTB_registerPref("Night Heat Gain/Loss", "Heat Mod", "$HeatMod_NightHeat", "num -1000 1000", "Server_HeatMod", -1, 0, 0);
	RTB_registerPref("Heat Gain/Loss", "Heat Mod", "$HeatMod_HeatLoss", "num -1000 1000", "Server_HeatMod", -1, 0, 0);
	RTB_registerPref("Fire Heat Gain", "Heat Mod", "$HeatMod_FireHeat", "num -1000 1000", "Server_HeatMod", 2, 0, 0);
	RTB_registerPref("Minigame Required", "Heat Mod", "$HeatMod_MinigameOnly", "bool", "Server_HeatMod", 1, 0, 0, "Rtb_HeatMod_Minigame");
	RTB_registerPref("Enabled", "Heat Mod", "$HeatMod_Enabled", "bool", "Server_HeatMod", 1, 0, 0, "Rtb_HeatMod_Enabled");
}
else
{
	$HeatMod_DayHeat = -1;
	$HeatMod_NightHeat = -2;
	$HeatMod_HeatLoss = -2;
	$HeatMod_FireHeat = 2;
	$HeatMod_Enabled = 1;
}
function Rtb_HeatMod_Enabled(%oldVal, %newVal)
{
	schedule(0, 0, "messageAll", '', "\c3+ Heat Mod\c0 - Heat Mod is now " @ (%newVal ? "\c2Enabled" : "\c3Disabled") @ "\c0.");
	ResetHeatModStuffs();
}
function Rtb_HeatMod_Minigame(%oldVal, %newVal)
{
	schedule(0, 0, "messageAll", '', "\c3+ Heat Mod\c0 - Heat Mod now on " @ (%newVal ? "\c3Minigame Only" : "\c3All the time") @ "\c0.");
	ResetHeatModStuffs();
}

function ResetHeatModStuffs()
{
	//If a pref is changed
	for(%i=0;%i<clientGroup.getCount();%i++)
	{
		%targetClient = clientGroup.getObject(%i);
		if(isObject(%targetClient.player))
		{
			HeatCheckLoop(%targetClient,0);
		}
	}
}
//------------------------
// Events
//------------------------
registerOutputEvent("Player", "AddHeat" ,"int -100 100 25");
registerOutputEvent("Player", "SetHeat" ,"int 0 100 100");
registerOutputEvent("Player", "isAffectedByHeat" ,"bool 1");
registerOutputEvent("fxDTSBrick", setHeatBrick, "bool 0");

function Player::isAffectedByHeat(%player, %val)
{
	if(%Val)
	{
		%Player.isNotAffectedByHeat = 0;
		HeatCheckLoop(%Player.Client,0);
	}
	if(!%Val)
	{
		%Player.isNotAffectedByHeat = 1;	
	}
}

function fxDTSBrick::setHeatBrick(%brick,%val)
{
	if(%Val)
	{
		%brick.createTrigger(Heat_Area_Trigger,"0 0 0 1 0 0 0 -1 0 0 0 1");
		%brick.setColliding(0);
		%brick.setRendering(0);
		%brick.setRayCasting(0);
	}
	if(!%Val)
	{
		if(isObject(%brick.trigger))
		%brick.trigger.delete();
		
		%brick.setColliding(1);
		%brick.setRendering(1);
		%brick.setRayCasting(1);	
	}
}
function Player::addHeat(%player, %amt)
{
	if(isObject(%player.Client))
	{
		%player.Client.bodyTemp += %amt;
	
		%player.client.heatSched = schedule(10,0,HeatCheckLoop,%player.client,1);
		
	}
}   

function Player::setHeat(%player, %amt)
{
	if(isObject(%player.Client))
	{
		%player.Client.bodyTemp = %amt;

		%player.client.heatSched = schedule(10,0,HeatCheckLoop,%player.client,1);
		
	}
}   

//------------------------
// Triggers
//------------------------

datablock TriggerData(Heat_Area_Trigger)
{
   tickPeriodMS = 50;
};
function Heat_Area_Trigger::onTickTrigger(%this,%trigger,%obj)
{
	parent::onTickTrigger(%this,%trigger,%obj);
	
	if(isObject(%obj.getMountedObject(0).client))
   	{
      		%obj = %obj.getMountedObject(0);
   	}
 	
	%client = %obj.client;
   	
	if(!isObject(%client))
    return;
	if(!isObject(%client.player))
    return;
	
	%client.heatSched = schedule(20,0,HeatCheckLoop,%client,1);
	%client.inHeatZone = 1;
	
	cancel(%client.heat_tick_deletedSched);
	%client.heat_tick_deletedSched = schedule(500,0,leave_Heat_Trigger,%client);
}

//Just in case the brick gets deleted while someone is still in it
function leave_Heat_Trigger(%Cl)
{
	%cl.heatSched = schedule(10,0,HeatCheckLoop,%client,1);
	%cl.inHeatZone = 0;
}

//------------------------
// Heat Checks
//------------------------

function HeatCheckLoop(%Cl,%Trig)
{
	if(!$HeatMod_Enabled)
	return;

	
	if(!isObject(%Cl.minigame))
	{
		if($HeatMod_MinigameOnly)
		return;
	}
	if(!isObject(%Cl.player))
	return;
	if(%Cl.player.isNotAffectedByHeat)
	return;
	
	cancel(%client.heat_tick_deletedSched);

	%HeatMod_Time_Var = getPartOfDayCycle();
	switch(%HeatMod_Time_Var)
	{
		case 0:
			%cl.HeatMod_Time = "Day";
		case 1:
			%cl.HeatMod_Time = "Day";
		case 2:
			%cl.HeatMod_Time = "Night";
		case 3:
			%cl.HeatMod_Time = "Night";
	}
	
	if(!%Trig)
	cancel(%Cl.heatSched);
	
	%Pl = %Cl.player;
	if(%Cl.inHeatZone)
	{
		if(%Cl.bodyTemp < 98.6 && !%Trig)
		%Cl.bodyTemp += $HeatMod_FireHeat;
		
		if(%Cl.bodyTemp > 98.6)
		%Cl.bodyTemp = 98.6;
		
		if(%cl.heatHealthLost > 0)
		{
			%cl.player.addhealth(1);
			%cl.heatHealthLost -= 1;
		}
		%Cl.bodyTemp_Var = mRound(%Cl.bodyTemp);	
		
		if(!%Trig)
		%Cl.heatSched = schedule(800,0,HeatCheckLoop,%Cl,0);
	}
	if(!%Cl.inHeatZone)
	{
		if(!%Trig)
		{
			if($HeatMod_Mode && $HeatMod::DayCycleOn)
			{
				if(getPartOfDayCycle() == 3 || getPartOfDayCycle() == 2)
				{
					%Cl.bodyTemp += $HeatMod_NightHeat;
				} else {
						%Cl.bodyTemp += $HeatMod_DayHeat;
				}
			} else {
						%Cl.bodyTemp += $HeatMod_HeatLoss;
			}
		}
		
		%Cl.bodyTemp_Var = mRound(%Cl.bodyTemp);
	    if(%Cl.bodyTemp >= 110)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 125;
				%cl.player.addhealth(-125);
			}
		}
	    if(%Cl.bodyTemp < 110 && %Cl.bodyTemp >= 109)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 100;
				%cl.player.addhealth(-100);
			}
		}
	    if(%Cl.bodyTemp < 109 && %Cl.bodyTemp >= 108)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 50;
				%cl.player.addhealth(-50);
			}
		}
	    if(%Cl.bodyTemp < 108 && %Cl.bodyTemp >= 107)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 25;
				%cl.player.addhealth(-25);
			}
		}
	    if(%Cl.bodyTemp < 107 && %Cl.bodyTemp >= 106)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 10;
				%cl.player.addhealth(-10);
			}
		}
	    if(%Cl.bodyTemp < 106 && %Cl.bodyTemp >= 105)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 5;
				%cl.player.addhealth(-5);
			}
		}
	    if(%Cl.bodyTemp < 105 && %Cl.bodyTemp >= 104)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 3;
				%cl.player.addhealth(-3);
			}
		}
	    if(%Cl.bodyTemp < 104 && %Cl.bodyTemp >= 103)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 0.5;
				%cl.player.addhealth(-0.5);
			}
		}
		if(%Cl.bodyTemp > 89.5 && %Cl.bodyTemp <= 95)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 3;
				%cl.player.addhealth(-3);
			}
		}		
		if(%Cl.bodyTemp > 82.4 && %Cl.bodyTemp <= 89.5)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 5;
				%cl.player.addhealth(-5);
			}
		}		
		if(%Cl.bodyTemp > 75.2 && %Cl.bodyTemp <= 82.4)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 10;
				%cl.player.addhealth(-10);
			}
		}
		if(%Cl.bodyTemp > 68 && %Cl.bodyTemp <= 75.2)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 25;
				%cl.player.addhealth(-25);
			}
		}
		if(%Cl.bodyTemp > 50 && %Cl.bodyTemp <= 68)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 50;
				%cl.player.addhealth(-50);
			}
		}
	    if(%Cl.bodyTemp > 40 && %Cl.bodyTemp <= 50)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 100;
				%cl.player.addhealth(-100);
			}
		}
	    if(%Cl.bodyTemp <= 40)
		{
			if(!%Trig)
			{
				%cl.heatHealthLost += 125;
				%cl.player.addhealth(-125);
			}
		}
		
		if(!%Trig)
		%Cl.heatSched = schedule(2000,0,HeatCheckLoop,%Cl,0);
	}
}
function ServerCmdTimeofDay(%Cl)
{
	//Might be helpful for some reason
	MessageClient(%Cl,'',"\c6It's " @ %cl.HeatMod_Time);
}

package Swol_HeatMod 
{
	function GameConnection::spawnPlayer(%this)
	{
		parent::spawnPlayer(%this);
		
		%this.inHeatZone = 0;
		%this.bodyTemp = 98.6;
		schedule(500,0,HeatCheckLoop,%this,0);
	}
	function heatbrick4x4::onplant(%data,%this)
	{
		Parent::onPlant(%this);
		heatbrick4x4::LoadParameters(%this);
	}
	function heatbrick4x4::onLoadplant(%data,%this)
	{	
		Parent::onLoadPlant(%this);
		heatbrick4x4::LoadParameters(%this);
	}
	function heatbrick4x4::LoadParameters(%this)
	{
		%this.createTrigger(Heat_Area_Trigger,"0 0 0 1 0 0 0 -1 0 0 0 1");
		%this.setColliding(0);
		%this.setRendering(0);
		%this.setRayCasting(0);
	}
	function heatbrick8x8::onplant(%data,%this)
	{
		Parent::onPlant(%this);
		heatbrick8x8::LoadParameters(%this);
	}
	function heatbrick8x8::onLoadplant(%data,%this)
	{	
		Parent::onLoadPlant(%this);
		heatbrick8x8::LoadParameters(%this);
	}
	function heatbrick8x8::LoadParameters(%this)
	{
		%this.createTrigger(Heat_Area_Trigger,"0 0 0 1 0 0 0 -1 0 0 0 1");
		%this.setColliding(0);
		%this.setRendering(0);
		%this.setRayCasting(0);
	}
	function heatbrick16x16::onplant(%data,%this)
	{
		Parent::onPlant(%this);
		heatbrick16x16::LoadParameters(%this);
	}
	function heatbrick16x16::onLoadplant(%data,%this)
	{
		Parent::onLoadPlant(%this);
		heatbrick16x16::LoadParameters(%this);
	}
	function heatbrick16x16::LoadParameters(%this)
	{
		%this.createTrigger(Heat_Area_Trigger,"0 0 0 1 0 0 0 -1 0 0 0 1");
		%this.setColliding(0);
		%this.setRendering(0);
		%this.setRayCasting(0);
	}
	function fxDtsBrick::onRemove(%this)
	{
		if(isObject(%this.trigger))
			%this.trigger.delete();
		
		parent::onRemove(%this);
	}
	function fxDtsBrick::createTrigger(%this,%data,%polyhedron)
	{
		if(%polyhedron $= "")
			%polyhedron = "0 0 0 1 0 0 0 -1 0 0 0 1";

		if(isObject(%this.trigger))
			%this.trigger.delete();

		%t = new Trigger()
		{
			datablock = %data;
			polyhedron = %polyhedron;
		};
		missionCleanup.add(%t);
	
		%boxMax = getWords(%this.getWorldBox(), 3, 5);
		%boxMin = getWords(%this.getWorldBox(), 0, 2);
		%boxDiff = vectorSub(%boxMax,%boxMin);
		%boxDiff = vectorAdd(%boxDiff,"0 0 0.2"); 
		%t.setScale(%boxDiff);
		%posA = %this.getWorldBoxCenter();
		%posB = %t.getWorldBoxCenter();
		%posDiff = vectorSub(%posA, %posB);
		%posDiff = vectorAdd(%posDiff, "0 0 0.1");
		%t.setTransform(%posDiff);

		%this.trigger = %t;
		%t.brick = %this;

		return %t;
	}
	
	function serverCmdEnvGui_SetVar(%client, %variable, %value)
	{
		if(%variable $= "DayCycleEnabled")
		{
			if(%value)
			{
				$HeatMod::DayCycleOn = 1;
			}
			else
			{
				$HeatMod::DayCycleOn = 0;
			}
		}
		
		return parent::serverCmdEnvGui_SetVar(%client, %variable, %value);
	}
};
ActivatePackage(Swol_HeatMod);

//------------------------
// Support Functions
//------------------------
function getDayCycleTime() //Returns the time in seconds from dawn from the current time
{
	%curTime = $Sim::Time; // the day cycle is tied directly to the simTime of the server.

	%length = DayCycle.dayLength; // this is how long in seconds the day will last. for example, 24 is a full 24 hour day in the space of 24 seconds.

	%offset = DayCycle.dayOffset; // this is how much offset is applied to the day.

	%offset = mfloor(%offset * %length); // this calculates how many seconds the offset actually affects, as the offset is defined in a range between 0 and 1.

	if(%offset != 0)
		%curTime = (%curTime + %offset) - %length; // this adds the offset into the equation.

	%final = mFloor(%curTime % %length); // this determines the remainder of simTime divided by length, which is how far, in seconds, we are into the day.

	if(%final < 0) //if the result is a negative, we need to subtract it from the total. this allows compatibility with offsets.
		%final = %length - %final;

	return %final;
}

function getPartOfDayCycle() //Returns 3, 2, 1, 0 for Midnight, Dusk, Noon, Dawn respectively
{
	%tod = getDayCycleTime(); // determine time into the day.

	%len = DayCycle.dayLength; // determine length of days

	%quarter = mFloatLength(%len / 4, 0);

	%part = mFloor(%tod / %quarter); // this ought to return a number like 1 2 3 4

	return %part;
}

function mRound(%num,%dec)
{
	%ten = mPow(10,%dec);
	%five = 5 / (%ten * 10);
	return (mFloor((%num + %five) * %ten) / %ten);
}

//------------------------
// Bricks
//------------------------

datablock fxDTSBrickData (heatbrick4x4 : brick4xCubeData)
{
	category = "Special";
	subCategory = "Heat Mod";
	uiName = "4x4 Heat Cube";
	
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData (heatbrick8x8 : brick8xCubeData)
{
	category = "Special";
	subCategory = "Heat Mod";
	uiName = "8x8 Heat Cube";
	
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};

datablock fxDTSBrickData (heatbrick16x16 : brick16xCubeData)
{
	category = "Special";
	subCategory = "Heat Mod";
	uiName = "16x16 Heat Cube";
	
	alwaysShowWireFrame = false;
	isWaterBrick = true;
};
