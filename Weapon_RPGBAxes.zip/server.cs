AddDamageType("BAxe",   '<bitmap:add-ons/Weapon_RPGBAxes/CI_rpgbaxe> %1',    '%2 <bitmap:add-ons/Weapon_RPGbaxes/CI_rpgBAxe> %1',0.75,1);

%errorA = ForceRequiredAddOn("Weapon_sword");

if(%error == $Error::AddOn_Disabled)
{
   swordItem.uiName = "";
}

if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Weapons_RPGBAxes - required add-ons not found");
else
{
    exec("./Weapon_BronzeBAxe.cs");
    exec("./Weapon_CopperBAxe.cs");
    exec("./Weapon_IronBAxe.cs");
    exec("./Weapon_SteelBAxe.cs");
    exec("./Weapon_HalaciteBAxe.cs");
}