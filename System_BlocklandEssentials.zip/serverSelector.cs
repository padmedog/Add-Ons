function blrsServerSelector::onWake(%this)
{
	$blrsall = 1;
	blrsServerList.clear();
	$blrs::serverCount = 0;
	deleteVariables("$blrs::serverTable*");
	new HTTPObject(blrsServerListGetter);
	blrsServerListGetter.get("master2.blockland.us:80","/");
}

function blrsServerListGetter::onLine(%this,%line)
{
	if(%line $= "" || %line $= " ")
		return;
	if($blrsall)
	{
	if(getField(%line,0) !$= "FIELDS" && %line !$= "START")
	{
		if(%line $= "END")
		{
			blrsServerList.sort(0);
			blrsServerListGetter.delete();
			return;
		}
		else
		{
			$blrs::serverTable[$blrs::serverCount] = getField(%line,0);
			blrsServerList.addRow($blrs::serverCount,getField(%line,4));
			$blrs::serverCount++;
		}
	}
	}
	else
	{
		if(%line $= "END")
		{
			blrsServerList.sort(0);
			blrsServerListGetter.delete();
			return;
		}
		else
		{
			%name = getField(%line,0);
			%add = getField(%line,1);
			$blrs::serverTable[$blrs::serverCount] = %add;
			blrsServerList.addRow($blrs::serverCount,%name);
			$blrs::serverCount++;
		}
	}
}

function blrsServerList::onSelect(%this,%id,%text)
{
	if($blrsall)
	{
	blrs_IPBox.setValue($blrs::serverTable[%id]);
	canvas.popDialog(blrsServerSelector);
	}
	else
	{
	%add = $blrs::serverTable[%id];
	%ip = getSubStr(%add,0,strpos(%add,":"));
	%port = getSubStr(%add,strpos(%add,":")+1,10);
	blrs_IPBox.setValue(%ip);
	blrs_portBox.setValue(%port);
	canvas.popDialog(blrsServerSelector);
	}
}

function blrs_listall()
{
	$blrsall = 1;
	blrsServerList.clear();
	$blrs::serverCount = 0;
	deleteVariables("$blrs::serverTable*");
	new HTTPObject(blrsServerListGetter);
	blrsServerListGetter.get("master2.blockland.us:80","/");
}

function blrs_listblrs()
{
	$blrsall = 0;
	blrsServerList.clear();
	$blrs::serverCount = 0;
	deleteVariables("$blrs::serverTable*");
	new HTTPObject(blrsServerListGetter);
	blrsServerListGetter.get("syerjchep.org:80","/blrs/index.html");
}
