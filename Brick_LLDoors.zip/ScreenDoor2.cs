datablock fxDTSBrickData ( brickScreenDoor2OpenCWData )
{
	brickFile = "./ScreenDoor2openCW.blb";
	uiName = "Screen Door 2";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickScreenDoor2CWData";
	openCW = "brickScreenDoor2OpenCWData";
	
	closedCCW = "brickScreenDoor2CWData";
	openCCW = "brickScreenDoor2OpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickScreenDoor2OpenCCWData : brickScreenDoor2OpenCWData )
{
	brickFile = "./ScreenDoor2openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickScreenDoor2CWData : brickScreenDoor2OpenCWData )
{
	brickFile = "./ScreenDoor2closed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/ScreenDoor2";
	
	isOpen = 0;
};