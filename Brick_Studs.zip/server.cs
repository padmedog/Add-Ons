datablock fxDTSBrickData (brick1x1fStudData)
{
	brickFile = "./1x1fStud.blb";
	canCover = true;
	category = "Special";
	subCategory = "Studs";
	uiName = "1x1F Stud";
	iconName = "Add-Ons/Brick_Studs/1x1FStud";
};

datablock fxDTSBrickData (brick1x2fStudData)
{
	brickFile = "./1x2fStud.blb";
	canCover = true;
	category = "Special";
	subCategory = "Studs";
	uiName = "1x2F Studs";
	iconName = "Add-Ons/Brick_Studs/1x2FStuds";
};

datablock fxDTSBrickData (brick2x2fStudData)
{
	brickFile = "./2x2fStud.blb";
	canCover = true;
	category = "Special";
	subCategory = "Studs";
	uiName = "2x2F Studs";
	iconName = "Add-Ons/Brick_Studs/2x2FStuds";
};


datablock fxDTSBrickData (brick2x4fStudData)
{
	brickFile = "./2x4fStud.blb";
	canCover = true;
	category = "Special";
	subCategory = "Studs";
	uiName = "2x4F Studs";
	iconName = "Add-Ons/Brick_Studs/2x4FStuds";
};


datablock fxDTSBrickData (brick4x4fStudData)
{
	brickFile = "./4x4fStud.blb";
	canCover = true;
	category = "Special";
	subCategory = "Studs";
	uiName = "4x4F Studs";
	iconName = "Add-Ons/Brick_Studs/4x4FStuds";
};


datablock fxDTSBrickData (brick8x8fStudData)
{
	brickFile = "./8x8fStud.blb";
	canCover = true;
	category = "Special";
	subCategory = "Studs";
	uiName = "8x8F Studs";
	iconName = "Add-Ons/Brick_Studs/8x8FStuds";
};

