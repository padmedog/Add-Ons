if (!isObject(PermissionsGui))
    exec("./client/PermissionsGui.gui");
if (!isObject(PermissionsNewRoleGui))
    exec("./client/PermissionsNewRoleGui.gui");
if (!isObject(PermissionsBLIDGui))
    exec("./client/PermissionsBLIDGui.gui");

exec("./Updater_Client.cs");

$remapDivision[$remapCount] = "Permissions Mod";
$remapName[$remapCount] = "Open Gui";
$remapCmd[$remapCount] = "PermGui_keyPress";
$remapCount++;

function PermGui_keyPress(%down)
{
    if(%down)
    {
        if(!PermissionsGui.isAwake() && $PermGUI::Server)
            canvas.pushDialog(PermissionsGui);
        else
            canvas.popDialog(PermissionsGui);
    }
}

PermissionsGui_value.add("No", -1);
PermissionsGui_value.add("Inherit", 0);
PermissionsGui_value.add("Yes", 1);

function clientCmdPermGUI(%arg1, %arg2, %arg3, %arg4)
{
    $PermGUI::Server = true;
    if(%arg1 $= "ROLE")
    {
        if(%arg2 !$= "")
        {
            PermissionsGui_roles.addRow(PermissionsGui_roles.rowCount(), %arg2);
            PermissionsGui_roles.sort(0);
        }
    }
    else if(%arg1 $= "PERM")
    {
        if(%arg2 !$= "")
        {
            %fn = getField(%arg2, 0);
            %cn = getField(%arg2, 1);
            PermissionsGui_values.addRow(PermissionsGui_values.rowCount(), (%fn !$= "" ? (%fn SPC "(" @ %cn @ ")") : %cn) TAB %cn);
            PermissionsGui_values.sort(0);
        }
    }
    else if(%arg1 $= "VALUE")
    {
        if(%arg2 !$= "")
            PermissionsGui_value.setSelected(%arg2);
    }
    else if(%arg1 $= "CLEAR")
    {
        if(%arg2 $= "PLAYERS")
            PermissionsGui_players.clear();
        else
        {
            PermissionsGui_players.clear();
    	    PermissionsGui_values.clear();
	        PermissionsGui_roles.clear();
        }
    }
    else if(%arg1 $= "PLAYER")
    {
        if(%arg2 !$= "")
        {
            PermissionsGui_players.addRow(PermissionsGui_players.rowCount(), %arg3 TAB %arg2);
            PermissionsGui_players.sortNumerical(0);
        }
    }
    else if(%arg1 $= "REMROLE")
    {
        if(%arg2 !$= "")
            PermissionsGui_roles.removeRow(PermissionsGui_roles.findTextIndex(%arg2));
    }
}

//================================
// PermissionsGui Lists
//================================

function PermissionsGui_values::onSelect(%this, %id, %perm)
{
    %perm = getField(%perm, 1);
	PermissionsGui_players.setValue(-1);

    if(PermissionsGui_roles.getValue() !$= "")
        commandtoserver('permgui', "GETPERM", PermissionsGui_roles.getValue(), %perm);
}

function PermissionsGui_players::onSelect(%this, %id, %name)
{
	PermissionsGui_values.setValue(-1);
}

function PermissionsGui_roles::onSelect(%this, %id, %name)
{
    if(PermissionsGui_values.getValue() != -1 && (%perm = PermissionsGui_values.getValue()) !$= "")
    {
        commandtoserver('permgui', "GETPERM", PermissionsGui_roles.getValue(), getField(%perm, 1));
    }
    commandtoserver('permgui', "GETPLAYERS", PermissionsGui_roles.getValue());
}

//================================
// PermGui functions
//================================

function PermGui_setValue()
{
    %value = PermissionsGui_value.getValue();
    if(%value $= "No")
        %val = -1;
    else if(%value $= "Inherit")
        %val = 0;
    else if(%value $= "Yes")
        %val = 1;

    if(PermissionsGui_roles.getValue() !$= "" && (%perm = PermissionsGui_values.getValue()) !$= "")
        commandtoserver('permgui', "SETPERM", PermissionsGui_roles.getValue(), getField(%perm, 1), %val);
}

function PermGui_createRole()
{
    canvas.pushDialog(PermissionsNewRoleGui);
}

function PermGui_createRoleAccept()
{
    if(PermGui_roleName.getValue() !$= "")
    {
        commandtoserver('permgui', "NEWROLE", PermGui_roleName.getValue());
        canvas.popDialog(PermissionsNewRoleGui);
    }
}

function PermGui_deleteRole()
{
    %yes = "commandtoserver('permgui', \"DELROLE\", " @ PermissionsGui_roles.getValue() @ ");";
    if(PermissionsGui_roles.getValue() !$= "")
        messageBoxYesNo("Delete Role", "Do you really want to delete role \"" @ PermissionsGui_roles.getValue() @ "\"?", %yes);
}

function PermGui_setDefault()
{
    if(PermissionsGui_players.getValue() !$= "")
        commandtoserver('permgui', "SETROLE", getField(PermissionsGui_players.getValue(), 1), "Default");
}

function PermissionsBLIDGui::onWake(%this) {
    PermissionsGui_roleBLIDSelector.clear();
    PermissionsGui_roleBLIDSelector.add("Please select...", -2);
    PermissionsGui_roleBLIDSelector.add("Other", -1);

    commandToServer('openPlayerList');
    commandToServer('closePlayerList');

    %rows = NPL_List.rowCount();
    for (%i = 0 ; %i < %rows ; %i++) {
        %line = NPL_List.getRowText(%i);

        %blid = getField(%line, 3); //NPL_List.getRowId(%i);
        %name = getField(%line, 1);

        PermissionsGui_roleBLIDSelector.add(%blid SPC "-" SPC %name, %blid);
    }

    PermissionsGui_roleBLIDManualBack.onClick();
}

function PermissionsGui_roleBLIDManualBack::onClick(%this) {
    PermissionsGui_roleBLIDSelector.setSelected(-2);
    PermissionsGui_roleBLIDOKBlocker.setVisible(true);

    PermissionsGui_roleBLID.setVisible(false);
    PermissionsGui_roleBLIDManualBack.setVisible(false);
    PermissionsGui_roleBLIDSelector.setVisible(true);
}

function PermissionsGui_roleBLIDSelector::onSelect(%this, %id, %text) {
    if (%id $= -2) {
        PermissionsGui_roleBLIDOKBlocker.setVisible(true);
    } else {
        PermissionsGui_roleBLIDOKBlocker.setVisible(false);

        if (%id $= -1) {
            PermissionsGui_roleBLID.setValue("");

            PermissionsGui_roleBLID.setVisible(true);
            PermissionsGui_roleBLIDManualBack.setVisible(true);
            PermissionsGui_roleBLIDSelector.setVisible(false);
        } else
            PermissionsGui_roleBLID.setValue(%id);
    }
}

function PermGui_addToRoleAccept()
{
    if((%id = PermissionsGui_roleBLID.getValue()) !$= "" && PermissionsGui_roles.getValue() !$= "")
    {
        PermissionsGui_roleBLID.setValue("");
        canvas.popDialog(PermissionsBLIDGui);

        commandtoserver('permgui', "SETROLE", %id, PermissionsGui_roles.getValue());
    }
}

//================================
// Package
//================================

package PermGui_Client_Package
{
    function disconnect(%a)
    {
        parent::disconnect(%a);
        PermissionsGui_players.clear();
        PermissionsGui_roles.clear();
        PermissionsGui_values.clear();
        $PermGUI::Server = false;
    }
};

activatePackage(PermGui_Client_Package);
