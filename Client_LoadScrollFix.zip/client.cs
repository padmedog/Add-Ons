package LoadScrollFix
{
    function scrollInventory(%value)
    {
        %name = "ProgressGui";
        %id = nameToID(%name);
        %id.setName("FrameOverlayGui");
        Parent::scrollInventory(%value);
        %id.setName(%name);
    }
};

activatePackage("LoadScrollFix");
