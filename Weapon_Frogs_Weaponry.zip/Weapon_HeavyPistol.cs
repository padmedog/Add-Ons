//audio

AddDamageType("heavypistol",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/ci_HeavyPistol> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/ci_HeavyPistol> %1',0.75,1);
datablock ProjectileData(heavypistolProjectile1)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 19;
   directDamageType    = $DamageType::heavypistol;
   radiusDamageType    = $DamageType::heavypistol;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 150; //150
   verticalImpulse     = 200;
   explosion           = gunExplosion;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(heavypistolItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./HeavyPistol.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Heavy Pistol";
	iconName = "./icon_HeavyPistol";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = heavypistolImage;
	canDrop = true;
	
	maxAmmo = 12;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(heavypistolImage)
{
   // Basic Item properties
   shapeFile = "./HeavyPistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = heavypistolItem;
   ammo = " ";
   projectile = heavypistolProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.5 0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = heavypistolItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.075;
	stateFire[2]                    = true;
	statesequence[2]                = "Fire";
    stateAllowImageChange[2]        = false;
    stateEjectShell[2]      = true;	
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= HeavySMGFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1; //0.05
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]        = 0.01;
	stateTransitionOnTimeout[3] = "LoadCheckA";


	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "ReloadWait";
	
	stateName[6]				= "ReloadWait";
	stateTimeoutValue[6]			= 0.25;
	stateScript[6]				= "";
	stateTransitionOnTimeout[6]		= "ReloadStart";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "ReloadStart";
	stateTimeoutValue[7]			= 0.5;
	stateScript[7]				= "onReloadStart";
		stateTransitionOnTimeout[7]		= "Reloaded";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "Reloaded";
	stateTimeoutValue[8]			= 0.3;
        stateScript[8]				= "onReloaded";
        stateTransitionOnTimeout[8]		= "AmmoCheck";
		
	stateName[9]                    = "SliderClose";
	stateTimeoutValue[9]            = 0.3;
	stateScript[9]                   = "OnSliderClose";
	stateSound[9]                    = "PistolPullBackSound";
	stateSequence[9]                 = "Fire";
	stateTransitionOnTimeout[9]       = "Ready";
	
	stateName[10]                     = "AmmoCheck";
	stateTransitionOnNoAmmo[10]       = "ReloadStart";
	stateTransitionOnAmmo[10]         = "SliderClose";
      
};

function heavypistolImage::onFire(%this,%obj,%slot)
{
	%projectile = heavypistolProjectile1;
	%spread = 0.0025;
	%shellcount = 1;

	%obj.playThread(2, shiftAway); //plant
	%shellcount = 1;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.45 Caliber <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["45caliber"] @ "", 1, 2, 3, 4); 
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 5 * 3.1415926 * %spread; //10
		%y = (getRandom() - 0.5) * 5 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 5 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function heavypistolImage::onReloadStart(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.45 Caliber <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["45caliber"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["45caliber"] >= 1)
	{
	%obj.playThread(2, shiftLeft);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function heavypistolImage::onReloadWait(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.45 Caliber <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["45caliber"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["45caliber"] >= 1)
	{
	            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
            //serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
            //serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
            //serverPlay3D(Block_changeBrick_Sound,%obj.getPosition());
	%obj.playThread(2, plant);
	}
}

function heavypistolImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["45caliber"] >= 1)
	{

        if(%obj.client.quantity["45caliber"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["45caliber"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.playThread(2, plant);
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.45 Caliber <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["45caliber"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["45caliber"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["45caliber"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.playThread(2, plant);
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["45caliber"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.45 Caliber <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["45caliber"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}


function heavypistolProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.setVelocity(getWord(%col.getVelocity(),0)/1.1 SPC getWord(%col.getVelocity(),1)/1.1 SPC getWord(%col.getVelocity(),1.1));
   }
parent::damage(%this,%obj,%col,%fade,%pos,%normal);
}

function heavypistolImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.45 Caliber <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["45caliber"] @ "", 1, 2, 3, 4); 
}

function heavypistolImage::onUnMount(%this,%obj,%slot)
{
	%obj.playThread(2, root);
}

function heavypistolImage::onSliderClose(%this,%obj,%slot)
{
	%obj.playThread(2, Plant);
}