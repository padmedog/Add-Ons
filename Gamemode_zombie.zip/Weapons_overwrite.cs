%errorA = ForceRequiredAddOn("Weapon_Sniper_Rifle");
if(%errorA != $Error::AddOn_Disabled && %errorA != $Error::AddOn_NotFound)
{
	datablock ShapeBaseImageData(SniperRifleImageNoFire : gunImageNoFire)
	{
		shapeFile = "Add-Ons/Weapon_Sniper Rifle/SniperRifle.dts";
		RWep = "SniperRifleImage";
		projectile = SniperRifleProjectile;
		doColorShift = SniperRifleItem.doColorShift;
		colorShiftColor = SniperRifleItem.colorShiftColor;//"0.400 0.196 0 1.000";
	};
}

%errorB = ForceRequiredAddOn("Weapon_Shotgun");
if(%errorB != $Error::AddOn_Disabled  && %errorB != $Error::AddOn_NotFound)
{
	datablock ShapeBaseImageData(ShotgunImageNoFire : gunImageNoFire)
	{
		shapeFile = "Add-Ons/Weapon_Shotgun/Shotgun.dts";
		RWep = "ShotgunImage";
		eyeOffset = ShotgunImage.eyeOffset;
		projectile = ShotgunProjectile;
		doColorShift = ShotgunItem.doColorShift;
		colorShiftColor = ShotgunItem.colorShiftColor;//"0.400 0.196 0 1.000";
	};
}

%errorC = ForceRequiredAddOn("Weapon_Minigun");
if(%errorC == $Error::AddOn_Disabled  || %errorC == $Error::AddOn_NotFound)
{
	return;
}
	datablock ShapeBaseImageData(MinigunImageNoFire : gunImageNoFire)
	{
		shapeFile = "Add-Ons/Weapon_Minigun/Minigun.dts";
		RWep = "MinigunImage";
		eyeOffset = MinigunImage.eyeOffset;
		projectile = MinigunProjectile;
		doColorShift = MinigunItem.doColorShift;
		colorShiftColor = MinigunItem.colorShiftColor;//"0.400 0.196 0 1.000";

	   stateName[0]                    		= "Ready";
	   stateSequence[0]				= "Ready";
	   stateTransitionOnTriggerDown[0] 		= "Fire";
	   stateAllowImageChange[0]             = true;

	   stateName[1]                    		= "Fire";
	   stateSequence[1]				= "Spin";
	   stateSound[1]			  	= NoAmmoClickSound;
	   stateScript[1]                  = "onFire";
	   stateTransitionOnTimeout[1]     		= "Ready";
	   stateTimeoutValue[1]            		= 0.2;
	};
	package ZMinigunOver
	{
		function minigunImage::onUnMount(%this,%obj,%slot)
		{
			Parent::onUnMount(%this,%obj,%slot);	
				%obj.playThread(0, root);
		}
		function minigunImageNoFire::onUnMount(%this,%obj,%slot)
		{
			Parent::onUnMount(%this,%obj,%slot);	
				%obj.playThread(0, root);
		}
	};
	ActivatePackage(ZMinigunOver);