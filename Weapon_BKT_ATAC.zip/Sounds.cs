//if(isFile("Add-Ons/Weapon_Blockombat/effects.cs"))
//{
//return;
//}
//else
//{
//datablock AudioProfile(shellhubopenSound)
//{
//   filename    = "./shellhub_open.wav";
//   description = shortRange3d;
//   preload = true;
//};
//datablock AudioProfile(shellhubcloseSound)
//{
//   filename    = "./shellhub_close.wav";
//   description = shortRange3d;
//   preload = true;
//};
//datablock AudioProfile(shelldropSound)
//{
//   filename    = "./shelldrop.wav";
//   description = shortRange3d;
//   preload = true;
//};
datablock AudioDescription(BulletWhizzingLoop3d : AudioDefaultLooping3d)
{
	isLooping= true;
	maxDistance = 15;
	referenceDistance = 7.5;
};
datablock AudioProfile(BulletWhizzingSound)
{
   filename = "./bulletWhiz.wav";
   description = BulletWhizzingLoop3d;
   preload = false;
};
datablock AudioDescription(ShortRange3d : AudioClose3d)
{
	maxDistance = 15;
	referenceDistance = 10;
};
datablock AudioProfile(pistolLightMagOutSound)
{
   filename = "./pistolLightOut.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(pistolLightMagInSound)
{
   filename = "./pistolLightIn.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(pistolMagOutSound)
{
   filename = "./pistolOut.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(pistolMagInSound)
{
   filename = "./pistolIn.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(RifleHeavyMagOutSound)
{
   filename = "./RifleHeavyOut.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(RifleHeavyMagInSound)
{
   filename = "./RifleHeavyIn.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(RifleMagOutSound)
{
   filename = "./RifleOut.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(RifleMagInSound)
{
   filename = "./RifleIn.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(BoltOutSound)
{
   filename = "./BoltOut.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(BoltInSound)
{
   filename = "./BoltIn.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(ShellInSound)
{
   filename = "./ShellIn.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(Pump2Sound)
{
   filename = "./Pump2.wav";
   description = ShortRange3d;
   preload = false;
};
datablock AudioProfile(Pump3Sound)
{
   filename = "./Pump3.wav";
   description = ShortRange3d;
   preload = false;
};
//}
datablock AudioDescription(GunshotRange3d : AudioClose3d)
{
	maxDistance = 60;
	referenceDistance = 20;
};
datablock AudioDescription(LongRange3d : AudioClose3d)
{
	maxDistance = 120;
	referenceDistance = 25;
};