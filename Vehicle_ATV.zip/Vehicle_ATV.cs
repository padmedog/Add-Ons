datablock AudioProfile(ATVGoSound)
{
   filename    = "./sounds/ATV_go.wav";
   description = AudioDefaultLooping3d;
   preload = true;
};

datablock AudioProfile(ATVIdleSound)
{
   filename    = "./sounds/ATV_idle.wav";
   description = AudioDefaultLooping3d;
   preload = true;
};

datablock ParticleData(ATVDustParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.6;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 20;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.6 0.6 0.6 0.2";
	colors[1]     = "0.6 0.6 0.6 0.0";
	sizes[0]      = 0.5;
	sizes[1]      = 0.6;

	useInvAlpha = true;
};

datablock ParticleEmitterData(ATVDustEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 4;
   ejectionVelocity = 3;
   velocityVariance = 2;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 50;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ATVDustParticle";

   uiName = "ATV Dust";
};

datablock WheeledVehicleTire(ATVTire)
{
shapeFile = "./shapes/ATVTire.dts";
staticFriction = 5;
kineticFriction = 20;
restitution = 0.5;	

// Spring that generates lateral tire forces
lateralForce = 18000;
lateralDamping = 4000;
lateralRelaxation = 0.01;

// Spring that generates longitudinal tire forces
longitudinalForce = 18000;
longitudinalDamping = 4000;
longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleSpring(ATVSpring)
{
// Wheel suspension properties
length = 0.2;                // Suspension travel
force = 4000;              // Spring force
damping = 1000;             // Spring damping
antiSwayForce = 2;        // Lateral anti-sway force
};

datablock WheeledVehicleData(ATVVehicle)
{
category = "Vehicles";
displayName = "";
shapeFile = "./shapes/ATV.dts";
emap = true;
minMountDist = 3;
   
numMountPoints = 1;
mountThread[0] = "armreadyboth";
//mountThread[1] = "sit";

maxDamage = 50.00;
destroyedLevel = 50.00;
speedDamageScale = 1.04;
collDamageThresholdVel = 20.0;
collDamageMultiplier   = 0.02;

massCenter = "0 0 0";
//massBox = "2 5 1";

maxSteeringAngle = 0.8;
integration = 4;
tireEmitter = ATVDustEmitter;

	// 3rd person camera settings
	cameraRoll = true;         // Roll the camera with the vehicle
	cameraMaxDist = 9;         // Far distance from vehicle
	cameraOffset = 1.5;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.4;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

useEyePoint = false;	

defaultTire	= ATVTire;
defaultSpring	= ATVSpring;
flatTire	= JeepTire;
flatSpring	= JeepFlatSpring;

numWheels = 4;

	// Rigid Body
	mass = 300;
	density = 5.0;
	drag = 1.6;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 12000; //4000;       // Engine power
	engineBrake = 2000;         // Braking when throttle is 0
	brakeTorque = 10000;        // When brakes are applied
	maxWheelSpeed = 30;        // Engine scale by current speed / max speed

	rollForce		= 500;
	yawForce		= 500;
	pitchForce		= 1000;
	rotationalDrag		= 20;

   // Advanced Steering
   steeringAutoReturn = true;
   steeringAutoReturnRate = 0.9;
   steeringAutoReturnMaxSpeed = 10;
   steeringUseStrafeSteering = true;
   steeringStrafeSteeringRate = 0.1;

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

uiName = "ATV ";
	rideable = true;
		lookUpLimit = 0.65;
		lookDownLimit = 0.45;

	paintable = true;
   
   damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

   initialExplosionProjectile = jeepExplosionProjectile;
   initialExplosionOffset = 0;         //offset only uses a z value for now

   burnTime = 4000;

   finalExplosionProjectile = jeepFinalExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now

   minRunOverSpeed    = 4;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 8;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed

   //protection for passengers
   protectPassengersBurn   = false;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = false; //protect passengers from direct damage (bullets) ?
};

datablock ParticleData(ATVExhaustParticle)
{
   textureName          = "base/data/particles/cloud";
   dragCoefficient      = 0.0;
   windCoefficient      = 0.5;
   gravityCoefficient   = -0.5; 
   inheritedVelFactor   = 0.2;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 0;
   useInvAlpha = true;
   spinRandomMin = 0.0;
   spinRandomMax = 0.0;

   colors[0]     = "0.7 0.5 0.2 0.7";
   colors[1]     = "0.5 0.5 0.5 0.07";

   sizes[0]      = 0.20;
   sizes[1]      = 0.20;

   times[0]      = 0;
   times[1]      = 0.1;
};

datablock ParticleEmitterData(ATVExhaustEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ATVExhaustParticle";
};

datablock ShapeBaseImageData(ATVExhaustImage1)
{
   shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 2;
   rotation = "1 0 0 -90";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateEmitter[1]					= ATVExhaustEmitter;
	stateEmitterTime[1]				= 10000;

};

function ATVSmokeCheck(%obj)
{
  %obj.mountImage(ATVExhaustImage1,2);
}

function ATVSpeedCheck(%this, %obj)
{


	if(!isObject(%obj))
		return;

	%vehicle = %obj;
%slot = 0; //Play the sound in the driver's spot
	%speed = vectorLen(%obj.getVelocity());

	if(%speed < 0) //Keeps throwing random negative numbers when train is at dead stop
	    %speed = 0;

	if(%speed < 5)
	    %vehicle.playAudio(%slot, ATVidleSound);

	else if(%speed < 100)
	    %vehicle.playAudio(%slot, ATVGoSound);




	    

	schedule(500,0,"ATVSpeedCheck",%this,%obj);
}

function ATVVehicle::onAdd(%this,%obj)
{
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");

	ATVSmokeCheck(%obj);

	ATVSpeedCheck(%this, %obj);

	//mount the nothing tire and ski spring
	%obj.setWheelTire(0, ATVtire);
	%obj.setWheelTire(1, ATVtire);
	%obj.setWheelTire(2, ATVtire);
	%obj.setWheelTire(3, ATVtire);

	%obj.setWheelSpring(0, ATVSpring);
	%obj.setWheelSpring(1, ATVSpring);
	%obj.setWheelSpring(2, ATVSpring);
	%obj.setWheelSpring(3, ATVSpring);
	
	%obj.setWheelSteering(0,1);
	%obj.setWheelSteering(1,1);
	%obj.setWheelSteering(2,0);
	%obj.setWheelSteering(3,0);
	
	%obj.setWheelPowered(0,false);
	%obj.setWheelPowered(1,false);
	%obj.setWheelPowered(2,true);
	%obj.setWheelPowered(3,true);

	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

function ATVvehicle::onDriverLeave(%this,%obj)
{
	%driver = %obj.getControllingObject();
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
	%driver.client.schedule(0,"applybodyparts");
}

package ATV
{
	function armor::onMount(%this,%obj,%col,%slot)
	{
		Parent::onMount(%this,%obj,%col,%slot);
		if(%col.getDataBlock() == ATVVehicle.getId())
		{
			%t = %obj.activeThread[1];
			if(!(%t $= "armReadyRight" || %t $= "armReadyBoth"))
			{
				%col.unhideNode($rhand[%obj.client.rhand]);
				%col.setNodeColor($rhand[%obj.client.rhand],%obj.client.rhandcolor);
				%obj.hideNode("rhand");
				%obj.hideNode("rhook");
			}
			if(!(%t $= "armReadyLeft" || %t $= "armReadyBoth"))
			{
				%col.unhideNode($lhand[%obj.client.lhand]);
				%col.setNodeColor($lhand[%obj.client.lhand],%obj.client.lhandcolor);
				%obj.hideNode("lhand");
				%obj.hideNode("lhook");
			}
		}
	}
	function GameConnection::applyBodyParts(%this)
	{
		Parent::applyBodyParts(%this);
		%player = %this.player;
		if(isObject(%player) && isObject(%veh = %player.getObjectMount()) && %veh.getDatablock().getID() == ATVVehicle.getID())
		{
			%player.hideNode("lhand");
			%player.hideNode("rhand");
			%player.hideNode("lhook");
			%player.hideNode("rhook");
			%veh.hideNode("lhand");
			%veh.hideNode("rhand");
			%veh.hideNode("lhook");
			%veh.hideNode("rhook");
			%veh.unhideNode($lhand[%this.lhand]);
			%veh.unhideNode($rhand[%this.rhand]);
			%veh.setNodeColor($lhand[%this.lhand],%this.lhandColor);
			%veh.setNodeColor($rhand[%this.rhand],%this.rhandColor);
		}
	}
	function Player::playThread(%player,%slot,%thread)
	{
		Parent::playThread(%player,%slot,%thread);
		%veh = %player.getObjectMount();
		%player.activeThread[%slot] = %thread;
		if(isObject(%veh) && %veh.getDatablock().getID() == ATVVehicle.getID())
		{
			if(%slot == 1)
			{
				if(%thread $= "armReadyRight")
				{
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					%player.unHideNode($rhand[%player.client.rhand]);
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.setNodeColor($lhand[%player.client.lhand],%player.client.lhandColor);
					%player.hideNode("lhand");
					%player.hideNode("lhook");
				} else if(%thread $= "armReadyLeft")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					%player.unHideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($rhand[%player.client.rhand],%player.client.rhandColor);
					%player.hideNode("rhand");
					%player.hideNode("rhook");
				} else if(%thread $= "armReadyBoth")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					%player.unHideNode($lhand[%player.client.lhand]);
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					%player.unHideNode($rhand[%player.client.rhand]);
				} else if(%thread $= "root")
				{
					%player.hideNode("lhand");
					%player.hideNode("rhand");
					%player.hideNode("lhook");
					%player.hideNode("rhook");
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($lhand[%player.client.lhand],%player.client.lhandColor);
					%veh.setNodeColor($rhand[%player.client.rhand],%player.client.rhandColor);
				}
			}
		}
	}
};
activatePackage(ATV);