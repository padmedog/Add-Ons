$RSC::Revision += 1;

new GuiControlProfile(BorderlessScrollProfile : ColorScrollProfile) { border = 0; };

if(isObject(RSC_FabricatorGUI))
	RSC_FabricatorGUI.delete();
new GuiControl(RSC_FabricatorGUI)
{
	visible = 0;
	
	new GuiWindowCtrl(RSC_FabricatorWindow)
	{
		position = "200 100";
		extent = "416 252";
		
		closeCommand = "Canvas.popDialog(RSC_FabricatorGUI); commandToServer('FabberGUIClosed');";
		command = "Canvas.popDialog(RSC_FabricatorGUI); commandToServer('FabberGUIClosed');";
		accelerator = "Escape";
		
		text = "Fabricator Menu";
		
		canMinimize = 0;
		canMaximize = 0;
		resizeHeight = 0;
		resizeWidth = 0;
		
		canMove = 0;  //Temporary, hopefully
		
		new GuiBitmapCtrl()
		{
			position = "8 32";
			extent = "48 48";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Slot";
			
			new GuiBitmapCtrl(Fabber_SlotIn1)
			{
				position = "0 0";
				extent = "48 48";
			
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = " ";
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberRemoveItem', 0);";
				};
			};
		};
		
		new GuiBitmapCtrl()
		{
			position = "60 32";
			extent = "48 48";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Slot";
			
			new GuiBitmapCtrl(Fabber_SlotIn2)
			{
				position = "0 0";
				extent = "48 48";
			
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = " ";
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberRemoveItem', 1);";
				};
			};
		};
		
		new GuiBitmapCtrl()
		{
			position = "112 32";
			extent = "48 48";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Slot";
			
			new GuiBitmapCtrl(Fabber_SlotIn3)
			{
				position = "0 0";
				extent = "48 48";
			
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = " ";
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberRemoveItem', 2);";
				};
			};
		};
		
		new GuiSwatchCtrl(RSC_FabberArrow)
		{
			position = "160 44";
			extent = "8 40";
			
			color = "255 255 255 255";
		};
		
		new GuiBitmapCtrl()
		{
			position = "160 44";
			extent = "80 40";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Arrow Negative";
		};
		
		new GuiBitmapCtrl()
		{
			position = "240 32";
			extent = "48 48";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Slot";
			
			new GuiBitmapCtrl(Fabber_SlotOut1)
			{
				position = "0 0";
				extent = "48 48";
			
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = " ";
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberRemoveItem', 3);";
				};
			};
		};
		
		new GuiBitmapCtrl()
		{
			position = "292 32";
			extent = "48 48";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Slot";
			
			new GuiBitmapCtrl(Fabber_SlotOut2)
			{
				position = "0 0";
				extent = "48 48";
			
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = " ";
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberRemoveItem', 4);";
				};
			};
		};
		
		new GuiBitmapCtrl()
		{
			position = "344 32";
			extent = "48 48";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Slot";
			
			new GuiBitmapCtrl(Fabber_SlotOut3)
			{
				position = "0 0";
				extent = "48 48";
			
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = " ";
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberRemoveItem', 5);";
				};
			};
		};
		
		new GuiSwatchCtrl()
		{
			position = "8 85";
			extent = "384 2";
			
			color = "150 150 150 255";
		};
		
		new GuiScrollCtrl()
		{
			position = "8 92";
			extent = "220 154";
			
			profile = "BorderlessScrollProfile";
			
			hScrollBar = "AlwaysOff";
			vScrollBar = "Dynamic";
			
			new GuiSwatchCtrl(RSC_FabMatsMenu)
			{
				position = "0 0";
				extent = "204 48";
				
				color = "0 0 0 0";
			};
		};
		
		new GuiScrollCtrl()
		{
			position = "240 92";
			extent = "168 154";
			
			profile = "BorderlessScrollProfile";
			
			hScrollBar = "AlwaysOff";
			vScrollBar = "Dynamic";
			
			new GuiSwatchCtrl(RSC_FabRecipeMenu)
			{
				position = "0 0";
				extent = "152 48";
				
				color = "0 0 0 0";
			};
		};
		
		new GuiSwatchCtrl(FabberLockedGrayOut)
		{
			position = "8 32";
			extent = "384 160";
			
			color = "200 200 200 128";
			visible = 0;
		};
		
		new GuiBitmapCtrl(FabberDropdownMerge)
		{
			position = "248 248";
			extent = "168 4";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Dropdown Merge";
		};
	};
	
	new GuiSwatchCtrl(FabberLockInfo)
	{
		position = "448 352";
		extent = "168 80";
		
		color = "0 0 0 0";
		
		new GuiBitmapCtrl()
		{
			position = "0 0";
			extent = "168 8";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Dropdown Menu";
			wrap = 1;
			
			new GuiTextCtrl(FabberInitLockText)
			{
				position = "8 11";
				extent = "152 20";
				
				text = "Start Lock: ";
			};
			
			new GuiTextEditCtrl(FabberInitLockEdit)
			{
				position = "64 11";
				extent = "24 20";
				
				maxLength = 3;
				command = "RSC_UpdateFabberLockTime(FabberInitLockEdit);";
				lockSetting = "StartLockTime";
			};
			
			new GuiCheckboxCtrl(FabberLockDuringBurn)
			{
				position = "8 26";
				extent = "152 20";
				
				text = "Burning Lock";
				command = "FabberLockDuringBurn.UpdateBurnLock();";
			};
			
			new GuiTextCtrl(FabberEndLockText)
			{
				position = "8 43";
				extent = "152 20";
				
				text = "End Lock: ";
			};
			
			new GuiTextEditCtrl(FabberEndLockEdit)
			{
				position = "64 43";
				extent = "24 20";
				
				maxLength = 3;
				command = "RSC_UpdateFabberLockTime(FabberEndLockEdit);";
				lockSetting = "EndLockTime";
			};
			
			new GuiTextCtrl(FabberEndLockText)
			{
				position = "96 6";
				extent = "68 20";
				
				text = "Trust Level: ";
			};
			
			new GuiPopupMenuCtrl(FabberTrustLevelEdit)
			{
				position = "98 23";
				extent = "50 20";
				
				command = "commandToServer('FabberSetSetting', \"TrustLevel\", FabberTrustLevelEdit.getSelected());";
			};
		};
		
		new GuiBitmapCtrl()
		{
			position = "0 8";
			extent = "168 8";
			
			bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Dropdown Bottom";
		};
		
		new GuiTextCtrl(FabberLockText)
		{
			position = "8 -5";
			extent = "152 20";
			
			text = "Unlocked";
		};
	};
};

FabberTrustLevelEdit.add("Anyone", 0);
FabberTrustLevelEdit.add("Build Trust", 1);
FabberTrustLevelEdit.add("Full Trust", 2);
FabberTrustLevelEdit.add("Only Me", 3);

package RSC_FabberGUI
{
	function clientcmdUpdateMaterial(%amt, %mat)
	{
		%list = RSC_FabMatsMenu;
		%count = %list.getCount();
		for(%i=0;%i<%count;%i++)
		{
			%slot = %list.getObject(%i);
			if(%slot.item $= ("Mat_"@%mat))
			{ %matSlot = %slot; break; }
			if(%slot.item $= "" && !isObject(%empty))
				%empty = %slot;
		}
		if(isObject(%matSlot))
		{
			if(%amt == 0)
			{
				%matSlot.setBitmap("Add-ons/Client_RealisticSpace/GUIs/Empty Slot");
				%matSlot.getObject(0).setText("<just:center>");
				%matSlot.item = ""; %matSlot.amount = "";
			}
			else
			{
				%matSlot.amount = %amt;
				%matSlot.getObject(0).setText("<just:center>"@%amt);
			}
		}
		else if(%amt == 0) { }
		else if(isObject(%empty))
		{
			%empty.item = "Mat_"@%mat; %empty.amount = %amt;
			%empty.setBitmap("Add-Ons/Client_RealisticSpace/GUIs/Fabber Icons/Mat_"@%mat);
			%empty.getObject(0).setText("<just:center>"@%amt);
			%empty.getObject(1).command = "commandToServer('FabberInsertItem', \"Mat "@%mat@"\");";
		}
		else
		{
			%x = %count % 4;
			%y = (%count - %x) / 4;
			%xPos = %x * 52;
			%yPos = %y * 52;
			%pos = %xPos SPC %yPos;
			%button = new GuiBitmapCtrl()
			{
				position = %pos;
				extent = "48 48";
				
				bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Icons/Mat_"@%mat;
				
				new GuiMLTextCtrl()
				{
					position = "0 32";
					extent = "48 12";
					
					text = "<just:center>"@%amt;
				};
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					text = " "; command = "commandToServer('FabberInsertItem', \"Mat "@%mat@"\");";
				};
			};
			%button.item = "Mat_"@%mat;
			%button.amount = %amt;
			%list.add(%button);
			%list.resize(0, 0, 204, %yPos + 48);
		}
		Parent::clientcmdUpdateMaterial(%amt, %mat);
	}
	
	function disconnect(%a)
	{
		%list = RSC_FabMatsMenu;
		%count = %list.getCount();
		for(%i=%count-1;%i>=0;%i--)
			%list.getObject(%i).delete();
		%list.resize(0, 0, 204, 48);
		return parent::disconnect(%a);
	}
};
activatePackage("RSC_FabberGUI");

function RSC_UpdateFabberLockTime(%this)
{
	if(%this.getValue() $= "")
		%this.setValue(0);
	%pos = %this.getCursorPos();
	%text = %this.getValue();
	%len = strLen(%text);
	%valid = "0123456789";
	for(%i=0;%i<%len;%i++)
	{
		%char = getSubStr(%text, %i, 1);
		if(strPos(%valid, %char) == -1 && %i < %pos) %shift++;
		else %final = %final @ %char;
	}
	%this.setValue(%final + 0);
	%this.setCursorPos(%pos - %shift);
	commandToServer('FabberSetSetting', %this.LockSetting, %this.getValue());
}

function FabberLockDuringBurn::UpdateBurnLock(%this)
{ commandToServer('FabberSetSetting', "BurningLock", %this.getValue()); }

function RSC_FabberArrow::burnUpdate(%arrow, %progress, %total, %last)
{
	cancel(%arrow.burnSched);
	%time = vectorDist(%last, %now = getSimTime()) / 1000;
	%progress += %time; %percent = mClampF(%progress / %total, 0, 1);
	if(%percent >= 1) { %arrow.resize(160, 44, 8, 40); return; }
	%arrow.resize(160, 44, 8 + mFloatLength(%percent * 64, 0), 40);
	%arrow.burnSched = %arrow.schedule(16, "burnUpdate", %progress, %total, %now);
}

function FabberLockText::lockUpdate(%text, %name, %timeLeft, %last)
{
	cancel(%text.lockSched);
	%time = vectorDist(%last, %now = getSimTime()) / 1000;
	%timeLeft -= %time;
	if(%timeLeft <= 0)
	{
		%text.setValue("Unlocked");
		FabberLockedGrayOut.setVisible(0);
		return;
	}
	%text.setValue(%name@" ("@mCeil(%timeLeft)@"s)");
	%text.lockSched = %text.schedule(16, "lockUpdate", %name, %timeLeft, %now);
}

function clientcmdOpenFabberGUI(%cl)
{
	Canvas.pushDialog(RSC_FabricatorGUI);
	commandToServer('listMats', 1);   //Need to make a better fix server-sided
}
function clientcmdCloseFabberGUI(%cl)
{ Canvas.popDialog(RSC_FabricatorGUI); }

function clientcmdFabberBurnTime(%progress, %total)
{
	cancel(RSC_FabberArrow.burnSched);
	RSC_FabberArrow.burnUpdate(%progress, %total, getSimTime());
}

function clientcmdFabberLockHolder(%name, %timeLeft, %isLockHolder, %fabberProperties)
{
	cancel(FabberLockText.lockSched);
	FabberLockedGrayOut.setVisible(!%isLockHolder);
	if(%timeLeft < 0) { FabberLockText.setValue(%name); return; }
	FabberLockText.lockUpdate(%name, %timeLeft, getSimTime());
	if(%fabberProperties $= "")
	{
		FabberLockInfo.getObject(0).resize(0, 0, 168, 8);
		FabberLockInfo.getObject(1).resize(0, 8, 168, 8);
	}
	else
	{
		FabberLockInfo.getObject(0).resize(0, 0, 168, 61);
		FabberLockInfo.getObject(1).resize(0, 61, 168, 8);
		FabberInitLockEdit.setValue(getWord(%fabberProperties, 0));
		FabberLockDuringBurn.setValue(getWord(%fabberProperties, 1));
		FabberEndLockEdit.setValue(getWord(%fabberProperties, 2));
		FabberTrustLevelEdit.setText(FabberTrustLevelEdit.getTextByID(getWord(%fabberProperties, 3)));
	}
}

function clientcmdFabberUpdateItem(%slot, %item)
{
	%slot = "Fabber_Slot"@(%slot>=3?"Out"@%slot-2:"In"@%slot+1);
	if(!isObject(%slot)) return;
	%type = firstWord(%item);
	%item = restWords(%item);
	%words = getWordCount(%item);
	switch$(%type)
	{
		case "Mat":
			%mat = getWords(%item, 0, %words - 2); %amt = getWord(%item, %words - 1);
			%slot.setBitmap("Add-Ons/Client_RealisticSpace/GUIs/Fabber Icons/Mat_"@%mat);
			if(%amt $= "Ghost") { %slot.setColor("1 1 1 0.5"); %amt = ""; }
			else %slot.setColor("1 1 1 1");
			%slot.getObject(0).setText("<just:center>"@%amt);
			%slot.item = "Mat_"@%mat; %slot.amount = %amt;
		case "GhostItem":
			%data = $UINameTable_Items[%item]; %slot.setBitmap(%data.iconName);
			%slot.setColor((%data.doColorShift?getWords(%data.colorShiftColor,0,2):"1 1 1")@" 0.5");
			%slot.getObject(0).setText("<just:center>");
			%slot.item = "Item_"@%item; %slot.amount = "";
		case "Item":
			%data = $UINameTable_Items[%item]; %slot.setBitmap(%data.iconName);
			%slot.setColor((%data.doColorShift?getWords(%data.colorShiftColor,0,2):"1 1 1")@" 1");
			%slot.getObject(0).setText("<just:center>");
			%slot.item = "Item_"@%item; %slot.amount = "";
		default:
			%slot.setBitmap("Add-Ons/Client_RealisticSpace/GUIs/Empty Slot");
			%slot.getObject(0).setText("<just:center>");
	}
}

function clientcmdFabberClearRecipes()
{
	%menu = RSC_FabRecipeMenu;
	%count = %menu.getCount();
	for(%i=0;%i<%count;%i++)
	{
		%button = %menu.getObject(%i);
		%button.setBitmap("Add-Ons/Client_RealisticSpace/GUIs/Empty Slot");
	}
	%menu.recipes = 0;
	%menu.resize(0, 0, 152, 48);
}

function clientcmdFabberAddRecipe(%item0, %item1, %item2, %recName)
{
	%menu = RSC_FabRecipeMenu;
	%recipe = -1+%menu.recipes++;
	if(%menu.getCount() < %menu.recipes * 3)
	{
		%yPos = %recipe * 52;
		for(%i=0;%i<3;%i++)
		{
			%color = "1 1 1 1";
			if(%item[%i] $= "") %image = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
			else if(firstWord(%item[%i]) $= "Mat") %image = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Icons/Mat_"@restWords(%item[%i]);
			else if(firstWord(%item[%i]) $= "Item")
			{
				%data = $UINameTable_Items[restWords(%item[%i])]; %image = %data.iconName;
				%color = (%data.doColorShift?getWords(%data.colorShiftColor,0,2):"1 1 1")@" 1";
			}
			%button = new GuiBitmapCtrl()
			{
				position = (%i * 52) SPC %yPos;
				extent = "48 48";
				
				bitmap = %image;
				
				new GuiBitmapButtonCtrl()
				{
					position = "0 0";
					extent = "48 48";
					
					text = " "; bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Blank";
					command = "commandToServer('FabberSelectRecipe', \""@%recName@"\");";
				};
			};
			%button.setColor(%color);
			%menu.add(%button);
		}
		%pos = %menu.getPosition();
		%menu.resize(getWord(%pos, 0), getWord(%pos, 1), getWord(%menu.extent, 0), %yPos + 48);
	}
	else
	{
		for(%i=%recipe*3;%i<3;%i++)
		{
			%color = "1 1 1 1";
			if(%item[%i] $= "") %image = "Add-Ons/Client_RealisticSpace/GUIs/Empty Slot";
			else if(firstWord(%item[%i]) $= "Mat") %image = "Add-Ons/Client_RealisticSpace/GUIs/Fabber Icons/Mat_"@restWords(%item[%i]);
			else if(firstWord(%item[%i]) $= "Item")
			{
				%data = $UINameTable_Items[restWords(%item[%i])]; %image = %data.iconName;
				%color = (%data.doColorShift?getWords(%data.colorShiftColor,0,2):"1 1 1")@" 1";
			}
			%button = %menu.getObject(%i); %button.setBitmap(%image); %button.setColor(%color);
			%button.getObject(0).command = "commandToServer('FabberSelectRecipe', \""@%recName@"\");";
		}
	}
}