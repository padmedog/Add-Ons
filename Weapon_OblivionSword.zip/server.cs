%error = ForceRequiredAddOn("Weapon_Sword");

if(%error == $Error::AddOn_Disabled) { SwordItem.uiName = ""; }
if(%error == $Error::AddOn_NotFound) { error("ERROR: Weapon_OblivionSword - required add-on Weapon_Sword not found!"); }
else {
  exec("./Weapon_OblivionSword.cs");
}
