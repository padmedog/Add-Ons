//> ===>
//> Title: Vehicle Stereo
//> Author: Truce
//> ===>

// Education Version
//  - Comments to clarify parts of code
//  - Code expanded for reading ease

function serverCmdStereo(%client)
{
	%player = %client.player;
	
	if (isObject(%player) == false)
	{
		// Their player isn't spawned/created
		
		return;
	}
	
	%mount = %player.getObjectMount();
	
	if (isObject(%mount) == false)
	{
		// They aren't mounted to anything
		
		return;
	}
	
	%class = %mount.getClassName();
	
	if (%class !$= "WheeledVehicle" && %class !$= "FlyingVehicle")
	{
		// They're mounted to a non-vehicle
		
		return;
	}
	
	if (isObject(%mount.stereoHandler) == false)
	{
		// Need to make the GUI system
		
		%mount.stereoHandler = new fxDTSBrick() {
			client = %client;
			dataBlock = brickMusicData;
			isPlanted = true;
			isStereo = true;
			mount = %mount;
			position = "-10000 -10000 -10000";
		};
	}
	
	// Hacky system of selecting music to follow

	%client.wrenchBrick = %mount.stereoHandler;
	%client.wrenchBrick.sendWrenchSoundData(%client);
	commandToClient(%client,'openWrenchSoundDlg',"Vehicle Stereo",1);
}

package VehicleStereo
{
	function serverCmdSetWrenchData(%client,%data)
	{
		if (%client.wrenchBrick.isStereo == true)
		{
			// If it's a special brick, we play the music
			
			if (isObject(%client.wrenchBrick.mount) == true)
			{
				// If the vehicle still exists, that is
				
				if (getWord(getField(%data,1),1) $= "0")
				{
					// Stop any music if they picked "NONE"
					
					%client.wrenchBrick.mount.stopAudio(0);
				}
				else
				{
					// Otherwise let's play the music they picked
					
					%client.wrenchBrick.mount.playAudio(0,getWord(getField(%data,1),1));
				}
			}
		}
		else
		{
			// Otherwise we let the brick update normally
			
			Parent::serverCmdSetWrenchData(%client,%data);
		}
	}
	
	function WheeledVehicle::delete(%this)
	{
		if (isObject(%this.stereoHandler) == true)
		{
			// Cleaning up the handlers that were made
			
			%this.stereoHandler.delete();
		}
		
		Parent::delete(%this);
	}
	
	function FlyingVehicle::delete(%this)
	{
		if (isObject(%this.stereoHandler) == true)
		{
			// Cleaning up the handlers that were made
			
			%this.stereoHandler.delete();
		}
		
		Parent::delete(%this);
	}
};
activatePackage(VehicleStereo);