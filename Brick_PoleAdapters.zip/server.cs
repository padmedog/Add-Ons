%error = ForceRequiredAddOn("Brick_Pole");

if(%error == $Error::AddOn_Disabled || %error == $Error::AddOn_NotFound)
{
   exec("./Adapters.cs");
}
else
{
   error("ERROR: Brick_PoleAdapters - This add-on does not work if the add-on Brick_Poles is enabled!");
}