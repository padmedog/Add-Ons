$zv=new GameTSCtrl(ZView) {
   profile = "GuiContentProfile";
   horizSizing = "right";
   vertSizing = "bottom";
   position = getword(getres(),0)/4 SPC 0;
   extent = getword(getres(),0)/2 SPC getword(getres(),1)/5;
   minExtent = "8 8";
   visible = "1";
   cameraZRot = "180";
   forceFOV = "0";
      noCursor = "1";
};
PlayGUI.add($zv);
$zviewisopen=1;
function clientcmdzviewvis(%i)
{
	if(%i == 0)
	{
		zview.visible=0;
		$zviewisopen=0;
	}
	else
	{
		zview.visible=1;
		$zviewisopen=1;
	}
}
function servercmdzviewnon(%client,%a)
{
	if(%client.issuperadmin)
	{
		if(%a==0)
		{
			zviewdown();
		}
		else
		{
			zviewup();
		}
	}
}
function zviewdown()
{
	%count=clientGroup.getCount();
	for(%i=0;%i<%count;%i++)
	{
		%c = ClientGroup.getObject(%i);
		if(%c.player)
		{
			commandtoclient(%c,'zviewvis',0);
		}
	}
	$cancelzview=schedule(2000,0,zviewdown);
}
function zviewup()
{
	cancel($cancelzview);
	%count=clientGroup.getCount();
	for(%i=0;%i<%count;%i++)
	{
		%c = ClientGroup.getObject(%i);
		if(%c.player)
		{
			commandtoclient(%c,'zviewvis',1);
		}
	}
}
if (!$zviewbind)
{
   $remapDivision[$remapCount] = "ZView";
   $remapName[$remapCount] = "Open/Close ZView";
   $remapCmd[$remapCount] = "zviewoc";
   $remapCount++;
   $zviewbind=true;
}
function zviewoc(%val)
{
	if(%val){return;}
	if($zviewisopen==1)
	{
		zview.visible=0;
		$zviewisopen=0;
	}
	else
	{
		zview.visible=1;
		$zviewisopen=1;
	}
}