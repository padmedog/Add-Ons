datablock fxLightData(DDNegativeLightAllVerySmall)
{
	uiName = "Anti All Very Small";
	LightOn = true;
	radius = 0;
	brightness = -10;
	color = "1 1 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightAllSmall)
{
	uiName = "Anti All Small";
	LightOn = true;
	radius = 0;
	brightness = -25;
	color = "1 1 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightAllMedium)
{
	uiName = "Anti All Medium";
	LightOn = true;
	radius = 0;
	brightness = -50;
	color = "1 1 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightAllLarge)
{
	uiName = "Anti All Large";
	LightOn = true;
	radius = 0;
	brightness = -100;
	color = "1 1 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightAllVeryLarge)
{
	uiName = "Anti All Very Large";
	LightOn = true;
	radius = 0;
	brightness = -200;
	color = "1 1 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};