datablock ProjectileData(ApocSideGunsProjectile)
{
   projectileShapeName = "add-ons/weapon_gun/bullet.dts";
   directDamage        = 4;
   directDamageType = $DamageType::ApocSideGunDirect;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 50;
   verticalImpulse	  = 50;
   explosion           = gunExplosion;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "";
};

AddDamageType("ApocSidegunDirect",   '<bitmap:add-ons/Vehicle_ApocalypsePack/ApocSidegunCI> %1',       '%2 <bitmap:add-ons/Vehicle_ApocalypsePack/ApocSidegunCI> %1',       1, 1);