datablock AudioProfile(AmmoCrateSound)
{
	filename = "./AmmoCrateSound.wav";
	description = AudioClosest3d;
	preload = true;
};
datablock ItemData(RAmmoCrateItem)
{
	category = "Item";  // Mission editor category
	//className = "Item"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./RotCoAmmoCrate2.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "";
	iconName = "./Icons/RMedKit";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = "";
	canDrop = true;
};
datablock fxDTSBrickData (BrickAmmoCrateData)
{
	brickFile = "./AmmoCrateBrick.blb";
	category = "Special";
	subCategory = "Zombie Bricks";
	uiName = "AmmoCrate";
	iconName = "add-ons/gamemode_zombie/Icons/Icon_AmmoCrate";
	indestructable = 1;
};
function BrickAmmoCrateData::onPlant(%data, %brick)
{
	//%total = %brick.getgroup().AmmoCrateCount;
	if(!%brick.getgroup().AmmoCrateCount)
	{
		%brick.getgroup().AmmoCrateCount = 0;
	}
	if(%brick.getgroup().AmmoCrateCount == 10 && %brick.getgroup().client.isadmin != 1)
	{
		%brick.schedule(0,delete);	
		%brick.getgroup().client.centerprint("<just:center>You already have 10 AmmoCrates planted",3);
		return;
	}
	%brick.getgroup().AmmoCrateCount++;
  %brick.setrendering(0);
  %attach = new Item()
	{
		datablock = "RAmmoCrateItem";
		static = 1;
	};
	%attach.spawnbrick = %brick;
	%attach.schedule(50,setnodecolor,"ALL",getwords(getColorIdTable(%brick.colorid),0,2) SPC "1");
	
  %attach.settransform(vectoradd(%brick.gettransform(),"0 0 -0.4") SPC getwords(%brick.gettransform(),3,6));
  %brick.attachment = %attach;
  parent::onPlant(%data, %brick);
}
function BrickAmmoCrateData::onDeath(%data, %brick)
{
   if(isObject(%brick.attachment))
	{
	  %brick.getgroup().AmmoCrateCount--;
      %brick.attachment.delete();
	}
}

function BrickAmmoCrateData::onRemove(%data, %brick)
{
   if(isObject(%brick.attachment))
	{
	  %brick.getgroup().AmmoCrateCount--;
      %brick.attachment.delete();
	}
}
datablock AudioProfile(HealthLockerOpenSound)
{
	filename = "./lockeropen.wav";
	description = AudioClosest3d;
	preload = true;
};
datablock AudioProfile(HealthLockerCloseSound)
{
	filename = "./lockerclose.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock ItemData(RHealthLockerItem)
{
	category = "Item";  // Mission editor category
	//className = "Item"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./HealthLocker15.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "";
	iconName = "./ItemIcons/RMedKit";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = "";
	canDrop = true;
};
datablock fxDTSBrickData (BrickLockerData)
{
	brickFile = "./LockerBrick.blb";
	category = "Special";
	subCategory = "Zombie Bricks";
	uiName = "Health Locker";
	iconName = "add-ons/gamemode_zombie/Icons/Icon_HealthLocker";
	indestructable = 1;
};
function BrickLockerData::onPlant(%data, %brick)
{
	//%total = %brick.getgroup().HealthLockerCount;
	if(!%brick.getgroup().HealthLockerCount)
	{
		%brick.getgroup().HealthLockerCount = 0;
	}
	if(%brick.getgroup().HealthLockerCount == 10 && %brick.getgroup().client.isadmin != 1)
	{
		%brick.schedule(0,delete);	
		%brick.getgroup().client.centerprint("<just:center>You already have 10 Lockers planted",3);
		return;
	}
	%brick.getgroup().HealthLockerCount++;
  %brick.setrendering(0);
  %attach = new Item()
	{
		datablock = "RHealthLockerItem";
		static = 1;
	};
	%attach.spawnbrick = %brick;
  %attach.settransform(vectoradd(%brick.gettransform(),"0 0 -1.42") SPC getwords(%brick.gettransform(),3,6));
  %brick.attachment = %attach;
  parent::onPlant(%data, %brick);
}
function BrickLockerData::onAdd(%data, %brick,%a,%b)
{
	parent::onAdd(%data, %brick,%a,%b);
}
function BrickLockerData::onDeath(%data, %brick)
{
   if(isObject(%brick.attachment))
	{
	  %brick.getgroup().HealthLockerCount--;
      %brick.attachment.delete();
	}
}

function BrickLockerData::onRemove(%data, %brick)
{
   if(isObject(%brick.attachment))
	{
	  %brick.getgroup().HealthLockerCount--;
      %brick.attachment.delete();
	}
}

function HealthlockerAnim(%obj,%oc)
{
	if(%oc == 1)
	{
		%obj.playaudio(2,HealthLockerOpenSound);
		%obj.playthread(1,open);
		%obj.isopen = 1;
		
	}
	if(%oc == 0)
	{
		%obj.playthread(1,close);
		cancel(%obj.slowd);
		%obj.isopen = 0;
		%obj.isshutting = 1;
		%obj.slowd = schedule(600,0,Evalcrashes,%obj);
		%obj.playaudio(2,HealthLockerCloseSound);
	}
}
function EvalCrashes(%obj)
{
	%obj.isshutting= 0;
}