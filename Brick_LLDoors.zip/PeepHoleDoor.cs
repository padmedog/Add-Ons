datablock fxDTSBrickData ( brickPeepHoleDoorOpenCWData )
{
	brickFile = "./PeepHoleDooropenCW.blb";
	uiName = "Peephole Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickPeepHoleDoorCWData";
	openCW = "brickPeepHoleDoorOpenCWData";
	
	closedCCW = "brickPeepHoleDoorCWData";
	openCCW = "brickPeepHoleDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickPeepHoleDoorOpenCCWData : brickPeepHoleDoorOpenCWData )
{
	brickFile = "./PeepHoleDooropenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickPeepHoleDoorCWData : brickPeepHoleDoorOpenCWData )
{
	brickFile = "./PeepHoleDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";
	
	iconName = "Add-Ons/Brick_LLDoors/PeepholeDoor";
	
	isOpen = 0;
};