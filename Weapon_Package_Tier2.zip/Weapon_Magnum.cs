//audio
datablock AudioProfile(MagnumFireSound)
{
   filename    = "./sawnoff.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(MagnumTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 210;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 0 0.5";
	colors[1]	= "1 1 0.4 0.5";
	colors[2]	= "1 1 1 0.5";
	sizes[0]	= 0.3;
	sizes[1]	= 0.25;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(MagnumTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = MagnumTrailParticle;

   useEmitterColors = true;
};

AddDamageType("Magnum",   '<bitmap:add-ons/Weapon_Package_Tier2/CI_Magnum> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2/CI_Magnum> %1',0.75,1);
AddDamageType("MagnumHeadshot",   '<bitmap:add-ons/Weapon_Package_Tier2/CI_Magnum><bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2/CI_Magnum><bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',0.75,1);
datablock ProjectileData(MagnumProjectile)
{
   projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 40;
   directDamageType    = $DamageType::Magnum;
   radiusDamageType    = $DamageType::Magnum;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 14;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 22;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1200;
   verticalImpulse	  = 400;
   explosion           = ShotgunExplosion;
   particleEmitter     = "MagnumTrailEmitter";

   muzzleVelocity      = 180;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 900;
   fadeDelay           = 800;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(MagnumItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./magnum.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Magnum";
	iconName = "./Magnum";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.72 1.000";

	 // Dynamic properties defined by the scripts
	image = MagnumImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 6;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MagnumImage)
{

   // Basic Item properties
   shapeFile = "./magnum.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = MagnumItem;
   ammo = " ";
   projectile = MagnumProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = MagnumItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.35;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "Reload";
	stateTransitionOnTriggerDown[1] = "FireCheckA";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;

	stateName[3] 			= "Smoke";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.35;
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout

	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTransitionOnTriggerUp[5]		= "LoadCheckB";
						
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "Reload";
	
	stateName[7]				= "ReloadCheckA";
	stateScript[7]				= "onReloadCheck";
	stateTimeoutValue[7]			= 0.01;
	stateTransitionOnTimeout[7]		= "ReloadCheckB";
						
	stateName[8]				= "ReloadCheckB";
	stateTransitionOnAmmo[8]		= "CompleteReload";
	stateTransitionOnNoAmmo[8]		= "Reload";
						
	stateName[9]				= "ForceReload";
	stateTransitionOnTimeout[9]     	= "ForceReloaded";
	stateTimeoutValue[9]			= 0.25;
	stateSequence[9]			= "Reload";
	stateSound[9]				= Block_MoveBrick_Sound;
	stateScript[9]				= "onReloadStart";
	
	stateName[10]				= "ForceReloaded";
	stateTransitionOnTimeout[10]     	= "ReloadCheckA";
	stateTimeoutValue[10]			= 0.2;
	stateScript[10]				= "onReloaded";
	
	stateName[11]				= "Reload";
	stateTransitionOnTimeout[11]     	= "Reloaded";
	stateTransitionOnTriggerDown[11] 	= "Fire";
	stateWaitForTimeout[11]			= false;
	stateTimeoutValue[11]			= 0.25;
	stateSequence[11]			= "Reload";
	//stateSound[11]				= Block_MoveBrick_Sound;
	stateScript[11]				= "onReloadStart";
	
	stateName[12]				= "Reloaded";
	stateTransitionOnTimeout[12]     	= "ReloadCheckA";
	stateWaitForTimeout[12]			= false;
	stateTimeoutValue[12]			= 0.2;
	stateScript[12]				= "onReloaded";

	stateName[13]			  = "CompleteReload";
	stateTimeoutValue[13]		  = 0.5;
	stateWaitForTimeout[13]		  = true;
	stateTransitionOnTimeout[13]     	= "Ready";
	stateSequence[13]			  = "fire";
	stateScript[13]                  = "onEject";

	stateName[14]				= "FireCheckA";
	stateScript[14]				= "onLoadCheck";
	stateTimeoutValue[14]		  = 0.01;
	stateTransitionOnTimeout[14]     	= "FireCheckB";
						
	stateName[15]				= "FireCheckB";
	stateTransitionOnAmmo[15]		= "Fire";
	stateTransitionOnNoAmmo[15]		= "Reload";
};

function MagnumImage::onFire(%this,%obj,%slot)
{
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, shiftAway);
        serverPlay3D(MagnumFireSound,%obj.getPosition());

	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
}

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if((getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0001;
	}
	else
	{
		%spread = 0.003;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};

	%projectile = "shotgunFlashProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;
	}
}
function MagnumImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}

function MagnumImage::onEject(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		
    if(%obj.client.quantity["880rounds"] >= 1)
	{
	%obj.playThread(2, shiftleft);
            serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}

function MagnumImage::onReloadStart(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		
    if(%obj.client.quantity["880rounds"] >= 1)
	{
	%obj.playThread(2, shiftright);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}

function MagnumImage::onReloaded(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["880rounds"] >= 1)
	{
		%obj.client.quantity["880rounds"]--;
		serverPlay3D(reloadClick5Sound,%obj.getPosition());
		%obj.playThread(2, shiftright);
		%obj.toolAmmo[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}
}

//needs more critical headshots. the magnum feels like a posing pistol right now :(
//using a weird offshoot of the huntsman's code for the moment

function MagnumProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 40;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 2;
         %damageType = $DamageType::MagnumHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}