// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

$Slayer::Server::Minigames::ResetTimeOut = 5000;

Slayer.Prefs.addPref("Chat", "Allow Dead Talking", "%mini.chat_deadChatMode", "list" TAB "0 Disabled" TAB "1 Enabled" TAB "2 Enabled - Global Only" TAB "3 Enabled - Team Only", 1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Chat", "Death Message Mode", "%mini.deathMsgMode", "list" TAB "0 Do Not Display" TAB "1 Colored Names" TAB "2 Non-Colored Names", 1, 0, 0, -1, "Advanced");
Slayer.Prefs.addPref("Chat", "Enable Team Chat", "%mini.chat_enableTeamChat", "bool", 1, 0, 1, 3, "Advanced");
Slayer.Prefs.addPref("Chat", "Team Display Mode", "%mini.chat_teamDisplayMode", "list" TAB "0 Disabled" TAB "1 Color Tag" TAB "2 Color Name" TAB "3 Add Name to Tag", 2, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Damage", "Bot", "%mini.botDamage", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Damage", "Brick", "%mini.brickDamage", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Damage", "Falling", "%mini.fallingDamage", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Damage", "Self", "%mini.selfDamage", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Damage", "Vehicle", "%mini.vehicleDamage", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Damage", "Weapon", "%mini.weaponDamage", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("EoRR", "Display End of Round Report", "%mini.eorrEnable", "bool", 1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("EoRR", "Display Team Scores", "%mini.eorrDisplayTeamScores", "bool", 1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("EoRR", "Display Victory/Defeat", "%mini.eorrDisplayVictory", "bool", 1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Allow Movement During Reset", "%mini.allowMoveWhileResetting", "bool", 0, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Auto Start With Server", "$Slayer::Server::Preload::Minigame::AutoStartMinigame", "bool", 0, 0, 0, 0, "Advanced");
Slayer.Prefs.addPref("Minigame", "Clear Scores on Reset", "%mini.clearScores", "bool", 1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Clear Stats on Reset", "%mini.clearStats", "bool", 1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Color", "%mini.colorIdx", "int 0 10", 0, 0, 0, -1, "", "%mini.updateColor(%1, %2);");
Slayer.Prefs.addPref("Minigame", "Custom Rule", "%mini.customRule", "string 150", "", 0, 0, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Default Minigame", "%mini.isDefaultMinigame", "bool", 0, 0, 1, 2, "", "%mini.updateDefaultMinigame(%1);");
Slayer.Prefs.addPref("Minigame", "Enable Building", "%mini.enableBuilding", "bool", 1, 0, 1, -1, "", "%mini.updateEnableBuilding();");
Slayer.Prefs.addPref("Minigame", "Enable Painting", "%mini.enablePainting", "bool", 1, 0, 1, -1, "", "%mini.updateEnablePainting();");
Slayer.Prefs.addPref("Minigame", "Enable Wand", "%mini.enableWand", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Minigame", "Gamemode", "%mini.mode", "string 100", "Slyr", 1, 1, -1, "", "%mini.updateGamemode(%1, %2);");
Slayer.Prefs.addPref("Minigame", "Host Name", "%mini.hostName", "string 25", "HOST", 0, 0, 3, "Advanced");
Slayer.Prefs.addPref("Minigame", "Invite-Only", "%mini.inviteOnly", "bool", 0, 0, 1, 4);
Slayer.Prefs.addPref("Minigame", "Late Join Time", "%mini.lateJoinTime", "slide -1 5 5 1", -1, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Players Use Own Bricks", "%mini.playersUseOwnBricks", "bool", 0, 0, 1, -1);
Slayer.Prefs.addPref("Minigame", "Pre-Round Countdown", "%mini.preRoundSeconds", "int 0 10", 0, 0, 1, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Reset When Empty", "%mini.resetOnEmpty", "bool", 1, 0, 0, 3, "Advanced");
Slayer.Prefs.addPref("Minigame", "Spawn Brick Color", "%mini.spawnBrickColor", "int -1 63", -1, 0, 0, -1, "Advanced");
Slayer.Prefs.addPref("Minigame", "Time Between Rounds", "%mini.timeBetweenRounds", "int 5 300", 10, 0, 1, 4, "Advanced");
Slayer.Prefs.addPref("Minigame", "Title", "%mini.Title", "string 50", "Slayer", 0, 1, -1);
Slayer.Prefs.addPref("Minigame", "Use All Players' Bricks", "%mini.useAllPlayersBricks", "bool", 0, 0, 1, -1);
Slayer.Prefs.addPref("Minigame", "Use Spawn Bricks", "%mini.useSpawnBricks", "bool", 1, 0, 1, -1);
Slayer.Prefs.addPref("Permissions", "Create Minigame Rights", "Slayer.Minigames.createRights", "list" TAB "0 Host" TAB "1 Super Admin" TAB "2 Admin" TAB "3 Everyone", 2, 0, 1, 0, "Advanced");
Slayer.Prefs.addPref("Permissions", "Edit Rights", "%mini.editRights", "list" TAB "3 Creator" TAB "4 Full Trust" TAB "5 Build Trust" TAB "0 Host" TAB "1 Super Admin" TAB "2 Admin", 3, 0, 1, 3, "Advanced");
Slayer.Prefs.addPref("Permissions", "Leave Rights", "%mini.leaveRights", "list" TAB "3 Creator" TAB "4 Full Trust" TAB "5 Build Trust" TAB "0 Host" TAB "1 Super Admin" TAB "2 Admin" TAB "6 Everyone", 2, 0, 1, 3, "Advanced");
Slayer.Prefs.addPref("Permissions", "Reset Rights", "%mini.resetRights", "list" TAB "3 Creator" TAB "4 Full Trust" TAB "5 Build Trust" TAB "0 Host" TAB "1 Super Admin" TAB "2 Admin", 3, 0, 1, 3, "Advanced");
Slayer.Prefs.addPref("Player", "Name Distance", "%mini.nameDistance", "slide 0 600 29 1", 140, 0, 1, -1, "", "%mini.updateNameDistance(%1);");
Slayer.Prefs.addPref("Player", "Playertype", "%mini.playerDatablock" TAB "PlayerData" TAB 1, "string 100", nameToID(playerStandardArmor), 0, 0, -1, "", "%mini.updatePlayerDatablock();");
Slayer.Prefs.addPref("Player", "Starting Equipment 0", "%mini.startEquip0" TAB "ItemData", "string 100", nameToID(hammerItem), 0, 0, -1, "", "%mini.updateEquip(0, %1, %2);");
Slayer.Prefs.addPref("Player", "Starting Equipment 1", "%mini.startEquip1" TAB "ItemData", "string 100", nameToID(wrenchItem), 0, 0, -1, "", "%mini.updateEquip(1, %1, %2);");
Slayer.Prefs.addPref("Player", "Starting Equipment 2", "%mini.startEquip2" TAB "ItemData", "string 100", nameToID(printGun), 0, 0, -1, "", "%mini.updateEquip(2, %1, %2);");
Slayer.Prefs.addPref("Player", "Starting Equipment 3", "%mini.startEquip3" TAB "ItemData", "string 100", 0, 0, 0, -1, "", "%mini.updateEquip(3, %1, %2);");
Slayer.Prefs.addPref("Player", "Starting Equipment 4", "%mini.startEquip4" TAB "ItemData", "string 100", 0, 0, 0, -1, "", "%mini.updateEquip(4, %1, %2);");
Slayer.Prefs.addPref("Points", "Break Brick", "%mini.points_breakBrick", "int -999 999", 0, 0, 1, -1);
Slayer.Prefs.addPref("Points", "CP Capture", "%mini.points_CP", "int -999 999", 10, 0, 1, -1, "Rules Teams Points");
Slayer.Prefs.addPref("Points", "Die", "%mini.points_die", "int -999 999", 0, 0, 1, -1);
Slayer.Prefs.addPref("Points", "Friendly Fire", "%mini.points_friendlyFire", "int -999 999", -5, 0, 1, -1, "Rules Teams Points");
Slayer.Prefs.addPref("Points", "Kill Bot", "%mini.points_killBot", "int -999 999", 1, 0, 1, -1);
Slayer.Prefs.addPref("Points", "Kill Player", "%mini.points_killPlayer", "int -999 999", 1, 0, 1, -1);
Slayer.Prefs.addPref("Points", "Plant Brick", "%mini.points_plantBrick", "int -999 999", 0, 0, 1, -1);
Slayer.Prefs.addPref("Points", "Suicide", "%mini.points_killSelf", "int -999 999", -1, 0, 1, -1);
Slayer.Prefs.addPref("Respawn Time", "Bot", "%mini.respawnTime_bot", "int -1 999", 5, 0, 1, -1, "", "%mini.updateRespawnTime(\"bot\", %1, %2);");
Slayer.Prefs.addPref("Respawn Time", "Brick", "%mini.respawnTime_brick", "int -1 999", 30, 0, 1, -1, "", "%mini.updateRespawnTime(\"brick\", %1, %2);");
Slayer.Prefs.addPref("Respawn Time", "Friendly Fire Penalty", "%mini.respawnPenalty_FriendlyFire", "int 0 999", 5, 0, 1, -1, "Rules Teams Respawn", "%mini.updateRespawnTime(\"penalty_FF\", %1, %2);");
Slayer.Prefs.addPref("Respawn Time", "Player", "%mini.respawnTime_player", "int 1 999", 5, 0, 1, -1, "", "%mini.updateRespawnTime(\"player\", %1, %2);");
Slayer.Prefs.addPref("Respawn Time", "Vehicle", "%mini.respawnTime_vehicle", "int 0 999", 10, 0, 1, -1, "", "%mini.updateRespawnTime(\"vehicle\", %1, %2);");
Slayer.Prefs.addPref("Victory Method", "Lives", "%mini.lives", "int 0 99", 0, 0, 1, -1, "", "%mini.updateLives(%1, %2);");
Slayer.Prefs.addPref("Victory Method", "Points", "%mini.points", "int 0 2000", 0, 0, 1, -1, "", "%mini.updatePoints(%1, %2);");
Slayer.Prefs.addPref("Victory Method", "Time", "%mini.time", "int 0 999999", 0, 0, 1, -1, "", "%mini.updateTime(%1, %2);");

Slayer.Prefs.addNonNetworkedPref("Chat", "Disable Slayer Messages", "%mini.disableSlayerMessages", "bool", false);

// +--------------------------+
// | Slayer_MinigameHandlerSO |
// +--------------------------+
function Slayer_MinigameHandlerSO::onAdd(%this)
{
	
}

function Slayer_MinigameHandlerSO::onRemove(%this)
{
	%this.endAllMinigames();
}

function Slayer_MinigameHandlerSO::addMinigame(%this, %client, %configFile)
{
	if(isObject(%client))
	{
		if(!%this.canCreate(%client))
			return;

		%blid = %client.getBLID();

		if(isObject(%this.getMinigameFromBLID(%blid)))
		{
			messageClient(%client, '', "\c5A minigame has already been created by Blockland ID" SPC %blid);
			return;
		}
	}
	else
	{
		if(isObject(%this.getHostMinigame()))
		{
			Slayer_Support::Debug(1, "Create Minigame", "A server-created minigame has already been set.");
			return;
		}

		%blid = Slayer_Support::getBlocklandID();
	}

	Slayer_Support::Debug(1, "Minigame", "Starting...");
		
	%mini = new ScriptObject()
	{
		class = Slayer_MinigameSO;
		superClass = MinigameSO;

		creatorBLID = %blid;
		owner = 0;

		isDedicatedStart = !isObject(%client);

		configFile = %configFile;
	};

	if(isObject(%client))
	{
		if(%mini.hostName $= "HOST")
		{
			%mini.schedule(0, setPref, "Minigame", "Host Name", %client.getPlayerName());
			%mini.schedule(0, broadcastMinigame);
		}

		%mini.addMember(%client);
	}

	return %mini;
}

function Slayer_MinigameHandlerSO::endAllMinigames(%this)
{
	for(%i = 0; %i < %this.getCount(); %i ++)
		%this.getObject(%i).endGame();
}

function Slayer_MinigameHandlerSO::getMinigameFromBLID(%this, %blid)
{
	if(!Slayer_Support::isFloat(%blid))
		return 0;

	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		%mini = %this.getObject(%i);
		if(%mini.creatorBLID == %blid)
		{
			return %mini;
		}
	}

	return 0;
}

function Slayer_MinigameHandlerSO::getHostMinigame(%this)
{
	%blid = Slayer_Support::getBlocklandID();

	return %this.getMinigameFromBLID(%blid);
}

function Slayer_MinigameHandlerSO::getHighestPriorityMinigame(%this, %blid)
{
	%m = %this.getMinigameFromBLID(%blid);
	if(isObject(%m))
	{
		%mini = %m; //owner has #1 priority
	}
	else
	{
		%hostID = Slayer_Support::getBlocklandID();

		for(%i = 0; %i < %this.getCount(); %i ++)
		{
			%m = %this.getObject(%i);
			if(!%m.useAllPlayersBricks)
				continue;

			if(%m.creatorBLID == %hostID) //host has #2 priority
				return %m;

			%mini = %m; //this is a crappy way of doing things
		}
	}

	return (isObject(%mini) ? %mini : -1);
}

function Slayer_MinigameHandlerSO::setDefaultMinigame(%this, %mini)
{
	%this.defaultMinigame = %mini;

	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		%m = %this.getObject(%i);
		%m.isDefaultMinigame = (%mini == %m);
		%m.broadcastMinigame();
	}

	if(isObject(%mini))
	{
		for(%i = 0; %i < clientGroup.getCount(); %i ++)
		{
			%cl = clientGroup.getObject(%i);
			if(%cl.hasSpawnedOnce)
			{
				%m = getMinigameFromObject(%cl);
				if(!isObject(%m))
					%mini.addMember(%cl);
			}
		}
	}
}

function Slayer_MinigameHandlerSO::broadcastAllMinigames(%this, %client, %onlyChanged)
{
	for(%i = 0; %i < %this.getCount(); %i ++)
		%this.getObject(%i).broadcastMinigame(%client, %onlyChanged);
}

function Slayer_MinigameHandlerSO::canCreate(%this, %client, %overRide)
{
	if(%client.isHost)
		return true;

	%mini = getMinigameFromObject(%client);
	if(isSlayerMinigame(%mini))
	{
		if(!%mini.canLeave(%client))
		{
			return false;
		}
	}

	%create = %this.createRights;
	%level = %client.getAdminLvl();

	if(%level <= %create || (%level <= %overRide && %overRide !$= "" && %overRide != -1))
		return true;

	return false;
}

// +-------------------+
// | Slayer_MinigameSO |
// +-------------------+
function Slayer_MinigameSO::onAdd(%this)
{
	%this.isStarting = true;
	%this.isSlayerMinigame = true;
	%this.isResetting = false;
	%this.numMembers = 0;

	%this.Prefs = Slayer.Prefs;
	%this.TeamPrefs = Slayer.TeamPrefs;
	%this.Teams = new scriptGroup()
	{
		class = Slayer_TeamHandlerSO;
		minigame = %this;
	};

	%this.onStart();
}

function Slayer_MinigameSO::onRemove(%this)
{
	%blid = Slayer_Support::getBlocklandID();
	if(%this.creatorBLID == %blid && ($Slayer::Server::CurGameModeArg $= "" || $Slayer::Server::CurGameModeArg $= $Slayer::Server::GameModeArg))
		Slayer.Prefs.exportPrefs($Slayer::Server::ConfigDir @ "/config_last.cs", %this);

	if(isObject(%this.Teams))
		%this.Teams.delete();

	if(isObject(%this.fakeClient))
		%this.fakeClient.delete();
}

function Slayer_MinigameSO::onStart(%this)
{
	Slayer.Minigames.add(%this);

	//PREFERENCES
	%this.resetPrefs();

	//AUTOMATIC STARTUP
	if(%this.isDedicatedStart)
	{
		if(isFile(%this.configFile))
		{
			%mini = %this; //needed to load prefs
			exec(%this.configFile);
		}

		//Are we using the BL Slayer game mode? (from the main menu)
		if($Slayer::Server::CurGameModeArg $= $Slayer::Server::GameModeArg)
		{
			%this.isDefaultMinigame = true;
		}
		else if($Slayer::Server::CurGameModeArg !$= "")
		{
			//"I reject your minigame and substitute my own" - replace the BL default minigame
			if(isObject($DefaultMiniGame))
				$DefaultMiniGame.delete();
		}
	}

	//add to the join minigame GUI
	%this.broadcastMinigame();

	%this.isStarting = false;

	%this.updateDefaultMinigame(%this.isDefaultMinigame);

	//callback for teams - must be called afterwards
	%this.teams.onMinigameStart();

	%this.reset(0);
	%this.lastResetTime = 0;

	Slayer_Support::Debug(1, "Slayer_MinigameSO::onStart");
}

function Slayer_MinigameSO::preConfigLoad(%this, %file)
{
	Slayer_Support::Debug(2, "Loading config file", %file);

	if(isObject(%this.Teams))
		%this.Teams.deleteAll();
}

function Slayer_MinigameSO::postConfigLoad(%this, %file)
{
	Slayer_Support::Debug(2, "Config file loaded", %file);

	if(!isObject(%this.gamemode)) //in case the gamemode they were using before was disabled
	{
		%this.setPref("Minigame", "Gamemode", "Slyr");
	}
	else if(%this.gamemode.teams && isObject(%this.Teams) && %this.Teams.getAutoSortTeamCount() > 0)
	{
		%this.Teams.autoSortAll(1);
	}

	//corruption protection
	//if this prefs isn't set, something went wrong with the config file
	//reset to defaults
	if(%this.getPref("Permissions", "Edit Rights") $= "")
		%this.resetPrefs();
}

function Slayer_MinigameSO::broadcastMinigame(%this, %client, %onlyIfChanged)
{
	%blid = %this.creatorBLID;

	%defaultMini = (Slayer.Minigames.defaultMinigame == %this ? "Yes" : "No");

	if(isObject(%client))
	{
		%canEdit = %this.canEdit(%client);
		%inviteOnly = (%this.inviteOnly && !%canEdit);
		%data = %this.hostName TAB %blid TAB %this.title TAB %inviteOnly TAB %defaultMini TAB %canEdit;

		if(%onlyIfChanged && %client.lastMinigameBroadcast[%this] $= %data)
			return;

		%client.lastMinigameBroadcast[%this] = %data;

		commandToClient(%client, 'addMinigameLine', %data, %this.getID(), %this.colorIDX);
	}
	else
	{
		for(%i = 0; %i < clientGroup.getCount(); %i ++)
		{
			%cl = clientGroup.getObject(%i);

			%canEdit = %this.canEdit(%cl);
			%inviteOnly = (%this.inviteOnly && !%canEdit);
			%data = %this.hostName TAB %blid TAB %this.title TAB %inviteOnly TAB %defaultMini TAB %canEdit;

			if(%onlyIfChanged && %cl.lastMinigameBroadcast[%this] $= %data)
				continue;

			%cl.lastMinigameBroadcast[%this] = %data;

			commandToClient(%cl, 'addMinigameLine', %data, %this.getID(), %this.colorIDX);
		}
	}
}

function Slayer_MinigameSO::victoryCheck_Lives(%this)
{
	if(%this.isResetting() || %this.isEnding)
		return -1;

	if(!%this.Gamemode.rounds)
		return -1;

	if(isFunction("Slayer_" @ %this.mode @ "_victoryCheck_Lives"))
		%special = call("Slayer_" @ %this.mode @ "_victoryCheck_Lives", %this);
	if(%special !$= "")
		return %special;

	//check if any teams have remaining players
	%teamCount = %this.Teams.getCount();
	if(%this.Gamemode.teams && %teamCount > 0)
	{
		%winnerColor = -1;
		for(%i = 0; %i < %teamCount; %i ++)
		{
			%t = %this.Teams.getObject(%i);
			if(%t.spectate)
				continue;
			if(!%t.isTeamDead())
			{
				if(%this.Teams.allySameColors && %t.color == %winnerColor)
				{
					%winner = setField(%winner, getFieldCount(%winner), %t);
				}
				else
				{
					%winner = %t;
					%winnerColor = %t.color;
					%count ++;
				}
			}
		}
		if(%count > 1)
			return -1;
	}

	//check if anyone without a team is still alive
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		%cl = %this.member[%i];
		if(!%cl.Dead() && !isObject(%cl.getTeam()))
		{
			%winner = %cl;
			%count ++;
		}
	}

	if(%count == 1)
		return %winner;
	else if(%count > 1)
		return -1;
	else
		return 0;
}

function Slayer_MinigameSO::victoryCheck_Points(%this)
{
	if(%this.isResetting())
		return -1;

	if(!%this.Gamemode.rounds || %this.points <= 0)
		return -1;

	if(isFunction("Slayer_" @ %this.mode @ "_victoryCheck_Points"))
		%special = call("Slayer_" @ %this.mode @ "_victoryCheck_Points", %this);

	if(%special >= 0 && %special !$= "")
		return %special;

	if(%this.Gamemode.teams && %this.Teams.getCount() > 0)
	{
		for(%i = 0; %i < %this.Teams.getCount(); %i ++)
		{
			%t = %this.Teams.getObject(%i);
			if(%t.spectate)
				continue;
			if(%t.getScore() >= %this.points)
			{
				%winner = %t;
				break;
			}
		}
	}

	if(!isObject(%winner))
	{
		for(%i = 0; %i < %this.numMembers; %i ++)
		{
			%cl = %this.member[%i];
			if(!isObject(%cl.slyrTeam) && %cl.score >= %this.points)
			{
				%winner = %cl;
				break;
			}
		}
	}

	if(isObject(%winner))
		return %winner;
	else
		return -1;
}

function Slayer_MinigameSO::victoryCheck_Time(%this, %ticks)
{
	if(!%this.Gamemode.rounds || %this.time <= 0 || %this.isResetting())
		return;

	//round time - total
	%time = %this.time * 60000;
	%this.timeTicks = %ticks;

	//round time - tick size
	%this.timeTickLength = (%ticks <= 0 ? 60000 : %this.timeTickLength);
	%timeTickLength = %this.timeTickLength;

	//round time - remaining
	%this.timeRemaining = (%ticks <= 0 ? %time : %this.timeRemaining - %timeTickLength);
	%timeRemaining = %this.timeRemaining;

	//round time - elapsed
	%this.timeElapsed = %time - %this.timeRemaining;
	%timeElapsed = %this.timeElapsed;

	Slayer_Support::Debug(2, "Slayer_MinigameSO::victoryCheck_Time", "Time remaining:" SPC %timeRemaining);

	//CHECK IF THE GAMEMODE HAS ANYTHING TO SAY ABOUT THIS
	if(isFunction("Slayer_" @ %this.mode @ "_victoryCheck_Time"))
		%special = call("Slayer_" @ %this.mode @ "_victoryCheck_Time", %this, %ticks);
	if(%special > 0 && %special !$= "")
	{
		%this.endRound(%special);
		return;
	}
	if(%special < 0 && %special !$= "")
		return;

	if(%timeElapsed >= %time)
	{
		%least = 0;
		%count = 0;
		if(%this.Gamemode.teams && %this.Teams.getCount() > 0)
		{
			for(%i = 0; %i < %this.Teams.getCount(); %i ++)
			{
				%t = %this.Teams.getObject(%i);
				if(%t.spectate)
					continue;

				%sc = %t.getScore();
				if((%sc > %least || %t.winOnTimeUp) && !%winOnTimeUp)
				{
					%winner = %t;
					%least = %sc;
					%count = 1;

					if(%t.winOnTimeUp)
						%winOnTimeUp = 1;
				}
				else if((%sc == %least && %least > 0 && !%winOnTimeUp) || (%winOnTimeUp && %t.winOnTimeUp))
				{
					%winner = setField(%winner, %count, %t);
					%count ++;
				}
			}
		}
		for(%i = 0; %i < %this.numMembers; %i ++)
		{
			%cl = %this.member[%i];
			%sc = %cl.score;

			if(isObject(%cl.getTeam()))
				continue;

			if(%sc > %least)
			{
				%winner = %cl;
				%least = %sc;
				%count = 1;
			}
			else if(%sc == %least && %least > 0)
			{
				%winner = setField(%winner, %count, %cl);
				%count ++;
			}
		}

		%this.endRound(%winner);
		return;
	}
	else
	{
		if(%timeRemaining % 60000 == 0) //only on the minute
		{
			if(%timeRemaining <= 60000) //start ticking every 10 seconds
				%this.timeTickLength = 30000;

			if(%timeRemaining % 600000 == 0) //every 10 minutes
				%announce = 1;
			else if(%timeRemaining <= 300000) // <= 5 minutes remaining
				%announce = 1;

			%minutes = %timeRemaining / 60000;
			%remain = %minutes SPC "\c5" @ (%minutes == 1 ? "minute" : "minutes");
		}
		else
		{
			if(%timeRemaining % 10000 == 0 && %timeRemaining <= 30000) //30, 20, 10 seconds remaining
			{
				if(%timeRemaining <= 10000) // <= 10 seconds remaining
					%this.timeTickLength = 5000;
				else
					%this.timeTickLength = 10000;
				%announce = 1;
			}
			else if(%timeRemaining <= 5000) // <= 5 seconds remaining
			{
				%this.timeTickLength = 1000;
				%announce = 1;
			}

			%seconds = %timeRemaining / 1000;
			%remain = %seconds SPC "\c5" @ (%seconds == 1 ? "second" : "seconds");
		}

		if(%announce && %ticks > 0)
			%this.messageAll('', '\c3%1 \c5remaining.', %remain);

		cancel(%this.timeSchedule);
		%this.timeSchedule = %this.scheduleNoQuota(%this.timeTickLength, victoryCheck_Time, %ticks++);
	}
}

function Slayer_MinigameSO::onReset(%this)
{
	//START THE ROUND
	if(%this.preRoundSeconds > 0)
		%this.preRoundCountdownTick(0);
	else
		%this.startRound();
}

function Slayer_MinigameSO::preRoundCountdownTick(%this, %ticks)
{
	cancel(%this.preRoundCountdownTimer);

	if(%this.isResetting())
		return;

	%remain = %this.preRoundSeconds - %ticks;

	Slayer_Support::Debug(2, "Slayer_MinigameSO::preRoundCountdownTick", %remain);

	if(%remain <= 0)
	{
		%this.startRound();

		%this.play2dAll(Slayer_Begin_Sound);
		%this.centerPrintAll("<font:Arial Bold:100><color:ff00ff>GO!", 2);
	}
	else
	{
		if(%ticks == 0)
		{
			for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
			{
				%cl = %this.member["GameConnection", %i];
				if(isObject(%cl.player))
					%cl.player.changeDatablock(PlayerFrozenArmor);
			}
			for(%i = 0; %i < %this.numMembers["AiConnection"]; %i ++)
			{
				%ai = %this.member["AiConnection", %i];
				if(isObject(%ai.player) && %ai.player.isHoleBot)
					%ai.player.stopHoleLoop();
			}
		}

		%sound = "Slayer_" @ %remain @ "_Seconds_Sound";
		if(isObject(%sound))
			%this.play2dAll(%sound);
		%this.centerPrintAll("<font:Arial Bold:100><color:ff00ff>" @ %remain);

		%this.preRoundCountdownTimer = %this.scheduleNoQuota(1000, preRoundCountdownTick, %ticks ++);
	}
}

function Slayer_MinigameSO::startRound(%this)
{
	Slayer_Support::Debug(1, "Slayer_MinigameSO::startRound");
	%this.roundStarted = $Sim::Time;

	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
	{
		%cl = %this.member["GameConnection", %i];
		%cl.roundWon = "";
		if(isObject(%cl.player))
		{
			if(%cl.player.getDatablock().getID() == PlayerFrozenArmor.getID())
			{
				%t = %cl.getTeam();
				%db = (isObject(%t) ? %t.playerDatablock : %this.playerDatablock);
				%cl.player.changeDatablock(%db);
			}
		}
		else if(!%cl.dead())
			%cl.spawnPlayer();
	}
	for(%i = 0; %i < %this.numMembers["AiConnection"]; %i ++)
	{
		%ai = %this.member["AiConnection", %i];
		if(isObject(%ai.player) && %ai.player.isHoleBot)
			%ai.player.resetHoleLoop();
	}

	//begin the winTick
	if(%this.Gamemode.rounds && %this.Time > 0)
		%this.victoryCheck_Time(0);

	//event
	$InputTarget_["MiniGame"] = %this;
	processMultiSourceInputEvent("onMinigameRoundStart", 0, %this);
}

function Slayer_MinigameSO::endRound(%this, %winner, %resetTime)
{
	if(%this.isResetting())
		return;
	%this.setResetting(1);

	Slayer_Support::Debug(1, "Slayer_MinigameSO::endRound", "winner:" SPC %winner TAB "resetTime:" SPC %resetTime);

	if(getField(%winner, 0) $= "CUSTOM")
	{
		%count = 1;
		%nameList = getField(%winner, 1);
	}
	else //this generates the list of winner names
	{
		%count = 0;
		for(%i = 0; %i < getFieldCount(%winner); %i ++)
		{
			%w = getField(%winner, %i);
			if(!isObject(%w))
				continue;
			if(getMinigameFromObject(%w) != %this)
				continue;

			if(%w.class $= "Slayer_TeamSO")
			{
				%name = "<sPush>" @ %w.getColoredName() @ "<sPop>";

				for(%e=0; %e < %w.numMembers; %e++)
				{
					%cl = %w.member[%e];

					if(isObject(%cl.player))
						%cl.player.emote(winStarProjectile);

					%cl.roundWon = true;
				}
			}
			else if(%w.getClassName() $= "GameConnection")
			{
				%name = "<sPush><color:ffff00>" @ %w.getPlayerName() @ "<sPop>";

				if(isObject(%w.player))
					%w.player.emote(winStarProjectile);

				%w.roundWon = true;
			}
			else
				continue;

			%w.wins ++;

			%winner[%count] = %w;
			%count ++;

			if(%nameList $= "")
				%nameList = %name;
			else
				%nameList = %nameList @ ", " SPC %name;
		}
	}

	if(isFunction("Slayer_" @ %this.mode @ "_preVictory"))
		call("Slayer_" @ %this.mode @ "_preVictory", %this, %winner, %nameList);

	if(%count <= 0)
		%msg = '\c5Nobody won this round. Resetting in %4 seconds.';
	else
	{
		if(%count > 1)
			%msg = '<color:ff00ff>%1 tied this round. Resetting in %4 seconds.';
		else if(isObject(%winner))
		{
			%score = %winner.getScore();
			%wins = (%winner.wins == 1 ? "once" : %winner.wins SPC "\c5times");
			if(%score > 0)
			{
				%points = %score SPC (%score == 1 ? "\c5point" : "\c5points");
				%msg = '<color:ff00ff>%1 won this round with a score of \c3%2\c5. %1 has won \c3%3\c5. Resetting in %4 seconds.';
			}
			else
				%msg = '<color:ff00ff>%1 won this round. %1 has won \c3%3\c5. Resetting in %4 seconds.';

			if(isObject(%winner.player) && %winner.player.getType() & $TypeMasks::PlayerObjectType)
				%winnerCam = true;
		}
		else
			%msg = '<color:ffff00>%1 \c5won this round. Resetting in %4 seconds.';
	}

	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
	{
		%cl = %this.member["GameConnection", %i];

		%cl.setDead(true);

		if(!%this.allowMoveWhileResetting)
		{
			if(%winnerCam)
				%cl.camera.setMode(corpse, %winner.player);
			else
			{
				if(isObject(%cl.player))
					%cl.camera.setMode(corpse, %cl.player);
			}
			%cl.setControlObject(%cl.camera);
		}

		//END OF ROUND REPORT
		if(%this.eorrEnable)
		{
			if(%cl.slayer)
				commandToClient(%cl, 'Slayer_ForceGUI', "Slayer_CtrDisplay", 1);
			else
				messageClient(%cl, '', "\c3You cannot see the \"End of Round Report\" because you don't have <a:forum.blockland.us/index.php?topic=256245.0>Slayer</a> \c3installed.");
		}
	}
	for(%i = 0; %i < %this.numMembers["AiConnection"]; %i ++)
	{
		%ai = %this.member["AiConnection", %i];

		%ai.setDead(true);

		if(!%this.allowMoveWhileResetting)
		{
			if(isObject(%ai.player) && %ai.player.isHoleBot)
				%ai.player.stopHoleLoop();
		}
	}

	if(%resetTime $= "")
		%resetTime = %this.timeBetweenRounds * 1000;
	%seconds = mCeil(%resetTime / 1000);

	//tell everybody who won
	%this.messageAll('', %msg, %nameList, %points, %wins, %seconds);

	//populate end of round report
	if(%this.eorrEnable)
		%this.sendScoreListAll();

	//reset countdown
	if(%resetTime != -1)
	{
		for(%i = 0; %i < %seconds; %i ++)
		{
			%remaining = %seconds - %i;
			%timeLeft = %remaining SPC (%remaining == 1 ? "second" : "seconds");
			%this.resetCountdownTimer[%i] = %this.schedule(%i * 1000, "bottomPrintAll", "<just:center>\c5Resetting in" SPC %timeLeft @ ".", 2, 1);
		}
		%this.resetCountdownTimerCount = %seconds;

		%this.resetTimer = %this.scheduleNoQuota(%resetTime, reset, 0);
	}

	//event
	$InputTarget_["MiniGame"] = %this;
	processMultiSourceInputEvent("onMinigameRoundEnd", 0, %this);

	%this.teams.onMinigameRoundEnd();

	if(isFunction("Slayer_" @ %this.mode @ "_postVictory"))
		call("Slayer_" @ %this.mode @ "_postVictory", %this, %winner, %nameList);
}

function Slayer_MinigameSO::sendScoreListAll(%this)
{
	//INIT LISTS ALL
	%this.commandToAllSlayerClients('Slayer_ctrDisplayInit');

	//SETUP HEADER
	%header = '<color:ffffff><tab:150, 250, 350, 450><font:arial:16>%1<h2>%2\t%3\t%4\t%5\t%6</h2><br>';

	%var1 = "&victoryStatus";
	%var2 = "Name";
	%var3 = "Score";
	%var4 = "Kills";
	%var5 = "Deaths";
	%var6 = "Rounds Won";

	if(isFunction("Slayer_" @ %this.mode @ "_scoreListInit"))
		%custom = call("Slayer_" @ %this.mode @ "_scoreListInit", %this, %header, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9);
	if(getField(%custom, 0))
	{
		%header = getField(%custom, 1);
		for(%e = 2; %e < 11; %e ++)
			%var[%e - 1] = getField(%custom, %e);
	}

	if(%this.eorrDisplayVictory) //check whether a gamemode replaced this
	{
		if(%var1 $= "&victoryStatus")
			%victoryStatus = 1;
	}
	else if(%var1 $= "&victoryStatus")
		%victoryStatus = 2;

	//SEND HEADER ALL
	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
	{
		%cl = %this.member["GameConnection", %i];
		if(%cl.slayer)
		{
			if(%victoryStatus == 1)
			{
				if(!%cl.slyrTeam.spectate)
					%var1 = "<just:center><h1>" @ (%cl.roundWon ? "VICTORY" : "DEFEAT") @ "</h1></just>";
				else
					%var1 = "";
			}
			else if(%victoryStatus == 2)
				%var1 = "";

			commandToClient(%cl, 'Slayer_ctrDisplayAdd', %header, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9);
		}
	}

	%isScoreListAdd = isFunction("Slayer_" @ %this.mode @ "_scoreListAdd");

	if(isFunction("Slayer_" @ %this.mode @ "_scoreListCheckSendTeams"))
		%sendTeams = call("Slayer_" @ %this.mode @ "_scoreListCheckSendTeams", %this);
	%sendTeams = (%sendTeams $= "" || %sendTeams);

	//SEND TEAMS ALL
	if(%sendTeams && %this.Gamemode.teams && %this.Teams.getCount() > 0 && %this.eorrDisplayTeamScores)
	{
		%this.commandToAllSlayerClients('Slayer_ctrDisplayAdd', "<b>Teams:</b><br>");

		%teamList = %this.Teams.getTeamListSortedScore();

		for(%i = 0; %i < %this.Teams.getCount(); %i ++)
		{
			%t = getField(%teamList, %i);
			if(%t.spectate)
				continue;

			%var1 = %t.colorHex;
			%var2 = %t.name;
			%var3 = %t.getScore();
			%var4 = %t.getKills();
			%var5 = %t.getDeaths();
			%var6 = %t.wins;

			%line = '<color:%1><b>%2</b></color>\t%3\t%4\t%5\t%6<br>';

			if(%isScoreListAdd)
			{
				%custom = call("Slayer_" @ %this.mode @ "_scoreListAdd", %this, %t, %line, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9);
				if(getField(%custom, 0))
				{
					%line = getField(%custom, 1);
					for(%e = 2; %e < 11; %e ++)
						%var[%e - 1] = getField(%custom, %e);
				}
			}

			%this.commandToAllSlayerClients('Slayer_ctrDisplayAdd', %line, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9);
		}

		%teamsSent = true;
	}

	if(isFunction("Slayer_" @ %this.mode @ "_scoreListCheckSendPlayers"))
		%sendPlayers = call("Slayer_" @ %this.mode @ "_scoreListCheckSendPlayers", %this);
	%sendPlayers = (%sendPlayers $= "" || %sendPlayers);

	//SEND PLAYERS ALL
	if(%sendPlayers)
	{
		if(%teamsSent)
			%this.commandToAllSlayerClients('Slayer_ctrDisplayAdd', "<br><b>Players:</b><br>");

		%memberList = %this.getMemberListSortedScore();
		%count = getFieldCount(%memberList);
		for(%i = 0; %i < %count; %i ++)
		{
			%cl = getField(%memberList, %i);
			%class = %cl.getClassName();
			if(%class $= "AiConnection" && %cl.hName $= "")
				continue;

			%team = %cl.getTeam();
			if(%team.spectate)
				continue;

			%var1 = (%team > 0 ? %team.colorHex : "ffffff");
			%var2 = (%class $= "GameConnection" ? %cl.getPlayerName() : %cl.hName);
			%var3 = %cl.getScore();
			%var4 = %cl.getKills();
			%var5 = %cl.getDeaths();
			%var6 = (%team > 0 ? "" : %cl.wins);

			%line = '<color:%1><b>%2</b></color>\t%3\t%4\t%5\t%6<br>';

			if(%isScoreListAdd)
			{
				%custom = call("Slayer_" @ %this.mode @ "_scoreListAdd", %this, %cl, %line, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9);
				if(getField(%custom, 0))
				{
					%line = getField(%custom, 1);
					for(%e = 2; %e < 11; %e ++)
						%var[%e - 1] = getField(%custom, %e);
				}
			}

			%this.commandToAllSlayerClients('Slayer_ctrDisplayAdd', %line, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9);
		}
	}
}

function Slayer_MinigameSO::roundStarted(%this)
{
	return %this.roundStarted;
}

function Slayer_MinigameSO::isResetting(%this)
{
	return %this.isResetting;
}

function Slayer_MinigameSO::setResetting(%this, %flag)
{
	%this.isResetting = %flag;

	if(!%flag)
		%this.roundStarted = $Sim::Time;
}

//Creates an AiConnection and adds it to the minigame.
//The bot is not tied to a specific brick and is instead tied to the minigame.
//@return	[objectID]	The newly created bot.
function Slayer_MinigameSO::addBotToGame(%this)
{
	//Blockland crashes when ~3500 AiConnection objects have been created.
	//We need to recycle them when possible.
	if(isObject(aiRecycler))
	{
		for(%i = 0; %i < aiRecycler.getCount(); %i ++)
		{
			%ai = aiRecycler.getObject(%i);
			if(%ai.bl_id $= %this.creatorBLID || %ai.bl_id $= "")
			{
				aiRecycler.remove(%ai);
				%bot = %ai;
				break;
			}
		}
	}

	if(!isObject(%bot))
	{
		%bot = new AiConnection();
	}

	%bot.hasSpawnedOnce = true;
	%bot.isHoleBot = true;
	%bot.isSlayerBot = true;

	%this.addMember(%bot);

	Slayer_Support::Debug(2, "Slayer_MinigameSO::addBotToGame", %bot);

	return %bot;
}

function Slayer_MinigameSO::resetVehicles(%this)
{
	for(%i = 0; %i < vehicleSpawnGroup.getCount(); %i ++)
	{
		%br = vehicleSpawnGroup.getObject(%i);
		if(minigameCanUse(%this, %br))
			%br.respawnVehicle();
	}
}

function Slayer_MinigameSO::resetBots(%this)
{
	if(!isObject(mainBrickGroup))
		return;

	for(%i = 0; %i < mainBrickGroup.getCount(); %i ++)
	{
		%bg = mainBrickGroup.getObject(%i);
		if(miniGameCanUse(%this, %bg))
		{
			hResetBots(%bg);
		}
	}
}

function Slayer_MinigameSO::resetCapturePoints(%this, %client)
{
	for(%i = 0; %i < Slayer.capturePoints.getCount(); %i ++)
	{
		%cp = Slayer.capturePoints.getObject(%i);

		if(minigameCanUse(%this, %cp))
			%cp.setCPControl(%cp.origColor, 1, %client);
	}
}

function Slayer_MinigameSO::resetBricks(%this)
{
	if(!isObject(mainBrickGroup))
		return;

	for(%i = 0; %i < mainBrickGroup.getCount(); %i ++)
	{
		%bg = mainBrickGroup.getObject(%i);
		if(%bg.bl_id == 888888 || %bg.bl_id == 999999)
			continue;
		if(miniGameCanUse(%this, %bg))
		{
			%bg.chain_batchSize = 600; //decrease this number to reduce lag but increase reload time
			%bg.chain_timeOut = 32;
			%bg.schedule(0, "chainMethodCall", "onSlayerMinigameReset", %this); //schedule reduces lag
		}
	}
}

function Slayer_MinigameSO::getMemberListSortedScore(%this, %class)
{
	if(%class $= "")
	{
		%count = %this.numMembers;
		for(%i = 0; %i < %count; %i ++)
			%list = setField(%list, getFieldCount(%list), %this.member[%i]);
	}
	else
	{
		%count = %this.numMembers[%class];
		for(%i = 0; %i < %count; %i ++)
			%list = setField(%list, getFieldCount(%list), %this.member[%class, %i]);
	}

	while(!%done)
	{
		%done = 1;
		for(%i = 0; %i < %count; %i ++)
		{
			%e = %i + 1;
			if(%e >= %count)
				continue;
			%f1 = getField(%list, %i);
			%f2 = getField(%list, %e);
			if(%f1.score < %f2.score)
			{
				%list = Slayer_Support::swapItemsInList(%list, %i, %e);
				%done = 0;
			}
		}
		%count --;
	}
	return %list;
}

function Slayer_MinigameSO::getLiving(%this)
{
	%living = 0;
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		if(!%this.member[%i].dead())
			%living ++;
	}
	return %living;
}

function Slayer_MinigameSO::getSpawned(%this)
{
	%spawned = 0;
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		if(isObject(%this.member[%i].player))
			%spawned ++;
	}
	return %spawned;
}

function Slayer_MinigameSO::canDamage(%this, %objA, %classA, %objB, %classB)
{
	Slayer_Support::Debug(3, "Slayer_MinigameSO::canDamage", "A:" SPC %objA SPC %classA SPC "B:" SPC %objB SPC %classB);

	if(%classA $= "fxDtsBrick")
		return %this.brickDamage;
	else if(%classA $= "Player")
	{
		if(!%this.weaponDamage && Slayer_Support::isVehicle(%objB))
			return %this.vehicleDamage;

		return %this.weaponDamage;
	}
	else if(%classA $= "AiPlayer")
	{
		return %this.botDamage;
	}
	else if(%classA $= "GameConnection" || %classA $= "AiConnection")
	{
		if(%classB $= "fxDtsBrick")
			return %this.brickDamage;

		return %this.weaponDamage;
	}
 	else if(Slayer_Support::isVehicle(%objA))
	{
		return %this.vehicleDamage;
	}

	return 1;
}

function Slayer_MinigameSO::setPref(%this, %category, %title, %value)
{
	Slayer.Prefs.setPref(%category, %title, %value, %this);
}

function Slayer_MinigameSO::getPref(%this, %category, %title)
{
	return Slayer.Prefs.getPref(%category, %title, %this);
}

function Slayer_MinigameSO::resetPrefs(%this)
{
	Slayer.Prefs.resetPrefs(%this);
}

function Slayer_MinigameSO::updateColor(%this, %new, %old)
{
	if($MinigameColorTaken[%new])
		%this.colorIdx = %old;
	else
	{
		$MinigameColorTaken[%new] = 1;
		$MinigameColorTaken[%old] = 0;
		%this.colorRGB = $MiniGameColorF[%new];

		for(%i = 0; %i < %this.numMembers; %i ++)
		{
			%cl = %this.member[%i];
			if(!isObject(%cl.slyrTeam) && isObject(%cl.player))
				%cl.player.setShapeNameColor($MiniGameColorF[%new]);
		}
	}
}

function Slayer_MinigameSO::updateGamemode(%this, %mode, %current)
{
	%mode = Slayer.Gamemodes.getModeFromFName(%mode);
	%current = Slayer.Gamemodes.getModeFromFName(%current);

	if(!isObject(%mode))
	{
		%this.mode = %current.fName;
		%this.Gamemode = %current;
		return;
	}

	if(isFunction("Slayer_" @ %current.fName @ "_onModeEnd"))
		call("Slayer_" @ %current.fName @ "_onModeEnd", %this);

	if(%current.teams && !%mode.teams)
		%this.Teams.removeAllMembers();
	else if(%mode.teams)
	{
		for(%i = 0; %i < %this.numMembers; %i ++)
		{
			%cl = %this.member[%i];
			if(!isObject(%cl.slyrTeam))
				%this.Teams.autoSort(%cl);
		}
	}

	%this.mode = %mode.fName;
	%this.Gamemode = %mode;

	if(isFunction("Slayer_" @ %this.mode @ "_onModeStart"))
		call("Slayer_" @ %this.mode @ "_onModeStart", %this);
}

function Slayer_MinigameSO::updateLives(%this, %new, %old)
{
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		%cl = %this.member[%i];

		%t = %cl.getTeam();
		if(isObject(%t) && %t.lives >= 0)
			continue;

		if(%new <= 0)
		{
			%cl.setLives(0);
			if(%cl.dead())
			{
				%cl.setDead(0);
				if(!isObject(%cl.player))
					%cl.spawnPlayer();
			}
			continue;
		}

		if(%old $= "")
			%cl.setLives(%new);
		else
			%cl.addLives(%new-%old);

		%lives = %cl.getLives();
		if(%lives <= 0 && !%cl.dead())
		{
			%cl.setDead(1);
			if(isObject(%cl.player))
			{
				%cl.camera.setMode(observer);
				%cl.setControlObject(%cl.camera);
				%cl.player.delete();
			}
			%cl.centerPrint("\c5The number of lives was reduced. You are now out of lives.", 5);

			%check = 1;
		}
		else if(%lives > 0 && %cl.dead())
		{
			%cl.setDead(0);
			if(!isObject(%cl.player))
				%cl.spawnPlayer();
		}
	}

	if(%check)
	{
		%win = %this.victoryCheck_Lives();
		if(%win >= 0)
			%this.endRound(%win);
	}
}

function Slayer_MinigameSO::updatePoints(%this, %new, %old)
{
	%this.victoryCheck_Points();
}

function Slayer_MinigameSO::updateTime(%this, %new, %old)
{
	if(%new <= 0 && %old > 0)
		cancel(%this.timeSchedule);
	else if(%new > 0 && %old <= 0 && %this.Gamemode.rounds)
	{
		cancel(%this.timeSchedule);
		%this.victoryCheck_Time(0);
	}
}

function Slayer_MinigameSO::updateRespawnTime(%this, %type, %flag, %old)
{
	%oldTime = %old * 1000;

	if(%flag == -1)
		%time = -1;
	else
	{
		%time = %flag * 1000;
		%time = Slayer_Support::mRestrict(%time, -999999, 999999);
	}

	switch$(%type)
	{
		case "player":
			%this.respawnTime = %time;

			for(%i = 0; %i < %this.numMembers; %i ++)
			{
				%cl = %this.member[%i];
				%t = %cl.getTeam();
				if(isObject(%t) && %t.lives >= 0)
					continue;
				if(%cl.respawnTime == %oldTime)
					%cl.setRespawnTime(%time);
			}

		case "bot":
			%this.botRespawnTime = %time;

		case "brick":
			%this.brickRespawnTime = %time;

		case "vehicle":
			%this.vehicleRespawnTime = %time;

		case "penalty_FF":
			%this.friendlyFireRespawnPenalty = %time;

		default:
			if(%type !$= "")
			{
				%this.respawnTime_[%type] = %time;
			}
	}
}

function Slayer_MinigameSO::updateNameDistance(%this, %flag)
{
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		%cl = %this.member[%i];
		if(isObject(%cl.player))
			%cl.player.setShapeNameDistance(%flag);
	}
}

function Slayer_MinigameSO::updateDefaultMinigame(%this, %flag)
{
	if(%this.isStarting)
		return;

	if(%flag)
		Slayer.Minigames.setDefaultMinigame(%this);
	else if(%this == Slayer.Minigames.defaultMinigame)
		Slayer.Minigames.setDefaultMinigame(0);
}

//different than the default forceEquip
//because it only forces the item if the player hasn't changed it
function Slayer_MinigameSO::updateEquip(%this, %slot, %new, %old)
{
	for(%i = 0; %i < %this.numMembers; %i ++)
	{
		%cl = %this.member[%i];
		if(!isObject(%cl.getTeam()))
		{
			%cl.updateEquip(%slot, %new, %old);
		}
	}
}

function Slayer_MinigameSO::pickSpawnPoint(%this, %client)
{
	if(!%this.useSpawnBricks
		|| (%numSpawns = Slayer.Spawns.getCount()) < 1)
		return pickSpawnPoint();

	if(isFunction("Slayer_" @ %this.mode @ "_pickSpawnPoint"))
	{
		%special = call("Slayer_" @ %this.mode @ "_pickSpawnPoint", %this, %client);
		if(isObject(%special))
			return %special;
	}

	%team = %client.getTeam();
	%count = 0;
	%openCount = 0;

	if(isObject(%team))
	{
		for(%i = 0; %i < %numSpawns; %i ++)
		{
			%sp = Slayer.Spawns.getObject(%i);
			%type = %sp.getDatablock().slyrType;
			%color = %sp.getControl();

			if(%type !$= "TeamSpawn"
				|| !minigameCanUse(%client, %sp)
				|| %color != %team.color)
				continue;

			if(!%sp.isBlocked())
			{
				%openSpawn[%openCount] = %sp;
				%openCount ++;
			}
			%spawn[%count] = %sp;
			%count ++;
		}
	}

	if(%count < 1)
	{
		for(%i = 0; %i < %numSpawns; %i ++)
		{
			%sp = Slayer.Spawns.getObject(%i);
			%db = %sp.getDatablock();

			if(%db.getName() !$= "brickSpawnPointData"
				|| !minigameCanUse(%client, %sp)
				|| (%this.spawnBrickColor >= 0 && %sp.getColorID() != %this.spawnBrickColor))
				continue;

			if(!%sp.isBlocked())
			{
				%openSpawn[%openCount] = %sp;
				%openCount ++;
			}
			%spawn[%count] = %sp;
			%count ++;
		}
	}

	Slayer_Support::Debug(2, "Slayer_MinigameSO::pickSpawnPoint", "open:" SPC %openCount SPC "total:" SPC %count);

	if(%count < 1)
		return pickSpawnPoint();
	else if(%openCount > 0)
	{
		%r = getRandom(0, %openCount - 1);
		%spawn = %openSpawn[%r];
	}
	else
	{
		%r = getRandom(0, %count - 1);
		%spawn = %spawn[%r];
	}

	if(%client.isHoleBot)
		%client.lastSpawnBrick = %spawn;
	if(isObject(%spawn))
		return %spawn.getSpawnPoint();
	else
		return pickSpawnPoint();
}

function Slayer_MinigameSO::messageAllDead(%this, %cmd, %msg, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q)
{
	for(%index=0; %index < %this.numMembers; %index ++)
	{
		%cl = %this.member[%index];
		if(%cl.dead())
			messageClient(%cl, %cmd, %msg, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q);
	}
}

function Slayer_MinigameSO::commandToAll(%this, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r, %s)
{
	for(%index = 0; %index < %this.numMembers["GameConnection"]; %index ++)
		commandToClient(%this.member["GameConnection", %index], %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r, %s);
}

function Slayer_MinigameSO::commandToAllSlayerClients(%this, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r, %s)
{
	for(%index = 0; %index < %this.numMembers["GameConnection"]; %index ++)
	{
		%cl = %this.member["GameConnection", %index];
		if(%cl.slayer)
			commandToClient(%cl, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r, %s);
	}
}

function Slayer_MinigameSO::play2dAll(%this, %sound)
{
	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
		%this.member["GameConnection", %i].play2d(%sound);
}

//for events
function Slayer_MinigameSO::centerPrintAll(%this, %msg, %time, %client)
{
	if(isObject(%client))
		%msg = strReplace(%msg, "%1", %client.getPlayerName());

	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
		%this.member["GameConnection", %i].centerPrint(%msg, %time);
}

//for events
function Slayer_MinigameSO::bottomPrintAll(%this, %msg, %time, %hideBar, %client)
{
	if(isObject(%client))
		%msg = strReplace(%msg, "%1", %client.getPlayerName());

	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
		%this.member["GameConnection", %i].bottomPrint(%msg, %time, %hideBar);
}

//for events
function Slayer_MinigameSO::chatMsgAll(%this, %msg, %client)
{
	if(isObject(%client))
		%msg = strReplace(%msg, "%1", %client.getPlayerName());

	for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
		%this.member["GameConnection", %i].chatMessage(%msg);
}

//for events
function Slayer_MinigameSO::respawnAll(%this, %client)
{
	for(%i = 0; %i < %this.numMembers; %i ++)
		%this.member[%i].spawnPlayer();
}

//for events
function Slayer_MinigameSO::incTimeRemaining(%this, %flag, %display)
{
	%inc = %flag * 60000;

	//round to the nearest 30 seconds
	%rmndr = %this.timeRemaining % 30000;
	if(%rmndr >= 15000)
	{
		%this.timeTickLength = 60000;
		%remain = %this.timeRemaining + (30000 - %rmndr);
	}
	else
	{
		%this.timeTickLength = 30000;
		%remain = %this.timeRemaining - %rmndr;
	}

	if(%display)
	{
		%min = (%flag == 1 ? "minute" : "minutes");
		%this.messageAll('', "\c5The round has been extended by\c3" SPC %flag SPC "\c5" @ %min @ ".");
	}

	%this.timeRemaining = %remain + %inc + %this.timeTickLength;
	%this.victoryCheck_time(%this.timeTicks + 1);
}

//for events
function Slayer_MinigameSO::setTimeRemaining(%this, %flag, %display)
{
	%time = %flag * 60000;

	if(%time > 1)
		%this.timeTickLength = 60000;
	else
		%this.timeTickLength = 30000;

	if(%display)
	{
		%min = (%flag == 1 ? "minute" : "minutes");
		%this.messageAll('', "\c5The round has been set to\c3" SPC %flag SPC "\c5" @ %min @ ".");
	}

	%this.timeRemaining = %time + %this.timeTickLength;
	%this.victoryCheck_time(%this.timeTicks + 1);
}

//for events
function MinigameSO::Slayer_setPref(%this, %category, %title, %value, %client)
{
	if(!isSlayerMinigame(%this))
		return;

	%pref = Slayer.Prefs.getPrefSO(%category, %title);
	if(!isObject(%pref))
		return;

	if((!isObject(%client) && %pref.editRights == -1) || %this.canEdit(%client, %pref.editRights))
		%pref.setValue(%value, %this);
}

//for events
function MinigameSO::Win(%this, %mode, %flag, %client)
{
	if(isObject(%client) && getMinigameFromObject(%client) != %this)
		return;

	if(!isSlayerMinigame(%this))
		return;

	switch(%mode)
	{
		case 0: //TRIGGERPLAYER
			if(isObject(%client))
				%this.endRound(%client);

		case 1: //TRIGGERTEAM
			if(isObject(%client))
			{
				%team = %client.getTeam();
				if(isObject(%team))
					%this.endRound(%team);
			}

		case 2: //CUSTOMPLAYER
			%cl = findClientByName(%flag);
			if(isObject(%cl))
				%this.endRound(%cl);

		case 3: //CUSTOMTEAM
			%team = %this.Teams.getTeamFromName(%flag);
			if(isObject(%team))
				%this.endRound(%team);

		case 4: //CUSTOMSTRING
			%this.endRound("CUSTOM" TAB %flag);

		case 5: //NONE
			%this.endRound();
	}
}

function Slayer_MinigameSO::getFakeClient(%this)
{
	if(!isObject(%this.fakeClient))
	{
		%blid = %this.creatorBLID;
		%brickgroup = nameToID("BrickGroup_" @ %blid);

		%this.fakeClient = new AiClient()
		{
			name = "Slayer";
			netName = "Slayer";
			LANName = "Slayer";
			bl_id = %blid;

			minigame = %this;

			brickgroup = %brickgroup;

			isSlayerFakeClient = 1;
		};
	}

	Slayer_Support::Debug(2, "Getting fake client", %this.fakeClient);

	return %this.fakeClient;
}

//PERMISSIONS
function MinigameSO::canEdit(%this, %client, %overRide)
{
	if(!isObject(%client))
		return 0;

	if(!isSlayerMinigame(%this))
	{
		Slayer_Support::Debug(3, "MinigameSO::canEdit", "False - Not a Slayer minigame");
		return 0;
	}

	if(%client.isHost)
	{
		Slayer_Support::Debug(3, "MinigameSO::canEdit", "True - Client is host");
		return 1;
	}

	%edit = %this.getPref("Permissions", "Edit Rights");

	%brickgroup = "Brickgroup_" @ %this.creatorBLID;

	switch(%edit)
	{
		case 0:
			%canEdit = %client.isHost;

		case 1:
			%canEdit = %client.isSuperAdmin;

		case 2:
			%canEdit = %client.isAdmin;

		case 3:
			%canEdit = (getTrustLevel(%client, %brickgroup) >= 3 || %client.getBLID() == %this.creatorBLID);

		case 4:
			%canEdit = (getTrustLevel(%client, %brickgroup) >= 2);

		case 5:
			%canEdit = (getTrustLevel(%client, %brickgroup) >= 1);

		default:
			Slayer_Support::Error("MinigameSO::canEdit", "[Permissions | Edit Rights] is invalid.");
			%canEdit = 0;
	}

	if(%canEdit && %overRide !$= "")
	{
		switch(%overRide)
		{
			case 0:
				%canEdit = %client.isHost;

			case 1:
				%canEdit = %client.isSuperAdmin;

			case 2:
				%canEdit = %client.isAdmin;

			case 3:
				%canEdit = (getTrustLevel(%client, %brickgroup) >= 3 || %client.getBLID() == %this.creatorBLID);

			case 4:
				%canEdit = (getTrustLevel(%client, %brickgroup) >= 2);

			case 5:
				%canEdit = (getTrustLevel(%client, %brickgroup) >= 1);
		}
	}

	Slayer_Support::Debug(3, "MinigameSO::canEdit", %canEdit);

	return %canEdit;
}

function MinigameSO::canReset(%this, %client, %overRide)
{
	if(!isObject(%client))
		return 0;

	if(!isSlayerMinigame(%this))
		return 0;

	if(%client.isHost)
		return 1;

	if(%client.getBLID() == %this.creatorBLID)
		return 1;

	%reset = %this.getPref("Permissions", "Reset Rights");

	%brickgroup = "Brickgroup_" @ %this.creatorBLID;

	switch(%reset)
	{
		case 0:
			%canReset = %client.isHost;

		case 1:
			%canReset = %client.isSuperAdmin;

		case 2:
			%canReset = %client.isAdmin;

		case 3:
			%canReset = (getTrustLevel(%client, %brickgroup) >= 3);

		case 4:
			%canReset = (getTrustLevel(%client, %brickgroup) >= 2);

		case 5:
			%canReset = (getTrustLevel(%client, %brickgroup) >= 1);

		default:
			Slayer_Support::Error("MinigameSO::canReset", "[Permissions | Reset Rights] is invalid.");
			%canReset = 0;
	}

	if(%canReset && %overRide !$= "")
	{
		switch(%overRide)
		{
			case 0:
				%canReset = %client.isHost;

			case 1:
				%canReset = %client.isSuperAdmin;

			case 2:
				%canReset = %client.isAdmin;

			case 3:
				%canReset = (getTrustLevel(%client, %brickgroup) >= 3);

			case 4:
				%canReset = (getTrustLevel(%client, %brickgroup) >= 2);

			case 5:
				%canReset = (getTrustLevel(%client, %brickgroup) >= 1);
		}
	}

	return %canReset;
}

function MinigameSO::canLeave(%this, %client, %overRide)
{
	if(!isObject(%client))
		return 0;

	if(!isSlayerMinigame(%this))
		return 0;

	if(!%this.isDefaultMinigame)
		return 1;

	if(%client.isHost)
		return 1;

	if(%client.getBLID() == %this.creatorBLID)
		return 1;

	%leave = %this.getPref("Permissions", "Leave Rights");

	%brickgroup = "Brickgroup_" @ %this.creatorBLID;

	switch(%leave)
	{
		case 0:
			%canLeave = %client.isHost;

		case 1:
			%canLeave = %client.isSuperAdmin;

		case 2:
			%canLeave = %client.isAdmin;

		case 3:
			%canLeave = (getTrustLevel(%client, %brickgroup) >= 3);

		case 4:
			%canLeave = (getTrustLevel(%client, %brickgroup) >= 2);

		case 5:
			%canLeave = (getTrustLevel(%client, %brickgroup) >= 1);

		default:
			Slayer_Support::Error("MinigameSO::canLeave", "[Permissions | Leave Rights] is invalid.");
			%canLeave = 0;
	}

	if(%canLeave && %overRide !$= "")
	{
		switch(%overRide)
		{
			case 0:
				%canLeave = %client.isHost;

			case 1:
				%canLeave = %client.isSuperAdmin;

			case 2:
				%canLeave = %client.isAdmin;

			case 3:
				%canLeave = (getTrustLevel(%client, %brickgroup) >= 3);

			case 4:
				%canLeave = (getTrustLevel(%client, %brickgroup) >= 2);

			case 5:
				%canLeave = (getTrustLevel(%client, %brickgroup) >= 1);
		}
	}

	return %canLeave;
}

function isSlayerMinigame(%mini)
{
	if(!isObject(%mini))
		return 0;

	if(!%mini.isSlayerMinigame)
		return 0;

	if(!isObject(Slayer.Minigames) || !Slayer.Minigames.isMember(%mini))
		return 0;

	return 1;
}

// +------------+
// | serverCmds |
// +------------+
function serverCmdSlayer(%client, %cmd, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r, %s, %t)
{
	if(%client.isSpamming())
		return;

	%mini = getMinigameFromObject(%client);

	switch$(%cmd)
	{
		case "edit":
			if(isObject(%a) || %a == -1)
				%minigame = %a;
			else
				%minigame = %mini;

			if(isSlayerMinigame(%minigame))
			{
				if(!%minigame.canEdit(%client))
				{
					messageClient(%client, '', "\c5You don't have permission to edit that minigame!");
					return;
				}
			}
			else
			{
				if(!Slayer.Minigames.canCreate(%client))
				{
					messageClient(%client, '', "\c5You don't have permission to create a minigame!");
					return;
				}
			}

			if(!%client.slayer)
			{
				if(%client.slayerVersion !$= "")
					commandToClient(%client, 'messageBoxOK', "Slayer | Error", "Version Mismatch!\n\nYou appear to be running a different version of Slayer than the server. Make sure you have the latest version.\n\n<a:mods.greek2me.us/storage/Gamemode_Slayer.zip>Download Latest Version</a>\n\nYour Version:" SPC %client.slayerVersion NL "Server:" SPC $Slayer::Server::Version);
				else
					commandToClient(%client, 'messageBoxOK', "Slayer | Error", "Missing GUI\n\nThis server is running the Slayer gamemode. To change the settings for Slayer, you need to download and install the Slayer GUI.\n\n<a:mods.greek2me.us/storage/Gamemode_Slayer.zip>Download Slayer</a>\n\nServer Version:" SPC $Slayer::Server::Version);
				return;
			}

			Slayer.sendData(%client, %minigame, "Slayer_Main");

		case "reset":
			if(isObject(%mini) && %mini.canReset(%client) && !%mini.isResetting)
				%mini.reset(%client);

		case "end":
			if(isObject(%client.editingMinigame) || %client.editingMinigame == -1)
			{
				commandToClient(%client, 'Slayer_ForceGUI', "ALL", 0);
				%minigame = %client.editingMinigame;
			}
			else
				%minigame = %mini;

			if(isObject(%minigame) && %minigame.canEdit(%client))
				%minigame.endGame();

		case "rules":
			if(isSlayerMinigame(%mini))
			{
				%team = %client.slyrTeam;
				%lifeCount = ((isObject(%team) && %team.lives >= 0) ? %team.lives : %mini.lives);
				%lives = "\c3" @ %lifeCount SPC "\c5" @ (%lifeCount == 1 ? "life" : "lives");
				%points = "\c3" @ %mini.points SPC "\c5" @ (%mini.points == 1 ? "point" : "points");
				%time = "\c3" @ %mini.time SPC "\c5" @ (%mini.time == 1 ? "minute" : "minutes");

				%person = (%mini.Gamemode.teams ? "team" : "man");

				messageClient(%client, '', "\c3" @ %mini.Gamemode.uiName);
				if(%lifeCount > 0)
					messageClient(%client, '', '\c5 + %1 - The last %2 standing wins.', %lives, %person);
				if(%mini.points > 0)
					messageClient(%client, '', '\c5 + %1 - The first %2 to reach %1 wins.', %points, %person);
				if(%mini.time > 0)
					messageClient(%client, '', '\c5 + %1 - The %2 with the highest score after %1 wins.', %time, %person);
				if(%mini.customRule !$= "")
					messageClient(%client, '', "\c5 +" SPC %mini.customRule);

				if(isFunction("Slayer_" @ %mini.mode @ "_onRules"))
					call("Slayer_" @ %mini.mode @ "_onRules", %mini, %client);
			}

		case "dump":
			%msg = '\c5[\c3%1\c5|\c3%2\c5] \c3%3';
			%count = Slayer.Prefs.getCount();
			for(%i = 0; %i < %count;%i ++)
			{
				%pref = Slayer.Prefs.getObject(%i);
				if(striPos(%pref.variable, "%mini") >= 0 && !isObject(%mini))
					%val = "";
				else
					%val = %pref.getValue(%mini);
				messageClient(%client, '', %msg, %pref.category, %pref.title, %val);
			}

		default:
			messageClient(%client, '', "\c5This server is running <a:bitbucket.org/Greek2me/slayer/downloads>Slayer</a> \c3v" @ $Slayer::Server::Version @ "\c5, by Greek2me (Blockland ID 11902).");
	}
}

function serverCmdRequestSlayerMiniGameColorList(%client)
{
	%mini = %client.editingMinigame;
	if(!isObject(%mini))
		%mini = getMinigameFromObject(%client);

	for(%i = 0; %i < $MiniGameColorCount; %i ++)
	{
		if(!$MiniGameColorTaken[%i] || (isObject(%mini) && %mini.colorIdx == %i))
			commandToClient(%client, 'addSlayerMiniGameColor', %i, $MiniGameColorName[%i], $MiniGameColorI[%i]);
	}
}

// +--------------------+
// | Packaged Functions |
// +--------------------+
package Slayer_Dependencies_Minigames
{
	function serverCmdCreateMinigame(%client, %a, %b, %c, %d, %e, %f, %g)
	{
		%mini = getMinigameFromObject(%client);

		if(isSlayerMinigame(%mini))
		{
			if(%mini.canLeave(%client))
			{
				%mini.removeMember(%client);
				parent::serverCmdCreateMinigame(%client, %a, %b, %c, %d, %e, %f, %g);
			}
			else
				messageClient(%client, '', "\c5You don't have permission to do that.");
		}
		else
			parent::serverCmdCreateMinigame(%client, %a, %b, %c, %d, %e, %f, %g);
	}

	function serverCmdLeaveMinigame(%client)
	{
		%mini = getMinigameFromObject(%client);

		if(!isSlayerMinigame(%mini) || (%can = %mini.canLeave(%client)))
			parent::serverCmdLeaveMinigame(%client);
		else if(!%can)
		{
			messageClient(%client, '', "\c5You don't have permission to do that.");
			return;
		}
	}

	function serverCmdJoinMinigame(%client, %minigame)
	{
		%mini = getMinigameFromObject(%client);

		if(isSlayerMinigame(%mini))
		{
			if(!%mini.canLeave(%client))
				return;
		}

		if(isSlayerMinigame(%minigame))
		{
			if(%mini == %minigame)
			{
				messageClient(%client, '', 'You\'re already in that mini-game.');
				return;
			}
			else if(%minigame.inviteOnly && %client.minigameInvitePending != %minigame && %mini.creatorBLID == %client.getBLID())
			{
				messageClient(%client, '', 'That mini-game is invite-only.');
				return;
			}
			else
				%minigame.addMember(%client);
		}
		else
			parent::serverCmdJoinMinigame(%client, %minigame);
	}

	function serverCmdResetMinigame(%client)
	{
		%mini = getMinigameFromObject(%client);
		if(isSlayerMinigame(%mini) && %mini.canReset(%client) && !%mini.isResetting)
			%mini.reset(%client);
		else
			parent::serverCmdResetMinigame(%client);
	}

	function serverCmdEndMinigame(%client)
	{
		%mini = getMinigameFromObject(%client);
		if(isSlayerMinigame(%mini) && %mini.canEdit(%client))
			%mini.endGame();
		else
			parent::serverCmdEndMinigame(%client);
	}

	function serverCmdSetMiniGameData(%client, %data1, %data2, %data3, %data4)
	{
		if(!isSlayerMinigame(getMinigameFromObject(%client)))
			parent::serverCmdSetMiniGameData(%client, %data1, %data2, %data3, %data4);
	}

	function serverCmdInviteToMinigame(%client, %victim)
	{
		%mini = getMinigameFromObject(%client);
		if(isSlayerMinigame(%mini))
		{
			if(%mini.canEdit(%client))
			{
				if(isObject(%victim))
				{
					%pend = %victim.minigameInvitePending;

					if(isObject(%pend))
					{
						if(%pend == %mini)
							commandToClient(%client, 'messageBoxOK', 'Mini-Game Invite Error', 'This person hasn\'t responded to your first invite yet.');
						else
							commandToClient(%client, 'messageBoxOK', 'Mini-Game Invite Error', 'This person is considering another invite right now.');
					}
					else if(%mini.isMember(%victim))
					{
						commandToClient(%client, 'messageBoxOK', 'Mini-Game Invite Error', 'This person is already in the mini-game.');
					}
					else
					{
						%victim.minigameInvitePending = %mini;
						commandToClient(%victim, 'minigameInvite', %mini.title, %mini.hostName, %mini.creatorBLID, %mini);
					}
				}
			}
			else
			{
				commandToClient(%client, 'messageBoxOK', 'Mini-Game Invite Error', 'You do not have permission to send invites.');
			}
		}
		else
			parent::serverCmdInviteToMinigame(%client, %victim);
	}

	function serverCmdAcceptMinigameInvite(%client, %mini)
	{
		if(isSlayerMinigame(%mini))
		{
			if(!%mini.isMember(%client))
			{
				%mini.addMember(%client);
			}
		}
		else
			parent::serverCmdAcceptMinigameInvite(%client, %mini);
	}

	function serverCmdRejectMinigameInvite(%client, %mini)
	{
		if(isSlayerMinigame(%mini))
		{
			%creator = findClientByBL_ID(%mini.creatorBLID);
			if(isObject(%creator))
				messageClient(%creator, '', '%1 rejected your mini-game invitation', %client.getPlayerName());

			%client.minigameInvitePending = 0;
		}
		else
			parent::serverCmdRejectMinigameInvite(%client, %mini);
	}

	function serverCmdIgnoreMinigameInvite(%client, %mini)
	{
		if(isSlayerMinigame(%mini))
		{
			%creator = findClientByBL_ID(%mini.creatorBLID);
			if(isObject(%creator))
				messageClient(%creator, '', '%1 rejected your mini-game invitation (ignoring)', %client.getPlayerName());

			%client.minigameInvitePending = 0;
		}
		else
			parent::serverCmdRejectMinigameInvite(%client, %mini);
	}

	function serverCmdRemoveFromMinigame(%client, %victim)
	{
		%mini = getMinigameFromObject(%client);
		if(isSlayerMinigame(%mini))
		{
			if(%mini.canEdit(%client))
			{
				if(isObject(%victim))
				{
					if(%mini.isMember(%victim))
					{
						%clName = %client.getPlayerName();
						%vName = %victim.getPlayerName();

						%mini.removeMember(%victim);
						messageClient(%victim, '', '%1 kicked you from the minigame', %clName);
						%mini.messageAll('', '%1 kicked %2 from the minigame', %clName, %vname);
					}
				}
			}
		}
		else
			parent::serverCmdRemoveFromMinigame(%client, %victim);
	}

	function Slayer_MinigameSO::addMember(%this, %client)
	{
		if(%this.isStarting)
			return;
		if(!isObject(%client))
			return;

		if(isObject(%client.minigame))
		{
			if(%client.minigame == %this || %this.isMember(%client))
				return;

			%client.minigame.removeMember(%client);
		}

		%class = %client.getClassName();
		if(%this.numMembers[%class] $= "")
			%this.numMembers[%class] = 0;

		if(%this.resetOnEmpty && %this.numMembers[%class] < 1 && %this.isResetting() && %class $= "GameConnection")
			%this.reset(0);

		%client.minigame = %this;
		%client.minigameJoinTime = getSimTime();
		%client.minigameInvitePending = 0;

		%this.member[%this.numMembers] = %client;
		%this.numMembers ++;
		%this.member[%class, %this.numMembers[%class]] = %client;
		%this.numMembers[%class] ++;

		//reset their stats
		%client.setScore(0);
		%client.setDeaths(0);
		%client.setKills(0);
		%client.setLives(%this.lives);
		%client.wins = 0;

		if(%class $= "GameConnection")
		{
			clearCenterPrint(%client);
			clearBottomPrint(%client);

			commandToClient(%client, 'SetBuildingDisabled', !%this.enableBuilding);
			commandToClient(%client, 'SetPaintingDisabled', !%this.enablePainting);
			commandToClient(%client, 'SetPlayingMinigame', 1); //enables the Leave button in the join minigame GUI

			//notify members
			%joinMessage = "\c1" @ %client.getPlayerName() SPC "joined the\c3" SPC %this.title SPC "\c1mini-game.";
			%this.messageAll('MsgClientInYourMiniGame', %joinMessage, %client, 1);
			for(%i = 0; %i < %this.numMembers; %i ++)
			{
				%cl = %this.member[%i];
				if(%cl.getClassName() $= "GameConnection" && %cl != %client)
					messageClient(%client, 'MsgClientInYourMiniGame', '', %cl, 1);
			}

			//tell them the gamemode, lives, points, time
			%client.ignoreSpam = 1;
			serverCmdSlayer(%client, rules);
			if(%this.Gamemode.teams && !%this.Teams.lock)
				messageClient(%client, '', "\c5 + Type \c3/joinTeam [Team Name] \c5to join a team. Type \c3/listTeams \c5to view a list of teams.");

			//autosort into team
			if(%this.Gamemode.teams && %this.Teams.autoSort)
				%this.Teams.autoSort(%client, 1);

			//late join time
			%ljt = %this.lateJoinTime;
			if(%this.getLiving()-1 > 1 && %this.Gamemode.rounds && %ljt >= 0 && ($Sim::Time-%this.roundStarted())/60 > %ljt)
			{
				%client.setDead(1);
				%tar = %client.nextCamTarget();
				if(!isObject(%tar))
				{
					%client.setControlObject(%client.camera);
					%client.camera.setMode(observer);
				}

				messageClient(%client, '', "\c5You will spawn when the next round starts.");
				%client.centerPrint("\c5You will spawn when the next round starts.", 6);

				if(isObject(%client.player))
					%client.player.delete();
			}
			else
				%client.spawnPlayer();

			//onMinigameJoin input event
			$InputTarget_["Client"] = %client;
			$InputTarget_["Player"] = %client.player;
			$InputTarget_["Minigame"] = %this;
			processMultiSourceInputEvent("onMinigameJoin", %client, %this);
		}
		else if(%class $= "AiConnection")
		{
			%client.removeAllObjectives();
			%client.assignObjectives();
			%client.spawnPlayer();
		}

		Slayer_Support::Debug(1, "Slayer_MinigameSO::addMember", %client.getSimpleName());

		if(isFunction("Slayer_" @ %this.mode @ "_onJoin"))
			call("Slayer_" @ %this.mode @ "_onJoin", %this, %client);

		//call this for compatibility
		if(%class $= "GameConnection")
			parent::addMember(%this, %client);
	}

	function Slayer_MinigameSO::removeMember(%this, %client)
	{
		if(!isObject(%client) || !%this.isMember(%client))
			return;

		%class = %client.getClassName();

		if(%class $= "GameConnection")
		{
			//onMinigameLeave input event
			$InputTarget_["Client"] = %client;
			$InputTarget_["Player"] = %client.player;
			$InputTarget_["Minigame"] = %this;
			processMultiSourceInputEvent("onMinigameLeave", %client, %this);
		}

		//GAMEMODE STUFF
		if(isFunction("Slayer_" @ %this.mode @ "_onLeave"))
			call("Slayer_" @ %this.mode @ "_onLeave", %this, %client);

		//REMOVE FROM TEAM
		%team = %client.getTeam();
		if(isObject(%team))
			%team.removeMember(%client);

		//CLEAR GUI
		clearCenterPrint(%client);
		clearBottomPrint(%client);
		if(%client.slayer)
			commandToClient(%client, 'Slayer_ForceGUI', "Slayer_CtrDisplay", 0);

		//CLEAR ATTRIBUTES
		%client.resetRespawnTime();
		%client.setDead(0);
		%client.setDeaths(0);
		%client.setLives(0);
		%client.setKills(0);

		//REMOVE FROM CLASS MEMBER ARRAY
		%start = -1;
		for(%i = 0; %i < %this.numMembers[%class]; %i ++)
		{
			if(%this.member[%class, %i] == %client) //find the member to be removed
			{
				%this.member[%class, %i] = "";
				%start = %i;
				break;
			}
		}
		if(%start >= 0)	
		{
			for(%i = %start + 1; %i < %this.numMembers[%class]; %i ++)
				%this.member[%class, %i - 1] = %this.member[%class, %i];

			%this.member[%class, %this.numMembers[%class] - 1] = "";
			%this.numMembers[%class] --;
		}

		if(%class $= "GameConnection")
		{
			//PREVENT OUR OWN DELETION
			if(%this.numMembers <= 1)
			{
				%subtract = 1;
				%this.numMembers ++; //hack!
			}

			//PREVENT VEHICLE DELETION
			%oldClearEventObjects = %client.doNotClearEventObjects;
			%oldClearVehicles = %client.doNotResetVehicles;
			%client.doNotClearEventObjects = 1;
			%client.doNotResetVehicles = 1;

			//CALL PARENT FOR COMPATIBILITY
			parent::removeMember(%this, %client);

			//RESTORE EVERYTHING
			%client.doNotClearEventObjects = %oldClearEventObjects;
			%client.doNotResetVehicles = %oldClearVehicles;
			if(%subtract)
				%this.numMembers --;

			//PAUSE GAME IF EMPTY
			if(%this.resetOnEmpty && %this.numMembers[%class] < 1)
			{
				for(%i = 0; %i < %this.numMembers["AiConnection"]; %i ++)
				{
					%ai = %this.member["AiConnection", %i];
					cancel(%ai.respawnSchedule);
					if(isObject(%ai.player))
						%ai.player.delete();
				}
				%this.isSuspended = true;
				%this.endRound(0, -1);
				cancel(%this.resetTimer); //in case it was resetting already
			}
		}
		else
		{
			//REMOVE FROM MEMBER ARRAY
			%start = -1;
			for(%i = 0; %i < %this.numMembers; %i ++)
			{
				if(%this.member[%i] == %client) //find the member to be removed
				{
					%this.member[%i] = "";
					%start = %i;
					break;
				}
			}
			if(%start >= 0)	
			{
				for(%i = %start + 1; %i < %this.numMembers; %i ++)
					%this.member[%i - 1] = %this.member[%i];

				%this.member[%this.numMembers - 1] = "";
				%this.numMembers --;
			}

			%client.miniGame = -1;
		}

		//CHECK IF ANYONE WON
		if(!%this.isSuspended)
		{
			if(%this.lives > 0 || %team.lives > 0)
			{
				%winner = %this.victoryCheck_Lives();
				if(%winner >= 0)
					%this.endRound(%winner);
			}
		}

		Slayer_Support::Debug(1, "Slayer_MinigameSO::removeMember", %client.getSimpleName());
	}

	function Slayer_MinigameSO::Reset(%this, %client)
	{
		if(getSimTime() - %this.lastResetTime < $Slayer::Server::Minigames::ResetTimeOut)
		{
			Slayer_Support::Error("Slayer_MinigameSO::Reset", "Minigame being reset too quickly!");
			return;
		}

		//make sure the schedules stop
		cancel(%this.timeSchedule);
		cancel(%this.resetTimer);
		for(%i = 0; %i < %this.resetCountdownTimerCount; %i ++)
			cancel(%this.resetCountdownTimer[%i]);

		//no longer suspended
		%this.isSuspended = false;

		//the minigame is resetting
		%this.setResetting(1);

		if(isFunction("Slayer_" @ %this.mode @ "_preReset"))
			call("Slayer_" @ %this.mode @ "_preReset", %this, %client);

		%this.resetBricks();
		%this.resetCapturePoints(%client);
		%this.Teams.onMinigameReset();
		if($AddOnLoaded__Bot_Hole)
			%this.resetBots();

		if(!isObject(%client))
			%client = 0;

		for(%i = 0; %i < %this.numMembers["GameConnection"]; %i ++)
		{
			%cl = %this.member["GameConnection", %i];
			%t = %cl.slyrTeam;

			%cl.setDead(0);
			%cl.setLives((isObject(%t) && %t.lives >= 0) ? %t.lives : %this.lives);
			if(%this.clearStats)
			{
				%cl.setKills(0);
				%cl.setDeaths(0);
			}

			clearCenterPrint(%cl);
			clearBottomPrint(%cl);
			commandToClient(%cl, 'Slayer_ForceGUI', "Slayer_CtrDisplay", 0);

			if(!%this.disableSlayerMessages)
			{
				if(%client)
					messageClient(%cl, '', '\c3%1 \c5reset the \c3%2 \c5minigame.', %client.name, %this.title);
				else
					messageClient(%cl, '', '\c5The \c3%1 \c5minigame was reset.', %this.title);

				//let them know the rules
				%cl.ignoreSpam = 1;
				serverCmdSlayer(%cl, "rules");
			}
		}
		for(%i = 0; %i < %this.numMembers["AiConnection"]; %i ++)
		{
			%ai = %this.member["AiConnection", %i];
			%t = %ai.slyrTeam;

			%ai.setDead(0);
			%ai.setLives((isObject(%t) && %t.lives >= 0) ? %t.lives : %this.lives);
			if(%this.clearStats)
			{
				%ai.setKills(0);
				%ai.setDeaths(0);
			}

			//Bot Objectives
			%ai.removeAllObjectives();
			%ai.assignObjectives();
		}

		%parent = parent::reset(%this, %client);

		//vehicles must be reset after the parent
		%this.resetVehicles();

		if(isFunction("Slayer_" @ %this.mode @ "_postReset"))
			call("Slayer_" @ %this.mode @ "_postReset", %this, %client);
		%this.setResetting(0); //the minigame is no longer resetting

		Slayer_Support::Debug(1, "Slayer_MinigameSO::Reset");

		//HANDLE STARTING THE NEW ROUND
		%this.onReset();

		return %parent;
	}

	function Slayer_MinigameSO::endGame(%this)
	{
		Slayer_Support::Debug(1, "Minigame", "Ending");

		%this.isEnding = true;

		if(isFunction("Slayer_" @ %this.mode @ "_onModeEnd"))
			call("Slayer_" @ %this.mode @ "_onModeEnd", %this);

		//remove all of our bots
		for(%i = %this.numMembers["AiConnection"] - 1; %i >= 0; %i --)
			%this.member["AiConnection", %i].recycle();

		for(%i = 0; %i < %this.numMembers; %i ++)
		{
			%cl = %this.member[%i];

			%cl.setDead(0);
			%cl.setLives(0);
			%cl.setKills(0);
			%cl.setDeaths(0);
			%cl.wins = 0;

			%cl.spawnPlayer();

			clearBottomPrint(%cl);
			clearCenterPrint(%cl);
			commandToClient(%cl, 'Slayer_ForceGUI', "ALL", 0);
		}

		%this.resetBricks();
		%this.resetVehicles();
		%this.resetCapturePoints();

		%parent = parent::endGame(%this);

		%this.delete();

		return %parent;
	}

	function miniGameCanUse(%objA, %objB)
	{
		Slayer_Support::Debug(3, "minigameCanUse", %objA TAB %objB);

		%miniA = getMinigameFromObject(%objA);
		%miniB = getMinigameFromObject(%objB);

		if(isSlayerMinigame(%miniA))
		{
			return minigameCanSlayerUse(%objA, %objB, %miniA, %miniB);
		}
		else if(isSlayerMinigame(%miniB))
		{
			return minigameCanSlayerUse(%objB, %objA, %miniB, %miniA);
		}

		return parent::miniGameCanUse(%objA, %objB);
	}

	//Determines if two objects are in the same or compatible Slayer minigames.
	//@see	miniGameCanUse
	//@private
	function minigameCanSlayerUse(%objA, %objB, %miniA, %miniB)
	{
		if(isFunction("Slayer_" @ %miniA.mode @ "_canUse"))
		{
			%special = call("Slayer_" @ %miniA.mode @ "_canUse", %miniA, %objA, %objB);
			if(%special != -1 && %special !$= "")
				return %special;
		}

		%blidA = Slayer_Support::getBLIDFromObject(%objA);
		%blidB = Slayer_Support::getBLIDFromObject(%objB);

		//bricks that we planted online need to work in LAN
		if((%blidA != "999999" || %blidB != getNumKeyID()) &&
			%blidA != "888888" && %blidB != "888888"
		)
		{
			if(%miniA.playersUseOwnBricks)
			{
				%trust = getTrustLevel(%objA, %objB);

				if((%trust !$= "" && %trust < $TrustLevel::Build) || %blidA != %blidB)
					return false;
			}

			if(%miniA.useAllPlayersBricks)
			{
				if(isObject(%miniB) && %miniA != %miniB)
					return false;
			}
			else if(%blidB != %miniA.creatorBLID)
			{
				if(%miniA != %objB.minigame)
				{
					if(%blidA != -1 && %blidB != -1)
						return false;
				}
			}
		}

		//team vehicles
		if(!%objB.doNotCheckTeamVehicle &&
			Slayer_Support::isVehicle(%objB) && 
			isObject(%spawn = %objB.spawnBrick) &&
			%spawn.getDatablock().slyrType $= "TeamVehicle" &&
			isObject(%clientA = Slayer_Support::getClientFromObject(%objA)) &&
			isObject(%team = %clientA.getTeam()) &&
			(%color = %spawn.getControl()) != %team.color && 
			(%teams = %miniA.teams.getTeamsFromColor(%color, "COM", 1)) !$= ""
		)
		{
			%clientA.schedule(0, centerPrint, "<color:ff00ff>Only members of"
				SPC %teams SPC "\c5may use this vehicle.", 2);
			return false;
		}

		return true;
	}

	//Determines whether two objects can damage each other.
	function minigameCanDamage(%objA, %objB)
	{
		if(!isObject(%objA) || !isObject(%objB))
			return parent::minigameCanDamage(%objA, %objB);

		//get minigames
		%miniA = getMinigameFromObject(%objA);
		%miniB = getMinigameFromObject(%objB);

		//figure out which minigame to use
		%isA = isObject(%miniA);
		%isB = isObject(%miniB);
		if(%isA && !%isB)
			%mini = %miniA;
		else if(!%isA && %isB)
			%mini = %miniB;
		else if(%miniA == %miniB)
			%mini = %miniA;
		else
			return parent::minigameCanDamage(%objA, %objB);

		//bad minigame
		if(!isSlayerMinigame(%mini))
			return parent::minigameCanDamage(%objA, %objB);

		Slayer_Support::Debug(3, "minigameCanDamage", %objA TAB %objB);

		//get classes
		%classA = %objA.getClassName();
		%classB = %objB.getClassName();

		//prevent player damage outside minigame
		if(%classB $= "Player" || %classB $= "AiPlayer")
		{
			if(%miniA != %miniB)
			{
				Slayer_Support::Debug(3, "minigameCanDamage", "False - Player not in minigame");
				return false;
			}
		}
		else //prevent damaging stuff not in the minigame
		{
			%objB.doNotCheckTeamVehicle = 1;
			%canUse = minigameCanUse(%objA, %objB);
			%objB.doNotCheckTeamVehicle = "";

			if(!%canUse)
			{
				Slayer_Support::Debug(3, "minigameCanDamage", "False - Object not in minigame");
				return false;
			}
		}

		//run a basic gamemode canDamage check
		if(isFunction("Slayer_" @ %mini.mode @ "_canDamage"))
		{
			%special = call("Slayer_" @ %mini.mode @ "_canDamage", %mini, %objA, %objB);
			if(%special != -1 && %special !$= "")
			{
				Slayer_Support::Debug(3, "minigameCanDamage", %special SPC "- Gamemode is in charge");
				return %special;
			}
		}

		//check if we can damage them, according to minigame prefs
		if(!%mini.canDamage(%objA, %classA, %objB, %classB) || !%mini.canDamage(%objB, %classB, %objA, %classA))
		{
			Slayer_Support::Debug(3, "minigameCanDamage", "False - Denied by preferences");
			return false;
		}

		//get clients
		%clientA = Slayer_Support::getClientFromObject(%objA);
		%clientB = Slayer_Support::getClientFromObject(%objB);

		//gamemode clientCanDamage check
		if(isFunction("Slayer_" @ %mini.mode @ "_ClientCanDamage"))
		{
			%special = call("Slayer_" @ %mini.mode @ "_ClientCanDamage", %mini, %clientA, %clientB);
			if(%special != -1 && %special !$= "")
			{
				Slayer_Support::Debug(3, "minigameCanDamage", %special SPC "- Gamemode client check");
				return %special;
			}
		}

		if(%clientA != %clientB && isObject(%clientA) && isObject(%clientB) &&
			!%mini.Teams.canDamage(%clientA.getTeam(), %clientB.getTeam())
		)
		{
			Slayer_Support::Debug(3, "minigameCanDamage", "False - Friendly fire");
			return false;
		}

		return true;
	}

	//why do minigames return -1 when checked with this...?
	function getMinigameFromObject(%obj)
	{
		%parent = parent::getMinigameFromObject(%obj);

		if(!isObject(%parent) && isObject(%obj) && !%obj.doNotCheckSlayerMinigame)
		{
			%className = %obj.getClassName();

			if(striPos("fxDtsBrick SimGroup", %className) >= 0)
			{
				%blid = Slayer_Support::getBLIDFromObject(%obj);
				if(%blid >= 0)
				{
					%mini = Slayer.Minigames.getHighestPriorityMinigame(%blid);
					if(isObject(%mini))
						return %mini;
				}
			}

			//MINIGAME
			if(%obj.class $= "MinigameSO" || %obj.superClass $= "MinigameSO")
				return %obj;
		}

		return %parent;
	}

	function getBrickGroupFromObject(%obj)
	{
		if(%obj.isSlayerFakeClient && isObject(%obj.brickgroup))
			return %obj.brickgroup;

		return parent::getBrickGroupFromObject(%obj);
	}

	function onMissionLoaded()
	{
		%parent = parent::onMissionLoaded();

		// +-------------------------+
		// | Minigame Initialization |
		// +-------------------------+
		if($Slayer::Server::CurGameModeArg $= $Slayer::Server::GameModeArg)
		{
			Slayer.Minigames.schedule(0, addMinigame, 0, $Slayer::Server::ConfigDir @ "/config_last.cs");
		}
		else
		{
			if($Slayer::Server::CurGameModeArg !$= "")
				%configFile = filePath($Slayer::Server::CurGameModeArg) @ "/config_slayer.cs";
			if(isFile(%configFile))
				Slayer.Minigames.schedule(0, addMinigame, 0, %configFile);
			else if($Slayer::Server::Preload::Minigame::AutoStartMinigame)
				Slayer.Minigames.schedule(0, addMinigame, 0, $Slayer::Server::ConfigDir @ "/config_last.cs");
		}
		

		return %parent;
	}
};
activatePackage(Slayer_Dependencies_Minigames);

// +----------------------+
// | Initialize Component |
// +----------------------+
if(!isObject(Slayer.Minigames))
{
	Slayer.Minigames = new scriptGroup(Slayer_MinigameHandlerSO);
	Slayer.add(Slayer.Minigames);
}

$Slayer::Server::Dependencies::Minigames = 1;
Slayer_Support::Debug(2, "Dependency Loaded", "Minigames");