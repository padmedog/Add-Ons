datablock fxDTSBrickData(brick2x2fcornerData)
{
	brickFile = "./2x2Fcorner.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x2F L-Shaped";
   iconName = "Add-Ons/Brick_Corner/2x2F Corner";
};

datablock fxDTSBrickData(brick2x2x3cornerData)
{
	brickFile = "./2x2x3corner.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x2x3 L-Shaped";
   iconName = "Add-Ons/Brick_Corner/2x2x3 Corner";
};

datablock fxDTSBrickData(brick2x2x5cornerData)
{
	brickFile = "./2x2x5corner.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x2x5 L-Shaped";
   iconName = "Add-Ons/Brick_Corner/2x2x5 Corner";
};

datablock fxDTSBrickData (brick2x2FcornerprintData : brick2x2fcornerData)
{
	brickFile = "./2x2Fcornerprint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F L-Shaped Print";
	iconName = "Add-Ons/Brick_Corner/2x2F Corner Print";
	
	hasPrint = 1;
	printAspectRatio = "2x2fl";
	orientationFix = 3;
};

datablock fxDTSBrickData (brick2x2cornerprintData : brick2x2cornerData)
{
	brickFile = "./2x2cornerprint.blb";
	category = "Bricks";
	subCategory = "Prints";
	uiName = "2x2 L-Shaped Print";
	iconName = "Add-Ons/Brick_Corner/2x2 Corner Print";
	
	hasPrint = 1;
	printAspectRatio = "2x2l";
	orientationFix = 3;
};