%errorA = ForceRequiredAddOn("Vehicle_Jeep");
%errorB = ForceRequiredAddOn("Weapon_Rocket_Launcher");
%errorD = ForceRequiredAddOn("Weapon_Gun");

if(%errorA == $Error::AddOn_Disabled)
   JeepVehicle.uiName = "";
if(%errorB == $Error::AddOn_Disabled)
   rocketLauncherItem.uiName = "";
if(%errorD == $Error::AddOn_Disabled)
	GunItem.uiName = "";

if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_A10 - required add-on Vehicle_Jeep not found");
else if(%errorB == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_A10 - required add-on Weapon_Rocket_Launcher not found");
else if(%errorD == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_A10 - required add-on Weapon_Gun not found");
else
{
exec("./Sounds_A10.cs"); 
exec("./Particles_A10.cs"); 
exec("./Debris_A10.cs"); 
exec("./Vehicle_A10Missile.cs"); 
exec("./Vehicle_A10.cs"); 
exec("./Player_A10.cs");
exec("./Support_A10.cs"); 
}



