//> ===>
//> Title: SetScore
//> Author: Truce
//> ===>

registerOutputEvent(GameConnection,SetScore,"int -2147483647 2147483647 0");