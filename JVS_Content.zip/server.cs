$JVS::Content::Version = 8;

//Audio Datablocks

if(!isObject(contentBuzzer))
{
	datablock AudioProfile(contentError)
	{
		filename = "Add-Ons/JVS_Content/sounds/contentSoundError.wav";
		description = AudioClose3d;
		preload = true;
	};
}

//Particle Datablocks

if(!isObject(contentParticleDebris))
{
	datablock ParticleData(contentParticleDebris)
	{
		dragCoefficient = 3.0;
		windCoefficient = 0.0;
		gravityCoefficient = -0.5;
		inheritedVelFactor = 0.0;
		constantAcceleration = 0.0;
		lifetimeMS = 500;
		lifetimeVarianceMS = 150;
		spinSpeed = 10.0;
		spinRandomMin = -50.0;
		spinRandomMax = 50.0;
		useInvAlpha = true;
		animateTexture = false;
		textureName = "base/data/particles/cloud";
		colors[0] = "0.0 0.0 0.0 0.0";
		colors[1] = "0.0 0.0 0.0 0.250";
		colors[2] = "0.0 0.0 0.0 0.0";
		sizes[0] = 1.50;
		sizes[1] = 2.50;
		sizes[2] = 3.50;
		times[0] = 0.0;
		times[1] = 0.1;
		times[2] = 1.0;
	};
}

//Emitter Datablocks

if(!isObject(contentEmitterDebris))
{
	datablock ParticleEmitterData(contentEmitterDebris)
	{
		ejectionPeriodMS = 90;
		periodVarianceMS = 0;
		ejectionVelocity = 0.0;
		velocityVariance = 0.0;
		ejectionOffset = 1.0;
		thetaMin = 0;
		thetaMax = 0;
		phiReferenceVel = 0;
		phiVariance = 360;
		overrideAdvance = false;
		particles = "contentParticleDebris";
	};
}

//Script Objects

if(!isObject(ContentBricksSO))
{
	new ScriptObject(ContentBricksSO)
	{
		bricks = 0;
	};
}

if(!isObject(ContentRestrictionsSO))
{
	new ScriptObject(ContentRestrictionsSO)
	{
		restrictions = 0;
	};
}

if(!isObject(ContentTypesSO))
{
	new ScriptObject(ContentTypesSO)
	{
		types = 0;
	};
}

//Package

package JVS_Content
{
	//Functions

	function changeMap(%path)
	{
		if(isObject(ContentBricksSO))
		{
			for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
			{
				ContentBricksSO.brick[%i] = "";
			}

			ContentBricksSO.bricks = 0;
		}
		else
		{
			error("JVS_Content - ContentBricksSO does not exist!");
		}

		Parent::changeMap(%path);
	}

	function contentBLIDCheck(%client, %text)
	{
		if(%client.BL_ID >= 0 && %text !$= "")
		{
			%allowed = 0;
			%denied = 0;

			for(%i = 0;%i < getWordCount(%text);%i++)
			{
				%word = getWord(%text, %i);
				%fail = 0;

				if(strlen(%word) >= 2)
				{
					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word, %j, 1);

						if((%j == 0 && strstr("-+", %char) == -1) || (%j > 0 && strstr("1234567890", %char) == -1))
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%sign = getSubStr(%word, 0, 1);
						%blid = getSubStr(%word, 1,strlen(%word) - 1);

						if(%blid >= 0)
						{
							if(%sign $= "-")
							{
								%deny[%denied++] = %blid;
							}
							else
							{
								%allow[%allowed++] = %blid;
							}
						}
					}
				}
			}

			%allow = 0;

			for(%i = 1;%i <= %allowed;%i++)
			{
				%blid = %allow[%i];

				if(%blid == %client.BL_ID)
				{
					%allow = 1;
					break;
				}
			}

			%deny = 0;

			for(%i = 1;%i <= %denied;%i++)
			{
				%blid = %deny[%i];

				if(%blid == %client.BL_ID)
				{
					%deny = 1;
					break;
				}
			}

			if(%allow == 1 && %deny == 0)
			{
				return 1;
			}
			else if(%allow == 0 && %deny == 1)
			{
				return 0;
			}
			else
			{
				return -1;
			}
		}
		else
		{
			return -1;
		}
	}

	function contentEulerToAxis(%euler)
	{
		%euler = VectorScale(%euler,$pi / 180);
		%matrix = MatrixCreateFromEuler(%euler);
		return getWords(%matrix, 3, 6);
	}

	function disconnect(%a)
	{
		if(isObject(ContentBricksSO))
		{
			ContentBricksSO.delete();
		}

		if(isObject(ContentRestrictionsSO))
		{
			ContentRestrictionsSO.delete();
		}

		if(isObject(ContentTypesSO))
		{
			ContentTypesSO.delete();
		}

		deleteVariables("$JVS::*");

      Parent::disconnect(%a);
	}

	function getMaxContentBricksPerPlayer()
	{
		if($JVS::Content::Prefs::MaxContentBricksPerPlayer $= "" || $JVS::Content::Prefs::MaxContentBricksPerPlayer < 0 || $JVS::Content::Prefs::MaxContentBricksPerPlayer > 9999)
		{
			$JVS::Content::Prefs::MaxContentBricksPerPlayer = 50;
		}

		return $JVS::Content::Prefs::MaxContentBricksPerPlayer;
	}

	function refreshRestrictions(%oldValue, %newValue)
	{
		ContentRestrictionsSO.refreshRestrictions("Change in RTB Prefs");
	}

	//ContentBricksSO Methods

	function ContentBricksSO::add(%this, %obj)
	{
		if(isObject(%obj))
		{
			%exists = 0;

			for(%i = 1;%i <= %this.bricks;%i++)
			{
				if(%this.brick[%i] == %obj)
				{
					%exists = 1;
				}
			}

			if(%exists != 1)
			{
				%this.brick[%this.bricks++] = %obj;
			}
		}
	}

	function ContentBricksSO::getContentBrickFromID(%this, %ID)
	{
		if(%this.brick[%ID] !$= "")
		{
			return %this.brick[%ID];
		}
		else
		{
			return -1;
		}
	}

	function ContentBricksSO::listObjects(%this)
	{
		for(%i = 1;%i <= %this.bricks;%i++)
		{
			echo("   " @ %this.brick[%i] @ ": " @ %this.brick[%i].getClassName());
		}
	}

	function ContentBricksSO::remove(%this, %obj)
	{
		%bricks = 0;

		for(%i = 1;%i <= %this.bricks;%i++)
		{
			if(%this.brick[%i] != %obj)
			{
				%bricks++;
				%brick[%bricks] = %this.brick[%i];
			}

			%this.brick[%i] = "";
		}

		if(%bricks > 0)
		{
			for(%j = 1;%j <= %bricks;%j++)
			{
				%this.brick[%j] = %brick[%j];
			}

			%this.bricks = %bricks;
		}
		else
		{
			%this.bricks = 0;
		}
	}

	//ContentRestrictionsSO Methods

	function ContentRestrictionsSO::addRestriction(%this, %name, %method, %id)
	{
		%error = 0;

		for(%i = 0;%i < strlen(%name);%i++)
		{
			%char = strupr(getSubStr(%name, %i, 1));

			if(strpos("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", %char) == -1)
			{
				%error = 1;
				break;
			}
		}

		if(%error == 0)
		{
			for(%i = 0;%i < strlen(%method);%i++)
			{
				%char = strupr(getSubStr(%method, %i, 1));

				if(%i == 0)
				{
					if(strpos("ABCDEFGHIJKLMNOPQRSTUVWXYZ", %char) == -1)
					{
						%error = 1;
						break;
					}
				}
				else if(strpos("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", %char) == -1)
				{
					%error = 1;
					break;
				}
			}

			if(%error == 0)
			{
				if(%id !$= mFloatLength(%id, 0))
				{
					%error = 1;
				}

				if(%error == 0)
				{
					if(%this.reservedName[%name] != 1)
					{
						if(%this.reservedMethod[%method] != 1)
						{
							if(%this.reservedId[%id] != 1)
							{
								%this.reservedMethod[%method] = 1;
								%this.reservedName[%name] = 1;
								%this.reservedId[%id] = 1;
								%this.restrictionMethod[%this.restrictions] = %method;
								%this.restrictionName[%this.restrictions] = %name;
								%this.restrictionId[%this.restrictions] = %id;
								%this.restrictions++;

								if(!$JVS::Content::RTBPrefs::Restriction[%id])
								{
									if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
									{
										if(!$RTB::RTBR_ServerControl_Hook)
										{
											exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
										}

										RTB_registerPref("Restriction - " @ %name, "JVS Content", "$JVS::Content::Prefs::Restriction" @ %id, "bool", "JVS_Content", 1, 0, 0, "refreshRestrictions");
										$JVS::Content::RTBPrefs::Restriction[%id] = 1;
									}
									else
									{
										$JVS::Content::Prefs::Restriction[%id] = 1;
									}
								}

								%this.refreshRestrictions("Adding restriction \"" @ %name @ "\"");
							}
							else
							{
								error("JVS_Content - ContentRestrictionsSO::addRestriction - " @ %id @ " - ID number already in use.");
							}
						}
						else
						{
							error("JVS_Content - ContentRestrictionsSO::addRestriction - " @ %method @ " - Method name already in use.");
						}
					}
					else
					{
						error("JVS_Content - ContentRestrictionsSO::addRestriction - " @ %name @ " - Restriction name already in use.");
					}
				}
				else
				{
					error("JVS_Content - ContentRestrictionsSO::addRestriction - " @ %method @ " - Invalid ID number specified.");
				}
			}
			else
			{
				error("JVS_Content - ContentRestrictionsSO::addRestriction - " @ %method @ " - Invalid method name specified.");
			}
		}
		else
		{
			error("JVS_Content - ContentRestrictionsSO::addRestriction - " @ %name @ " - Invalid restriction name specified.");
		}
	}

	function ContentRestrictionsSO::refreshRestrictions(%this, %newRestrictionName)
	{
		if($JVS::Content::Restrictions == 1)
		{
			if(%newRestrictionName !$= "")
			{
				%warning = "Refreshing JVS Content Restrictions (" @ %newRestrictionName @ ")";
			}
			else
			{
				%warning = "Refreshing JVS Content Restrictions";
			}

			warn(%warning);
		}

		%list = new GuiTextListCtrl();

		for(%i = 0;%i < %this.restrictions;%i++)
		{
			%list.addRow(%i, %this.restrictionMethod[%i] TAB %this.restrictionName[%i] TAB %this.restrictionId[%i]);
		}

		%list.sort(0);

		for(%i = 0;%i < %this.restrictions;%i++)
		{
			%row = %list.getRowText(%i);
			%this.restrictionMethod[%i] = getField(%row, 0);
			%this.restrictionName[%i] = getField(%row, 1);
			%this.restrictionId[%i] = getField(%row, 2);
		}

		%list.delete();
		%string = "list Unrestricted 0";

		for(%i = 0;%i < %this.restrictions;%i++)
		{
			if($JVS::Content::Prefs::Restriction[%this.restrictionId[%i]])
			{
				%string = %string SPC %this.restrictionName[%i] SPC %this.restrictionId[%i];
			}
		}

		registerOutputEvent("fxDTSBrick", "contentStop", %string TAB "string 200 72", 1);
		registerOutputEvent("fxDTSBrick", "contentStart", %string TAB "list CW 0 CCW 1" TAB "string 200 72", 1);
	}

	//ContentTypesSO Methods

	function ContentTypesSO::addContentType(%this, %file)
	{
		deleteVariables("$JVS::Content::Type::*");
		%filePath = filePath(%file);
		%typesCheck = getSubStr(%filePath,strLen(%filePath) - 6, 6);

		if(isFile(%file) && %typesCheck $= "/types")
		{
			%basePath = getSubStr(%filePath, 0,strLen(%filePath) - 5);
			%name = fileBase(%file);
			exec(%file);
			%parse = 1;

			if($JVS::Content::Type::animationNameStopCW $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": animationNameStopCW is missing.");
			}

			if($JVS::Content::Type::animationNameStopCCW $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": animationNameStopCCW is missing.");
			}

			if($JVS::Content::Type::animationNameStartCW $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": animationNameStartCW is missing.");
			}

			if($JVS::Content::Type::animationNameStartCCW $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": animationNameStartCCW is missing.");
			}

			if($JVS::Content::Type::animationLengthStop $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": animationLengthStop is missing.");
			}

			if($JVS::Content::Type::animationLengthStart $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": animationLengthStart is missing.");
			}

			if($JVS::Content::Type::datablockBrick $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockBrick is missing.");
			}

			if($JVS::Content::Type::datablockDebris $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockDebris is missing.");
			}

			if($JVS::Content::Type::datablockProjectile $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockProjectile is missing.");
			}

			if($JVS::Content::Type::datablockExplosion $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockExplosion is missing.");
			}

			if($JVS::Content::Type::datablockShape $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockShape is missing.");
			}

			if($JVS::Content::Type::datablockShapeColliding $= "" && %parse == 1)
			{
				$JVS::Content::Type::datablockShapeColliding = $JVS::Content::Type::datablockShape;
			}

			if($JVS::Content::Type::datablockSoundStop $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockSoundStop is missing.");
			}

			if($JVS::Content::Type::datablockSoundStart $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": datablockSoundStart is missing.");
			}

			if($JVS::Content::Type::nodeCount $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": nodeCount is missing.");
			}

			for(%i = 0;%i < $JVS::Content::Type::nodeCount;%i++)
			{
				if($JVS::Content::Type::nodeColor[%i] $= "" && %parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": nodeColor" @ %i @ " is missing.");
				}

				if($JVS::Content::Type::nodeName[%i] $= "" && %parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": nodeName" @ %i @ " is missing.");
				}
			}

			if($JVS::Content::Type::uiName $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": uiName is missing.");
			}

			if($JVS::Content::Type::brickSearches $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSearches is missing.");
			}

			for(%i = 0;%i < $JVS::Content::Type::brickSearches;%i++)
			{
				if($JVS::Content::Type::brickSearchBox[%i] $= "" && %parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSearchBox" @ %i @ " is missing.");
				}

				if($JVS::Content::Type::brickSearchPositionCCW[%i] $= "" && %parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSearchPositionCCW" @ %i @ " is missing.");
				}

				if($JVS::Content::Type::brickSearchPositionCW[%i] $= "" && %parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSearchPositionCW" @ %i @ " is missing.");
				}
			}

			if($JVS::Content::Type::brickSize $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSize is missing.");
			}
			else if(%parse == 1)
			{
				$JVS::Content::Type::brickSizeX = mFloatLength(getField($JVS::Content::Type::brickSize, 0), 0);
				$JVS::Content::Type::brickSizeY = mFloatLength(getField($JVS::Content::Type::brickSize, 1), 0);
				$JVS::Content::Type::brickSizeZ = mFloatLength(getField($JVS::Content::Type::brickSize, 2), 0);

				if($JVS::Content::Type::brickSizeX > 0 && %parse == 1)
				{
				}
				else if(%parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSizeX is missing.");
				}

				if($JVS::Content::Type::brickSizeY > 0 && %parse == 1)
				{
				}
				else if(%parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSizeY is missing.");
				}

				if($JVS::Content::Type::brickSizeZ > 0 && %parse == 1)
				{
				}
				else if(%parse == 1)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSizeZ is missing.");
				}
			}

			if($JVS::Content::Type::soundDelayStop $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": soundDelayStop is missing.");
			}

			if($JVS::Content::Type::soundDelayStart $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": soundDelayStart is missing.");
			}

			if($JVS::Content::Type::brickSubcategory $= "" && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": brickSubcategory is missing.");
			}

			if(!isFile($JVS::Content::Type::brickFile) && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ $JVS::Content::Type::brickFile @ " is missing.");
			}
			else
			{
				%brickFile = $JVS::Content::Type::brickFile;
			}

			if(isFile($JVS::Content::Type::brickCollisionFile) && %parse == 1)
			{
				%brickCollisionFile = $JVS::Content::Type::brickCollisionFile;
			}

			if(!isFile(%basePath @ "sounds/" @ $JVS::Content::Type::datablockSoundStop @ ".wav") && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ %basePath @ "sounds/" @ $JVS::Content::Type::datablockSoundStop @ ".wav" @ " is missing.");
			}
			else
			{
				%stopSoundFile = %basePath @ "sounds/" @ $JVS::Content::Type::datablockSoundStop @ ".wav";
			}

			if(!isFile(%basePath @ "sounds/" @ $JVS::Content::Type::datablockSoundStart @ ".wav") && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ %basePath @ "sounds/" @ $JVS::Content::Type::datablockSoundStart @ ".wav" @ " is missing.");
			}
			else
			{
				%startSoundFile = %basePath @ "sounds/" @ $JVS::Content::Type::datablockSoundStart @ ".wav";
			}

			if(!isFile(%basePath @ "shapes/" @ $JVS::Content::Type::datablockShape @ ".dts") && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ %basePath @ "shapes/" @ $JVS::Content::Type::datablockShape @ ".dts" @ " is missing.");
			}
			else
			{
				%shapeFile = %basePath @ "shapes/" @ $JVS::Content::Type::datablockShape @ ".dts";
			}

			if(!isFile(%basePath @ "shapes/" @ $JVS::Content::Type::datablockShapeColliding @ ".dts") && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ %basePath @ "shapes/" @ $JVS::Content::Type::datablockShapeColliding @ ".dts" @ " is missing.");
			}
			else
			{
				%shapeFileColliding = %basePath @ "shapes/" @ $JVS::Content::Type::datablockShapeColliding @ ".dts";
			}

			if(!isFile(%basePath @ "shapes/" @ $JVS::Content::Type::datablockDebris @ ".dts") && %parse == 1)
			{
				%parse = 0;
				error("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ %basePath @ "shapes/" @ $JVS::Content::Type::datablockDebris @ ".dts" @ " is missing.");
			}
			else
			{
				%debrisFile = %basePath @ "shapes/" @ $JVS::Content::Type::datablockDebris @ ".dts";
			}

			if(!isFile(%basePath @ "icons/" @ $JVS::Content::Type::datablockShape @ ".png") && %parse == 1)
			{
				warn("JVS_Content - ContentTypesSO::addContentType - " @ %name @ ": " @ %basePath @ "icons/" @ $JVS::Content::Type::datablockShape @ ".png" @ " is missing.");
			}
			else
			{
				%uiFile = %basePath @ "icons/" @ $JVS::Content::Type::datablockShape;
			}

			for(%i = 0;%i < %this.types;%i++)
			{
				%type = %this.types[%i];

				if(stricmp(%type.uiName, $JVS::Content::Type::uiName) == 0)
				{
					%parse = 0;
					error("JVS_Content - ContentTypesSO::addContentType - '" @ $JVS::Content::Type::uiName @ "' already exists.");
				}
			}

			if(%parse == 1)
			{
				%type = new ScriptObject(ContentTypeSO){};

				%type.id = %this.types;
				%type.animationNameStopCW = $JVS::Content::Type::animationNameStopCW;
				%type.animationNameStopCCW = $JVS::Content::Type::animationNameStopCCW;
				%type.animationLengthStop = $JVS::Content::Type::animationLengthStop;
				%type.animationNameStartCW = $JVS::Content::Type::animationNameStartCW;
				%type.animationNameStartCCW = $JVS::Content::Type::animationNameStartCCW;
				%type.animationLengthStart = $JVS::Content::Type::animationLengthStart;
				%type.brickSearches = $JVS::Content::Type::brickSearches;

				for(%i = 0;%i < %type.brickSearches;%i++)
				{
					%type.brickSearchBox[%i] = $JVS::Content::Type::brickSearchBox[%i];
					%type.brickSearchPositionCCW[%i] = $JVS::Content::Type::brickSearchPositionCCW[%i];
					%type.brickSearchPositionCW[%i] = $JVS::Content::Type::brickSearchPositionCW[%i];
				}

				%type.brickSearchBoxString = "";

				for(%i = 0;%i < %type.brickSearches;%i++)
				{
					if(%type.brickSearchBox[%i] !$= "")
					{
						if(%type.brickSearchBoxString $= "")
						{
							%type.brickSearchBoxString = %type.brickSearchBox[%i];
						}
						else
						{
							%type.brickSearchBoxString = %type.brickSearchBoxString TAB %type.brickSearchBox[%i];
						}
					}
					else
					{
						%type.brickSearchBoxString = -1;
						break;
					}
				}

				for(%i = 0;%i < getFieldCount("CCW" TAB "CW");%i++)
				{
					%direction = getField("CCW" TAB "CW", %i);

					%type.brickSearchPositionString[%direction] = "";

					for(%j = 0;%j < %type.brickSearches;%j++)
					{
						if(%type.brickSearchPosition[%direction @ %j] !$= "")
						{
							if(%type.brickSearchPositionString[%direction] $= "")
							{
								%type.brickSearchPositionString[%direction] = %type.brickSearchPosition[%direction @ %j];
							}
							else
							{
								%type.brickSearchPositionString[%direction] = %type.brickSearchPositionString[%direction] TAB %type.brickSearchPosition[%direction @ %j];
							}
						}
						else
						{
							%type.brickSearchPositionString[%direction] = -1;
							break;
						}
					}
				}

				%type.datablockBrick = $JVS::Content::Type::datablockBrick;
				%type.nodeCount = $JVS::Content::Type::nodeCount;

				for(%i = 0;%i < %type.nodeCount;%i++)
				{
					%type.nodeColor[%i] = $JVS::Content::Type::nodeColor[%i];
					%type.nodeName[%i] = $JVS::Content::Type::nodeName[%i];
				}

				%type.datablockDebris = $JVS::Content::Type::datablockDebris;
				%type.uiName = $JVS::Content::Type::uiName;
				%type.datablockExplosion = $JVS::Content::Type::datablockExplosion;
				%type.datablockProjectile = $JVS::Content::Type::datablockProjectile;
				%type.datablockShape = $JVS::Content::Type::datablockShape;
				%type.datablockShapeColliding = $JVS::Content::Type::datablockShapeColliding;
				%type.brickSize = $JVS::Content::Type::brickSizeX TAB $JVS::Content::Type::brickSizeY TAB $JVS::Content::Type::brickSizeZ;
				%type.soundDelayStop = $JVS::Content::Type::soundDelayStop;
				%type.datablockSoundStop = $JVS::Content::Type::datablockSoundStop;
				%type.soundDelayStart = $JVS::Content::Type::soundDelayStart;
				%type.datablockSoundStart = $JVS::Content::Type::datablockSoundStart;
				%type.brickSubcategory = $JVS::Content::Type::brickSubcategory;

				if(!isObject(%type.datablockBrick))
				{
					datablock fxDTSBrickData(contentBrick)
					{
						brickFile = %brickFile;
						category = "JVS";
						subCategory = %type.brickSubcategory;
						uiName = %type.uiName;
						iconName = %uiFile;
						collisionShapeName = %brickCollisionFile;
					};

					contentBrick.setName(%type.datablockBrick);
				}

				%type.datablockBrick.contentType = %type;

				if(!isObject(%type.datablockSoundStop))
				{
					datablock AudioProfile(contentStopSound)
					{
						filename = %stopSoundFile;
						description = AudioClose3d;
						preload = true;
					};

					contentStopSound.setName(%type.datablockSoundStop);
				}

				if(!isObject(%type.datablockSoundStart))
				{
					datablock AudioProfile(contentStartSound)
					{
						filename = %startSoundFile;
						description = AudioClose3d;
						preload = true;
					};

					contentStartSound.setName(%type.datablockSoundStart);
				}

				if(!isObject(%type.datablockShape))
				{
					datablock StaticShapeData(contentShape)
					{
						shapefile = %shapeFile;
					};

					contentShape.setName(%type.datablockShape);
				}

				if(!isObject(%type.datablockShapeColliding))
				{
					datablock StaticShapeData(contentShapeColliding)
					{
						shapefile = %shapeFileColliding;
					};

					contentShapeColliding.setName(%type.datablockShapeColliding);
				}

				if(!isObject(%type.datablockDebris))
				{
					datablock DebrisData(contentDebris)
					{
						baseRadius = "1";
						bounceVariance = "0";
						className = "DebrisData";
						elasticity = "0.5";
						explodeOnMaxBounce = "0";
						fade = "1";
						friction = "0.2";
						gravModifier = "2";
						ignoreWater = "1";
						lifetime = "2";
						lifetimeVariance = "0";
						maxSpinSpeed = "200";
						minSpinSpeed = "-400";
						numBounces = "3";
						render2D = "0";
						shapeFile = %debrisFile;
						snapOnMaxBounce = "0";
						staticOnMaxBounce = "1";
						terminalVelocity = "0";
						useRadiusMass = "0";
						velocity = "0";
						velocityVariance = "0";
						emitters[0] = "contentEmitterDebris";
					};

					contentDebris.setName(%type.datablockDebris);
				}

				if(!isObject(%type.datablockExplosion))
				{
					datablock ExplosionData(contentExplosion)
					{
						className = "ExplosionData";
						Debris = %type.datablockDebris;
						debrisNum = "1";
						debrisNumVariance = "0";
						debrisPhiMax = "360";
						debrisPhiMin = "0";
						debrisThetaMax = "85";
						debrisThetaMin = "40";
						debrisVelocity = "14";
						debrisVelocityVariance = "3";
						delayMS = "0";
						delayVariance = "0";
						explosionScale = "1 1 1";
						faceViewer = "1";
						lifetimeMS = "150";
						lifetimeVariance = "0";
						offset = "0";
						particleDensity = "10";
						particleRadius = "1";
						playSpeed = "1";
						shakeCamera = "0";
						damageRadius = "0";
						impulseForce = "0";
						impulseRadius = "0";
						radiusDamage = "0";
					};

					contentExplosion.setName(%type.datablockExplosion);
				}

				if(!isObject(%type.datablockProjectile))
				{
					datablock ProjectileData(contentProjectile)
					{
						directDamage = 0;
						radiusDamage = 0;
						damageRadius = 0;
						explosion = %type.datablockExplosion;
						directDamageType = $DamageType::jeepExplosion;
						radiusDamageType = $DamageType::jeepExplosion;
						explodeOnDeath = 1;
						armingDelay = 0;
						lifetime = 10;
					};

					contentProjectile.setName(%type.datablockProjectile);
				}

				$JVS::Content::Type::eventCount = mFloatLength($JVS::Content::Type::eventCount, 0);

				if($JVS::Content::Type::eventCount >= 0)
				{
				}
				else
				{
					$JVS::Content::Type::eventCount = 0;
				}

				%type.eventCount = $JVS::Content::Type::eventCount;

				for(%i = 0;%i < $JVS::Content::Type::eventCount;%i++)
				{
					%type.eventEnabled[%i] = $JVS::Content::Type::eventEnabled[%i];
					%type.eventDelay[%i] = $JVS::Content::Type::eventDelay[%i];
					%type.eventInput[%i] = $JVS::Content::Type::eventInput[%i];
					%type.eventTarget[%i] = $JVS::Content::Type::eventTarget[%i];
					%type.eventOutput[%i] = $JVS::Content::Type::eventOutput[%i];
					%type.eventParameterCount[%i] = $JVS::Content::Type::eventParameterCount[%i];
					%type.eventParameterString[%i] = "";

					for(%j = 0;%j < $JVS::Content::Type::eventParameterCount[%i];%j++)
					{
						%type.eventParameter[%i @ "_" @ %j] = $JVS::Content::Type::eventParameter[%i @ "_" @ %j];
						%type.eventParameterString[%i] = %type.eventParameterString[%i] @ "," @ %type.eventParameter[%i @ "_" @ %j];
					}
				}

				%this.type[%this.types] = %type;
				%this.types++;
			}

			deleteVariables("$JVS::Content::Type::*");
		}
		else
		{
			error("JVS_Content - ContentTypesSO::addContentType - " @ %file @ " is missing.");
		}
	}

	function ContentTypesSO::getDatablockSoundStartFromID(%this, %id)
	{
		if(isObject(%this.type[%id]) && %this.type[%id].datablockSoundStart !$= "")
		{
			return %this.type[%id].datablockSoundStart;
		}
		else
		{
			return -1;
		}
	}

	function ContentTypesSO::getDatablockSoundStopFromID(%this, %id)
	{
		if(isObject(%this.type[%id]) && %this.type[%id].datablockSoundStop !$= "")
		{
			return %this.type[%id].datablockSoundStop;
		}
		else
		{
			return -1;
		}
	}

	function ContentTypesSO::getSoundDelayStartFromID(%this, %id)
	{
		if(isObject(%this.type[%id]) && %this.type[%id].soundDelayStart !$= "")
		{
			return %this.type[%id].soundDelayStart;
		}
		else
		{
			return -1;
		}
	}

	function ContentTypesSO::getSoundDelayStopFromID(%this, %id)
	{
		if(isObject(%this.type[%id]) && %this.type[%id].soundDelayStop !$= "")
		{
			return %this.type[%id].soundDelayStop;
		}
		else
		{
			return -1;
		}
	}

	//fxDTSBrick Methods

	function fxDTSBrick::contentBrickCheck(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(%obj.shape.stopAnimationName $= %obj.dataBlock.contentType.animationNameStopCCW)
			{
				%obj.contentUse(%client, 1, "STOP", "CCW");
			}
			else if(%obj.shape.stopAnimationName $= %obj.dataBlock.contentType.animationNameStopCW)
			{
				%obj.contentUse(%client, 1, "STOP", "CW");
			}
		}
	}

	function fxDTSBrick::contentCheck(%obj)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(!isObject(%obj.shape) || %obj.shape.scale !$= "1 1 1" || %obj.shape.getTransform() !$= %obj.shape.transform)
			{
				%bricks = 0;

				for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
				{
					%brick = ContentBricksSO.getContentBrickFromID(%i);

					if(isObject(%brick) && %brick.getGroup() == %obj.getGroup() && !%brick.isDead() && %brick != %obj)
					{
						%bricks++;
					}
				}

				%max = getMaxContentBricksPerPlayer();

				if(%bricks < %max)
				{
					%obj.noContentEvents = 1;
					%obj.contentCreate(1);
				}
			}
		}
	}

	function fxDTSBrick::contentCreate(%obj, %allowLimitOverride)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(isObject(%obj.shape))
			{
				%obj.shape.delete();
			}

			%bricks = 0;

			for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
			{
				%brick = ContentBricksSO.getContentBrickFromID(%i);

				if(isObject(%brick) && %brick.getGroup() == %obj.getGroup() && !%brick.isDead() && %brick != %obj)
				{
					%bricks++;
				}
			}

			%max = getMaxContentBricksPerPlayer();

			if(%bricks < %max || %allowLimitOverride == 1)
			{
				%angleID = %obj.getAngleID();
				%datablock = %obj.dataBlock.contentType.datablockShapeColliding;

				%shape = new StaticShape()
				{
					datablock = %datablock;
					spawnBrick = %obj;
				};

				if(isObject(%shape))
				{
					MissionCleanup.add(%shape);
					%obj.shape = %shape;
					%shape.state = 0;

					%color = getColorIDTable(%obj.getColorId());
					%r = getWord(%color, 0);
					%g = getWord(%color, 1);
					%b = getWord(%color, 2);
					%color = %r SPC %g SPC %b SPC 1;
					%black25 = %r * 0.75 SPC %g * 0.75 SPC %b * 0.75 SPC 1;
					%black50 = %r * 0.5 SPC %g * 0.5 SPC %b * 0.5 SPC 1;
					%black75 = %r * 0.25 SPC %g * 0.25 SPC %b * 0.25 SPC 1;

					for(%i = 0;%i < %obj.dataBlock.contentType.nodeCount;%i++)
					{
						%nodecolor = %obj.dataBlock.contentType.nodeColor[%i];
						%nodename = %obj.dataBlock.contentType.nodeName[%i];

						if(%nodecolor $= "black25")
						{
							%shape.setNodeColor(%nodename, %black25);
						}
						else if(%nodecolor $= "black50")
						{
							%shape.setNodeColor(%nodename, %black50);
						}
						else if(%nodecolor $= "black75")
						{
							%shape.setNodeColor(%nodename, %black75);
						}
						else if(%nodecolor $= "color")
						{
							%shape.setNodeColor(%nodename, %color);
						}
						else
						{
							%shape.setNodeColor(%nodename, %nodecolor);
						}
					}

					%pos = %obj.position;

					if(%angleID == 2)
					{
						%shape.setTransform(%pos SPC contentEulerToAxis("0 0 270"));
					}
					else if(%angleID == 0)
					{
						%shape.setTransform(%pos SPC contentEulerToAxis("0 0 90"));
					}
					else if(%angleID == 1)
					{
						%shape.setTransform(%pos SPC contentEulerToAxis("0 0 0"));
					}
					else if(%angleID == 3)
					{
						%shape.setTransform(%pos SPC contentEulerToAxis("0 0 180"));
					}

					%shape.transform = %shape.getTransform();

					if(%obj.noContentEvents != 1)
					{
						%obj.clearEvents();
						%oldWrenchBrick = %obj.getGroup().client.wrenchBrick;

						for(%i = 0;%i < %obj.dataBlock.contentType.eventCount;%i++)
						{
							eval("%enabled = " @ %obj.dataBlock.contentType.eventEnabled[%i] @ ";");
							eval("%delay = " @ %obj.dataBlock.contentType.eventDelay[%i] @ ";");
							eval("%inputEventName = " @ %obj.dataBlock.contentType.eventInput[%i] @ ";");
							eval("%targetName = " @ %obj.dataBlock.contentType.eventTarget[%i] @ ";");
							eval("%outputEventName = " @ %obj.dataBlock.contentType.eventOutput[%i] @ ";");
							%inputEventIdx = inputEvent_GetInputEventIdx(%inputEventName);
							%targetIdx = inputEvent_GetTargetIndex("fxDTSBrick", %inputEventIdx, %targetName);
							%targetClass = inputEvent_GetTargetClass("fxDTSBrick", %inputEventIdx, %targetIdx);
							%outputEventIdx = outputEvent_GetOutputEventIdx(%targetClass, %outputEventName);
							%NamedTargetNameIdx = -1;
							%obj.getGroup().client.wrenchBrick = %obj;
							eval("serverCmdAddEvent(%obj.getGroup().client, %enabled, %inputEventIdx, %delay, %targetIdx, %NamedTargetNameIdx, %outputEventIdx" @ %obj.dataBlock.contentType.eventParameterString[%i] @ ");");
							%obj.getGroup().client.wrenchBrick = %oldWrenchBrick;
						}
					}
				}
			}
			else if(isObject(%obj.getGroup().client) && %obj.noContentEvents != 1)
			{
				if(%max > 1)
				{
					commandToClient(%obj.getGroup().client, 'centerprint', "\c0You are not permitted to make more than " @ %max @ " content bricks.", 2, 2, 2000);
				}
				else if(%max == 1)
				{
					commandToClient(%obj.getGroup().client, 'centerprint', "\c0You are not permitted to make more than " @ %max @ " content brick.", 2, 2, 2000);
				}
				else
				{
					commandToClient(%obj.getGroup().client, 'centerprint', "\c0You are not permitted to make content bricks.", 2, 2, 2000);
				}
			}

			%obj.noContentEvents = "";
			ContentBricksSO.add(%obj);
			%obj.schedule(33, "onContentCreated", %obj.getGroup().client);
		}
	}

	function fxDTSBrick::contentDestroy(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(isObject(%obj.shape))
			{
				%obj.shape.delete();
			}

			%p = new Projectile()
			{
				dataBlock = %obj.dataBlock.contentType.datablockProjectile;
				initialPosition = %obj.getPosition();
				initialVelocity = "0 0 1";
				client = %client;
				sourceClient = %client;
			};
		}
	}

	function fxDTSBrick::contentGhostBrickCheck(%obj)
	{
		if(isObject(%obj) && !%obj.isPlanted)
		{
			%contentTypeID = %obj.contentTypeID();

			if(%contentTypeID > -1)
			{
				if(isObject(%obj.ghostShape) && %obj.dataBlock $= %obj.dataBlock.contentType.datablockShape)
				{
					%pos = %obj.position;
					%angleID = %obj.getAngleID();

					if(%angleID == 2)
					{
						%rot = contentEulerToAxis("0 0 270");
					}
					else if(%angleID == 3)
					{
						%rot = contentEulerToAxis("0 0 180");
					}
					else if(%angleID == 0)
					{
						%rot = contentEulerToAxis("0 0 90");
					}
					else
					{
						%rot = contentEulerToAxis("0 0 0");
					}

					%obj.ghostShape.setTransform(%pos SPC %rot);
				}
				else
				{
					if(isObject(%obj.ghostShape))
					{
						%obj.ghostShape.delete();
					}

					%obj.ghostShape = "";
					%pos = %obj.position;
					%angleID = %obj.getAngleID();

					if(%angleID == 2)
					{
						%rot = contentEulerToAxis("0 0 270");
					}
					else if(%angleID == 3)
					{
						%rot = contentEulerToAxis("0 0 180");
					}
					else if(%angleID == 0)
					{
						%rot = contentEulerToAxis("0 0 90");
					}
					else
					{
						%rot = contentEulerToAxis("0 0 0");
					}

					%dataBlock = %obj.dataBlock.contentType.datablockShape;

					%obj.ghostShape = new StaticShape()
					{
						dataBlock = %dataBlock;
					};

					%obj.ghostShape.setTransform(%pos SPC %rot);
					%color = %obj.getColorId();
					%setcolor = getColorIDTable(%color);
					%r = getWord(%setcolor, 0);
					%g = getWord(%setcolor, 1);
					%b = getWord(%setcolor, 2);
					%obj.ghostShape.setNodeColor("ALL", %r SPC %g SPC %b SPC 1);
				}
			}
			else
			{
				if(isObject(%obj.ghostShape))
				{
					%obj.ghostShape.delete();
				}
				
				%obj.ghostShape = "";
			}
		}
		else if(isObject(%obj) && %obj.isPlanted)
		{
			if(isObject(%obj.ghostShape))
			{
				%obj.ghostShape.delete();
			}

			%obj.ghostShape = "";
		}
	}

	function fxDTSBrick::contentHide(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1 && isObject(%obj.shape) && %obj.shape.state == 0)
		{
			%obj.shape.delete();
		}
	}

	function fxDTSBrick::contentRestrictionAdmin(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%blid_permission = contentBLIDCheck(%client, %text);

			if(((%client.isAdmin || %client.isSuperAdmin) && %blid_permission != 0) || %blid_permission == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentRestrictionBLIDAllow(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(%text !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%text);%i++)
				{
					%word = getWord(%text, %i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word, %j, 1);

						if(strstr("1234567890", %char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%allow = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%allow = 1;
						break;
					}
				}

				if(%allow == 1)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentRestrictionBLIDDeny(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(%text !$= "")
			{
				%ids = 0;

				for(%i = 0;%i < getWordCount(%text);%i++)
				{
					%word = getWord(%text, %i);
					%fail = 0;

					for(%j = 0;%j < strlen(%word);%j++)
					{
						%char = getSubStr(%word, %j, 1);

						if(strstr("1234567890", %char) == -1)
						{
							%fail = 1;
						}
					}

					if(!%fail)
					{
						%id[%ids++] = %word;
					}
				}

				%deny = 0;

				for(%i = 1;%i <= %ids;%i++)
				{
					%blid = %id[%i];

					if(%blid == %client.BL_ID)
					{
						%deny = 1;
						break;
					}
				}

				if(%deny == 0)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 1;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentRestrictionMiniGame(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%blid_permission = contentBLIDCheck(%client, %text);

			if((miniGameCanUse(%client, %obj) == 1 && %blid_permission != 0) || %blid_permission == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentRestrictionTrustLevel1(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%blid_permission = contentBLIDCheck(%client, %text);

			if((getTrustLevel(%client, %obj) >= 1 && %blid_permission != 0) || %blid_permission == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentRestrictionTrustLevel2(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%blid_permission = contentBLIDCheck(%client, %text);

			if((getTrustLevel(%client, %obj) >= 2 && %blid_permission != 0) || %blid_permission == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentRestrictionTrustLevel3(%obj, %action, %direction, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%blid_permission = contentBLIDCheck(%client, %text);

			if((getTrustLevel(%client, %obj) >= 3 && %blid_permission != 0) || %blid_permission == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::contentStart(%obj, %startType, %startDirection, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();
		%direction[0] = "CW";
		%direction[1] = "CCW";
		%direction = %direction[%startDirection];

		if((%direction $= "CCW" || %direction $= "CW") && %contentTypeID > -1)
		{
			%permitted = -1;

			if(%startType == 0 || !$JVS::Content::Prefs::Restriction[%startType])
			{
				%permitted = 1;
			}
			else
			{
				%action = "START";

				for(%i = 0;%i < ContentRestrictionsSO.restrictions;%i++)
				{
					if(ContentRestrictionsSO.restrictionId[%i] == %startType)
					{
						eval("%permitted = %obj." @ ContentRestrictionsSO.restrictionMethod[%i] @ "(%action, %direction, %text, %client);");
						break;
					}
				}
			}

			if(%permitted == 1)
			{
				%obj.contentCheck();
				%obj.contentUse(%client, 0, "START", %direction);
			}
			else if(%permitted == 0)
			{
				%obj.onContentRestricted(%client);
			}
		}
	}

	function fxDTSBrick::contentStateStartingToStarted(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1 && isObject(%obj.shape))
		{
			%obj.shape.state = 2;
			%obj.onContentStarted(%client);
		}
	}

	function fxDTSBrick::contentStateStoppingToStopped(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1 && isObject(%obj.shape))
		{
			%obj.shape.stopAnimationName = "";
			%obj.shape.stopAnimationTime = "";
			%obj.shape.state = 0;
			%obj.onContentStopped(%client);
			%obj.isContentBlocking(%client);
		}
	}

	function fxDTSBrick::contentStop(%obj, %stopType, %text, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%direction = -1;

			if(%obj.shape.stopAnimationName $= %obj.dataBlock.contentType.animationNameStopCCW)
			{
				%direction = "CCW";
			}
			else if(%obj.shape.stopAnimationName $= %obj.dataBlock.contentType.animationNameStopCW)
			{
				%direction = "CW";
			}

			if(%direction $= "CCW" || %direction $= "CW")
			{
				%permitted = -1;

				if(%stopType == 0 || !$JVS::Content::Prefs::Restriction[%stopType])
				{
					%permitted = 1;
				}
				else
				{
					%action = "STOP";

					for(%i = 0;%i < ContentRestrictionsSO.restrictions;%i++)
					{
						if(ContentRestrictionsSO.restrictionId[%i] == %stopType)
						{
							eval("%permitted = %obj." @ ContentRestrictionsSO.restrictionMethod[%i] @ "(%action, %direction, %text, %client);");
							break;
						}
					}
				}

				if(%permitted == 1)
				{
					%obj.contentCheck();
					%obj.contentUse(%client, 0, "STOP", %direction);
				}
				else if(%permitted == 0)
				{
					%obj.onContentRestricted(%client);
				}
			}
		}
	}

	function fxDTSBrick::contentTypeID(%obj)
	{
		%error = 0;
		%contentTypeID = -1;

		if(!isObject(ContentTypesSO))
		{
			%error = 1;
			error("JVS_Content - ContentTypesSO does not exist!");
		}

		if(!isObject(ContentBricksSO))
		{
			%error = 1;
			error("JVS_Content - ContentBricksSO does not exist!");
		}

		if(%error != 1)
		{
			if(isObject(%obj.dataBlock.contentType))
			{
				%contentTypeID = %obj.dataBlock.contentType.id;
			}
		}
		else
		{
			error("JVS_Content - De-activating package.");
			deactivatePackage(JVS_Content);
		}

		return %contentTypeID;
	}

	function fxDTSBrick::contentUse(%obj, %client, %no_buzzer, %action, %direction)
	{
		%contentTypeID = %obj.contentTypeID();

		if((%action $= "START" || %action $= "STOP") && (%direction $= "CCW" || %direction $= "CW") && %contentTypeID > -1)
		{
			switch$(%action)
			{
				case "START":

					if(isObject(%obj.shape) && %obj.shape.state == 0)
					{
						%blockage = %obj.isContentBlocked(%client, 0, %direction);

						if(%blockage != 1)
						{
							%obj.onContentStart(%client);
							%obj.shape.stopAnimationName = %obj.dataBlock.contentType.animationNameStop[%direction];
							%obj.shape.unhideNode("ALL");
							%obj.shape.playThread(0, %obj.dataBlock.contentType.animationNameStart[%direction]);
							%obj.schedule(%obj.dataBlock.contentType.animationLengthStart, "contentStateStartingToStarted", %client);
							%obj.shape.state = 1;
						}
					}

				case "STOP":

					if(isObject(%obj.shape) && %obj.shape.state == 2)
					{
						%blockage = %obj.isContentBlocked(%client, %no_buzzer, %direction);

						if(%blockage != 1)
						{
							%obj.onContentStop(%client);
							%obj.shape.stopAnimationName = "";
							%time = %obj.dataBlock.contentType.animationLengthStop;
							%obj.shape.unhideNode("ALL");
							%obj.shape.playThread(0, %obj.dataBlock.contentType.animationNameStop[%direction]);
							%obj.schedule(%time, "contentStateStoppingToStopped", %client);
							%obj.shape.state = 3;
						}
						else
						{
							%obj.schedule(200, "contentBrickCheck", %client);
						}
					}
			}
		}
	}

	function fxDTSBrick::fakeKillBrick(%obj, %velocity_vector, %seconds_until_respawn, %client)
	{
		Parent::fakeKillBrick(%obj, %velocity_vector, %seconds_until_respawn, %client);
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%obj.contentDestroy(%client);
		}
	}

	function fxDTSBrick::isContentBlocked(%obj, %client, %no_buzzer, %direction)
	{
		%contentTypeID = %obj.contentTypeID();

		if((%direction $= "CCW" || %direction $= "CW") && %contentTypeID > -1 && isObject(%obj.shape))
		{
			%boxes = %obj.dataBlock.contentType.brickSearchBoxString;
			%positions = %obj.dataBlock.contentType.brickSearchPositionString[%direction];
			%objects = 0;

			if(getFieldCount(%boxes) > 0 && getFieldCount(%boxes) == getFieldCount(%positions))
			{
				for(%i = 0;%i < getFieldCount(%boxes);%i++)
				{
					%boxX = getWord(getField(%boxes, %i), 0);
					%boxY = getWord(getField(%boxes, %i), 1);
					%boxZ = getWord(getField(%boxes, %i), 2);

					%posX = getWord(getField(%positions, %i), 0);
					%posY = getWord(getField(%positions, %i), 1);
					%posZ = getWord(getField(%positions, %i), 2);

					%brickX = getWord(%obj.position, 0);
					%brickY = getWord(%obj.position, 1);
					%brickZ = getWord(%obj.position, 2);

					if(%obj.getAngleID() == 1)
					{
						%pos = %brickX + %posX SPC %brickY + %posY SPC %brickZ + %posZ;
						%box = %boxX SPC %boxY SPC %boxZ;
					}
					else if(%obj.getAngleID() == 2)
					{
						%pos = %brickX + %posY SPC %brickY - %posX SPC %brickZ + %posZ;
						%box = %boxY SPC %boxX SPC %boxZ;
					}
					else if(%obj.getAngleID() == 3)
					{
						%pos = %brickX - %posX SPC %brickY - %posY SPC %brickZ + %posZ;
						%box = %boxX SPC %boxY SPC %boxZ;
					}
					else if(%obj.getAngleID() == 0)
					{
						%pos = %brickX - %posY SPC %brickY + %posX SPC %brickZ + %posZ;
						%box = %boxY SPC %boxX SPC %boxZ;
					}
					else
					{
						return -1;
					}

					InitContainerBoxSearch(%pos, %box, $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::VehicleObjectType);

					while(isObject(%checkObj = containerSearchNext()))
					{
						if(%checkObj.getClassName() !$= "fxDTSBrick" || (%checkObj != %obj && %checkObj.isPlanted == 1 && !%checkObj.isFakeDead() && !%checkObj.isDead() && (%checkObj.isColliding() || %checkObj.contentTypeID() > -1)))
						{
							%objects++;
						}
					}
				}

				if(%objects > 0)
				{
					if(isObject(%client) && %no_buzzer != 1)
					{
						%obj.onContentBlocked(%client);
					}

					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return -1;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::isContentBlocking(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1 && isObject(%obj.shape))
		{
			%size = %obj.dataBlock.contentType.brickSize;
			%x = getField(%size, 0);
			%y = getField(%size, 1);
			%z = getField(%size, 2);
			%box = %x / 2 - 0.1 SPC %y / 2 - 0.1 SPC %z / 3 * 0.6 - 0.1;
			%pos = %obj.position;
			%objects = 0;
			%players = 0;
			%vehicles = 0;
			InitContainerBoxSearch(%pos, %box, $TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType);

			while(isObject(%checkObj = containerSearchNext()))
			{
				if(%checkObj.getClassName() $= "Player")
				{
					if(%checkObj.isEnabled())
					{
						if(%checkObj.isCrouched())
						{
							%boxMax = vectorAdd(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().crouchBoundingBox, 1/8));
							%boxMin = vectorSub(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().crouchBoundingBox, 1/8));
						}
						else
						{
							%boxMax = vectorAdd(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().boundingBox, 1/8));
							%boxMin = vectorSub(%checkObj.getHackPosition(),vectorScale(%checkObj.getDataBlock().boundingBox, 1/8));
						}

						%brickMinX = getWord(%obj.getWorldBox(), 0);
						%brickMinY = getWord(%obj.getWorldBox(), 1);
						%brickMinZ = getWord(%obj.getWorldBox(), 2);

						%brickMaxX = getWord(%obj.getWorldBox(), 3);
						%brickMaxY = getWord(%obj.getWorldBox(), 4);
						%brickMaxZ = getWord(%obj.getWorldBox(), 5);

						%playerMinX = getWord(%boxMin, 0);
						%playerMinY = getWord(%boxMin, 1);
						%playerMinZ = getWord(%boxMin, 2);

						%playerMaxX = getWord(%boxMax, 0);
						%playerMaxY = getWord(%boxMax, 1);
						%playerMaxZ = getWord(%boxMax, 2);

						if(%playerMaxX > %brickMinX && %playerMinX < %brickMaxX && %playerMaxY > %brickMinY && %playerMinY < %brickMaxY && %playerMaxZ > %brickMinZ && %playerMinZ < %brickMaxZ)
						{
							%objects++;
							%players++;

							if(%players - 1 == 0)
							{
								%obj.onContentStuckPlayer(%checkObj.client);
							}
							else if(%players - 1 > 0)
							{
								%obj.schedule((%players - 1) * 33, "onContentStuckPlayer", %checkObj.client);
							}
						}
					}
				}
				else
				{
					%objects++;
					%vehicles++;

					if(%vehicles - 1 == 0)
					{
						%obj.onContentStuckVehicle(%checkObj);
					}
					else if(%vehicles - 1 > 0)
					{
						%obj.schedule((%vehicles - 1) * 33, "onContentStuckVehicle", %checkObj);
					}
				}
			}

			if(%objects > 0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return -1;
		}
	}

	function fxDTSBrick::onBlownUp(%obj, %client)
	{
		Parent::onBlownUp(%obj, %client);
		%obj.contentDestroy(%client);
	}

	function fxDTSBrick::onClearFakeDeath(%obj)
	{
		Parent::onClearFakeDeath(%obj);
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%obj.setRendering(1);
			%obj.noContentEvents = 1;
			%obj.schedule(600, "contentCreate", 0);
		}
	}

	function fxDTSBrick::onContentBlocked(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentBlocked", %client);
		}
	}

	function fxDTSBrick::onContentCreated(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentCreated", %client);
		}
	}

	function fxDTSBrick::onContentRestricted(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentRestricted", %client);
		}
	}

	function fxDTSBrick::onContentStart(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentStart", %client);
		}
	}

	function fxDTSBrick::onContentStarted(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentStarted", %client);
		}
	}

	function fxDTSBrick::onContentStop(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentStop", %client);
		}
	}

	function fxDTSBrick::onContentStopped(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentStopped", %client);
		}
	}

	function fxDTSBrick::onContentStuckPlayer(%obj, %client)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			%obj.processInputEvent("onContentStuckPlayer", %client);
		}
	}

	function fxDTSBrick::onContentStuckVehicle(%obj, %stuckVehicle)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%client = 0;

			if(isObject(%stuckVehicle.lastDrivingClient))
			{
				%client = %stuckVehicle.lastDrivingClient;
			}
			else
			{
				%client = %stuckVehicle.spawnBrick.getGroup().client;
			}

			$InputTarget_["Self"] = %obj;
			$InputTarget_["Player"] = %client.Player;
			$InputTarget_["Client"] = %client;

			if($Server::LAN)
			{
				$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
				$InputTarget_["OwnerPlayer"] = 0;
				$InputTarget_["OwnerClient"] = 0;
			}
			else
			{
				if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
				{
					$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
				}
				else
				{
					$InputTarget_["MiniGame"] = 0;
				}

				if(isObject(%obj.getGroup().client))
				{
					$InputTarget_["OwnerPlayer"] = %obj.getGroup().client.Player;
					$InputTarget_["OwnerClient"] = %obj.getGroup().client;
				}
				else
				{
					$InputTarget_["OwnerPlayer"] = 0;
					$InputTarget_["OwnerClient"] = 0;
				}
			}

			if(isObject(%stuckVehicle.spawnBrick))
			{
				$InputTarget_["StuckVehicleSpawns"] = %stuckVehicle.spawnBrick;
			}
			else
			{
				$InputTarget_["StuckVehicleSpawns"] = 0;
			}

			%obj.processInputEvent("onContentStuckVehicle", %client);
		}
	}

	function fxDTSBrick::onDeath(%obj)
	{
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(isObject(%obj.shape))
			{
				%obj.shape.delete();
			}

			%obj.shape = "";
		}

		Parent::onDeath(%obj);
	}

	function fxDTSBrick::onPlant(%obj)
	{
		Parent::onPlant(%obj);
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(%obj == $LastLoadedBrick)
			{
				%obj.noContentEvents = 1;
			}

			%obj.schedule(33, "contentCreate", 0);
		}
	}

   function fxDTSBrick::onLoadPlant(%obj)
	{
		Parent::onLoadPlant(%obj);
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(%obj == $LastLoadedBrick)
			{
				%obj.noContentEvents = 1;
			}

			%obj.schedule(33, "contentCreate", 0);
		}
	}

	function fxDTSBrick::onRemove(%obj)
	{
		%error = 0;
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(isObject(%obj.shape))
			{
				%obj.shape.delete();
			}

			%obj.shape = "";

			if(isObject(%obj.ghostShape))
			{
				%obj.ghostShape.delete();
			}

			%obj.ghostShape = "";

			ContentBricksSO.remove(%obj);
		}

		Parent::onRemove(%obj);
	}

	function fxDTSBrick::setColor(%obj, %colorID)
	{
		if(%colorID $= "")
		{
			%colorID = 0;
		}

		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			if(isObject(%obj.ghostShape))
			{
				%color = getColorIDTable(%colorID);
				%r = getWord(%color, 0);
				%g = getWord(%color, 1);
				%b = getWord(%color, 2);
				%obj.ghostShape.setNodeColor("ALL", %r SPC %g SPC %b SPC 1);
			}

			if(isObject(%obj.shape))
			{
				%color = getColorIDTable(%colorID);
				%r = getWord(%color, 0);
				%g = getWord(%color, 1);
				%b = getWord(%color, 2);
				%color = %r SPC %g SPC %b SPC 1;
				%black25 = %r * 0.75 SPC %g * 0.75 SPC %b * 0.75 SPC 1;
				%black50 = %r * 0.5 SPC %g * 0.5 SPC %b * 0.5 SPC 1;
				%black75 = %r * 0.25 SPC %g * 0.25 SPC %b * 0.25 SPC 1;

				for(%i = 0;%i < %obj.dataBlock.contentType.nodeCount;%i++)
				{
					%nodecolor = %obj.dataBlock.contentType.nodeColor[%i];
					%nodename = %obj.dataBlock.contentType.nodeName[%i];

					if(%nodecolor $= "black25")
					{
						%obj.shape.setNodeColor(%nodename, %black25);
					}
					else if(%nodecolor $= "black50")
					{
						%obj.shape.setNodeColor(%nodename, %black50);
					}
					else if(%nodecolor $= "black75")
					{
						%obj.shape.setNodeColor(%nodename, %black75);
					}
					else if(%nodecolor $= "color")
					{
						%obj.shape.setNodeColor(%nodename, %color);
					}
					else
					{
						%obj.shape.setNodeColor(%nodename, %nodecolor);
					}
				}
			}
		}

		Parent::setColor(%obj, %colorID);
	}

	function fxDTSBrick::setTransform(%obj, %transform)
	{
		Parent::setTransform(%obj, %transform);
		%contentTypeID = %obj.contentTypeID();

		if(%contentTypeID > -1)
		{
			%obj.schedule(33, "contentGhostBrickCheck");
		}
		else
		{
			if(isObject(%obj.ghostShape))
			{
				%obj.ghostShape.delete();
			}

			%obj.ghostShape = "";
		}
	}

	//Server Commands

	function serverCmdCancelBrick(%client)
	{
		%obj = %client.Player.tempBrick;

		if(isObject(%obj))
		{
			%contentTypeID = %obj.contentTypeID();

			if(isObject(%obj) && %contentTypeID > -1)
			{
				if(isObject(%obj.ghostShape))
				{
					%obj.ghostShape.delete();
				}

				%obj.ghostShape = "";
			}
		}

		Parent::serverCmdCancelBrick(%client);
	}

	function serverCmdClearAllContent(%client)
	{
		%error = 0;

		if(!isObject(ContentTypesSO))
		{
			%error = 1;
			error("JVS_Content - ContentTypesSO does not exist!");
		}

		if(!isObject(ContentBricksSO))
		{
			%error = 1;
			error("JVS_Content - ContentBricksSO does not exist!");
		}

		if((%client.isAdmin == 1 || %client.isSuperAdmin == 1) && %error != 1)
		{
			%brick_count = ContentBricksSO.bricks;
			%bricks = 0;

			for(%i = 1;%i <= %brick_count;%i++)
			{
				%object = ContentBricksSO.brick[%i];

				if(isObject(%object))
				{
					%brick[%bricks++] = %object;
				}
			}

			if(%bricks > 0)
			{
				for(%i = 1;%i <= %bricks;%i++)
				{
					if(isObject(%brick[%i]))
					{
						%brick[%i].delete();
					}

					ContentBricksSO.remove(%brick[%i]);
				}

				messageAll('MsgClearBricks', "\c3" @ %client.name @ "\c0 cleared all content bricks.");
			}
		}
		else if(%client.isAdmin == 1 || %client.isSuperAdmin == 1)
		{
			error("JVS_Content - De-activating package.");
			deactivatePackage(JVS_Content);
		}
	}

	function serverCmdClearContent(%client)
	{
		%error = 0;

		if(!isObject(ContentTypesSO))
		{
			%error = 1;
			error("JVS_Content - ContentTypesSO does not exist!");
		}

		if(!isObject(ContentBricksSO))
		{
			%error = 1;
			error("JVS_Content - ContentBricksSO does not exist!");
		}

		if(%error != 1)
		{
			%brick_count = ContentBricksSO.bricks;
			%bricks = 0;

			for(%i = 1;%i <= %brick_count;%i++)
			{
				%object = ContentBricksSO.brick[%i];

				if(isObject(%object))
				{
					if(%object.getGroup().client == %client)
					{
						if(isObject(%object))
						{
							%brick[%bricks++] = %object;
						}
					}
				}
			}

			if(%bricks > 0)
			{
				for(%i = 1;%i <= %bricks;%i++)
				{
					if(isObject(%brick[%i]))
					{
						%brick[%i].delete();
					}

					ContentBricksSO.remove(%brick[%i]);
				}

				messageAll('MsgClearBricks', "\c3" @ %client.name @ "\c2 cleared \c3" @ %client.name @ "\c2's content bricks.");
			}
		}
		else
		{
			error("JVS_Content - De-activating package.");
			deactivatePackage(JVS_Content);
		}
	}

	function serverCmdClearContentByBLID(%client, %blid)
	{
		%error = 0;

		if(!isObject(ContentTypesSO))
		{
			%error = 1;
			error("JVS_Content - ContentTypesSO does not exist!");
		}

		if(!isObject(ContentBricksSO))
		{
			%error = 1;
			error("JVS_Content - ContentBricksSO does not exist!");
		}

		if((%client.isAdmin == 1 || %client.isSuperAdmin == 1) && %error != 1)
		{
			%group = 0;

			for(%i = 0;%i < MainBrickGroup.getCount();%i++)
			{
				%brick_group = MainBrickGroup.getObject(%i);

				if(%brick_group.bl_id == %blid)
				{
					%group = %brick_group;
					break;
				}
			}

			if(isObject(%group))
			{
				%brick_count = ContentBricksSO.bricks;
				%bricks = 0;

				for(%i = 1;%i <= %brick_count;%i++)
				{
					%obj = ContentBricksSO.brick[%i];

					if(isObject(%obj))
					{
						if(%obj.getGroup() == %group)
						{
							if(isObject(%obj))
							{
								%brick[%bricks++] = %obj;
							}
						}
					}
				}

				if(%bricks > 0)
				{
					for(%i = 1;%i <= %bricks;%i++)
					{
						if(isObject(%brick[%i]))
						{
							%brick[%i].delete();
						}

						ContentBricksSO.remove(%brick[%i]);
					}

					messageAll('MsgClearBricks', "\c3" @ %client.name @ "\c2 cleared \c1BL_ID: " @ %blid @ "\c2's content bricks.");
				}
			}
		}
		else if(%client.isAdmin == 1 || %client.isSuperAdmin == 1)
		{
			error("JVS_Content - De-activating package.");
			deactivatePackage(JVS_Content);
		}
	}

	function serverCmdClearContentByName(%client, %name)
	{
		%error = 0;

		if(!isObject(ContentTypesSO))
		{
			%error = 1;
			error("JVS_Content - ContentTypesSO does not exist!");
		}

		if(!isObject(ContentBricksSO))
		{
			%error = 1;
			error("JVS_Content - ContentBricksSO does not exist!");
		}

		if((%client.isAdmin == 1 || %client.isSuperAdmin == 1) && %error != 1)
		{
			%cl = findClientByName(%name);

			if(isObject(%cl))
			{
				%brick_count = ContentBricksSO.bricks;
				%bricks = 0;

				for(%i = 1;%i <= %brick_count;%i++)
				{
					%obj = ContentBricksSO.brick[%i];

					if(isObject(%obj))
					{
						if(%obj.getGroup().client == %cl)
						{
							if(isObject(%obj))
							{
								%brick[%bricks++] = %obj;
							}
						}
					}
				}

				if(%bricks > 0)
				{
					for(%i = 1;%i <= %bricks;%i++)
					{
						if(isObject(%brick[%i]))
						{
							%brick[%i].delete();
						}

						ContentBricksSO.remove(%brick[%i]);
					}

					messageAll('MsgClearBricks', "\c3" @ %client.name @ "\c2 cleared \c3" @ %cl.name @ "\c2's content bricks.");
				}
			}
		}
		else if(%client.isAdmin == 1 || %client.isSuperAdmin == 1)
		{
			error("JVS_Content - De-activating package.");
			deactivatePackage(JVS_Content);
		}
	}

	function serverCmdContentCount(%client)
	{
		%bricks = 0;

		for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
		{
			%brick = ContentBricksSO.getContentBrickFromID(%i);

			if(isObject(%brick) && %brick.getGroup() == %client.brickGroup && !%brick.isDead())
			{
				%bricks++;
			}
		}

		if(%bricks == 0 || %bricks > 1)
		{
			%message = "You own " @ %bricks @ " content bricks.";
		}
		else
		{
			%message = "You own " @ %bricks @ " content brick.";
		}

		messageClient(%client, "", %message);
	}

	function serverCmdContentCountAll(%client)
	{
		if(%client.isAdmin || %client.isSuperAdmin)
		{
			%bricks = 0;

			for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
			{
				%brick = ContentBricksSO.getContentBrickFromID(%i);

				if(isObject(%brick) && !%brick.isDead())
				{
					%bricks++;
				}
			}

			if(%bricks == 0 || %bricks > 1)
			{
				%message = "There are " @ %bricks @ " content bricks.";
			}
			else
			{
				%message = "There is " @ %bricks @ " content brick.";
			}

			messageClient(%client, "", %message);
		}
	}

	function serverCmdContentCountByBLID(%client, %blid)
	{
		if(%client.isAdmin || %client.isSuperAdmin)
		{
			%group = 0;

			for(%i = 0;%i < MainBrickGroup.getCount();%i++)
			{
				%brick_group = MainBrickGroup.getObject(%i);

				if(%brick_group.bl_id == %blid)
				{
					%group = %brick_group;
					break;
				}
			}

			if(isObject(%group))
			{
				%bricks = 0;

				for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
				{
					%brick = ContentBricksSO.getContentBrickFromID(%i);

					if(isObject(%brick) && %brick.getGroup() == %group && !%brick.isDead())
					{
						%bricks++;
					}
				}

				if(%bricks == 0 || %bricks > 1)
				{
					%message = "BLID " @ %blid @ " owns " @ %bricks @ " content bricks.";
				}
				else
				{
					%message = "BLID " @ %blid @ " owns " @ %bricks @ " content brick.";
				}

				messageClient(%client, "", %message);
			}
		}
	}

	function serverCmdContentCountByName(%client, %name)
	{
		if(%client.isAdmin || %client.isSuperAdmin)
		{
			%cl = findClientByName(%name);

			if(isObject(%cl))
			{
				%bricks = 0;

				for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
				{
					%brick = ContentBricksSO.getContentBrickFromID(%i);

					if(isObject(%brick) && %brick.getGroup() == %cl.brickGroup && !%brick.isDead())
					{
						%bricks++;
					}
				}

				if(%bricks == 0 || %bricks > 1)
				{
					%message = %cl.name @ " owns " @ %bricks @ " content bricks.";
				}
				else
				{
					%message = %cl.name @ " owns " @ %bricks @ " content brick.";
				}

				messageClient(%client, "", %message);
			}
		}
	}

	function serverCmdContentCreate(%client)
	{
		%obj = %client.wrenchBrick;

		if(isObject(%obj))
		{
			%contentTypeID = %obj.contentTypeID();

			if(%contentTypeID > -1)
			{
				%obj.contentCreate(0);
			}
		}
	}

	function serverCmdContentLimit(%client)
	{
		%message = "Max content bricks per player is " @ getMaxContentBricksPerPlayer() @ ".";
		messageClient(%client, "", %message);
	}

	function serverCmdPlantBrick(%client)
	{
		%obj = %client.Player.tempBrick;

		if(isObject(%obj))
		{
			%contentTypeID = %obj.contentTypeID();

			if(%contentTypeID > -1)
			{
				%bricks = 0;

				for(%i = 1;%i <= ContentBricksSO.bricks;%i++)
				{
					%brick = ContentBricksSO.getContentBrickFromID(%i);

					if(isObject(%brick) && %brick.getGroup() == %obj.getGroup() && %brick != %obj && !%brick.isDead())
					{
						%bricks++;
					}
				}

				%max = getMaxContentBricksPerPlayer();

				if(%bricks < %max)
				{
					Parent::serverCmdPlantBrick(%client);
				}
				else
				{
					if(%max > 1)
					{
						commandToClient(%client, 'centerprint', "\c0You are not permitted to make more than " @ %max @ " content bricks.", 2, 2, 2000);
					}
					else if(%max == 1)
					{
						commandToClient(%client, 'centerprint', "\c0You are not permitted to make more than " @ %max @ " content bricks.", 2, 2, 2000);
					}
					else
					{
						commandToClient(%client, 'centerprint', "\c0You are not permitted to make content bricks.", 2, 2, 2000);
					}
				}
			}
			else
			{
				Parent::serverCmdPlantBrick(%client);
			}
		}
		else
		{
			Parent::serverCmdPlantBrick(%client);
		}
	}
};

activatePackage(JVS_Content);

//Prefs

if(!$JVS::Content::RTBPrefs::MaxContent)
{
	if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
	{
		if(!$RTB::RTBR_ServerControl_Hook)
		{
			exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
		}

		RTB_registerPref("Max Bricks Per Player", "JVS Content", "$JVS::Content::Prefs::MaxContentBricksPerPlayer", "int 0 9999", "JVS_Content", 50, 0, 0);
		$JVS::Content::RTBPrefs::MaxContent = 1;
	}
	else
	{
		$JVS::Content::Prefs::MaxContentBricksPerPlayer = getMaxContentBricksPerPlayer();
	}
}

//Input Events

if(!$JVS::Content::InputEvents)
{
	registerInputEvent("fxDTSBrick", "onContentBlocked", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentCreated", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentRestricted", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentStart", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentStarted", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentStop", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentStopped", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentStuckPlayer", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection", 1);
	registerInputEvent("fxDTSBrick", "onContentStuckVehicle", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "OwnerPlayer Player" TAB "OwnerClient GameConnection" TAB "StuckVehicleSpawns fxDTSBrick", 1);

	$JVS::Content::InputEvents = 1;
}

//Output Events

if(!$JVS::Content::OutputEvents)
{
	registerOutputEvent("fxDTSBrick", "contentHide", "", 1);

	$JVS::Content::OutputEvents = 1;
}

//Restrictions

if(!$JVS::Content::Restrictions)
{
	ContentRestrictionsSO.refreshRestrictions();
	$JVS::Content::Restrictions = 1;

	ContentRestrictionsSO.addRestriction("Admin", "contentRestrictionAdmin", 10100205);
	ContentRestrictionsSO.addRestriction("BLIDAllow", "contentRestrictionBLIDAllow", 10200205);
	ContentRestrictionsSO.addRestriction("BLIDDeny", "contentRestrictionBLIDDeny", 10300205);
	ContentRestrictionsSO.addRestriction("MiniGame", "contentRestrictionMiniGame", 10400205);
	ContentRestrictionsSO.addRestriction("TrustLevel1", "contentRestrictionTrustLevel1", 10500205);
	ContentRestrictionsSO.addRestriction("TrustLevel2", "contentRestrictionTrustLevel2", 10600205);
	ContentRestrictionsSO.addRestriction("TrustLevel3", "contentRestrictionTrustLevel3", 10700205);
}