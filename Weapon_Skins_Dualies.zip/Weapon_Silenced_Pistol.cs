//////////
// item //
//////////
datablock ItemData(AkimboSilencedPistolItem : SilencedPistolItem)
{
	uiName = "Covert Pistols A.";


   	shapeFile = "add-ons/weapon_skins_pistol/pistol_covert.dts";
	iconName = "./item_dualSilenced";
	colorShiftColor = Silencedpistolitem.colorshiftcolor;
	 // Dynamic properties defined by the scripts
	image = AkimboSilencedPistolImage;
	//Ammo Guns Parameters
	l4ditemtype = "secondary";
	maxAmmo = Silencedpistolitem.maxammo*2;
};

////////////////
//weapon image//
////////////////
AddDamageType("AkimboL4SilencedPistol",   '<bitmap:add-ons/Weapon_Package_Tier1/CI_DualPistol> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier1/CI_DualPistol> %1',0.75,1);
datablock ShapeBaseImageData(AkimboSilencedPistolImage : AkimboPistolImage)
{
   // Basic Item properties
   	shapeFile = "add-ons/weapon_skins_pistol/pistol_covert.dts";
   item = AkimboSilencedPistolItem;

   doColorShift = true;
   colorShiftColor = AkimboSilencedPistolItem.colorShiftColor;//"0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 200; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = Silencedpistolimage.raycastdirectdamage;
   raycastDirectDamageType = $DamageType::AkimboL4SilencedPistol;
   raycastSpreadAmt = 0.0006; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = PistolTracerProjectile;
   raycastFromMuzzle = true;

	stateSound[2]			  = SilencedPistolfireSound;

};

datablock ShapeBaseImageData(LeftHandedSilencedPistolImage : LeftHandedPistolImage)
{
   // Basic Item properties
   	shapeFile = "add-ons/weapon_skins_pistol/pistol_covert.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = AkimboSilencedPistolItem;
   ammo = " ";
   projectile = PumpShotgunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = AkimboSilencedPistolItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 200; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = Silencedpistolimage.raycastdirectdamage;
   raycastDirectDamageType = $DamageType::AkimboL4SilencedPistol;
   raycastSpreadAmt = 0.0006; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = PistolTracerProjectile;
   raycastFromMuzzle = true;

	stateSound[2]			  = SilencedPistolfireSound;
};

function AkimbosilencedPistolImage::onMount(%this, %obj, %slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	Parent::onMount(%this, %obj, %slot);
	%obj.mountImage(LeftHandedsilencedPistolImage, 1);
}

function AkimbosilencedPistolImage::onUnMount(%this, %obj, %slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	Parent::onUnMount(%this, %obj, %slot);
	%obj.unMountImage(1);
}

function AkimbosilencedPistolImage::onFire(%this,%obj,%slot)
{
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0018;
		%this.raycastWeaponRange = 85;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0006;
		%this.raycastWeaponRange = 200;
	}
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}

	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, shiftAway);
}

function AkimbosilencedPistolImage::onFireAkimbo(%this,%obj,%slot)
{
	%obj.setImageTrigger(1,1);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
}

function AkimbosilencedPistolImage::onLoadCheck(%this,%obj,%slot)
{
	Parent::onLoadCheck(%this,%obj,%slot);
	%obj.setImageAmmo(1,%obj.getImageAmmo(0));
}

function AkimbosilencedPistolImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, activate2);
            serverPlay3D(block_moveBrick_Sound,%obj.getPosition());
	}
}

//function AkimbosilencedPistolImage::onReloadLeft(%this,%obj,%slot)
//{
//	%obj.playThread(3, leftRecoil);
//}

function AkimbosilencedPistolImage::onReloadNext(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, plant);
            serverPlay3D(block_plantBrick_Sound,%obj.getPosition());
	}
}

function AkimbosilencedPistolImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.client.quantity["9MMrounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(pistolClickSound,%obj.getPosition());

        if(%obj.client.quantity["9MMrounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["9MMrounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["9MMrounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["9MMrounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["9MMrounds"] = 0;

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}
	}
}

function LeftHandedsilencedPistolImage::onMount(%this, %obj, %slot)
{
	Parent::onMount(%this, %obj, %slot);
	%obj.playThread(1, armreadyboth);
}

function LeftHandedsilencedPistolImage::onUnMount(%this, %obj, %slot)
{
	Parent::onUnMount(%this, %obj, %slot);
}

function LeftHandedsilencedPistolImage::onFire(%this, %obj, %slot)
{
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0027;
		%this.raycastWeaponRange = 85;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0012;
		%this.raycastWeaponRange = 200;
	}
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, leftrecoil);
}