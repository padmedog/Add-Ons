%error = ForceRequiredAddOn( "Support_Doors" );

if( %error == $Error::AddOn_NotFound )
{
	error("Brick Doors: Support_Doors is missing somehow, what did you do?");
}
else
{
	exec( "./PlainDoor.cs" );
	exec( "./PlainDoor2.cs" );
	exec( "./OfficeDoor.cs" );
	exec( "./ScreenDoor.cs" );
	exec( "./ScreenDoor2.cs" );
	exec( "./WoodenDoor.cs" );
	exec( "./WoodenDoor2.cs" );
	exec( "./WoodenDoor3.cs" );
	exec( "./SlidingDoor.cs" );
	exec( "./SecurityDoor.cs" );
	exec( "./SecurityDoor2.cs" );
	exec( "./PeepHoleDoor.cs" );
}