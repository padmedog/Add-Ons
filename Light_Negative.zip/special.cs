datablock fxLightData(AntiAllBlinkingLight)
{
	uiName = "Blinking Anti All";
	LightOn = true;
	radius = 1;
	brightness = -50;
	color = "1 1 1 0";
	FlareOn			= true;
	FlareTP			= true;
	Flarebitmap		= "base/lighting/flare2";
	FlareColor		= "1 1 1";
	ConstantSizeOn	= false;
	ConstantSize	= 1;
	NearSize		= 1;
	FarSize			= 0.5;
	NearDistance	= 10.0;
	FarDistance		= 30.0;
	FadeTime		= 0.1;
	BlendMode		= 0;
	AnimColor		= false;
	AnimBrightness	= true;
	AnimOffsets		= false;
	AnimRotation	= false;
	AnimRadius	= true;
	LinkFlare		= true;
	LinkFlareSize	= true;
	MinColor		= "1 1 1";
	MaxColor		= "0 0 0";
	MinBrightness	= -51;
	MaxBrightness	= 1;
	MinRadius		= 1;
	MaxRadius		= 5;
	StartOffset		= "-5 0 0";
	EndOffset		= "5 0 0";
	MinRotation		= 0;
	MaxRotation		= 359;
	SingleColorKeys	= false;
	RedKeys			= "AAAAAAA";
	GreenKeys		= "DHSFJYJ";
	BlueKeys		= "ZZZZZZZ";
	BrightnessKeys	= "AZAZAZA";
	RadiusKeys		= "AZAZAZA";
	OffsetKeys		= "AZAAAAA";
	RotationKeys	= "AZAAAAA";
	ColorTime		= 1;
	BrightnessTime	= 1;
	RadiusTime		= 1;
	OffsetTime		= 1;
	RotationTime	= 1;
	LerpColor		= false;
	LerpBrightness	= false;
	LerpRadius		= false;
	LerpOffset		= false;
	LerpRotation	= false;
};

datablock fxLightData(AntiRedBlinkingLight : AntiAllBlinkingLight)
{
	uiname = "Blinking Anti Red";
	color = "1 0 0 0";
};

datablock fxLightData(AntiGreenBlinkingLight : AntiAllBlinkingLight)
{
	uiname = "Blinking Anti Green";
	color = "0 1 0 0";
};

datablock fxLightData(AntiBlueBlinkingLight : AntiAllBlinkingLight)
{
	uiname = "Blinking Anti Blue";
	color = "0 0 1 0";
};