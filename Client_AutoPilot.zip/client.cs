if (!$autoPilotBinds)
{
	$remapDivision[$remapCount] = "Time/Pilot";
	$remapName[$remapCount] = "Toggle AutoPilot";
	$remapCmd[$remapCount] = "autoPilot_Startup";
    $remapCount++;
    $remapName[$remapCount] = "Increase timescale";
	$remapCmd[$remapCount] = "timescale_Add";
    $remapCount++;
    $remapName[$remapCount] = "Decrease timescale";
	$remapCmd[$remapCount] = "timescale_Subtract";
	$remapCount++;
	$autoPilotBinds = 3;
}

$mainTimeScale = 0;

function autoPilot_Startup(%x)
{
	if(%x)
	{ 
		if(!moveforward(0))
		{
			moveforward(1);
		}
		else
		{
			moveforward(0);
		}
	}

}

function timescale_Add()
{
    $mainTimeScale += 0.1;
}

function timescale_Subtract()
{
    $mainTimeScale -= 0.1;
}

//package timescale_Pack
//{
    function timescale_Main(%client)
    {
        clientcmdtimescale($mainTimeScale);
    }
//}
//activatePackage(timescale_Pack);