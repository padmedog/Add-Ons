%error = ForceRequiredAddOn("Weapon_Rocket_Launcher");
if(%error == $Error::AddOn_Disabled)
	RocketLauncherItem.uiName = "";
if(%error == $Error::AddOn_NotFound)
	error("ERROR: Weapon_TcPowerBeam - required add-on Weapon_Rocket_Launcher not found");
else
	exec("./Weapon_PowerBeam.cs");