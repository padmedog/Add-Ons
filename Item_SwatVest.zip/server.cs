datablock AudioProfile(EquipVest)
{
   filename    = "./Equipsound.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ItemData(TacticalVestItem)
{
	category = "Item";  // Mission editor category

	equipment = true;

	 // Basic Item Properties
	shapeFile = "./Swatvestermcgee.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Swat Vest";
	iconName = "./";
	doColorShift = True;
	colorShiftColor = "0.0784314 0.0784314 0.0784314 1";
	
	 // Dynamic properties defined by the scripts
	image = TacticalVesthandImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TacticalVesthandImage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/empty.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.13 0.2 -0.8";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0.13 0.2 -0.8";
   eyeRotation = eulerToMatrix("0 0 0");

   doColorShift = true;
	colorShiftColor = TacticalVestItem.colorShiftColor;
   

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "ToolImage";

   // Projectile && Ammo.
   item = TacticalVestItem;

   //melee particles shoot from eye node for consistancy
   melee = true;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = TacticalVestItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]       = "Ready";


	stateName[1]                     = "Ready";
	stateScript[1]                  = "onUse";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;


	stateName[2]                    = "Fire";
	stateTransitionOnTriggerUp[2]	= "Ready";
	stateScript[2]                  = "onFire";
};

datablock ShapeBaseImageData(TacticalVestMImage)
{
   // Basic Item properties
   shapeFile = "./Swatvestermcgee.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 2;
   offset = "0 0.05 -0.42";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0.65 1 5.1";
   eyeRotation = eulerToMatrix("0 0 0");

   doColorShift = true;
   colorShiftColor = TacticalVestItem.colorShiftColor;
   

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "ToolImage";

   // Projectile && Ammo.
   item = TacticalVest2Item;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = TacticalVestItem.colorShiftColor; //"0.200 0.200 0.200 1.000";

	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]       = "Ready";

	stateName[1]                     = "Ready";
};

function TacticalVestHandImage::onFire(%this, %obj, %slot)
{
	%client = %obj.client;
	if(%client.player.TacticalVest == 0)
	{
		serverPlay3D(EquipVest, %obj.position);
		%client.player.unmountimage(1);
		%client.player.mountimage(TacticalVestMimage, 2);
		%client.player.TacticalVest = 1;
	}
	else
	{
		%client.player.TacticalVest = 0;
		%client.player.unmountimage(2);
	}
}


function TacticalVestimage::onMount(%this,%user)
{
	%user.playthread(1,root);
	if(%user.TacticalVest)
	{
		return;
	}
}

function TacticalVestimage::onUnMount(%this,%user)
{
	if(%user.TacticalVest)
	{
		return;
	}
	%user.unmountimage(1);
}

package TacticalVested
{
   function Armor::damage(%this, %obj, %sourceObject, %position, %damage, %damageType, %slot)
   {
      if(%obj.client.player.TacticalVest == 1)
      {
         %damage/= 2; // Damage/2
      }
      Parent::damage(%this, %obj, %sourceObject, %position, %damage, %damageType, %slot);
   }
};
activatePackage(TacticalVested);