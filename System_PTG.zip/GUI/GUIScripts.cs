function PTG_ColPriBri_GUI::onBrickSelect()
{
	if(BrickList.getSelectedID() != -1)
	{
		%BriIcon = DataBlockGroup.getObject(BrickList.getSelectedID()).IconName;
		BrickPreview.setBitmap(%BriIcon);
		$BriPrev.setBitmap(%BriIcon);
		$BriNPrev.setText("<font:Calibri:15><color:000000>" @ BrickList.getValue());
	}
	if(BrickList.getSelectedID() == -1)
	{
		BrickPreview.setBitmap("base/client/ui/brickicons/Unknown");
		$BriPrev.setBitmap("base/client/ui/brickicons/Unknown");
		$BriNPrev.setText("<font:Calibri:15><color:000000>" @ "(NO BRICK)");
	}
}
function PTG_ColPriBri_GUI::onPrintSelect()
{
	if(PrintList.getSelectedID()!=-1)
	{
		%fp = getPrintTexture(PrintList.getSelectedID());
		%fp = strReplace(%fp,"prints","icons");
	}
	else
		%fp = "Add-Ons/System_PTG/Bricks_Prints/emptyprint.png";

	PrintPreview.setBitmap(%fp);
	$PriPrev.setBitmap(%fp);
}
function PTG_ColPriBri_GUI::onColorSelect()
{
	%CBc=getColorIDtable($ColNum);
	%CBcb=mFloatLength((getWord(%CBc,0)*255),0) @ " " @ mFloatLength((getWord(%CBc,1)*255),0) @ " " @ mFloatLength((getWord(%CBc,2)*255),0) @ " " @ mFloatLength((getWord(%CBc,3)*255),0);
	ColorPreview.setColor(%CBcb);
	PrintPreviewCol.setColor(%CBcb);
	BrickPreview.mColor=%CBcb;
	$ColPrev.setColor(%CBcb);

	if(BrickSwatch.visible==1)
		$BriPrev.mColor=%CBcb;
}
function PTG_ColPriBri_GUI::Apply()
{
	PTG_ColPriBri_GUI::onColorSelect();
	PTG_ColPriBri_GUI::onPrintSelect();

	if(BrickSwatch.visible==1)
		PTG_ColPriBri_GUI::onBrickSelect();

	canvas.popDialog(PTG_ColPriBri_GUI);

	if(BrickList.getSelectedID() == -1)
		%Bri=NA;
	else
		%Bri = DataBlockGroup.getObject(BrickList.getSelectedID()).getName();

	if(PrintList.getSelectedID() == -1)
		%Pri=0;
	else
		%Pri = PrintList.getSelectedID();

	switch($case)
	{
		case 1:
			$ColBioLDet = $ColNum;
			$BriBioLDet = %Bri;
			$PriBioLDet = %Pri;
		case 2:
			$ColBioLDetb = $ColNum;
			$BriBioLDetb = %Bri;
			$PriBioLDetb = %Pri;
		case 3:
			$ColBioLDetc = $ColNum;
			$BriBioLDetc = %Bri;
			$PriBioLDetc = %Pri;
		case 4:
			$ColBioSDet = $ColNum;
			$BriBioSDet = %Bri;
			$PriBioSDet = %Pri;
		case 5:
			$ColBioSDetb = $ColNum;
			$BriBioSDetb = %Bri;
			$PriBioSDetb = %Pri;
		case 6:
			$ColBioSDetc = $ColNum;
			$BriBioSDetc = %Bri;
			$PriBioSDetc = %Pri;
		case 7:
			$ColBioMDet = $ColNum;
			$BriBioMDet = %Bri;
			$PriBioMDet = %Pri;
		case 8:
			$ColBioMDetb = $ColNum;
			$BriBioMDetb = %Bri;
			$PriBioMDetb = %Pri;
		case 9:
			$ColBioMDetc = $ColNum;
			$BriBioMDetc = %Bri;
			$PriBioMDetc = %Pri;
		case 10:
			$ColBio = $ColNum;
			$PriBio = %Pri;
		case 11:
			$ColBioDrt = $ColNum;
			$PriBioDrt = %Pri;
		case 12:
			$ColBioWat = $ColNum;
			$PriBioWat = %Pri;

		///////////////////

		case 13:
			$ColBiobLDet = $ColNum;
			$BriBiobLDet = %Bri;
			$PriBiobLDet = %Pri;
		case 14:
			$ColBiobLDetb = $ColNum;
			$BriBiobLDetb = %Bri;
			$PriBiobLDetb = %Pri;
		case 15:
			$ColBiobLDetc = $ColNum;
			$BriBiobLDetc = %Bri;
			$PriBiobLDetc = %Pri;
		case 16:
			$ColBiobSDet = $ColNum;
			$BriBiobSDet = %Bri;
			$PriBiobSDet = %Pri;
		case 17:
			$ColBiobSDetb = $ColNum;
			$BriBiobSDetb = %Bri;
			$PriBiobSDetb = %Pri;
		case 18:
			$ColBiobSDetc = $ColNum;
			$BriBiobSDetc = %Bri;
			$PriBiobSDetc = %Pri;
		case 19:
			$ColBiobMDet = $ColNum;
			$BriBiobMDet = %Bri;
			$PriBiobMDet = %Pri;
		case 20:
			$ColBiobMDetb = $ColNum;
			$BriBiobMDetb = %Bri;
			$PriBiobMDetb = %Pri;
		case 21:
			$ColBiobMDetc = $ColNum;
			$BriBiobMDetc = %Bri;
			$PriBiobMDetc = %Pri;
		case 22:
			$ColDirt = $ColNum;
			$PriDirt = %Pri;
		case 23:
			$ColDirtb = $ColNum;
			$PriDirtb = %Pri;
		case 24:
			$ColSand = $ColNum;
			$PriSand = %Pri;
		case 25:
			$ColStone = $ColNum;
			$PriStone = %Pri;
		case 26:
			$ColClouds = $ColNum;
			$PriClouds = %Pri;
		case 27:
			$ColBounds = $ColNum;
			$PriBounds = %Pri;

		///////////////////

		case 28:
			$ColBiocLDet = $ColNum;
			$BriBiocLDet = %Bri;
			$PriBiocLDet = %Pri;
			
		case 29:
			$ColBiocLDetb = $ColNum;
			$BriBiocLDetb = %Bri;
			$PriBiocLDetb = %Pri;
		case 30:
			$ColBiocLDetc = $ColNum;
			$BriBiocLDetc = %Bri;
			$PriBiocLDetc = %Pri;
		case 31:
			$ColBiocSDet = $ColNum;
			$BriBiocSDet = %Bri;
			$PriBiocSDet = %Pri;
		case 32:
			$ColBiocSDetb = $ColNum;
			$BriBiocSDetb = %Bri;
			$PriBiocSDetb = %Pri;
		case 33:
			$ColBiocSDetc = $ColNum;
			$BriBiocSDetc = %Bri;
			$PriBiocSDetc = %Pri;
		case 34:
			$ColBiocMDet = $ColNum;
			$BriBiocMDet = %Bri;
			$PriBiocMDet = %Pri;
		case 35:
			$ColBiocMDetb = $ColNum;
			$BriBiocMDetb = %Bri;
			$PriBiocMDetb = %Pri;
		case 36:
			$ColBiocMDetc = $ColNum;
			$BriBiocMDetc = %Bri;
			$PriBiocMDetc = %Pri;
		case 37:
			$ColBioc = $ColNum;
			$PriBioc = %Pri;
		case 38:
			$ColBiocDrt = $ColNum;
			$PriBiocDrt = %Pri;
		case 39:
			$ColBiocWat = $ColNum;
			$PriBiocWat = %Pri;

		///////////////////

		case 40:
			$ColBiodLDet = $ColNum;
			$BriBiodLDet = %Bri;
			$PriBiodLDet = %Pri;
		case 41:
			$ColBiodLDetb = $ColNum;
			$BriBiodLDetb = %Bri;
			$PriBiodLDetb = %Pri;
		case 42:
			$ColBiodLDetc = $ColNum;
			$BriBiodLDetc = %Bri;
			$PriBiodLDetc = %Pri;
		case 43:
			$ColBiodSDet = $ColNum;
			$BriBiodSDet = %Bri;
			$PriBiodSDet = %Pri;
		case 44:
			$ColBiodSDetb = $ColNum;
			$BriBiodSDetb = %Bri;
			$PriBiodSDetb = %Pri;
		case 45:
			$ColBiodSDetc = $ColNum;
			$BriBiodSDetc = %Bri;
			$PriBiodSDetc = %Pri;
		case 46:
			$ColBiodMDet = $ColNum;
			$BriBiodMDet = %Bri;
			$PriBiodMDet = %Pri;
		case 47:
			$ColBiodMDetb = $ColNum;
			$BriBiodMDetb = %Bri;
			$PriBiodMDetb = %Pri;
		case 48:
			$ColBiodMDetc = $ColNum;
			$BriBiodMDetc = %Bri;
			$PriBiodMDetc = %Pri;
		case 49:
			$ColBiod = $ColNum;
			$PriBiod = %Pri;
		case 50:
			$ColBiodDrt = $ColNum;
			$PriBiodDrt = %Pri;
		case 51:
			$ColBiodWat = $ColNum;
			$PriBiodWat = %Pri;

		///////////////////

		case 52:
			$ColBioeLDet = $ColNum;
			$BriBioeLDet = %Bri;
			$PriBioeLDet = %Pri;
		case 53:
			$ColBioeLDetb = $ColNum;
			$BriBioeLDetb = %Bri;
			$PriBioeLDetb = %Pri;
		case 54:
			$ColBioeLDetc = $ColNum;
			$BriBioeLDetc = %Bri;
			$PriBioeLDetc = %Pri;
		case 55:
			$ColBioeSDet = $ColNum;
			$BriBioeSDet = %Bri;
			$PriBioeSDet = %Pri;
		case 56:
			$ColBioeSDetb = $ColNum;
			$BriBioeSDetb = %Bri;
			$PriBioeSDetb = %Pri;
		case 57:
			$ColBioeSDetc = $ColNum;
			$BriBioeSDetc = %Bri;
			$PriBioeSDetc = %Pri;
		case 58:
			$ColBioeMDet = $ColNum;
			$BriBioeMDet = %Bri;
			$PriBioeMDet = %Pri;
		case 59:
			$ColBioeMDetb = $ColNum;
			$BriBioeMDetb = %Bri;
			$PriBioeMDetb = %Pri;
		case 60:
			$ColBioeMDetc = $ColNum;
			$BriBioeMDetc = %Bri;
			$PriBioeMDetc = %Pri;
		case 61:
			$ColBioe = $ColNum;
			$PriBioe = %Pri;
		case 62:
			$ColBioeDrt = $ColNum;
			$PriBioeDrt = %Pri;
		case 63:
			$ColBioeWat = $ColNum;
			$PriBioeWat = %Pri;

		///////////////////

		case 64:
			$ColBiofLDet = $ColNum;
			$BriBiofLDet = %Bri;
			$PriBiofLDet = %Pri;
		case 65:
			$ColBiofLDetb = $ColNum;
			$BriBiofLDetb = %Bri;
			$PriBiofLDetb = %Pri;
		case 66:
			$ColBiofLDetc = $ColNum;
			$BriBiofLDetc = %Bri;
			$PriBiofLDetc = %Pri;
		case 67:
			$ColBiofSDet = $ColNum;
			$BriBiofSDet = %Bri;
			$PriBiofSDet = %Pri;
		case 68:
			$ColBiofSDetb = $ColNum;
			$BriBiofSDetb = %Bri;
			$PriBiofSDetb = %Pri;
		case 69:
			$ColBiofSDetc = $ColNum;
			$BriBiofSDetc = %Bri;
			$PriBiofSDetc = %Pri;
		case 70:
			$ColBiofMDet = $ColNum;
			$BriBiofMDet = %Bri;
			$PriBiofMDet = %Pri;
		case 71:
			$ColBiofMDetb = $ColNum;
			$BriBiofMDetb = %Bri;
			$PriBiofMDetb = %Pri;
		case 72:
			$ColBiofMDetc = $ColNum;
			$BriBiofMDetc = %Bri;
			$PriBiofMDetc = %Pri;

		default:
	}
	deleteVariables("$case");
}

//Generates a random seed, avoiding scientific notation and Int length < 10
function PTG_GUI_GetRandomSeed()
{
	$Sd = getRandom(10000,99999);
	$Sd = $Sd @ getRandom(10000,99999);
	canvas.popDialog(PTG_MainMenu_GUI);
	canvas.pushDialog(PTG_MainMenu_GUI);
}

//Uses a player's position for Grid Start X and Y
function PTG_GUI_GetPlyrPos()
{
	%sop = serverConnection.getControlObject().getTransform(); //fix???
	$GSx = (mFloor(getword(%sop, 0) / $ChS)) * $ChS;
	$GSy = (mFloor(getword(%sop, 1) / $ChS)) * $ChS;
	canvas.popDialog(PTG_MainMenu_GUI);
	canvas.pushDialog(PTG_MainMenu_GUI);
}

//Increment/Decrement Chunk (Grid End Pos X & Y)
function PTG_GUI_IncDecChunkXY(%case)
{
	switch(%case)
	{
		case 1:
			$GEx = $GEx + $Chs;
		case 2:
			$GEy = $GEy + $Chs;
		case 3:
			$GEx = $GEx - $Chs;
		case 4:
			$GEy = $GEy - $Chs;
		default:
			$GEx = $GEx;$GEy = $GEy;
	}
	canvas.popDialog(PTG_MainMenu_GUI);
	canvas.pushDialog(PTG_MainMenu_GUI);
}

//Terrain Type Radio
function PTG_GUI_TerRadio(%case)
{
	switch(%case)
	{
		case 1:
			$Norm=1;$Plai=0;$FloI=0;
		case 2:
			$Norm=0;$Plai=1;$FloI=0;
		case 3:
			$Norm=0;$Plai=0;$FloI=1;
		default:
			$Norm=1;$Plai=0;$FloI=0;
	}
}

//Smoothing Type Radio
function PTG_GUI_SmoothingCoRadio(%case)
{
	switch(%case)
	{
		case 1:
			$SCSm=1;$DSCSm=0;
		case 2:
			$SCSm=0;$DSCSm=1;
		case 3:
			$SCSm=0;$DSCSm=0;
		default:
			$SCSm=1;$DSCSm=0;
	}
}

//Variable Adjustments and Interference Checks
function PTG_GUI_IntStartRoutine_Relay(%client)
{
	if($Server::Lan)
	{
		if(%client.bl_id!=999999 && !%client.isSuperAdmin)
		{
			MessageBoxOK("PTG: ACCESS DENIED","You are not allowed to start a routine.");
			return;
		}
		$cl=%client;
		$clBG = "BrickGroup_999999";
	}
	if(!$Server::Lan)
	{
		if(%client.bl_id!=getNumKeyID() && !%client.isSuperAdmin)
		{
			MessageBoxOK("PTG: ACCESS DENIED","You are not allowed to start a routine.");
			return;
		}
		$cl= %client;
		%clBLID = $cl.bl_id;
		$clBG = "BrickGroup_" @ %clBLID;
	}
	if($Start==1)
	{
		MessageBoxOK("PTG: ERROR","Routine already started!");
		return;
	}
	$ChStf = $ChS*0.75;
	$ChSoh = $ChS*0.5;
	$ChSof = $ChS*0.25;
	$TerSS = $TerSS*$ChS;
	$BioSS = $BioSS*$ChS;
	$ChBD = $ChBD*1000;
	$DRot = "0 0 1 0";

	$GSx = (mFloatLength(($GSx/$ChS),0))*$ChS;
	$GSy = (mFloatLength(($GSy/$ChS),0))*$ChS;
	$GEx = (mFloatLength(($GEx/$ChS),0))*$ChS;
	$GEy = (mFloatLength(($GEy/$ChS),0))*$ChS;

	if($UseSd==0)
	{
		if(($GSx || $GSy)!=0)
		{
			canvas.popDialog(PTG_MainMenu_GUI);
			canvas.pushDialog(PTG_MainMenu_GUI); //Refreshes GUI due to issues with variables otherwise
			MessageBoxOK("PTG: ERROR","When using custom height values, Grid Start X & Y must be = to 0.");
			return;
		}
		if(($GEx<=0 || $GEx>($ChS*15)) || ($GEy<=0 || $GEy>($ChS*15)))
		{
			canvas.popDialog(PTG_MainMenu_GUI);
			canvas.pushDialog(PTG_MainMenu_GUI);
			MessageBoxOK("PTG: ERROR","When using custom height values, Grid End X & Y must be > 0 and <= 15 Chunks (or the Chunk Size * 15).");
			return;
		}
	}

	if($GEx<=$GSx || $GEy<=$GSy)
	{
		canvas.popDialog(PTG_MainMenu_GUI);
		canvas.pushDialog(PTG_MainMenu_GUI);
		MessageBoxOK("PTG: ERROR","Grid Start must be < Grid End.");
		return;
	}
	if($FloI==1 && ($SanL>0 || $WatL>0))
	{
		canvas.popDialog(PTG_MainMenu_GUI);
		canvas.pushDialog(PTG_MainMenu_GUI);
		MessageBoxOK("PTG: ERROR","Please set the Sand and Water Levels to 0 when generating Floating Islands.");
		return;
	}
	if($PrevPass==1)
	{
		PrevList.clear();
		PrevList.Extent = (($GEx-$GSx)*2) @ " " @ (($GEy-$GSy)*2);
		canvas.pushDialog(PTG_Preview_GUI);
	}
	if($PrevPass!=1)
	{
		if($ModTer==1)
		{
			if($AddOn__Brick_ModTer_4xPack==-1)
			{
				canvas.popDialog(PTG_MainMenu_GUI);
				canvas.pushDialog(PTG_MainMenu_GUI);
				MessageBoxOK("PTG: ERROR","Brick_ModTer_4xPack is not enabled! Make sure you have downloaded and enabled the Add-On before generating Modular Terrain, or disable the Modular Terrain option to use Large Cube bricks instead.");
				return;
			}
			if($PlaC==1)
			{
				canvas.popDialog(PTG_MainMenu_GUI);
				canvas.pushDialog(PTG_MainMenu_GUI);
				MessageBoxOK("PTG: ERROR","Please disable Plate-Capping when using the Modular Terrain option.");
				return;
			}
			if($TerHS!=1 && $TerHS!=2)
			{
				canvas.popDialog(PTG_MainMenu_GUI);
				canvas.pushDialog(PTG_MainMenu_GUI);
				MessageBoxOK("PTG: ERROR","Please set the Terrain Z-Scale to either 1 or 2 when using the Modular Terrain option.");
				return;
			}
			$FxCB = brick4Cube1Data;
			$STxCB = brick16Cube1PTGMTData;
			$WtB = brick32wPTGMTData;
		}
		if($ModTer==0)
		{
			if($AddOn__Brick_Large_Cubes==-1)
			{
				canvas.popDialog(PTG_MainMenu_GUI);
				canvas.pushDialog(PTG_MainMenu_GUI);
				MessageBoxOK("PTG: ERROR","Brick_Large_Cubes is not enabled! Make sure you have enabled the Add-On before generating terrain, or enable the Modular Terrain option instead.");
				return;
			}
			$FxCB = brick4xCubeData;
			$STxCB = brick16xCubeData;
			$WtB = brick32xWaterData;
		}
		if($GFill==1)
		{
			if($SolG==0)
			{
				canvas.popDialog(PTG_MainMenu_GUI);
				canvas.pushDialog(PTG_MainMenu_GUI);
				MessageBoxOK("PTG: ERROR","Please enable Solid Ground when using the Ground Gap-Filling option.");
				return;
			}
			if($TerHS==1 || $TerHS==2)
			{
				canvas.popDialog(PTG_MainMenu_GUI);
				canvas.pushDialog(PTG_MainMenu_GUI);
				MessageBoxOK("PTG: ERROR","Ground Gap-Filling is not necessary when Terrain Z-Scale is set to a value of either 1 or 2.");
				return;
			}
		}
		%clN=$cl.Name;

		if($MTPass==0 && $PrevPass!=1)
			messageAll('',"PTG: Routine Started By " @ %clN);
	}
	$TerHS = $TerHS*2;

	PTG_GUI_StartRoutine();
}

//Preview Terrain (ServerCmd to grab %client)
function PreviewPTG() 
{
	if($Start==1)
	{
		MessageBoxOK("PTG: ERROR","You can't preview terrain while routine is running.");
		return;
	}
	canvas.popDialog(PTG_MainMenu_GUI);
	canvas.pushDialog(PTG_MainMenu_GUI);

	$PrevPass=1;
	
	commandToServer('PTG_GUI_IntStartRoutine');
}

function Restore_PTG_MainMenu_GUI()
{
	if($Start==1)
		MessageBoxOK("PTG: ERROR","Main Menu is disabled while terrain is being generated.");
	else
	{
		canvas.popDialog(PTG_TempMainMenu_GUI);
		canvas.pushDialog(PTG_MainMenu_GUI);
	}
}