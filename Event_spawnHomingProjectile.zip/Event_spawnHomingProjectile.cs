registerOutputEvent(fxDTSBrick,spawnHomingProjectile,"list ActivePlayer 0 ClosestPlayer 1 ClosestBot 2 ClosestVehicle 3 ClosestEnemy 4" TAB "dataBlock ProjectileData" TAB "vector" TAB "float 0 2 0.1 1",1);
function fxDTSBrick::spawnHomingProjectile(%this,%target,%projectile,%spread,%scaleFactor,%client)
{
	if(%this.isDead() || %this.isFakeDead() || !%this.isRaycasting())
		return;
	
	if(!isObject(%projectile) || %projectile.getClassName() !$= "ProjectileData")
		return;
	
	%center = %this.getWorldBoxCenter();
	%x = (%this.dataBlock.brickSizeX * 0.5 / 2) - 0.5;
	%y = (%this.dataBlock.brickSizeY * 0.5 / 2) - 0.5;
	%z = (%this.dataBlock.brickSizeZ * 0.2 / 2) - 0.5;
	
	%x = (%x > 0 ? %x : 0);
	%y = (%y > 0 ? %y : 0);
	%z = (%z > 0 ? %z : 0);
	
	%x = %x - (%x * getRandom() * 2);
	%y = %y - (%y * getRandom() * 2);
	%z = %z - (%z * getRandom() * 2);
	
	%v = %x SPC %y SPC %z;
	
	%start = vectorAdd(%center,%v);
	
	%obj = -1;
	switch(%target)
	{
		case 0:
			if(isObject(%client.player))
			{
				%obj = %client.player;
				%pos = %obj.getHackPosition();
			}
				
		
		case 1:
			%minDist = 1000;
			initContainerRadiusSearch(%start,60,$TypeMasks::PlayerObjectType);
			while(isObject(firstWord(%searchObj = containerSearchNext())))
			{
				if((miniGameCanDamage(%client,%searchObj) || (!isObject(%client.minigame) && %client == %searchObj.client)) && %searchObj.getClassName() $= "Player")
				{
					%d = vectorDist(%start,%searchObj.getHackPosition());
					if(%d < %minDist)
					{
						%minDist = %d;
						%obj = %searchObj;
						%pos = %obj.getHackPosition();
					}
				}
			}
		
		case 2:
			%minDist = 1000;
			initContainerRadiusSearch(%start,60,$TypeMasks::PlayerObjectType);
			while(isObject(firstWord(%searchObj = containerSearchNext())))
			{
				if((miniGameCanDamage(%client,%searchObj) || (!isObject(%client.minigame) && %client == %searchObj.client)) && %searchObj.getClassName() $= "AIPlayer")
				{
					%d = vectorDist(%start,%searchObj.getHackPosition());
					if(%d < %minDist)
					{
						%minDist = %d;
						%obj = %searchObj;
						%pos = %obj.getHackPosition();
					}
				}
			}
		
		case 3:
			%minDist = 1000;
			initContainerRadiusSearch(%start,60,$TypeMasks::VehicleObjectType);
			while(isObject(firstWord(%searchObj = containerSearchNext())))
			{
				if(miniGameCanDamage(%client,%searchObj) && %searchObj.getDamageLevel() < %searchObj.dataBlock.maxDamage)
				{
					%d = vectorDist(%start,%searchObj.getWorldBoxCenter());
					if(%d < %minDist)
					{
						%minDist = %d;
						%obj = %searchObj;
						%pos = %obj.getWorldBoxCenter();
					}
				}
			}
		
		case 4:
			%minDist = 1000;
			initContainerRadiusSearch(%start,60,$TypeMasks::PlayerObjectType);
			while(isObject(firstWord(%searchObj = containerSearchNext())))
			{
				if((miniGameCanDamage(%client,%searchObj)))
				{
					if(%client == %searchObj.client)
						continue;
					
					if(%client.minigame.EnableZombies && $pref::Server::ZombiesEnabled)
					{
						if(isObject(GameModeStorerSO) && %client.tdmTeam == %searchObj.client.tdmTeam)
							continue;
						
						if(%searchObj.isZombie && %searchObj.getdatablock().isgoodguy)
							continue;
					}
					else if(isObject(GameModeStorerSO) && %client.tdmTeam == %searchObj.client.tdmTeam && %searchObj.client.tdmTeam != -1)
						continue;
					
					%d = vectorDist(%start,%searchObj.getHackPosition());
					if(%d < %minDist)
					{
						%minDist = %d;
						%obj = %searchObj;
						%pos = %obj.getHackPosition();
					}
				}
			}
		
		default:
			return;
	}
	
	if(!isObject(%obj))
		return;
	
	%x = getWord(%spread,0);
	%y = getWord(%spread,1);
	%z = getWord(%spread,2);
	
	%x = %x - (%x * getRandom() * 2);
	%y = %y - (%y * getRandom() * 2);
	%z = %z - (%z * getRandom() * 2);
	
	%random = %x SPC %y SPC %z;
	
	if(%this.lastFireHomingObject == %obj && (getSimTime() - %this.lastFireHomingTime) < 1000)
	{
		%delta = vectorSub(%obj.getVelocity(),%this.lastFireHomingVel);
		%accl = vectorScale(%delta,100/(getSimTime() - %this.lastFireHomingTime));
	}
	else
	{
		%accl = 0;
	}
	
	%end = %pos;
	%vec = getProjectileAimVector(%start,%end,%projectile);
	
	//Approximate the travel time. This assumes that the time to the adjusted point is the same as the time to the object position
	//... which it isn't. If you're moving slowly it shouldn't make much of a difference.
	for(%i=0;%i<5;%i++)
	{
		%t = vectorDist(%start,%end) / vectorLen(vectorScale(getWord(%vec,0) SPC getWord(%vec,1),%projectile.muzzleVelocity));
		%velaccl = vectorScale(%accl,%t);
		
		%x = getword(%velaccl,0);
		%y = getword(%velaccl,1);
		%z = getWord(%velaccl,2);
		
		%x = (%x < 0 ? 0 : %x);
		%y = (%y < 0 ? 0 : %y);
		%z = (%z < 0 ? 0 : %z);
		
		%vel = vectorAdd(vectorScale(%obj.getVelocity(),%t),%x SPC %y SPC %z);
		%end = vectorAdd(%pos,%vel);
		%vec = getProjectileAimVector(%start,%end,%projectile);
	}	
	
	%vel = vectorAdd(vectorScale(%vec,%projectile.muzzleVelocity),%random);
	
	%this.lastFireHomingObject  = %obj;
	%this.lastFireHomingTime    = getSimTime();
	%this.lastFireHomingVel     = %obj.getVelocity();
	
	//I can't use ::spawnProjectile to create it because the start place might be different on a non-1x1 brick
	
	%p = new Projectile()
	{
		dataBlock = %projectile;
		initialPosition = %start;
		initialVelocity = %vel;
		sourceObject = %this;
		client = %client;
		sourceClient = %client;
		sourceSlot = 0;
		originPoint = %start;
	};
	
	//Projectile quota
	if(!isObject(%p))
		return;
	
	MissionCleanup.add(%p);
	%p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
}