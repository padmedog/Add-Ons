registerInputEvent(fxDTSBrick,onRapidActivate,"Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame Minigame");

package rapidActivate
{
	function player::activateStuff(%a)
	{
		parent::activateStuff(%a);
		%player = %a;
		if(%player.activatelevel >= 5)
		{
			%player.rapidActivateStuff();
		}
	}
};activatePackage(rapidActivate);

function player::rapidActivateStuff(%player)
{
		%client = %player.client;
		%EyeVector = %player.getEyeVector();
		%EyePoint = %player.getEyePoint();
		%Range = 6;
		%RangeScale = VectorScale(%EyeVector, %Range);
		%RangeEnd = VectorAdd(%EyePoint, %RangeScale);
		%raycast = containerRayCast(%eyePoint,%RangeEnd,$TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::FxBrickObjectType, %player);

		if(isObject(%rayCast))
		{
			%brick = %raycast;
  			$InputTarget_["Self"]   = %brick;
  			$InputTarget_["Player"] = %client.player;
   			$InputTarget_["Client"] = %client;
     			if(getMiniGameFromObject(%brick) == getMiniGameFromObject(%client))
         			$InputTarget_["MiniGame"] = getMiniGameFromObject(%brick);
      			else
         			$InputTarget_["MiniGame"] = 0;

 		  	%brick.processInputEvent(onRapidActivate,%client);
		}
}