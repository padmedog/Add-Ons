$NewtonCamera::Force = 400; // 100
$NewtonCamera::Mass = 10;
$NewtonCamera::Drag = 5; // 2



// BEGIN PARTS ADDED BY EKSI :D

if(!$newtCamBind)
{
	$remapDivision[$remapCount] = "Newtonian Camera Movement";

	$remapName[$remapCount] = "Toggle";
	$remapCmd[$remapCount] = "toggleNewtonianCamera";
	$remapCount++;

	$remapName[$remapCount] = "Reset drag (5)";
	$remapCmd[$remapCount] = "resDragNC";
	$remapCount++;

	$remapName[$remapCount] = "Increase drag";
	$remapCmd[$remapCount] = "incDragNC";
	$remapCount++;

	$remapName[$remapCount] = "Decrease drag";
	$remapCmd[$remapCount] = "decDragNC";
	$remapCount++;

	$remapName[$remapCount] = "Reset mass (10)";
	$remapCmd[$remapCount] = "resMassNC";
	$remapCount++;

	$remapName[$remapCount] = "Increase mass";
	$remapCmd[$remapCount] = "incMassNC";
	$remapCount++;

	$remapName[$remapCount] = "Decrease mass";
	$remapCmd[$remapCount] = "decMassNC";
	$remapCount++;

	$remapName[$remapCount] = "Reset force (400)";
	$remapCmd[$remapCount] = "resForceNC";
	$remapCount++;

	$remapName[$remapCount] = "Increase force";
	$remapCmd[$remapCount] = "incForceNC";
	$remapCount++;

	$remapName[$remapCount] = "Decrease force";
	$remapCmd[$remapCount] = "decForceNC";
	$remapCount++;

	$newtCamBind = true;
}

function toggleNewtonianCamera(%toggle)
{
	if(%toggle)
	{
		$NewtCamOff = !$NewtCamOff;
		if($NewtCamOff)
		{
			activatePackage("NewtonCamera");
			clientCmdBottomPrint("\c6Newtonian Camera \c2activated", 3);
		}
		else
		{
			deactivatePackage("NewtonCamera");
			clientCmdBottomPrint("\c6Newtonian Camera \c0deactivated", 3);
		}
	}
}

function resDragNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Drag = 5;
		clientCmdBottomPrint("\c6Newtonian Camera \c1DRAG SET TO\c3" SPC $NewtonCamera::Drag, 3);
	}
}

function incDragNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Drag++;
		dispNCDrag();
	}
}

function decDragNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Drag--;
		dispNCDrag();
	}
}

function dispNCDrag()
{
	if($NewtonCamera::Drag > 0)
	{
		clientCmdBottomPrint("\c6Newtonian Camera \c1DRAG =\c3" SPC $NewtonCamera::Drag,3);
	}
	else
	{
		clientCmdBottomPrint("\c6Newtonian Camera \c1DRAG =\c0" SPC $NewtonCamera::Drag,3);
	}
}




function resMassNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Mass = 10;
		clientCmdBottomPrint("\c6Newtonian Camera \c2MASS SET TO\c5" SPC $NewtonCamera::Mass, 3);
	}
}

function incMassNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Mass++;
		dispNCMass();
	}
}

function decMassNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Mass--;
		dispNCMass();
	}
}

function dispNCMass()
{
	if($NewtonCamera::Mass > 0)
	{
		clientCmdBottomPrint("\c6Newtonian Camera \c2MASS =\c5" SPC $NewtonCamera::Mass,3);
	}
	else
	{
		clientCmdBottomPrint("\c6Newtonian Camera \c2MASS =\c0" SPC $NewtonCamera::Mass,3);
	}
}





function resForceNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Force = 400;
		clientCmdBottomPrint("\c6Newtonian Camera \c0FORCE SET TO\c4" SPC $NewtonCamera::Force, 3);
	}
}

function incForceNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Force += 10;
		dispNCForce();
	}
}

function decForceNC(%toggle)
{
	if(%toggle)
	{
		$NewtonCamera::Force -= 10;
		dispNCForce();
	}
}

function dispNCForce()
{
	if($NewtonCamera::Force > 0)
	{
		clientCmdBottomPrint("\c6Newtonian Camera \c0FORCE =\c4" SPC $NewtonCamera::Force,3);
	}
	else
	{
		clientCmdBottomPrint("\c6Newtonian Camera \c0FORCE =\c0" SPC $NewtonCamera::Force,3);
	}
}


//END PARTS ADDED BY EKSI, BEGIN THE ACTUALLY REALLY IMPORTANT PARTS MADE BY PORT

 
function updateNewtonCamera(%vx, %vy)
{
	cancel($updateNewtonCamera);
	%delta = 16 / 1000;
 
	%force = $NewtonCamera::Force;
	%mass = $NewtonCamera::Mass;
	%drag = $NewtonCamera::Drag;
 
	%vx += (ServerConnection.cameraBufferX * %force / %mass) * %drag * %delta;
	%vy += (ServerConnection.cameraBufferY * %force / %mass) * %drag * %delta;
 
	ServerConnection.cameraBufferX = 0;
	ServerConnection.cameraBufferY = 0;
 
	%vx -= %vx * %drag * %delta;
	%vy -= %vy * %drag * %delta;
 
	$mvYaw = %vx * %delta;
	$mvPitch = %vy * %delta;
 
	if (mAbs(%vx) >= 0.0001 || mAbs(%vy) >= 0.0001)
	{
		$updateNewtonCamera = schedule(16, 0, updateNewtonCamera, %vx, %vy);
	}
}
 
package NewtonCamera
{
	function yaw(%n)
	{
		%mvYaw = $mvYaw;
		Parent::yaw(%n);
 
		if (!isObject(ServerConnection))
		{
			return;
		}
 
		ServerConnection.cameraBufferX += $mvYaw - %mvYaw;
		$mvYaw = %mvYaw;
 
		if (!isEventPending($updateNewtonCamera))
		{
			updateNewtonCamera(0, 0);
		}
	}
 
	function pitch(%n)
	{
		%mvPitch = $mvPitch;
		Parent::pitch(%n);
 
		if (!isObject(ServerConnection))
		{
			return;
		}
 
		ServerConnection.cameraBufferY += $mvPitch - %mvPitch;
		$mvPitch = %mvPitch;
 
		if (!isEventPending($updateNewtonCamera))
		{
			updateNewtonCamera(0, 0);
		}
	}
};
 
//activatePackage("NewtonCamera");