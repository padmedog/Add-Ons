//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier2a");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Skins_LMG- required add-on Weapon_Package_Tier2a not found");
}
else
{
   exec("./Weapon_drumlmg.cs");
   exec("./Weapon_modernlmg.cs");
}
