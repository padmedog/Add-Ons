$remapDivision[$remapCount] = "Dynamic FOV";
$remapName[$remapCount] = "Toggle Dynamic FOV";
$remapCmd[$remapCount] = "toggleDynamicFOV";
$remapName[$remapCount++] = "Increase Intensity";
$remapCmd[$remapCount] = "IncreaseDynamicFOV";
$remapName[$remapCount++] = "Decrease Intensity";
$remapCmd[$remapCount] = "DecreaseDynamicFOV";
$remapName[$remapCount++] = "Increase Max FOV";
$remapCmd[$remapCount] = "IncreaseMaxFOV";
$remapName[$remapCount++] = "Decrease Max FOV";
$remapCmd[$remapCount] = "DecreaseMaxFOV";
$remapCount++;
$DynamicFOV::Itensity = 1;
$DynamicFOV::TickRate = 33;
$DynamicFOV::MaxFOV = 135;
$DynamicFOV::ModeName0="Off";
$DynamicFOV::ModeName1="On";
$DynamicFOV::ModeName2="Automatic";
function ToggleDynamicFov(%toggle)
{
	if(%toggle)
	{
		$DynamicFOV::Mode++;
		if($DynamicFOV::Mode > 2)
			$DynamicFOV::Mode=0;
		DynamicFOVTick($DynamicFOV::Mode);
		clientCmdBottomPrint("\c0Dynamic FOV: \c3"@ $DynamicFOV::ModeName[$DynamicFOV::Mode] @"<just:right>\c0Current FOV: \c3"@ mFloor($DynamicFOV::CurrentFOV),3);
	}
}
function IncreaseDynamicFov(%toggle)
{
	if(%toggle && $DynamicFOV::Itensity<2)
		$DynamicFOV::Itensity+=0.1;
	DynamicFOVTick(1);
	clientCmdBottomPrint("\c0Intensity: \c3"@ $DynamicFOV::Itensity @"x<just:right>\c0Current FOV: \c3"@ mFloor($DynamicFOV::CurrentFOV),3);
}
function DecreaseDynamicFov(%toggle)
{
	if(%toggle && $DynamicFOV::Itensity>0.5)
		$DynamicFOV::Itensity-=0.1;
	DynamicFOVTick(1);
	clientCmdBottomPrint("\c0Intensity: \c3"@ $DynamicFOV::Itensity @"x<just:right>\c0Current FOV: \c3"@ mFloor($DynamicFOV::CurrentFOV),3);
}
function IncreaseMaxFov(%toggle)
{
	if(%toggle && $DynamicFOV::MaxFOV<150)
		$DynamicFOV::MaxFOV++;
	DynamicFOVTick(1);
	clientCmdBottomPrint("\c0Max FOV: \c3"@ $DynamicFOV::MaxFOV @"<just:right>\c0Current FOV: \c3"@ mFloor($DynamicFOV::CurrentFOV),3);
}
function DecreaseMaxFov(%toggle)
{
	if(%toggle && $DynamicFOV::MaxFOV>100)
		$DynamicFOV::MaxFOV--;
	DynamicFOVTick(1);
	clientCmdBottomPrint("\c0Max FOV: \c3"@ $DynamicFOV::MaxFOV @"<just:right>\c0Current FOV: \c3"@ mFloor($DynamicFOV::CurrentFOV),3);
}
function RestoreDefaultFOV()
{
	clientCmdSetVignette($DynamicFOV::VignetteMultiply,$DynamicFOV::VignetteColor);
	if($DynamicFOV::CurrentFOV != $pref::Player::defaultFov && !$DynamicFOV::Zooming)
	{
		setFov($pref::Player::defaultFov);
		$DynamicFOV::CurrentFOV = $pref::Player::defaultFov;
	}
}
function DynamicFOVTick(%enable)
{
	cancel($DynamicFOV::Tick);
	if(isObject(ServerConnection) && %enable)
	{
		if(isObject(%player = ServerConnection.getControlObject()) && !$DynamicFOV::Zooming)
		{
			if($DynamicFOV::Mode == 1)
			{
				$DynamicFOV::Velocity = vectorLen(%player.getVelocity());
				$DynamicFOV::CurrentFOV = $pref::Player::defaultFov+$DynamicFOV::Velocity*$DynamicFOV::Itensity;
				if($DynamicFOV::CurrentFOV > $DynamicFOV::MaxFOV)
					$DynamicFOV::CurrentFOV = $DynamicFOV::MaxFOV;
				PlayGUI_Vignette.mColor = "0 0 0"SPC (($DynamicFOV::CurrentFOV-$pref::Player::defaultFov)/($DynamicFOV::MaxFOV-$pref::Player::defaultFov))*255;
				if(isObject(PlayGUI_Vignette2))
					PlayGUI_Vignette2.mColor = "0 0 0"SPC (($DynamicFOV::CurrentFOV-$pref::Player::defaultFov)/($DynamicFOV::MaxFOV-$pref::Player::defaultFov))*255;
				SetFOV($DynamicFOV::CurrentFOV);
			}
			else
			{
				if(amIdrivingAvehicle())
				{
					$DynamicFOV::Velocity = vectorLen(%player.getVelocity());
					$DynamicFOV::CurrentFOV = $pref::Player::defaultFov+$DynamicFOV::Velocity*$DynamicFOV::Itensity;
					if($DynamicFOV::CurrentFOV > $DynamicFOV::MaxFOV)
						$DynamicFOV::CurrentFOV = $DynamicFOV::MaxFOV;
					PlayGUI_Vignette.mColor = "0 0 0"SPC (($DynamicFOV::CurrentFOV-$pref::Player::defaultFov)/($DynamicFOV::MaxFOV-$pref::Player::defaultFov))*255;
					if(isObject(PlayGUI_Vignette2))
						PlayGUI_Vignette2.mColor = "0 0 0"SPC (($DynamicFOV::CurrentFOV-$pref::Player::defaultFov)/($DynamicFOV::MaxFOV-$pref::Player::defaultFov))*255;
					SetFOV($DynamicFOV::CurrentFOV);
				}
				else
					restoreDefaultFOV();
			}
		}
		$DynamicFOV::Tick = schedule($DynamicFOV::TickRate, 0, "DynamicFOVTick",%enable);
	}
	else
		restoreDefaultFOV();
}
package DynamicFOV
{
	function clientCmdSetVignette(%multiply, %color)
	{
		parent::ClientCmdSetVignette(%multiply, %color);
		$DynamicFOV::VignetteColor = %color;
		$DynamicFOV::VignetteMultiply = %multiply;
	}
	function ToggleZoom(%toggle)
	{
		parent::ToggleZoom(%toggle);
		$DynamicFOV::Zooming = %toggle;
	}
};
activatePackage(DynamicFOV);