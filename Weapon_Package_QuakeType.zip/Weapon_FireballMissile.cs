//fireballMissile.cs

datablock AudioProfile(fireballMissileFireSound)
{
   filename    = "./flare_missile2.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ExplosionData(fireballMissileExplosion : quakeMisStormExplosion)
{
   debris = "";
   emitter[2] = afterburnEmitter;
};

datablock ParticleData(fireballMissileParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 95;
	lifetimeVarianceMS   = 85;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 16.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.8 0.8 0.8 0.7";
	colors[1]     = "0.9 0.6 0.3 0.3";
	colors[2]     = "0.9 0.3 0.1 0.4";
	colors[3]     = "0.9 0.3 0.1 0.5";
	colors[4]     = "0.9 0.3 0.1 0";
	sizes[0]      = 0.05;
	sizes[1]      = 1.3;
	sizes[2]      = 0.65;
	sizes[3]      = 0.2;
	sizes[4]      = 0;
   times[0] = 0.0;
   times[1] = 0.3;
   times[2] = 0.8;
   times[3] = 0.9;
   times[4] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(fireballMissileEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 8.0;
   ejectionOffset   = 0.5;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "fireballMissileParticle";
};
AddDamageType("fireballMissile",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_burnmortar> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_burnmortar> %1',0.05,1);
datablock ProjectileData(fireballMissileProjectile)
{
   projectileShapeName = "./quake_grenade.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::fireballMissile;
   radiusDamageType    = $DamageType::fireballMissile;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1000;
   verticalImpulse	  = 1000;
   explosion           = fireballMissileExplosion;
   particleEmitter     = fireballMissileEmitter;

   explodeOnPlayerImpact = false;
   explodeondeath = true;

   muzzleVelocity      = 75;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.999;
   bounceFriction      = 0.0;
   isBallistic         = true;
   gravityMod = 1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(fireballMissileItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./fireball_launcher.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Burn Mortar";
	iconName = "./burnmortar";
	doColorShift = true;
	colorShiftColor = "0.24 0.22 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = fireballMissileImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(fireballMissileImage)
{
   // Basic Item properties
	shapeFile = "./fireball_launcher.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 -0.04";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = fireballMissileProjectile;
   projectileType = Projectile;

	casing = nitrostreamJetDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 -0.5 0.2";
	shellExitVariance   = 7.0;	
	shellVelocity       = 14.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = fireballMissileItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.15;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakerocketFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= fireballMissileFireSound;
	stateEjectShell[2]       = true;

	stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.15;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Fire";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.01;
	stateTransitionOnTimeout[5]     = "Wait";
	stateSound[5]					= sawbladeRifleClickSound;

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.48;
	stateTransitionOnTimeout[6]     = "Ready";
};

function fireballMissileImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, plant);

	%projectile = fireballMissileProjectile;
	%spread = 0.00015;
	%shellcount = 1;

  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
   //%obj.setImageTrigger(1,1);
}

function fireballMissileImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, plant);	
}


function fireballMissileProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 10;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {     
      %col.damage(%obj, %pos, %directDamage, %damageType);
	%col.mountImage(afterburnImage, 2);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}
