//audio
datablock AudioProfile(LasrifleFireSound)
{
   filename    = "./lasrifleshot.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(LasrifleTrailParticle)
{
	dragCoefficient		= 0.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0625;
	constantAcceleration	= 0.0;
	lifetimeMS		= 240;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 0.25 0 1";
	colors[1]	= "1 0.5 0.25 1";
	sizes[0]	= 0.2;
	sizes[1]	= 0.15;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(LasrifleTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = LasrifleTrailParticle;

   useEmitterColors = true;
};

datablock ParticleData(LasrifleExplosionParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 125;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1.0 0.25 0.0 1";
	colors[1]     = "1.0 0.75 0.5 0.0";
	sizes[0]      = 0.5;
	sizes[1]      = 0.125;

	useInvAlpha = false;
};
datablock ParticleEmitterData(LasrifleExplosionEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "LasrifleExplosionParticle";

   useEmitterColors = false;
   uiName = "Lasgun Hit Dust";
};

datablock ParticleData(LasrifleExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 50;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1.0 0.25 0.0 1";
	colors[1]     = "1.0 0.5 0.25 0.0";
	sizes[0]      = 0.75;
	sizes[1]      = 1.5;

	useInvAlpha = false;
};
datablock ParticleEmitterData(LasrifleExplosionRingEmitter)
{
	lifeTimeMS = 200;

   ejectionPeriodMS = 12;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "LasrifleExplosionRingParticle";

   useEmitterColors = true;
   uiName = "Lasgun Hit Flash";
};

datablock ExplosionData(LasrifleExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 100;

   particleEmitter = LasrifleExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = LasrifleExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.25;
   camShakeRadius = 1.25;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "1.0 0.5 0.25";
   lightEndColor = "0 0 0";
};

datablock ProjectileData(LasrifleTracerProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 100;
   verticalImpulse	  = 50;
//   explosion           = LasrifleExplosion;
   particleEmitter     = "LasrifleTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 1000;
   fadeDelay           = 700;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "1 0.25 0";
};

datablock ProjectileData(LasrifleExplosionProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 100;
   verticalImpulse	  = 50;
   explosion           = LasrifleExplosion;
   particleEmitter     = "LasrifleTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 1000;
   fadeDelay           = 700;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(LasrifleItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Lasrifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Lasgun";
	iconName = "./Lasgun";
	doColorShift = false;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = LasrifleImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 50;
	canReload = 1;
};

AddDamageType("Lasrifle",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Lasgun> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Lasgun> %1',0.75,1);

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(LasrifleImage)
{

   // Basic Item properties
	shapeFile = "./Lasrifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = LasrifleItem;
   ammo = " ";
   projectile = LasrifleTracerProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = LasrifleItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 400; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = LasrifleExplosionProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 17; //10
   raycastDirectDamageType = $DamageType::Lasrifle;
   raycastSpreadAmt = 0.0006; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = LasrifleTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= LasriflefireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[2]              = false;
	stateTimeoutValue[4]		= 0.13;
	stateScript[4]                  = "onBounce";
	stateTransitionOnTimeout[4]	= "Ready";
	
};

function LasrifleImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0036;
		%this.raycastWeaponRange = 400;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0005;
		%this.raycastWeaponRange = 400;
	}
	
		Parent::onFire(%this,%obj,%slot);
	%obj.playThread(2, plant);	
}

