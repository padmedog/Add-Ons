if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
	{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/Hooks/ServerControl.cs");
	RTB_registerPref("Enabled","Drop Item On Damage","$Swollow::DropItemOnDamage","bool","Server_DropItemOnDamage",1,0,0);
	RTB_registerPref("MinRand","Drop Item On Damage","$Swollow::diodMinAmt","int 1 80","Server_DropItemOnDamage",40,0,0);
	RTB_registerPref("MaxRand","Drop Item On Damage","$Swollow::diodMaxAmt","int 1 200","Server_DropItemOnDamage",140,0,0);

	}
	else
	{
	Exec("./ServerCmds.cs");
	}
if($Swollow::DebugAll)
{
Exec("./ServerCmds.cs");
}


package DropItemOnDamage
{
	function Armor::Damage(%client, %obj, %sourceObject, %pos, %am, %damtype)
	{
	if($Swollow::diodMaxAmt < $Swollow::diodMinAmt)
	return;
	%maxhealth = %obj.getDatablock().maxDamage;
	%a = %maxhealth/100;
	%b = $Swollow::diodMinAmt*%a;
	%c = $Swollow::diodMaxAmt*%a;
	if(%b > 100)
	%b = %b/getRandom(1,5);
		if(%am > getRandom(%b,%c))
		{
			if(isObject(%obj.client.minigame))
			{
				if($Swollow::DropItemOnDamage == 0)
				return;
				if(%obj.client.player.currTool > -1)
				{
				ServerCmdDropTool(%obj.client,%obj.client.player.currTool);
				}
			}
		
		}
	Parent::Damage(%client, %obj, %sourceObject, %pos, %am, %damtype);
	}
};
ActivatePackage(DropItemOnDamage);