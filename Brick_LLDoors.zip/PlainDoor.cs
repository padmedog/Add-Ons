datablock fxDTSBrickData ( brickPlainDoorOpenCWData )
{
	brickFile = "./PlainDooropenCW.blb";
	uiName = "Simple Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickPlainDoorCWData";
	openCW = "brickPlainDoorOpenCWData";
	
	closedCCW = "brickPlainDoorCWData";
	openCCW = "brickPlainDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickPlainDoorOpenCCWData : brickPlainDoorOpenCWData )
{
	brickFile = "./PlainDooropenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickPlainDoorCWData : brickPlainDoorOpenCWData )
{
	brickFile = "./PlainDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";
	
	iconName = "Add-Ons/Brick_LLDoors/SimpleDoor";
	
	isOpen = 0;
};