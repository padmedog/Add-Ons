datablock fxDTSBrickData(brickGrass16Data)
{
	brickFile = "./Grass.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Grass Patch"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/Grass";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTree1Data)
{
	brickFile = "./Tree1.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Base 1"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/Tree1";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTree2Data)
{
	brickFile = "./Tree2.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Base 2"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/Tree2";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTree3Data)
{
	brickFile = "./Tree3.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Base 3"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/Tree3";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop11Data)
{
	brickFile = "./TreeTop1.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Marshmallow"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop1";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop12Data)
{
	brickFile = "./TreeTop2.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Pine"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop2";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop13aData)
{
	brickFile = "./TreeTop3a.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Grouped"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop3a";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop13bData)
{
	brickFile = "./TreeTop3b.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Grouped Wedge"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop3b";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop14Data)
{
	brickFile = "./TreeTop4.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Simple"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop4";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop14FatData)
{
	brickFile = "./TreeTop4Fat.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Simple Fat"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop4Fat";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop15Data)
{
	brickFile = "./TreeTop5.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Trapezoidal"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop5";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop16Data)
{
	brickFile = "./TreeTop6.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Wedge"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop6";
	orientationFix = 3;
};
datablock fxDTSBrickData(brickTreeTop17Data)
{
	brickFile = "./TreeTop7.blb";
	canCover = true;
	category = "Special";
	subCategory = "Sylvanor's Trees";
	uiName = "Tree Classic"; 	
	iconName = "Add-Ons/Brick_LLSylvanorTrees/TreeTop7";
	orientationFix = 3;
};