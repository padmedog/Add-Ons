//////////
// item //
//////////
datablock ItemData(L4BPipeWrenchItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./pipe_wrench.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Monkey Wrench";
	iconName = "./icon_monkeywrench";
	doColorShift = true;
	colorShiftColor = "0.9 0 0 1.000";

	 // Dynamic properties defined by the scripts
	image = L4BPipeWrenchImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////

AddDamageType("L4BPipeWrench",   '<bitmap:Add-Ons/weapon_melee_extended_ii/monkeywrench> %1',    '%2 <bitmap:Add-Ons/weapon_melee_extended_ii/monkeywrench> %1',0.75,1);

datablock ShapeBaseImageData(L4BPipeWrenchImage)
{
   shapeFile = "./pipe_wrench.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 -0.1 0.1";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "TF2MeleeWeaponImage";

   // Projectile && Ammo.
   item = L4BPipeWrenchItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = L4BPipeWrenchItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = l4bBatonHitSoundA;
   raycastExplosionPlayerSound = l4bBatonHitSoundB;
   raycastDirectDamage = 55;
   raycastDirectDamageType = $DamageType::L4BPipeWrench;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateSequence[0]                 = "swing";
	stateTransitionOnTimeout[0]      = "Ready";
	stateScript[0]                  = "onActivate";
	stateSound[0]                    = weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.05;
	stateTransitionOnTimeout[2]     = "FireA";
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "FireB";
	stateTimeoutValue[3]            = 0.10;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                 = "activate";
	stateSound[3]			= tf2MeleeSwingSound;
	stateScript[3]                  = "onFireB";
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "FireB";
	stateTransitionOnTimeout[4]     = "Wait";
	stateTimeoutValue[4]            = 0.15;
	stateFire[4]                    = true;
	stateSequence[4]                 = "swing";
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		= true;
	
	stateName[5]			= "Wait";
	stateTransitionOnTimeout[5]	= "CheckFire";
	stateTimeoutValue[5]		= 0.05;
	stateScript[5]			= "onStopFire";
	stateAllowImageChange[5]	= false;
	stateWaitForTimeout[5]		= true;

	stateName[6]			= "CheckFire";
	stateTransitionOnTriggerUp[6]	= "StopFire";
	stateTransitionOnTriggerDown[6]	= "PreFire";
	
	stateName[7]                    = "StopFire";
	stateTransitionOnTimeout[7]     = "Ready";
	stateTimeoutValue[7]            = 0.2;
	stateAllowImageChange[7]        = false;
	stateWaitForTimeout[7]		= true;
	stateSequence[7]                = "StopFire";
	stateScript[7]                  = "onStopFire";
};

function L4BPipeWrenchImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);

	if(getRandom(0,1))
	{
		%this.raycastExplosionBrickSound = l4bBatonHitSoundA;
		%this.raycastExplosionPlayerSound =meleeHammerSound;
	}
	else
	{
		%this.raycastExplosionBrickSound = l4bBatonHitSoundB;
		%this.raycastExplosionPlayerSound =meleeHammerSound;
	}

	WeaponImage::onFire(%this, %obj, %slot);
}

function L4BPipeWrenchImage::onFireB(%this, %obj, %slot)
{
	//%obj.playthread(2, shiftaway);
}

function L4BPipeWrenchImage::onActivate(%this, %obj, %slot)
{
	%obj.playthread(2, shiftto);
}
