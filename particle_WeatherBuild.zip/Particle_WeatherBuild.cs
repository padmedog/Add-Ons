//Weather//

datablock ParticleData(Snow1Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.2;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 3080;
	lifetimeVarianceMS   = 0;
	textureName          = "./snow1";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.05;
	times[2]      = 0.99;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleData(Snow2Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 4000;
	lifetimeVarianceMS   = 0;
	textureName          = "./snow2";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.05;
	times[2]      = 0.99;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleData(Snow7Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.2;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 6160;
	lifetimeVarianceMS   = 0;
	textureName          = "./snow1";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.05;
	times[2]      = 0.99;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleData(Snow8Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 8000;
	lifetimeVarianceMS   = 0;
	textureName          = "./snow2";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.05;
	times[2]      = 0.99;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleEmitterData(SnowingEffect2Emitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 15;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = false;
   particles = "Snow7Particle Snow8Particle";

   useEmitterColors = true;

    uiName = "W Snow 16x16 lots";
};

datablock ParticleEmitterData(SnowingEffect4Emitter)
{
   ejectionPeriodMS = 480;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 15;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = false;
   particles = "Snow8Particle";

   useEmitterColors = true;

    uiName = "W Snow 4x4 lots";
};

datablock ParticleData(Snow3Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.2;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 2080;
	lifetimeVarianceMS   = 300;
	textureName          = "./snow1";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.10;
	times[2]      = 0.90;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleData(Snow4Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.3;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 2100;
	lifetimeVarianceMS   = 400;
	textureName          = "./snow2";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.10;
	times[2]      = 0.90;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleEmitterData(SnowShooter1EffectEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 35.0;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = false;
   particles = "Snow3Particle Snow4Particle";

   useEmitterColors = true;

    uiName = "W Snow Wind";
};

datablock ParticleData(Snow5Particle)
{
	dragCoefficient      = 0.2;
	gravityCoefficient   = 0.2;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 580;
	lifetimeVarianceMS   = 100;
	textureName          = "./snow1";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.10;
	times[2]      = 0.90;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleData(Snow6Particle)
{
	dragCoefficient      = 0.1;
	gravityCoefficient   = 0.3;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 600;
	lifetimeVarianceMS   = 50;
	textureName          = "./snow2";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "1.0 1.0 1.0 0.0";
	colors[1]     = "1.0 1.0 1.0 1.0";
	colors[2]     = "1.0 1.0 1.0 1.0";
	colors[3]     = "1.0 1.0 1.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.30;
	sizes[2]      = 0.30;
	sizes[3]      = 0.30;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.10;
	times[2]      = 0.90;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleEmitterData(SnowShooter2EffectEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 35.0;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = false;
   particles = "Snow5Particle Snow6Particle";

   useEmitterColors = true;

    uiName = "W Snow shooter";
};

datablock ParticleData(Rain3Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 3300;
	lifetimeVarianceMS   = 0;
	textureName          = "./Droplet1";
	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "0.5 0.5 0.7 0.0";
	colors[1]     = "0.5 0.5 0.7 1.0";
	colors[2]     = "0.5 0.5 0.7 1.0";
	colors[3]     = "0.5 0.5 0.7 0.0";
	sizes[0]      = 0.23;
	sizes[1]      = 0.25;
	sizes[2]      = 0.25;
	sizes[3]      = 0.25;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.10;
	times[2]      = 0.99;
	times[3]      = 1.0;

	useInvAlpha = false;
};

// ~5 blocks per m

datablock ParticleEmitterData(RainingEffect2Emitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 20.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = true;
   particles = "Rain3Particle";

   useEmitterColors = True;

    uiName = "W Rain 16x16 lots";
};

datablock ParticleEmitterData(RainingEffect4Emitter)
{
   ejectionPeriodMS = 80;
   periodVarianceMS = 0;
   ejectionVelocity = 20.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = true;
   particles = "Rain3Particle";

   useEmitterColors = True;

    uiName = "W Rain 4x4 lots";
};


datablock ParticleEmitterData(RainingEffect5Emitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 20.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 95;
   thetaMax         = 110;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   orientParticles = true;
   particles = "Rain3Particle";

   useEmitterColors = True;

    uiName = "W HeavyRain 16x16 lots";
};

datablock ParticleEmitterData(RainingEffect6Emitter)
{
   ejectionPeriodMS = 32;
   periodVarianceMS = 0;
   ejectionVelocity = 20.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 95;
   thetaMax         = 110;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   orientParticles = true;
   particles = "Rain3Particle";

   useEmitterColors = True;

    uiName = "W HeavyRain 4x4 lots";
};

datablock ParticleData(rainscParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0;
	constantAcceleration = 0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 0;
	textureName          = "./watersplash2";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.5 0.5 0.7 1.0";
	colors[1]     = "0.5 0.5 0.7 1.0";
	colors[2]     = "0.5 0.5 0.7 0.0";
	sizes[0]      = 0.55;
	sizes[1]      = 0.65;
	sizes[2]      = 0.85;
	times[0]      = 0.0;
	times[1]      = 0.9;
	times[2]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(rainSplash1Emitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 1;
   ejectionVelocity = 0.1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.30;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = False;
   particles = "rainscParticle";
   useEmitterColors = true;

   uiName = "W Splash 16x16 lots";
};

datablock ParticleEmitterData(rainSplash2Emitter)
{
   ejectionPeriodMS = 128;
   periodVarianceMS = 16;
   ejectionVelocity = 0.1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.30;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = False;
   particles = "rainscParticle";
   useEmitterColors = true;

   uiName = "W Splash 4x4 lots";
};

datablock ParticleEmitterData(rainSplash3Emitter)
{
   ejectionPeriodMS = 512;
   periodVarianceMS = 64;
   ejectionVelocity = 0.1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.70;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = False;
   particles = "rainscParticle";
   useEmitterColors = true;

   uiName = "W Splash 2x2 lots";
};

datablock ParticleEmitterData(rainSplashWallEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 1;
   ejectionVelocity = 0.1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.75;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = False;
   particles = "rainscParticle";
   useEmitterColors = true;

   uiName = "W Splash Wall lots";
};

datablock ParticleData(Thunder3Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 100;
	textureName          = "./Lightning_1";

	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "0.5 0.5 0.7 0.8";
	colors[1]     = "0.7 0.7 0.9 1.0";
	colors[2]     = "0.5 0.5 0.7 1.0";
	colors[3]     = "0.2 0.2 0.4 0.0";
	sizes[0]      = 14.00;
	sizes[1]      = 14.00;
	sizes[2]      = 14.00;
	sizes[3]      = 14.00;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.3;
	times[2]      = 0.6;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleData(Thunder4Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 100;
	textureName          = "./Lightning_2";

	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "0.5 0.5 0.7 0.8";
	colors[1]     = "0.7 0.7 0.9 1.0";
	colors[2]     = "0.5 0.5 0.7 1.0";
	colors[3]     = "0.2 0.2 0.4 0.0";
	sizes[0]      = 14.00;
	sizes[1]      = 14.00;
	sizes[2]      = 14.00;
	sizes[3]      = 14.00;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.3;
	times[2]      = 0.6;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleData(Thunder5Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 100;
	textureName          = "./Lightning_3";

	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "0.5 0.5 0.7 0.8";
	colors[1]     = "0.7 0.7 0.9 1.0";
	colors[2]     = "0.5 0.5 0.7 1.0";
	colors[3]     = "0.2 0.2 0.4 0.0";
	sizes[0]      = 14.00;
	sizes[1]      = 14.00;
	sizes[2]      = 14.00;
	sizes[3]      = 14.00;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.3;
	times[2]      = 0.6;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleData(Thunder6Particle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 100;
	textureName          = "./Lightning_4";

	spinSpeed		= 0.0;
	spinRandomMin		= 00.0;
	spinRandomMax		= 00.0;
	colors[0]     = "0.5 0.5 0.7 0.8";
	colors[1]     = "0.7 0.7 0.9 1.0";
	colors[2]     = "0.5 0.5 0.7 1.0";
	colors[3]     = "0.2 0.2 0.4 0.0";
	sizes[0]      = 14.00;
	sizes[1]      = 14.00;
	sizes[2]      = 14.00;
	sizes[3]      = 14.00;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.3;
	times[2]      = 0.6;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(ThunderBEmitter)
{
   ejectionPeriodMS = 5000;
   periodVarianceMS = 3000;
   ejectionVelocity = 0.1;
   velocityVariance = 0.0;
   ejectionOffset   = 8.0;
   thetaMin         = 0;
   thetaMax         = 2;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = true;
   particles = "Thunder3Particle Thunder4Particle Thunder5Particle Thunder6Particle";

   useEmitterColors = True;

    uiName = "W Lightning";
};

datablock ParticleEmitterData(ThunderCEmitter)
{
   ejectionPeriodMS = 400;
   periodVarianceMS = 220;
   ejectionVelocity = 0.1;
   velocityVariance = 0.0;
   ejectionOffset   = 8.0;
   thetaMin         = 0;
   thetaMax         = 2;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = true;
   particles = "Thunder3Particle Thunder4Particle Thunder5Particle Thunder6Particle";

   useEmitterColors = True;

    uiName = "W Crazy Lightning";
};

datablock ParticleData(ThunderCloud1Particle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0;
	constantAcceleration = 2;
	lifetimeMS           = 40000;
	lifetimeVarianceMS   = 3000;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 0.0;
	spinRandomMin		= -10.0;
	spinRandomMax		= 10.0;
	colors[0]     = "0.2 0.2 0.3 0.0";
	colors[1]     = "0.7 0.7 0.9 0.8";
	colors[2]     = "0.2 0.2 0.3 0.6";
	colors[3]     = "0.2 0.2 0.3 0.0";
	sizes[0]      = 10.15;
	sizes[1]      = 10.10;
	sizes[2]      = 10.15;
	sizes[3]      = 10.10;
	times[0]      = 0.0;
	times[1]      = 0.01;
	times[2]      = 0.02;
	times[3]      = 1.0;
	useInvAlpha = true;

	windCoefficient = 0.0;
};

datablock ParticleData(ThunderCloud2Particle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0;
	constantAcceleration = 2;
	lifetimeMS           = 40000;
	lifetimeVarianceMS   = 1000;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 0.0;
	spinRandomMin		= -10.0;
	spinRandomMax		= 10.0;
	colors[0]     = "0.2 0.2 0.3 0.0";
	colors[1]     = "0.3 0.3 0.4 0.8";
	colors[2]     = "0.4 0.4 0.5 0.7";
	colors[3]     = "0.4 0.4 0.4 0.0";
	sizes[0]      = 10.15;
	sizes[1]      = 10.10;
	sizes[2]      = 10.15;
	sizes[3]      = 10.10;
	times[0]      = 0.0;
	times[1]      = 0.1;
	times[2]      = 0.9;
	times[3]      = 1.0;

	useInvAlpha = true;

	windCoefficient = 0.0;
};

datablock ParticleEmitterData(ThunderCloudBEffectEmitter)
{
   ejectionPeriodMS = 200;
   periodVarianceMS = 13;
   ejectionVelocity = 1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.01;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = false;
   particles = "ThunderCloud2Particle ThunderCloud2Particle ThunderCloud1Particle";

    uiName = "W Clouds Thunder";
};

datablock ParticleData(NormCloud1Particle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0;
	constantAcceleration = 2;
	lifetimeMS           = 40000;
	lifetimeVarianceMS   = 1000;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 0.0;
	spinRandomMin		= -10.0;
	spinRandomMax		= 10.0;
	colors[0]     = "0.6 0.6 0.7 0.0";
	colors[1]     = "0.8 0.8 0.8 0.8";
	colors[2]     = "0.7 0.7 0.7 0.7";
	colors[3]     = "0.4 0.4 0.5 0.0";
	sizes[0]      = 10.15;
	sizes[1]      = 10.10;
	sizes[2]      = 10.15;
	sizes[3]      = 10.10;
	times[0]      = 0.0;
	times[1]      = 0.1;
	times[2]      = 0.9;
	times[3]      = 1.0;

	useInvAlpha = false;

	windCoefficient = 0.0;
};

datablock ParticleEmitterData(NormCloudBEffectEmitter)
{
   ejectionPeriodMS = 200;
   periodVarianceMS = 13;
   ejectionVelocity = 1;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.01;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles = false;
   particles = "NormCloud1Particle";

   useEmitterColors = True;

    uiName = "W Clouds Heavy";
};