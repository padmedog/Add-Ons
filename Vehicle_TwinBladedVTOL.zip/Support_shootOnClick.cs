$TP::Version=1.1; //Version number, do NOT change this unless you know what you are doing.

if($Support::Shootonclick<$Prop::Version) {return;} //Newer version already loaded.
$Support::Shootonclick=$TP::Version;

package Shootonclick_Pack
{
	function armor::onTrigger(%db,%obj,%slot,%val)
	{
		if(%obj.getClassName()$="Player")
		{
			if(%slot==0)
			{
				if(%val)
				{
					if($Sim::Time<%obj.client.SOC_LastFireTime)
					{
						return;
					}
				}
				%obj.SOC_Shoot(%slot,%val);
			}
		}
		return Parent::onTrigger(%db,%obj,%slot,%val);
	}
};
ActivatePackage(Shootonclick_Pack);

function repeatedVectorAddwithScale(%vecs)
{
	%vec="0 0 0";
	%cnt=getFieldCount(%vecs);
	for(%i=0;%i<%cnt;%i++)
	{
		%fld=getField(%vecs,%i);
		%tvec=getWords(%fld,0,3);
		%scale=getWord(%fld,3);
		%svec=vectorScale(%tvec,%scale);
		%vec=vectorAdd(%vec,%svec);
	}
	return %vec;
}

function SimObject::getLeftVector(%obj)
{
	return vectorCross(%obj.getEyeVector(),%obj.getUpVector());
}

function SimObject::getRightVector(%obj)
{
	return vectorScale(%obj.getLeftVector(%obj),-1);
}

function Player::SOC_Shoot(%obj,%slot,%val)
{
	if(!%val) {cancel(%obj.SOC_reshoot);return;}
	
	%mnt= %obj.getObjectMount();
	if(!isObject(%mnt))
	{
		return;
	}

	%data= %mnt.getDatablock();
	
	%mountObj= %mnt.getMountNodeObject(%data.Shootonclick_RequiredSlot);
	if(%mountObj!$=%Obj) {return;}
	
	if(%data.Shootonclick)
	{
		//Checks OK, shoot it all.
		%cnt=%data.Shootonclick_ProjectileCount;
		for(%i=0;%i<%cnt;%i++)
		{
			%pos= %mnt.getPosition();
			%PVec= %data.Shootonclick_Position[%i];
			%VVec= %data.Shootonclick_Velocity[%i];
			%iPos= repeatedVectorAddwithScale(
			%mnt.getEyeVector() SPC getWord(%PVec,0) TAB
			%mnt.getLeftVector() SPC getWord(%PVec,1) TAB
			%mnt.getUpVector() SPC getWord(%PVec,2)
			);
			%iVel= repeatedVectorAddwithScale(
			%mnt.getEyeVector() SPC getWord(%VVec,0) TAB
			%mnt.getLeftVector() SPC getWord(%VVec,1) TAB
			%mnt.getUpVector() SPC getWord(%VVec,2)
			);
			%scale=%data.Shootonclick_Scale[%i];
			if(%scale$="") {%scale="1 1 1";}
			%p= new Projectile()
			{
				dataBlock= %data.Shootonclick_Projectile[%i];
				initialPosition= vectorAdd(%pos,%iPos);
				initialVelocity= %iVel;
				sourceObject= %obj;
				client= %obj.client;
				sourceSlot= %slot;
				scale= %scale;
			};missionCleanup.add(%p);
		}
		serverPlay3d(%data.Shootonclick_Sound,%pos);
		
		//If hold, schedule.
		if(%data.Shootonclick_Hold)
		{
			//Delay according to datablocks.
			%obj.SOC_reshoot= %obj.schedule(%data.Shootonclick_ReshootDelay,SOC_Shoot,%slot,%val);
		}
		%obj.client.SOC_LastFireTime=$Sim::Time+%data.Shootonclick_ShootDelay/1000;
	}
}