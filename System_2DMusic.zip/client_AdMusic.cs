if($Pref::Client::2dMusic $= "")
	$Pref::Client::2dMusic = true;

function clientCmdPlayMusic(%filename)
{
	if($Pref::Client::2dMusic)
	{
		clientCmdStopMusic();
		playAdMusic(%filename);
	}
	else if(!$DMusicNotify)
	{
		clientCmdServerMessage('',"The server is trying to play music, but you have disabled it.");
		$DMusicNotify = 1;
	}
}

function clientCmdStopMusic()
{
	if($pref::Client::2dMusic)
		stopAdMusic();
}

function toggle2dMusic(%b)
{
	if(%b)
	{
		$Pref::Client::2dMusic = $Pref::Client::2dMusic ? false : true;
		clientCmdServerMessage('',"Server 2D music enabled: " @ $Pref::Client::2dMusic);
	}
}

function AddBind(%division, %name, %command)
{
	for(%i=0;%i<$remapCount;%i++)
	{
		if($remapDivision[%i] $= %division)
		{
			%foundDiv = 1;
			continue;
		}
		if(%foundDiv && $remapDivision[%i] !$= "")
		{
			%position = %i;
			break;
		}
	}
	if(!%foundDiv)
	{
		error("Division not found: " @ %division);
		return;
	}
	if(!%position)
	{
		$remapName[$remapCount] = %name;
		$remapCmd[$remapCount] = %command;
		$remapCount++;
		return;
	}
	for(%i=$remapCount;%i>%position;%i--)
	{
		$remapDivision[%i] = $remapDivision[%i - 1];
		$remapName[%i] = $remapName[%i - 1];
		$remapCmd[%i] = $remapCmd[%i - 1];
	}
	$remapDivision[%position] = "";
	$remapName[%position] = %name;
	$remapCmd[%position] = %command;
	$remapCount++;
}

if(!$added2dadmusicbind)
{
	AddBind("Gui","Toggle Server 2dMusic","toggle2dMusic");
	$addedChatSoundBind = true;
}