datablock fxDTSBrickData ( brickWoodenDoor3OpenCWData )
{
	brickFile = "./WoodenDoor3openCW.blb";
	uiName = "Wooden Door 3";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWoodenDoor3CWData";
	openCW = "brickWoodenDoor3OpenCWData";
	
	closedCCW = "brickWoodenDoor3CWData";
	openCCW = "brickWoodenDoor3OpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickWoodenDoor3OpenCCWData : brickWoodenDoor3OpenCWData )
{
	brickFile = "./WoodenDoor3openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickWoodenDoor3CWData : brickWoodenDoor3OpenCWData )
{
	brickFile = "./WoodenDoor3closed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/WoodenDoor3";
	
	isOpen = 0;
};