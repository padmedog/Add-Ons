//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier1");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Skins_SMG- required add-on Weapon_Package_Tier1 not found");
}
else
{
   exec("./Weapon_NavalSMG.cs"); 
   exec("./Weapon_ReplicaSMG.cs"); 
   exec("./Weapon_ModernSMG.cs"); 
   exec("./Weapon_SilencedSMG.cs"); 
   exec("./Weapon_MicroSMG.cs"); 
}
