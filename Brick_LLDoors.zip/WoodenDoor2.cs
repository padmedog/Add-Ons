datablock fxDTSBrickData ( brickWoodenDoor2OpenCWData )
{
	brickFile = "./WoodenDoor2openCW.blb";
	uiName = "Wooden Door 2";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWoodenDoor2CWData";
	openCW = "brickWoodenDoor2OpenCWData";
	
	closedCCW = "brickWoodenDoor2CWData";
	openCCW = "brickWoodenDoor2OpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickWoodenDoor2OpenCCWData : brickWoodenDoor2OpenCWData )
{
	brickFile = "./WoodenDoor2openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickWoodenDoor2CWData : brickWoodenDoor2OpenCWData )
{
	brickFile = "./WoodenDoor2closed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/WoodenDoor2";
	
	isOpen = 0;
};