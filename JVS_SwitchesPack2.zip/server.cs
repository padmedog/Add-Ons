%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_SwitchesPack1: JVS_Content is missing and is required for this Add-On to work.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack2/types/HorizontalLightSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack2/types/HorizontalValve.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack2/types/VerticalLightSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_SwitchesPack2/types/VerticalValve.cs");
}
