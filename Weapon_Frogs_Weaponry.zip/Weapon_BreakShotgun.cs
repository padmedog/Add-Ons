//audio

AddDamageType("BreakShotgun",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_BreakShotgun> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_BreakShotgun> %1',0.75,1);
datablock ProjectileData(BreakShotgunProjectile1)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 15;
   directDamageType    = $DamageType::BreakShotgun;
   radiusDamageType    = $DamageType::BreakShotgun;

   brickExplosionRadius = 0.2;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 15;
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 20;
   verticalImpulse     = 10;
   explosion           = gunExplosion;

   muzzleVelocity      = 125;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.8;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock DebrisData(BreakShotgunShellDebris)
{
	shapeFile = "./ShellRed.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};


//////////
// item //
//////////
datablock ItemData(BreakShotgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./BreakShotgun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Break Shotgun";
	iconName = "./icon_BreakShotgun";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = BreakShotgunImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(BreakShotgunImage)
{
   // Basic Item properties
   shapeFile = "./BreakShotgun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BreakShotgunItem;
   ammo = " ";
   projectile = BreakShotgunProjectile1;
   projectileType = Projectile;

   casing = BreakShotgunShellDebris;
   shellExitDir        = "-0.2 1.0 1.75"; //-1.0 1.0 1.0
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = BreakShotgunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= BreakShotgunFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.05;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
        stateTimeoutValue[4]		= 0.2;
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateEjectShell[7]              = true;
	stateScript[7]				= "onReloadWait";
    stateSequence[7]               = "BreakOpen";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 1.1;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.2;
	stateScript[9]				= "onReloaded";
        stateTransitionOnTimeout[9]		= "Breakclosecheck";
		
	stateName[10]              = "Breakclose";
	stateTimeoutValue[10]         = 0.1;
	stateScript[10]               = "OnBreakclose";
	stateSequence[10]             = "BreakClose";
	stateSound[10]                = "FWReload1Sound";
	stateTransitionOnTimeout[10]  = "Ready";
	
	stateName[11]                = "BreakcloseCheck";
	stateTransitionOnNoAmmo[11]  = "ReloadStart";
	stateTransitionOnAmmo[11]     = "Breakclose";
};

function BreakShotgunImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 1, 2, 3, 4); 
}

function BreakShotgunImage::onFire(%this,%obj,%slot)
{
	%projectile = BreakShotgunProjectile1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1)
	{
		%spread = 0.0025; //0.002
	}
	else
	{
		%spread = 0.0027; //0.0025
	}
	
	%shellcount = 8;

	%obj.playThread(2, shiftaway);
	%shellcount = 8;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTHugeRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function BreakShotgunImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 1, 2, 3, 4); 
}

function BreakShotgunImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["shotgunrounds"] >= %this.item.maxAmmo)
	{

	%obj.playThread(2, plant);
        if(%obj.client.quantity["shotgunrounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["shotgunrounds"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["shotgunrounds"] <= 1)
	{
		%obj.client.exchangebullets = %obj.client.quantity["shotgunrounds"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.client.quantity["shotgunrounds"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}

function BreakShotgunImage::onBreakclose(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 1, 2, 3, 4); 
	%obj.playThread(2, shiftUp);

}

function BreakShotgunImage::onReloadWait(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun<font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["shotgunrounds"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}



//statescript onBounce