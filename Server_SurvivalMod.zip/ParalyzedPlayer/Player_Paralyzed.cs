datablock PlayerData(PlayerParalyzedArmor : PlayerStandardArmor)
{
   runForce = 0 * 0;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;

   firstPersonOnly = 1;

   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;

   maxUnderwaterForwardSpeed = 0;
   maxUnderwaterBackwardSpeed = 0;
   maxUnderwaterSideSpeed = 0;
   maxUnderwaterForwardCrouchSpeed = 0;
   maxUnderwaterBackwardCrouchSpeed = 0;
   maxUnderwaterSideCrouchSpeed = 0;
   density = 7.5;
   
   jumpForce = 0 * 00;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Paralyzed Player";
	showEnergyBar = false;

   runSurfaceAngle  = 0;
   jumpSurfaceAngle = 0;
};