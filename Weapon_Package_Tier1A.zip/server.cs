//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier1");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Package_Tier1A - required add-on Weapon_Package_Tier1 not found");
}
else
{
   exec("./Weapon_Peppergun.cs"); 
   exec("./Weapon_Snubnose.cs"); 
   //exec("./Weapon_Nailgun.cs"); 
   exec("./Weapon_HuntingShotgun.cs"); 
}
