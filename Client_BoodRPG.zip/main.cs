

function BRPG_Client_GetVersion() {
	//This HAS to be nice binary numbers, 0.01 didnt work due to rounding errors
	//when its passed through the network. Idk how many bytes it has, 2 or 4 probably
	return 0.5;
}

function BRPG_Client_GetGroup() {
	if(!isObject(BRPG_Client_Group))
		new SimGroup(BRPG_Client_Group);
	return BRPG_Client_Group;
}

function BRPG_Client_SwitchCursor(%img) {
	DefaultCursor.delete();

	%cursor = new GuiCursor(DefaultCursor) {
		bitmapName = %img;
		hotSpot = "20 20";
	};

	if(%img $= "Default") {
		DefaultCursor.bitmapName = "base/client/ui/CUR_3darrow";
		DefaultCursor.hotSpot = "1 1";
	}

	canvas.setCursor(DefaultCursor);
}


function clientCmdBRPG_JoinedServer() {
	schedule(0, 0, BRPG_Client_OnJoinBRPGServer);
	echo("BRPG Joined server!");
}


function BRPG_Client_OnJoinBRPGServer() {
	$BRPG::Client::IsInBRPGServer = 1;

	//	exec("./controls.cs");
	//	exec("./battleMembers.cs");

	exec("./playerShapes.cs"); //For info, go to playerShapes.cs
}

function BRPG_Client_OnLeaveBRPGServer() {
	if(!$BRPG::Client::IsInBRPGServer)
		return;

	$BRPG::Client::IsInBRPGServer = 0;
	exec("./unload.cs");
}




package BRPG_Client_Package {
	function GuiMouseEventCtrl::onMouseEnter(%this) {
		if($BRPG::Client::onMouseEnter)
			parent::onMouseEnter(%this);

		if(%this.BRPG_OnMouseEnter !$= "")
			eval(%this.BRPG_OnMouseEnter);
	}

	function GuiMouseEventCtrl::onMouseLeave(%this) {
		if($BRPG::Client::onMouseLeave)
			parent::onMouseLeave(%this);

		if(%this.BRPG_OnMouseLeave !$= "")
			eval(%this.BRPG_OnMouseLeave);
	}

	function GuiMouseEventCtrl::onMouseDown(%this) {
		if($BRPG::Client::onMouseDown)
			parent::onMouseDown(%this);

		if(%this.BRPG_OnMouseDown !$= "")
			eval(%this.BRPG_OnMouseDown);
	}

	function GuiMouseEventCtrl::onMouseUp(%this) {
		if($BRPG::Client::onMouseUp)
			parent::onMouseUp(%this);

		if(%this.BRPG_OnMouseUp !$= "")
			eval(%this.BRPG_OnMouseUp);
	}

	function GuiMouseEventCtrl::onMouseDragged(%this) {
		if($BRPG::Client::onMouseDragged)
			parent::onMouseDragged(%this);

		if(%this.BRPG_OnMouseDragged !$= "")
			eval(%this.BRPG_OnMouseDragged);
	}

	function GuiMouseEventCtrl::onRightMouseDown(%this) {
		if($BRPG::Client::onRightMouseDown)
			parent::onRightMouseDown(%this);

		if(%this.BRPG_OnRightMouseDown !$= "")
			eval(%this.BRPG_OnRightMouseDown);
	}

	function GuiMouseEventCtrl::onRightMouseUp(%this) {
		if($BRPG::Client::onRightMouseUp)
			parent::onRightMouseUp(%this);

		if(%this.BRPG_OnRightMouseUp !$= "")
			eval(%this.BRPG_OnRightMouseUp);
	}


	function GameConnection::setConnectArgs(%client, %lanName, %netName, %prefix, %suffix, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13) {

		%arg4 = trim(%arg4 TAB "BRPG" SPC BRPG_Client_GetVersion());

		if($BRPG::Client::HasDeactivatedDRPG) {
			%arg6 = "\tDRPG\t" @ $DRPG::Client::Version TAB %arg6;

			//I put on the rest of %arg6 incase some other add-on is using it and DRPG is breaking that too
		}

		parent::setConnectArgs(%client, %lanName, %netName, %prefix, %suffix, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13);
	}

	function disconnect(%a) {
		BRPG_Client_OnLeaveBRPGServer();
		parent::disconnect(%a);
	}

	function disconnectedCleanup() {
		BRPG_Client_OnLeaveBRPGServer();
		parent::disconnectedCleanup();
	}
};
schedule(1000, 0, activatePackage, BRPG_Client_Package);


//Okay, so DRPG is being a bully and not giving nearly enough arguments for GameConnection::setConnectArgs
//so instead of all add-ons playing nicely together, ive gotta disable his package.
// See  http://forum.blockland.us/index.php?topic=271036.0  for a collection of args
if($DRPG::Client::Version > 0 && !$BRPG::Client::HasDeactivatedDRPG) {
	warn("BoodRPG Client: Deactivating DRPG client...");
	deactivatePackage(DRPG_Client);

	$BRPG::Client::HasDeactivatedDRPG = 1;
}
