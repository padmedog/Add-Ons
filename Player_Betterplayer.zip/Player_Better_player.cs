//Made by NXTMASTER


datablock PlayerData(PlayerFirstPerson : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	thirdPersonOnly = 1;

 cameramaxdist = 0;
   cameraVerticalOffset = 0.8;
  cameraHorizontalOffset = 0;
   cameraTilt = 0;
  maxfreelookangle = 3;

   runForce = 100 * 60;
  runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 6;
  maxBackwardSpeed = 4;
   maxSideSpeed = 4;

   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
  maxSideCrouchSpeed = 2;

   jumpForce = 10 * 90;
  jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

   runSurfaceAngle  = 55;
  jumpSurfaceAngle = 55;

	uiName = "Better Player";
	showenergybar = false;

	Playerobject.hideNode(head);
	Playerobject.hideNode(larm);
	Playerobject.hideNode(rarm);
	Playerobject.hideNode(body);
};

