datablock fxDTSBrickData (brickVenderData)
{
	brickFile = "Add-Ons/Brick_Vender/Vender.blb";
	category = "Special"; 
	subCategory = "Home-Made";
	uiName = "Vender";                  
	iconName = "Add-Ons/Brick_Vender/imgVender";
};