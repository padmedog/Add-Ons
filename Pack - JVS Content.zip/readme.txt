To Install
==========
Click "Extract all Files" on the left, then in the window click "Next" and then click "Browse" and browse to your Add-Ons folder which is in your Blockland Folder (default: C:\Program Files\Blockland\ or C:\Blockland\ if using Vista).

Make sure you extract to the Add-Ons Folder, NOT the Blockland Folder.