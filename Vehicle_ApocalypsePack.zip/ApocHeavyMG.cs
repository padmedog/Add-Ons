datablock ProjectileData(ApocHeavyMGProjectile)
{
   projectileShapeName = "add-ons/weapon_gun/bullet.dts";
   directDamage        = 9;
   directDamageType = $DamageType::ApocHeavyMGDirect;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse	  = 200;
   explosion           = gunExplosion;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "";
};

AddDamageType("ApocHeavyMGDirect",   '<bitmap:add-ons/Vehicle_ApocalypsePack/ApocHeavyMGCI> %1',       '%2 <bitmap:add-ons/Vehicle_ApocalypsePack/ApocHeavyMGCI> %1',       1, 1);