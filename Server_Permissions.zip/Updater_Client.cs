exec("./Updater.cs");

package Server_Perms_Updater {
	function authTCPobj_Client::onDisconnect(%this) {
		checkPermsUpdate();
		return parent::onDisconnect(%this);
	}
}; activatePackage(Server_Perms_Updater);

function Permissions_Updatecheck_Available(%path) {
	messageBoxOKCancel("Permissions Updater", "There is an update available for Permissions. Update?", "updatePermissions();");
}

function Permissions_Updater_Done() {
	messageBoxOK("Permissions Updater", "The update has now been downloaded. Please restart Blockland to apply it.");
}