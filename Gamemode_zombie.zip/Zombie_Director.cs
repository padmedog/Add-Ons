//This is where I'd write something witty
//%spawnbrick.setvehicle(%zombiedatablock.getid(),%client); %spawnbrick.spawnvehicle();
$pref::Zombies::DirectorTick = 8;
function ZombieSpawnSearchLoop(%minigame)
{
	if(%minigame.member0.isAdmin != 1 && %minigame.member0.isSuperAdmin != 1)
	{
		messageclient(%minigame.member0,'',"Sorry the director is admin only.");
		return;
	}
	if(%minigame.zombieDirectorEnabled == 0 )
	{
		return;
	}
	%minigame.zombieSpecialEventE = 0;
	%min = %minigame.zombieminHorde;
	%max = %minigame.zombiemaxHorde;
	if(%min < 0)
	{
		%min = 0;
	}
	if(%max <= 0)
	{
		%max = 1;
	}
	if(%minigame.zombieMax <= 0)
	{
		%minigame.zombieMax = 1;
	}
	if(%minigame.zombieMax > 30)
	{
		%minigame.zombieMax = 30;
	}
	%spawnnum = getrandom(%min,%max);
	
	%specialRoll = getrandom(0,30);

	if(%minigame.zombieIsPanic)
	{
		%spawnnum = %max;
	}

	//("Zombie Spawn Search Loop");
	cancel(%minigame.ZSS);
	if(isobject(%minigame))
	{
		createZombieSimSet(%minigame);

		if(%specialRoll == 30)
		{	
			//Tank Event
			if(%minigame.LastDirectorEvent+30000 <= getsimtime() && %minigame.zombieIsPanic != 1)
			{
				TankEvent(%minigame);
				return;
			}
		}
		if(%specialRoll == 29)
		{	
			if(%minigame.LastDirectorEvent+30000 <= getsimtime() && %minigame.zombieIsPanic != 1)
			{
				WitchEvent(%minigame);
				return;
			}
		}
		if(%specialRoll <= 28 && %specialRoll >= 24)
		{
			if(%minigame.LastDirectorEvent+50000 <= getsimtime() && %minigame.zombieIsPanic != 1)
			{
				cancel(%minigame.ZPS);
				%minigame.play2dSoundAll("HordeIncoming" @ getrandom(1,4) @ "Sound");
				%minigame.zombieIspanic = 1;
				%minigame.ZPS = schedule(getrandom(1,3)*10000,0,ZombiePanicSchedule,%minigame);
				%minigame.LastDirectorEvent = getsimtime();
			}
		}
		for(%n = 0; %n <%minigame.numMembers; %n++)
		{
			%stab = %minigame.Member[%n];
			ZombieSpawnSearch(%stab.player,%spawnnum/%minigame.numMembers);
		}
		if(%minigame.ZombieIsPanic == 1)
		{
			%minigame.ZSS = schedule($pref::Zombies::DirectorTick*1000/2,0,ZombieSpawnSearchLoop,%minigame);
			return;
		}
		%minigame.ZSS = schedule($pref::Zombies::DirectorTick*1000,0,ZombieSpawnSearchLoop,%minigame);
	}
}
function ZombieSpawnSearch(%player,%znumtospawn,%special)
{
	%client = %player.client;
	if(isobject(%player) && %player.getstate() !$= "Dead")
	{
		//("Entering Spawn Search");
		//%zombiemin = 2;
		//%zombiemax = 8;
		//%znumtospawn = getrandom(%zombiemin,%zombiemax);
		%curspawn = 0;
	   
		if(isInDoors(%player))
		{
			//("OMG I'm in a house");
			%pos = %player.getposition();
			%box = "25 25 4";
			if(%player.client.minigame.ZombieIsPanic == 1)
			{
				%box = "50 50 4";
			}
			%type = $TypeMasks::FxBrickAlwaysObjectType;
			InitContainerBoxSearch(%pos,%box,%type);
			while(%id = containerSearchNext())
			{
				if(%id.getdatablock().getname() $= "ZombieSpawnData"  && %id.vehicle == 0 && MinigameIncludesPlayerBricks(%id.getgroup().client.player))
				{
					if(%player.client.minigame.zombieSimSet.getcount() >= %player.client.minigame.ZombieMax-1)
					{
						return;
					}
					if(%curspawn >= %znumtospawn)
					{
						return;
					}
					//if(CanIseeYou(%id,%player) == 0)
					if(CanISeeAnyone(%id) == 0)
					{
						%curspawn++;
						//%player.client.minigame.numzombies++;
						%zomb = GetRandomZombie(%special);
						//%id.schedule(%timer,setvehicle,%zomb,%client); 
						%id.vss = schedule(%timer,%id,DirectorSetVehicle,%id,%zomb,%client);
						%timer += 100;
						if(%special != 0)
						{
							//("What?");
							return 1;
						}
					}
				}
			}
			return;
		}

	   %searchMasks = $TypeMasks::FxBrickAlwaysObjectType;
	   %radius = 30;
		if(%player.client.minigame.ZombieIsPanic == 1)
		{
				%radius = 50;
		}
		//%maxzombs = 5;
		//%zombs = 0;
		%timer = 0;
		%pos = %player.getPosition();
		InitContainerRadiusSearch(%pos, %radius, %searchMasks);
	  
		while ((%targetid = containerSearchNext()) != 0 ) 
		{

			%id = %targetid.getId();
			if(%id.getdatablock().getname() $= "ZombieSpawnData" && %id.vehicle == 0 && MinigameIncludesPlayerBricks(%id.getgroup().client.player))
			{
				if(%curspawn >= %znumtospawn)
				{
					return;
				}
				if(%player.client.minigame.zombieSimSet.getcount() >= %player.client.minigame.ZombieMax-1)
				{
					return;
				}
				//if(CanIseeYou(%id,%player) == 0)
				if(CanISeeAnyone(%id) == 0)
				{
					%curspawn++;
					//%player.client.minigame.numzombies++;
					%zomb = GetRandomZombie(%special);
					//%id.schedule(%timer,setvehicle,%zomb,%client); 
					%id.vss = schedule(%timer,%id,DirectorSetVehicle,%id,%zomb,%client);
					%timer += 100;
					if(%special != 0)
					{
						//("What?");
						return 1;
					}
				}
			}
		}  
	}
}
function DirectorSetVehicle(%id,%zomb,%client)
{
	if(%client.minigame.zombieSimSet.getcount() <= %client.minigame.ZombieMax-1)
	{
		%id.setvehicle(%zomb,%client);
	}
}
function GetRandomZombie(%special)
{
	if(%special $= "Tank")
	{
		return RotTankZombie.getid();
	}
	if(%special $= "Witch")
	{
		return RotWitchZombie.getid();
	}
	%n = getrandom(0,100);
	if(%n >= 0 && %n < 30)
	{
		return RotSlowZombie.getid();
	}
	if(%n >= 30 && %n < 60)
	{
		return RotNormalZombie.getid();
	}
	if(%n >= 60 && %n < 90)
	{
		return RotFastZombie.getid();
	}
	if(%n >= 90 && %n < 94)
	{
		return RotHunterZombie.getid();
	}
	if(%n >= 94 && %n < 97)
	{
		return RotSmokerZombie.getid();
	}
	if(%n >= 97 && %n <= 100)
	{
		return RotBoomerZombie.getid();
	}
	
}

function CanIseeYou(%this,%obj)
{
	if(!isobject(%obj))
	{
		return 0;
	}
	if(isobject(%this))
	{
		%tPos = %this.getPosition();
	}
	if(isobject(%obj))
	{
		%oPos = %obj.getposition();
	}
		%dis = VectorSub(%oPos, %tPos);
		%normVec = VectorNormalize(%dis);

		//%eyeVec = %this.getEyeVector();
		%eyevec = %normVec;
				
		%startPos = vectoradd(%tpos,"0 0 2");
		%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,30));

		%mask = $TypeMasks::FxBrickObjectType | $typemasks::PlayerObjectType | $TypeMasks::InteriorObjectType;
		%target = ContainerRayCast(%startPos, %endPos, %mask,%this);

		//%p = new Projectile()
		// {
		// dataBlock = gunProjectile;
		//initialPosition = %startpos;
		//	  initialVelocity = vectorscale(%eyevec,20);
		//   };
		//   missionCleanup.add(%p); 
		if(vectordist(%tpos,%opos) <= 3)
		{
			return 1;
		}
		if(%target && %target.getclassname() $= "player")
		{
			return 1;
		}
		if(%target && %target.getclassname() $= "Aiplayer")
		{
			return 1;
		}
		else
		{
			return 0;
		}
}

function zombiedeletecheck(%zombie,%minigame)
{
	if(!isobject(%zombie) || %zombie.getstate $= "Dead")
	{
		//echo("Zombie is already removed, minusing count");
		//%minigame.NumZombies--;
		//if(%minigame.numzombies < 0)
		//{
			//%minigame.numZombies = 0;
		//}
		return;
	}
	if(isobject(%zombie) && %zombie.getstate !$= "Dead")
	{
		//("Del Check called");
		if(%zombie.isfollowing && %zombie.minigame.zombieIsPanic != 1)
		{
			//("Zombie is following a player.");
			%zombie.delsched = schedule($pref::Zombies::DirectorTick*1000,0,zombiedeletecheck,%zombie,%minigame);
			return;
		}
		for(%n = 0; %n <%minigame.numMembers; %n++)
		{
			//echo("Member" @ %n);
			//%t = 5;%p = woo; eval("%T." @ %p @ "= 5;"); echo(%t.woo);
			//eval("%stab = %zombie.spawnbrick.getgroup().client.minigame.Member" @ %n @ ";");
			%stab = %minigame.Member[%n];
			//%stab = "Member" @ %n;
			//echo("Woah woah:" @ CanIseeYou(%zombie,%stab.player));
			%check = CanIseeYou(%zombie,%stab.player);
			if(isobject(%stab.player))
			{
				%ch = vectordist(%zombie.getposition(),%stab.player.getposition());

				if(%ch <= 10)%check2 = 1;
			}
			if(%check == 1 || %check2 == 1)
			{
				//("Player is too close or is in sight");
				%zombie.delsched = schedule($pref::Zombies::DirectorTick*1000,0,zombiedeletecheck,%zombie,%minigame);
				return;
			}
		}
		//("Del check Deletes");
		//%minigame.NumZombies--;
		if(%minigame.numzombies < 0)
		{
			%minigame.numZombies = 0;
		}
		%zombie.spawnbrick.setvehicle("None");
	}
}

function ClearRotZombies(%client)
{
	%foo = "ZombieGroup::" @ %client;
	if(isobject(%foo))
	{
		%num = %foo.getcount();

		for(%a= %num-1;%a >= 0; %a--)
		{
			%foo.getobject(%a).spawnbrick.setvehicle("None");	
		}
	}
}
function ClearMinigameRotZombies(%minigame)
{
	for(%n = 0; %n <%minigame.numMembers; %n++)
	{
		//eval("%client = %minigame.Member" @ %n @ ";");
		%client = %minigame.Member[%n];
		ClearRotZombies(%client);
	}
}

function isInDoors(%this)
{
			%eyeVec = %this.getEyeVector();

			%startPos = %this.getEyePoint();
			%endPos = VectorAdd(%startPos,"0 0 3.75");

			%mask = $TypeMasks::FxBrickObjectType;
			%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
			if(%target)
			{
					return 1;
			}
}
function BoxCastTest(%player)
{
		%a = 0;
		%pos = %player.getposition();
		%box = "35 35 4";
		%type = $TypeMasks::FxBrickObjectType;
		InitContainerBoxSearch(%pos,%box,%type);
		while(%targ = containerSearchNext())
		{
			if(%targ.getdatablock().getname() $= "ZombieSpawnData")
			{
				%targ.disappear(1);
				//(%a++);
			}
		}
}
function TankEvent(%minigame)
{
	if(isobject(%minigame) && %minigame.zombieDirectorEnabled)
	{
		//("Tank Called");
		cancel(%minigame.DSLL);
		cancel(%minigame.ZSS);
		%minigame.zombieSpecialEventE++;
		if(%minigame.zombieSimSet.getcount() == 0 || %minigame.zombieSpecialEventE >= 5)
		{
			//Play really heavy tank noise
			%rand = getrandom(0,%minigame.numMembers-1);
			%su = ZombieSpawnSearch(%minigame.member[%rand].player,1,"Tank");
			//(%su);
			if(%su)
			{
				%minigame.ZSS = schedule($pref::Zombies::DirectorTick*1000*2,0,ZombieSpawnSearchLoop,%minigame);
				%minigame.LastDirectorEvent = getsimtime();
				//("Tank Done");
				return;
			}
		}
		%minigame.DSLL = schedule($pref::Zombies::DirectorTick*1000/2,0,TankEvent,%minigame);
		//Play some tank noise
		return;
	}
}
function WitchEvent(%minigame)
{
	if(isobject(%minigame) && %minigame.zombieDirectorEnabled)
	{
		//("Witch Called");
		cancel(%minigame.DSLL);
		cancel(%minigame.ZSS);
		%minigame.zombieSpecialEventE++;
		if(%minigame.zombieSimSet.getcount() == 0 || %minigame.zombieSpecialEventE >= 5)
		{
			//Play really heavy tank noise
			%rand = getrandom(0,%minigame.numMembers-1);
			%su = ZombieSpawnSearch(%minigame.member[%rand].player,1,"Witch");
			if(%su)
			{
				%minigame.ZSS = schedule($pref::Zombies::DirectorTick*1000*2,0,ZombieSpawnSearchLoop,%minigame);
				%minigame.LastDirectorEvent = getsimtime();
				//("Witch Done");
				return;
			}
		}
		%minigame.DSLL = schedule($pref::Zombies::DirectorTick*1000/2,0,WitchEvent,%minigame);
		//Play some tank noise
		return;
	}
}
function CanISeeAnyone(%this)
{
	if(isobject(%this.getgroup().client.minigame))
	{
		for(%a = 0; %a < %this.getgroup().client.minigame.numMembers; %a++)
		{
			%find = CanIseeYou(%this,%this.getgroup().client.minigame.member[%a].player);
			//(%find);
			if(%find)
			{
				return 1;
			}
		}
		return 0;
	}
}
function createZombieSimSet(%minigame)
{
	if(!isobject(%minigame.zombieSimSet))
	{
		%minigame.zombieSimSet = new SimSet ()
		{
			
		};
		MissionCleanup.add(%minigame.zombieSimSet);
		return;
	}
	//echo("Failure");
}
function MiniGameSO::play2dSoundAll(%minigame,%sound)
{
	if(isobject(%minigame))
	{
		for(%a = 0;%a < %minigame.numMembers; %a++)
		{
			%minigame.member[%a].play2d(%sound);
		}
	}
}
function ZombiePanicSchedule(%minigame)
{
	%minigame.ZombieIsPanic = 0;
	cancel(%minigame.ZSS);
	%minigame.ZSS = schedule(15000,%minigame,ZombieSpawnSearchLoop,%minigame);
}
datablock ProjectileData(DirectorBlankProjectile)
{
   projectileShapeName = "";
   uiName = "";
};