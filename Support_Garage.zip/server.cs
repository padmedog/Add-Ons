function Garage_AddParts(%f)
{
   if(!isFile(%f))
      return;
   %o=new FileObject();
   %o.openForRead(%f);
   while(!%o.isEOF())
      %s=%s@(strLen(%s)?"\n":"")@%o.readLine();
   %o.close();
   %o.delete();
   Garage_ParseString(%s);
}
function Garage_ParseString(%s)
{
   for(%i=0;%i<getLineCount(%s);%i++)
   {
      %l=lTrim(trim(getLine(%s,%i)));
      
      switch$(getWord(getField(%l,0),0))
      {
         case "VEHICLE" :
            %v=getField(%l,1);
            deleteVariables("$Garage::PartName"@%v@"*");
            deleteVariables("$Garage::PartCount"@%v@"*");
            deleteVariables("$Garage::PartExists"@%v@"*");
            deleteVariables("$Garage::PartTotal"@%v@"*");
            deleteVariables("$Garage::Part"@%v@"*");
            deleteVariables("$Garage::Parts"@%v@"*");
            if(!$Garage::IsVehicle[%v])
            {
               $Garage::Vehicle[mFloor($Garage::Vehicles)]=%v;
               $Garage::Vehicles++;
            }
         default :
            %w=getWord(getField(%l,0),0);
            if(%w$="tire")
               continue;
            if(StrLen(lTrim(trim(%w))))
            {
               $Garage::PartName[%v,%w,mFloor($Garage::PartTotal[%v,%w])]=getField(%l,1);
               $Garage::PartCount[%v,%w,mFloor($Garage::PartTotal[%v,%w])]=getField(%l,2);
               $Garage::PartExists[%v,%w,getField(%l,1)]=mFloor($Garage::PartTotal[%v,%w]);
               if(!$Garage::PartTotal[%v,%w])
               {
                  $Garage::Part[%v,mFloor($Garage::Parts[%v])]=%w;
                  $Garage::Parts[%v]++;
               }
               $Garage::PartTotal[%v,%w]++;
            }
      }
   }
}
function Vehicle::GarageDefault(%this,%a)
{
   if(!isObject(findClientByBL_ID(%this.spawnBrick.getGroup().bl_id)))
   {
      %this.schedule(0,delete);
      return;
   }
   %this.hideParts();
   %abc="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   %k=0;
   %type=%this.getDatablock().type;
   %c=getWords(getColorIDTable(%this.spawnBrick.colorid),0,2) SPC 1;
   for(%j=0;%j<$Garage::Parts[%type];%j++)
   {
      if($Garage::Part[%type,%j]$="tire")
         continue;
      %this.setPart($Garage::Part[%type,%j],(!%a&&strLen(%this.spawnBrick.part[%type,$Garage::Part[%type,%j]])?%this.spawnBrick.part[%type,$Garage::Part[%type,%j]]:0),!%a);
      %this.setPartColor($Garage::Part[%type,%j],(!%a&&strLen(%this.spawnBrick.partColor[%type,$Garage::Part[%type,%j]])?%this.spawnBrick.partColor[%type,$Garage::Part[%type,%j]]:%c),!%a);
   }
}
//$Garage::PartCount["VEHICLE","PART","PARTID"]
//$Garage::PartTotal["VEHICLE","PART"]
//$Garage::PartExists["VEHICLE","PART","NAME"]
//$Garage::PartName["VEHICLE","PART","PARTID"]
function Vehicle::setPart(%obj,%p,%b,%l)
{
   for(%i=0;%i<ClientGroup.getCount();%i++)
   {
      if((%c=ClientGroup.getObject(%i)).Garage_Editing==%obj)
         commandtoClient(%c,'Garage_SetPart',%p,%b);
   }
   %abc="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   if(%p$="Tire")
   {
      return; //no more tires lel
      if(!isObject(nameToID($Garage::PartCount[%obj.getDatablock().type,"Tire",%b])))
         return;
      //return;
      %obj.partTire=%b;
      for(%i=0;%i<%obj.getWheelCount();%i++)
         %obj.setWheelTire(%i,nameToID($Garage::PartCount[%obj.getDatablock().type,"Tire",%b]));
      return;
   }
   else
   {
      if(!$Garage::PartTotal[%obj.getDatablock().type,%p])
         return;
   }
   %s=%obj.part[%p];
   if(strLen(%s))
      for(%i=0;%i<$Garage::PartCount[%obj.getDatablock().type,%p,%obj.part[%p]];%i++)
         %obj.hideNode(%p@"_"@getSubStr(%abc,%obj.part[%p],1)@"_"@getSubStr(%abc,%i,1));
      
   for(%i=0;%i<$Garage::PartCount[%obj.getDatablock().type,%p,%b];%i++)
      %obj.unhideNode(%p@"_"@getSubStr(%abc,%b,1)@"_"@getSubStr(%abc,%i,1));
   %obj.part[%p]=%b;
   if(isObject(%obj.spawnBrick)&&!%l)
      %obj.spawnBrick.part[%obj.getDatablock().type,%p]=%b;
}
function Vehicle::setPartColor(%obj,%m,%c,%l)
{
   for(%i=0;%i<ClientGroup.getCount();%i++)
   {
      if((%a=ClientGroup.getObject(%i)).Garage_Editing==%obj)
         commandtoClient(%a,'Garage_SetPartColor',%m,%c);
   }
   %abc="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   %obj.partColor[%m]=%c;
   if(isObject(%obj.spawnBrick)&&!%l)
      %obj.spawnBrick.partColor[%obj.getDatablock().type,%m]=%c;
   if(%m$="Tire")
      return;
   for(%k=0;%k<$Garage::PartTotal[%obj.getDatablock().type,%m];%k++)
      for(%i=0;%i<$Garage::PartCount[%obj.getDatablock().type,%m,%k];%i++)
         %obj.setNodeColor(%m@"_"@getSubStr(%abc,%k,1)@"_"@getSubStr(%abc,%i,1),%c);
}
function Vehicle::HideParts(%this)
{
   
   %abc="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   
   %type=%this.getDatablock().type;
   for(%j=0;%j<$Garage::Parts[%type];%j++)
      if((%p[%j]=$Garage::Part[%type,%j])!$="Tire")
         for(%k=0;%k<$Garage::PartTotal[%type,%p[%j]];%k++)
            for(%i=0;%i<$Garage::PartCount[%type,%p[%j],%k];%i++)
               %this.hideNode(%p[%j]@"_"@getSubStr(%abc,%k,1)@"_"@getSubStr(%abc,%i,1));
}
function Player::DisplayVehicleInfos(%this)
{
   if(!isObject(%this.client))
      return;
   if(!isObject(%this.getObjectMount()))
   {
      %start = %this.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%this.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%this);
      %col = firstWord(%ray);
   }
   else
      %col=%this.getObjectMount();
   if(!isObject(%col))
         return;
   if(!%col.getDatablock().isCustom)
      return;
   %type=%col.getDatablock().type;
   %str=   "<font:arial:16>\c3Vehicle: \c6"@%col.getDatablock().uiname@"   ";
   for(%i=0;%i<$Garage::Parts[%type];%i++)
   {
      %n=$Garage::Part[%type,%i];
      if(strLen(%n))
         %str=%str@"<br>\c3"@%n@"\c6: "@$Garage::PartName[%type,%n,%col.part[%n]]@"   ";
   }
   %this.client.centerprint("<just:right>"@%str,3);
}
function servercmdSetPart(%c,%a,%b)
{
   if(!isObject(%p=%c.player))
   {
      %c.chatMessage("\c3Could not apply part, you don't have a player");
      commandToClient(%c,'Garage_Error',"No Player","You don't have a player");
      return;
   }
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not apply part, you aren't looking at a vehicle");
      commandToClient(%c,'Garage_Error',"No Vehicle","You aren't looking at a vehicle");
      return;
   }
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not apply part, you can't mod that vehicle");
      commandToClient(%c,'Garage_Error',"Not Custom","You can't customize that vehicle");
      return;
   }
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
   {
      %c.chatMessage("\c3Could not apply part, owner doesn't trust you enough");
      commandToClient(%c,'Garage_Error',"No Trust","You don't have enough trust");
      return;
   }
   %type=%col.getDatablock().type;
   if(strLen(%w=$Garage::PartExists[%type,%a,%b]))
   {
      %col.setPart(%a,%w);
      if(!%c.partLoading)
         %c.chatMessage("\c3Applied Part");
      commandToClient(%c,'Garage_SetPart',%a,%b);
      return;  
   }
   %c.chatMessage("\c3Could not apply part, invalid part selected");
   commandToClient(%c,'Garage_Error',"No Part","That part doesn't work on this vehicle");
}
function servercmdDefaultParts(%c)
{
   if(!isObject(%p=%c.player))
   {
      %c.chatMessage("\c3Could not default parts, you don't have a player");
      commandToClient(%c,'Garage_Error',"No Player","You don't have a player");
      return;
   }
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not default parts, you aren't looking at a vehicle");
      commandToClient(%c,'Garage_Error',"No Vehicle","You aren't looking at a vehicle");
      return;
   }
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not default parts, you can't mod that vehicle");
      commandToClient(%c,'Garage_Error',"Not Custom","You can't customize that vehicle");
      return;
   }
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
   {
      %c.chatMessage("\c3Could not default parts, owner doesn't trust you enough");
      commandToClient(%c,'Garage_Error',"No Trust","You don't have enough trust");
      return;
   }
   %type=%col.getDatablock().type;
   %col.GarageDefault(1);
   if(!%c.partLoading)
      %c.chatMessage("\c3Applied Default Parts");
   return;
}
function servercmdPaintPart(%c,%a,%r,%g,%b)
{
   %color=vectorScale(getColorIDTable(%c.currentColor),255);
   servercmdColorPart(%c,%a,getWord(%color,0),getWord(%color,1),getWord(%color,2));
}
function servercmdColorPart(%c,%a,%r,%g,%b)
{
   %g=%r SPC %g SPC %b;
   if(!isObject(%p=%c.player))
   {
      %c.chatMessage("\c3Could not color part, you don't have a player");
      commandToClient(%c,'Garage_Error',"No Player","You don't have a player");
      return;
   }
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not color part, you aren't looking at a vehicle");
      commandToClient(%c,'Garage_Error',"No Vehicle","You aren't looking at a vehicle");
      return;
   }
   if(getWordCount(%g)!=3)
   {
      %c.chatMessage("\c3Could not color part, invalid color format (0-255, RGB)");
      commandToClient(%c,'Garage_Error',"Bad Color","That color doesn't work");
      return;
   }
   if(getWord(%g,0)>255||getWord(%g,0)<0||getWord(%g,1)>255||getWord(%g,1)<0||getWord(%g,2)>255||getWord(%g,2)<0)
   {
      %c.chatMessage("\c3Could not color part, colors out of bounds (0-255)");
      commandToClient(%c,'Garage_Error',"Bad Color","That color doesn't work");
      return;
   }
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not color part, you can't mod that vehicle");
      commandToClient(%c,'Garage_Error',"Not Custom","You can't customize that vehicle");
      return;
   }
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
   {
      %c.chatMessage("\c3Could not color part, owner doesn't trust you enough");
      commandToClient(%c,'Garage_Error',"No Trust","You don't have enough trust");
      return;
   }
   %type=%col.getDatablock().type;
   if(strLen($Garage::PartTotal[%type,%a]))
   {
      %col.setPartColor(%a,vectorScale(%g,1/255) SPC 1);
      if(!%c.partLoading)
         %c.chatMessage("\c3Colored Part");
      return;  
   }
   %c.chatMessage("\c3Could not color part, invalid part selected");
}
function servercmdSaveParts(%c)
{
   if(!isObject(%p=%c.player))
   {
      %c.chatMessage("\c3Could not save part, you don't have a player");
      commandToClient(%c,'Garage_Error',"No Player","You don't have a player");
      return;
   }
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not save parts, you aren't looking at a vehicle");
      commandToClient(%c,'Garage_Error',"No Vehicle","You aren't looking at a vehicle");
      return;
   }
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not save parts, you can't mod that vehicle");
      commandToClient(%c,'Garage_Error',"Not Custom","You can't customize that vehicle");
      return;
   }
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
   {
      %c.chatMessage("\c3Could not save parts, owner doesn't trust you enough");
      commandToClient(%c,'Garage_Error',"No Trust","You don't have enough trust");
      return;
   }
   %type=%col.getDatablock().type;
   if(!isObject(GarageFile)) new FileObject(GarageFile);
   GarageFile.openForWrite("config/Garage/"@%c.bl_id@".txt");
   GarageFile.writeLine(%type);
   for(%i=0;%i<$Garage::Parts[%type];%i++)
   {
      %n=$Garage::Part[%type,%i];
      if(strLen(%n))
         GarageFile.writeLine(%n@"\t"@$Garage::PartName[%type,%n,%col.part[%n]]@"\t"@(strLen(%col.partColor[%n])?getWords(%col.partColor[%n],0,2):getWords(getColorIDTable(%col.spawnBrick.colorid),0,2)));
   }
   
   GarageFile.close();
   %c.chatMessage("\c3Saved Parts");
   commandToClient(%c,'Garage_Error',"Save","Parts have been saved");
}
function servercmdGarage_SaveParts(%c)
{
    if(!isObject(%p=%c.player))
   {
      %c.chatMessage("\c3Could not save part, you don't have a player");
      commandToClient(%c,'Garage_Error',"No Player","You don't have a player");
      return;
   }
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not save parts, you aren't looking at a vehicle");
      commandToClient(%c,'Garage_Error',"No Vehicle","You aren't looking at a vehicle");
      return;
   }
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not save parts, you can't mod that vehicle");
      commandToClient(%c,'Garage_Error',"Not Custom","You can't customize that vehicle");
      return;
   }
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
   {
      %c.chatMessage("\c3Could not save parts, owner doesn't trust you enough");
      commandToClient(%c,'Garage_Error',"No Trust","You don't have enough trust");
      return;
   }
   %type=%col.getDatablock().type;
   for(%i=0;%i<$Garage::Parts[%type];%i++)
   {
      %n=$Garage::Part[%type,%i];
      if(strLen(%n))
         commandToClient(%c,'Garage_SavePart',%type@"\t"@%n@"\t"@$Garage::PartName[%type,%n,%col.part[%n]]@"\t"@(strLen(%col.partColor[%n])?getWords(%col.partColor[%n],0,2):getWords(getColorIDTable(%col.spawnBrick.colorid),0,2)));
   }
}
function servercmdLoadParts(%c)
{
    if(!isObject(%p=%c.player))
   {
      %c.chatMessage("\c3Could not load part, you don't have a player");
      commandToClient(%c,'Garage_Error',"No Player","You don't have a player");
      return;
   }
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not load parts, you aren't looking at a vehicle");
      commandToClient(%c,'Garage_Error',"No Vehicle","You aren't looking at a vehicle");
      return;
   }
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not load parts, you can't mod that vehicle");
      commandToClient(%c,'Garage_Error',"Not Custom","You can't customize that vehicle");
      return;
   }
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
   {
      %c.chatMessage("\c3Could not load parts, owner doesn't trust you enough");
      commandToClient(%c,'Garage_Error',"No Trust","You don't have enough trust");
      return;
   }
   if(!isFile("config/Garage/"@%c.bl_id@".txt"))
   {
      %c.chatMessage("\c3Could not load parts, no save avaliable");
      commandToClient(%c,'Garage_Error',"No Save","You don't have a save");
      return;
   }
   %type=%col.getDatablock().type;
   if(!isObject(GarageFile)) new FileObject(GarageFile);
   GarageFile.openForRead("config/Garage/"@%c.bl_id@".txt");
   while(!GarageFile.isEOF())
      %str=%str@(strLen(%str)?"\n":"")@GarageFile.readLine();
   GarageFile.close();
   if(lTrim(trim(getLine(%str,0)))!$=%type)
   {
      %c.chatMessage("\c3Could not load parts, save file has different vehicle type");
      commandToClient(%c,'Garage_Error',"Bad Save","Save is for a different vehicle type");
      return;
   }
   %c.partLoading=1;
   for(%i=1;%i<getLineCount(%str);%i++)
   {
      %l=getLine(%str,%i);
      if(!StrLen(%l)||!getFieldCount(%l)) continue;
      servercmdSetPart(%c,getField(%l,0),getField(%l,1));
      if(getField(%l,0)!$="Tire")
      {
         %w=vectorScale(getField(%l,2),255);
         servercmdColorPart(%c,getField(%l,0),getWord(%w,0),getWord(%w,1),getWord(%w,2));
      }
   }
   %c.partLoading=0;
   %c.chatMessage("\c3Loaded Parts");
   commandToClient(%c,'Garage_Error',"Load","Parts have been loaded");
}
function servercmdGarage(%c)
{
   commandtoclient(%c,'OpenGarage');
}
function servercmdGarage_ToggleMessages(%c,%a)
{
   %c.partLoading=(strLen(%a)?%a :!%c.partLoading);
}
function servercmdGarage_GetPartList(%c)
{
   for(%t=0;%t<$Garage::Vehicles;%t++)
   {
      %type=$Garage::Vehicle[%t];
      for(%j=0;%j<$Garage::Parts[%type];%j++)
      {
         %part=$Garage::Part[%type,%j];
         for(%k=0;%k<$Garage::PartTotal[%type,%part];%k++)
            commandToClient(%c,'Garage_AddPart',%type,%part,$Garage::PartName[%type,%part,%k],$Garage::PartCount[%type,%part,%k]);
      }
   }
}
function servercmdgetParts(%c)
{
   if(!isObject(%p=%c.player))
      return;
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
   {
      %c.chatMessage("\c3Could not get parts, you aren't looking at a vehicle");
      return;
   }
   
   if(!%col.getDatablock().isCustom)
   {
      %c.chatMessage("\c3Could not get parts, you can't mod that vehicle");
      return;
   }
   %type=%col.getDatablock().type;
   %c.chatMessage("\c3Vehicle\c6: "@%col.getDatablock().uiName);
   for(%i=0;%i<$Garage::Parts[%type];%i++)
   {
      %n=$Garage::Part[%type,%i];
      for(%k=0;%k<$Garage::PartTotal[%type,%n];%k++)
            %s[%i]=%s[%i]@"\c3/\c6"@$Garage::PartName[%type,%n,%k];
      if(strLen(%s[%i]))
         %c.chatMessage("\c3"@%n@"\c6: "@getSubStr(%s[%i],2,strLen(%s[%i])-2));
   }
}
if(isPackage(Garage))
   deactivatepackage(Garage);
package Garage
{
   function Player::activatestuff(%this)
   {
      parent::activatestuff(%this);
      %this.displayVehicleInfos();
   }
};
activatepackage(Garage);
function servercmdCustomHelp(%c)
{
   %c.chatMessage("<font:impact:20>\c4How to make a custom vehicle:");
   %c.chatMessage("<font:impact:20>\c6Look at a vehicle or get in it and type a command:");
   %c.chatMessage("<font:impact:20>\c4/getParts\c6 for a list of all parts");
   %c.chatMessage("<font:impact:20>\c4/setPart Part Name\c6, example: \c4/setPart Hood Super");
   %c.chatMessage("<font:impact:20>\c4/colorPart Part R G B\c6, example: \c4/colorPart Hood 1 1 0");
   %c.chatMessage("<font:impact:20>\c4/paintPart Part\c6, to set a part color to paint can color");
   %c.chatMessage("<font:impact:20>\c4/defaultParts\c6, to reset a vehicles parts to default");
   %c.chatMessage("<font:impact:20>\c6Click a car to see its specs");
   
}
function servercmdGarage_ClientEdit(%c,%w)
{
   if(!%w)
   {
      %c.Garage_Editing=0;
      return;
   }
   if(!isObject(%p=%c.player))
      return;
   if(!isObject(%p.getObjectMount()))
   {
      %start = %p.getEyePoint();
      %ray = containerRaycast(%start,vectorAdd(%start,vectorScale(%p.getEyeVector(),10)),($TypeMasks::VehicleObjectType),%p);
      %col = firstWord(%ray);
   }
   else
      %col=%p.getObjectMount();
   if(!isObject(%col))
      return;
   if(!%col.getDatablock().isCustom)
      return;
   if(getTrustLevel(%c,%col)<2&&!%c.isAdmin)
      return;
   %c.Garage_Editing=%col;
   commandToClient(%c,'Garage_setDatablock',%col.getDatablock(),%type=%col.getDatablock().type);
   for(%j=0;%j<$Garage::Parts[%type];%j++)
   {
      commandToClient(%c,'Garage_setPart',$Garage::Part[%type,%j],%col.part[%type,$Garage::Part[%type,%j]]);
      commandToClient(%c,'Garage_colorPart',$Garage::Part[%type,%j],%col.partColor[%type,$Garage::Part[%type,%j]]);
   }
}