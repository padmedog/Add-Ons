//Tc572(Block Builder) & HellsHero
//Charged shot & Other by HellsHero
//Effects & Base by Tc572

//Audio
datablock AudioProfile(BeamfireSound)
{
   filename    = "./Sound/Beamfire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(Chargeloop)
{
   filename    = "./Sound/Chargeloop.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(BeamchargestartASound)
{
   filename    = "./Sound/BeamchargestartA.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(BeamchargestartBSound)
{
   filename    = "./Sound/BeamchargestartB.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(MissilefireSound)
{
   filename    = "./Sound/Missilefire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(BeamhitSound)
{
   filename    = "./Sound/Beamhit.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ChargebeamfireSound)
{
   filename    = "./Sound/Chargebeamfire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(BeamswitchSound)
{
   filename    = "./Sound/Beamswitch.wav";
   description = AudioClose3d;
   preload = true;
};

//Visual
datablock ParticleData(BeamTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 100;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 1000.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0.9 0.9 0 0.8";
   	colors[1]     = "0.9 0.2 0 0.8";
	sizes[0]	= 1.2;
	sizes[1]	= 1.0;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(BeamTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 5; //0.25;
   velocityVariance = 5; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = BeamTrailParticle;
};

datablock ParticleData(BeamTrailParticle2)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 100;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 500.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "1.0 0.8 0 0.6";
   	colors[1]     = "1.0 0.2 0 0.5";
   	sizes[0]	= 1.0;
	sizes[1]	= 0.8;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(BeamTrailEmitter2)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 5; //0.25;
   velocityVariance = 5; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = BeamTrailParticle2;
};

datablock ParticleData(Beam2TrailParticle) //Charged Beam
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 100;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 1000.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0.0 0.9 0.9 0.8"; // 0 229.5 229.5 204
   	colors[1]     = "0.0 0.2 0.9 0.8"; // 0 51 229.5 204
   	sizes[0]	= 1.2;
	sizes[1]	= 1.0;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(Beam2TrailEmitter)
{
	ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 5; //0.25;
   velocityVariance = 5; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = Beam2TrailParticle;
};

datablock ParticleData(Beam2TrailParticle2)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 100;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 500.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0 0 1.0 0.6";
   	colors[1]     = "0 0 1.0 0.5";
   	sizes[0]	= 1.0;
	sizes[1]	= 0.8;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(Beam2TrailEmitter2)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 5; //0.25;
   velocityVariance = 5; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = Beam2TrailParticle2;
};

datablock ParticleData(BeamExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 1;
	inheritedVelFactor   = 0.4;
	constantAcceleration = 0.0;
	lifetimeMS           = 900;
	lifetimeVarianceMS   = 800;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 100.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.9 0.3";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.55;
	sizes[1]      = 1.15;

	useInvAlpha = false;
};
datablock ParticleEmitterData(BeamExplosionEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "BeamExplosionParticle";

   useEmitterColors = true;
   uiName = "Beam Hit Dust";
};

datablock ExplosionData(BeamExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 190;

   soundProfile = BeamhitSound;

   emitter[0] = BeamExplosionEmitter;
   particleDensity = 4000;
   particleRadius = 5.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;

   // Dynamic light
   lightStartRadius = 4;
   lightEndRadius = 3;
   lightStartColor = "0.45 0.3 0.1"; // 114.75 25.5 76.5
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 2;
   impulseForce = 5;

   //radius damage
   radiusDamage        = 1;
   damageRadius        = 0;
};

datablock ExplosionData(Beam2Explosion)
{
   //explosionShape = "";
   lifeTimeMS = 190;

   soundProfile = BeamhitSound;

   emitter[0] = BeamExplosionEmitter;
   particleDensity = 4000;
   particleRadius = 5.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;

   // Dynamic light
   lightStartRadius = 4;
   lightEndRadius = 3;
   lightStartColor = "0.1 0.3 0.45"; // 25.5 76.5 114.75 (Decimal*255)
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 3;
   impulseForce = 9;

   //radius damage
   radiusDamage        = 5;
   damageRadius        = 1;
};

datablock ParticleData(MissileTrailParticle)
{
	dragCoefficient		= 2.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 305;
	lifetimeVarianceMS	= 250;
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "./dot";

	// Interpolation variables
	colors[0]     = "0.0 0.0 0.8 0.5";
   	colors[1]     = "0.0 0.0 0.9 0.4";
	sizes[0]	= 0.15;
	sizes[1]	= 0.45;
	times[0]	= 0.0;
	times[1]	= 0.4;
};

datablock ParticleEmitterData(MissileTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 4; //0.25;
   velocityVariance = 3; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = MissileTrailParticle;
	
};

datablock ParticleData(MissileExplosionParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = 0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.3 0.4 0.3";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.45;
	sizes[1]      = 0.95;

	useInvAlpha = false;
};

datablock ParticleEmitterData(MissileExplosionEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MissileExplosionParticle";

   useEmitterColors = true;
   uiName = "Missile Explosion Smoke";
   emitterNode = TenthEmitterNode;
};

datablock ExplosionData(MissileExplosion)
{

   lifeTimeMS = 100;

   soundProfile = BeamhitSound;

   emitter[0] = MissileExplosionEmitter;
   particleDensity = 10;
   particleRadius = 6.2;

   faceViewer     = true;
   explosionScale = "0.9 0.9 0.9";

   shakeCamera = false;

   // Dynamic light
   lightStartRadius = 4;
   lightEndRadius = 3;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 3.5;
   impulseForce = 650;

   //radius damage
   radiusDamage        = 20;
   damageRadius        = 1.5;
};


AddDamageType("Beam",   '<bitmap:add-ons/Weapon_TcPowerBeam/Images/CI_beam> %1',    '%2 <bitmap:add-ons/Weapon_TcPowerBeam/Images/CI_beam> %1',0.2,1);
AddDamageType("BeamCharged",   '<bitmap:add-ons/Weapon_TcPowerBeam/Images/CI_beamcharged> %1',    '%2 <bitmap:add-ons/Weapon_TcPowerBeam/Images/CI_beamcharged> %1',0.2,1);
AddDamageType("Missile",   '<bitmap:add-ons/Weapon_TcPowerBeam/Images/CI_Missile> %1',    '%2 <bitmap:add-ons/Weapon_TcPowerBeam/Images/CI_Missile> %1',0.2,1);
datablock ProjectileData(BeamProjectile)
{
   projectileShapeName = "";
   directDamage        = 8;
   directDamageType    = $DamageType::Beam;
   radiusDamageType    = $DamageType::Beam;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 1;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 10;
   verticalImpulse	  = 10;
   explosion           = BeamExplosion;
   particleEmitter     = BeamTrailEmitter;
   particleEmitter2    = BeamTrailEmitter2;

   muzzleVelocity      = 96;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Power Beam";
};
datablock ProjectileData(BeamChargedProjectile)
{
   projectileShapeName = "";
   directDamage        = 28;
   directDamageType    = $DamageType::BeamCharged;
   radiusDamageType    = $DamageType::BeamCharged;

   brickExplosionRadius = 1;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 3;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 10;
   verticalImpulse	  = 10;
   explosion           = Beam2Explosion;
   particleEmitter     = Beam2TrailEmitter;
   particleEmitter2    = Beam2TrailEmitter2;

   muzzleVelocity      = 136;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Power Beam, Charged";
};

datablock ProjectileData(MissileProjectile)
{
   projectileShapeName = "add-ons/weapon_rocket_launcher/rocketprojectile.dts";
   directDamage        = 25;
   directDamageType    = $DamageType::Missile;
   radiusDamageType    = $DamageType::Missile;

   brickExplosionRadius = 1.5;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 12;
   brickExplosionMaxVolume = 4;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 10;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 250;
   verticalImpulse	  = 250;
   explosion           = MissileExplosion;
   particleEmitter     = MissileTrailEmitter;

   muzzleVelocity      = 72;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.1;
   isBallistic         = false;
   gravityMod = 0.04;

   hasLight    = true;
   lightRadius = 1.0;
   lightColor  = "0 0.1 1.0";

   uiName = "Missile";
};

//////////
// item //
//////////
datablock ItemData(PowerBeamItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Model/ArmCannon.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "PowerBeam";
	iconName = "./Images/icon_powerbeam";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = BeamImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(beamImage)
{
   // Basic Item properties
   shapeFile = "./Model/ArmCannon.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BeamItem;
   ammo = " ";
   projectile = BeamProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = GunItem.colorShiftColor;//"0.400 0.196 0 0.100";

   //casing = " ";

   // The Power beam is designed to fire multiple shots before beginning the charging
   // sequence. This was heavily edited from the gun and spear script.


   // Initial start up state
	stateName[0]					= "Activate";
	stateTimeoutValue[0]			= 0.2;
	stateTransitionOnTimeout[0]		= "Ready";
	stateSequence[0]				= "ready";
	stateSound[0]					= BeamswitchSound;

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "FireA";
	stateAllowImageChange[1]		= true;

	stateName[2]					= "FireA";
	stateTransitionOnTimeout[2]		= "FireB";
	stateTimeoutValue[2]			= 0.15;
	stateTransitionOnTriggerUp[2]	= "Ready";
	stateFire[2]					= true;
	stateSequence[2]				= "fire";
	stateScript[2]					= "onFire";
	stateWaitForTimeout[2]			= true;
	stateAllowImageChange[2]		= false;
	stateSound[2]					= BeamFireSound;

	stateName[3]					= "FireB";
	stateTransitionOnTimeout[3]		= "FireC";
	stateTimeoutValue[3]			= 0.1;
	stateTransitionOnTriggerUp[3]	= "Ready";
	stateFire[3]					= true;
	stateSequence[3]				= "fire";
	stateScript[3]					= "onFire";
	stateWaitForTimeout[3]			= true;
	stateAllowImageChange[3]		= false;
	stateSound[3]					= BeamFireSound;

	stateName[4]					= "FireC";
	stateTransitionOnTimeout[4]		= "ChargeA";
	stateTimeoutValue[4]			= 0.1;
	StateTransitionOnTriggerUp[4]	= "Ready";
	stateFire[4]					= true;
	stateSequence[4]				= "fire";
	stateScript[4]					= "onFire";
	stateWaitForTimeout[4]			= true;
	stateAllowImageChange[4]		= false;
	stateSound[4]					= BeamFireSound;

	stateName[5]					= "ChargeA";
	stateTransitionOnTimeout[5]		= "ChargeB";
	stateScript[5]					= "onCharge";
	stateTimeoutValue[5]			= 0.6;
	stateWaitForTimeout[5]			= False;
	stateTransitionOnTriggerUp[5]	= "AbortCharge";
	stateAllowImageChange[5]		= false;
	stateSound[5]					= BeamchargestartAsound;

	stateName[6]					= "ChargeB";
	stateTransitionOnTimeout[6]		= "Armed";
	stateScript[6]					= "onCharge";
	stateTimeoutValue[6]			= 0.7;
	stateWaitForTimeout[6]			= False;
	stateTransitionOnTriggerUp[6]	= "AbortCharge";
	stateAllowImageChange[6]		= false;
	stateSound[6]					= BeamchargestartBsound;

	stateName[7]					= "AbortCharge";
	stateTransitionOnTimeout[7]		= "Ready";
	stateTimeoutValue[7]			= 0.1;
	stateWaitForTimeout[7]			= true;
	stateScript[7]					= "onAbortCharge";
	stateFire[7]					= true;
	stateSequence[7]				= "fire";
	stateScript[7]					= "onFire";
	stateAllowImageChange[7]		= false;
	stateSound[7]					= BeamFireSound;

	stateName[8]					= "Armed";
	stateTransitionOnTriggerUp[8]	= "Firecharge";
	stateSequence[8]				= "Armed";
	stateAllowImageChange[8]		= false;		
	stateSound[8]					= Chargeloop;

	stateName[9]					= "Firecharge";
	stateTransitionOnTimeout[9]		= "Ready";
	stateTimeoutValue[9]			= 0.4;
	stateSequence[9]				= "fire";
	stateScript[9]					= "onFireCharged";
	stateWaitForTimeout[9]			= true;
	stateAllowImageChange[9]		= false;
	stateSound[9]					= ChargebeamfireSound;

};

function BeamImage::onMount(%this,%obj,%slot) //We use this to hide the right hand/hook.
{
	Parent::onMount(%this,%obj,%slot);
	%obj.hideNode("RHand");
	%obj.hideNode("RHook");
}

function BeamImage::onUnMount(%this,%obj,%slot) //We use this to unHide the right hand. (And to make sure everything is proper.)
{
	Parent::onMount(%this,%obj,%slot);
	%obj.unHideNode("ALL");
	if(isObject(%obj.client))
	{
		%obj.client.applyBodyParts();
		%obj.client.applyBodyColors();
	}
	else
		applyDefaultCharacterPrefs(%obj);
}

function BeamImage::onFireCharged(%this,%obj,%slot) //This is what makes it shoot charged projectiles.
{
	%projectile = BeamChargedProjectile;
	%spread = 0.00;
	%shellcount = 1;
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

// This is the "Fire missile on right click" part. "Borrowed" from the Mp7 :P
package Powerbeam
{
  	function Armor::onTrigger(%this, %player, %slot, %val)
	{
		if(%player.getMountedImage(0) $= BeamImage.getID() && %slot $= 4 && %val)
		{
			if(%player.lastRocket !$= "" && getSimTime() - %player.lastRocket < 1000)
			{
				return;
			}
			%projectile = MissileProjectile;
			%vector = %player.getMuzzleVector(0);
			%objectVelocity = %player.getVelocity();
			%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
			%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
			%velocity = VectorAdd(%vector1,%vector2);
			%p = new Projectile()
			{
				dataBlock = %projectile;
				initialVelocity = %velocity;
				initialPosition = %player.getMuzzlePoint(0);
				sourceObject = %player;
				sourceSlot = 0;
				client = %player.client;
			};
			%player.lastRocket = getSimTime();
			serverPlay3D(MissilefireSound,%player.getPosition());
			MissionCleanup.add(%p);
			return %p;
		 
		}

		Parent::onTrigger(%this, %player, %slot, %val);
	}
};	
ActivatePackage(Powerbeam);	