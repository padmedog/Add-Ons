//Spinning Saw Blade

$JVS::Content::Type::animationLengthStart = 200;
$JVS::Content::Type::animationLengthStop = 500;
$JVS::Content::Type::animationNameStartCCW = "spin";
$JVS::Content::Type::animationNameStartCW = "spin";
$JVS::Content::Type::animationNameStopCCW = "stop";
$JVS::Content::Type::animationNameStopCW = "stop";
$JVS::Content::Type::brickFile = "Add-Ons/content_phydeouxTraps/bricks/1_6_15s.blb";
$JVS::Content::Type::brickSearches = 0;
$JVS::Content::Type::brickSize = 1 TAB 6 TAB 15;
$JVS::Content::Type::brickSubcategory = "Phytraps";
$JVS::Content::Type::datablockBrick = "contentBrickSpinningSawBlade";
$JVS::Content::Type::datablockDebris = "contentDebrisSawBlade";
$JVS::Content::Type::datablockExplosion = "contentExplosionSpinningSawBlade";
$JVS::Content::Type::datablockProjectile = "contentProjectileSpinningSawBlade";
$JVS::Content::Type::datablockShape = "contentShapeSawBlade";
$JVS::Content::Type::datablockShapeColliding = "contentShapeSawBladeColliding";
$JVS::Content::Type::datablockSoundStart = "contentSoundStartlightswitch";
$JVS::Content::Type::datablockSoundStop = "contentSoundStopLightswitch";
$JVS::Content::Type::eventCount = 10;

$JVS::Content::Type::eventEnabled[0] = 0;
$JVS::Content::Type::eventDelay[0] = 0;
$JVS::Content::Type::eventInput[0] = "\"onPlayerTouch\"";
$JVS::Content::Type::eventTarget[0] = "\"Player\"";
$JVS::Content::Type::eventOutput[0] = "\"AddHealth\"";
$JVS::Content::Type::eventParameterCount[0] = 1;
$JVS::Content::Type::eventParameter[0 @ "_" @ 0] = -50;

$JVS::Content::Type::eventEnabled[1] = 1;
$JVS::Content::Type::eventDelay[1] = "ContentTypesSO.getSoundDelayStartFromID(%contentTypeID)";
$JVS::Content::Type::eventInput[1] = "\"onContentStart\"";
$JVS::Content::Type::eventTarget[1] = "\"Self\"";
$JVS::Content::Type::eventOutput[1] = "\"playSound\"";
$JVS::Content::Type::eventParameterCount[1] = 1;
$JVS::Content::Type::eventParameter[1 @ "_" @ 0] = "ContentTypesSO.getDatablockSoundStartFromID(%contentTypeID)";

$JVS::Content::Type::eventEnabled[2] = 1;
$JVS::Content::Type::eventDelay[2] = "ContentTypesSO.getSoundDelayStopFromID(%contentTypeID)";
$JVS::Content::Type::eventInput[2] = "\"onContentStop\"";
$JVS::Content::Type::eventTarget[2] = "\"Self\"";
$JVS::Content::Type::eventOutput[2] = "\"playSound\"";
$JVS::Content::Type::eventParameterCount[2] = 1;
$JVS::Content::Type::eventParameter[2 @ "_" @ 0] = "ContentTypesSO.getDatablockSoundStopFromID(%contentTypeID)";

$JVS::Content::Type::eventEnabled[3] = 1;
$JVS::Content::Type::eventDelay[3] = 0;
$JVS::Content::Type::eventInput[3] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[3] = "\"Self\"";
$JVS::Content::Type::eventOutput[3] = "\"setColliding\"";
$JVS::Content::Type::eventParameterCount[3] = 1;
$JVS::Content::Type::eventParameter[3 @ "_" @ 0] = 0;

$JVS::Content::Type::eventEnabled[4] = 1;
$JVS::Content::Type::eventDelay[4] = 0;
$JVS::Content::Type::eventInput[4] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[4] = "\"Self\"";
$JVS::Content::Type::eventOutput[4] = "\"setRaycasting\"";
$JVS::Content::Type::eventParameterCount[4] = 1;
$JVS::Content::Type::eventParameter[4 @ "_" @ 0] = 1;

$JVS::Content::Type::eventEnabled[5] = 1;
$JVS::Content::Type::eventDelay[5] = 0;
$JVS::Content::Type::eventInput[5] = "\"onContentCreated\"";
$JVS::Content::Type::eventTarget[5] = "\"Self\"";
$JVS::Content::Type::eventOutput[5] = "\"setRendering\"";
$JVS::Content::Type::eventParameterCount[5] = 1;
$JVS::Content::Type::eventParameter[5 @ "_" @ 0] = 0;

$JVS::Content::Type::eventEnabled[6] = 1;
$JVS::Content::Type::eventDelay[6] = 0;
$JVS::Content::Type::eventInput[6] = "\"onContentStarted\"";
$JVS::Content::Type::eventTarget[6] = "\"Self\"";
$JVS::Content::Type::eventOutput[6] = "\"toggleEventEnabled\"";
$JVS::Content::Type::eventParameterCount[6] = 1;
$JVS::Content::Type::eventParameter[6 @ "_" @ 0] = "\"0\"";

$JVS::Content::Type::eventEnabled[7] = 1;
$JVS::Content::Type::eventDelay[7] = 0;
$JVS::Content::Type::eventInput[7] = "\"onContentStopped\"";
$JVS::Content::Type::eventTarget[7] = "\"Self\"";
$JVS::Content::Type::eventOutput[7] = "\"toggleEventEnabled\"";
$JVS::Content::Type::eventParameterCount[7] = 1;
$JVS::Content::Type::eventParameter[7 @ "_" @ 0] = "\"0\"";

$JVS::Content::Type::eventEnabled[8] = 1;
$JVS::Content::Type::eventDelay[8] = 0;
$JVS::Content::Type::eventInput[8] = "\"onContentStart\"";
$JVS::Content::Type::eventTarget[8] = "\"Self\"";
$JVS::Content::Type::eventOutput[8] = "\"setColliding\"";
$JVS::Content::Type::eventParameterCount[8] = 1;
$JVS::Content::Type::eventParameter[8 @ "_" @ 0] = 1;

$JVS::Content::Type::eventEnabled[9] = 1;
$JVS::Content::Type::eventDelay[9] = 0;
$JVS::Content::Type::eventInput[9] = "\"onContentStop\"";
$JVS::Content::Type::eventTarget[9] = "\"Self\"";
$JVS::Content::Type::eventOutput[9] = "\"setColliding\"";
$JVS::Content::Type::eventParameterCount[9] = 1;
$JVS::Content::Type::eventParameter[9 @ "_" @ 0] = 0;

$JVS::Content::Type::nodeCount = 3;
$JVS::Content::Type::nodeColor0 = Color;
$JVS::Content::Type::nodeColor1 = "0.5 0.5 0.5 1.0";
$JVS::Content::Type::nodeColor2 = black25;
$JVS::Content::Type::nodeName0 = "blade";
$JVS::Content::Type::nodeName1 = "axis";
$JVS::Content::Type::nodeName2 = "tips";
$JVS::Content::Type::soundDelayStart = 0;
$JVS::Content::Type::soundDelayStop = 0;
$JVS::Content::Type::uiName = "Spinning Saw Blade";
