//-----------------------------------------------------------------------------
// Script_Mute
// Made by Solar, fixed for v13 by Mr.Wheehaw
//-----------------------------------------------------------------------------

package mute
{
   function serverCmdmute(%client, %victim, %time)
   {
      if(%client.isAdmin || %client.isSuperAdmin)
      {
         %victim = findClientByName(%victim);
         if(%victim != 0)
         {
            if(%victim.isMuted)
            {
               messageClient(%client,'',"This person has already been muted.");
               return;
            }
            %victim.isMuted = true;
            messageClient(%victim, '', '\c3You have been muted by \c6%1\c3 for \c6%2\c3 seconds.', %client.name, %time);
            %time *= 1000;
            %victim.muteSchedule = schedule(%time, 0, muteTimeUp, %victim);
         }
         else
         {
            messageClient(%client,'',"Player not found!");
         }
         return;
      }
      messageClient(%client,'',"You are not an admin!");
   }
   function muteTimeUp(%client)
   {
      %client.isMuted = false;
      messageClient(%client, '', '\c3Your mute time is up. You can now talk.');
   }
   function serverCmdunMute(%client, %victim)
   {
      if(%client.isAdmin || %client.isSuperAdmin)
      {
         %victim = findClientByName(%victim);
         if(%victim != 0)
         {
            if(!%victim.isMuted)
            {
               messageClient(%client, '', 'This person is not muted.');
               return;
            }
            %victim.isMuted = false;
            messageClient(%victim, '', '\c3You have been unmuted by \c6%1\c3.', %client.name);
            cancel(%victim.muteSchedule);
         }
         else
         {
            messageClient(%client,'',"Player not found!");
         }
         return;
      }
      messageClient(%client, '', 'You are not an admin!');
   }
   function serverCmdmessageSent(%client, %text)
   {
      if(%client.isMuted)
      {
         messageClient(%client,'',"You have been muted, you cannot talk!");
         return;
      }
      parent::serverCmdmessageSent(%client, %text);
   }
};
activatePackage(mute);