//gun.cs

datablock AudioProfile(nitrostreamFireSound)
{
   filename    = "./nitrostream_loop.wav";
   description = AudioCloseLooping3d;
   preload = true;
};
datablock AudioProfile(nitrostreamStartSound)
{
   filename    = "./nitrostream_fire.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(nitrostreamEndSound)
{
   filename    = "./flamethrower_end.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(nitrostreamProjectileParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = -2;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 325;
	lifetimeVarianceMS   = 255;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 16.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.8 0.8 0.8 0.5";
	colors[1]     = "0.9 0.6 0.3 0.8";
	colors[2]     = "0.9 0.3 0.1 0.4";
	colors[3]     = "0.9 0.3 0.1 0.1";
	sizes[0]      = 0.35;
	sizes[1]      = 0.4;
	sizes[2]      = 1.05;
	sizes[3]      = 2.9;
   times[0] = 0.0;
   times[1] = 0.3;
   times[2] = 0.6;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(nitrostreamProjectileEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 70;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "nitrostreamProjectileParticle";
};

datablock ParticleData(nitrostreamJetParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 50;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/cloud";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

	colors[0]     = "0.8 0.8 0.8 0.0";
    colors[1]     = "1.0 1 1 0.1";
    colors[2]     = "1.0 1 1 0.1";
    colors[3]     = "1 1 1 0";

	sizes[0]      = 0.35;
	sizes[1]      = 0.4;
	sizes[2]      = 0.05;
	sizes[3]      = 1.9;

   times[0] = 0.0;
   times[1] = 0.3;
   times[2] = 0.6;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(nitrostreamJetEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "nitrostreamJetParticle";
};

datablock DebrisData(nitrostreamJetDebris)
{
	shapeFile = "";
   	emitters = "nitrostreamJetEmitter";

	lifetime = 0.25;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;
	spinSpeed			= 300.0;
	minSpinSpeed = -600.0;
	maxSpinSpeed = 600.0;

	gravModifier = 0.25;
};

AddDamageType("nitrostream",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_flamethrower> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_flamethrower> %1',0.2,1);
datablock ProjectileData(nitrostreamProjectile : gunProjectile)
{
   projectileShapeName = "";
   directDamage        = 14;
   directDamageType    = $DamageType::nitrostream;
   radiusDamageType    = $DamageType::nitrostream;

   impactImpulse	     = 50;
   verticalImpulse	  = 20;
   explosion           = "";
   //particleEmitter     = nitrostreamFireEmitter; //bulletTrailEmitter;

   muzzleVelocity      = 190;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 150;
   fadeDelay           = 150;
   bounceElasticity    = 0.3;
   bounceFriction      = 0.60;
   isBallistic         = true;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(nitrostreamItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./new_flamethrower.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Flamethrower";
	iconName = "./flamethrower";
	doColorShift = true;
	colorShiftColor = "0.44 0.42 0.4 1.000";

	 // Dynamic properties defined by the scripts
	image = nitrostreamImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(nitrostreamImage)
{
   // Basic Item properties
	shapeFile = "./new_flamethrower.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 -0.13";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = nitrostreamProjectile;
   projectileType = Projectile;

	casing = nitrostreamJetDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0.2";
	shellExitVariance   = 7.0;	
	shellVelocity       = 9.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = nitrostreamItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Prefire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Fire";
	stateTransitionOnTriggerUp[2]  = "Endfire";
	stateTimeoutValue[2]            = 0.06;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= nitrostreamProjectileEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= nitrostreamFireSound;
	stateEjectShell[2]       = true;

	stateName[3]                     = "Prefire";
	stateTimeoutValue[3]             = 0.01;
	stateTransitionOnTriggerUp[3]  = "Endfire";
	stateTransitionOnTimeout[3]       = "Fire";
	stateSound[3]					= nitrostreamStartSound;

	stateName[4]                     = "Endfire";
	stateTimeoutValue[4]             = 0.01;
	stateTransitionOnTimeout[4]       = "Ready";
	stateSound[4]					= nitrostreamEndSound;
};

function nitrostreamImage::onFire(%this,%obj,%slot)
{
	%projectile = nitrostreamProjectile;
	%spread = 0.002;
	%shellcount = 1;
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function nitrostreamProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 10;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {     
      %col.damage(%obj, %pos, %directDamage, %damageType);
	%col.mountImage(afterburnImage, 2);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}
