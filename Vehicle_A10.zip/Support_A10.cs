//Warning: This is specific to my A10
package A10shootOnClick_Pack
{	
	//Next seat => switch weapons
	function serverCmdNextSeat(%client)
	{

		%p = %client.player;
		if(!isobject(%p.getobjectmount()))
			return Parent::serverCmdNextSeat(%client);

				if(%p.getobjectmount().getdatablock() == A10vehicle.getid())
				{
			
	
				%jet = %p.getobjectmount();
				//applies the settings for each weapon
				switch (%jet.weaponi)
					{
					case 1:
					%jet.weaponi = 2;
					%jet.weapon = "AGM-114 Hellfire Missile";
					case 0:
					%jet.weaponi = 1;
					%jet.weapon = "6x LAU-10 Rocket Pod <color:0000FF>" @ %jet.ammo[%jet.weaponi] @ "/12";
					case 2:
					%jet.weaponi = 0;
					%jet.weapon = "GAU-8/A Minigun";
					}
				}
				else
				{	
				Parent::serverCmdNextSeat(%client);
				}	
			
		
		
	}
	//Deploy flares
	function serverCmdPrevSeat(%client)
	{

		if(isObject(%client.player))
		{
			%p = %client.player;
			
			if(%p.getobjectmount())
			{	
		
				
				if(%p.getobjectmount().getdatablock() == A10vehicle.getid())
				{
					if($Sim::Time<%client.flaredelay)
					{
						return;
					}
					%jet = %p.getobjectmount();

					%jet.flaresDeployed=true;
					%jet.islocked=false;
					//%jet.lockstat="";

						
					%p.A10SOC_Shoot(%slot,1,3);
					%client.flaredelay=$Sim::Time+7000/1000;
				}
				else
				{	
				Parent::serverCmdPrevSeat(%client);
				}	
			}
		}
	}
	function armor::onTrigger(%db,%obj,%slot,%val)
	{	
		if(%obj.getObjectmount() == 0)
		return Parent::onTrigger(%db,%obj,%slot,%val);
		
		if(%obj.getObjectmount().getDatablock() == A10Vehicle.getID())
		{
			%jet=%obj.getObjectmount();
			if(%obj.getClassName()$="Player")
			{
				if(%slot==0)
				{
					if(%val)
					{
						if($Sim::Time<%obj.client.A10SOC_LastFireTime[%obj.getObjectmount().getid().weaponi])
						{
							return;
						}
						
					}
					if(%jet.A10gear == 1)	//if landing gear is up lets the plane shoot
					{
						%obj.A10SOC_Shoot(%slot,%val,%jet.weaponi);
					}
				}
			}
		}
		return Parent::onTrigger(%db,%obj,%slot,%val);
	}
	function Projectile::onAdd(%obj,%a,%b)
	{
		if(%obj.dataBlock.getID() == RocketPodProjectile.getID())
		{
		%obj.initialvelocity=vectorscale(vectorNormalize(%obj.initialvelocity),200);
		}
		if(%obj.dataBlock.getID() == A10CannonProjectile.getID())
		{
		%obj.initialvelocity=vectorscale(vectorNormalize(%obj.initialvelocity),700);
		}
		
		
		Parent::onAdd(%obj,%a,%b);
	}

};
ActivatePackage(A10shootOnClick_Pack);
//Gun Temperature Checker
function A10Vehicle::tempRegenTick(%data,%this)
{
	cancel(%this.tempRegenTick);
	if(!isObject(%this))
		return;

	%this.temp = mClampF(%this.temp + 1,0,%data.maxtemp);
	%o = %this.getMountedObject(0);
	%this.getMountedObject(1).isCloaked = 1;
	
	if(%this.temp < %data.maxtemp)
	{
		%this.tempRegenTick = %data.schedule(%data.tempRegenTime,"tempRegenTick",%this);
	}
}
//Self Explanitory
function A10Vehicle::onReload(%this,%obj,%weaponi)
{
	if(!isobject(%obj))
		return;
	%obj.ammo[%weaponi]=%obj.getDatablock().A10shootOnClick_Ammo[%weaponi];
	if(%obj.weaponi==1)
		%obj.weapon = "6x LAU-10 Rocket Pod <color:0000FF>" @ %obj.ammo[%weaponi] @ "/12";
}

function repeatedVectorAddwithScale(%vecs)
{
	%vec="0 0 0";
	%cnt=getFieldCount(%vecs);
	for(%i=0;%i<%cnt;%i++)
	{
		%fld=getField(%vecs,%i);
		%tvec=getWords(%fld,0,3);
		%scale=getWord(%fld,3);
		%svec=vectorScale(%tvec,%scale);
		%vec=vectorAdd(%vec,%svec);
	}
	return %vec;
}

function SimObject::getLeftVector(%obj)
{
	return vectorCross(%obj.getEyeVector(),%obj.getUpVector());
}

function SimObject::getRightVector(%obj)
{
	return vectorScale(%obj.getLeftVector(%obj),-1);
}
//Main shooting function
function Player::A10SOC_Shoot(%obj,%slot,%val,%weaponi)
{
	if(!%val) {cancel(%obj.A10SOC_reshoot);return;}	//if not val
	
	if(!isObject(%obj.getObjectMount())) {return;}	//if driver is object
	
	%jet= %obj.getObjectMount();
	%data= %jet.getDatablock();
	%mountObj= %jet.getMountNodeObject(%data.A10shootOnClick_RequiredSlot[%weaponi]);
	
	if(%mountObj!$=%Obj) {return;}
	
	if(%data.A10shootOnClick)	
	{
		if(%jet.getDatablock() == A10Vehicle.getID())
		{
					%cnt=%data.A10shootOnClick_ProjectileCount[%weaponi];
					for(%i=0;%i<%cnt;%i++)
					{
						//Handles Gun Temperature
						%temp = mClampF(%jet.temp,0,%data.maxtemp);
						if(%temp <= 0)
						{
							
							if(%data.A10shootOnClick_Hold[%weaponi])
								{
									%obj.A10SOC_reshoot= %obj.schedule(%data.A10shootOnClick_ReshootDelay[%weaponi],A10SOC_Shoot,%slot,%val,%weaponi);
								}
							return;
						} 
						else 
						{
							%jet.temp = mClampF(%jet.temp - 1,0,%data.maxtemp - 1);
							cancel(%jet.tempRegenTick);
							%jet.tempRegenTick = %data.schedule(%data.tempRegenTime,"tempRegenTick",%jet);
						}
						%pos= %jet.getPosition();
						//slot specific functions
						
						
						//alternate firing pos
						if(%data.A10ShootOnClick_Alternate[%weaponi]==true)
						{
							if(%jet.left==true)
							{
								%PVec= %data.A10shootOnClick_Position[%i,%weaponi];
								%VVec= %data.A10shootOnClick_Velocity[%i,%weaponi];
								%jet.left=false;
							}
							else
							{
								%PVec= %data.A10ShootOnClick_PositionB[%i,%weaponi];
								%VVec= %data.A10shootOnClick_VelocityB[%i,%weaponi];
								%jet.left=true;
							}
						}
						else
						{
						%PVec= %data.A10shootOnClick_Position[%i,%weaponi];
						%VVec= %data.A10shootOnClick_Velocity[%i,%weaponi];
						}



						%iPos= repeatedVectorAddwithScale(
						%jet.getEyeVector() SPC getWord(%PVec,0) TAB
						%jet.getLeftVector() SPC getWord(%PVec,1) TAB
						%jet.getUpVector() SPC getWord(%PVec,2)
						);
						%iVel= repeatedVectorAddwithScale(
						%jet.getEyeVector() SPC getWord(%VVec,0) TAB
						%jet.getLeftVector() SPC getWord(%VVec,1) TAB
						%jet.getUpVector() SPC getWord(%VVec,2)
						);
						//spread code
						%spread = %data.A10shootOnClick_Spread[%i,%weaponi];
						%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
						%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
						%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
						%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
						%velocity = MatrixMulVector(%mat, %iVel);
						//end spread
						
						%scale=%data.A10shootOnClick_Scale[%i,%weaponi];
						if(%scale$="") 
							%scale="1 1 1";
						
						switch(%weaponi)
						{
							case 0://minigun
								%jet.turret.playthread(0,"fire");
								%PVec= %data.A10shootOnClick_Position[%i,%weaponi];
							case 1://rocketpod + ammo
								%jet.weapon = "6x LAU-10 Rocket Pod  <color:0000FF>" @ %jet.ammo[%weaponi] @"/12";
								if(%jet.ammo[%weaponi]==0)
								{
									%data.schedule(%data.A10shootOnClick_Reloadtime[%weaponi],"onReload",%jet,%weaponi);
									return;
								}
								else
									%jet.ammo[%weaponi]--;
							case 2://AGM
								if(%jet.missilefired==true)	//detonate missile
								{
									if(!isobject(%jet.missile))
										return;
									%missile = %jet.missile;
									
										if(getSimTime() < %missile.creationtime+1000)
										return;

										if(%missile.destroyed)
											return;
											
										%missile.setDamageLevel(0);
										%missile.destroyed = 1;

										%trans = %missile.getTransform();
										%t = new Projectile()
										{
											dataBlock = A10MissileExplosionProjectile;
											initialVelocity  = "0 0 0";
											initialPosition  = %trans;
											client = %missile.owner.client;
											sourceClient = %missile.owner.client;
										};
										MissionCleanup.add(%t);
									
										%missile.schedule(10,"delete");
									
								}
								else
								{
									serverPlay3d(%data.A10shootOnClick_fireSound[%weaponi],%pos);
									%jet.missilefired=true;
									%eye = %jet.getTransform();
									%muzPos = vectorAdd(%pos,%iPos);
									%velocity = Vectoradd(%jet.getforwardvector(), %jet.getvelocity());
									
									%p = new WheeledVehicle()
									{
										dataBlock = A10MissileVehicle;
										position= %muzPos SPC getWord(%eye,3) SPC getWord(%eye,4) SPC getWord(%eye,5) SPC getWord(%eye,6);

									};
									%p.setVelocity(vectorscale(%velocity,1));
									%p.owner=%obj;
									%p.setTransform(%muzPos SPC getWord(%eye,3) SPC getWord(%eye,4) SPC getWord(%eye,5) SPC getWord(%eye,6));
									
									%jet.getmountedobject(0).setcontrolobject(%p);
									%jet.missile=%p;
								}
							case 3://flares
								%jet.flaresDeployed=false;
							
						}
						if(%weaponi == 0 || %weaponi == 1 || %weaponi == 3)
						{
							serverPlay3d(%data.A10shootOnClick_fireSound[%weaponi],vectorAdd(%pos,%iPos));
							%p = new Projectile()
							{
								dataBlock= %data.A10shootOnClick_Projectile[%i,%weaponi];
								initialPosition= vectorAdd(%pos,%iPos);
								initialVelocity= %velocity;
								sourceObject= %obj;
								client= %obj.client;
								firstproj = 1;
								sourceSlot= %slot;
								scale= %scale;
								target=getword(%jet.target,0);
							};
							missionCleanup.add(%p);
							
							if (%data.A10shootOnClick_FlashProjectile[%i,%weaponi] !$= "")
							{
								%fVec= %data.A10shootOnClick_flashVelocity[%i,%weaponi];
								%fVel= repeatedVectorAddwithScale(
								%jet.getEyeVector() SPC getWord(%fVec,0) TAB
								%jet.getLeftVector() SPC getWord(%fVec,1) TAB
								%jet.getUpVector() SPC getWord(%fVec,2)
								);
								%s = new Projectile()
								{
									dataBlock = %data.A10shootOnClick_FlashProjectile[%i,%weaponi];
									initialPosition = vectorAdd(%pos,%iPos);
									initialVelocity = %fVel;
									client = %obj.client;
									sourceObject= %obj;
									sourceSlot= %slot;
									scale= %scale;
								};
								MissionCleanup.add(%s);

							}
						}
						
						
						
					}
					
				if(%data.A10shootOnClick_Hold[%weaponi])
				{
					if(%obj.getObjectmount().getID().A10gear == 1)
					{
					%obj.A10SOC_reshoot= %obj.schedule(%data.A10shootOnClick_ReshootDelay[%weaponi],A10SOC_Shoot,%slot,%val,%weaponi);
					}
				}
			%obj.client.A10SOC_LastFireTime[%weaponi]=$Sim::Time+%data.A10shootOnClick_ShootDelay[%weaponi]/1000;
		}
	}

}
