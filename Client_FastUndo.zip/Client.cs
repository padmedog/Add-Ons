function undoBrick(%val) {
	if(!%val) {
		while(isEventPending($FastUndoSchedule))
			cancel($FastUndoSchedule);
		return;
	}
	commandToServer('undoBrick');
	$FastUndoSchedule = Schedule(1500, 0, FastUndoLoop);
}

function FastUndoLoop() {
	commandToServer('undoBrick');	
	$FastUndoSchedule = Schedule(60, 0, FastUndoLoop);
}