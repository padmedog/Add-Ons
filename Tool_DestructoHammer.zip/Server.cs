//=========================================================================
// Execution
//=========================================================================
exec("./spacecasts.cs");
//=========================================================================
// Data
//=========================================================================
datablock itemData(DestructoHammerItem : hammerItem)
{
	uiName = "";
	image = DestructoHammerImage;
	colorShiftColor = "1 0 0 1";
};

datablock shapeBaseImageData(DestructoHammerImage : AdminWandImage)
{
	// SpaceCasts
	raycastWeaponRange = 100;
	raycastWeaponTargets = $TypeMasks::All;
	raycastDirectDamage = 0;
	raycastDirectDamageType = $DamageType::HammerDirect;
	raycastExplosionProjectile = hammerProjectile;
	raycastExplosionSound = hammerHitSound;

	shapeFile = "base/data/shapes/Hammer.dts";
	projectile = hammerProjectile;
	item = DestructoHammerItem;
	colorShiftColor = DestructoHammerItem.colorShiftColor;
};
//=========================================================================
// Animation Junk
//=========================================================================
function DestructoHammerImage::onPreFire(%this, %obj, %slot)
{
	%obj.playThread(2, "armAttack");
}

function DestructoHammerImage::onStopFire(%this, %obj, %slot)
{
	%obj.playThread(2, "root");
}
//=========================================================================
// Server Command
//=========================================================================
function serverCmdMagicHammer(%client)
{
	if(%client.isAdmin)
	{
		%client.player.mountImage(DestructoHammerImage, 0);
		%client.player.playThread(1, armReadyRight);
	}
}
//=========================================================================
// On Hit Object
//=========================================================================
package DestructoHammer
{
	function DestructoHammerImage::onHitObject(%this, %obj, %slot, %col, %pos, %normal)
	{
		parent::onHitObject(%this, %obj, %slot, %col, %pos, %normal);

		if(%col.getClassName() $= "fxDTSBrick")
		{
			if(!%col.willCauseChainKill())
			{
				%col.killBrick();
			}
		}
	}
};
activatePackage(DestructoHammer);