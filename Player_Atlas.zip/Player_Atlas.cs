// Load dts shapes and merge animations
datablock TSShapeConstructor(AtlasDts)
{
	baseShape  = "./Atlas.dts";
	sequence0  = "./at_root.dsq root";

	sequence1  = "./at_run.dsq run";
	sequence2  = "./at_run.dsq walk";
	sequence3  = "./at_back.dsq back";
	sequence4  = "./at_side.dsq side";

	sequence5  = "./at_crouch.dsq crouch";
	sequence6  = "./at_crouchforward.dsq crouchRun";
	sequence7  = "./at_crouchback.dsq crouchBack";
	sequence8  = "./at_crouchside.dsq crouchSide";

	sequence9  = "./at_look.dsq look";
	sequence10 = "./at_headside.dsq headside";
	sequence11 = "./at_root.dsq headUp";

	sequence12 = "./at_jump.dsq jump";
	sequence13 = "./at_jump.dsq standjump";
	sequence14 = "./at_root.dsq fall";
	sequence15 = "./at_portalready.dsq land";

	sequence16 = "./at_armattack.dsq armAttack";
	sequence17 = "./at_armreadyleft.dsq armReadyLeft";
	sequence18 = "./at_armreadyright.dsq armReadyRight";
	sequence19 = "./at_armreadyboth.dsq armReadyBoth";
	sequence20 = "./at_spearready.dsq spearready";  
	sequence21 = "./at_spearthrow.dsq spearThrow";

	sequence22 = "./at_root.dsq talk";  

	sequence23 = "./at_death.dsq death1"; 
	
	sequence24 = "./at_shiftUp.dsq shiftUp";
	sequence25 = "./at_shiftDown.dsq shiftDown";
	sequence26 = "./at_shiftUp.dsq shiftAway";
	sequence27 = "./at_shiftDown.dsq shiftTo";
	sequence28 = "./at_shiftLeft.dsq shiftLeft";
	sequence29 = "./at_shiftRight.dsq shiftRight";
	sequence30 = "./at_rotCW.dsq rotCW";
	sequence31 = "./at_rotCCW.dsq rotCCW";

	sequence32 = "./at_root.dsq undo";
	sequence33 = "./at_root.dsq plant";

	sequence34 = "./at_sit.dsq sit";

	sequence35 = "./at_wrench.dsq wrench";

   sequence36 = "./at_activate.dsq activate";
   sequence37 = "./at_activate.dsq activate2";

   sequence38 = "./at_leftrecoil.dsq leftrecoil";
};    




datablock DebrisData( AtlasDebris )
{
   explodeOnMaxBounce = false;

   elasticity = 0.15;
   friction = 0.5;

   lifetime = 4.0;
   lifetimeVariance = 0.0;

   minSpinSpeed = 40;
   maxSpinSpeed = 600;

   numBounces = 5;
   bounceVariance = 0;

   staticOnMaxBounce = true;
   gravModifier = 1.0;

   useRadiusMass = false;
   baseRadius = 1;

   velocity = 20.0;
   velocityVariance = 12.0;
};             

datablock PlayerData(AtlasArmor)
{
   renderFirstPerson = false;
   emap = false;
   
   className = Armor;
   shapeFile = "./Atlas.dts";
   cameraMaxDist = 7;
   cameraTilt = 0;//0.174 * 2.5; //~25 degrees
   cameraVerticalOffset = 2;
   computeCRC = false;
  
   canObserve = true;
   cmdCategory = "Clients";

   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;
   
   //debrisShapeName = "~/data/shapes/player/debris_player.dts";
   //debris = horseDebris;

   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 1.5708;
   maxFreelookAngle = 3.0;

   mass = 60;
   drag = 0.1;
   maxdrag = 0.52;
   density = 0.7;
   maxDamage = 100;
   maxEnergy =  10;
   repairRate = 0.33;
   energyPerDamagePoint = 75.0;

   rechargeRate = 0.4;

   runForce = 28 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 10;
   maxBackwardSpeed = 7;
   maxSideSpeed = 4;

   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 1;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 1;
   maxBackwardWalkSpeed = 0;
   maxSideWalkSpeed = 0;

   maxUnderwaterForwardSpeed = 8.4;
   maxUnderwaterBackwardSpeed = 7.8;
   maxUnderwaterSideSpeed = 7.8;

   jumpForce = 7.5 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

   minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

   recoverDelay = 0;
   recoverRunForceScale = 1.2;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("1 1.5 2.8", 4); //"2.5 2.5 2.4";
   crouchBoundingBox	= vectorScale("5 5 1", 4); //"2.5 2.5 2.4";
   proneBoundingBox		= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";

   pickupRadius = 1.2;
   
   // Damage location details
   boxNormalHeadPercentage       = 0.83;
   boxNormalTorsoPercentage      = 0.49;
   boxHeadLeftPercentage         = 0;
   boxHeadRightPercentage        = 1;
   boxHeadBackPercentage         = 0;
   boxHeadFrontPercentage        = 1;

   // Foot Prints
   //decalData   = HorseFootprint;
   //decalOffset = 0.25;
	
   jetEmitter = "";
   jetGroundEmitter = "";
   jetGroundDistance = 4;
  
   //footPuffEmitter = LightPuffEmitter;
   footPuffNumParts = 10;
   footPuffRadius = 0.25;

   //dustEmitter = LiftoffDustEmitter;

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 65;
   jumpSurfaceAngle = 66;

   minJumpSpeed = 20;
   maxJumpSpeed = 30;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;
   
   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   JumpSound			= HorseJumpSound;

   // Footstep Sounds
//   FootSoftSound        = HorseFootFallSound;
//   FootHardSound        = HorseFootFallSound;
//   FootMetalSound       = HorseFootFallSound;
//   FootSnowSound        = HorseFootFallSound;
//   FootShallowSound     = HorseFootFallSound;
//   FootWadingSound      = HorseFootFallSound;
//   FootUnderwaterSound  = HorseFootFallSound;
   //FootBubblesSound     = FootLightBubblesSound;
   //movingBubblesSound   = ArmorMoveBubblesSound;
   //waterBreathSound     = WaterBreathMaleSound;

   //impactSoftSound      = ImpactLightSoftSound;
   //impactHardSound      = ImpactLightHardSound;
   //impactMetalSound     = ImpactLightMetalSound;
   //impactSnowSound      = ImpactLightSnowSound;
   
   impactWaterEasy      = Splash1Sound;
   impactWaterMedium    = Splash1Sound;
   impactWaterHard      = Splash1Sound;
   
   groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;
   
   observeParameters = "0.5 4.5 4.5";

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "Atlas";
	rideable = false;
		lookUpLimit = 0.6;
		lookDownLimit = 0.2;

	canRide = true;
	showEnergyBar = false;
	paintable = false;

	brickImage = HorseBrickImage;	//the imageData to use for brick deployment

};