// Turismo_spring.cs

datablock WheeledVehicleSpring(TurismoSpring)
{
   // Wheel suspension properties
   length = 0.4;			 // Suspension travel
   force = 4000; //3000;		 // Spring force
   damping = 700; //600;		 // Spring damping
   antiSwayForce = 3; //3;		 // Lateral anti-sway force
};


