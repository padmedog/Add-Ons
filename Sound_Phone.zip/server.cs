datablock AudioProfile(Phone_Ring_1_Sound)
{
	filename = "./Phone_Ring_1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Phone_Ring_2_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Ring_2.wav";
};

datablock AudioProfile(Phone_Ring_Bell_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Ring_Bell.wav";
};

datablock AudioProfile(Phone_Ring_Harsh_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Ring_Harsh.wav";
};

datablock AudioProfile(Phone_Tone_1_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Tone_1.wav";
};

datablock AudioProfile(Phone_Tone_2_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Tone_2.wav";
};

datablock AudioProfile(Phone_Tone_3_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Tone_3.wav";
};

datablock AudioProfile(Phone_Tone_4_Sound : Phone_Ring_1_Sound)
{
	filename = "./Phone_Tone_4.wav";
};
