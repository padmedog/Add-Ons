function Player::getYawB(%this)
{
	%fv = %this.getForwardVector();
	%pi = 3.1415926535897932384626433;
	%x = mASin(getWord(%fv,0)) * 180 / %pi;
	return 180 - mFloatLength(%x / mAbs(%x),0) * (180 - (mACos(getWord(%fv,1)) * 180 / %pi));
}
function Player::getPitchB(%this)
{
	%fv = %this.getEyeVector();
	%pi = 3.1415926535897932384626433;
	return mASin(getWord(%fv,2)) * 180 / %pi;
}

package InitVars
{
	function VCE_initServer()
	{
		Parent::VCE_initServer();
		registerSpecialVar(Player,"rhealth","mCeil(%this.getDatablock().maxDamage - %this.getDamageLevel())");
		registerSpecialVar(Player,"renergy","mCeil(%this.getEnergyLevel())");
		registerSpecialVar(Player,"yaw","%this.getYawB()");
		registerSpecialVar(Player,"pitch","%this.getPitchB()");
		registerSpecialVar(Player,"pos","getWords(%this.getTransform(),0,2)");
		registerSpecialVar(Player,"posx","getWord(%this.getTransform(),0)");
		registerSpecialVar(Player,"posy","getWord(%this.getTransform(),1)");
		registerSpecialVar(Player,"posz","getWord(%this.getTransform(),2)");
		registerSpecialVar(Player,"state","%this.getstate()");
		registerSpecialVar(Player,"isPassenger","(%this.getObjectMount().dataBlock.rideable)");
		registerSpecialVar(Player,"isDriver","(%this.getObjectMount().dataBlock.rideable && %this.getObjectMount().getControllingObject() == %this)");
		registerSpecialVar(Player,"altFire","%this.slot1");
		registerSpecialVar(Player,"veDamage","%this.getObjectMount() ? %this.getObjectMount().getDamageLevel() : 0");
		registerSpecialVar(Player,"veHealth","%this.getObjectMount() ? %this.getObjectMount().getDatablock().maxDamage - %this.getObjectMount().getDamageLevel() : 0");
		registerSpecialVar(Player,"veMaxHealth","%this.getObjectMount() ? %this.getObjectMount().getDatablock().maxDamage : 0");
		registerSpecialVar(Player,"veDatablock","%this.getObjectMount() ? %this.getObjectMount().getDatablock().uiName : 0");
		registerSpecialVar(Player,"weDamage","%this.tool[%this.currTool].image.projectile.directDamage + 0");
		registerSpecialVar(Player,"weRadiusDamage","%this.tool[%this.currTool].image.projectile.explosion.radiusDamage + 0");
		registerSpecialVar(Player,"weDamageRadius","%this.tool[%this.currTool].image.projectile.explosion.damageRadius + 0");
		registerSpecialVar(Player,"weSpeed","%this.tool[%this.currTool].image.projectile.muzzleVelocity + 0");
		registerSpecialVar(Player,"weArc","%this.tool[%this.currTool].image.projectile.isBallistic*%this.tool[%this.currTool].image.projectile.gravityMod + 0");
		registerSpecialVar(fxDTSbrick,"pos","%this.getPosition()");
		registerSpecialVar(fxDTSbrick,"posx","getWord(%this.getPosition(),0)");
		registerSpecialVar(fxDTSbrick,"posy","getWord(%this.getPosition(),1)");
		registerSpecialVar(fxDTSbrick,"posz","getWord(%this.getPosition(),2)");
		registerSpecialVar(fxDTSbrick,"type","%this.getDataBlock().getID().category");
		registerSpecialVar(Vehicle,"velx","getWord(%this.getVelocity(),0)");
		registerSpecialVar(Vehicle,"vely","getWord(%this.getVelocity(),1)");
		registerSpecialVar(Vehicle,"velz","getWord(%this.getVelocity(),2)");
		registerSpecialVar(Vehicle,"speed","vectorDist(%this.getVelocity(),\"0 0 0\")");
		registerSpecialVar(Vehicle,"pos","getWords(%this.getTransform(),0,2)");
		registerSpecialVar(Vehicle,"posx","getWord(%this.getTransform(),0)");
		registerSpecialVar(Vehicle,"posy","getWord(%this.getTransform(),1)");
		registerSpecialVar(Vehicle,"posz","getWord(%this.getTransform(),2)");
		registerSpecialVar(Vehicle,"yaw","%this.getYawB()");
		registerSpecialVar(Vehicle,"pitch","%this.getPitchB()");
		registerSpecialVar(Vehicle,"trigger","%this.triggerOn");
		registerSpecialVar("GLOBAL","pi","3.14159265");
		registerSpecialVar("GLOBAL","simSecond","mFloor(getSimTime()/1000)");
		registerSpecialVar("GLOBAL","simMinute","mFloor(getSimTime()/60000)");
		registerSpecialVar("GLOBAL","simHour","mFloor(getSimTime()/3600000)");
	}

	function Armor::onTrigger(%data,%player,%slot,%io)
	{
		Parent::onTrigger(%data,%player,%slot,%io);

		if(%slot == 1)
			%player.slot1 = %io;
	}

	function WheeledVehicleData::onTrigger(%this, %obj, %client)
	{
		if(!%this.triggerOn)
			%this.triggerOn = 1;
		else
			%this.triggerOn = 0;
	}

	function FlyingVehicleData::onTrigger(%this, %obj, %client)
	{
		if(!%this.triggerOn)
			%this.triggerOn = 1;
		else
			%this.triggerOn = 0;
	}
};
activatePackage(InitVars);