datablock fxDTSBrickData(brickForestTreeData)
{
	brickFile = "./foresttree.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Forest Tree";
	iconName = "Add-Ons/Brick_ForestTree/foresttree";
	collisionShapeName = "./foresttree.dts";
};