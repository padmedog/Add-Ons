//########## Revolving Crossbow

//### Projectile

AddDamageType("gc_RevCrossbow",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_revolvingcrossbow> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_revolvingcrossbow> %1',0.2,1);

datablock ProjectileData(gc_RevCrossbowProjectile : gc_CrossbowProjectile)
{
  uiName = "";
  directDamage = 18;
  directDamageType = $DamageType::gc_RevCrossbow;
  radiusDamageType = $DamageType::gc_RevCrossbow;
  muzzleVelocity = 150;
};

//### Item

datablock ItemData(gc_RevCrossbowItem)
{
  uiName = "Revolving Crossbow";
  iconName = "./icon_revolvingcrossbow";
  image = gc_RevCrossbowImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./revolvingcrossbow.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_RevCrossbowImage)
{
  shapeFile = "./revolvingcrossbow.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_RevCrossbowItem;
  ammo = "";
  projectile = gc_RevCrossbowProjectile;
  projectilespread = 0.0005;
  projectilemagcount = 12;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;
  stateSequence[0] = "Ready";

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";
  stateSequence[1] = "Ready";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "AmmoCheck";
  stateTimeoutValue[2] = 0.2;
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateSound[2] = gc_CrossbowFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Reload";

  stateName[3] = "AmmoCheck";
  stateTransitionOnTimeout[3] = "Ready";
  stateAllowImageChange[3] = true;
  stateScript[3] = "onAmmoCheck";

  stateName[4] = "Reload";
  stateTimeoutValue[4] = 4;
  stateTransitionOnTimeout[4] = "Done";
  stateWaitForTimeout[4] = true;
  stateAllowImageChange[4] = true;
  stateScript[4] = "onReloadStart";
  stateSequence[4] = "Reload";

  stateName[5] = "Done";
  stateTransitionOnTimeout[5] = "Ready";
  stateTimeoutValue[5] = 0.1;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReload";
};

//### Functions

function gc_RevCrossbowImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %spread = %this.projectilespread;
  if(vectorLen(%obj.getVelocity()) >= 5 && !isObject(%obj.getObjectMount())) %spread += 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
}
function gc_RevCrossbowImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > %this.projectilemagcount) { %obj.toolMag[%obj.currTool] = %this.projectilemagcount; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_RevCrossbowImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,shiftRight); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }
function gc_RevCrossbowImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); %obj.toolMag[%obj.currTool] = %this.projectilemagcount; %obj.setImageAmmo(0,1); }

function gc_RevCrossbowProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(miniGameCanDamage(%obj,%col) && getMiniGameFromObject(%col) != -1) {
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
  if(%col.isCrouched() != 1) {
  %colscale = getWord(%col.getScale(),2);
  if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale)
  { %col.damage(%obj,%pos,%this.directDamage,%this.directDamageType); } } }
  if(%col.getType() & $TypeMasks::VehicleObjectType)
  { %col.damage(%obj,%pos,1,%this.directDamageType); return 1; } }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}
