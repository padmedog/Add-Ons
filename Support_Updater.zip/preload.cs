if(!$Server::Dedicated)
	return;

function checkForUpdates()
{
	if(getMax(300, $Sim::Time) - $Updater::LastManualQuery < 300)
	{
		echo("You can only check for updates once every 5 minutes.");
		return;
	}
	$Updater::LastManualQuery = $Sim::Time;

	$Updater::ManualQuery = true;
	if(isObject(updater))
		updater.checkForUpdates();
	else
		exec("./dedicated.cs");
	$Updater::ManualQuery = false;
}

if(!$Pref::Updater::DedicatedServerUpdates && $Pref::Updater::DedicatedServerUpdates !$= "")
	return;

$Updater::DediAutoCheckTimeout = 5000;

package Support_Updater_DedicatedAuto
{
	function initDedicated()
	{
		$Updater::dediServerPaused = true;
		echo("\n--------- Checking for Add-On Updates ---------");
	}
	
	function initDedicatedLAN()
	{
		$Updater::dediServerPaused = true;
		echo("\n--------- Checking for Add-On Updates ---------");
	}

	function updaterInterfacePushItem(%item)
	{
		parent::updaterInterfacePushItem(%item);
		cancel($Updater::dediContinueSched);
	}
};

function updaterDediContinue()
{
	if(!$Updater::dediServerPaused)
		return;
	$Updater::dediServerPaused = false;
	$TCPClient::PrintErrors = $Temp::TCPClient::PrintErrors;
	deActivatePackage(Support_Updater_DedicatedAuto);
	if($Server::LAN)
		initDedicatedLAN();
	else
		initDedicated();
}

exec("./dedicated.cs");
$Temp::TCPClient::PrintErrors = $TCPClient::PrintErrors;
$TCPClient::PrintErrors = false; //hide the errors - this is a CLI
cancel($Updater::dediContinueSched);
$Updater::dediContinueSched = schedule($Updater::DediAutoCheckTimeout, 0, updaterDediContinue);
activatePackage(Support_Updater_DedicatedAuto);