//########## Flintlock Weapons

%error1 = ForceRequiredAddOn("Weapon_Gun");
%error2 = ForceRequiredAddOn("Weapon_Spear");
if(%error1 == $Error::AddOn_NotFound)
  error("ERROR: Weapon_FlintlockWeapons - required add-on Weapon_Gun not found");
else if(%error2 == $Error::AddOn_NotFound)
  error("ERROR: Weapon_FlintlockWeapons - required add-on Weapon_Spear not found");
else
  exec("./basic.cs");
