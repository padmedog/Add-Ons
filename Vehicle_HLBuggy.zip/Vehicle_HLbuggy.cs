
datablock WheeledVehicleTire(HLbuggyTire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile = "add-ons/vehicle_HLbuggy/buggytire.dts";
	
	mass = 10;
   radius = 1;
   staticFriction = 5;
   kineticFriction = 5;
   restitution = 0.5;	

   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 4000;
   lateralRelaxation = 0.01;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 14000;
   longitudinalDamping = 2000;
   longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleSpring(HLbuggySpring)
{
   // Wheel suspension properties
   length = 0.4;        // Suspension trave
   force = 5000;        // Spring force
   damping = 200;      // Spring damping
   antiSwayForce = 6;   // Lateral anti-sway force
};

datablock WheeledVehicleData(HLbuggyVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./buggy3.dts";
	emap = true;
	minMountDist = 3;
   
   numMountPoints = 1;
   mountThread[0] = "sit";//exec("add-ons/vehicle_HLbuggy/server.cs");


	maxDamage = 200.00;
	destroyedLevel = 200.00;
	energyPerDamagePoint = 160;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0";
   //massBox = "2 5 1";

	maxSteeringAngle = 0.7785;  // Maximum steering angle, should match animation
	integration = 10;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 13;         // Far distance from vehicle
	cameraOffset = 7.5;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.4;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

	defaultTire	= HLbuggyTire;
	defaultSpring	= HLbuggySpring;

   numWheels = 4;

	// Rigid Body
	mass = 800;
	density = 5.0;
	drag = 1.6;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 25000; //4000;       // Engine power
	engineBrake = 2000;         // Braking when throttle is 0
	brakeTorque = 50000;        // When brakes are applied
	maxWheelSpeed = 40;        // Engine scale by current speed / max speed

	rollForce		= 500;
	yawForce		= 600;
	pitchForce		= 1000;
	rotationalDrag		= 0.9;

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = HLbuggyidleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "Half Life Buggy";
	rideable = true;
   //lookUpLimit = 0.9;
   //lookDownLimit = 0.1;
   lookUpLimit  = 0.5;
   lookDownLimit = 0.5;

	paintable = true;
   
   damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

   initialExplosionProjectile = buggyExplosionProjectile;
   initialExplosionOffset = 1;         //offset only uses a z value for now

   burnTime = 4000;

   finalExplosionProjectile = buggyFinalExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now


   minRunOverSpeed    = 4;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 25;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed

   //protection for passengers
   protectPassengersBurn   = true;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = false; //protect passengers from direct damage (bullets) ?
};

function HLbuggyVehicle::onAdd(%this,%obj)
{

   // Setup the car with some defaults tires & springs
   for(%i = 0; %i < %this.numWheels; %i++)
   {
      %obj.setWheelTire(%i, %this.defaultTire);
      %obj.setWheelSpring(%i, %this.defaultSpring);
   }

   // 4 wheel steering
   %obj.setWheelSteering(0,1);
   %obj.setWheelSteering(1,1);
   %obj.setWheelSteering(2,0);
   %obj.setWheelSteering(3,0);


   // 4 wheel drive
   %obj.setWheelPowered(0,true);
   %obj.setWheelPowered(1,true);
   %obj.setWheelPowered(2,true);
   %obj.setWheelPowered(3,true);






	    


}

