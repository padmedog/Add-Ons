while(isobject(neo_options))
	neo_options.delete();
exec("./options.gui");

function neo_options()
{
	neo_options.loadvalues();

	//for some reason this can get stuck behind other things
	if(neo_options.isawake())
		canvas.popdialog(neo_options);
	canvas.pushdialog(neo_options);
}

function neo_options::loadvalues(%this)
{
	neo_debug("loading values");

	//version 1.0 Beta to 1.0 Full changed the format of this variables
	if(getwordcount($neo::pref::backgroundColor) == 3)
		$neo::pref::backgroundColor = $neo::pref::backgroundColor SPC "192";

	neo_options_versioncheck.setValue($neo::pref::versioncheck);
	neo_options_mainmenuescape.setValue($neo::pref::mainmenuescape);
	neo_options_imagescaling.setValue($neo::pref::imageScaling);
	neo_options_fadein.setValue($neo::pref::fadein);
	neo_options_animate.setValue($neo::pref::animate);
	neo_options_defaulticon.setValue($neo::pref::defaulticon);
	neo_options_datapath.setValue($neo::pref::datapath);
	neo_options_prefpath.setValue($neo::pref::prefpath);
	neo_options_dragthreshold.setValue($neo::pref::dragThreshold);
	neo_options_buttonsize.setValue($neo::pref::buttonsize);
	neo_options_animationticks.setValue($neo::pref::animationticks);
	neo_options_backgroundcolor.setValue($neo::pref::backgroundColor);
	neo_options_idlecolor.setValue($neo::pref::buttonColorIdle);
	neo_options_highlightcolor.setValue($neo::pref::buttonColorHighlight);
	neo_options_presscolor.setValue($neo::pref::buttonColorPress);
	neo_options_contextcolor.setValue($neo::pref::buttonColorContext);
	neo_options_selectcolor.setValue($neo::pref::buttonColorSelect);
	neo_options_dragcolor.setValue($neo::pref::buttonColorDrag);
}

function neo_options::clickapply(%this)
{
	$neo::pref::versioncheck = neo_options_versioncheck.getValue();
	$neo::pref::mainmenuescape = neo_options_mainmenuescape.getValue();
	$neo::pref::imageScaling = neo_options_imagescaling.getValue();
	$neo::pref::fadein = neo_options_fadein.getValue();
	$neo::pref::animate = neo_options_animate.getValue();
	$neo::pref::backgroundColor = %this.filtercolor(neo_options_backgroundcolor.getValue(), 4);
	$neo::pref::buttonsize = neo_options_buttonsize.getValue();
	$neo::pref::animationticks = neo_options_animationticks.getValue();
	$neo::pref::buttonColorIdle = %this.filtercolor(neo_options_idlecolor.getValue(), 4);
	$neo::pref::buttonColorHighlight = %this.filtercolor(neo_options_highlightcolor.getValue(), 4);
	$neo::pref::buttonColorPress = %this.filtercolor(neo_options_presscolor.getValue(), 4);
	$neo::pref::buttonColorContext = %this.filtercolor(neo_options_contextcolor.getValue(), 4);
	$neo::pref::buttonColorSelect = %this.filtercolor(neo_options_selectcolor.getValue(), 4);
	$neo::pref::buttonColorDrag = %this.filtercolor(neo_options_dragcolor.getValue(), 4);

	if(iswriteablefilename(neo_options_datapath.getValue()))
		$neo::pref::datapath = neo_options_datapath.getValue();
	else
	{
		neo_debug("Invalid data filepath selected: " @ neo_options_datapath.getValue());
		neo_options_datapath.setValue($neo::pref::datapath);
	}

	if(iswriteablefilename(neo_options_prefpath.getValue()))
		$neo::pref::prefpath = neo_options_prefpath.getValue();
	else
	{
		neo_debug("Invalid pref filepath selected: " @ neo_options_prefpath.getValue());
		neo_options_prefpath.setValue($neo::pref::prefpath);
	}

	if(isfile(neo_options_defaulticon.getValue()))
		$neo::pref::defaulticon = neo_options_defaulticon.getValue();
	else
		neo_options_defaulticon.setValue($neo::pref::defaulticon);
	$neo::pref::dragThreshold = neo_options_dragthreshold.getValue();

	//updates
	NARGEscapeOverlay.getobject(0).setcolor($neo::pref::backgroundColor);
	NARGEscapeOverlay.getobject(0).getobject(0).setcolor(getwords($neo::pref::backgroundColor, 0, 2) SPC mceil(getword($neo::pref::backgroundColor, 3)*(2/3)));

	export("$neo::pref::*", $neo::pref::prefpath);

	if($neo::pref::prefpath !$= $neo::defaultpref::prefpath)
		export("$neo::pref::prefpath", $neo::defaultpref::prefpath);
	neomain.modified = true;

	if(NARGEscapeOverlay.isawake())
		neomain.draw();
}

function neo_options::filtercolor(%this, %color, %x)
{
	%ret = "";

	for(%i=0; %i<%x; %i++)
	{
		if(%ret $= "")
			%ret = getword(%color, %i)*1.0;
		else
			%ret = %ret SPC getword(%color, %i)*1.0;
	}
	return %ret;
}

function neo_options::clickdefaults(%this)
{
	neo_options_versioncheck.setValue($neo::defaultpref::versioncheck);
	neo_options_mainmenuescape.setValue($neo::defaultpref::mainmenuescape);
	neo_options_imagescaling.setValue($neo::defaultpref::imageScaling);
	neo_options_fadein.setValue($neo::defaultpref::fadein);
	neo_options_animate.setValue($neo::defaultpref::animate);
	neo_options_defaulticon.setValue($neo::defaultpref::defaulticon);
	neo_options_datapath.setValue($neo::defaultpref::datapath);
	neo_options_prefpath.setValue($neo::defaultpref::prefpath);
	neo_options_dragthreshold.setValue($neo::defaultpref::dragThreshold);
	neo_options_buttonsize.setValue($neo::defaultpref::buttonsize);
	neo_options_animationticks.setValue($neo::defaultpref::animationticks);
	neo_options_backgroundcolor.setValue($neo::defaultpref::backgroundColor);
	neo_options_idlecolor.setValue($neo::defaultpref::buttonColorIdle);
	neo_options_highlightcolor.setValue($neo::defaultpref::buttonColorHighlight);
	neo_options_presscolor.setValue($neo::defaultpref::buttonColorPress);
	neo_options_contextcolor.setValue($neo::defaultpref::buttonColorContext);
	neo_options_selectcolor.setValue($neo::defaultpref::buttonColorSelect);
	neo_options_dragcolor.setValue($neo::defaultpref::buttonColorDrag);
}

function neo_options::clickok(%this)
{
	%this.clickapply();
	canvas.popdialog(%this);
}

function neo_options::browseicon(%this)
{
	promptUserFile($neo::pref::defaulticon, "neo_options_seticon", "load", ".png");
}

function neo_options_seticon(%file)
{
	neo_options_defaulticon.setValue(%file);
}

function neo_options::browsedatafile(%this)
{
	promptUserFile($neo::pref::datapath, "neo_options_setdatapath", "save", ".cs");
}

function neo_options_setdatapath(%file)
{
	neo_options_datapath.setValue(%file);
}

function neo_options::browsepreffile(%thile)
{
	promptUserFile($neo::pref::prefpath, "neo_options_setprefpath", "save", ".cs");
}

function neo_options_setprefpath(%file)
{
	neo_options_prefpath.setValue(%file);
}

function neo_options::selectbackgroundcolor(%this)
{
	promptUserColor($neo::pref::backgroundcolor, "neo_options_setbackgroundcolor", 1, 1, 1);
}

function neo_options_setbackgroundcolor(%color)
{
	//$neo::pref::backgroundcolor = %color;
	neo_options_backgroundcolor.setValue(%color);
}

function neo_options::selectidlecolor(%this)
{
	promptUserColor($neo::pref::buttonColorIdle, "neo_options_setidlecolor", 1, 1, 1);
}

function neo_options_setidlecolor(%color)
{
	//bork bork
	neo_options_idlecolor.setValue(%color);
}

function neo_options::selecthighlightcolor(%this)
{
	promptUserColor($neo::pref::buttonColorHighlight, "neo_options_sethighlightcolor", 1, 1, 1);
}

function neo_options_sethighlightcolor(%color)
{
	//$neo::pref::buttonColorHighlight = %color;
	neo_options_highlightcolor.setValue(%color);
}

function neo_options::selectpresscolor(%this)
{
	promptUserColor($neo::pref::buttonColorPress, "neo_options_setpresscolor", 1, 1, 1);
}

function neo_options_setpresscolor(%color)
{
	//$neo::pref::buttonColorpress = %color;
	neo_options_presscolor.setValue(%color);
}

function neo_options::selectcontextcolor(%this)
{
	promptUserColor($neo::pref::buttonColorcontext, "neo_options_setcontextcolor", 1, 1, 1);
}

function neo_options_setcontextcolor(%color)
{
	//$neo::pref::buttonColorcontext = %color;
	neo_options_contextcolor.setValue(%color);
}

function neo_options::selectselectcolor(%this)
{
	promptUserColor($neo::pref::buttonColorselect, "neo_options_setselectcolor", 1, 1, 1);
}

function neo_options_setselectcolor(%color)
{
	//$neo::pref::buttonColorselect = %color;
	neo_options_selectcolor.setValue(%color);
}

function neo_options::selectdragcolor(%this)
{
	promptUserColor($neo::pref::buttonColordrag, "neo_options_setdragcolor", 1, 1, 1);
}

function neo_options_setdragcolor(%color)
{
	//$neo::pref::buttonColordrag = %color;
	neo_options_dragcolor.setValue(%color);
}

