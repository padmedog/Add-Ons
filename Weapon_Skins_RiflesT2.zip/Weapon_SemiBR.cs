AddDamageType("SemiBRifle",   '<bitmap:add-ons/Weapon_Skins_RiflesT2/CI_rifle_b> %1',    '%2 <bitmap:add-ons/Weapon_Skins_RiflesT2/CI_rifle_b> %1',0.75,1);
datablock ProjectileData(SemiBattleRifleProjectile1 : BattleRifleProjectile1)
{
   directDamage        = 17;
   directDamageType    = $DamageType::SemiBRifle;
};

datablock ItemData(SemiBattleRifleItem : BattleRifleItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Semi_BR.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Compact B.Rifle";
	iconName = "./icon_rifle_b";
	doColorShift = true;
	colorShiftColor = "0.49 0.49 0.52 1.000";

	 // Dynamic properties defined by the scripts
	image = SemiBattleRifleImage;
	canDrop = true;
	
	maxAmmo = 22;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(SemiBattleRifleImage : BattleRifleImage)
{
   // Basic Item properties
   shapeFile = "./Semi_BR.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = SemiBattleRifleItem;
   ammo = " ";
   projectile = SemiBattleRifleProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = SemiBattleRifleItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
};

function SemiBattleRifleImage::onFire(%this,%obj,%slot)
{
	%projectile = SemiBattleRifleProjectile1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1)
	{
		%spread = 0.0022;
	}
	else
	{
		%spread = 0.0044;
	}
	
	%shellcount = 1;

	%obj.playThread(2, plant);
	%shellcount = 1;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function SemiBattleRifleImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["708rounds"] >= 1)
	{
	%obj.playThread(2, shiftRight);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function SemiBattleRifleImage::onReloadWait(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["708rounds"] >= 1)
	{
	%obj.playThread(2, plant);
            serverPlay3D(magazineOutSound,%obj.getPosition());
	}
}

function SemiBattleRifleImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["708rounds"] >= 1)
	{

        if(%obj.client.quantity["708rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["708rounds"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["708rounds"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["708rounds"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["708rounds"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
}
}

function SemiBattleRifleProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.setVelocity(getWord(%col.getVelocity(),0)/1.2 SPC getWord(%col.getVelocity(),1)/1.2 SPC getWord(%col.getVelocity(),1.2));
   }
parent::damage(%this,%obj,%col,%fade,%pos,%normal);
}

function SemiBattleRifleImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
}

function SemiBattleRifleImage::onUnMount(%this,%obj,%slot)
{
	%obj.playThread(2, root);
}