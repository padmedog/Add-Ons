//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// Load dts shapes and merge animations
datablock TSShapeConstructor(MechHeavyDts)
{
	baseShape  = "./MechHeavy.dts";
	sequence0  = "./M_root.dsq root";

	sequence1  = "./M_run.dsq run";
	sequence2  = "./M_run.dsq walk";
	sequence3  = "./M_back.dsq back";
	sequence4  = "./M_side.dsq side";

	sequence5  = "./M_root.dsq crouch";
	sequence6  = "./M_run.dsq crouchRun";
	sequence7  = "./M_back.dsq crouchBack";
	sequence8  = "./M_side.dsq crouchSide";

	sequence9  = "./M_look.dsq look";
	sequence10 = "./M_root.dsq headside";
	sequence11 = "./M_root.dsq headUp";

	sequence12 = "./M_jump.dsq jump";
	sequence13 = "./M_jump.dsq standjump";
	sequence14 = "./M_root.dsq fall";
	sequence15 = "./M_root.dsq land";

	sequence16 = "./M_root.dsq armAttack";
	sequence17 = "./M_root.dsq armReadyLeft";
	sequence18 = "./M_root.dsq armReadyRight";
	sequence19 = "./M_root.dsq armReadyBoth";
	sequence20 = "./M_root.dsq spearready";  
	sequence21 = "./M_root.dsq spearThrow";

	sequence22 = "./M_root.dsq talk";  

	sequence23 = "./M_Death.dsq death1"; 
	
	sequence24 = "./M_root.dsq shiftUp";
	sequence25 = "./M_root.dsq shiftDown";
	sequence26 = "./M_root.dsq shiftAway";
	sequence27 = "./M_root.dsq shiftTo";
	sequence28 = "./M_root.dsq shiftLeft";
	sequence29 = "./M_root.dsq shiftRight";
	sequence30 = "./M_root.dsq rotCW";
	sequence31 = "./M_root.dsq rotCCW";

	sequence32 = "./M_root.dsq undo";
	sequence33 = "./M_root.dsq plant";

	sequence34 = "./M_root.dsq sit";

	sequence35 = "./M_root.dsq wrench";

   sequence36 = "./M_root.dsq activate";
   sequence37 = "./M_root.dsq activate2";

   sequence38 = "./M_root.dsq leftrecoil";
};    


datablock AudioProfile(MechHeavyJumpSound)
{
   fileName = "./jumpMech.wav";
   description = AudioClose3d;
   preload = true;
};


datablock DebrisData( MechHeavyDebris )
{
   explodeOnMaxBounce = false;

   elasticity = 0.15;
   friction = 0.5;

   lifetime = 4.0;
   lifetimeVariance = 0.0;

   minSpinSpeed = 40;
   maxSpinSpeed = 600;

   numBounces = 5;
   bounceVariance = 0;

   staticOnMaxBounce = true;
   gravModifier = 1.0;

   useRadiusMass = true;
   baseRadius = 1;

   velocity = 20.0;
   velocityVariance = 12.0;
};             

datablock PlayerData(MechHeavyArmor)
{
   renderFirstPerson = true;
   emap = false;
   
   className = Armor;
   shapeFile = "./MechHeavy.dts";
   cameraMaxDist = 8;
   cameraTilt = 0.261;//0.174 * 2.5; //~25 degrees
   cameraVerticalOffset = 6.1;
   computeCRC = false;
  
   canObserve = true;
   cmdCategory = "Clients";

   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;
   
   //debrisShapeName = "~/data/shapes/player/debris_player.dts";
   //debris = MechHeavyDebris;

   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 1.5708;
   maxFreelookAngle = 3.0;

   mass = 90;
   drag = 0.1;
   maxdrag = 0.52;
   density = 0.7;
   maxDamage = 650;
   maxEnergy =  10;
   repairRate = 0.33;
   energyPerDamagePoint = 75.0;

   rechargeRate = 0.4;

   runForce = 28 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 12;
   maxBackwardSpeed = 12;
   maxSideSpeed = 3;

   maxForwardCrouchSpeed = 12;
   maxBackwardCrouchSpeed = 6;
   maxSideCrouchSpeed = 1;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 0;
   maxBackwardWalkSpeed = 0;
   maxSideWalkSpeed = 0;

   maxUnderwaterForwardSpeed = 8.4;
   maxUnderwaterBackwardSpeed = 7.8;
   maxUnderwaterSideSpeed = 7.8;

   jumpForce = 15 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

   minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

   recoverDelay = 0;
   recoverRunForceScale = 1.2;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("5 5 11", 4); //"2.5 2.5 2.4";
   crouchBoundingBox	= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";
   proneBoundingBox		= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";

   pickupRadius = 0.75;
   
   // Damage location details
   boxNormalHeadPercentage       = 0.83;
   boxNormalTorsoPercentage      = 0.49;
   boxHeadLeftPercentage         = 0;
   boxHeadRightPercentage        = 1;
   boxHeadBackPercentage         = 0;
   boxHeadFrontPercentage        = 1;

   // Foot Prints
   //decalData   = MechHeavyFootprint;
   //decalOffset = 0.25;
	
   jetEmitter = "";
   jetGroundEmitter = "";
   jetGroundDistance = 4;
  
   //footPuffEmitter = LightPuffEmitter;
   footPuffNumParts = 10;
   footPuffRadius = 0.25;

   //dustEmitter = LiftoffDustEmitter;

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 85;
   jumpSurfaceAngle = 86;

   minJumpSpeed = 20;
   maxJumpSpeed = 30;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;
   
   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   JumpSound			= MechHeavyJumpSound;

   // Footstep Sounds
//   FootSoftSound        = MechHeavyFootFallSound;
//   FootHardSound        = MechHeavyFootFallSound;
//   FootMetalSound       = MechHeavyFootFallSound;
//   FootSnowSound        = MechHeavyFootFallSound;
//   FootShallowSound     = MechHeavyFootFallSound;
//   FootWadingSound      = MechHeavyFootFallSound;
//   FootUnderwaterSound  = MechHeavyFootFallSound;
   //FootBubblesSound     = FootLightBubblesSound;
   //movingBubblesSound   = ArmorMoveBubblesSound;
   //waterBreathSound     = WaterBreathMaleSound;

   //impactSoftSound      = ImpactLightSoftSound;
   //impactHardSound      = ImpactLightHardSound;
   //impactMetalSound     = ImpactLightMetalSound;
   //impactSnowSound      = ImpactLightSnowSound;
   
   impactWaterEasy      = Splash1Sound;
   impactWaterMedium    = Splash1Sound;
   impactWaterHard      = Splash1Sound;
   
   groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;
   
   observeParameters = "0.5 4.5 4.5";

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "Mech Heavy";
	rideable = true;
		lookUpLimit = 0.55;
		lookDownLimit = 0.55;

	canRide = false;
	showEnergyBar = false;
	paintable = true;

	brickImage = MechHeavyBrickImage;	//the imageData to use for brick deployment

   numMountPoints = 1;
   mountThread[0] = "sit";
   mountNode[0] = 0;
   
      //Weapons
   ShootOnClick = 1;
   
   ShootOnClick_Hold = 1;
   ShootOnClick_ShootDelay = 1000;
   ShootOnClick_ReShootDelay = 1000;
   ShootOnClick_ProjectileCount = 2;
   ShootOnClick_RequiredSlot = 0;

   ShootOnClick_Projectile[0] = MechHeavyRocketProjectile;
   ShootOnClick_Position[0] = "0 -3 9";
   ShootOnClick_Velocity[0] = "60 0 0";
   ShootOnClick_Scale[0] = "2 2 2";
   ShootOnClick_Projectile[1] = MechHeavyRocketProjectile;
   ShootOnClick_Position[1] = "0 3 9";
   ShootOnClick_Velocity[1] = "60 0 0";
   ShootOnClick_Scale[1] = "2 2 2";
   
};

//rocket trail effects
datablock ParticleData(MechHeavyrocketTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 805;
	textureName          = "./Twincloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 1.0 0.0 0.4";
	colors[1]     = "1.0 0.2 0.0 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 0.85;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.3;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(MechHeavyrocketTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MechHeavyrocketTrailParticle";

   uiName = "MechHeavy Rocket Trail";
};

datablock ExplosionData(MechHeavyrocketExplosion)
{
   //explosionShape = "";
   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";
	soundProfile = rocketExplodeSound;

   lifeTimeMS = 150;

   particleEmitter = rocketExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = rocketExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 20;
   lightStartColor = "1 1 1 1";
   lightEndColor = "0 0 0 0";

   damageRadius = 4;
   radiusDamage = 60;

   impulseRadius = 6;
   impulseForce = 2000;
};



datablock ProjectileData(MechHeavyRocketProjectile)
{
   projectileShapeName = "./MechProjectile.dts";
   directDamage        = 70;
   directDamageType = $DamageType::RocketDirect;
   radiusDamageType = $DamageType::RocketRadius;
   impactImpulse	   = 800;
   verticalImpulse	   = 800;
   explosion           = MechHeavyrocketExplosion;
   particleEmitter     = MechHeavyrocketTrailEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = rocketLoopSound;

   muzzleVelocity      = 50;
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "MechHeavy Rockets";
};


function MechHeavyArmor::onAdd(%this,%obj)
{
   // Vehicle timeout
   %obj.mountVehicle = true;

   // Default dynamic armor stats
   %obj.setRechargeRate(%this.rechargeRate);
   %obj.setRepairRate(0);

}



//called when the driver of a player-vehicle is unmounted
function MechHeavyArmor::onDriverLeave(%obj, %player)
{
	//do nothing
}