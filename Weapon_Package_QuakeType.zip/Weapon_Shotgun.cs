//gun.cs

datablock AudioProfile(quakeShotgunReloadSound)
{
   filename    = "./pump_Shotgun_reload.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(quakeShotgunFireSound)
{
   filename    = "./ShotgunPump.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(quakeImpactExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.9 0.3";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 2.25;
	sizes[1]      = 2.75;

	useInvAlpha = true;
};
datablock ParticleEmitterData(quakeImpactExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakeImpactExplosionParticle";

   useEmitterColors = true;
};


datablock ParticleData(quakeImpactExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 35;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 1 0.0 0.9";
	colors[1]     = "1 1 0.0 0.4";
	colors[2]     = "0.9 0.0 0.0 0.0";
	sizes[0]      = 1;
	sizes[1]      = 4;
	sizes[2]      = 3;
   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(quakeImpactExplosionRingEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakeImpactExplosionRingParticle";

   useEmitterColors = true;
};

datablock ParticleData(quakeShotgunFireParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 50;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/star1";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "1.0 0.5 0 0.9";
    colors[1]     = "0.9 0.4 0 0.8";
    colors[2]     = "1 0.5 0.2 0.6";
    colors[3]     = "1 0.5 0.2 0.4";

    sizes[0]      = 2.95;
   sizes[1]      = 0.3;
    sizes[2]      = 0.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(quakeShotgunFireEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 54.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "quakeShotgunFireParticle";
};

datablock ParticleData(quakeShotgunSmokeParticle)
{
    dragCoefficient      = 3;
    gravityCoefficient   = -8;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 100;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/cloud";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "0.6 0.6 0.6 0.4";
    colors[1]     = "0.7 0.7 0.7 0.3";
    colors[2]     = "1 1 1 0.2";
    colors[3]     = "1 1 1 0";

    sizes[0]      = 0.55;
   sizes[1]      = 0.4;
    sizes[2]      = 0.10;
    sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(quakeShotgunSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 32.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "quakeShotgunSmokeParticle";
};

datablock ParticleData(quakeShotgunFlashParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 35;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
    colors[0]     = "1.0 0.5 0 0.9";
    colors[1]     = "0.9 0.4 0 0.8";
    colors[2]     = "1 0.5 0.2 0.6";
    colors[3]     = "1 0.5 0.2 0.4";
	sizes[0]      = 1.75;
	sizes[1]      = 1.95;
	sizes[2]      = 1.95;
	sizes[3]      = 1.95;
   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(quakeShotgunFlashEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "quakeShotgunFlashParticle";

   useEmitterColors = false;
};


datablock ExplosionData(quakeShotgunExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 150;

   particleEmitter = quakeImpactExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0;

   emitter[0] = quakeImpactExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";

   impulseRadius = 2;
   impulseForce = 1000;
};

//shell
datablock DebrisData(quakeShotgunShellDebris)
{
	shapeFile = "./bushido's_shell_Shotgun.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 4;
};

AddDamageType("quakeShotgun",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_shotgun> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_shotgun> %1',0.2,1);
datablock ProjectileData(quakeShotgunProjectile : gunProjectile)
{
   directDamage        = 10;
   directDamageType    = $DamageType::quakeShotgun;
   radiusDamageType    = $DamageType::quakeShotgun;

   impactImpulse	     = 200;
   verticalImpulse	  = 100;
   explosion           = gunExplosion;
   stickExplosion        = gunExplosion;
   bloodExplosion        = gunExplosion;
   particleEmitter     = nailgunTrailEmitter; //bulletTrailEmitter;

   muzzleVelocity      = 190;
   velInheritFactor    = 0;

   armingDelay         = 0000;
   lifetime            = 6000;
   fadeDelay           = 5500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(quakeShotgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./spas.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Shotgun";
	iconName = "./shotgun";
	doColorShift = true;
	colorShiftColor = "0.65 0.65 0.65 1.000";

	 // Dynamic properties defined by the scripts
	image = quakeShotgunImage;
	canDrop = true;
};

datablock ProjectileData(quakeShotgunBlastProjectile : quakeShotgunProjectile)
{
   projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 100; //14;
   directDamageType    = $DamageType::quakeShotgun;
   radiusDamageType    = $DamageType::quakeShotgun;

   brickExplosionRadius = 0.4;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;
   brickExplosionMaxVolume = 25;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 35;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 300;
   verticalImpulse     = 100;
   explosion           = quakeShotgunExplosion;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 70;
   fadeDelay           = 0;
   isBallistic         = true;
   gravityMod = 0.0;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(quakeShotgunImage)
{
   // Basic Item properties
	shapeFile = "./spas.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = quakeShotgunProjectile;
   projectileType = Projectile;

	casing = quakeShotgunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 9.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = quakeShotgunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.15;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakeShotgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= quakeShotgunFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.18;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Fire";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.5;
	stateTransitionOnTimeout[5]     = "Wait";
	stateSound[5]					= quakeShotgunReloadSound;
	stateEjectShell[5]       = true;

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.04;
	stateTransitionOnTimeout[6]     = "Ready";
};

function quakeShotgunImage::onFire(%this,%obj,%slot)
{
	%projectile = quakeShotgunProjectile;
	%spread = 0.0028;
	%shellcount = 9;

	%obj.playThread(2, plant);
	%obj.playThread(0, shiftAway);
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-6")));
	%obj.spawnExplosion(QuakeBigRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}

	%projectile = quakeShotgunBlastProjectile;
	%spread = 0.0001;
	%shellcount = 1;
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}

function quakeShotgunImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, plant);	
	%obj.playThread(0, shiftleft);
}
