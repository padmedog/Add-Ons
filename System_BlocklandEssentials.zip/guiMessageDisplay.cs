function blrs_showNone()
{
	blrsTextAll.visible = false;
	blrsTextStatus.visible = false;
	blrsTextChats.visible = false;
	blrsTextEvents.visible = false;
	blrsTextAdmin.visible = false;
}

function blrs_showAll()
{
	blrs_showNone();
	blrsTextAll.visible = true;
}

function blrs_showStatus()
{
	blrs_showNone();
	blrsTextStatus.visible = true;
}

function blrs_showChats()
{
	blrs_showNone();
	blrsTextChats.visible = true;
}

function blrs_showEvents()
{
	blrs_showNone();
	blrsTextEvents.visible = true;
}

function blrs_showAdmin()
{
	blrs_showNone();
	blrsTextAdmin.visible = true;
}

function blrs_addStatus(%text)
{
	blrsTextAll.getObject(0).getObject(0).addRow(1,%text);
	blrsTextStatus.getObject(0).getObject(0).addRow(1,%text);
	if(blrs_Scrollbox.getValue())
		blrsTextStatus.getObject(0).scrollToBottom();
	if(blrs_Scrollbox.getValue())
		blrsTextAll.getObject(0).scrollToBottom();
}

function blrs_addChats(%text)
{
	blrsTextAll.getObject(0).getObject(0).addRow(1,%text);
	blrsTextChats.getObject(0).getObject(0).addRow(1,%text);
	if(blrs_Scrollbox.getValue())
		blrsTextChats.getObject(0).scrollToBottom();
	if(blrs_Scrollbox.getValue())
		blrsTextAll.getObject(0).scrollToBottom();
}

function blrs_addEvents(%text)
{
	blrsTextAll.getObject(0).getObject(0).addRow(1,%text);
	blrsTextEvents.getObject(0).getObject(0).addRow(1,%text);
	if(blrs_Scrollbox.getValue())
		blrsTextEvents.getObject(0).scrollToBottom();
	if(blrs_Scrollbox.getValue())
		blrsTextAll.getObject(0).scrollToBottom();
}

function blrs_addAdmin(%text)
{
	blrsTextAll.getObject(0).getObject(0).addRow(1,%text);
	blrsTextAdmin.getObject(0).getObject(0).addRow(1,%text);
	if(blrs_Scrollbox.getValue())
		blrsTextAdmins.getObject(0).scrollToBottom();
	if(blrs_Scrollbox.getValue())
		blrsTextAll.getObject(0).scrollToBottom();
}

function blrs_clear()
{
	blrsTextAll.getObject(0).getObject(0).clear();
	blrsTextAdmin.getObject(0).getObject(0).clear();
	blrsTextEvents.getObject(0).getObject(0).clear();
	blrsTextChats.getObject(0).getObject(0).clear();
	blrsTextStatus.getObject(0).getObject(0).clear();
}
