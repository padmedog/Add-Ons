AddDamageType("MavMagnum",   '<bitmap:add-ons/Weapon_Skins_Magnum/CI_Semiauto_Magnum> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Magnum/CI_Semiauto_Magnum> %1',0.75,1);
AddDamageType("MavMagnumHeadshot",   '<bitmap:add-ons/Weapon_Skins_Magnum/CI_Semiauto_Magnum><bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Magnum/CI_Semiauto_Magnum><bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',0.75,1);
datablock ProjectileData(MavMagnumProjectile : MagnumProjectile)
{
   directDamageType    = $DamageType::MavMagnum;
   radiusDamageType    = $DamageType::MavMagnum;
};

//////////
// item //
//////////
datablock ItemData(MavMagnumItem : MagnumItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
   shapeFile = "./Mav_magnum.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Mav Magnum";
	iconName = "./mavmagnum";
	doColorShift = true;
	colorShiftColor = "0.4 0.4 0.46 1";
	l4ditemtype = "secondary";

	 // Dynamic properties defined by the scripts
	image = MavMagnumImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 6;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MavMagnumImage : MagnumImage)
{
   // Basic Item properties
   shapeFile = "./Mav_magnum.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = MavMagnumItem;
   ammo = " ";
   projectile = MavMagnumProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = MavMagnumItem.colorShiftColor;
};

function MavMagnumImage::onFire(%this,%obj,%slot)
{
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, shiftAway);
        serverPlay3D(MagnumFireSound,%obj.getPosition());

	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
}

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0013;
	}
	else
	{
		%spread = 0.0000;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};

	%projectile = "shotgunFlashProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;
	}
}

function MavMagnumImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}

function MavMagnumImage::onReloadStart(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		
    if(%obj.client.quantity["880rounds"] >= 1)
	{
	%obj.playThread(2, shiftto);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}
function MavMagnumImage::onEject(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		
    if(%obj.client.quantity["880rounds"] >= 1)
	{
	%obj.playThread(2, shiftleft);
            serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}

function MavMagnumImage::onReloaded(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["880rounds"] >= 1)
	{
		%obj.client.quantity["880rounds"]--;
		serverPlay3D(reloadClick5Sound,%obj.getPosition());
		%obj.playThread(2, shiftright);
		%obj.toolAmmo[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.880 Magnum <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["880rounds"] @ "", 4, 2, 3, 4); 
	}
}
}

//needs more critical headshots. the magnum feels like a posing pistol right now :(
//using a weird offshoot of the huntsman's code for the moment

function MavMagnumProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 40;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 2;
         %damageType = $DamageType::MagnumHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}