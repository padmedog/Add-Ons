
datablock AudioProfile(radioWaveExplosionSound)
{
   filename    = "./radioWaveExplosion.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(radioWaveTravelSound)
{
   filename    = "./radioWaveTravel.wav";
   description = AudioClosestLooping3d;
   preload = true;
};

//explosion
datablock ParticleData(radioWaveExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "./bolt";
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "1 1 0.5 1";
   colors[1]     = "1 1 0.0 1";
	colors[2]     = "1 0 0 0";
	sizes[0]      = 0.5;
   sizes[1]      = 0.25;
	sizes[2]      = 0.0;
   times[0] = 0;
   times[1] = 0.5;
   times[2] = 1.0;
};

datablock ParticleEmitterData(radioWaveExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.5;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "radioWaveExplosionParticle";

   useEmitterColors = true;

   uiName = "Radio Wave Explosion";
};

datablock ExplosionData(radioWaveExplosion)
{
   //explosionShape = "";
	soundProfile = radioWaveExplosionSound;

   lifeTimeMS = 150;

   particleEmitter = radioWaveExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 0;
   lightStartColor = "1 1 0.5";
   lightEndColor = "0 0 0";
};


//trail
datablock ParticleData(radioWaveTrailParticle)
 {
   dragCoefficient      = 3;
   gravityCoefficient   = -0.0;
   inheritedVelFactor   = 1.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 200;
   lifetimeVarianceMS   = 0;
   textureName          = "./bolt";
   spinSpeed		   = 0.0;
   spinRandomMin		= 0.0;
   spinRandomMax		= 0.0;
   colors[0]     = "1 1 0.2 0.9";
   colors[1]     = "1 1 0.1 0.5";
   colors[2]     = "1 1 0 0";

   sizes[0]      = 0.5;
   sizes[1]      = 0.5;
   sizes[2]      = 0.5;

   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;

   useInvAlpha = false;
};
datablock ParticleEmitterData(radioWaveTrailEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "radioWaveTrailParticle";

   useEmitterColors = true;

   uiName = "Radio Wave Trail";
};

datablock ProjectileData(radioWaveProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   explosion           = radioWaveExplosion;
   particleEmitter     = radioWaveTrailEmitter;
   explodeOnDeath = true;

   brickExplosionRadius = 0;
   brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   collideWithPlayers = false;

   sound = radioWaveTravelSound;

   muzzleVelocity      = 65;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 30000;
   fadeDelay           = 29500;
   bounceElasticity    = 0.99;
   bounceFriction      = 0.00;
   isBallistic         = true;
   gravityMod          = 0.0;

   hasLight    = true;
   lightRadius = 1.0;
   lightColor  = "1.0 1.0 0.5";

   uiName = "Radio Wave"; 
};