if(!($pref::server::autosaves > 0) && !($pref::server::autosaves < 0))
	$pref::server::autosaves = 0;

$pref::server::autosaveOmitOwnership = true;

function autoSaverLoop()
{
	if(!$autosaving)
		return;
	if(!$brickSinceAutosave)
	{
		echo("No bricks have been placed since last autosave, aborting!");
		talk("No bricks have been placed since last autosave, aborting!");
		cancel($autosavesch);
		$autosavesch = schedule(900000,0,autoSaverLoop);
		return;
	}
	talk("Autosaving!");
	echo("Autosaving!");
	$autosavestarttime = getSimTime();
	cancel($autosavesch);
	$autosavesch = schedule(900000,0,autoSaverLoop);
	BVSS_saveBricks("saves/bvss/autosaves/" @ $pref::server::autosaves @ ".bvs",$pref::server::autosaveOmitOwnership,"Autosaved!");
	$pref::server::autosaves++;
	talk("Saved to " @ "saves/bvss/autosaves/" @ $pref::server::autosaves @ ".bvs" SPC "in" SPC getSimTime() SPC "-" SPC $autosavestarttime SPC "ms");
	echo("Saved to " @ "saves/bvss/autosaves/" @ $pref::server::autosaves @ ".bvs" SPC "in" SPC getSimTime() SPC "-" SPC $autosavestarttime SPC "ms");
	$brickSinceAutosave = false;
}

function servercmdbvsssave(%client,%file,%da,%db,%dc,%dd,%de)
{
	%description = %da SPC %db SPC %dc SPC %dd SPC %de;
	%file = "saves/bvss/" @ %file @ ".bvs";
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		talk(%client.name SPC "saved bricks to" SPC %file);
		BVSS_saveBricks(%file,1,%description);
	}
	else
		messageclient(%client,'',"You must be admin!");
}

function servercmdbvsssaveownership(%client,%file,%da,%db,%dc,%dd,%de)
{
	%description = %da SPC %db SPC %dc SPC %dd SPC %de;
	%file = "saves/bvss/" @ %file @ ".bvs";
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		talk(%client.name SPC "saved bricks to" SPC %file);
		BVSS_saveBricks(%file,0,%description);
	}
	else
		messageclient(%client,'',"You must be admin!");
}

function servercmdbvssload(%client,%file)
{
	%file = "saves/bvss/" @ %file @ ".bvs";
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		talk(%client.name SPC "loaded the bricks from" SPC %file);
		BVSS_loadBricks(%file,%client);
	}
	else
		messageclient(%client,'',"You must be admin!");
}

function servercmdautosaveron(%client)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		$autosaving = true;
		talk(%client SPC "turned the autosaver on!");
		autoSaverLoop();
	}
}

function servercmdautosaveroff(%client)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		talk(%client SPC "turned the autosaver off!");
		$autosaving = false;
		cancel($autosavesch);
	}
}

package autosaveCheck
{
	function fxDTSBrick::onPlant(%brick)
	{
		parent::onPlant(%brick);
		$brickSinceAutosave = true;
	}
};
activatepackage(autosaveCheck);
