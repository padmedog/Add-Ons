 datablock PlayerData(RotWitchZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;
	
	mass = 500;
	maxDamage = 450;
	runforce = 440 * 90;
	maxForwardSpeed = 30;
	maxBackwardSpeed = 25;
	maxSideSpeed = 15;
	attackpower = 10;
	jumpsound = "ZombieJumpSound";
	
	BrickDestroyMaxVolume = 100;
	BrickMaxJumpHeight = 25;
	uiName = "Zombie Witch";
	rideable = true;
	canRide = true;
	BrickKillRadius = 1;
	skinColor = "0.1 0.1 0.1 1";
	FollowAnim = "ArmReadyBoth";
	noRandomwalk = 1;
	zNoCrouch = 1;
	zNoJump = 1;
	SearchRadius = 10;
	AnimationWhenStopped = "Sit";
	OneAtATime = 1;
	SpecialAttack = 1;
	zDeathSound = "WitchDeathsound";
	ignorePipeBombs = 1;
};
function RotWitchZombie::SpecialAttack(%this,%onshot)
{
	if(isobject(%this) && %this.lastspecial+5000 < getsimtime())
	{
		%this.playaudio(2,"WitchAttack" @ getrandom(1,2) @ "Sound");
		%this.lastspecial = getsimtime();
	}
}
function RotWitchZombie::ondisabled(%this,%obj)
{
	%obj.spawnbrick.setlight("");
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotWitchZombie::onRemove(%this,%obj)
{
	%obj.spawnbrick.setlight("");
	parent::onRemove(%this,%obj);
}
function RotWitchZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	if(%col.getclassname() $= player && %col.client.minigame.EnableDowned == 1 && IsInSameMinigame(%col,%obj) == 1 && %col.isdowned != 1 && %obj.getstate() !$= "dead" && %col.client.minigame.EnableZombies == 1)
	{
		if(%obj.isfollowingid == %col)
		{
			%col.downer = %obj;
			%col.kill();
		}
	}
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotWitchZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotWitchZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotWitchZombie::onAdd(%this,%obj)
{
	%obj.playthread(1,sit);
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
	witchify(%obj);
	schedule(20,0,witchStuff,%obj);
}
function witchify(%obj)
{
	%obj.name = "Witch";
	%obj.chestcolor = "0.2 0.2 0.2 1";
	//%obj.hatcolor = "0.72  0.53 0.29 1";
	%obj.rarmcolor = "0.2 0.2 0.2 1";
	%obj.larmcolor = "0.2 0.2 0.2 1";
	%obj.hipcolor = "0.078 0.078 0.078 1";
	%obj.llegcolor = "0.2 0.2 0.2 1";
	%obj.rlegcolor = "0.2 0.2 0.2 1";

	%obj.chest = "1";
	%obj.lhand = "0";
	%obj.rhand = "0";
	%obj.larm = "1";
	%obj.rarm = "1";
	%obj.hat = "0";
	%obj.accent = "0";
	%obj.pack = "0";
	%obj.secondpack = "0";
	%obj.lleg = "0";
	%obj.rleg = "0";
	%obj.hip = "0";

	//servercmdupdatebodyparts(%obj,6);
}
function witchStuff(%obj)
{
	%obj.setfacename("asciiTerror");
	%obj.setdecalname("");
	%obj.spawnbrick.setlight("RedLight");
	witchCryLoop(%obj);
}
function witchCryLoop(%obj)
{
	cancel(%obj.cryloop);
	if(isobject(%obj) && %obj.isfollowing == 0 && isobject(%obj.minigame))
	{
		%obj.playaudio(2,"WitchCry" @ getrandom(1,4) @ "Sound");
		%obj.cryloop = schedule(4000,%obj,witchCryLoop,%obj);
	}
}