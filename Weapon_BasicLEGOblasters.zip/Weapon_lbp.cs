//lbp.cs

datablock ParticleData(lbpTrailParticle)
{
	dragCoefficient		= 2.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 30;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= " ";

	colors[0]	= "1 0.4 0.2 1.0";
	colors[1]	= "1 0.4 0.2 0.0";
	sizes[0]	= 0.13;
	sizes[1]	= 0.25;
	//times[0]	= 0.5;
	//times[1]	= 0.5;
};

datablock ParticleEmitterData(lbpTrailEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = lbpTrailParticle;

   useEmitterColors = true;
   uiName = "LEGO Blaster Pistol Trail";
};

datablock ParticleData(lbpExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 1;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 100;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 2.0;
	spinRandomMin		= -20.0;
	spinRandomMax		= 20.0;
	colors[0]     = "1.0 0.4 0.2 0.5";
	colors[1]     = "1.0 0.4 0.2 0.0";
	sizes[0]      = 0.75;
	sizes[1]      = 0.0;

	useInvAlpha = true;
};

datablock ParticleEmitterData(lbpExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "lbpExplosionParticle";

   useEmitterColors = true;
   uiName = "LEGO Blaster Pistol Explosion";
};

datablock ExplosionData(lbpExplosion)
{
   //explosionShape = "";
	soundProfile = lbsHitSound;

   lifeTimeMS = 150;

   particleEmitter = lbpExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1.5 1.5 1.5";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 3;
   lightStartColor = "1 0.4 0.2 1";
   lightEndColor = "1 0.4 0.2 1";
};


AddDamageType("lbp",   '<bitmap:add-ons/Weapon_BasicLEGOblasters/CI_lbp> %1',    '%2 <bitmap:add-ons/Weapon_BasicLEGOblasters/CI_lbp> %1',0.2,1);
datablock ProjectileData(lbpProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 25;
   directDamageType    = $DamageType::lbp;
   radiusDamageType    = $DamageType::lbp;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 1;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse	  = 200;
   explosion           = lbpExplosion;
   particleEmitter     = lbpTrailEmitter;

   muzzleVelocity      = 70;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "1 0.4 0.2 1";

   uiName = "LEGO Blaster Pistol Laser";
};

//////////
// item //
//////////
datablock ItemData(lbpItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./lbp.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "LEGO Blaster Pistol";
	iconName = "./icon_lbp";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = lbpImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(lbpImage)
{
   // Basic Item properties
   shapeFile = "./lbp.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = lbpProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = lbpItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.14;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= lbsShot1Sound;

	stateName[3]			= "Reload";
	stateSequence[3]                = "Reload";
	stateTransitionOnTriggerUp[3]     = "Ready";
	stateSequence[3]	= "Ready";

};

function lbpImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, shiftAway);
	Parent::onFire(%this,%obj,%slot);	
}
