function CreateChunk_Plains_SolidG()
{
	for(%Cz=1;%Cz<=$TerHO;%Cz=%Cz+2) 
	{
		%brick = new fxDTSbrick()
		{
			datablock = $FxCB;
			position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %Cz;
			rotation = "0 0 0 0";
			scale = "1 1 1";
			colorID = $ColDirt;
			colorFXID = 0;
			shapefxID = 0;
			angleID = 0;
			printID = $PriDirt;
			client = $cl;
			stackBL_ID = $cl.bl_id;
			isPlanted = 1;
			PTG = 1;
		};
		$clBG.add(%brick);
		%brick.setTrusted(1);
		%brick.plant();

		if(%Cz<=$TerHO*0.75)
		{
			%brick.colorID = $ColDirtb;
			%brick.setPrint = $PriDirtb;
		}
		if(%Cz<=$TerHO*0.5)
		{
			%brick.colorID = $ColStone;
			%brick.setPrint = $PriStone;
		}
	}
	if($PlaC==1)
	{
		%brick = new fxDTSbrick()
		{
			datablock = brick4x4FData;
			position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz-1);
			rotation = "0 0 0 0";
			scale = "1 1 1";
			colorID = $ColDirt;
			colorFXID = 0;
			shapefxID = 0;
			angleID = 0;
			client = $cl;
			stackBL_ID = $cl.bl_id;
			isPlanted = 1;
			PTG = 1;
		};
		$clBG.add(%brick);
		%brick.setTrusted(1);
		%brick.plant();
	}
	%brick.colorID = $ColBio;
	CreateChunk_Biomes(%brick);

	if($LDet==1 || $SDet==1 || $MDet==1)
		CreateChunk_Details(%brick);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Plains_EmptyG()
{
	for(%Cz=1;%Cz<=$TerHO;%Cz=%Cz+2) 
	{
		if(%Cz>=$TerHO-4)
		{
			%brick = new fxDTSbrick()
			{
				datablock = $FxCB;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %Cz;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if(%Cz<=$TerHO*0.75)
				%brick.colorID = $ColDirtb;
			if(%Cz<=$TerHO*0.5)
				%brick.colorID = $ColStone;
		}
	}
	if($PlaC==1)
	{
		%brick = new fxDTSbrick()
		{
			datablock = brick4x4FData;
			position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz-1);
			rotation = "0 0 0 0";
			scale = "1 1 1";
			colorID = $ColDirt;
			colorFXID = 0;
			shapefxID = 0;
			angleID = 0;
			client = $cl;
			stackBL_ID = $cl.bl_id;
			isPlanted = 1; 
			PTG = 1;
		};
		$clBG.add(%brick);
		%brick.setTrusted(1);
		%brick.plant();
	}
	%brick.colorID = $ColBio;
	CreateChunk_Biomes(%brick);

	if($LDet==1 || $SDet==1 || $MDet==1)
		CreateChunk_Details(%brick);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Normal_SolidG_Caves()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;

	if($Holes==1 && $RHfsM<=0)
		$RHfsM = -1;
	if($Holes==0 && $RHfsM<=0)
		$RHfsM = 1;

	for(%Cz=0;%Cz>=(-$RHfsM*1.5);%Cz=%Cz-2)
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+%Cz);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext())
		{
			if(($TerHO+%Cz)>=1 && $RHfsM>-1)
			{
				%brick = new fxDTSbrick()
				{
					datablock = $FxCB;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+%Cz);
					rotation = "0 0 0 0";
					scale = "1 1 1";
					colorID = $ColDirt;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriDirt;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();
			
				if(%Cz<$RHfsM)
				{
					if(%Cz<=($RHfsM*0.5) && %Cz>=(-$RHfsM*0.5))
					{
						%brick.colorID = $ColDirtb;
						%brick.setPrint($PriDirtb);
					}
					if(%Cz<(-$RHfsM*0.5))
					{
						%brick.colorID = $ColStone;
						%brick.setPrint($PriStone);
					}
				}
			}
		}
		if(%Cz==0) 
		{
			if($PlaC==1)
			{
				CreateChunk_Biomes(%brick);
				%brick.colorID = $BioDrCl;
				%brick.printID = $BioDrPr;

				if($RHfsM>$SanL)
				{
					%brick = new fxDTSbrick()
					{
						datablock = brick4x4FData;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+1);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColDirt;
						colorFXID = 0;
						shapefxID = 0;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();
				}
			}
			$WatC = $ColBioWat;
			CreateChunk_Biomes(%brick);

			if($LDet==1 || $SDet==1 || $MDet==1)
				CreateChunk_Details(%brick);
		}
	}
	%RHfsMT = $RHfsM;

	if(%RHfsMT<1)
		%RHfsMT=1;

	for(%Cz=%RHfsMT;%Cz>=1;%Cz=%Cz-2) 
	{
		%CzT = %Cz;
		if(%CzT<1)
			%CzT=1;

		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %CzT;
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext())
		{
			if(%CzbT<1)
				%CzbT=1;
			
			%brick = new fxDTSbrick()
			{
				datablock = $FxCB;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %CzT;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColStone;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriStone;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
	if($GFill==1)
		CreateChunk_GapFill();
	if($WatL>0 && $RHfsM<$WatL)
		CreateChunk_Water();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Normal_SolidG_NoCaves()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;

	if($Holes==1 && $RHfsM<=0)
		$RHfsM = -1;
	if($Holes==0 && $RHfsM<=0)
		$RHfsM = 1;
	
	for(%Cz=($TerHO+$RHfsM);%Cz>=1;%Cz=%Cz-2) 
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext())
		{
			if(%Cz>=1 && $RHfsM>-1)
			{
				%brick = new fxDTSbrick()
				{
					datablock = $FxCB;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
					rotation = "0 0 0 0";
					scale = "1 1 1";
					colorID = $ColDirt;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriDirt;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();

				if(%Cz<($TerHO+$RHfsM))
				{
					if(%Cz<=(($TerHO+$RHfsM)*0.75))
					{
						%brick.colorID = $ColDirtb;
						%brick.setPrint($PriDirtb);
					}
					if(%Cz<=(($TerHO+$RHfsM)*0.5))
					{
						%brick.colorID = $ColStone;
						%brick.setPrint($PriStone);
					}
				}
			}
		}
		if(%Cz==($TerHO+$RHfsM)) 
		{
			if($PlaC==1)
			{
				CreateChunk_Biomes(%brick);
				%brick.colorID = $BioDrCl;
				%brick.printID = $BioDrPr;

				if($RHfsM>$SanL)
				{
					%brick = new fxDTSbrick()
					{
						datablock = brick4x4FData;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+1);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColDirt;
						colorFXID = 0;
						shapefxID = 0;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();
				}
			}
			$WatC =  $ColBioWat;
			CreateChunk_Biomes(%brick);

			if($LDet==1 || $SDet==1 || $MDet==1)
				CreateChunk_Details(%brick);
		}
	}
	if($GFill==1)
		CreateChunk_GapFill();
	if($WatL>0 && $RHfsM<$WatL)
		CreateChunk_Water();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Normal_EmptyG_Caves()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;

	if($Holes==1 && $RHfsM<=0)
		$RHfsM = -1;
	if($Holes==0 && $RHfsM<=0)
		$RHfsM = 1;

	for(%Cz=$RHfsM;%Cz>=(-$RHfsM*1.5);%Cz=%Cz-2)
	{
		if(%Cz>=$RHfsM-2 || %Cz<=((-$RHfsM*1.5)+6))	//if(%Cz>=$RHfsM-4 || %Cz<=((-$RHfsM*1.5)+8)) //!
		{
			%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
			%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
			initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

			if(!(%brick=containerSearchNext()))
			{
				if(($TerHO+%Cz)>1 && $RHfsM>-1) 
				{
					%brick = new fxDTSbrick()
					{
						datablock = $FxCB;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColDirt;
						colorFXID = 0;
						shapefxID = 0;
						printID = $PriDirt;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();

					if(%Cz<$RHfsM)
					{
						if(%Cz<=($RHfsM*0.5) && %Cz>=(-$RHfsM*0.5))
						{
							%brick.colorID = $ColDirtb;
							%brick.setPrint($PriDirtb);
						}
						if(%Cz<(-$RHfsM*0.5))
						{
							%brick.colorID = $ColStone;
							%brick.setPrint($PriStone);
						}
					}
				}
			}
		}
		if(%Cz==$RHfsM) 
		{
			if($PlaC==1)
			{
				CreateChunk_Biomes(%brick);
				%brick.colorID = $BioDrCl;
				%brick.printID = $BioDrPr;

				if($RHfsM>$SanL)
				{
					%brick = new fxDTSbrick()
					{
						datablock = brick4x4FData;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+1);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColDirt;
						colorFXID = 0;
						shapefxID = 0;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();
				}
			}
			$WatC =  $ColBioWat;
			CreateChunk_Biomes(%brick);

			if($LDet==1 || $SDet==1 || $MDet==1)
				CreateChunk_Details(%brick);
		}
	}
	%RHfsMT = $RHfsM;
	if(%RHfsMT<1)
		%RHfsMT=1;

	for(%Czb=%RHfsMT;%Czb>=1;%Czb=%Czb-2) 
	{
		if(%Czb>=(%RHfsMT-2) && %Czb<($TerHO+%Cz))	//if(%Czb>=(%RHfsMT-4) && %Czb<($TerHO+%Cz))
		{
			%CzbT = %Czb;
			if(%CzbT<1)
				%CzbT=1;

			%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %CzbT;
			%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
			initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

			if(!%brick=containerSearchNext())
			{
				if(%CzbT<1)
					%CzbT=1;

				%brick = new fxDTSbrick()
				{
					datablock = $FxCB;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %CzbT;
					rotation = "0 0 0 0";
					scale = "1 1 1";
					colorID = $ColStone;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriStone;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();
			}
		}
	}
	if($WatL>0 && $RHfsM<$WatL)
		CreateChunk_Water();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Normal_EmptyG_NoCaves()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;

	if($Holes==1 && $RHfsM<=0)
		$RHfsM = -1;
	if($Holes==0 && $RHfsM<=0)
		$RHfsM = 1;
	
	for(%Cz=$RHfsM;%Cz>=($RHfsM-2);%Cz=%Cz-2)
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext())
		{
			if($RHfsM>-1)
			{
				%brick = new fxDTSbrick()
				{
					datablock = $FxCB;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
					rotation = "0 0 0 0";
					scale = "1 1 1";
					colorID = $ColDirt;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriDirt;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();
			}
		}
		if(%Cz==$RHfsM)
		{
			if($PlaC==1)
			{
				CreateChunk_Biomes(%brick);

				%brick.colorID = $BioDrCl;
				%brick.printID = $BioDrPr;

				if($RHfsM>$SanL)
				{
					%brick = new fxDTSbrick()
					{
						datablock = brick4x4FData;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+1);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColDirt;
						colorFXID = 0;
						shapefxID = 0;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();
				}
			}
			$WatC =  $ColBioWat;
			CreateChunk_Biomes(%brick);

			if($LDet==1 || $SDet==1 || $MDet==1)
				CreateChunk_Details(%brick);
			if($WatL>0 && $RHfsM<$WatL)
				CreateChunk_Water();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_FloatingIslands_SolidG()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;

	if($Holes==1 && $RHfsM<=0)
		$RHfsM = -1;
	if($Holes==0 && $RHfsM<=0)
		$RHfsM = 1;

	for(%Cz=$RHfsM;%Cz>=(-$RHfsM*1.5)+$FISH*3;%Cz=%Cz-2)
	{
		if($RHfsM>$FISH && ($TerHO+%Cz)>1)
		{
			%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
			%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
			initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

			if(!%brick=containerSearchNext())
			{
				//if(($TerHO+%Cz)>1)
				//{
					%brick = new fxDTSbrick()
					{
						datablock = $FxCB;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColStone;
						colorFXID = 0;
						shapefxID = 0;
						printID = $PriStone;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();
				//}
			}
			if(%Cz==$RHfsM) 
			{
				if($PlaC==1)
				{
					CreateChunk_Biomes(%brick);
					%brick.colorID = $BioDrCl;
					%brick.printID = $BioDrPr;

					if(($RHfsM-$FISH)>$SanL)
					{
						%brick = new fxDTSbrick()
						{
							datablock = brick4x4FData;
							position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+1);
							rotation = "0 0 0 0";
							scale = "1 1 1";
							colorID = $ColDirt;
							colorFXID = 0;
							shapefxID = 0;
							angleID = 0;
							client = $cl;
							stackBL_ID = $cl.bl_id;
							isPlanted = 1;
							PTG = 1;
						};
						$clBG.add(%brick);
						%brick.setTrusted(1);
						%brick.plant();
					}
				}
				$WatC =  $ColBioWat;
				CreateChunk_Biomes(%brick);

				if(($RHfsM-$FISH)<=$SanL)
				{
					%brick.colorID = $ColSand;
					%brick.setPrint($PriSand);
				}
				if($LDet==1 || $SDet==1 || $MDet==1)
					CreateChunk_Details(%brick);
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_FloatingIslands_EmptyG()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;

	if($Holes==1 && $RHfsM<=0)
		$RHfsM = -1;
	if($Holes==0 && $RHfsM<=0)
		$RHfsM = 1;

	%t = ((-$RHfsM*1.5)+$FISH*3);
	
	for(%Cz=$RHfsM;%Cz>=%t;%Cz=%Cz-2)
	{
		if($RHfsM>$FISH && ($TerHO+%Cz)>1 && (%Cz>=$RHfsM-2 || %Cz<=%t+6)) //&& (%Cz>=$RHfsM-4 || %Cz<=%t+8))
		{
			%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
			%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
			initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

			if(!%brick=containerSearchNext())
			{
				//if(($TerHO+%Cz)>1)
				//{
					%brick = new fxDTSbrick()
					{
						datablock = $FxCB;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+%Cz);
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColDirt;
						colorFXID = 0;
						shapefxID = 0;
						printID = $PriDirt;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();

					if(%Cz<$RHfsM)
					{
						%brick.colorID = $ColStone;
						%brick.setPrint($PriStone);
					}
				//}
			}
			if(%Cz==$RHfsM) 
			{
				if($PlaC==1)
				{
					CreateChunk_Biomes(%brick);
					%brick.colorID = $BioDrCl;
					%brick.printID = $BioDrPr;

					if(($RHfsM-$FISH)>$SanL)
					{
						%brick = new fxDTSbrick()
						{
							datablock = brick4x4FData;
							position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($TerHO+$RHfsM+1);
							rotation = "0 0 0 0";
							scale = "1 1 1";
							colorID = $ColDirt;
							colorFXID = 0;
							shapefxID = 0;
							angleID = 0;
							client = $cl;
							stackBL_ID = $cl.bl_id;
							isPlanted = 1;
							PTG = 1;
						};
						$clBG.add(%brick);
						%brick.setTrusted(1);
						%brick.plant();
					}
				}
				$WatC =  $ColBioWat;
				CreateChunk_Biomes(%brick);

				if(($RHfsM-$FISH)<=$SanL)
				{
					%brick.colorID = $ColSand;
					%brick.setPrint($PriSand);
				}
				if($LDet==1 || $SDet==1 || $MDet==1)
					CreateChunk_Details(%brick);
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Biomes(%brick)
{
	if(isObject(%brick))
	{
		if($RHfsM<=$SanL)
		{
			%brick.colorID = $ColSand;
			%brick.setPrint($PriSand);
			$BioDrCl = $ColSand;

			if($WatL>0 && $RHfsM<=$WatL)
			{
				if($BioA==1)
				{
					$WatC = $ColBioWat;
					$WatP = $PriBioWat;
				}
				if(($BioC==1 && $RHfsBio>$BioSH) || ($BioC==1 && $NN==1))
				{
					$WatC = $ColBiocWat;
					$WatP = $PriBiocWat;
				}
				if(($BioD==1 && $RHfsBiob>$BioSH) || ($BioD==1 && $NN==1))
				{
					$WatC = $ColBiodWat;
					$WatP = $PriBiodWat;
				}
				if(($BioE==1 && $RHfsBio>$BioSH && $RHfsBiob>$BioSH) || ($BioE==1 && $NN==1))
				{
					$WatC = $ColBioeWat;
					$WatP = $PriBioeWat;
				}
			}
		}
		if($RHfsM>$SanL)
		{
			if($BioA==1)
			{
				%brick.colorID = $ColBio;
				$BDet = BiomeA;
				%brick.setPrint($PriBio);
				$BioDrCl = $ColBioDrt;
				$BioDrPr = $PriBioDrt;
			}
			if(($BioC==1 && $RHfsBio>$BioSH) || ($BioC==1 && $NN==1))
			{
				%brick.colorID = $ColBioc;
				$BDet = BiomeC;
				%brick.setPrint($PriBioc);
				$BioDrCl = $ColBiocDrt;
				$BioDrPr = $PriBiocDrt;
			}
			if(($BioD==1 && $RHfsBiob>$BioSH) || ($BioD==1 && $NN==1))
			{
				%brick.colorID = $ColBiod;
				$BDet = BiomeD;
				%brick.setPrint($PriBiod);
				$BioDrCl = $ColBiodDrt;
				$BioDrPr = $PriBiodDrt;
			}
			if(($BioE==1 && $RHfsBio>$BioSH && $RHfsBiob>$BioSH) || ($BioE==1 && $NN==1))
			{
				%brick.colorID = $ColBioe;
				$BDet = BiomeE;
				%brick.setPrint($PriBioe);
				$BioDrCl = $ColBioeDrt;
				$BioDrPr = $PriBioeDrt;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Details(%brick)
{
	if(isObject(%brick))
	{
		%BP = %brick.gettransform();
		%BPx = getword(%BP, 0);
		%BPy = getword(%BP, 1);
		%BPz = getword(%BP, 2);
		%DetTN = mCos(%BPx @ %BPy @ %BPz);
		%DetT = getSubStr(%DetTN,StrLen(%DetTN)-1,1);

		%DetTNb = mCos(%BPx * %BPy);
		%DetTF = getSubStr(%DetTNb,StrLen(%DetTNb)-1,1);
		%DetTF = %DetTF @ 0;
		%DetTVT = %DetTNb;

		if(StrLen(%DetTVT)<2)
			%DetTVT=%DetTN;

		%DetTV = getSubStr(%DetTVT,StrLen(%DetTVT)-2,1);
		%BT = %brick.getWorldBox();
		%BT = getWord(%BT,5);

		%DetBG = false;

		if(%DetT==3 && %DetTF<=$DetF && $LDet==1)
		{
			if(%BT>($SanL+$TerHO))
			{
				if($BDet $= BiomeA)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBioLDet;
						%DetC = $ColBioLDet;
						%DetP = $PriBioLDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBioLDetb;
						%DetC = $ColBioLDetb;
						%DetP = $PriBioLDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBioLDetc;
						%DetC = $ColBioLDetc;
						%DetP = $PriBioLDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeC)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiocLDet;
						%DetC = $ColBiocLDet;
						%DetP = $PriBiocLDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiocLDetb;
						%DetC = $ColBiocLDetb;
						%DetP = $PriBiocLDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiocLDetc;
						%DetC = $ColBiocLDetc;
						%DetP = $PriBiocLDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeD)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiodLDet;
						%DetC = $ColBiodLDet;
						%DetP = $PriBiodLDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiodLDetb;
						%DetC = $ColBiodLDetb;
						%DetP = $PriBiodLDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiodLDetc;
						%DetC = $ColBiodLDetc;
						%DetP = $PriBiodLDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeE)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBioeLDet;
						%DetC = $ColBioeLDet;
						%DetP = $PriBioeLDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBioeLDetb;
						%DetC = $ColBioeLDetb;
						%DetP = $PriBioeLDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBioeLDetc;
						%DetC = $ColBioeLDetc;
						%DetP = $PriBioeLDetc;
						%DetBG = true;
					}
				}
			}
			if(%BT<=($SanL+$TerHO))
			{
				if(%BT>($WatL+$TerHO))
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiobLDet;
						%DetC = $ColBiobLDet;
						%DetP = $PriBiobLDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiobLDetb;
						%DetC = $ColBiobLDetb;
						%DetP = $PriBiobLDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiobLDetc;
						%DetC = $ColBiobLDetc;
						%DetP = $PriBiobLDetc;
						%DetBG = true;
					}
				}
				if(%BT<($WatL+$TerHO-2))
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiofLDet;
						%DetC = $ColBiofLDet;
						%DetP = $PriBiofLDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiofLDetb;
						%DetC = $ColBiofLDetb;
						%DetP = $PriBiofLDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiofLDetc;
						%DetC = $ColBiofLDetc;
						%DetP = $PriBiofLDetc;
						%DetBG = true;
					}
				}
			}
		}

		//////////////////////////////////////////////////////////////////////

		if(%DetT==5 && %DetTF<=$DetF && $SDet==1)
		{
			if(%BT>($SanL+$TerHO))
			{
				if($BDet $= BiomeA)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBioSDet;
						%DetC = $ColBioSDet;
						%DetP = $PriBioSDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBioSDetb;
						%DetC = $ColBioSDetb;
						%DetP = $PriBioSDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBioSDetc;
						%DetC = $ColBioSDetc;
						%DetP = $PriBioSDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeC)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiocSDet;
						%DetC = $ColBiocSDet;
						%DetP = $PriBiocSDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiocSDetb;
						%DetC = $ColBiocSDetb;
						%DetP = $PriBiocSDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiocSDetc;
						%DetC = $ColBiocSDetc;
						%DetP = $PriBiocSDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeD)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiodSDet;
						%DetC = $ColBiodSDet;
						%DetP = $PriBiodSDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiodSDetb;
						%DetC = $ColBiodSDetb;
						%DetP = $PriBiodSDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiodSDetc;
						%DetC = $ColBiodSDetc;
						%DetP = $PriBiodSDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeE)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBioeSDet;
						%DetC = $ColBioeSDet;
						%DetP = $PriBioeSDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBioeSDetb;
						%DetC = $ColBioeSDetb;
						%DetP = $PriBioeSDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBioeSDetc;
						%DetC = $ColBioeSDetc;
						%DetP = $PriBioeSDetc;
						%DetBG = true;
					}
				}
			}
			if(%BT<=($SanL+$TerHO))
			{
				if(%BT>($WatL+$TerHO))
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiobSDet;
						%DetC = $ColBiobSDet;
						%DetP = $PriBiobSDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiobSDetb;
						%DetC = $ColBiobSDetb;
						%DetP = $PriBiobSDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiobSDetc;
						%DetC = $ColBiobSDetc;
						%DetP = $PriBiobSDetc;
						%DetBG = true;
					}
				}
				if(%BT<($WatL+$TerHO-2))
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiofSDet;
						%DetC = $ColBiofSDet;
						%DetP = $PriBiofSDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiofSDetb;
						%DetC = $ColBiofSDetb;
						%DetP = $PriBiofSDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiofSDetc;
						%DetC = $ColBiofSDetc;
						%DetP = $PriBiofSDetc;
						%DetBG = true;
					}
				}
			}
		}

		//////////////////////////////////////////////////////////////////////

		if(%DetT==7 && %DetTF<=$DetF && $MDet==1)
		{
			if(%BT>($SanL+$TerHO))
			{
				if($BDet $= BiomeA)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBioMDet;
						%DetC = $ColBioMDet;
						%DetP = $PriBioMDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBioMDetb;
						%DetC = $ColBioMDetb;
						%DetP = $PriBioMDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBioMDetc;
						%DetC = $ColBioMDetc;
						%DetP = $PriBioMDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeC)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiocMDet;
						%DetC = $ColBiocMDet;
						%DetP = $PriBiocMDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiocMDetb;
						%DetC = $ColBiocMDetb;
						%DetP = $PriBiocMDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiocMDetc;
						%DetC = $ColBiocMDetc;
						%DetP = $PriBiocMDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeD)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiodMDet;
						%DetC = $ColBiodMDet;
						%DetP = $PriBiodMDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiodMDetb;
						%DetC = $ColBiodMDetb;
						%DetP = $PriBiodMDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiodMDetc;
						%DetC = $ColBiodMDetc;
						%DetP = $PriBiodMDetc;
						%DetBG = true;
					}
				}
				if($BDet $= BiomeE)
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBioeMDet;
						%DetC = $ColBioeMDet;
						%DetP = $PriBioeMDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBioeMDetb;
						%DetC = $ColBioeMDetb;
						%DetP = $PriBioeMDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBioeMDetc;
						%DetC = $ColBioeMDetc;
						%DetP = $PriBioeMDetc;
						%DetBG = true;
					}
				}
			}
			if(%BT<=($SanL+$TerHO))
			{
				if(%BT>($WatL+$TerHO))
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiobMDet;
						%DetC = $ColBiobMDet;
						%DetP = $PriBiobMDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiobMDetb;
						%DetC = $ColBiobMDetb;
						%DetP = $PriBiobMDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiobMDetc;
						%DetC = $ColBiobMDetc;
						%DetP = $PriBiobMDetc;
						%DetBG = true;
					}
				}
				if(%BT<($WatL+$TerHO-2))
				{
					if(%DetTV>=0 && %DetTV<3)
					{
						%DetDB = $BriBiofMDet;
						%DetC = $ColBiofMDet;
						%DetP = $PriBiofMDet;
						%DetBG = true;
					}
					if(%DetTV>=3 && %DetTV<6)
					{
						%DetDB = $BriBiofMDetb;
						%DetC = $ColBiofMDetb;
						%DetP = $PriBiofMDetb;
						%DetBG = true;
					}
					if(%DetTV>=6 && %DetTV<9)
					{
						%DetDB = $BriBiofMDetc;
						%DetC = $ColBiofMDetc;
						%DetP = $PriBiofMDetc;
						%DetBG = true;
					}
				}
			}
		}

		//////////////////////////////////////////////////////////////////////

		if(%DetTF<=$DetF && (%DetBG $= true) && (%DetDB !$= NA))
		{
			%BHA = (%DetDB.brickSizeZ)*0.2;

			if(((%BT<($WatL+$TerHO-2)) && ((%BHA+%BT)>($WatL+$TerHO))))
				return;

			%brick = new fxDTSbrick()
			{
				datablock = %DetDB;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %BT;
				rotation = $DRot;
				scale = "1 1 1";
				colorID = %DetC;
				colorFXID = 0;
				shapefxID = 0;
				printID = %DetP;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%BHA = ((%brick.getDatablock().brickSizeZ)/2)*0.2;
			%brick.setTransform(($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%BT+%BHA));
			%brick.setTrusted(1);
			%brick.setRaycasting(1); //prevents issues with initContainerBoxSearch
			%brick.plant();

			%bhb = BrickBlockheadBot_HoleSpawnData;
			%hb = BrickHorseBot_HoleSpawnData;
			%sb = BrickSharkBot_HoleSpawnData;
			%zb = BrickZombie_HoleSpawnData;

			if((%DetDB $= %bhb) || (%DetDB $= %hb) || (%DetDB $= %sb) || (%DetDB $= %zb))
			{
				%brick.isBotHole=1;
				%brick.hBotType = %DetDB.holeBot;
				%brick.spawnHoleBot();
			}
		}
	}
	%r = getWord($DRot,3)+90;
	if(%r>270)
		%r = 0;
	$DRot = "0 0 1 " @ %r;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Water()
{
	%Flr = $TerHO + $RHfsM;
	%WatLM = $TerHO + $WatL;
	%WFDf = %WatLM-%Flr;
	%CxM = ((mFloor($Cx/16))*16)+7;

	if(%CxM>$Chs)
		%Cont=0;

	%CyM = ((mFloor($Cy/16))*16)+7;

	if(%CyM>$Chs)
		%Cont=0;

	%ChPxM = $ChPx+%CxM;
	%ChPyM = $ChPy+%CyM;
	
	for(%WC=0;%WC<=(%WFDf);%WC=%WC+4)
	{
		%WArrL = %ChPxM @ " " @ %ChPyM @ " " @ (%WatLM-%WC-2);

		if(!($WArray[%WArrL] $= WPres))	
		{
			%brick = new fxDTSbrick()
			{
				datablock = $WtB;
				position = %ChPxM @ " " @ %ChPyM @ " " @ (%WatLM-%WC-2);
				angleID = 0;
				colorID = $WatC;
				colorFXID = 0;
				isPlanted = 1;
				client = $cl;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				shapefxID = 0;
				stackBL_ID = $cl.bl_id;
				printID = $WatP;
				PTG = 1;
			};	
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
			%brick.setShapeFX(2);
			%brick.createWaterZone();

			if(%WC>2)
				%brick.setRendering(0);
		}
		$WArray[%WArrL] = WPres;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Clouds()
{
	%RHfsM = ((mFloor($RHfs/2))*2)-1;

	if($RHfsM<$CloL && $CloH>$TerHO)
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($CloH-1);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext())
		{
			%brick = new fxDTSbrick()
			{
				datablock = $FxCB;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($CloH+1);
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColClouds;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriClouds;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
			%brick.setColliding(0);
		}
		for(%Cz=-1;%Cz<=5;%Cz=%Cz+2)
		{
			%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($CloH+($CloL-%RHfsM)+%Cz)-6;
			%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
			initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

			if(!%brick=containerSearchNext())
			{
				if((($CloH+($CloL-%RHfsM)+%Cz)-6)>($CloH+1))
				{
					%brick = new fxDTSbrick()
					{
						datablock = $FxCB;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($CloH+($CloL-%RHfsM)+%Cz)-6;
						rotation = "0 0 0 0";
						scale = "1 1 1";
						colorID = $ColClouds;
						colorFXID = 0;
						shapefxID = 0;
						printID = $PriClouds;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();
					%brick.setColliding(0);
				}
			}
		}
	}	
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_Boundaries()
{
	for(%BCx=$GSx-5;%BCx<=$GEx+8;%BCx=%BCx+8)
	{
		for(%BCz=4;%BCz<=$BndsH;%BCz=%BCz+8)
		{
			%brick = new fxDTSbrick()
			{
				datablock = $STxCB;
				position = %BCx @ " " @ ($GSy-5) @ " " @ %BCz;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColBounds;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriBounds;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();	

			%brick = new fxDTSbrick()
			{
				datablock = $STxCB;
				position = %BCx @ " " @ ($GEy+3) @ " " @ %BCz;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColBounds;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriBounds;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
	for(%BCy=$GSy+3;%BCy<=$GEy+8;%BCy=%BCy+8)
	{
		for(%BCz=4;%BCz<=$BndsH;%BCz=%BCz+8)
		{
			%brick = new fxDTSbrick()
			{
				datablock = $STxCB;
				position = ($GSx-5) @ " " @ %BCy @ " " @ %BCz;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColBounds;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriBounds;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			%brick = new fxDTSbrick()
			{
				datablock = $STxCB;
				position = ($GEx+3) @ " " @ %BCy @ " " @ %BCz;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColBounds;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriBounds;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_GapFill()
{
	for(%Cz=0.1;%Cz<2.0;%Cz=%Cz+0.1)
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %Cz;
		%size = 1.5 @ " " @ 1.5 @ " " @ 0.1875;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext())
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4x4FData;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ %Cz;
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColStone;
				colorFXID = 0;
				shapefxID = 0;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_PTGPreview()
{
	$RHfsM = ((mFloor($RHfs/$TerHS))*$TerHS)-1;
	$clr="NA";

	if($Norm==1)
	{
		if($Holes==1 && $RHfsM<=0)
			$RHfsM = -1;
		if($Holes==0 && $RHfsM<=0)
			$RHfsM = 1;
		if($RHfsM>1)
			$clr=$ColDirt;

		CreateChunk_PTGBiomesPreview();
	}
	if($Plai==1)
	{
		$RHfsM = $TerHO;

		if($RHfsM>1)
			$clr=$ColDirt;

		CreateChunk_PTGBiomesPreview();
	}
	if($FloI==1)
	{
		if($Holes==1 && ($RHfsM-$FISH)<=0)
			$RHfsM = -1;
		if($Holes==0 && ($RHfsM-$FISH)<=0)
			$RHfsM = 1;
		if($RHfsM>$FISH && ($TerHO+$RHfsM)>1)
		{
			$clr=$ColDirt;
			CreateChunk_PTGBiomesPreview();
		}
	}
	if($clr !$= "NA")
	{
		%col = getColorIDtable($clr);
		%colf=mFloor(getWord(%col,0)*255) @ " " @ mFloor(getWord(%col,1)*255) @ " " @ mFloor(getWord(%col,2)*255) @ " " @ mFloor(getWord(%col,3)*255);
	}
	else
		%colf="255 0 255 0";

	%sw=new GuiSwatchCtrl()
	{
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = ((($ChPx+$Cx)*2)-($GSx*2)) @ " " @ ((($GEy-$GSy)*2)-((($ChPy+$Cy)*2)-($GSy*2)))-4;
		extent = "4 4";
		minExtent = "4 4";
		visible = "1";
		color = %colf;
	};
	PrevList.add(%sw);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_PTGBiomesPreview()
{
	if($FloI==0)
	{
		if($RHfsM<=$SanL)
		{
			if($RHfsM>($WatL-2))
				$clr=$ColSand;
		
			if($WatL>0 && $RHfsM<=($WatL-2))
			{
				if($BioA==1)
					$clr=$ColBioWat;
				if(($BioC==1 && $RHfsBio>$BioSH) || ($BioC==1 && $NN==1))
					$clr=$ColBiocWat;
				if(($BioD==1 && $RHfsBiob>$BioSH) || ($BioD==1 && $NN==1))
					$clr=$ColBiodWat;
				if(($BioE==1 && $RHfsBio>$BioSH && $RHfsBiob>$BioSH) || ($BioE==1 && $NN==1))
					$clr=$ColBioeWat;
			}
		}
		if($RHfsM>$SanL)
		{
			if($BioA==1)
				$clr=$ColBio;
			if(($BioC==1 && $RHfsBio>$BioSH) || ($BioC==1 && $NN==1))
				$clr=$ColBioc;
			if(($BioD==1 && $RHfsBiob>$BioSH) || ($BioD==1 && $NN==1))
				$clr=$ColBiod;
			if(($BioE==1 && $RHfsBio>$BioSH && $RHfsBiob>$BioSH) || ($BioE==1 && $NN==1))
				$clr=$ColBioe;
		}
	}
	if($FloI==1)
	{
		if(($RHfsM)<=($SanL+$FISH) && ($RHfsM)>($WatL-2+$FISH))
			$clr=$ColSand;

		if(($RHfsM)>($SanL+$FISH))
		{
			if($BioA==1)
				$clr=$ColBio;
			if(($BioC==1 && $RHfsBio>$BioSH) || ($BioC==1 && $NN==1))
				$clr=$ColBioc;
			if(($BioD==1 && $RHfsBiob>$BioSH) || ($BioD==1 && $NN==1))
				$clr=$ColBiod;
			if(($BioE==1 && $RHfsBio>$BioSH && $RHfsBiob>$BioSH) || ($BioE==1 && $NN==1))
				$clr=$ColBioe;
		}
	}
}