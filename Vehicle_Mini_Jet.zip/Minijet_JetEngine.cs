datablock ParticleData(MiniJetEngineParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.9 0.5 0.1 0.9";
	colors[1]     = "0.1 0.1 0.9 0.0";
	sizes[0]      = 0.7;
	sizes[1]      = 0.01;

	useInvAlpha = false;
};
datablock ParticleEmitterData(MiniJetEngineEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MiniJetEngineParticle";
   
   //uiName = "Mini Jet Engine Emitter";
};

datablock ParticleData(MiniJetEngineSmokeParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = -0.1;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 3000;
	lifetimeVarianceMS   = 150;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 2.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.3 0.3 0.3 0.4";
	colors[1]     = "0.5 0.5 0.5 0.2";
	colors[2]     = "0.0 0.0 0.0 0.0";
	sizes[0]      = 0.75;
	sizes[1]      = 5.0;
	sizes[2]      = 6.0;
	times[0]		= 0;
	times[1]		= 0.3;
	times[2]		= 1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(MiniJetEngineSmokeEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 5;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "MiniJetEngineSmokeParticle";
   
   //uiName = "Mini Jet Engine Smoke Emitter";
};

datablock ShapeBaseImageData(JetEngineImage1)
{
   shapeFile = "./empty.dts";
	emap = false;

	mountPoint = 1;
   rotation = "1 0 0 180";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= MiniJetEngineEmitter;
	stateEmitterTime[1]				= 10000;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function JetEngineImage1::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

datablock ShapeBaseImageData(JetEngineImage2)
{
   shapeFile = "./empty.dts";
	emap = false;

	mountPoint = 2;
   rotation = "1 0 0 180";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= MiniJetEngineSmokeEmitter;
	stateEmitterTime[1]				= 10000;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function JetEngineImage2::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

function JetEngineCheck(%obj)
{
//	return;
	if(!isObject(%obj))
		return;

	%speed = vectorLen(%obj.getVelocity());
	if(%speed < %obj.dataBlock.minJetEngineSpeed)
	{
		if(%obj.getMountedImage(0) !$= "")
		{
			%obj.unMountImage(0);
			// %obj.unMountImage(3);
		}
	}
	else
	{
		if(%obj.getMountedImage(0) $= 0)
		{
			%obj.mountImage(JetEngineImage2,0);
			// %obj.mountImage(contrailImage2,3);
		}
	}
	
	if(%obj.getMountedObject(0))
	{
		if(%obj.getMountedImage(1) $= 0)
		{
			%obj.mountImage(JetEngineImage1,1);
		}
	}
	else
	{
		if(%obj.getMountedImage(1) !$= "")
		{
			%obj.unMountImage(1);
		}
	}

	schedule(2000,0,"JetEngineCheck",%obj);
}