if(isPackage(coreSurvival))
{
	deactivatepackage("coreSurvival");
}
package coreSurvival
{
	function gameConnection::autoAdminCheck(%client)
    {
        %p = parent::autoAdminCheck(%client);

        if(!$SurvivalMod::Data::ID[%client.bl_id])
		{
		    $SurvivalMod::Data::ID[%client.bl_id] = 1;
		}
		$BottomPrintShown = 1;
        return %p;
    }

    function serverCmdSuicide(%client)
	{
	messageClient(%client,'',"");
	}
	
	function servercmdhidebottomprint(%this)
	{
	 if(%this.isAdmin)
	 {
	  if($BottomPrintShown == 1)
	  {
	  $BottomPrintShown = 0;
	  messageClient(%this,'',"<color:FFFFFF>Bottom Print is now hidden.");
	  }
	  else
	  {
	  messageClient(%this,'',"<color:FF0000>Bottom Print is already hidden.");
	  }
	 }
	 else
	 {
	  messageClient(%this,'',"<color:FF0000>You aren't an admin!");
	 }
	}
	
    function servercmdunhidebottomprint(%this)
	{
	 if(%this.isAdmin)
	 {
	  if($BottomPrintShown == 0)
	  {
	  $BottomPrintShown = 1;
	  messageClient(%this,'',"<color:FFFFFF>Bottom Print is now shown.");
	  }
	  else
	  {
	  messageClient(%this,'',"<color:FF0000>Bottom Print is already shown.");
	  }
	 }
	 else
	 {
	  messageClient(%this,'',"<color:FF0000>You aren't an admin!");
	 }
	}
	
	function GameConnection::spawnPlayer(%this)
	{
		%p = parent::spawnPlayer(%this);
        
		%this.player.EnergyConsumedHunger = 0;
		%this.player.EnergyConsumedThirst = 0;		

		return %p;
	}
	
	function hellbanadminannounce(%msg) {
		for (%clientIndex = 0 ; %clientIndex < ClientGroup.getCount() ; %clientIndex++) {
			%client = ClientGroup.getObject(%clientIndex);
			if (%client.isadmin) {
				MessageClient(%client, '', "<color:FFFF00>" @ %msg);
			}
		}
	}

	function servercmdhellban(%client, %target) {
		%target = findclientbyname(%target);
		%target.ishellbanned = true;
		hellbanadminannounce(%target.name SPC "was hellbanned by" SPC %client.name);
	}

	function servercmdunhellban(%client, %target) {
		%target = findclientbyname(%target);
		%target.ishellbanned = false;
		hellbanadminannounce(%target.name SPC "was unhellbanned by" SPC %client.name);
	}

	function servercmdlisthellbanned(%client) {
		if (%client.isadmin) {
			MessageClient(%client, '', "<color:FFFFFF>List of hellbanned users:");
			for (%clientIndex = 0 ; %clientIndex < ClientGroup.getCount() ; %clientIndex++) {
				%cl = ClientGroup.getObject(%clientIndex);
				if (%cl.ishellbanned) {
					MessageClient(%client, '', "<color:FFFFFF>" @ %cl.name);
				}
			}
			MessageClient(%client, '', "<color:FFFFFF>End of list");
		}
	}

	function servercmdmessagesent(%client, %msg) {
		if (%client.ishellbanned) {
			MessageClient(%client, '', "<color:606060>" @ %client.clanprefix @ "<color:FFFF00>" @ %client.name @ "<color:606060>" @ %client.clansuffix @ "<color:FFFFFF>:" SPC stripmlcontrolchars(%msg));
		} else {
			Parent::servercmdmessagesent(%client, %msg);
		}
	}
	
	function GameConnection::onDeath(%client,%obj,%killer,%type,%area)
	{
	   parent::onDeath(%client,%obj,%killer,%type,%area);
	   
       %client.ishellbanned = true;
	   
	   return parent::onDeath(%client,%obj,%killer,%type,%area);
	   
	}
	
	function SurvivalModSaveTick()
	{
		export("$SurvivalMod*", "config/server/SurvivalModData.cs");
		schedule(1000,0,SurvivalModSaveTick);
	}
	
		function servercmdhelp(%this)
	{
    commandToClient(%this,'messageBoxOk',"                                                             [HELP] ","Say /rules to know about the rules.\n" @ "Say /temp to know about temperatures.\n\n" @ "Say /help to see this again.");
	}
	
			function servercmdtemp(%this)
	{
    commandToClient(%this,'messageBoxOk',"                                                      [TEMPERATURE] ","The Body Temperature is effected by heat and cold. To switch your type to Celsius/Fahrenheit say /temptype [C]elsius or [F]ahrenheit. Default is Celsius.");
	}
	
			function servercmdtemptype(%this, %i)
	{
      if(%i $= "celsius")
	  {
	    if($SurvivalMod::Data::ID[%this.bl_id,TempType] $= "Fahrenheit")
		{
	     $SurvivalMod::Data::ID[%this.bl_id,TempType] = "Celsius";
		 messageClient(%this,'',"<color:FFFF00>You have changed your temperature type to Celsius.");
	    }
		else
		{
		messageClient(%this,'',"<color:FF0000>Your already using the temperature type Celsius.");
		}
	  }
	  if(%i $= "fahrenheit")
	  {
	  	if($SurvivalMod::Data::ID[%this.bl_id,TempType] $= "Celsius")
		{
	     $SurvivalMod::Data::ID[%this.bl_id,TempType] = "Fahrenheit";
		 messageClient(%this,'',"<color:FFFF00>You have changed your temperature type to Fahrenheit.");
	    }
		else
		{
		messageClient(%this,'',"<color:FF0000>Your already using the temperature type Fahrenheit.");
		}
	  }
	  if(%i $= "c")
	  {
	    if($SurvivalMod::Data::ID[%this.bl_id,TempType] $= "Fahrenheit")
		{
	     $SurvivalMod::Data::ID[%this.bl_id,TempType] = "Celsius";
		 messageClient(%this,'',"<color:FFFF00>You have changed your temperature type to Celsius.");
	    }
		else
		{
		messageClient(%this,'',"<color:FF0000>Your already using the temperature type Celsius.");
		}
	  }
	  if(%i $= "f")
	  {
	  	if($SurvivalMod::Data::ID[%this.bl_id,TempType] $= "Celsius")
		{
	     $SurvivalMod::Data::ID[%this.bl_id,TempType] = "Fahrenheit";
		 messageClient(%this,'',"<color:FFFF00>You have changed your temperature type to Fahrenheit.");
	    }
		else
		{
		messageClient(%this,'',"<color:FF0000>Your already using the temperature type Fahrenheit.");
		}
	  }
	}
	
		function servercmdrules(%this)
	{
    commandToClient(%this,'messageBoxOk',"                                                             [RULES]","Nothing Yet.");
	}
};
ActivatePackage(coreSurvival);
SurvivalModSaveTick();
if(isFile("config/server/SurvivalModData.cs"))
{
	exec("config/server/SurvivalModData.cs");
}