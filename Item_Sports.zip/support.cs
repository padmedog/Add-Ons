//Support.cs functions used repeatedly in other functions, or things that don't fit anywhere else

// emitters used by the balls
// small trail
datablock ParticleData( smallBallTrailParticle )
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/dot";
	spinSpeed		   = 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.5 0.5 0.5 0.2";
	colors[1]     = "0.5 0.5 0.5 0.1";
	colors[2]     = "0.5 0.5 0.5 0.0";

	sizes[0]      = 0.4;
	sizes[1]      = 0.15;
	sizes[2]      = 0.0;

	times[0] = 0.0;
	times[1] = 0.5;
	times[2] = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData( smallBallTrailEmitter )
{
	ejectionPeriodMS = 15;
	periodVarianceMS = 1;
	ejectionVelocity = 0.25;
	velocityVariance = 0.0;
	ejectionOffset   = 0.0;
	thetaMin         = 0;
	thetaMax         = 90;
	phiReferenceVel  = 0;
	phiVariance      = 360;
	overrideAdvance = false;
	particles = "smallBallTrailParticle";

	uiName = "Ball Trail Small";
};

// normal trail
datablock ParticleData( ballTrailParticle )
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/dot";
	spinSpeed		   = 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.5 0.5 0.5 0.2";
	colors[1]     = "0.5 0.5 0.5 0.1";
	colors[2]     = "0.5 0.5 0.5 0.0";

	sizes[0]      = 0.7;
	sizes[1]      = 0.3;
	sizes[2]      = 0.0;

	times[0] = 0.0;
	times[1] = 0.5;
	times[2] = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData( ballTrailEmitter )
{
	ejectionPeriodMS = 15;
	periodVarianceMS = 1;
	ejectionVelocity = 0.25;
	velocityVariance = 0.0;
	ejectionOffset   = 0.0;
	thetaMin         = 0;
	thetaMax         = 90;
	phiReferenceVel  = 0;
	phiVariance      = 360;
	overrideAdvance = false;
	particles = "ballTrailParticle";

	uiName = "Ball Trail";
};

// general check for if two objects are in the same minigame
function sportIsInSameMinigame( %obj1, %obj2 )
{
	// get the minigame info from the objects and make sure it's not -1
	%minigame1 = getMiniGameFromObject( %obj1 );
	
	if( %minigame1 < 0 )
		%minigame1 = 0;
		
	%minigame2 = getMiniGameFromObject( %obj2 );
	
	if( %minigame2 < 0 )
		%minigame2 = 0;
	
	// check if we're in the same minigame
	if( %minigame1 == %minigame2 )
		return true;
	else
		return false;
}

// this needs to be the main function for picking up balls
function passBallCheck( %ball, %player, %isBrickItem )
{			
	//%player = player we're playerliding with, %ball = projectile
	//check if we can pass the ball to the other player, check trust list for passing outside of minigame
	// checking trust list is stupid
	if( %player.getType() & $TypeMasks::PlayerObjectType )
	{
		// check if they have an item equipped already, or if the player or ball is timing out
		if( isObject( %player.getMountedImage( 0 ) ) || getSimTime() < %player.sbTimeout || getSimTime() < %ball.pickupTimeout )
			return false;
			
		// check if we're a brick item
		if( %isBrickItem )
		{
			// do minigame check, might need message, also check if we can pick it up
			if( !%ball.canPickup )
				return false;

			if( miniGameCanUse( %player, %ball ) == 0 )
			{
				// if they're in a minigame don't give this message
				if( %player.client.minigame > 0 )
					%player.client.centerPrint( "This item is not part of the mini-game.", 1 );
				else
					%player.client.centerPrint( "This item is part of a mini-game.", 1 );
					
				return false;
			}
				
			// ok we are a brick item and we just got picked up so respawn
			%ball.respawn();
		}
		
		// much better check than we had before for checking if the player and ball are in the same minigame
		if( !sportIsInSameMinigame( %ball, %player ) )
			return false;
			
		// fuck this, this is pointless
		// this whole check is complicated and confusing, will redo this
		// if( %player.client.MiniGame == %ball.sourceObject.client.Minigame || %player.spawnBrick.client.MiniGame == %ball.sourceObject.client.Minigame || %ball.sourceObject == %player || isObject(%ball.spawnBrick) ) // || getTrustLevel(%player, %ball.sourceObject) >= $TrustLevel::Build) )
		// {
		
		// if we're a turbo player unturbo
		if( %player.getDataBlock().isTurboSportPlayer )
			delaySportPlayerCheck( %player );
			
		// add a timeout so the player doesn't immediately fire after getting a ball
		// only used by some alt fires
		%player.sbShootTimeout = getSimTime() + 300;
			
		// if projectile, check if horse
		if( %ball.getClassName() $= "Projectile" )
		{
			if( isObject( HorseArmor ) && %player.getDataBlock() == HorseArmor.getID() && isObject( "horse" @ %ball.getDataBlock().sportBallImage ) )
				%player.mountImage( "horse" @ %ball.getDataBlock().sportBallImage, 0 );
			else
				%player.mountImage( %ball.getDataBlock().sportBallImage, 0 );
		}
		else
		{
			if( isObject( HorseArmor ) && %player.getDataBlock() == HorseArmor.getID() && isObject( "horse" @ %ball.getDataBlock().image ) )
				%player.mountImage( "horse" @ %ball.getDataBlock().image, 0 );
			else
				%player.mountImage( %ball.getDataBlock().image, 0 );
		}
		
		// play catch/pickup sound
		serverPlay3D( weaponSwitchSound, vectorAdd( %player.getEyePoint(), "0 0 -1" ) );
		
		// remember the last time we picked up a ball
		%player.lastBallPickupTime = getSimTime();
		
		// check if we should delete the item
		if( %isBrickItem && %ball.isStatic() )
			return true;
		else
			%ball.delete();//%ball.schedule( 0, delete );	// this is done to prevent leaks, so the object is deleted after the function is over.
			
		return true;
		// }
	}
	return false;
}

//Random float function
function sGetRandomFloat(%min, %max, %neg)
{
	%a = getRandom(%min, %max);
	
	if(%a == 10) %a = 1;
	else %a = "0." @ %a;

	if(getRandom(0,1) && %neg) %a = "-" @ %a;

	return %a;
}

// general dropball function
function Player::dropBall( %obj )
{
	// check if we exist
	if( !isObject( %obj ) )
		return;
	
	// get the datablock from the image
	%image = %obj.getMountedImage( 0 );
	if( isObject( %image ) && %image.isSportBall )
		%dataBlock = %image.projectile;
	else
		return;

	// get a random vector, should probably just make a getRandomVector function
	//%rVec = sGetRandomFloat( 0, 10, 1 ) SPC sGetRandomFloat( 0, 10, 1 ) SPC sGetRandomFloat( 0, 10, 1 );
	
	// scale it up
	//%fVel = vectorAdd( vectorScale( %rVec, getRandom( 4, 4 ) ), "0 0 4" );
	
	// let's try a simpler method
	%fVec = %obj.getForwardVector();
	%sVec = vectorScale( %fVec, 2 );
	%vec = vectorAdd( %sVec, "0 0 4" );
	
	// er, I don't seem to use this why is this here?
	// get the player velocity, make sure z velocity isn't too high divide that by 2
	%playerVel = getWords( %obj.getVelocity(), 0, 1 ) SPC getWord( %obj.getVelocity(), 2 )/2;

	// add in player velocity
	%fVel = vectorAdd( %playerVel, %vec );
	
	// if football we need to spawn from a different place slightly
	if( %image.projectile $= "footballProjectile" )
		%initialPos = vectorAdd( %fVec, %obj.getMuzzlePoint( 0 ) );
	else
		%initialPos = %obj.getMuzzlePoint( 0 );
	
	// create the projectile
	// this is done outside of the spawnball function due to some slight variations that need to happen
	// to prevent the football from spawning in us
	%p = new Projectile()
	{
		dataBlock       = %dataBlock;
		initialPosition = %initialPos;
		initialVelocity = %fVel;
		sourceObject    = %obj;
		client          = %obj.client;
		sourceSlot      = 0;
		originPoint     = %obj.getMuzzlePoint( 0 );
		scale			= %obj.getScale();
		minigame = getMiniGameFromObject( %obj );//%obj.client.minigame;
	};
	MissionCleanup.add(%p);
	
	%obj.sbTimeout = getSimTime()+500;
	
	%obj.unmountImage( 0 );
}

// general ball spawning function
function Player::spawnBall( %obj, %dataBlock, %vel, %noSound )
{
	%pos = %obj.getMuzzlePoint( 0 );
	
	// sound
	if( !%noSound )
		serverPlay3D( weaponSwitchSound, vectorAdd( %obj.getEyePoint(), "0 0 -0.5" ) );
	
	// apply timeout until we can pick up another ball
	%obj.sbTimeout = getSimTime() + 300;
	
	%scale = %obj.getScale();
	%vel = vectorScale( %vel, getWord( %scale, 0 ) );
	
	%p = new Projectile()
	{
		dataBlock       = %dataBlock;
		initialPosition = %pos;
		initialVelocity = %vel;
		sourceObject    = %obj;
		client          = %obj.client;
		sourceSlot      = 0;
		originPoint     = %pos;
		scale = %scale;
		sourceObjectVel = %obj.getVelocity();
		minigame = getMiniGameFromObject( %obj );//%obj.client.minigame;
	};
	
	%p.ballCreationTime = getSimTime();
	
	MissionCleanup.add( %p );
	
	// check if we came from a bot
	// if( isObject( %obj.spawnBrick ) )
		// %p.minigame = %obj.spawnBrick.getGroup().client.minigame;
	
	return %p;
}

function spawnBall( %pos, %dataBlock, %vel, %source, %noSound )
{
	if( !%noSound )
		serverPlay3D( weaponSwitchSound, %pos );
	
	// if I do this scale then things screw up with the soccer ball, so for now this won't scale
	// if( isObject( %source ) )
		// %scale = %obj.getScale();
	// else
		// %scale = "1 1 1";
		
	// %vel = vectorScale( %vel, getWord( %scale, 0 ) );
	
	%p = new Projectile()
	{
		dataBlock       = %dataBlock;
		initialPosition = %pos;
		initialVelocity = %vel;
		sourceObject    = %source;
		client          = %source.client;
		sourceSlot      = 0;
		originPoint     = %pos;
		minigame		= getMiniGameFromObject( %source );//%source.client.minigame;
		// scale = %scale;
	};
	
	MissionCleanup.add( %p );
	
	// check if we came from a bot
	// if( isObject( %source.spawnBrick ) )
		// %p.minigame = %source.spawnBrick.getGroup().client.minigame;
	
	return %p;
}

// general ball sound effect function
function Projectile::playSportBallSound( %obj, %sound )
{
	%speed = vectorLen( %obj.getVelocity() );
	
	if( !isObject( %sound ) )
		%sound = basketballBounceSound;
	
	//Play bounce sound and check that we haven't played it too recently
	if( %obj.lastBounceTime < getSimTime() && %speed > 3 )
	{
		serverPlay3D( %sound, %obj.getPosition() );
		%obj.lastBounceTime = getSimTime()+50;
	}
}

//Convert vector to radian
function hGetAnglesFromVector( %vec )
{
	%yawAng = mAtan( getWord(%vec,0), getWord(%vec,1) );

	if( %yawAng < 0.0 )
	{
		%yawAng += $pi*2;
	}
	
	return %yawAng;
}

//A general drop function for when you have a ball, used in onDisabled call
// function dropSportBall(%obj)
// {
	// %ball = %obj.getMountedImage(0).projectile;

	// %rVec = sGetRandomFloat(0,10,1) SPC sGetRandomFloat(0,10,1) SPC sGetRandomFloat(5,10,0);
	// %pVel = %obj.getVelocity();

	// %fVel = vectorAdd(vectorScale(%rVec,getRandom(2,4)), pVel);

	// %p = new Projectile()
	// {
		// dataBlock       = %ball;
		// initialPosition = %obj.getMuzzlePoint(0);
		// initialVelocity = %fVel;
		// sourceObject    = %obj;
		// client          = %obj.client;
		// sourceSlot      = 0;
		// originPoint     = %obj.getMuzzlePoint(0);
	// };
	// MissionCleanup.add(%p);

	// %obj.unMountImage(0);
	// //%col.setDataBlock(%col.basketballOriginalDataBlock);
	// %obj.playThread(2,root);
	// %obj.playThread(1,root);

	// // %p.sbShootTimeout = getSimTime()+2000;
// }

function ItemData::onBallCollision( %this, %obj, %col )
{
	// echo( "onBallCollision Empty Callback" );
}
function ShapeBaseImageData::onBallTrigger(%this, %obj, %trigger, %val)
{
	// lool nothing
	// parent::onBallTrigger(%this, %obj, %trigger, %val);
}

function pickupSportBalls( %obj )
{
	%type = $TypeMasks::ItemObjectType;
	%pos = %obj.getEyePoint();
	%vec = vectorScale( %obj.getEyeVector(), 5 );
	%end = vectorAdd( %pos, %vec );

	%target = containerRayCast(%pos, %end, %type, %obj);
	
	// not sure if this check works 100%, should do this a better way or recheck it
	if( ( %col = getWord(%target,0) ) )
	{
		// slightly confusing, but a item spawned via the wrench will not have the isSportball on it, it'll only have it on the datablock
		if( %col.getDataBlock().isSportBall && !%col.isSportBall )
		{
			passBallCheck( %col, %obj, 1 );
			
			// kind of confusing but this flag means that we are clickign and not using the e key
			if( %obj.sbIsTriggeringPickup )
			{
				// set a flag so we know not to immediately fire after we're don picking it up
				%obj.sbPickupTrigger = 1;
			}
		}
	}
}

//sport ball package
package sportBallsPackage
{
	// activate stuff, packaged for clicking/picking up items
	function Player::activateStuff( %obj )
	{
		// call the pickup function
		pickupSportBalls( %obj );
		stealBasketball( %obj );
		
		parent::activateStuff( %obj );
	}
	
	//Trigger packages for alt fires of the balls
	function armor::onTrigger(%this, %obj, %trigger, %val)
	{
		//if(%trigger == 4 && %val == 1 && !%obj.isCrouched())
		//	%obj.setEnergyLevel(0);
		
		// check if we're triggering then we can know if activate stuff what to do
		if( %trigger == 0 && %val == 1 )
			%obj.sbIsTriggeringPickup = 1;
		
		// reset the pickup trigger from onActivate if we have clicked again fast
		if( %obj.sbPickupTrigger && %trigger == 0 && %val == 1 )
			%obj.sbPickupTrigger = 0;
			
		parent::onTrigger(%this, %obj, %trigger, %val);
		
		// now that we've already activated stuff let's clear this
		if( %trigger == 0 && %val == 1 )
			%obj.sbIsTriggeringPickup = 0;
		
		// check if we got out of a car recently and return if so
		if( isObject( %obj.getObjectMount() ) || %obj.lastMountTime+500 > getSimTime() )
			return;
		
		// if we just came out of turboMode then don't alt fire
		if( %obj.hesOnFire && !%obj.getDataBlock().isTurboSportPlayer )
		{
			%obj.hesOnFire = 0;
			return;
		}
		
		// should we do a get control object check here?
		%image = %obj.getMountedImage(0);
		if( isObject( %image ) && %image.isSportBall )
		{
			// %name = %image.getName();
			%image.onBallTrigger( %obj, %trigger, %val );
		}
		// if(%trigger == 0 && %val == 1)
		// {
			// stealBasketball(%obj);
			// pickupSportBalls( %obj );
			//catchDodgeball(%obj);
			//dodgeballCatchTestFoo(%obj);
		// }
	}
	
	function fxDTSBrick::onPlayerTouch(%obj, %col)
	{
		//Call onTouchdown event, not sure if this should be called before or after onPlayerTouch
		%obj.onTouchdown(%col);

		parent::onPlayerTouch(%obj, %col);
	}

	// Collision overwrites so you can pickup balls correctly
	// this is kind of backwards, should I instead overwrite projectile::onCollision?
	// nevermind apparently this is done so i can correctly pick up ball items as well as projectiles
	function armor::onCollision(%this,%obj,%col,%a,%b,%c,%d)
	{
		// this whole block is kind of confusing, but basically we're checking if it's a ball
		// if so what type of ball, projectile or item, or spawned item
		if( !isObject( %obj.getMountedImage( 0 ) ) && ( %col.getType() & $TypeMasks::ItemObjectType ) )
		{
			// if we're a sportball that means we're a spawned item, otherwise that means we're a normal item from a brick
			if(%col.isSportBall)
			{
				// specific check for if the football was fumbled and then turned into an item, should implement this better
				%isFumbled = %col.isFumbled;
				
				if( passBallCheck( %col, %obj ) && %isFumbled )
					%obj.emote(winStarProjectile);
				
				return;
			}
			else if(%col.getDataBlock().isSportBall)
			{
				passBallCheck( %col, %obj, 1 );
				return;
			}
		}
		else if( %col.getDataBlock().isSportBall )
			return;
		
		// detect if we're colliding with another player then forward it to that datablock
		if( !isObject( %obj.getMountedImage( 0 ) ) && sportIsInSameMinigame( %obj, %col ) && ( %col.getType() & $TypeMasks::PlayerObjectType ) && %col.hasSportBall)
		{
			// what ball do we got?
			%dataBlock = %col.getMountedImage( 0 ).item;
			
			// forward it to the item datablock function
			%dataBlock.onBallCollision( %col, %obj );
		}

		parent::onCollision(%this,%obj,%col,%a,%b,%c,%d);
	}

	//parent onDisabled so we can get the ball off the dead guy
	function armor::onDisabled(%this, %obj, %a)
	{
		// if(%obj.hasSportBall)
		// {
		if( isObject( %obj ) )
			%obj.dropBall();
		// }
		parent::onDisabled(%this, %obj, %a);
	}

	//Overwrite this so instead of the default item, they just mount the sportball directly if it's in the first slot
	function serverCmdSetMiniGameData(%client, %info, %test)
	{
      Parent::serverCmdSetMiniGameData(%client, %info, %test);

      %fieldCount = getFieldCount(%info);
      for(%i = 0; %i < %fieldCount; %i++)
      {
         %field = getField(%info, %i);
         %type = getWord(%field, 0);
         
         //if first slot is ball, use that as starting ball
         //also clear out all balls from starting equipment because you can spam drop them

         if(%type !$= "SE") 
            continue;
         
         %idx = mFloor(getWord(%field, 1));
         %db = mFloor(getWord(%field, 2));

         if(%db.isSportBall)
         {
            %client.miniGame.startEquip[%idx] = 0;
            if(%idx == 0)
               %client.miniGame.StartBall = %db.image.getID();            
         }
         else if(%idx == 0)
         {
            %client.miniGame.StartBall = 0;
         }                  
         
         %client.miniGame.forceEquip(%idx);
      }

      schedule(50,%client.minigame, updatePlayerBalls, %client.miniGame);
	}

	function armor::onAdd(%this, %obj)
	{
		parent::onAdd(%this, %obj);
		
		if( isObject(%obj.client.miniGame.StartBall) )
			%obj.mountImage( %obj.client.miniGame.StartBall, 0 );
	}
	
	// packaged for when you change an item to a sportball mid minigame, you can unEquip the "empty" item without losing the ball
	function serverCmdUnUseTool(%client)
	{
		if( isObject( %client.player ) && %client.player.getMountedImage( 0 ).isSportBall )
			return;

		parent::serverCmdUnUseTool(%client);
	}
	
	// when equiping a tool you want to drop your balls
	// might be a weird case where you don't have a tool yet you drop the ball, need to keep an eye out
	function serverCmdUseTool( %client, %slot )
	{
		// if we have a ball and we use an item drop ball
		if( isObject( %client.player ) )
			%client.player.dropBall();

		parent::serverCmdUseTool( %client, %slot );
	}
	
	// package inventory for same reason as above
	function serverCmdUseInventory( %client, %slot )
	{
		if( isObject( %client.player ) )
			%client.player.dropBall();
		
		parent::serverCmdUseInventory( %client, %slot );
	}
	
	// instant use brick
	function serverCmdInstantUseBrick( %client, %brick )
	{
		if( isObject( %client.player ) )
			%client.player.dropBall();
		
		parent::serverCmdInstantUseBrick( %client, %brick );
	}
	
	// package spraycan for the same reason
	function serverCmdUseSprayCan( %client, %id )
	{
		if( isObject( %client.player ) )
			%client.player.dropBall();
		
		parent::serverCmdUseSprayCan( %client, %id );
	}
	
	// client leaves game
	function GameConnection::onDrop( %client, %dunno )
	{
		if( isObject( %client.player ) )
			%client.player.dropBall();
		
		parent::onDrop( %client, %dunno );
	}
	
	// should of just parented this from the get go
	function armor::onRemove( %this, %obj )
	{
		if( isObject( %obj ) )
			%obj.dropBall();
		
		parent::onRemove( %this, %obj );
	}
};
activatePackage(sportBallsPackage);

function updatePlayerBalls(%miniGame)
{
	if(!isObject(%miniGame.StartBall))
		return;

	%count = %miniGame.numMembers;

	for(%a = 0; %a < %count; %a++)
	{
		%client = %miniGame.member[%a];
		if(isObject(%client.player) && !%client.player.isDisabled && !isObject(%client.player.getMountedImage(0)))
			%client.player.mountImage(%miniGame.StartBall,0);
	}
}

//Specialized event, will be removed when i make custom bricks for these items
// function Player::giveBall(%obj)
// {	
	// %obj.mountImage(basketballImage,0);
// }
// registerOutputEvent(Player,"GiveBall","");

//onTouchdown event, called when player touches brick and has a ball
function fxDTSBrick::onTouchdown(%obj, %player)
{
	if(!%player.hasSportBall)
		return;

	$InputTarget_["Self"]   = %obj;
	$InputTarget_["Player"] = %player;
	$InputTarget_["Client"] = %player.client;
	$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);

	%obj.processInputEvent("onTouchdown", %player.client);
}
registerInputEvent("fxDTSBrick", "onTouchdown", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");

function fxDTSBrick::onBallHit( %obj, %player, %projectile )
{
	$InputTarget_["Self"]   = %obj;
	$InputTarget_["Player"] = %player;
	$InputTarget_["Client"] = %player.client;
	$InputTarget_["Ball"]	= %projectile;
	$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);

	%obj.processInputEvent("onBallHit", %player.client);
}
registerInputEvent("fxDTSBrick", "onBallHit", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Ball Projectile" TAB "MiniGame MiniGame");
//Sport player datablock, can jet while jumping and crouching, "tackling" so to speak
datablock PlayerData(PlayerSportArmor : PlayerStandardArmor)
{
	isSportPlayer = 1;
	runForce = 50 * 90;
	runEnergyDrain = 0;
	minRunEnergy = 0;
	maxForwardSpeed = 8;
	maxBackwardSpeed = 5;
	maxSideSpeed = 5;

	maxForwardCrouchSpeed = 3;
	maxBackwardCrouchSpeed = 2;
	maxSideCrouchSpeed = 2;

	jumpForce = 9 * 90; //8.3 * 90;
	jumpEnergyDrain = 0;
	minJumpEnergy = 0;
	jumpDelay = 0;

	runSurfaceAngle  = 55;
	jumpSurfaceAngle = 55;

	minJetEnergy = 10;
	jetEnergyDrain = 10;
	canJet = 0;

	rechargeRate = 0.5;

	uiName = "Sport Player";
	showEnergyBar = true;
};

function PlayerSportArmor::onTrigger(%this, %obj, %trigger, %val)
{
	if(%trigger == 4 && %val == 1 && !%obj.hasSportBall)
	{
		%obj.hesOnFire = 1;
		delaySportPlayerCheck(%obj, 1);
	}

	parent::onTrigger(%this, %obj, %trigger, %val);
}

// shoe fire effect
datablock ShapeBaseImageData( HesOnFireLImage )
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 4;//$HeadSlot;

	offset = "0 -0.3 0.1";
	rotation = "1 0 0 180";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Ready";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 35;
	stateEmitter[1]					= PlayerJetEmitter;
	stateEmitterTime[1]				= 35;

	// stateName[2]					= "Done";
	// stateScript[2]					= "onDone";
};

datablock ShapeBaseImageData( HesOnFireRImage )
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 3;//$HeadSlot;

	offset = "0 -0.3 0.1";
	rotation = "1 0 0 180";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Ready";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 35;
	stateEmitter[1]					= PlayerJetEmitter;
	stateEmitterTime[1]				= 35;

	// stateName[2]					= "Done";
	// stateScript[2]					= "onDone";
};

datablock PlayerData(PlayerSportTurboArmor : PlayerStandardArmor)
{
	isTurboSportPlayer = 1;
	runForce = 100 * 90;
	runEnergyDrain = 0;
	minRunEnergy = 0;
	maxForwardSpeed = 12;
	maxBackwardSpeed = 8;
	maxSideSpeed = 12;

	maxForwardCrouchSpeed = 7;
	maxBackwardCrouchSpeed = 6;
	maxSideCrouchSpeed = 6;

	jumpForce = 12 * 90; //8.3 * 90;
	jumpEnergyDrain = 0;
	minJumpEnergy = 0;
	jumpDelay = 0;

	runSurfaceAngle  = 55;
	jumpSurfaceAngle = 55;

	minJetEnergy = 10;
	jetEnergyDrain = 8;
	canJet = 0;

	rechargeRate = -1.0;

	uiName = "";
	showEnergyBar = true;
};
function PlayerSportTurboArmor::onTrigger(%this, %obj, %trigger, %val)
{
	if(%trigger == 4 && %val == 0)
	{
		delaySportPlayerCheck(%obj);
		%obj.hesOnFire = 0;
	}
	parent::onTrigger(%this, %obj, %trigger, %val);
}

//
function delaySportPlayerCheck( %obj, %type )
{
	// make sure we're not dead
	if(%obj.isDisabled())
		return;

	// cancel the last sport schedule if there was one
	cancel(%obj.sportPlayerSched);
	
	%dataBlock = %obj.getDataBlock();
	
	if( %type != 1 && %dataBlock != PlayerSportTurboArmor.getID() )
	{
		// he's not on fire :(
		%obj.unMountImage( 2 );
		%obj.unMountImage( 3 );
		
		return;
	}
	
	if(%type == 1)
	{
		%obj.setDataBlock("PlayerSportTurboArmor");
		
		// color the shoes & peglegs nba jam style
		// should maybe add some effect?
		%obj.setNodeColor("lshoe", "1 0 0 1");
		%obj.setNodeColor("rshoe", "1 0 0 1");
		
		%obj.setNodeColor("lpeg", "1 0 0 1");
		%obj.setNodeColor("rpeg", "1 0 0 1");
		
		// he's on fire!
		%obj.mountImage( HesOnFireLImage, 2 );
		%obj.mountImage( HesOnFireRImage, 3 );
		
		%obj.sportPlayerSched = schedule(%obj.getEnergyLevel()*32.5, %obj, delaySportPlayerCheck,%obj);
	}
	else
	{
		// set the player back to normal
		%obj.setDataBlock("PlayerSportArmor");
		%obj.client.applyBodyColors();
		
		// he's not on fire :(
		%obj.unMountImage( 2 );
		%obj.unMountImage( 3 );
	}
}