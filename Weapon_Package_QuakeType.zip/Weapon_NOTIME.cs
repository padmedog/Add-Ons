//gun.cs

datablock AudioProfile(noTimeFireSound)
{
   filename    = "./bigLaser.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(noTimeFlashParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 35;
	textureName          = "./blastCorona1";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
    colors[0]     = "1 1 1 1";
    colors[1]     = "0.8 0.8 1 0.3";
    colors[2]     = "0.75 0.75 1 0.2";
    colors[3]     = "0.5 0.5 0.75 0.0";

    sizes[0]      = 18.15;
   sizes[1]      = 19.25;
    sizes[2]      = 18.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;


	useInvAlpha = false;
};
datablock ParticleEmitterData(noTimeFlashEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "noTimeFlashParticle";

   useEmitterColors = false;
};

AddDamageType("noTime",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_ibbs> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_ibbs> %1',0.2,1);

function drawRaylinenoTime(%pos1, %pos2)
{
	//should be the dimensions of the model in torque units
	%modelwidth = 0.01 +getRandom(1,10)*0.001;
	%modeldepth = 0.01 +getRandom(1,10)*0.001;
	%modelheight = 1.45 +getRandom(1,10)*0.0001;
	
	if(isObject($lastShape))
		$lastShape.delete();

	//find the point halfway between the two points, this will be our position
	%point = vectorAdd(vectorScale(vectorSub(%pos2, %pos1), 0.5), %pos1);
	
	//rotation
	%xRot = 0;
	
	//mAtan(z/len(x and y))
	%yRot = 90 - mRadToDeg(mAtan(getWord(%pos2, 2) - getWord(%pos1, 2), vectorLen(vectorSub(getWords(%pos2, 0, 1), getWords(%pos1, 0, 1)))));
	//%yRot = 90;
	
	//mAtan(x/y)
	%zRot = mRadToDeg(mAtan(getWord(%pos2, 1) - getWord(%pos1, 1), getWord(%pos2, 0) - getWord(%pos1, 0)));
	
	%rot = eulerToAxis(%xRot SPC %yRot SPC %zRot);
	
	//scaling
	%width = 0.3 / %modelWidth;
	%depth = 0.3 / %modeldepth;
	%height = vectorLen(vectorSub(%pos2, %pos1)) / %modelheight;
	
	
	//create it
	%shape = new TSStatic() {
		shapeName = "add-ons/weapon_package_quaketype/raycastline_electricity.dts";
	};
	
	%shape.setTransform(%point SPC %rot);
	%shape.setScale(%width SPC %depth SPC %height);

	$lastShape = %shape;
	
	return %shape;
}

//////////
// item //
//////////
datablock ItemData(noTimeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./fly_gun.2.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "INFINITY BIG BANG STORM";
	iconName = "./ibbs";
	doColorShift = true;
	colorShiftColor = "0.6 0.6 0.6 1.000";

	 // Dynamic properties defined by the scripts
	image = noTimeImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(noTimeImage)
{
   // Basic Item properties
	shapeFile = "./fly_gun.2.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = noTimeItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 300; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = gravityRocketProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 10000000; //10
   raycastDirectDamageType = $DamageType::noTime;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSequence[0]	= "Fire";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Prefire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnTimeout[1]     = "Ready";
	stateWaitForTimeout[1]			= false;
	stateTimeoutValue[1]            = 0.9;
	stateSequence[1]	= "idle";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.02;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= staticBeamFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= noTimeFireSound;

	stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.02;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerDown[4]     = "Fire";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Prefire";
	stateSequence[5]	= "fire";
	stateTimeoutValue[5]            = 0.18;
	stateScript[5]                  = "onBoltback";
	stateTransitionOnTimeout[5]     = "Fire";
	stateTransitionOnTriggerUp[5]     = "Ready";
	stateSound[5]					= staticBeamChargeSound;
};

function noTimeImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, shiftleft);	
	%obj.playThread(0, plant);	
}

function noTimeImage::onFire(%this,%obj,%slot)
{
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	if(%obj.getDamagePercent() >= 1.0)
		return;	
	%obj.playThread(0, plant);	
	
	Parent::onFire(%this,%obj,%slot);
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-7")));
	%obj.spawnExplosion(QuakeHugeRecoilProjectile,"1 1 1");

	////////////////////////////////////////////////////
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylinenoTime(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylinenoTime(%start, %end);
	}
	%line.schedule(90, delete);
}
