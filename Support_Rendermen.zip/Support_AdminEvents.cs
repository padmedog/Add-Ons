//Support_AdminEvents.cs
//Adam487 (Forum: Headcrab Zombie)
//This file is freely available for use by others. I only ask that you leave this comment header unchanged.


//Allows for events that are only placeable by admins
//Once placed by an admin, anyone can activate them
//If desired, event developers must add an if admin check inside individual events functions to prevent this


//To use, call registerAdminOnlyOutputEvent after calling registerOutputEvent
//registerAdminOnlyOutputEvent(%class,%name,%adminLevel);
//%class - the class of your event's target. FxDtsBrick, Player, GameConnection, etc
//%name - the name of your output event
//%adminLevel - admin level required to place the event. 1 for admin, 2 for superadmin, 3 for host


package AdminEvents
{
	function serverCmdAddEvent(%client, %delay, %input, %target, %a, %b, %output, %par1, %par2, %par3, %par4)
	{
		//Define aLevel based on whether the client is host, super admin, admin, or none
		if(%client.bl_id == getNumKeyID())
			%aLevel = 3;
		else if(%client.isSuperAdmin)
			%aLevel = 2;
		else if(%client.isAdmin)
			%aLevel = 1;
		else
			%aLevel = 0;

		//Get more information about what event the client chose
		%class = getWord(getField($InputEvent_TargetListfxDTSBrick_[%input],%a),1);
		eval("%name = $OutputEvent_Name" @ %class @ "_" @ %output @ ";");
		%reqLevel = $AdminOutputEvent[%class,%name];
		
		//Does the client have sufficient priviledges to use this event?
		if(%reqLevel > %aLevel)
			messageClient(%client,'','You do not have a sufficient admin level to use the event %1::%2. It has been removed from your brick.',%class,%name);
		else
			Parent::serverCmdAddEvent(%client, %delay, %input, %target, %a, %b, %output, %par1, %par2, %par3, %par4);
	}
	
	//Fix a duplicator exploit that allows non-admins to duplicate bricks with admin only events on them
	function fxDtsBrick::onPlant(%this)
	{
		%r = Parent::onPlant(%this);
		%this.schedule(50,checkForAdminEvents);
		return %r;
	}
};
ActivatePackage(AdminEvents);

function registerAdminOnlyOutputEvent(%class,%name,%adminLevel)
{
	//Add the event to the list of admin-only events
	%id = outputEvent_GetOutputEventIdx(%class,%name);
	if(%id == -1) //This could be caused by typos in the event class or event name, or calling before registering the event
		error("registerAdminOnlyOutputEvent - Output event " @ %class @ "::" @ %name @ " not found!");
	else
		$AdminOutputEvent[%class,%name] = %adminLevel;
}

//Function used to check for admin-only events after duplicating
function fxDtsBrick::checkForAdminEvents(%this)
{
	%client = %this.getGroup().client;
	if(%client.bl_id == getNumKeyID())
		%aLevel = 3;
	else if(%client.isSuperAdmin)
		%aLevel = 2;
	else if(%client.isAdmin)
		%aLevel = 1;
	else
		%aLevel = 0;
	for(%i=0;%i<%this.numEvents;%i++)
	{
		%event = InputEvent_GetInputEventIdx(%this.eventInput0);
		%class = getWord(getField($InputEvent_TargetListFxDtsBrick_[%event],%this.eventTargetIdx),1);
		%name = %this.eventOutput[%i];
		echo(%class SPC %name);
		%reqLevel = $AdminOutputEvent[%class,%name];
		
		if(%reqLevel > %aLevel)
			%this.eventEnabled[%i] = 0; //Just disabling the event is plenty. It will be deleted when the client resends it after wrenching it
	}
}