//sword.cs
datablock AudioProfile(ChainswordHitSound)
{
   filename    = "./ChainswordHit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(ChainswordSwingSound)
{
   filename    = "./ChainswordSwing.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ChainswordIdleSound)
{
   filename    = "./chainswordidle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

//effects
datablock ParticleData(ChainswordExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -500;
   spinRandomMax = 500;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 250;
   textureName          = "base/data/particles/chunk";
   colors[0]     = "1.0 0.75 0.0 1.0";
   colors[1]     = "0.25 0.25 0.25 0.9";
   colors[2]     = "0.25 0.25 0.25 0.0";
   sizes[0]      = 0.25;
   sizes[1]      = 0.125;
   sizes[2]      = 0.125;
   times[0]		 = 0;
   times[1]		 = 0.25;
   times[2]		 = 1;
   useinvalpha = true;
};

datablock ParticleEmitterData(ChainswordExplosionEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 1.5;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ChainswordExplosionParticle";

   uiName = "Chainsword Hit";
};

datablock ExplosionData(ChainswordExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = ChainswordHitSound;

   particleEmitter = ChainswordExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 0;
   lightStartColor = "1 0.75 0 1";
   lightEndColor = "1 0.5 0 0";
};


//projectile
AddDamageType("Chainsword",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_chainsword> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_chainsword> %1',0.75,1);
datablock ProjectileData(ChainswordProjectile)
{
   directDamage        = 40;
   directDamageType  = $DamageType::Chainsword;
   radiusDamageType  = $DamageType::Chainsword;
   explosion           = ChainswordExplosion;
   //particleEmitter     = poo;

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 70;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Chainsword Slice";
};


//////////
// item //
//////////
datablock ItemData(ChainswordItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Chainsword.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Chainsword";
	iconName = "./Chainsword";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = ChainswordImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ChainswordImage)
{
   // Basic Item properties
   shapeFile = "./Chainsword.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = "0";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ChainswordItem;
   ammo = " ";
   projectile = ChainswordProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.05;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                    = "Ready";
	stateTransitionOnTimeout[1]     = "Ready";
	stateTimeoutValue[1]            = 0.15;
	stateTransitionOnTriggerDown[1] = "PreFire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]				= "Fire";
	stateSound[1]					= ChainswordIdleSound;
	stateSequence[1]				= "Chain";

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";	
	stateSound[2]                    = ChainswordSwingSound;
	stateSequence[2]				= "Chain";
	
	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Wait";
	stateTimeoutValue[3]            = 0.1;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;
	stateSequence[3]				= "Chain";
	
	stateName[4]					= "Wait";
	stateTransitionOnTimeout[4]		= "Ready";
	stateTimeoutValue[4]			= 0.1;
	stateSequence[4]				= "Wait";
	stateScript[4]					= "onWait";
	stateSequence[4]				= "Chain";


};

function ChainswordImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, shiftTo);
	%obj.playthread(3, shiftLeft);
}

function ChainswordImage::onWait(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
