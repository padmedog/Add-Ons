datablock fxLightData(Anablue)
{
	uiName = "Eksi (AMB) - Ana blue";

	LightOn = true;
	radius = 50;
	brightness = 10;
	color = "0.63 0.86 1 1";

	flareOn = false;
	flarecolor = "1 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicblue";
	ConstantSizeOn = true;
	ConstantSize = 2;
	NearSize = 1;
	FarSize = 1;
};
datablock fxLightData(Anayel : Anablue)
{
	brightness=7;
	uiName = "Eksi (AMB) - Ana yellow";
	color = "1 0.8 0.65 1";
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicyellow";
};
datablock fxLightData(Bleuhoriz : Anablue)
{
	brightness = 8;
	uiName = "Eksi (AMB) - Horiz blue";
	color = "0.7 0.9 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/bleuhorizontal";
};
datablock fxLightData(Bleutonderayons : Anablue)
{
	brightness = 9;
	uiName = "Eksi (AMB) - Blue-rays";
	color = "0.75 0.92 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/bleutonderayons";
};
datablock fxLightData(Classicblue : Anablue)
{
	brightness = 7;
	uiName = "Eksi (AMB) - Blue 3";
	color = "0.6 0.9 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/classicblue";
};
datablock fxLightData(Etoilebleu : Anablue)
{
	brightness = 11;
	uiName = "Eksi (AMB) - Blue bright";
	color = "0.83 0.94 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/etoilebleu";
};
datablock fxLightData(Jaunidiagonal : Anablue)
{
	brightness = 7;
	uiName = "Eksi (AMB) - Diag yellow";
	color = "1 0.91 0.75 1";
	flarebitmap = "Add-Ons/Light_Eksi/jaunidiagonal";
};
datablock fxLightData(Multidirectionalcolor : Anablue)
{
	brightness = 9;
	uiName = "Eksi (AMB) - Teal multi";
	color = "0.67 1 0.97 1";
	flarebitmap = "Add-Ons/Light_Eksi/multidirectionalcolor";
};
datablock fxLightData(Neutresunetoile : Anablue)
{
	brightness = 8;
	uiName = "Eksi (AMB) - Neutral star";
	color = "1 0.88 0.76 1";
	flarebitmap = "Add-Ons/Light_Eksi/neutresunetoile";
};
datablock fxLightData(Normal20 : Anablue)
{
	brightness = 6;
	uiName = "Eksi (AMB) - Normal 20";
	color = "0.45 0.55 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/normal20";
};
datablock fxLightData(Vertical : Anablue)
{
	brightness = 7;
	uiName = "Eksi (AMB) - Vert yellow";
	color = "1 0.5 0.33 1";
	flarebitmap = "Add-Ons/Light_Eksi/vertical";
};
datablock fxLightData(Flashlight : Anablue)
{
	brightness = 9;
	uiName = "Eksi (AMB) - White spectrum";
	color = "1 1 1 1";
};