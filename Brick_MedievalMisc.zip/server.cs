datablock fxDTSBrickData(brickPotion1x1x1Data)
{
	brickFile = "./Bricks/Brick_Potion.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Potion";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Potion";
};
datablock fxDTSBrickData(brickTankard1x1x1Data)
{
	brickFile = "./Bricks/Brick_Tankard.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Tankard";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Tankard";
};
datablock fxDTSBrickData(brickRTankard1x1x1Data)
{
	brickFile = "./Bricks/Brick_ReversedTankard.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Upside-Down Tankard";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/RTankard";
};
datablock fxDTSBrickData(brickCandle1x3x3Data)
{
	brickFile = "./Bricks/Brick_Candlestick.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Candlestick";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Candlestick";
};
datablock fxDTSBrickData(brickBowl2x2x1Data)
{
	brickFile = "./Bricks/Brick_Bowl.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Bowl";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Bowl";
};
datablock fxDTSBrickData(brickJug2x2x2Data)
{
	brickFile = "./Bricks/Brick_Jug.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Jug";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Jug";
};
datablock fxDTSBrickData(brickMushroom1x1x1Data)
{
	brickFile = "./Bricks/Brick_Mushroom.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Mushroom";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Mushroom";
};
datablock fxDTSBrickData(brickBarrel2x2x2Data)
{
	brickFile = "./Bricks/Brick_Barrel.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Oak Barrel";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Barrel";
};
datablock fxDTSBrickData(brickLBarrel2x2x3Data)
{
	brickFile = "./Bricks/Brick_LBarrel.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Large Barrel";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/LBarrel";
};
datablock fxDTSBrickData(brickLBarrelSidewaysData)
{
	brickFile = "./Bricks/Brick_LSidewaysBarrel.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Large Sideways Barrel";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/LSWB";
};
datablock fxDTSBrickData(brickBarrelSidewaysData)
{
	brickFile = "./Bricks/Brick_SidewaysBarrel.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Sideways Barrel";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/SWB";
};
datablock fxDTSBrickData(brickHorizSword1x6x1Data)
{
	brickFile = "./Bricks/Brick_HorizSword.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Horizonal Prop Sword";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/HorizSword";
};
datablock fxDTSBrickData(brickVertSword1x1x5Data)
{
	brickFile = "./Bricks/Brick_VertSword.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Vertical Prop Sword";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/VertSword";
};
datablock fxDTSBrickData(brickVertSword_R1x1x5Data)
{
	brickFile = "./Bricks/Brick_VertSword_R.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Revered Vertical Sword";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/VertSword_R";
};
datablock fxDTSBrickData(brickBucket2x2x4Data)
{
	brickFile = "./Bricks/Brick_Bucket.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Bucket";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Bucket";
};
datablock fxDTSBrickData(brickVertTorch1x1x2Data)
{
	brickFile = "./Bricks/Brick_VertTorch.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Wall Mounted Torch";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/VertTorch";
};
datablock fxDTSBrickData(brickKeg2x3x2Data)
{
	brickFile = "./Bricks/Brick_Keg.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Keg";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Keg";
};
datablock fxDTSBrickData(brickArmorStandData)
{
	brickFile = "./Bricks/Brick_ArmorStand.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Armor Stand";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/ArmorStand";
};
datablock fxDTSBrickData(brickTrainingStandData)
{
	brickFile = "./Bricks/Brick_TrainingStand.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Training Dummy";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/TrainingStand";
};
datablock fxDTSBrickData(brickHelmStand1Data)
{
	brickFile = "./Bricks/Brick_Stand_Pointy.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Pointy Helmet Stand";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Pointy";
};
datablock fxDTSBrickData(brickHelmStand2Data)
{
	brickFile = "./Bricks/Brick_Stand_Flare.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Flare Helmet Stand";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Flare";
};
datablock fxDTSBrickData(brickStocksData)
{
	brickFile = "./Bricks/Brick_Stocks.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Stocks";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Stocks";
};
datablock fxDTSBrickData(brickCartData)
{
	brickFile = "./Bricks/Brick_Cart.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Cart";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Cart";
};
datablock fxDTSBrickData(brickAnvilData)
{
	brickFile = "./Bricks/Brick_Anvil.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Anvil";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Anvil";
};
datablock fxDTSBrickData(brickSackData)
{
	brickFile = "./Bricks/Brick_Sack.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Sack";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Sack";
};
datablock fxDTSBrickData(brickStuckHatchetData)
{
	brickFile = "./Bricks/Brick_HatchetStuck.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Stuck Hatchet";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/HatchetStuck";
};
datablock fxDTSBrickData(brickWellData)
{
	brickFile = "./Bricks/Brick_Well.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Well";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Well";
};
datablock fxDTSBrickData(brickCraftingTableData)
{
	brickFile = "./Bricks/Brick_CraftingTable.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Crafting Table";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/CraftingTable";
};
datablock fxDTSBrickData(brickAlchemyTableData)
{
	brickFile = "./Bricks/Brick_AlchemyTable.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Alchemy Table";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/AlchemyTable";
};
datablock fxDTSBrickData(brickFurnaceData)
{
	brickFile = "./Bricks/Brick_Furnace.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Furnace";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/Furnace";
};
datablock fxDTSBrickData(brickTanningRackData)
{
	brickFile = "./Bricks/Brick_TanningRack.blb";
	category = "Special";
	subCategory = "Medieval Props";
	uiName = "Tanning Rack";
	iconName = "Add-Ons/Brick_MedievalMisc/Icons/TanningRack";
};