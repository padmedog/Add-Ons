function EnvGui::updateGroundEnabled(%this)
{
    if(isObject(ServerConnection))
    {
        commandToServer('toggleGround');
    }
}

%btn = new GuiBitmapButtonCtrl(EnvGuiTogGround)
{
    profile = BlockButtonProfile;
    horizSizing = "left";
    vertSizing = "top";
    position = "114 397";
    extent = "96 38";
    command = "EnvGui.updateGroundEnabled();";
    text = "Toggle Ground";
    bitmap = "base/client/ui/button2";
    mcolor = "255 0 0 255";
};
EnvGui_Window.add(%btn);