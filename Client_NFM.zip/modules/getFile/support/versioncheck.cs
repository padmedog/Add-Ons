//version check
//----------
function nfm_versioncheck(%x) //%x is true if version check is manual
{
	if(!%x && !$NFM::VersionCheck)
		return;
	$nfmdownloader_manualconnect = %x;

	if(isobject(nfm_Downloader))
		nfm_Downloader.delete();

	new tcpobject(nfm_Downloader);
	$nfmdownloader_downloadphase = 0;
	nfm_Downloader.connect("forum.blockland.us:80");
}

function nfm_Downloader::onConnected(%this)
{
	if($nfmdownloader_downloadphase == 0)
	{
		//forum.blockland.us/index.php?topic=161834.720
		%req = "GET /index.php?topic=161834.720 HTTP/1.0\nHost: forum.blockland.us\n\n";
		%this.send(%req);
	}
	else
	{
		%req = "GET /index.php?action=dlattach;topic=161834.0;attach="@ $nfmdownloader_versionfile SPC"HTTP/1.0\nHost: forum.blockland.us\n\n";
		%this.send(%req);
	}
}

function nfm_Downloader::onConnectFailed(%this)
{
	if($nfmdownloader_manualconnect)
		messageboxok("Attention!", "Unable to connect to the online version information.\n\nYou should check online to make sure this File Manager is up to date.");
}

function nfm_Downloader::onDisconnect(%this)
{
	if(!$nfmdownloader_connected)
	{
		if($nfmdownloader_manualconnect)
			messageboxok("Attention!", "Unable to connect to the online version information.");
	}
	else
		$nfmdownloader_connected = "";
}

function nfm_Downloader::onLine(%this, %line)
{
	if($nfmdownloader_downloadphase == 0)
	{
		if(strpos(%line, "Versions.txt") > -1)
		{
			%subline = "http://forum.blockland.us/index.php?action=dlattach;topic=161834.0;attach=";
			$nfmdownloader_versionfile = getsubstr(%line, strpos(%line, %subline)+strlen(%subline), strpos(%line, "\">")-(strpos(%line, %subline)+strlen(%subline)));

			if(mfloor($nfmdownloader_versionfile) $= $nfmdownloader_versionfile)
			{
				$nfmdownloader_connected = 1;
				nfm_Downloader.disconnect();
				$nfmdownloader_downloadphase = 1;
				nfm_Downloader.connect("forum.blockland.us:80");
			}
			else
				nfm_Downloader.disconnect();
		}
	}
	else
	{
		%tag = "NARG MOD VERSION NFM: ";

		if(getsubstr(%line, 0, strlen(%tag)) $= %tag)
		{
			$nfmdownloader_connected = 1;
			$nfmdownloader_availableversion = getsubstr(%line, 22, strlen(%line));

//			if($nfmdownloader_availableversion $= $nfm_version)
//				nfm_versionresult(1);
//			else
//				nfm_versionresult(0);
			%av0 = getword($nfmdownloader_availableversion, 0);
			%av1 = getword($nfmdownloader_availableversion, 1);
			%v0 = getword($nfm_version, 0);
			%v1 = getword($nfm_version, 1);

			if(%av0 > %v0 || (%av0 $= %v0 && stricmp(%av1, %v1) == 1))
			{
				nfm_versionresult(0);
			}
			else
			{
				nfm_versionresult(1);
			}
			nfm_Downloader.disconnect();
		}
	}
}

function nfm_versionresult(%x)
{
	if(%x)
	{
		if($nfmdownloader_manualconnect)
			messageboxok("Good News!", "Your File Manager is up to date.");
	}
	else
		messageboxok("Attention!", "There is a more current version of Your File Manager!\n\nYour Version: "@$nfm_version@"\n\nAvailable: "@$nfmdownloader_availableversion);
}

