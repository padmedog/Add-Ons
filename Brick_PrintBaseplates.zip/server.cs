datablock fxDTSBrickData(brick64x64PrintData)
{
	brickFile = "Add-Ons/Brick_PrintBaseplates/64x64Print.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "64x Print";
	iconName = "Add-Ons/Brick_PrintBaseplates/64x64Print";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};
datablock fxDTSBrickData(brick48x48PrintData)
{
	brickFile = "Add-Ons/Brick_PrintBaseplates/48x48Print.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "48x Print";
	iconName = "Add-Ons/Brick_PrintBaseplates/48x48Print";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};
datablock fxDTSBrickData(brick32x32PrintData)
{
	brickFile = "Add-Ons/Brick_PrintBaseplates/32x32Print.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "32x Print";
	iconName = "Add-Ons/Brick_PrintBaseplates/32x32Print";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};
datablock fxDTSBrickData(brick16x16PrintData)
{
	brickFile = "Add-Ons/Brick_PrintBaseplates/16x16Print.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "16x Print";
	iconName = "Add-Ons/Brick_PrintBaseplates/16x16Print";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};