%this = new PhysicalZone(AdjustableZone)
{
	position = "-5000 5000 -5000";
	rotation = "1 0 0 0";
	scale = "9999 9999 9999";
	velocityMod = "1";
	gravityMod = "0.1";
	extraDrag = "0";
	isWater = "0";
	waterViscosity = "40";
	waterDensity = "1";
	waterColor = "0.200000 0.600000 0.600000 0.300000";
	appliedForce = "0 0 0";
	polyhedron = "0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 -1.0000000 0.0000000 0.0000000 0.0000000 1.0000000";
};
missiongroup.add(%this);

%admin = new scriptobject()
{
	isadmin = true;
};
servercmdenvgui_setvar(%admin, "groundcolor", "1 1 1 0");
%admin.delete();

if($spacepropertiesloaded)
	return;
$spacepropertiesloaded = true;
messageall('', "\c6You can change gravity, toggle crouch dropping, and toggle the ground now through /commands!");

function servercmdtoggleground(%client)
{
	servercmdtogground(%client);
}

function servercmdtogground(%client)
{
	if(!%client.isAdmin)
		return;

	if(isobject(groundplane))
	{
		servercmdenvgui_setvar(%client, "groundcolor", "1 1 1 0");
		groundplane.save("config/server/temp/groundplane.cs");
		groundplane.delete();
		messageall('', "\c2"@ %client.name @" has removed the ground.");
	}
	else
	{
		if(isfile("config/server/temp/groundplane.cs"))
		{
			exec("config/server/temp/groundplane.cs");
			missiongroup.add(groundplane);
			//We'll let them figure out how to recolor it
			messageall('', "\c2"@ %client.name @" has unremoved the ground.");
		}
		else
			messageclient(%client, '', "Ground plane recovery file not found, you are screwed.");
	}
}

function servercmdsetgravity(%client, %val)
{
	if(!%client.isAdmin || !isobject(AdjustableZone))
		return;

	%val *= 1; //makes it a number

	AdjustableZone.gravityMod = %val;
	messageall('', "\c4"@ %client.name @"\c6 has changed the gravity to \c0"@ %val);
}

$crouchdropactive = 1;

if(ispackage(crouchdrop))
	deactivatepackage(crouchdrop);

package crouchdrop
{
	function armor::ontrigger(%dtb, %player, %slot, %x)
	{
		if(%slot == 3)
			forcedown(%player, %x);
		parent::ontrigger(%dtb, %player, %slot, %x);
	}
};
activatepackage(crouchdrop);

function forcedown(%player, %en)
{
	if(!isobject(%player) || !isobject(AdjustableZone))
		return;

	if(%en)
	{
		%vel = %player.getvelocity();
		%x = getword(%player.getvelocity(), 0);
		%y = getword(%player.getvelocity(), 1);
		%z = getword(%player.getvelocity(), 2);
		%player.setvelocity(%x SPC %y SPC %z-0.03);
		%cmd = "forcedown("@ %player @","@ %en @");";
		%player.forcedownsched = schedule(1, 0, "eval", %cmd);
		return;
	}

	if(iseventpending(%player.forcedownsched))
		cancel(%player.forcedownsched);
}

function servercmdtogglecrouchdrop(%client)
{
	if(!%client.isadmin)
		return;
	$crouchdropactive = !$crouchdropactive;

	if($crouchdropactive)
		activatepackage(crouchdrop);
	else
		deactivatepackage(crouchdrop);
	%state = $crouchdropactive ? "on":"off";
	messageall('', "\c6"@ %client.name @" \c2has turned Crouch to Drop \c3"@ %state);
}