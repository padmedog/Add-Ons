exec("./Player_Survivor.cs");
exec("./Zombie_Ai.cs");
exec("./Zombie_DefaultParent.cs");
exec("./Zombie_spawn.cs");
exec("./Zombie_images.cs");
exec("./Zombie_slow.cs");
exec("./Zombie_normal.cs");
exec("./Zombie_fast.cs");
exec("./Zombie_tank.cs");
exec("./Zombie_boomer.cs");
exec("./Zombie_hunter.cs");
exec("./Zombie_witch.cs");
exec("./Zombie_smoker.cs");
exec("./Zombie_Director.cs");
exec("./Weapon_PropaneTank.cs");
exec("./Item_MedKit.cs");
exec("./Item_AmmoCrate.cs");
exec("./Weapons_overwrite.cs");
exec("./Zombie_overwrite.cs");
exec("./Item_Pills.cs");
exec("./pipebomb/pserver.cs");
//exec("./Weapon_GasCan.cs");

function ParseZombieAP()
{
   %file = new FileObject();
   if(%file.openForRead("Add-ons/gamemode_zombie/zombie_appearances.txt"))
   {
      while(!%file.isEOF())
      {
         %line = %file.readLine();
		 eval(%line);
	  }
   }
   %file.close();
   %file.delete();
}
ParseZombieAP();
function ExecZombies()
{
	exec("add-ons/gamemode_zombie/server.cs");
}
function UpdateZombieSettings(%minigame,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%crouch,%ggfollow,%retspawn,%radius,%chance,%dir)
{
	%minigame.EnableZombies = %a;

	%minigame.Points_KillZombie = %b;
	%minigame.Points_HelpPlayer = %c;

	%minigame.EnableDowned = %d;
	%minigame.EnableAmmoMod = %e;
	%minigame.PlayersCanRespawn = %f;

	%minigame.zombieBrickDamage = %g;
	%minigame.zombieBreakLargePlates = %h;
	%minigame.zombieBreakBrickTerrain = %i;
	%minigame.zombieCanJump = %j;
	%minigame.zombieCanDrive = %k;
	%minigame.zombieAlwaysFindPlayer = %l;
	%minigame.zombieMax = %m;
	%minigame.zombieMaxHorde = %n;
	%minigame.zombieMinHorde = %o;
	%minigame.zombieMelee = %p;
	%minigame.zombieCanCrouch = %crouch;
	%minigame.zombieGGCanFollow = %ggfollow;
}
function UpdateZombieSettings2(%minigame,%retspawn,%radius,%chance,%dir,%los,%fri,%diff)
{
	%minigame.zombieReturnToSpawn = %retspawn;
	%minigame.zombieRadiusOver = %radius;
	%minigame.zombieChanceOver = %chance;

	%minigame.zombieDirectorEnabled = %dir;
	%minigame.zombieDisableLosChecks = %los;
	%minigame.zombieFriendlyFire = %fri;
	%minigame.zombieDifficulty = %diff;
}
function servercmdServerZombiePrefs(%client,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%crouch,%ggfollow,%retspawn,%radius,%chance,%dir)
{
	if(isobject(%client.minigame) && %client.minigame.owner == %client)
	{
		UpdateZombieSettings(%client.minigame,%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%crouch,%ggfollow,%retspawn,%radius,%chance,%dir);
	}
}
function servercmdServerZombiePrefs2(%client,%retspawn,%radius,%chance,%dir,%los,%fri,%diff)
{
	if(isobject(%client.minigame) && %client.minigame.owner == %client)
	{
		UpdateZombieSettings2(%client.minigame,%retspawn,%radius,%chance,%dir,%los,%fri,%diff);
	}
}

function servercmdEnableZombieMod(%client)
{
	if(%client.isadmin && %client.issuperadmin)
	{
	$pref::Server::ZombiesEnabled = 1;
	MessageAll("",'<color:AAFFAA>%1 Enabled Zombie mod',%client.name);
	}
}

function servercmdDisableZombieMod(%client)
{
	if(%client.isadmin && %client.issuperadmin)
	{
	$pref::Server::ZombiesEnabled = 0;
	MessageAll("",'<color:FFBBBB>%1 Disabled Zombie mod',%client.name);
	}
}
$pref::Server::ZombiesEnabled = 1;

//-----------------------------------------------------------------------------
//Safehouse trigger
//-----------------------------------------------------------------------------

datablock TriggerData(SafeHouseTrigger)
{
	//uiName = "Safehouse";
   tickPeriodMS = 500;
};
function getMinigameLivingCount(%minigame)
{
	%base = 0;
	for(%a = 0; %a < %minigame.numMembers; %a++)
	{
		%player = %minigame.member[%a].player;
		if(!%player.isdowned && isobject(%player))
		{
			%base+=1;
		}
		if(isobject(%player) && !%player.getstate() $= "Dead")
		{
			%base+=1;
		}
	}
	return %base;
}
function SafeHouseTrigger::onEnterTrigger(%this,%trigger,%obj)
{
	if(IsInMinigame(%obj) == 0)
	{
		return;
	}
	%minigame = %obj.client.minigame;
	if(%minigame.SafeFromZombies != 1 && isobject(%minigame))
	{
		if(!isobject(%minigame.safeHouseSim))
		{
			%minigame.safeHouseSim = new SimSet ()
			{
				
			};
			MissionCleanup.add(%minigame.safeHouseSim);
		}

		%minigame.safeHouseSim.add(%obj);

		if(getMinigameLivingCount(%minigame) <= %minigame.safeHouseSim.getcount())
		//if(getMinigameLivingCount(%minigame) <= %trigger.getNumObjects())
		{
			%minigame.SafeFromZombies = 1;
			safehouseWinTest(%obj.client);
		}
	}
   Parent::onEnterTrigger(%this,%trigger,%obj);
}

function SafeHouseTrigger::onLeaveTrigger(%this,%trigger,%obj)
{
	if(IsInMinigame(%obj) == 0)
	{
		return;
	}
	%minigame = %obj.client.minigame;
	if(%minigame.SafeFromZombies != 1 && isobject(%minigame))
	{
		%minigame.safeHouseSim.remove(%obj);
	}
   Parent::onLeaveTrigger(%this,%trigger,%obj);
}

function SafeHouseTrigger::onTickTrigger(%this,%trigger)
{
	%nTest = 0;
	%Players = %trigger.getnumobjects();
	for(%n = 0; %n < %players; %n++)
	{
		if(isobject(%trigger.getobject(%n).client.minigame) && %trigger.getobject(%n).client.minigame == %trigger.brick.getgroup().client.minigame)
		{
			%minigame = %trigger.getobject(%n).client.minigame;
			%nTest++;
			break;
		}
	}
	if(%minigame.SafeFromZombies != 1  && isobject(%minigame))
	{
		if(getMinigameLivingCount(%minigame) <= %minigame.safeHouseSim.getcount())
		{
			%minigame.SafeFromZombies = 1;
			safehouseWinTest(%minigame.member0);
		}
	}
   Parent::onTickTrigger(%this,%trigger);
}
function SafehouseReset(%minmemb,%n)
{
	%numalive = getMinigameLivingCount(%minmemb.minigame);
	%numt = %minmemb.minigame.numMembers;
	if(isobject(%minmemb))
	{
		if(%n == 0)
		{	
			schedule(600,0,yetanotherhacktoavoidevalcrashbyrot,%minmemb);
			%minmemb.bottomprint("<just:center><color:AAFFAA>Minigame Reset.",5);
			return;
		}
		%minmemb.centerprint("<just:center><color:AAFFAA>" @ %numalive SPC "out of"SPC %numt SPC "survivors made it to the safe house!",2);
		if(%numalive == %numt)
		{
			%minmemb.centerprint("<just:center><color:AAFFAA>All survivors have made it to the safe house!",2);
		}
	
		%minmemb.bottomprint("<just:center><color:AAFFAA> Minigame Resetting in" SPC %n SPC "seconds.",2);
	}
}
function yetanotherhacktoavoidevalcrashbyrot(%minmemb)
{
	%minmemb.minigame.SafeFromZombies = 0;
	%minmemb.minigame.NumInSafeZone = 0;
}
function safehouseWinTest(%obj)
{
			for(%a= 0;%a< %obj.minigame.numMembers;%a++)
			{
				%minmemb = %obj.minigame.member[%a];
				SafehouseReset(%minmemb,5,%r);
				schedule(1000,0,SafehouseReset,%minmemb,4);
				schedule(2000,0,SafehouseReset,%minmemb,3);
				schedule(3000,0,SafehouseReset,%minmemb,2);
				schedule(4000,0,SafehouseReset,%minmemb,1);
				schedule(5000,0,SafehouseReset,%minmemb,0);
			}
			schedule(5000,0,AllPlayerDeadRestart,%obj.minigame);
}
//I was an extra in a movie today, it was really strange, and I probably heard someone say standby about 300 times.
function SetTriggerOnBrick(%brick,%trigger)
{	
	%brick.Satrigger = new Trigger()
	{
      initialPosition = "0 0 0";
	  scale = "1 1 1";
      dataBlock = "SafeHouseTrigger";
      polyhedron = "0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 -1.0000000 0.0000000 0.0000000 0.0000000 1.0000000";
	};
	missionCleanup.add(%brick.Satrigger);
	%brick.Satrigger.brick = %brick;
	%bpos = %brick.getposition();
	%tpos = %brick.Satrigger.getposition();

	%brot = getwords(%brick.gettransform(),3,6);
	%trot = getwords(%brick.Satrigger.gettransform(),3,6);

	%bx = %brick.getdatablock().brickSizeX/4;
	%by = %brick.getdatablock().brickSizeY/4;
	
	%brick.Satrigger.setscale(%bx*2 SPC %by*2 SPC 1);
	if(getword(%brot,0) == 1)
	{
		%brick.Satrigger.settransform(vectoradd(%bpos,-%bx SPC %by SPC "0") SPC %brot);
		return %brick.Satrigger;
	}
	
	if(getword(%brot,2) == 1 && getword(%brot,3) == 1.5708)
	{
		%brick.Satrigger.settransform(vectoradd(%bpos,%by SPC %bx SPC "0") SPC %brot);
		return %brick.Satrigger;
	}

	if(getword(%brot,3) == 3.14159)
	{
		%brick.Satrigger.settransform(vectoradd(%bpos,%bx SPC -%by SPC "0") SPC %brot);
		return %brick.Satrigger;
	}

	if(getword(%brot,2) == -1 && getword(%brot,3) == 1.5708)
	{
		%brick.Satrigger.settransform(vectoradd(%bpos,-%by SPC -%bx SPC "0") SPC %brot);
		return %brick.Satrigger;
	}
}
datablock ItemData(SafehouseItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./emptymodel.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Safehouse";
	iconName = "";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = "";
	canDrop = true;
};

function SafehouseItem::onAdd(%this,%obj,%a,%b,%c)
{
	%obj.setscale("0.01 0.01 0.01");

	schedule(10,0,SafeHouseTriggerAdd,%obj);
}
function SafehouseItem::onCollision(%this,%obj,%col,%a,%b,%c)
{
	return;
}
function SafeHouseTriggerAdd(%obj)
{	
	%obj.canpickup = 0;
	%obj.settransform(vectoradd(%obj.getposition(),"0 0 -0.15"));
	if(isobject(%obj.spawnbrick))
	{
		SetTriggerOnBrick(%obj.spawnbrick);
	}
}
function SafehouseItem::onRemove(%this,%obj,%a,%b,%c)
{
	%obj.spawnbrick.Satrigger.schedule(10,delete);
}