if (!$AutoJet::addedJet)
{
	$remapDivision[$remapCount] = "Auto-Jet";
	$remapName[$remapCount] = "Activate/Deacticate";
	$remapCmd[$remapCount] = "activateJet";
	$remapCount++;
	$remapName[$remapCount] = "Elevate";
	$remapCmd[$remapCount] = "autoJetHeightUp";
	$remapCount++;
	$remapName[$remapCount] = "Decend";
	$remapCmd[$remapCount] = "autoJetHeightDown";
	$remapCount++;
	$AutoJet::addedJet = true;
}

function autoJetHeightUp()
{
	$autoJetHeight++;
}

function autoJetHeightDown()
{
	$autoJetHeight--;
}

function autoJet(%player)
{
	if (!isObject(%player) || $autojetheight $= "")
	{
		deactivateJet();
		return;
	}
	%curHeight = getWord(%player.getTransform(), 2);
	%heightDif = %curHeight - $autojetheight;
	%curVel = getWord(%player.getVelocity(), 2);
//	if ($mvtriggercount[3] > 0) //someone can try fixing this if they want, it was going to stop the jet while crouching
//	{
//		$mvtriggerCount[4] = false;
//	}
	if (%player.getWaterCoverage() >= 0.65)
	{
		$AutoJet::crouching = true;
		if (%curVel < -1)
		{
			$mvtriggercount[3] = false;
		}
		else if (%heightDif <= 0.2)
		{
			$mvtriggercount[3] = false;
		}
		else if (%heightDif > 0)
		{
			$mvtriggercount[3] = true;
		}
		if ($AutoJet::jetting)
		{
			$mvtriggercount[4] = false;
			$AutoJet::jetting = false;
		}
	}
	else
	{
		$AutoJet::jetting = true;
		$mvtriggercount[3] = false;
		if (%curVel < -1)
		{
			$mvtriggercount[4] = true;
		}
		else if (%heightDif <= 0.2)
		{
			$mvtriggercount[4] = true;
		}
		else if (%heightDif > 0)
		{
			$mvtriggercount[4] = false;
		}
		if ($AutoJet::crouching)
		{
			$mvtriggercount[3] = false;
			$AutoJet::crouching = false;
		}
	}
	$AutoJet::jetTick = schedule(50, 0, "autoJet", %player);
}

function findJetPlayer(%playername)
{
	if (%playername $= "")
	{
		%player = ServerConnection.getControlObject();
		%type = %player.getClassName();
		if (%type $= "Player" || %type $= "AIPlayer") return %player;
		else return false;
	}
	for (%i = 0; %i < ServerConnection.getCount(); %i++)
	{
		%testObj = ServerConnection.getObject(%i);
		if (%testObj.getClassName() $= "Player")
		{
			if (%testObj.getShapeName() $= $pref::Player::NetName)
			{
				%player = %testObj;
				return %player;
			}
		}
	}
	return false;
}

function activateJet(%val)
{
	if (!%val) return;

	if (!isEventPending($AutoJet::jetTick))
	{
		%player = findJetPlayer();
		if (isObject(%player))
		{
			$autojetheight = getWord(%player.getTransform(), 2);
			$AutoJet::jetTick = schedule(0, 0, "autoJet", %player);		
		}
	}
	else
	{
		deactivateJet();
	}
}

function deactivateJet()
{
	if (isEventPending($AutoJet::jetTick))
	{
		cancel($AutoJet::jetTick);
		$mvTriggerCount[4] = false;
		$mvTriggerCount[3] = false;
	}
}

package autoJetPackage
{
	function jet(%val)
	{
		if(isEventPending($AutoJet::jetTick) && $AutoJet::jetting)
			return;
		Parent::jet(%val);
	}
	
	function crouch(%val)
	{
		if(isEventPending($AutoJet::jetTick))
			return;
		Parent::crouch(%val);
	}
};

activatePackage(autoJetPackage);