//########## Saiga
datablock AudioProfile(SaigaWhizSound){filename="./Sounds/whiz.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaDeploySound){filename="./Sounds/equip.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaHitSound){filename="./Add-Ons/Weapon_Gun/bulletHit.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaMetalHitSound){filename="./Add-Ons/Weapon_Gun/bulletHit.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaFireSound){filename="./Sounds/Saigafire.wav";description=AudioClose3d;preload=true;};

datablock AudioProfile(SaigaClickSound){filename="./Sounds/empty.wav";detscription=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaReload1Sound){filename="./Sounds/SaigaReload1.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaReload2Sound){filename="./Sounds/SaigaReload2.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(SaigaCockSound){filename="./Sounds/SaigaCock.wav";description=AudioClosest3d;preload=true;};

datablock ParticleData(SaigabulletExplosionParticle){dragCoefficient=8;gravityCoefficient=0;inheritedVelFactor=0.2;constantAcceleration=0;lifetimeMS=1000;lifetimeVarianceMS=0;textureName="base/data/particles/cloud";spinSpeed=10;spinRandomMin=-50;spinRandomMax=50;colors[0]="0.4 0.4 0.4 0.5";colors[1]="0.2 0.2 0.2 0";sizes[0]=0.5;sizes[1]=2;useInvAlpha=true;};

datablock ParticleEmitterData(SaigabulletExplosionEmitter){uiName="";ejectionPeriodMS=8;periodVarianceMS=0;ejectionVelocity=2;velocityVariance=1;ejectionOffset=0;thetaMin=89;thetaMax=90;phiReferenceVel=0;phiVariance=360;overrideAdvance=false;particles="SaigabulletExplosionParticle";};

datablock ParticleData(SaigabulletDebrisExplosionParticle){dragCoefficient=0;gravityCoefficient=5;inheritedVelFactor=0.2;constantAcceleration=0;lifetimeMS=1000;lifetimeVarianceMS=500;textureName="base/data/particles/chunk";spinSpeed=10;spinRandomMin=-50;spinRandomMax=50;colors[0]="0.2 0.2 0.2 1";colors[1]="0.2 0.2 0.2 0";sizes[0]=0.2;sizes[1]=0.2;useInvAlpha=true;};

datablock ParticleEmitterData(SaigabulletDebrisExplosionEmitter){uiName="";ejectionPeriodMS=3;periodVarianceMS=0;ejectionVelocity=16;velocityVariance=8;ejectionOffset=0;thetaMin=0;thetaMax=30;phiReferenceVel=0;phiVariance=360;overrideAdvance=false;particles="SaigabulletDebrisExplosionParticle";};

datablock ParticleData(SaigabulletExplosionSmokeParticle : SaigabulletExplosionParticle){dragCoefficient=6;gravityCoefficient=0.2;inheritedVelFactor=0;lifetimeMS=1400;lifetimeVarianceMS=200;textureName="base/data/particles/cloud";colors[0]="0.6 0.6 0.6 1";colors[1]="0.6 0.6 0.6 0.2";colors[2]="0.4 0.4 0.4 0";sizes[0]=0.5;sizes[1]=0.6;sizes[2]=5;times[0]=0;times[1]=0.1;times[2]=1;useInvAlpha=true;};

datablock ParticleEmitterData(SaigabulletExplosionSmokeEmitter : SaigabulletExplosionEmitter){uiName="";ejectionPeriodMS=8;ejectionVelocity=9;velocityVariance=8;thetaMin=0;thetaMax=30;overrideAdvance=false;particles="SaigabulletExplosionSmokeParticle";};

datablock ExplosionData(SaigabulletExplosion){lifeTimeMS=50;emitter[0]=SaigabulletExplosionSmokeEmitter;emitter[1]=SaigabulletDebrisExplosionEmitter;faceViewer=true;explosionScale="1 1 1";shakeCamera=true;camShakeFreq="2 2 2";camShakeAmp="1 1 1";camShakeDuration=0.5;camShakeRadius=1;};

datablock ExplosionData(SaigaRecoilExplosion){lifeTimeMS=1;explosionScale="1 1 1";shakeCamera=true;camShakeFreq="1.5 1.5 1.5";camShakeAmp="0.8 1.0 0.8";camShakeDuration=0.6;camShakeRadius=1;};

datablock ProjectileData(SaigaRecoil){uiName="";explosion=SaigaRecoilExplosion;muzzleVelocity=0;velInheritFactor=1;lifetime=1;fadeDelay=1;explodeOnDeath=true;};

datablock ParticleData(SaigaFlashParticle : SaigabulletExplosionParticle){dragCoefficient=0;inheritedVelFactor=1;lifetimeMS=30;textureName="base/data/particles/cloud";spinSpeed=50;spinRandomMin=-500;spinRandomMax=500;colors[0]="1 0.5 0 1";colors[1]="1 0.8 0.6 1";colors[2]="1 0.6 0.3 0";sizes[0]=0.1;sizes[1]=0.5;sizes[2]=0;times[9]=0;times[1]=0.3;times[2]=1;useInvAlpha=false;};

datablock ParticleEmitterData(SaigaFlashEmitter : SaigabulletExplosionEmitter){ejectionPeriodMS=3;ejectionVelocity=50;velocityVariance=0;thetaMin=0;thetaMax=10;particles="SaigaFlashParticle";uiName="";};

datablock DebrisData(SaigaShellDebris){shapeFile="./Models/BFShotgunShell.dts";lifetime=2;minSpinSpeed=-400;maxSpinSpeed=200;elasticity=0.5;friction=0.2;numBounces=3;staticOnMaxBounce=true;snapOnMaxBounce=false;fade=true;gravModifier=2;};

datablock ParticleData(BFShotgunsTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 120;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 0 1";
	colors[1]	= "1 1 0.4 1";
	colors[2]	= "1 1 1 1";
	sizes[0]	= 0.2;
	sizes[1]	= 0.15;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(BFShotgunsTracer)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 30.0;  

   particles = BFShotgunsTrailParticle;

   useEmitterColors = true;
};

AddDamageType("Saiga",'<bitmap:Add-ons/Weapon_BFShotguns/CISaiga>%1','%2<bitmap:Add-ons/Weapon_BFShotguns/CISaiga> %1',0.2,1);

datablock ProjectileData(SaigaProjectile){uiName="";
projectileShapeName="./Models/modernBullet.dts";
directDamage=13;
directDamageType=$DamageType::Saiga;
radiusDamageType=$DamageType::Saiga;brickExplosionRadius=0;
brickExplosionImpact=true;
brickExplosionForce=30;brickExplosionMaxVolume=1;
brickExplosionMaxVolumeFloating=2;
impactImpulse=60;
explosion=SaigabulletExplosion;
//particleEmitter     = "BFShotgunsTracer";
muzzleVelocity=500;
verInheritFactor=1;
lifetime=4000;
fadeDelay=2000;
bounceElasticity=0.5;
bounceFriction=0.2;
isBallistic=true;
gravityMod=0.20;
sound=SaigaWhizSound;

};

datablock ItemData(SaigaItem){uiName="Saiga12";iconName="./Saiga";

image=SaigaImage;category=Weapon;className=Weapon;shapeFile="./Models/SaigaDisplay.dts";
mass=1;
density=0.2;
elasticity=0;
friction=0.6;
emap=true;
doColorShift=true;
colorShiftColor="1 1 1 1";
canDrop=true;Saigareload=1;Saigamaxmag=8;};
datablock shapeBaseImageData(SaigaImage){shapeFile="./Models/Saiga.dts";
emap=true;
correctMuzzleVector=true;className="WeaponImage";
item=SaigaItem;
ammo="";
projectile=SaigaProjectile;
projectileType=Projectile;
casing=SaigaShellDebris;
shellExitDir="1 0.5 0.5";
shellExitVariance=10;
shellVelocity=6;
melee=false;
doReaction=false;
armReady=true;
doColorShift=true;
colorShiftColor="1 1 1 1";

//#########################################################################################
//#-Sequences-										#
//#											#
//#	fire / fire the weapon								#
//#	reload / reloads the weapon -clipIn and clipOut combined-			#
//#	use / When you equip the weapon -I added this-					#	
//#											#		
//#########################################################################################	
	
	stateName[0]="Activate";
	stateTimeoutValue[0]=0.8;
	stateTransitionOnTimeout[0]="AmmoCheck";
	stateSequence[0]="use";
	stateSound[0]=SaigaDeploySound;

	stateName[1]="Ready";
	stateTransitionOnTriggerDown[1]="Fire1";
	stateAllowImageChange[1]=true;
	stateTransitionOnNoAmmo[1]="Empty";
	
	stateName[2]="Fire1";
	stateTransitionOnTimeout[2]="AmmoCheck";
	stateTimeoutValue[2]="0.14";
	stateFire[2]=true;
	stateAllowImageChange[2]=false;
	stateWaitForTimeout[2]=true;
	stateEmitter[2]=SaigaFlashEmitter;
	stateEmitterTime[2]=0.05;
	stateEmitterNode[2]="muzzlePoint";
	stateSound[2]=SaigaFireSound;
	stateScript[2]="onFire1";
	stateEjectShell[2]=true;
	stateSequence[2]="Fire";

	stateName[3]="Fire2";
	stateTransitionOnTimeout[3]="AmmoCheck";
	stateTimeoutValue[3]="0.63";
	stateFire[3]=true;
	stateAllowImageChange[3]=false;
	stateWaitForTimeout[3]=true;
	stateEmitter[3]=SaigaFlashEmitter;
	stateEmitterTime[3]=0.05;
	stateEmitterNode[3]="muzzlePoint";
	stateSound[3]=SaigaFireSound;
	stateScript[3]="onFire2";
	stateEjectShell[3]=true;
	stateSequence[3]="Fire";
	
	stateName[4]="AmmoCheck";
	stateTransitionOnTriggerUp[4]="Ready";
	stateAllowImageChange[4]=true;
	stateScript[4]="onAmmoCheck";
	
	stateName[5]="Reload";
	stateTimeoutValue[5]=0.8;
	stateSequence[5]="Reload1";
	stateTransitionOnTimeout[5]="Reload2";
	stateWaitForTimeout[5]=true;
	stateSound[5]=SaigaReload1Sound;
	stateAllowImageChange[5]=true;

	stateName[9]="Reload2";
	stateTimeoutValue[9]=1.9;
	stateSequence[9]="Reload2";
	stateTransitionOnTimeout[9]="Cock";
	stateWaitForTimeout[9]=true;
	stateSound[9]=SaigaReload2Sound;
	stateAllowImageChange[9]=true;
	
	stateName[10]="Cock";
	stateTimeoutValue[10]=1.0;
	stateSequence[10]="Cock";
	stateTransitionOnTimeout[10]="Done";
	stateWaitForTimeout[10]=true;
	stateSound[10]=SaigaCockSound;
	stateAllowImageChange[10]=true;
	
	stateName[6]="Done";
	stateTransitionOnTimeout[6]="Ready";
	stateTimeoutValue[6]=0.1;
	stateAllowImageChange[6]=true;
	stateScript[6]="onReload";stateName[7]="Empty";
	
	stateTransitionOnTriggerDown[7]="EmptyFire";
	stateAllowImageChange[7]=true;
	stateTransitionOnAmmo[7]="Reload";
	
	stateName[8]="EmptyFire";
	stateTransitionOnTriggerUp[8]="Ready";
	stateTimeoutValue[8]="0.15";
	stateAllowImageChange[8]=false;
	stateWaitForTimeout[8]=true;
	stateSound[8]=SaigaClickSound;

};		
	
	datablock shapeBaseImageData(SaigaImageScoped : SaigaImage)
{
	offset = "-0.2 0.3 0"; //-Left +Right, -Back +Front, -Down +Up
   	eyeOffset="0.0 1.5 -0.85"; //-Left +Right, -Back +Front, -Down +Up


	stateName[0]="Activate";
	stateTimeoutValue[0]=0.3;
	stateTransitionOnTimeout[0]="AmmoCheck";
	//stateSequence[0]="Sight";
	
	stateName[1]="Ready";
	stateTransitionOnTriggerDown[1]="Fire1";
	stateAllowImageChange[1]=true;
	stateTransitionOnNoAmmo[1]="Empty";
	stateSequence[1]="Ready";
	
	stateName[2]="Fire1";
	stateTransitionOnTimeout[2]="AmmoCheck";
	stateTimeoutValue[2]="0.14";
	stateFire[2]=true;
	stateAllowImageChange[2]=false;
	stateWaitForTimeout[2]=true;
	stateEmitter[2]=SaigaFlashEmitter;
	stateEmitterTime[2]=0.10;
	stateEmitterNode[2]="muzzlePoint";
	stateSound[2]=SaigaFireSound;
	stateScript[2]="onFire1";
	stateEjectShell[2]=true;
	stateSequence[2]="Fire";
	
	stateName[3]="Fire2";
	stateTransitionOnTimeout[3]="AmmoCheck";
	stateTimeoutValue[3]="0.25";
	stateFire[3]=true;
	stateAllowImageChange[3]=false;
	stateWaitForTimeout[3]=true;
	stateEmitter[3]=SaigaFlashEmitter;
	stateEmitterTime[3]=0.05;
	stateEmitterNode[3]="muzzlePoint";
	stateSound[3]=SaigaFireSound;
	stateScript[3]="onFire2";
	stateEjectShell[3]=true;
	stateSequence[3]="Fire";
	
	stateName[4]="AmmoCheck";
	stateTransitionOnTriggerUp[4]="Ready";
	stateAllowImageChange[4]=true;
	stateScript[4]="onAmmoCheck";
	
	stateName[5]="Reload";
	stateTimeoutValue[5]=0.8;
	stateSequence[5]="Reload";
	stateTransitionOnTimeout[5]="Reload2";
	stateWaitForTimeout[5]=true;
	stateSound[5]=SaigaReload1Sound;
	stateAllowImageChange[5]=true;
	stateSequence[5]="Reload1";

	stateName[10]="Reload2";
	stateTimeoutValue[10]=0.9;
	stateSequence[10]="Reload2";
	stateTransitionOnTimeout[10]="Cock";
	stateWaitForTimeout[10]=true;
	stateSound[10]=SaigaReload2Sound;
	stateAllowImageChange[10]=true;
	
	stateName[11]="Cock";
	stateTimeoutValue[11]=1.0;
	stateSequence[11]="Cock";
	stateTransitionOnTimeout[11]="Done";
	stateWaitForTimeout[11]=true;
	stateSound[11]=SaigaCockSound;
	stateAllowImageChange[11]=true;

	stateName[6]="Done";
	stateTransitionOnTimeout[6]="Ready";
	stateTimeoutValue[6]=0.1;
	stateAllowImageChange[6]=true;
	stateScript[6]="onReload";

	stateName[7]="Empty";
	stateTransitionOnTriggerDown[7]="EmptyFire";
	stateAllowImageChange[7]=true;
	stateTransitionOnAmmo[7]="Reload";
	stateName[8]="EmptyFire";
	stateTransitionOnTriggerUp[8]="Ready";
	stateTimeoutValue[8]="0.15";
	stateAllowImageChange[8]=false;
	stateWaitForTimeout[8]=true;
	stateSound[8]=SaigaClickSound;

	stateName[9]="ReadyWeap";
	stateSequence[9]="Ready";
	stateTimeoutValue[9]=0.95;
	stateSound[9]=SaigaDeploySound;
	stateTransitionOnTimeout[9]="Ready";

};
   
function SaigaImage::onAmmoCheck(%this,%obj,%slot)
{
	if(%obj.toolMag[%obj.currTool]<1)
	{	
		%obj.toolMag[%obj.currTool]=0;

	}
	if(%obj.toolMag[%obj.currTool]>%this.item.Saigamaxmag)
	
	{
		%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;
	
	}
	if(%obj.toolMag[%obj.currTool]<1)
	
	{

		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

}
}
function SaigaImage::onReload(%this,%obj,%slot)
	
{
	%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;%obj.setImageAmmo(0,1);

}
function SaigaImage::onFire1(%this,%obj,%slot)

	{
		%obj.toolMag[%obj.currTool]-=1;if(%obj.toolMag[%obj.currTool]<1)

	{
		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

	}
		SaigaFire(%this,%obj,%slot,0.0015,1,0.02);

}
function SaigaImage::onFire2(%this,%obj,%slot)
	{
		%obj.toolMag[%obj.currTool]-=1;

	if(%obj.toolMag[%obj.currTool]<1)
	{
		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

	}
		SaigaFire(%this,%obj,%slot,0.0030,1,0.04);
}
	function SaigaImage::onMount(%this,%obj,%slot)
	
{
	if(%obj.toolMag[%obj.currTool]$="")
	{

		%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;
}

		parent::onMount(%this,%obj,%slot);

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
}
function SaigaImage::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);
			%obj.unhideNode("ALL");

	if(isObject(%obj.client))
	{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();
	}
	else{applyDefaultCharacterPrefs(%obj);

	}

			%obj.client.setControlCameraFov(90);

}
function SaigaImageScoped::onAmmoCheck(%this,%obj,%slot)

{
	if(%obj.toolMag[%obj.currTool]<1)

	{
			%obj.toolMag[%obj.currTool]=0;

	}
	if(%obj.toolMag[%obj.currTool]>%this.item.Saigamaxmag)

	{
			%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;

	}
	if(%obj.toolMag[%obj.currTool]<1)

	{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

}
}
function SaigaImageScoped::onReload(%this,%obj,%slot)

		{
			%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;
			%obj.setImageAmmo(0,1);

}
	function SaigaImageScoped::onFire1(%this,%obj,%slot)

		{
			%obj.toolMag[%obj.currTool]-=1;
	
	if(%obj.toolMag[%obj.currTool]<1)
		
		{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

	}
		SaigaFire(%this,%obj,%slot,0.0015,1,0.02);

}
function SaigaImageScoped::onFire2(%this,%obj,%slot)

{
			%obj.toolMag[%obj.currTool]-=1;

	if(%obj.toolMag[%obj.currTool]<1)

		{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

	}
		SaigaFire(%this,%obj,%slot,0.0030,1,0.04);

}

function SaigaImageScoped::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);

			%obj.unhideNode("ALL");

	if(isObject(%obj.client))

		{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();

		}
			else{applyDefaultCharacterPrefs(%obj);

		}
			%obj.client.setControlCameraFov(90);

}
function SaigaProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)

{
	if(%col.getClassName()$="WheeledVehicle"||%col.getClassName()$="FlyingVehicle")serverPlay3D(SaigaMetalHitSound,%obj.getTransform());


			else{serverPlay3D(SaigaHitSound,%obj.getTransform());

	}
		parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);

}
function SaigaFire(%this,%obj,%slot,%spread,%shellcount,%recoil)


{
  %shellcount = 10;
  %spread =  0.005;
	if(%obj.isCrouched()==1){%spread=%spread-0.00001;
%recoil=%recoil/2;

}
	if(vectorLen(%obj.getVelocity()) >= 0.1 && !isObject(%obj.getObjectMount()))

		{
			%spread=0.01;
}%vector=%obj.getMuzzleVector(%slot);
%p=new Projectile()

{


dataBlock=SaigaRecoil;initialVelocity=%obj.getVelocity();

  
	initialPosition=%obj.getEyePoint();
	sourceObject=%obj;sourceSlot=%slot;client=%obj.client;};
	for(%shell=0;%shell<%shellcount;%shell++){

    %x=(getRandom()-0.5)*31.415926*%spread;
	%y=(getRandom()-0.5)*30.415926*%spread;
	%z=(getRandom()-0.5)*30.415926*%spread;
	%p=new Projectile(){dataBlock=SaigaProjectile;
	initialVelocity=MatrixMulVector(MatrixCreateFromEuler(%x@" "@%y@" "@%z),VectorScale(%obj.getMuzzleVector(%slot),SaigaProjectile.muzzleVelocity));
	initialPosition=%obj.getMuzzlePoint(%slot);
	sourceObject=%obj;sourceSlot=%slot;
	client=%obj.client;};
	MissionCleanup.add(%p);

}
	if(isObject(%obj.getObjectMount()))

	{
		return %p;}%a=%obj.getTransform();

			%rnd=getRandom(1);if(%rnd==1)

		{
			%recoil=%recoil*-1;

		}
			%obj.setTransform(getWord(%a,0)@" "@getWord(%a,1)@" "@getWord(%a,2)@" "@getWord(%a,3)@" "@getWord(%a,4)@" "@getWord(%a,5)@" "@getWord(%a,6)+%recoil);

	return %p;}package Saiga


{
function GameConnection::onDeath(%this,%killerPlayer,%killer,%damageType,%damageLoc)

{
		%this.player.client.setControlCameraFov(90);

		parent::onDeath(%this,%killerPlayer,%killer,%damageType,%damageLoc);

}
function Armor::onTrigger(%this,%player,%slot,%val){if(isObject(%player.getMountedImage(0)))

	{
		%item=%player.getMountedImage(0).getName();if((%item $= "SaigaImage" || %item $= "SaigaImageScoped") && %slot $= 4 && %val)

{
	if(%item$="SaigaImage"){%player.mountImage(SaigaImageScoped,0);

			%player.client.setControlCameraFov(80);
}
	if(%item$="SaigaImageScoped")

	{
		%player.mountImage(SaigaImage,0);

			%player.client.setControlCameraFov(90);

		}
		}
		else{parent::onTrigger(%this,%player,%slot,%val);

		}
		}
		else{parent::onTrigger(%this,%player,%slot,%val);

}
}
function Player::pickUp(%this,%item)

	{
			%data=%item.dataBlock;
			%mag=%item.mag;
			%status=parent::pickUp(%this,%item);

	if(!%status==1)

	{
		return %status;}
			%slot=-1;
	
	for(%i=0;%i<%this.dataBlock.maxTools;%i++)


	if(isObject(%this.tool[%i])&&%this.tool[%i].getID()==%data.getID()){%slot=%i;break;
}	

	if(%slot == -1)
	
{
		return %val;

}
	if(%mag $= "")

		{
			%this.toolMag[%slot]=%data.Saigamaxmag;

		}
			else%this.toolMag[%slot]=%mag;

}
function serverCmdDropTool(%client,%slot)

{
	if(!isObject(%client.player))

	{
		return parent::serverCmdDropTool(%client,%slot);

}
	$weaponMag=%client.player.toolMag[%client.player.currTool];

			%client.player.toolMag[%client.player.currTool]="";

		return parent::serverCmdDropTool(%client,%slot);

}
function ItemData::onAdd(%this,%obj){if($weaponMag!$="")

{
			%obj.mag=$weaponMag;$weaponMag="";

	}
		parent::onAdd(%this,%obj);

}
function serverCmdLight(%client)

	{
		%player=%client.player;

			%image=%player.getMountedImage(0);

	if(%image.item.Saigareload)

{
	if(%player.getImageState(0)$="Ready"||%player.getImageState(0)$="Empty")

{
	if(%player.toolMag[%player.currTool]<%image.item.Saigamaxmag)

{
		%player.setImageAmmo(0,0);

			%player.Schedule(50,setImageAmmo,0,1);

		}
			else{parent::serverCmdLight(%client);

	}
	}
		return;}parent::serverCmdLight(%client);

}
}
;activatePackage(Saiga);  

function SaigaImageScoped::onUnMount(%this,%obj,%slot)
{
	
		crossHair.setBitmap("base/client/ui/crosshair.png");
	
}
function SaigaImage::onUnMount(%this,%obj,%slot)
{
	
		crossHair.setBitmap("base/client/ui/crosshair.png");
}

function SaigaImageScoped::onMount(%this,%obj,%slot)
{
    if(%obj.toolMag[%obj.currTool]$="")
{
			%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;
}

	
		crossHair.setBitmap("add-ons/weapon_BFShotguns/empty.png");
	
    
                parent::onMount(%this,%obj,%slot);
		    	
			    %obj.hideNode("LHand");
			    %obj.hideNode("RHand");
			    %obj.hideNode("LHook");
			    %obj.hideNode("RHook");

}

function SaigaImage::onMount(%this,%obj,%slot)
{
    if(%obj.toolMag[%obj.currTool]$="")
{
			%obj.toolMag[%obj.currTool]=%this.item.Saigamaxmag;
}

	
		crossHair.setBitmap("base/client/ui/crosshair.png");
	
    
                parent::onMount(%this,%obj,%slot);
		    	
			    %obj.hideNode("LHand");
			    %obj.hideNode("RHand");
			    %obj.hideNode("LHook");
			    %obj.hideNode("RHook");

}

