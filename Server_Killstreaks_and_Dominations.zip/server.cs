//---------------------------------------------------------------
//	 _  ___ _ _  _____ _                  _        	
//	| |/ (_) | |/ ____| |                | |       	
//	| ' / _| | | (___ | |_ _ __ ___  __ _| | _____ 	
//	|  < | | | |\___ \| __| '__/ _ \/ _` | |/ / __|
//	| . \| | | |____) | |_| | |  __/ (_| |   <\__ \	
//	|_|\_\_|_|_|_____/ \__|_|  \___|\__,_|_|\_\___/	
//---------------------------------------------------------------
// Title: Killstreaks and Dominations
// Author: Swollow (6531)
// Thanks Arekan for ripping sounds
//---I'm BACK BITCH
// Version: 5
//---------------------------------------------------------------
// Commented for your convenience but you probably shouldn't
// actually use any of my bad code as an example, PROCEED AT RISK
//---------------------------------------------------------------
//---Change log
// v3.0.1 -- > v4
// -I rewrote everything from scratch, different mod same concept
// v4 -- > v5
// -Added sounds
// -Fixed a glitch
//---------------------------------------------------------------
$Swol_KillstreakMsg[0] 	= "Killing Spree";
$Swol_KillstreakMsg[1] 	= "Killing Streak";
$Swol_KillstreakMsg[2] 	= "Killing Frenzy";
$Swol_KillstreakMsg[3]	= "Rampage";
$Swol_KillstreakMsg[4] 	= "Massacre";
$Swol_KillstreakMsg[5] 	= "Slaughter";
$Swol_KillstreakMsg[6] 	= "Carnage";
$Swol_KillstreakMsg[7] 	= "Homicide";
$Swol_KillstreakMsg[8] 	= "Annihilation";
$Swol_KillstreakMsg[9] 	= "War Crime";
$Swol_KillstreakMsg[10] = "Godly";
$Swol_KillStreakMsgC 	= 10;

$Swol_KillstreakOvr[0]	= "Impervious";
$Swol_KillstreakOvr[1]	= "Overkill";
$Swol_KillstreakOvr[2]	= "Divine";
$Swol_KillstreakOvr[3]	= "Untouchable";
$Swol_KillstreakOvr[4]	= "Invincible";
$Swol_KillstreakOvr[5]	= "Reaper";
$Swol_KillstreakOvr[6]	= "Killtrocity";
$Swol_KillstreakOvrC 	= 6;

$Swol_KillstreakMul[0] 	= "Double-Kill";
$Swol_KillstreakMul[1] 	= "Triple-Kill";
$Swol_KillstreakMul[2] 	= "Multi-Kill";
$Swol_KillstreakMul[3] 	= "Ulta-Kill";
$Swol_KillstreakMul[4] 	= "Monster-Kill";
$Swol_KillStreakMulC 	= 4;

//---Multi Kill Window
$Swol_KillStreakMulW = 2000;
//----Multi Kill Bonus Points (killing a player*0.5)
$Swol_KillstreakModMultiKillRatio = 0.5;
//----Killstreak Bonus Points (killing a player*0.25)
$Swol_KillstreakModStreakKillRatio = 0.25;
//----Bonus Points Cap (8 times killing a player)
$Swol_KillstreakModPointCapRatio = 8;
//----Bonus Points Cap when dead
$Swol_KillstreakModDeadPointCapRatio = 2;
//----Attempt to block other center print messages from overlapping the ks center prints
$Swol_KillstreakBlockOtherCenterPrint = true;
//----Self Explanatory
$Swol_KillstreakShowChatMsgs = true;
//----Self Explanatory
$Swol_KillstreakShowCenterMsgs = true;
//----Self Explanatory
$Swol_KillstreakShowDominations = true;
//----Amount of consecutive kills on a player it takes to be 'dominating' them
$Swol_KillstreakDominationCount = 3;

$Swol_KillstreakCurGameKills = 0;
$Swol_KillstreakLastSave = 0;

//--------------------------------------------------------------
// Sounds
//--------------------------------------------------------------
datablock AudioProfile(swol_ksTickSound)
{
   filename    = "./sounds/ks_score_tick.wav";
   description = Audio2D;
   preload = true;
};
datablock AudioProfile(swol_ksWoosh1Sound : swol_ksTickSound)
{
   filename    = "./sounds/ks_woosh_1.wav";
};
datablock AudioProfile(swol_ksWoosh2Sound : swol_ksTickSound)
{
   filename    = "./sounds/ks_woosh_2.wav";
};
datablock AudioProfile(swol_ksWoosh3Sound : swol_ksTickSound)
{
   filename    = "./sounds/ks_woosh_3.wav";
};
datablock AudioProfile(swol_ksDominatedSound : swol_ksTickSound)
{
   filename    = "./sounds/ks_dominated.wav";
};
datablock AudioProfile(swol_ksDominatingSound : swol_ksTickSound)
{
   filename    = "./sounds/ks_dominating.wav";
};
datablock AudioProfile(swol_ksRevengeSound : swol_ksTickSound)
{
   filename    = "./sounds/ks_revenge.wav";
};
datablock AudioProfile(swol_ksRevengeDSound : swol_ksTickSound)
{
   filename    = "./sounds/ks_revenged.wav";
};
package swol_ks
{
//--------------------------------------------------------------
// onDeath
//--------------------------------------------------------------
	function gameConnection::onDeath(%killed, %killerPlayer, %killer, %a, %b)
	{
		parent::onDeath(%killed, %killerPlayer, %killer, %a, %b);
		if(isObject(%killed.minigame))
		{
			%killed.swol_resetKills();
		//---Ya.
			if(%killed == %killer || (!isObject(%killer.player) && !isObject(%killed.player)))
			return;
		//---Where all my code starts
			%killer.swol_addKill(%killed);
			
		//---Saving global kills
			$Swol_KillstreakAllTimeKills++;
			$Swol_KillstreakCurGameKills++; 
			if($Swol_KillstreakCurGameKills%50 == 0)
			{
				if(getSimTime()-$Swol_KillstreakLastSave < 10000)
				return;
				swol_killstreakSave();
			}
		}
	}
//--------------------------------------------------------------
// Minigame support function for potential additions
//--------------------------------------------------------------
	function gameConnection::swol_getMinigameData(%this,%data)
	{
		%killPlayer = 100;
		if(isObject((%mini = %this.minigame)))
		%killPlayer = %mini.points_killPlayer;
		switch$(%data)
		{
			case "kill":
			return %killPlayer;
			default:
			return 0;
		}
	}
//--------------------------------------------------------------
// Reset Kills on death
//--------------------------------------------------------------
    function gameConnection::swol_resetKills(%this)
	{
	//---Check killstreak record
		if(%this.swol_kills > $Swol_KillstreakRecord)
		swol_killstreakRecordBreak(%this);
	//---Set everything to 0
    	cancel(%this.swol_ksDrawSched);
		%this.swol_kills = 0;
		%this.swol_mKill = 0;
        %this.swol_lastKill = getSimTime()-$Swol_KillStreakMulW;
	}
//--------------------------------------------------------------
// Add Kills, handle dominations, and calculate bonus points
//--------------------------------------------------------------
	function gameConnection::swol_domination(%this,%killer,%killed,%mode)
	{
		switch$(%mode)
		{
			case "dominating":
			%this.play2D(swol_ksDominatingSound);
			%this.swol_drawAccMsg("Dominating",%killed,0,swol_generateAccMsgVars(),-666);
			case "dominated":
			messageClient(%this,'',"<bitmap:base/client/ui/ci/skull> \c6" @ %killer @ "<color:ffd700> is dominating you");
			%this.play2D(swol_ksDominatedSound);
			case "revenge":
			%this.play2D(swol_ksRevengeSound);
			%this.swol_drawAccMsg("Revenge",%killed,0,swol_generateAccMsgVars(),-666);
			case "revenged":
			messageClient(%this,'',"<bitmap:base/client/ui/ci/skull> \c6" @ %killer @ "<color:ffd700> claimed revenge on you");
			%this.play2D(swol_ksRevengedSound);
		}
	}
	function gameConnection::swol_addKill(%this,%killed)
	{
		if(%killed !$= "")
		%this.swol_domination[%killed]++;
		%noMsg = false;
	//----Domination
		if(%this.swol_domination[%killed] == $Swol_KillstreakDominationCount)
		{
			if($Swol_KillstreakShowDominations)
			{
				%this.swol_domination(%this.getPlayerName(),%killed.getPlayerName(),"dominating");
				%killed.swol_domination(%this.getPlayerName(),%killed.getPlayerName(),"dominated");
			}
			%noMsg = true;
		}
	//----Revenge
		if(%killed.swol_domination[%this] >= $Swol_KillstreakDominationCount)
		{
			if($Swol_KillstreakShowDominations)
			{
				%this.swol_domination(%this.getPlayerName(),%killed.getPlayerName(),"revenge");
				%killed.swol_domination(%this.getPlayerName(),%killed.getPlayerName(),"revenged");
			}
			%noMsg = true;
		}
		%killed.swol_domination[%this] = 0;
	//----Multi kill check	
		if(getSimTime()-%this.swol_lastKill < $Swol_KillStreakMulW)
		%this.swol_mKill++;
		else
		%this.swol_mKill = 0;
		%this.swol_lastKill = getSimTime();
	//----Add to killstreak
		if((%alive = isObject(%this.player)))
		%this.swol_kills++;
	//----Base points for killing someone in or out of minigame	
		%base = %this.swol_getMinigameData("kill");
	//----Calculate bonus points for consecutive killstreaks and multi kills
		%bonus = ((%base*$Swol_KillstreakModStreakKillRatio)*(%this.swol_kills-1))+(%this.swol_mKill*(%base*$Swol_KillstreakModMultiKillRatio));
        %points = %base+%bonus;
	//----Cap the points
		%cap = (%alive ? %base*$Swol_KillstreakModPointCapRatio : %base*$Swol_KillstreakModDeadPointCapRatio);
		%points = mClampF(%points,0,%cap);
		%bonus = %points-%base;
	//----Hopefully the base score should be added by the minigame	
		%this.incScore(%bonus);
		if(!%noMsg)
		%this.swol_displayKillStreak(%this.swol_kills,%this.swol_mKill,%points);
		else
		%this.schedule(750,swol_displayKillStreak,%this.swol_kills,%this.swol_mKill,%points);
	}
//--------------------------------------------------------------
// Potential function for cool capture point messages
//--------------------------------------------------------------
    function gameConnection::swol_displayCapPoint(%this)
    {
    	%this.swol_drawAccMsg("Point Captured","",200,swol_generateAccMsgVars(),-1337);
    }
//--------------------------------------------------------------
// Figure out killstreak titles and multi kill messages
//--------------------------------------------------------------
	function gameConnection::swol_displayKillstreak(%this,%kills,%multiKills,%points)
	{
	//----Base kills for the killstreak messages which actually start at 3 kills
		%killT = %kills-3;
	//----If we have surpassed the first 11 killstreak messages
		if(%killT > $Swol_KillStreakMsgC)
		{
		//----Choose a random one
			%rand = getRandom(0,6);
		//----If we just had that message a second ago
			if(%this.lastOverKillMsg == %rand)
			{
				%rand2 = getRandom(0,5);
                %rand += %rand2;
				if(%rand > (%c = $Swol_KillStreakOvrC))
				%rand = %c%%rand2;
			}
			%this.lastOverKillMsg = %rand;
			%ksmsg = $Swol_KillstreakOvr[%rand];
		}
	//----Simple kill message before we are on a killstreak
		else if(%killT < 0)
		%ksmsg = "Kill";
		else
	//----Killstreak message
		%ksmsg = $Swol_KillstreakMsg[%killT];
	//----Keep our multikills within the bounds of the ones we have set
		%multiKills = mClampF(%multiKills,0,$Swol_KillStreakMulC+1);
		
	//----After life kills that probably overlap the respawn messages
		if(!isObject(%this.player))
		%ksmsg = "Afterlife";
		
		if(%multiKills != 0)
		%mkmsg = $Swol_KillstreakMul[%multiKills-1];
		else
		%mkmsg = "";
	//----Chat messages (they clog the chat but make you look cool)	
		if(%killT >= 0 && $Swol_KillstreakShowChatMsgs)
		{
			cancel(%this.swol_showksmsgSched);
		//---send the message delayed so that there isn't too much ks spam
			%this.swol_showksmsgSched = %this.schedule(350,swol_killstreakMsgCheck,%ksmsg,%kills,%multiKills,%mkmsg);
		}
		if($Swol_KillstreakShowCenterMsgs)
		%this.swol_drawAccMsg(%ksmsg,%mkmsg,%points,swol_generateAccMsgVars(),(%killT < 0 ? -666 : %kills));
		
	}
//--------------------------------------------------------------
// Killstreak chat messages
//--------------------------------------------------------------
	function gameConnection::swol_killstreakMsgCheck(%this,%ksmsg,%kills,%multiKills,%mkmsg)
	{
		cancel(%this.swol_showksmsgSched);
		swol_killstreakMinigameMsg(%this,"<bitmap:base/client/ui/ci/star> \c0[\c6" @ %this.getPlayerName() @ "\c0] <color:ffd700>" @ %ksmsg @ " <color:ff2200>[" @ %kills @ " Kills]" @ (%multiKills != 0 ? " \c0(" @ %mkmsg @ ")" : ""));
	}
//--------------------------------------------------------------
// Animated center print effects (80% of the work for this mod)
//--------------------------------------------------------------
	function gameConnection::swol_drawAccMsg(%this,%msg,%multi,%points,%vars,%kills,%barsD)
	{
		cancel(%this.swol_ksDrawSched);
	//---Just don't fuck with these numbers everything might unravel into a black hole
        %rate = 30;
        %max = 750;
	//---On complete
		if(%vars.steps > %max/%rate)
		{
			%this.swolKsMsg = false;
			return;
		}
	//----Attempt to prevent the messages from being overlapped
		%this.swolKsMsg = true;
	//---Check if we have a multi kill message
		if(%multi $= "")
		%mkMsg = false; 
		else 
		%mkMsg = true;
	//---Figure out what stage we are at
		%phase = 1;
		if(%vars.steps > (mFloor(%max/2.5)/%rate) && %vars.steps < (mFloor(%max/1.6666)/%rate))
		%phase = 0;
		else if(%vars.steps >= (mFloor(%max/1.6666)/%rate))
		%phase = 2;
    //----This is set for special kinds of messages that aren't really used in the mod (yet!)
        if(%kills == -1337)
        %mode = 2;
        else if(%kills == -666)
        %mode = 3;
		else
		%mode = 1;
	//----Sounds
		if(%vars.steps == 0 && (%kills != -666 || %msg $= "kill" || %msg $= "afterlife"))
		{
			%rand = getRandom(1,3);
			%this.play2D("swol_ksWoosh" @ %rand @ "Sound");
		}
		if(%vars.steps == mFloor(mFloor(%max/1.6666)/%rate) && mFloor(%points) != 0)
		%this.play2D(swol_ksTickSound);
	//----Make colors pretty
		%tmpStp = %vars.steps+(%max/%rate)*0.36;
		if(%tmpStp > 15) %tmpStp = 15;
		%hexPiece = getHexChar(%tmpStp);
        if(%mode == 1 || %mode == 3)
		%vars.col = %hexPiece @ %hexPiece @ "2200";
        else
        %vars.col = "22" @ %hexPiece @ %hexPiece @ "00";
		
		%vars.col_2 = "ffdd00";
	//----Lay out color, fonts, and sizes of text
		%style_size = "<font:impact:" @ %vars.size @ ">";
		%style = %style_size @ "<color:" @ %vars.col @ ">";
		%small_style = "<font:impact:" @ %vars.size*0.6 @ ">" @ "<color:" @ %vars.col @ ">";
		%bar_size = "<font:impact:" @ (36/((10-%var.steps)/10)) @ ">";
		%bar_style = %bar_size @ "\c7";
		%points_style = "<font:impact:" @ %vars.size*0.7 @ ">" @ "<color:" @ %vars.col_2 @ ">";
	//----Reverse the text grow direction
		if(%vars.steps == (mFloor(%max/5)/%rate))
		%vars.size_dir = false;
		
	//----Grow/Shrink animation	and bonus point animation
		if(%phase == 1)
		{
			if(%vars.size_dir)
			%vars.size += %rate/6;
			else
			%vars.size -= %rate/15;
		}
		else if(%phase == 2)
		%points_s = "+" @ mFloor(%points-((%points/10)*(25-(%vars.steps))));
		
	//----Add and draw bars onto either end	
		if(!%vars.size_dir && %phase < 2)
		%vars.bars++;
		%bars_l = "";
		%bars_r = "";
		if(!%barsD)
		{
			for(%i=0;%i<%vars.bars;%i++)
			%bars_l = %bars_l @ "-";
			
			for(%i=0;%i<%vars.bars;%i++)
			%bars_r = %bars_r @ "-";
		}
	//----This is for those other special messages that we don't really use in the mod
		if(%mode == 1)
		%killMsg = "<br>" @ %small_style @ %kills @ " kills" @ (%mkmsg ? " \c0[" @ %multi @ "]" : "");
		else if(%mode == 3 && %mkmsg)
		%killMsg = "<br>" @ %small_style @ %multi;
		else
		%killMsg = "";
		
	//----Draw the center print and attempt to prevent it from being overlapped
		%this.swolKsMsg = false;
		%this.centerPrint("<br><br><br><br><br>" @ %bar_style @ %bars_l SPC %style @ %msg @ %bar_style SPC %bars_r @
        %killMsg @ ((%phase >= 2 && mFloor(%points) > 0) ? "<br>" @ %points_style @ %points_s : ""),4);
		%this.swolKsMsg = true;
		
		%vars.steps++;
		%this.swol_ksDrawSched = %this.schedule(%rate,swol_drawAccMsg,%msg,%multi,%points,%vars,%kills,%barsD);
	}
//--------------------------------------------------------------
// Send a message to everyone in minigame 
// (created my own function in case I wanted to add something else to it like sounds)
//--------------------------------------------------------------
	function swol_killstreakMinigameMsg(%cl,%msg)
	{
		if(!isObject(%mini = %cl.minigame))
		return;
		for(%i=0;%i<%mini.numMembers;%i++)
		{
			%member = %mini.member[%i];
			messageClient(%member,'',%msg);
		}
	}
//--------------------------------------------------------------
// Saving/Loading killstreak record and global server kill count
//--------------------------------------------------------------
	function swol_killstreakSave()
	{
	//----Instead of using $Pref:: I'm super fucking cool and made my own save system
		$Swol_KillstreakLastSave = getSimTime();
		%f = new fileObject();
		%f.openForWrite("config/server/skillstreak.cs");
   
		%f.writeLine($Swol_KillstreakAllTimeKills);
		%f.writeLine($Swol_KillstreakRecord);
		%f.writeLine($Swol_KillstreakRecName);
		%f.writeLine($Swol_KillstreakRecBlid);

		%f.close();
		%f.delete();
	}
	function swol_killstreakLoad()
	{
		if(isFile("config/server/skillstreak.cs"))
		{
			%f = new fileObject();
			%f.openForRead("config/server/skillstreak.cs");
	   
			$Swol_KillstreakAllTimeKills = %f.readLine();
			$Swol_KillstreakRecord = %f.readLine();
			$Swol_KillstreakRecName = %f.readLine();
			$Swol_KillstreakRecBlid = %f.readLine();

			%f.close();
			%f.delete();
		}
	//---File appears not to exist, create it
		if($Swol_KillstreakAllTimeKills $= "" || $Swol_KillstreakRecBlid $= "")
		{
			$Swol_KillstreakAllTimeKills = 0;
			$Swol_KillstreakRecord = 0;
			$Swol_KillstreakRecName = "";
			$Swol_KillstreakRecBlid = -1;
			swol_killstreakSave();
		}
	}
//--------------------------------------------------------------
// Called when the killstreak record is broken (duh)
//--------------------------------------------------------------
	function swol_killstreakRecordBreak(%cl)
	{
		%kills = %cl.swol_kills;
		if(%kills > $Swol_KillstreakRecord)
		{
			%previd = $Swol_KillstreakRecBlid;
			%prevname = $Swol_KillstreakRecName;
		//----Figure out who actually held the record before bushido beats it
			if(%previd == %cl.bl_id)
			%prevMsg = " (held by themselves)";
			else if(%prevname $= "")
			%prevMsg = "";
			else
			%prevMsg = " (held by \c0" @ %prevname @ "<color:ffa400>)";
			
			%killDif = %kills-$Swol_KillstreakRecord;
		//---Select a random word for our message to add some uniqueness
			%word[0] = "beaten";%word[1] = "broken";%word[2] = "defeated";%word[3] = "destroyed";%word[4] = "demolished";%word[5] = "eliminated";
			%rand = getRandom(0,2);
		//---If we beat the record by atleast 8 kills we'll use a more dramatic word
			if(%killDif >= 8)
			%rand += 3;
			%word = %word[%rand];
			messageAll('',"<bitmap:base/client/ui/ci/star><font:a:7> <font:impact:28><color:ffa400>" @ %cl.getPlayerName() @ "<color:ffd700> has " @ %word @ " the previous killstreak record of <color:ffa400>" @ $Swol_KillstreakRecord @ %prevMsg @ "<color:ffd700> by <color:ffa400>" @ %killDif @ "<color:ffd700> kill" @ (%killDif == 1 ? "" : "s"));
		//---Rape everyone in the ears with an alert
			serverPlay2D(rewardSound);
			$Swol_KillstreakRecBlid = %cl.bl_id;
			$Swol_KillstreakRecName = %cl.getPlayerName();
			$Swol_KillstreakRecord = %kills;
			swol_killstreakSave();
		}
	}
//--------------------------------------------------------------
// Prevent Overlapping
//--------------------------------------------------------------
//Note: if your code uses commandToClient('centerprint') instead of center print then FUCK YOU, YOU ARROGANT CUNT
//--------------------------------------------------------------
	function gameConnection::centerPrint(%this,%a,%b,%c)
	{
		if(%this.swolKsMsg && $Swol_KillstreakBlockOtherCenterPrint)
		return;
		return parent::centerPrint(%this,%a,%b,%c);
	}
//idk if this is the right stuff for shutting down a server, either way the only thing we might not have fully accurate is the global amount of kills on the sever
	function disconnect(%a)
	{
		swol_killstreakSave();
		return parent::disconnect(%a);
	}
//--------------------------------------------------------------
// Support Functions
//--------------------------------------------------------------
	function swol_generateAccMsgVars()
	{
		return new simSet() 
		{ 
			col = "";
			col_2 = "";
			size = 24;
			size_dir = true;
			step = 0;
			bars = 2;
		};
	}
	function getHexChar(%num) //I love you port
	{
		return getSubStr("0123456789ABCDEF", %num, 1);
	}
};
ActivatePackage(swol_ks);
swol_killstreakLoad();