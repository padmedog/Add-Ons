datablock ParticleData(CandleParticle)
{
	textureName          = "base/data/particles/cloud";
	dragCoefficient      = 1.0;
	gravityCoefficient   = -7.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "0.0 0.0 0.0 0.0";
	colors[1]	= "1   1   0.3 0.0";
	colors[2]	= "1   1   0.3 1.0";
	colors[3]	= "0.6 0.0 0.0 0.0";

	sizes[0]	= 0.0;
	sizes[1]	= 0.0;
	sizes[2]	= 0.09;
	sizes[3]	= 0.01;

	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 0.51;
	times[3]	= 0.7;
};

datablock ParticleEmitterData(CandleEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = CandleParticle;   

	uiName = "Candle";
};

