package KDR
{
	function GameConnection::autoAdminCheck(%client)
	{
		%client.oldSuffix = %client.clanSuffix;
		return Parent::autoAdminCheck(%client);
	}
	function GameConnection::onClientEnterGame(%client)
	{
		Parent::onClientEnterGame(%client);

		%client.kdr = "1.00";

		%fw = new FileObject();
		%fw.openForRead("config/server/KDR/" @ %client.BL_ID @ ".txt");
		%name = %fw.readLine();
		%client.kills = %fw.readLine();
		%client.deaths = %fw.readLine();
		%fw.close();
		%fw.delete();

		%ck = $Pref::KDR::Save ? %client.kills : %client.kills2;
		%cd = $Pref::KDR::Save ? %client.deaths : %client.deaths2;

		if(!%ck) %ck++;
		if(!%cd) %cd++;

		%client.kdr = mFloatLength(%ck/%cd,2);

		%pre = "<color:666666>[<color:00FFFF>";
		%suf = "<color:666666>]<color:FFFFFF>";

		if($Pref::KDR::Enabled)
			%client.clansuffix = trim(%pre @ %client.kdr @ %suf);
		else
			%client.clansuffix = trim(%pre @ %client.oldSuffix @ %suf);
	}

	function GameConnection::onClientLeaveGame(%client)
	{
		%fw = new FileObject();
		%fw.openForWrite("config/server/KDR/" @ %client.BL_ID @ ".txt");
		%fw.writeLine(%client.getPlayerName());
		%fw.writeLine(%client.kills);
		%fw.writeLine(%client.deaths);
		%fw.close();
		%fw.delete();

		Parent::onClientLeaveGame(%client);
	}

	function GameConnection::onDeath(%client, %killerPlayer, %killer, %damageType, %damageLoc)
	{
		parent::onDeath(%client, %killerPlayer, %killer, %damageType, %damageLoc);

		%victim = %client;

		if(%victim != %killer)
		{
			%killer.kills++;
			%killer.kills2++;
		}

		%victim.deaths++;
		%victim.deaths2++;

		%kk = $Pref::KDR::Save ? %killer.kills : %killer.kills2;
		%kd = $Pref::KDR::Save ? %killer.deaths : %killer.deaths2;
		%vk = $Pref::KDR::Save ? %victim.kills : %victim.kills2;
		%vd = $Pref::KDR::Save ? %victim.deaths : %victim.deaths2;

		if(!%kk) %kk++;
		if(!%kd) %kd++;
		if(!%vk) %vk++;
		if(!%vd) %vd++;

		%killer.kdr = mFloatLength(%kk/%kd,2);
		%victim.kdr = mFloatLength(%vk/%vd,2);

		%pre = "<color:666666>[<color:00FFFF>";
		%suf = "<color:666666>]<color:FFFFFF>";

		if($Pref::KDR::Enabled)
		{
			%killer.clansuffix = trim(%pre @ %killer.kdr @ %suf);
			%victim.clansuffix = trim(%pre @ %victim.kdr @ %suf);
		}
		else
		{
			%killer.clansuffix = trim(%pre @ %killer.oldSuffix @ %suf);
			%victim.clansuffix = trim(%pre @ %victim.oldSuffix @ %suf);
		}
	}
};
activatePackage(KDR);