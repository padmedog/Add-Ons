//Code made by Bauklotz (2107) and McTwist (9845) with Demian (10334) poking around (Snooping around as an apprentice of the Senseis, doing some commenting and RTB prefs.)

function healthKitPickup(%this, %obj, %col, %respawn)
{
	if(%obj.respawning || (%dmg = %col.getDamageLevel()) <= 0)
		return;
	%health = ($Pref::TF2S::Percentage) ? %col.getDataBlock().maxDamage * %this.healScale : %this.healScale;
	%col.addHealth(%health);
	%obj.fadeOut();
	%obj.respawning = true;
	%obj.schedule(%respawn, fadeInSchedule);
}

function Item::spinTF2S(%obj)
{
	%obj.rotate = $Pref::TF2S::Spin; //Enable/Disable spinning.
}

//Spin speed and rotation is built in an cannot be changed.
function Item::fadeInSchedule(%obj)
{
	%obj.respawning = false;
	%obj.fadeIn();
}

function healthKitSmallItem::onAdd(%this, %obj)
{
	%obj.spinTF2S();
}
function healthKitMediumItem::onAdd(%this, %obj)
{
	%obj.spinTF2S();
}
function healthKitLargeItem::onAdd(%this, %obj)
{
	%obj.spinTF2S();
}
function healthKitSmallItem::onPickup(%this, %obj, %col)
{ 
	healthKitPickup(%this, %obj, %col, $Pref::TF2S::RespawnSmall);
}
function healthKitMediumItem::onPickup(%this, %obj, %col)
{
	healthKitPickup(%this, %obj, %col, $Pref::TF2S::RespawnMedium);
}
function healthKitLargeItem::onPickup(%this, %obj, %col)
{
	healthKitPickup(%this, %obj, %col, $Pref::TF2S::RespawnLarge);
}

datablock itemData(healthKitSmallItem : printGun)
{
	image = "";
	uiName = "Health Kit, Small";
	healScale = ($Pref::TF2S::Percentage) ? $Pref::TF2S::HealSmall / 100 : $Pref::TF2S::HealSmall ;
	shapeFile = "./Healthkit_Small.dts";
};
datablock itemData(healthKitMediumItem : printGun)
{
	image = "";
	uiName = "Health Kit, Medium";
	healScale = ($Pref::TF2S::Percentage) ? $Pref::TF2S::HealMedium / 100 : $Pref::TF2S::HealMedium;
	shapeFile = "./Healthkit_Medium.dts";
};
datablock itemData(healthKitLargeItem : printGun)
{
	image = "";
	uiName = "Health Kit, Large";
	healScale = ($Pref::TF2S::Percentage) ? $Pref::TF2S::HealLarge / 100 : $Pref::TF2S::HealLarge;
	shapeFile = "./Healthkit_Large.dts";
};