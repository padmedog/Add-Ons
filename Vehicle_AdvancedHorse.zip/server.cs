//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// Load dts shapes and merge animations
datablock TSShapeConstructor(AdvancedAdvancedHorseDts)
{
	baseShape  = "./advancedhorse.dts";
	sequence0  = "./ah_root.dsq root";

	sequence1  = "./ah_run.dsq run";
	sequence2  = "./ah_run.dsq walk";
	sequence3  = "./ah_back.dsq back";
	sequence4  = "./ah_side.dsq side";

	sequence5  = "./ah_root.dsq crouch";
	sequence6  = "./ah_run.dsq crouchRun";
	sequence7  = "./ah_back.dsq crouchBack";
	sequence8  = "./ah_side.dsq crouchSide";

	sequence9  = "./ah_look.dsq look";
	sequence10 = "./ah_root.dsq headside";
	sequence11 = "./ah_root.dsq headUp";

	sequence12 = "./ah_jump.dsq jump";
	sequence13 = "./ah_jump.dsq standjump";
	sequence14 = "./ah_root.dsq fall";
	sequence15 = "./ah_root.dsq land";

	sequence16 = "./ah_root.dsq armAttack";
	sequence17 = "./ah_root.dsq armReadyLeft";
	sequence18 = "./ah_root.dsq armReadyRight";
	sequence19 = "./ah_root.dsq armReadyBoth";
	sequence20 = "./ah_root.dsq spearready";  
	sequence21 = "./ah_root.dsq spearThrow";

	sequence22 = "./ah_root.dsq talk";  

	sequence23 = "./ah_death.dsq death1"; 
	
	sequence24 = "./ah_root.dsq shiftUp";
	sequence25 = "./ah_root.dsq shiftDown";
	sequence26 = "./ah_root.dsq shiftAway";
	sequence27 = "./ah_root.dsq shiftTo";
	sequence28 = "./ah_root.dsq shiftLeft";
	sequence29 = "./ah_root.dsq shiftRight";
	sequence30 = "./ah_root.dsq rotCW";
	sequence31 = "./ah_root.dsq rotCCW";

	sequence32 = "./ah_root.dsq undo";
	sequence33 = "./ah_root.dsq plant";

	sequence34 = "./ah_root.dsq sit";

	sequence35 = "./ah_root.dsq wrench";

   sequence36 = "./ah_root.dsq activate";
   sequence37 = "./ah_root.dsq activate2";

   sequence38 = "./ah_root.dsq leftrecoil";
};    

datablock DebrisData(AdvancedHorseDebris )
{
   explodeOnMaxBounce = false;

   elasticity = 0.15;
   friction = 0.5;

   lifetime = 4.0;
   lifetimeVariance = 0.0;

   minSpinSpeed = 40;
   maxSpinSpeed = 600;

   numBounces = 5;
   bounceVariance = 0;

   staticOnMaxBounce = true;
   gravModifier = 1.0;

   useRadiusMass = true;
   baseRadius = 1;

   velocity = 20.0;
   velocityVariance = 12.0;
};             

datablock PlayerData(AdvancedHorseArmor)
{
   renderFirstPerson = false;
   emap = false;
   
   className = Armor;
   shapeFile = "./advancedhorse.dts";
   cameraMaxDist = 8;
   cameraTilt = 0.261;//0.174 * 2.5; //~25 degrees
   cameraVerticalOffset = 2.3;
   computeCRC = false;
  
   canObserve = true;
   cmdCategory = "Clients";

   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;
   
   //debrisShapeName = "~/data/shapes/player/debris_player.dts";
   //debris = AdvancedHorseDebris;

   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 1.5708;
   maxFreelookAngle = 3.0;

   mass = 90;
   drag = 0.1;
   maxdrag = 0.52;
   density = 0.7;
   maxDamage = 250;
   maxEnergy =  10;
   repairRate = 0.33;
   energyPerDamagePoint = 75.0;

   rechargeRate = 0.4;

   runForce = 28 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 18;
   maxBackwardSpeed = 6;
   maxSideSpeed = 1;

   maxForwardCrouchSpeed = 18;
   maxBackwardCrouchSpeed = 6;
   maxSideCrouchSpeed = 1;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 0;
   maxBackwardWalkSpeed = 0;
   maxSideWalkSpeed = 0;

   maxUnderwaterForwardSpeed = 8.4;
   maxUnderwaterBackwardSpeed = 7.8;
   maxUnderwaterSideSpeed = 7.8;

   jumpForce = 15 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

   minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

   recoverDelay = 0;
   recoverRunForceScale = 1.2;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("2.5 1.5 2.4", 4); //"2.5 2.5 2.4";
   crouchBoundingBox	= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";
   proneBoundingBox		= vectorScale("2.5 2.5 2.4", 4); //"2.5 2.5 2.4";

   pickupRadius = 0.75;
   
   // Damage location details
   boxNormalHeadPercentage       = 0.83;
   boxNormalTorsoPercentage      = 0.49;
   boxHeadLeftPercentage         = 0;
   boxHeadRightPercentage        = 1;
   boxHeadBackPercentage         = 0;
   boxHeadFrontPercentage        = 1;

   // Foot Prints
   //decalData   = AdvancedHorseFootprint;
   //decalOffset = 0.25;
	
   jetEmitter = "";
   jetGroundEmitter = "";
   jetGroundDistance = 4;
  
   //footPuffEmitter = LightPuffEmitter;
   footPuffNumParts = 10;
   footPuffRadius = 0.25;

   //dustEmitter = LiftoffDustEmitter;

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 85;
   jumpSurfaceAngle = 86;

   minJumpSpeed = 20;
   maxJumpSpeed = 30;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;
   
   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   JumpSound			= HorseJumpSound;

   // Footstep Sounds
//   FootSoftSound        = AdvancedHorseFootFallSound;
//   FootHardSound        = AdvancedHorseFootFallSound;
//   FootMetalSound       = AdvancedHorseFootFallSound;
//   FootSnowSound        = AdvancedHorseFootFallSound;
//   FootShallowSound     = AdvancedHorseFootFallSound;
//   FootWadingSound      = AdvancedHorseFootFallSound;
//   FootUnderwaterSound  = AdvancedHorseFootFallSound;
   //FootBubblesSound     = FootLightBubblesSound;
   //movingBubblesSound   = ArmorMoveBubblesSound;
   //waterBreathSound     = WaterBreathMaleSound;

   //impactSoftSound      = ImpactLightSoftSound;
   //impactHardSound      = ImpactLightHardSound;
   //impactMetalSound     = ImpactLightMetalSound;
   //impactSnowSound      = ImpactLightSnowSound;
   
   impactWaterEasy      = Splash1Sound;
   impactWaterMedium    = Splash1Sound;
   impactWaterHard      = Splash1Sound;
   
   groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;
   
   observeParameters = "0.5 4.5 4.5";

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "Advanced Horse";
	rideable = true;
		lookUpLimit = 0.6;
		lookDownLimit = 0.2;

	canRide = false;
	showEnergyBar = false;
	paintable = true;

	brickImage = AdvancedHorseBrickImage;	//the imageData to use for brick deployment

   numMountPoints = 1;
   mountThread[0] = "root";
   mountNode[0] = 2;
};


function AdvancedHorseArmor::onAdd(%this,%obj)
{
   // Vehicle timeout
   %obj.mountVehicle = true;

   // Default dynamic armor stats
   %obj.setRepairRate(0);

}
