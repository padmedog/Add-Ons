$HatMod::CurrentVersion = 4.2;
if($HatMod::Debug $= "")
	$HatMod::Debug = 0;
if($HatMod::LatestVersion $= "")
	$HatMod::LatestVersion = $HatMod::CurrentVersion;