// Below is a simple script to make requiring add-ons a whole fuckton easier.

function requireAddOn(%addOn)
{
	%datablockCount = datablockGroup.getCount(); // For later use..
	
	%error = forceRequiredAddOn(%addOn);
	
	if(%error == $error::addOn_notFound) // Slap on the wrist and leave.
	{
		error("ERROR: Required add-on '" @ %addOn @ "' not found!");
		
		return false;
	}
	
	if(%error == $error::addOn_disabled) // Remove the UI names.
		for(%i = %datablockCount; %i < datablockGroup.getCount(); %i++)
		{
			%data = datablockGroup.getObject(%i);
			
			if(%data.uiName !$= "")
				%data.uiName = ""; // No UI names, please!
			
			if(%data.subCategory !$= "")
			{
				%data.category = ""; // No brick category.
				%data.subCategory = ""; // No brick category.
			}
		}
	
	return true;
}

// Below adds the default wrench mode and register function.

function wrench_addMode(%name, %function, %trustLevel)
{
	for(%i = 1; %i <= $wrenchModes; %i++)
		if($wrenchMode[%i] $= %name) // Duplicate entry.
			return false;
	
	$wrenchMode[$wrenchModes++] = %name; // The name.
	$wrenchFunction[$wrenchModes] = %function; // The function.
	$wrenchTrust[$wrenchModes] = %trustLevel; // The trust level.
	
	return true;
}

if($wrenchModes $= "")
	$wrenchModes = 0;

wrench_addMode("normal", "", "");