function getPlayerVar(%player,%var)
{
	if(!isObject(%player))
		return 0;
	return getVariableGroupFromObject(%player).valuePlayer["",%player,%var];
}

function getClientVar(%client,%var)
{
	if(!isObject(%client))
		return 0;
	return getVariableGroupFromObject(%client).valueClient["",%client,%var];
}

$statOnePlayer = 0;
$statOneClient = 0;
$statTwoPlayer = 0;
$statTwoClient = 0;

function servercmdvcestatoneplayer(%client,%var)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		$statOneName = %var;
		$statOnePlayer = 1;
		$statOneClient = 0;
		commandtoall('statOneName',%var);
	}
}

function servercmdvcestatoneclient(%client,%var)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		$statOneName = %var;
		$statOnePlayer = 0;
		$statOneClient = 1;
		commandtoall('statOneName',%var);
	}
}

function servercmdvcestattwoplayer(%client,%var)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		$stattwoName = %var;
		$stattwoPlayer = 1;
		$stattwoClient = 0;
		commandtoall('statTwoName',%var);
	}
}

function servercmdvcestattwoclient(%client,%var)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		$stattwoName = %var;
		$stattwoPlayer = 0;
		$stattwoClient = 1;
		commandtoall('statTwoName',%var);
	}
}

package vceStatOnUpdate
{
	function Player::VCE_modVariable(%player,%var,%logic,%value,%client)
	{
		Parent::VCE_modVariable(%player,%var,%logic,%value,%client);
		if($statOnePlayer)
			updateStatOne(%client,getPlayerVar(%player,$statOneName));
		if($statTwoPlayer)
			updateStatTwo(%client,getPlayerVar(%player,$statTwoName));
	}
	function GameConnection::VCE_modVariable(%client,%var,%logic,%value,%clientagain)
	{
		Parent::VCE_modVariable(%client,%var,%logic,%value,%clientagain);
		if($statOneClient)
			updateStatOne(%client,getClientVar(%client,$statOneName));
		if($statTwoClient)
			updateStatTwo(%client,getClientVar(%client,$statTwoName));
	}
};
activatepackage(vceStatOnUpdate);
