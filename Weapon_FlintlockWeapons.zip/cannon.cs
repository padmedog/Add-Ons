//########## Cannon Portable Turret

//### Sounds

datablock AudioProfile(gc_PCannonSetupSound)
{
  filename = "./cannonsetup.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_PCannonFireSound)
{
  filename = "./cannon.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_PCannonReloadSound)
{
  filename = "./cannonreload.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Turrets

datablock TSShapeConstructor(cannonDts)
{
  baseShape = "./cannon.dts";
  sequence0 = "./cannon_root.dsq root";
  sequence1 = "./cannon_look.dsq look";
  sequence2 = "./cannon_reload.dsq reload";
  sequence3 = "./cannon_setup.dsq setup";
};

datablock PlayerData(gc_PCannonTurretPlayer)
{
  renderFirstPerson = true;
  emap = true;
  className = Armor;
  shapeFile = "./cannon.dts";
  cameraMaxDist = 8;
  cameraTilt = 0.261;
  cameraVerticalOffset = 1;
  cameraDefaultFov = 90;
  cameraMinFov = 5;
  cameraMaxFov = 120;
  aiAvoidThis = true;
  minLookAngle = -0.7;
  maxLookAngle = 0.7;
  maxFreelookAngle = 3;
  mass = 200000;
  drag = 1;
  density = 5;
  maxDamage = 300;
  maxEnergy = 10;
  repairRate = 0.33;
  rechargeRate = 0.4;
  runForce = 1000;
  runEnergyDrain = 0;
  minRunEnergy = 0;
  maxForwardSpeed = 0;
  maxBackwardSpeed = 0;
  maxSideSpeed = 0;
  maxForwardCrouchSpeed = 0;
  maxBackwardCrouchSpeed = 0;
  maxSideCrouchSpeed = 0;
  maxUnderwaterForwardSpeed = 0;
  maxUnderwaterBackwardSpeed = 0;
  maxUnderwaterSideSpeed = 0;
  jumpForce = 0;
  jumpEnergyDrain = 0;
  minJumpEnergy = 0;
  jumpDelay = 0;
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
  minImpactSpeed = 250;
  speedDamageScale = 3.8;
  boundingBox = "1 1 7";
  crouchBoundingBox = "1 1 7";
  pickupRadius = 0;
  jetEmitter = "";
  jetGroundEmitter = "";
  jetGroundDistance = 4;
  splash = PlayerSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 0.1;
  splashEmitter[0] = PlayerFoamDropletsEmitter;
  splashEmitter[1] = PlayerFoamEmitter;
  splashEmitter[2] = PlayerBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  runSurfaceAngle = 85;
  jumpSurfaceAngle = 86;
  minJumpSpeed = 20;
  maxJumpSpeed = 30;
  horizMaxSpeed = 68;
  horizResistSpeed = 33;
  horizResistFactor = 0.35;
  upMaxSpeed = 80;
  upResistSpeed = 25;
  upResistFactor = 0.3;
  footstepSplashHeight = 0.35;
  JumpSound = "";
  groundImpactMinSpeed = 10;
  groundImpactShakeFreq = "4 4 4";
  groundImpactShakeAmp = "1 1 1";
  groundImpactShakeDuration = 0.8;
  groundImpactShakeFalloff = 10;
  maxItems = 0;
  maxWeapons = 0;
  maxTools = 0;
  uiName = "Cannon Turret";
  rideable = true;
  lookUpLimit = 0.6;
  lookDownLimit = 0.4;
  canRide = false;
  showEnergyBar = false;
  paintable = true;
  brickImage = horseBrickImage;
  numMountPoints = 1;
  mountThread[0] = "root";
  protectPassengersBurn = false;
  protectPassengersRadius = false;
  protectPassengersDirect = false;
  useCustomPainEffects = true;
  PainHighImage = "";
  PainMidImage = "";
  PainLowImage = "";
  painSound = "";
  deathSound = "";
  useEyePoint = 1;
  gc_portableTurret = 1;
  gc_turretItem = gc_PCannonItem;
};

function gc_PCannonTurretPlayer::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  %obj.playThread(0,setup);
  %obj.lastShotTime = getSimTime()+1300;
  %obj.PlayAudio(0,gc_PCannonSetupSound);
  schedule(1300,0,gc_PCannonReadyUp,%obj);
}

function gc_PCannonReadyUp(%obj)
{
  if(!isObject(%obj)) return;
  %obj.playThread(0,root);
  %obj.playThread(1,reload);
  %obj.PlayAudio(1,gc_PCannonReloadSound);
}

//### Effects

datablock ParticleData(gc_PCannonFlashParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/star1";
  spinSpeed = 50;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "1 1 1 1";
  colors[1] = "1 0.5 0 1";
  colors[2] = "1 0 0 0";
  sizes[0] = 5;
  sizes[1] = 3;
  sizes[2] = 2;
  times[9] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_PCannonFlashEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = -50;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 10;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_PCannonFlashParticle";
};

datablock ParticleData(gc_PCannonSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = -0.5;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0 0 0 0.5";
  colors[1] = "0 0 0 0.2";
  colors[2] = "0 0 0 0";
  sizes[0] = 1;
  sizes[1] = 2;
  sizes[2] = 4;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_PCannonSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 10;
  periodVarianceMS = 0;
  ejectionVelocity = -10;
  velocityVariance = 0;
  ejectionOffset = 1;
  thetaMin = 0;
  thetaMax = 45;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_PCannonSmokeParticle";
};

datablock ShapeBaseImageData(gc_PCannonFireImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 1;

  stateName[0] = "FireA";
  stateTransitionOnTimeout[0] = "FireB";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 0.1;
  stateEmitter[0] = gc_PCannonFlashEmitter;
  stateEmitterTime[0] = 0.1;

  stateName[1] = "FireB";
  stateTransitionOnTimeout[1] = "Done";
  stateWaitForTimeout[1] = true;
  stateTimeoutValue[1] = 0.05;
  stateEmitter[1] = gc_PCannonSmokeEmitter; 
  stateEmitterTime[1] = 0.2;

  stateName[2] = "Done";
  stateScript[2] = "onDone";
};

function gc_PCannonFireImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

datablock ParticleData(gc_PCannonExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/star1";
  spinSpeed = 0;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 4;
  sizes[1] = 2;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_PCannonExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 1;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 1;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_PCannonExplosionParticle";
};

datablock ParticleData(gc_PCannonExplosionSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = -0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 0.5";
  colors[1] = "0 0 0 0";
  sizes[0] = 3;
  sizes[1] = 5;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_PCannonExplosionSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 5;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 5;
  ejectionOffset = 0.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_PCannonExplosionSmokeParticle";
};

datablock ExplosionData(gc_PCannonExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_PCannonExplosionEmitter;
  emitter[1] = gc_PCannonExplosionSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  damageRadius = 4;
  radiusDamage = 80;
  impulseRadius = 4;
  impulseForce = 20;
  soundProfile = spearExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 6;
};

//### Projectile

AddDamageType("gc_PCannon",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_cannon> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_cannon> %1',0.2,1);

datablock ProjectileData(gc_PCannonProjectile)
{
  uiName = "";
  projectileShapeName = "Add-Ons/Weapon_FlintlockWeapons/cannonball.dts";
  directDamage = 100;
  directVehicleDamage = 30;
  directDamageType = $DamageType::gc_PCannon;
  radiusDamageType = $DamageType::gc_PCannon;
  brickExplosionRadius = 0;
  brickExplosionImpact = false;
  impactImpulse = 500;
  verticalImpulse = 0;
  particleEmitter = "";
  explosion = gc_PCannonExplosion;
  particleEmitter = gc_GrenadeTrailEmitter;
  muzzleVelocity = 100;
  armingDelay = 0;
  lifetime = 5000;
  fadeDelay = 5000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
};

function gc_PCannonProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(miniGameCanDamage(%obj,%col) && getMiniGameFromObject(%col) != -1) {
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
  if(%col.isCrouched() != 1) {
  %colscale = getWord(%col.getScale(),2);
  if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale)
  { %col.damage(%obj,%pos,%this.directDamage/2,%this.directDamageType); } } }
  if(%col.getType() & $TypeMasks::VehicleObjectType)
  { %col.damage(%obj,%pos,%this.directVehicleDamage,%this.directDamageType); return 1; } }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}

//### Item

datablock ItemData(gc_PCannonItem)
{
  uiName = "Cannon Turret";
  iconName = "./icon_cannon";
  image = gc_PCannonImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./cannonitem.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  canDrop = true;
  gc_placementTurret = gc_PCannonTurretPlayer;
  gc_placementBoxSize = "1 1 1.2";
};

//### Item Image

datablock shapeBaseImageData(gc_PCannonImage)
{
  shapeFile = "./cannonitem.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_PCannonItem;
  melee = false;
  doReaction = false;
  armReady = true;
  offset = "-0.52 0 0";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTimeoutValue[1] = 0.05;
  stateTransitionOnTimeout[1] = "Ready";
  stateWaitForTimeout[1] = false;
  stateScript[1] = "checkPlacement";

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.6";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateScript[2] = "onFire";
};

function gc_PCannonImage::checkPlacement(%this,%obj,%slot) { gc_PTcheckPlacement(%this,%obj,%slot); }
function gc_PCannonImage::onFire(%this,%obj,%slot) { gc_PTplaceDown(%this,%obj,%slot); }
function gc_PCannonImage::onMount(%this,%obj,%slot) { parent::onMount(%this,%obj,%slot); %obj.playThread(1,armreadyboth); bottomPrint(%obj.client,"\c0Left click\c3 to place turret! \c0Right click\c3 on placed turret to pick it up! You can<br>\c3only place one turret! Type \c0/clearturret\c3 to remove your current one!",10); }
function gc_PCannonImage::onUnMount(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.playThread(1,root); gc_PTclear(%obj); }

package gc_PCannonPackage
{
  function Player::Burn(%obj,%time)
  {
    if(%obj.dataBlock $= gc_PCannonTurretPlayer) return;
    parent::Burn(%obj,%time);
  }
  function Player::emote(%obj,%emote)
  {
    if(%obj.dataBlock $= gc_PCannonTurretPlayer) return;
    parent::emote(%obj,%emote);
  }
  function armor::onMount(%this,%obj,%col,%slot)
  {
    parent::onMount(%this,%obj,%col,%slot);
    if(isObject(%obj.client))
      if(%col.getDataBlock() == gc_PCannonTurretPlayer.getId()) { %col.playThread(0,root); ServerCmdUnUseTool(%obj.client); }
  }
  function armor::onTrigger(%this,%obj,%triggerNum,%val)
  {
    %mount = %obj.getObjectMount();
    if(%obj.getDataBlock().getID() == gc_PCannonTurretPlayer.getID()) %mount = %obj;
    if(isObject(%mount))
    {
      if(%mount.getDataBlock() == gc_PCannonTurretPlayer.getId() && %triggerNum == 0 && %val)
      {
        %client = %obj.client;
        if(isObject(%client)) ServerCmdUnUseTool(%client);
        if(getSimTime() - %mount.lastShotTime < 2800) return;
        %scaleFactor = getWord(%mount.getScale(),2);
        %p = new Projectile()
        {
          dataBlock = gc_PCannonProjectile;
          initialPosition = %mount.getSlotTransform(1);
          initialVelocity = MatrixMulVector(MatrixCreateFromEuler(((getRandom()-0.5)*0.04) SPC ((getRandom()-0.5)*0.04) SPC ((getRandom()-0.5)*0.04)),VectorScale(%mount.getMuzzleVector(1),100));
          sourceObject = %obj;
          client = %obj.client;
          sourceSlot = 0;
          originPoint = %mount.getSlotTransform(1);
        };
        MissionCleanup.add(%p);
        %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
        %mount.PlayAudio(0,gc_PCannonFireSound);
        %mount.lastShotTime = getSimTime();
        %mount.playThread(1,fire);
        %mount.mountImage(gc_PCannonFireImage,0);
        %mount.schedule(250,playThread,1,reload);
        %mount.schedule(250,PlayAudio,1,gc_PCannonReloadSound);
        return;
      }
    }
    parent::onTrigger(%this,%obj,%triggerNum,%val);
  }
};
activatepackage(gc_PCannonPackage);
