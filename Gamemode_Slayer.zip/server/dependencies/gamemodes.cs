// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

//Adds default gamemodes.
function Slayer_GamemodeHandlerSG::onAdd(%this)
{
	%this.addMode("Slayer","Slyr",0,1);
	%this.addMode("Team Slayer","TSlyr",1,1);
}

//Adds a gamemode.
//@param	string uiName	The name that players will see.
//@param	string fName	This is the one-word name used in callbacks and functions.
//@param	bool teams	This gamemode uses default team functionality.
//@param	bool rounds	This gamemode uses default rounds functionality.
//@return	objectID	The newly created gamemode object.
function Slayer_GamemodeHandlerSG::addMode(%this,%uiName,%fname,%teams,%rounds)
{
	if(%uiName $= "" || %fName $= "" || %teams $= "" || %rounds $= "")
		return;

	if(isObject(%this.getModeFromFName(%fName)) || isObject(%this.getModeFromUIName(%uiName)))
	{
		Slayer_Support::Error("Gamemode Already Exists",%fName TAB %uiName);
		return;
	}

	%mode = new scriptObject()
	{
		class = Slayer_GamemodeSO;

		uiName = %uiName;
		fName = %fName;
		teams = %teams;
		rounds = %rounds;
	};
	%this.add(%mode);

	if(isObject(missionCleanup) && missionCleanup.isMember(%mode))
		missionCleanup.remove(%mode);

	return %mode;
}

//Finds the gamemode object belonging to the fName.
//@param	string flag	The fName to search for.
//@return	objectID The gamemode found.
function Slayer_GamemodeHandlerSG::getModeFromFName(%this,%flag)
{
	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		%m = %this.getObject(%i);
		if(%m.fName $= %flag)
			return %m;
	}

	return 0;
}

//Finds the gamemode object belonging to the uiName.
//@param	string flag	The uiName to search for.
//@return	objectID The gamemode found.
function Slayer_GamemodeHandlerSG::getModeFromUIName(%this,%flag)
{
	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		%m = %this.getObject(%i);
		if(%m.uiName $= %flag)
			return %m;
	}

	return 0;
}

//Finds the the uiName associated with a fName.
//@param	string flag	The fName to search for.
//@return	string	The uiName associated with the fName.
function Slayer_GamemodeHandlerSG::getFNameFromUIName(%this,%flag)
{
	return %this.getModeFromUIName(%flag).fName;
}

//Finds the the fName associated with a uiName.
//@param	string flag	The uiName to search for.
//@return	string	The fName associated with the uiName.
function Slayer_GamemodeHandlerSG::getUINameFromFName(%this,%flag)
{
	return %this.getModeFromFName(%flag).uiName;
}

//Sends gamemode data to a client.
//@param	objectID client	The client to send data to.
//@see	Slayer::sendInitialData
function Slayer_GamemodeHandlerSG::sendGamemodes(%this,%client)
{
	//START THE GAMEMODE TRANSFER
	commandToClient(%client,'Slayer_getGamemodes_Start');

	for(%i = 0; %i < %this.getCount(); %i ++)
	{
		%mode = %this.getObject(%i);
		commandToClient(%client,'Slayer_getGamemodes_Tick',%mode.uiName,%mode.fName,%mode.Teams,%mode.Rounds);
	}

	//END THE GAMEMODE TRANSFER
	commandToClient(%client,'Slayer_getGamemodes_End');
}

// +----------------------+
// | Initialize Component |
// +----------------------+
if(!isObject(Slayer.Gamemodes))
{
	Slayer.Gamemodes = new scriptGroup(Slayer_GamemodeHandlerSG);
	Slayer.add(Slayer.Gamemodes);
}

$Slayer::Server::Dependencies::Gamemodes = 1;
Slayer_Support::Debug(2,"Dependency Loaded","Gamemode");