//Handles startup tasks and initializes update check.
function Updater::onAdd(%this)
{
	//Startup
	%this.add(%this.repositories = new SimSet());
	%this.add(%this.addons = new ScriptGroup()
	{
		class = UpdaterAddOnHandlerSG;
	});
	%this.add(%this.queue = new ScriptGroup()
	{
		class = UpdaterQueueSG;
	});
	
	//This repository is for "community updates".
	%repo = UpdaterRepoSO("http://mods.greek2me.us/third-party");
	%this.repositories.add(%repo);
	
	//TESTING
	//%repo = UpdaterRepoSO("http://mods.greek2me.us/test-repo.json", "JSON");
	//%this.repositories.add(%repo);
	
	//Query
	%datetime = getDateTime();
	%last = $Pref::Updater::LastQueryDate;
	%interval = $Pref::Updater::QueryInterval;
	%this.readFileInfo();
	if($Updater::ManualQuery || !strLen(%last) || DT_getDayDifference(%last, %datetime) >= %interval)
	{
		$Pref::Updater::LastQueryDate = %datetime;
		%this.schedule(100, "checkForUpdates");
	}
	
	%this.checkDayTick(getWord(%datetime, 0));
}

//Handles cleanup tasks.
function Updater::onRemove(%this)
{

}

//Reads version information from all version.txt files in Blockland/Add-Ons.
function Updater::readFileInfo(%this)
{
	//Reset add-ons
	%this.addons.deleteAll();

	%readFO = new FileObject();
	
	echo("Updater reading files.");

	%mask = "Add-Ons/*/version.txt";
	for(%file = findFirstFile(%mask); %file !$= ""; %file = findNextFile(%mask))
	{
		%filePath = filePath(%file);
		%zip = %filePath @ ".zip";
		if($Pref::Updater::ZippedFilesOnly && !isFile(%zip))
			continue;
		%zipPath = filePath(%zip);
		if(%zipPath !$= "Add-Ons")
			continue;
		%zipBase = fileBase(%zip);
		%readFO.openForRead(%file);
		
		%version = "";
		%channel = "";
		%repository = "";
		%format = "";
		%id = "";
		
		//Read the file info.
		while(!%readFO.isEOF())
		{
			%line = %readFO.readLine();
			%tag = "";
			%val = "";
			if(getFieldCount(%line) == 2)
			{
				%tag = getField(%line, 0);
				%val = getField(%line, 1);
			}
			else if(getWordCount(%line) == 2)
			{
				%tag = getWord(%line, 0);
				%val = getWord(%line, 1);
			}
			switch$(%tag)
			{
				case "version" or "version:" or "vers":			%version = %val;
				case "channel" or "channel:" or "chan":			%channel = %val;
				case "repository" or "repository:" or "repo":	%repository = %val;
				case "format" or "format:" or "form":			%format = %val;
				case "id" or "id:":
					if(strPos(%val, " ") >= 0 || strPos(%val, "\t") >= 0)
						echo("Invalid ID for add-on" SPC %zipBase);
					else
						%id = %val;
			}
		}
		%readFO.close();
		
		if(strLen(%version) && strLen(%channel) && strLen(%repository))
		{
			//Find the correct repo object, if it exists
			%components = urlGetComponents(%repository);
			%repoSO = 0;
			for(%i = %this.repositories.getCount() - 1; %i >= 0; %i --)
			{
				%r = %this.repositories.getObject(%i);
				if(%components $= urlGetComponents(%r.url))
				{
					%repoSO = %r;
					if(!strLen(%r.format) && strLen(%format))
						%r.format = %format;
					break;
				}
			}
			if(!isObject(%repoSO))
			{
				%repoSO = UpdaterRepoSO(%repository, %format);
				%this.repositories.add(%repoSO);
			}
			
			//Add the mod to our list of add-ons.
			%addonSO = UpdaterAddOnSO(%zipBase, %version, %channel, %repoSO, %id);
			%this.addons.add(%addonSO);
		}
		else
		{
			echo("Invalid version file:" SPC %file);
		}
	}

	%readFO.delete();
}

//Connects to repositories and looks for updates.
function Updater::checkForUpdates(%this)
{
	//clear the queue
	if(!isObject(%this.queue.currentDownload))
		%this.queue.removeAll();

	for(%i = %this.repositories.getCount() - 1; %i >= 0; %i --)
	{
		%repo = %this.repositories.getObject(%i);
		%repo.queryRemote();
	}
}

//Downloads and installs selected updates.
function Updater::doUpdates(%this)
{
	%this.queue.downloadNext();
}

//Checks for updates on a large interval.
//@param	string date
function Updater::checkDayTick(%this, %date)
{
	%datetime = getDateTime();
	%newDate = getWord(%datetime, 0);
	
	if(%newDate !$= %date)
	{
		%last = $Pref::Updater::LastQueryDate;
		%interval = $Pref::Updater::QueryInterval;
		if(!strLen(%last) || DT_getDayDifference(%last, %datetime) >= %interval)
		{
			$Pref::Updater::LastQueryDate = %datetime;
			%this.checkForUpdates();
		}
	}
	
	if(isEventPending(%this.checkDaySched))
		cancel(%this.checkDaySched);
	%this.checkDaySched = %this.scheduleNoQuota(30000, checkDayTick, %newDate);
}