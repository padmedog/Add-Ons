	$LockPref::Password = "";

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs")) {
	if(!$RTB::Hooks::ServerControl)
		exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");
	RTB_registerPref("Locking Password", "Script_Lock", "$LockPref::Password", "string 200", "LockMod", $LockPref::Password, 0, 0);
}

    
    
    function serverCmdLockServer(%client)
    {
        if(%player.client.isSuperAdmin)
        {
            $Pref::Server::Password = $LockPref::Password;
            messageAll('',"\c6The server has been locked!");
        }
    }
    
    function serverCmdUnlockServer(%client)
    {
        if(%player.client.isSuperAdmin)
        {
            $Pref::Server::Password = "";
            messageAll('',"\c6The server has been unlocked!");
        }

    }
