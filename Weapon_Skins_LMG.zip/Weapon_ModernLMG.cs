AddDamageType("BlockyLMG",   '<bitmap:add-ons/Weapon_Skins_LMG/CI_BlockyLMG> %1',    '%2 <bitmap:add-ons/Weapon_Skins_LMG/CI_BlockyLMG> %1',0.75,1);
datablock ProjectileData(BlockyLMGProjectile1 : lightMachineGunProjectile1)
{
   directDamage        = 10;
   directDamageType    = $DamageType::BlockyLMG;
};

datablock ItemData(BlockyLMGItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Blocky_lmg.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Blocky LMG";
	iconName = "./blockylmg";
	doColorShift = true;
	colorShiftColor = "0.6 0.6 0.64 1.000";

	 // Dynamic properties defined by the scripts
	image = BlockyLMGImage;
	canDrop = true;
	
	maxAmmo = 65;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(BlockyLMGImage : lightMachineGunImage)
{
	shapeFile = "./Blocky_lmg.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
   correctMuzzleVector = true;
   className = "WeaponImage";
   item = BlockyLMGItem;
   ammo = " ";
   projectile = BlockyLMGProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = BlockyLMGItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
};

function BlockyLMGImage::onFire(%this,%obj,%slot)
{ 
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	
	%obj.lastShotTime = getSimTime();
	%shellcount = 1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 1000)
	{
		%spread = 0.0012;
	}
	else
	{
		%spread = 0.0025;
	}

	%projectile = BlockyLMGProjectile1;
	
	%obj.playThread(2, plant);
	%shellcount = 1;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function BlockyLMGImage::onFire2(%this,%obj,%slot)
{ 
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	
	%obj.lastShotTime = getSimTime();
	%shellcount = 1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 1000)
	{
		%spread = 0.0002;
	}
	else
	{
		%spread = 0.0004;
	}

	%projectile = LightMachinegunProjectile1;
	
	%obj.playThread(2, plant);
	%shellcount = 1;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}


function BlockyLMGImage::onReloadStart(%this,%obj,%slot)
{           		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, shiftRight);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
	%obj.popDatablock(LMGArmor.getID());
}

function BlockyLMGImage::onReloadWait(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, plant);
            serverPlay3D(magazineOutSound,%obj.getPosition());
	}
}

function BlockyLMGImage::onClick(%this,%obj,%slot)
{
	%obj.pushDatablock(LMGArmor.getID());
}

function BlockyLMGImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.client.quantity["556rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["556rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["556rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["556rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["556rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["556rounds"] = 0;

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

function BlockyLMGImage::onHalt(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
   %obj.popDatablock(LMGArmor.getID());
}

function BlockyLMGImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
}

function BlockyLMGImage::onUnMount(%this,%obj,%slot)
{
   Parent::onUnMount(%this,%obj,%slot);
   
   %obj.popDatablock(LMGArmor.getID());
}

function BlockyLMGProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.setVelocity(getWord(%col.getVelocity(),0)/1.5 SPC getWord(%col.getVelocity(),1)/1.5 SPC getWord(%col.getVelocity(),1.5));
   }
parent::damage(%this,%obj,%col,%fade,%pos,%normal);
}