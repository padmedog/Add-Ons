//sword.cs
datablock AudioProfile(PowerfistHitSound)
{
   filename    = "./PowerfistHit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(PowerfistSwingSound)
{
   filename    = "./PowerfistSwing.wav";
   description = AudioClose3d;
   preload = true;
};

//effects
datablock ParticleData(PowerfistExplosionParticle)
{
   dragCoefficient      = 0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -500;
   spinRandomMax = 500;
   lifetimeMS           = 150;
   lifetimeVarianceMS   = 50;
   textureName          = "./power";
   colors[0]     = "1 1 1 0.9";
   colors[1]     = "0 0.5 1 0.0";
   sizes[0]      = 2.5;
   sizes[1]      = 4;
};

datablock ParticleEmitterData(PowerfistExplosionEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.25;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PowerfistExplosionParticle";

   uiName = "Power Fist Hit";
};

datablock ExplosionData(PowerfistExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 50;

   soundProfile = PowerfistHitSound;

   particleEmitter = PowerfistExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 10.0 10.0";
   camShakeAmp = "1.50 1.50 1.50";
   camShakeDuration = 1.0;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 0;
   lightStartColor = "0.5 0.75 1 1";
   lightEndColor = "0 0.5 1 0";
   
   damageRadius = 2;
   radiusDamage = 1;

   impulseRadius = 2;
   impulseForce = 3000;  
};


//projectile
AddDamageType("Powerfist",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Powerfist> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Powerfist> %1',0.75,1);
datablock ProjectileData(PowerfistProjectile)
{
   directDamage        = 200;
   directDamageType  = $DamageType::Powerfist;
   radiusDamageType  = $DamageType::Powerfist;
   explosion           = PowerfistExplosion;
   //particleEmitter     = ass;
   impactImpulse      = 1000;
   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   brickExplosionRadius = 1;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 16;
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 30;  //max volume of bricks that we can destroy if they aren't connected to the ground

   armingDelay         = 0;
   lifetime            = 70;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 1.5;
   lightColor  = "0.33 0.66 1";
};


//////////
// item //
//////////
datablock ItemData(PowerfistItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Powerfist.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Power Fist";
	iconName = "./Powerfist";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = PowerfistImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(PowerfistImage)
{
   // Basic Item properties
   shapeFile = "./Powerfist.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = "0";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = PowerfistItem;
   ammo = " ";
   projectile = PowerfistProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.30;
	stateTransitionOnTimeout[2]     = "Fire";	
	stateSound[2]                    = PowerfistSwingSound;
	stateSequence[2]				= "Swing";
	
	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Wait";
	stateTimeoutValue[3]            = 0.05;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;
	
	stateName[4]					= "Wait";
	stateTransitionOnTimeout[4]		= "Ready";
	stateTimeoutValue[4]			= 0.2;
	stateSequence[4]				= "Wait";
	stateScript[4]					= "onWait";

	
};

function PowerfistImage::onPrePreFire(%this, %obj, %slot)
{
	//%obj.playthread(2, shiftAway);
	//%obj.playthread(3, shiftLeft);
}

function PowerfistImage::onPreFire(%this, %obj, %slot)
{
	//%obj.playthread(2, plant);
	//%obj.playthread(3, shiftLeft);
}

function PowerfistImage::onMount(%this, %obj, %slot)
{
	%obj.client.player.hidenode(rhand);
}

function PowerfistImage::onUnMount(%this, %obj, %slot)
{
	%obj.client.applybodyparts();
	%obj.client.applyBodyColors();
}

//function PowerswordImage::onWait(%this, %obj, %slot)
//{	
//	%obj.playthread(2, root);
//}
