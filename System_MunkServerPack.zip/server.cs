//./server.cs

exec("./main.cs");
exec("./admincommands.cs");
exec("./pokenpm.cs");
exec("./status.cs");
exec("./rotationmessage.cs"); 
//exec("./phonesystem.cs");  //Not part of system anymore. But the file is still there if you want it.
exec("./scriptloader.cs");