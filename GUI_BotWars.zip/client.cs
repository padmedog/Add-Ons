if(!$BotWars::GUIEnabled)
{
	$BotWars::GUIEnabled = true;
	
	exec("./BotWarsGUI.gui");

	$remapDivision[$remapCount] = "Bot Wars";
	$remapName[$remapCount] = "Toggle Bot Wars GUI";
	$remapCmd[$remapCount] = "toggleBotWarsGUI";
	$remapCount++;
}

function toggleBotWarsGUI(%val)
{
	if(%val)
	{
		if(BotWarsGUI.isAwake()) canvas.popDialog(BotWarsGUI);
		else {
			canvas.pushDialog(BotWarsGUI);
			commandtoserver('BotWarsGUIRefresh');
		}
	}
}

function ClientCmdBotWarsGUIGetData(%tag, %p1, %p2)
{
	//echo("getData: \"" @ %tag @ "\" \"" @ %p1 @ "\" \"" @ %p2 @ "\"");
	switch$(%tag) {
		case "selectedbot":
			for(%i = 1; %i <= 5; %i++) eval("BotWarsGUI_SelectBotBtn" @ %i @ ".mColor = \"0 192 0 255\";");
			%p1 = mfloor(%p1);
			if(%p1 >= 1 && %p1 <= 5) eval("BotWarsGUI_SelectBotBtn" @ %p1 @ ".mColor = \"255 255 0 255\";");
		
		case "botname":
			eval("BotWarsGUI_BotName" @ %p1 @ ".setText(\"" @ %p2 @ "\");");
			
		case "budget":
			BotWarsGUI_BudgetText.setText("\c6" @ %p1);
		
		case "weapons":
			if(%p2 <= 1) BotWarsGUI_WeaponDrop.clear();
			BotWarsGUI_WeaponDrop.add(%p1, %p2);
			
		case "selectedweapon":
			BotWarsGUI_WeaponSwatch.mColor = "255 255 255 255";
			BotWarsGUI_WeaponDrop.setText(%p1);
			BotWarsGUI_WeaponSwatch.color = "255 255 255 255";
			BotWarsGUI_WeaponDrop.nativeWeapon = %p1;
			
		case "equipment":
			if(!%p2) BotWarsGUI_EquipmentList.clear();
			else BotWarsGUI_EquipmentList.addRow(%p2, %p1, %p2);
		
		case "faces":
			if(%p2 <= 1) BotWarsGUI_FaceDrop.clear();
			BotWarsGUI_FaceDrop.add(%p1, %p2);
		
		case "roles":
			if(%p2 <= 1) BotWarsGUI_RoleDrop.clear();
			BotWarsGUI_RoleDrop.add(%p1, %p2);
		
		case "chests":
			if(%p2 <= 1) BotWarsGUI_ChestDrop.clear();
			BotWarsGUI_ChestDrop.add(%p1, %p2);
		
		case "arms":
			if(%p2 <= 1) BotWarsGUI_HandsDrop.clear();
			BotWarsGUI_HandsDrop.add(%p1, %p2);
		
		case "legs":
			if(%p2 <= 1) BotWarsGUI_FeetDrop.clear();
			BotWarsGUI_FeetDrop.add(%p1, %p2);
		
		case "others":
			if(!%p2) BotWarsGUI_OthersList.clear();
			else BotWarsGUI_OthersList.addRow(%p1, %p2, %p1);
			
		case "info":
			BotWarsGUI_InfoText.setText(%p1);
			BotWarsGUI_PriceText.setText((%p2 >= 0 ? (%p2 > BotWarsGUI_BudgetText.getValue() ? "\c6" : "\c0") : "\c2") @ %p2);
	}
}

function BotWarsGUI_WeaponDrop::onSelect()
{
	commandToServer('BotWarsGUISelectItem', "weapons", BotWarsGUI_WeaponDrop.getSelected());
	if(BotWarsGUI_WeaponDrop.getText() !$= BotWarsGUI_WeaponDrop.nativeWeapon) BotWarsGUI_WeaponSwatch.color = "255 192 0 255";
	else BotWarsGUI_WeaponSwatch.color = "255 255 255 255";
}

function BotWarsGUIResetWeapon()
{
	BotWarsGUI_WeaponDrop.setSelected(0);
	BotWarsGUI_WeaponDrop.setText(BotWarsGUI_WeaponDrop.nativeWeapon);
	BotWarsGUI_WeaponSwatch.color = "255 255 255 255";
}

function BotWarsGUI_EquipmentList::Clicked()
{
	commandToServer('BotWarsGUISelectItem', "equipment", BotWarsGUI_EquipmentList.getSelectedID());
	BotWarsGUIResetWeapon();
}

function BotWarsGUI_FaceDrop::onSelect()
{
	commandToServer('BotWarsGUISelectItem', "faces", BotWarsGUI_FaceDrop.getSelected());
	BotWarsGUIResetWeapon();
	BotWarsGUI_RoleDrop.setText("");
	BotWarsGUI_ChestDrop.setText("");
	BotWarsGUI_HandsDrop.setText("");
	BotWarsGUI_FeetDrop.setText("");
}

function BotWarsGUI_RoleDrop::onSelect()
{
	commandToServer('BotWarsGUISelectItem', "roles", BotWarsGUI_RoleDrop.getSelected());
	BotWarsGUIResetWeapon();
	BotWarsGUI_FaceDrop.setText("");
	BotWarsGUI_ChestDrop.setText("");
	BotWarsGUI_HandsDrop.setText("");
	BotWarsGUI_FeetDrop.setText("");
}

function BotWarsGUI_ChestDrop::onSelect()
{
	commandToServer('BotWarsGUISelectItem', "chests", BotWarsGUI_ChestDrop.getSelected());
	BotWarsGUIResetWeapon();
	BotWarsGUI_FaceDrop.setText("");
	BotWarsGUI_RoleDrop.setText("");
	BotWarsGUI_HandsDrop.setText("");
	BotWarsGUI_FeetDrop.setText("");
}

function BotWarsGUI_HandsDrop::onSelect()
{
	commandToServer('BotWarsGUISelectItem', "arms", BotWarsGUI_HandsDrop.getSelected());
	BotWarsGUIResetWeapon();
	BotWarsGUI_FaceDrop.setText("");
	BotWarsGUI_RoleDrop.setText("");
	BotWarsGUI_ChestDrop.setText("");
	BotWarsGUI_FeetDrop.setText("");
}

function BotWarsGUI_FeetDrop::onSelect()
{
	commandToServer('BotWarsGUISelectItem', "legs", BotWarsGUI_FeetDrop.getSelected());
	BotWarsGUIResetWeapon();
	BotWarsGUI_FaceDrop.setText("");
	BotWarsGUI_RoleDrop.setText("");
	BotWarsGUI_ChestDrop.setText("");
	BotWarsGUI_HandsDrop.setText("");
}

function BotWarsGUI_OthersList::Clicked()
{
	commandToServer('BotWarsGUISelectItem', "others", BotWarsGUI_OthersList.getSelectedID());
	BotWarsGUIResetWeapon();
	BotWarsGUI_FaceDrop.setText("");
	BotWarsGUI_RoleDrop.setText("");
	BotWarsGUI_ChestDrop.setText("");
	BotWarsGUI_HandsDrop.setText("");
	BotWarsGUI_FeetDrop.setText("");
}