//NARG File Manager
//Version 1.2 Full
//  By Nexus 4833
//=================

//just execute necessary files
exec("./modules/getName/getname.cs");
exec("./modules/zoomImage/zoomimage.cs");

//this module is dependent on the other two
exec("./modules/getFile/getfile.cs");

//in my head it was a cool idea to abstract the specific brick save/load system away from the "prompt file" module
//turns out this adds a lot of unnecessary stuff, oh well.

//package
//----------
package NARGFileManager
{
	function escapeMenu::clickLoadBricks(%this)
	{
		//opens File Manager with 'load' parameter instead
		promptUserFile("", "nfm_uploadsavefile", "loadbls");
	}

	function escapeMenu::clickSaveBricks(%this)
	{
		promptUserFile("", "nfm_savebricks", "savebls");
	}

	//TO DO: redirect auto open gui on becoming admin?
};
activatePackage(NARGFileManager);

function nfm_uploadsavefile(%path)
{
	canvas.popdialog(EscapeMenu);

	if(!isfile(%path) || fileext(%path !$= ".bls"))
	{
		nfm_debug("Warning: File is not a valid blockland save file: " @ %path);
	}
	$LoadingBricks_FileName = %path;

	if($LoadingBricks_ColorMethod $= "")
	{
		$LoadingBricks_ColorMethod = 3;
	}

	if(serverconnection.islocal())
	{
		serverDirectSaveFileLoad($LoadingBricks_FileName, $LoadingBricks_ColorMethod, $LoadingBricks_Silent, $LoadingBricks_Ownership);
	}
	else
	{
		//This is supposed to be used only for dedicated servers, but it seems to work for non dedicated as well.
		//The only side effect that I have found is a line saying that the host cancelled the upload in chat.
		commandtoserver('InitUploadHandshake');

		//I believe all this stuff here is handled automatically, but here it is anyway for future reference.
//		commandtoserver('SetColorMethod', $LoadingBricks_ColorMethod);
//
//		//I actually have no idea what DirName is, but this is how you upload ownership
//		commandtoserver('SetSaveUploadDirName', $LoadingBricks_DirName, $LoadingBricks_Ownership);
	}
}

function nfm_savebricks(%path, %desc)
{
	canvas.popdialog(EscapeMenu);

	if(!isWriteableFileName(%path))
	{
		messageboxok("Error", "Cannot write to file: " @ %path);
		return;
	}
	canvas.pushdialog(SavingGui);
	schedule(0, 0, "saveBricks", %path, %desc);
}

