exec("./bricks/Brick_grinder.cs");

datablock fxDTSBrickData (JointsBrickData)
{
	brickFile = "./Joints.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Joints";
	iconName = "./Brick_StonerPack/JointsIMG";
};

datablock fxDTSBrickData (BluntBrickData)
{
	brickFile = "./Blunt.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Blunt";
	iconName = "./Add-Ons/Brick_StonerPack/BluntIMG";
};

datablock fxDTSBrickData (FattyBrickData)
{
	brickFile = "./Fatty.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Great Fatty";
	iconName = "./Add-Ons/Brick_StonerPack/FattyIMG";
};

datablock fxDTSBrickData (JointDiagBrickData)
{
	brickFile = "./JointDiag.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Joints Diagonal";
	iconName = "./Add-Ons/Brick_StonerPack/JointDiagIMG";
};

datablock fxDTSBrickData (SingleJointBrickData)
{
	brickFile = "./SingleJoint.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Joint";
	iconName = "./Add-Ons/Brick_StonerPack/SingleJointIMG";
};
datablock fxDTSBrickData (BongTokeBrickData)
{
	brickFile = "./Bong.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Bong";
	iconName = "./Add-Ons/Brick_StonerPack/SingleJointIMG";
};
datablock fxDTSBrickData (LighterBrickData)
{
	brickFile = "./Lighter.blb";
	category = "Special";
	subCategory = "Stoner Pack";
	uiName = "Lighter";
	iconName = "./Add-Ons/Brick_StonerPack/SingleJointIMG";
};




