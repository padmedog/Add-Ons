datablock fxLightData(HAnablue)
{
	uiName = "Eksi (AMB) 1/2 - Ana blue";

	LightOn = true;
	radius = 50;
	brightness = 5;
	color = "0.63 0.86 1 1";

	flareOn = false;
	flarecolor = "1 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicblue";
	ConstantSizeOn = true;
	ConstantSize = 2;
	NearSize = 1;
	FarSize = 1;
};
datablock fxLightData(HAnayel : HAnablue)
{
	brightness=3.5;
	uiName = "Eksi (AMB) 1/2 - Ana yellow";
	color = "1 0.8 0.65 1";
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicyellow";
};
datablock fxLightData(HBleuhoriz : HAnablue)
{
	brightness = 4;
	uiName = "Eksi (AMB) 1/2 - Horiz blue";
	color = "0.7 0.9 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/bleuhorizontal";
};
datablock fxLightData(HBleutonderayons : HAnablue)
{
	brightness = 4.5;
	uiName = "Eksi (AMB) 1/2 - Blue-rays";
	color = "0.75 0.92 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/bleutonderayons";
};
datablock fxLightData(HClassicblue : HAnablue)
{
	brightness = 3.5;
	uiName = "Eksi (AMB) 1/2 - Blue 3";
	color = "0.6 0.9 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/classicblue";
};
datablock fxLightData(HEtoilebleu : HAnablue)
{
	brightness = 5.5;
	uiName = "Eksi (AMB) 1/2 - Blue bright";
	color = "0.83 0.94 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/etoilebleu";
};
datablock fxLightData(HJaunidiagonal : HAnablue)
{
	brightness = 3.5;
	uiName = "Eksi (AMB) 1/2 - Diag yellow";
	color = "1 0.91 0.75 1";
	flarebitmap = "Add-Ons/Light_Eksi/jaunidiagonal";
};
datablock fxLightData(HMultidirectionalcolor : HAnablue)
{
	brightness = 4.5;
	uiName = "Eksi (AMB) 1/2 - Teal multi";
	color = "0.67 1 0.97 1";
	flarebitmap = "Add-Ons/Light_Eksi/multidirectionalcolor";
};
datablock fxLightData(HNeutresunetoile : HAnablue)
{
	brightness = 4;
	uiName = "Eksi (AMB) 1/2 - Neutral star";
	color = "1 0.88 0.76 1";
	flarebitmap = "Add-Ons/Light_Eksi/neutresunetoile";
};
datablock fxLightData(HNormal20 : HAnablue)
{
	brightness = 3;
	uiName = "Eksi (AMB) 1/2 - Normal 20";
	color = "0.45 0.55 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/normal20";
};
datablock fxLightData(HVertical : HAnablue)
{
	brightness = 3.5;
	uiName = "Eksi (AMB) 1/2 - Vert yellow";
	color = "1 0.5 0.33 1";
	flarebitmap = "Add-Ons/Light_Eksi/vertical";
};
datablock fxLightData(HFlashlight : HAnablue)
{
	brightness = 4.5;
	uiName = "Eksi (AMB) 1/2 - White spectrum";
	color = "1 1 1 1";
};