datablock AudioProfile(StormBlasterShotSound)
{
	filename	 = "./sounds/BlasterShoot.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(StormSniperShotSound)
{
	filename	 = "./sounds/SniperShoot.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(StormHitSound)
{
	filename	 = "./sounds/StormImpact.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(StormEquipSound)
{
	filename	 = "./sounds/StormEquip.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(StormBomberShotSound)
{
	filename	 = "./sounds/BomberShoot.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(StormBomberExplosionSound)
{
	filename	 = "./sounds/BomberExplosion.wav";
	description = AudioClose3d;
	preload = true;
};

exec("./blasters.cs");
exec("./bombers.cs");
exec("./snipers.cs");