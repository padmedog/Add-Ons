//	--
//Title: Props_Household
//Author: Anybody
//	--

//Prop datablocks
	datablock StaticShapeData(MugShape)
	{
		shapefile="add-ons/Props_household/Shapes/Mug.dts";
	};

	datablock fxDtsBrickData(MugBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Mug";
		iconName = "add-ons/props_household/brickicons/Mug";
		
		brickSizeX=1;
		brickSizeY=1;
		brickSizeZ=2;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=MugShape;
		modelOffset="0 0 0";
		modelScale="1.7 1.7 1.7";
		
		colorCount=1;
		
		colorGroup[0]="ALL";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};



	datablock StaticShapeData(PlateShape)
	{
		shapefile="add-ons/Props_household/Shapes/Plate.dts";
	};

	datablock fxDtsBrickData(PlateBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Plate";
		iconName = "add-ons/props_household/brickicons/Plate";
		
		brickSizeX=2;
		brickSizeY=2;
		brickSizeZ=1;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=PlateShape;
		modelOffset="0 0 -.05";
		modelScale="5 5 7";
		
		colorCount=1;
		
		colorGroup[0]="trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

	datablock StaticShapeData(ForkKnifeShape)
	{
		shapefile="add-ons/Props_household/Shapes/KnifeFork.dts";
	};

	datablock fxDtsBrickData(ForkKnifeBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Fork and knife";
		
		brickSizeX=2;
		brickSizeY=1;
		brickSizeZ=1;
		iconName = "add-ons/props_household/brickicons/ForkKnife";
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=ForkKnifeShape;
		modelOffset="0 0 -.08";
		modelScale="3 3 3";
		
		colorCount=2;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
		
		colorGroup[1]="Gray";
			colorMode[1]="Fix";
			colorShift[1]="0.6 0.6 0.6 1";
	};

	datablock StaticShapeData(ComputerShape)
	{
		shapefile="add-ons/Props_household/Shapes/Computer.dts";
	};

	datablock fxDtsBrickData(ComputerBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Computer";
		iconName = "add-ons/props_household/brickicons/Computer1";
		
		brickSizeX=2;
		brickSizeY=3;
		brickSizeZ=6;
		
		//Is a prop!
		isProp=1;

		//Is a screen!
		isComputer=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=ComputerShape;
		modelOffset="0 0 0";
		modelScale="7 7 6.3";
		
		colorCount=2;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";

		colorGroup[1]="Screen";
			colorMode[1]="Fix";
			colorShift[1]="0 1 0 1";
	};

	datablock StaticShapeData(Computer2Shape)
	{
		shapefile="add-ons/Props_household/Shapes/Computer2.dts";
	};

	datablock fxDtsBrickData(Computer2BrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Computer2";
		iconName = "add-ons/props_household/brickicons/Computer2";
		
		brickSizeX=2;
		brickSizeY=3;
		brickSizeZ=6;
		
		//Is a prop!
		isProp=1;

		//Is a screen!
		isComputer=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=Computer2Shape;
		modelOffset="-.05 0 -.06";
		modelScale="7 7 6.3";
		
		colorCount=2;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";

		colorGroup[1]="Screen";
			colorMode[1]="Fix";
			colorShift[1]="0 1 0 1";
	};

	datablock StaticShapeData(Computer3Shape)
	{
		shapefile="add-ons/Props_household/Shapes/Computer3.dts";
	};

	datablock fxDtsBrickData(Computer3BrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Computer3";
		iconName = "add-ons/props_household/brickicons/Computer3";		

		brickSizeX=2;
		brickSizeY=3;
		brickSizeZ=6;
		
		//Is a prop!
		isProp=1;

		//Is a screen!
		isComputer=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=Computer3Shape;
		modelOffset="-.05 0 -.06";
		modelScale="7 7 6.3";
		
		colorCount=2;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";

		colorGroup[1]="Screen";
			colorMode[1]="Fix";
			colorShift[1]="0 1 0 1";
	};

	datablock StaticShapeData(FlatTVShape)
	{
		shapefile="add-ons/Props_household/Shapes/FlatTV.dts";
	};

	datablock fxDtsBrickData(FlatTVBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Flatscreen TV";
		iconName = "add-ons/props_household/brickicons/FlatTV";		

		brickSizeX=2;
		brickSizeY=4;
		brickSizeZ=7;
		
		//Is a prop!
		isProp=1;

		//Is a screen!
		isComputer=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=FlatTVShape;
		modelOffset="0 0 -.65";
		modelScale="10 10 10";
		
		colorCount=2;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";

		colorGroup[1]="Screen";
			colorMode[1]="Fix";
			colorShift[1]="0 1 0 1";
	};

	datablock StaticShapeData(KeyboardShape)
	{
		shapefile="add-ons/Props_household/Shapes/Keyboard.dts";
	};

	datablock fxDtsBrickData(KeyboardBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Keyboard";
		iconName = "add-ons/props_household/brickicons/Keyboard";		

		brickSizeX=1;
		brickSizeY=2;
		brickSizeZ=1;
		
		//Is a prop!
		isProp=1;
		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=KeyboardShape;
		modelOffset="-.03 .03 -.01";
		modelScale="6 6 6";
		
		colorCount=1;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";
	};

	datablock StaticShapeData(FridgeShape)
	{
		shapefile="add-ons/Props_household/Shapes/Fridge.dts";
	};

	datablock fxDtsBrickData(FridgeBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Fridge";
		iconName = "add-ons/props_household/brickicons/Fridge";
		
		brickSizeX=4;
		brickSizeY=4;
		brickSizeZ=15;
		
		//Is a prop!
		isProp=1;

		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=FridgeShape;
		modelOffset="0 0 0";
		modelScale="9 9 9";
		
		colorCount=3;
		
		colorGroup[0]="Fridge";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";

		colorGroup[1]="Bottom";
			colorMode[1]="Fix";
			colorShift[1]="0.2 0.2 0.2 1";

		colorGroup[2]="Handels";
			colorMode[2]="Fix";
			colorShift[2]="0.5 0.5 0.5 1";
	};

	datablock StaticShapeData(OvenShape)
	{
		shapefile="add-ons/Props_household/Shapes/Oven.dts";
	};

	datablock fxDtsBrickData(OvenBrickData)
	{
		category="Props";
		subCategory="Home";
		uiName="Oven";
		iconName = "add-ons/props_household/brickicons/Oven";
		
		brickSizeX=4;
		brickSizeY=4;
		brickSizeZ=9;
		
		//Is a prop!
		isProp=1;

		
		//Brick
		brickRender=0;
		brickCollide=1;
		brickRaycast=1;
		
		//Model
		spawnModel=OvenShape;
		modelOffset="0 0 0";
		modelScale="9 9 8";
		
		colorCount=3;
		
		colorGroup[0]="Trans";
			colorMode[0]="Intensity";
			colorShift[0]="1 1 1 1";

		colorGroup[1]="Bottom";
			colorMode[1]="Fix";
			colorShift[1]="0.2 0.2 0.2 1";

		colorGroup[2]="Handle";
			colorMode[2]="Fix";
			colorShift[2]="0.5 0.5 0.5 1";
	};


//--

//Computerscreen event
	registerOutputEvent(fxDtsBrick,"setScreen","paintColor 0",0);
	
	function fxDtsBrick::setScreen(%b,%green)
	{
		if(%b.getDatablock().isComputer)
		{
			%b.prop.setNodeColor("Screen",getColorIDTable(%green));
		}
	}
//--