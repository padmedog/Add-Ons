datablock fxDTSBrickData ( brickWoodenDoorOpenCWData )
{
	brickFile = "./WoodenDooropenCW.blb";
	uiName = "Wooden Door";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWoodenDoorCWData";
	openCW = "brickWoodenDoorOpenCWData";
	
	closedCCW = "brickWoodenDoorCWData";
	openCCW = "brickWoodenDoorOpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickWoodenDoorOpenCCWData : brickWoodenDoorOpenCWData )
{
	brickFile = "./WoodenDooropenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickWoodenDoorCWData : brickWoodenDoorOpenCWData )
{
	brickFile = "./WoodenDoorclosed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/WoodenDoor";
	
	isOpen = 0;
};