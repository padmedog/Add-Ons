//Ripped from speedgui which was ripped from greekbots

if(!$SubwayVehicle_Binded)
{
    $remapDivision[$remapCount] = "Trains";
    $remapName[$remapCount] = "Toggle Bell";
    $remapCmd[$remapCount] = "togglebellcommand";
    $remapCount++;
    $SubwayVehicle_Binded = 1;
}

function togglebellcommand(%val)
{
   //if released
   if(!%val)
      commandtoserver('togglebell');

}