datablock fxDTSBrickData (brick16FPrintBaseplateCData)
{
	brickFile = "./16FPrintBaseplateC.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "16x Ceiling Print Baseplate";
	iconName = "Add-Ons/Brick_PrintBaseplatesCeiling/16FPrintBaseplateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (brick32FPrintBaseplateCData)
{
	brickFile = "./32FPrintBaseplateC.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "32x Ceiling Print Baseplate";
	iconName = "Add-Ons/Brick_PrintBaseplatesCeiling/32FPrintBaseplateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (brick48FPrintBaseplateCData)
{
	brickFile = "./48FPrintBaseplateC.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "48x Ceiling Print Baseplate";
	iconName = "Add-Ons/Brick_PrintBaseplatesCeiling/48FPrintBaseplateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (brick64FPrintBaseplateCData)
{
	brickFile = "./64FPrintBaseplateC.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "64x Ceiling Print Baseplate";
	iconName = "Add-Ons/Brick_PrintBaseplatesCeiling/64FPrintBaseplateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};