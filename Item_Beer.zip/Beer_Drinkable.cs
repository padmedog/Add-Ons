datablock AudioProfile(BeerOpenSound)
{
	filename = "./BeerOpen.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(BeerDrinkSound)
{
	filename = "./BeerDrink.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock DebrisData(BeerCapDebris)
{
	shapeFile = "./BottleCap.dts";
	lifetime = 5;
	minSpinSpeed = -400;
	maxSpinSpeed = 200;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 5;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 4;
};

datablock ItemData(Beer_DrinkableItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./Bottle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "Beer - Drinkable";
	iconName = "./Icon_Beer_Drinkable";
	doColorShift = false;

	image = Beer_DrinkableImage;
	canDrop = true;
};

datablock ShapeBaseImageData(Beer_DrinkableImage)
{
	shapeFile = "./Open_Bottle.dts";
	emap = true;

	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0;
	rotation = eulerToMatrix("0 0 0");

	className = "WeaponImage";

	item = Beer_DrinkableItem;

	casing = BeerCapDebris;
	shellExitDir = "30 0 500";
	shellExitOffset = "10 0 50";
	shellExitVariance = 10;
	shellVelocity = 9;

	alcohol = 0.06;

	armReady = true;

	doColorShift = false;

	stateName[0]			= "Ready";
	stateTransitionOnTriggerDown[0]	= "Fire";
	stateAllowImageChange[0]	= true;
	stateEjectShell			= true;
	stateSound[0]			= BeerOpenSound;

	stateName[1]			= "Fire";
	stateTransitionOnTimeout[1]	= "Ready";
	stateAllowImageChange[1]	= true;
	stateScript[1]			= "onFire";
	stateTimeoutValue[1]		= 1;
};

function Beer_DrinkableImage::onFire(%data, %player, %slot)
{
	%player.playThread(0, activate);

	//We're using audio slot 1 because the pain noise uses 0 and we
	//want to still hear the drinking sound, even when you get hurt
	//from drinking the beer.
	%player.stopAudio(1);
	%player.playAudio(1, BeerDrinkSound);

	%player.tool[%player.currTool] = 0;
	%player.weaponCount--;

	if(!isObject(%client = %player.client))
	{
		%player.unMountImage(%slot);

		return;
	}

	messageClient(%client, 'MsgItemPickup', '', %player.currTool, 0, 1);
	serverCmdUnUseTool(%client);

	%player.increaseAlcoholLevel(%data.alcohol);
}