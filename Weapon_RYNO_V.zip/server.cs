switch(forcerequiredaddon(Projectile_GravityRocket))
{
	case $Error::AddOn_Disabled: GravityRocketProjectile.uiName = "";
	case $Error::AddOn_NotFound: echo("\c2The RYNO V requires the Gravity Rocket add-on!"); return;
}

exec("./homing.cs");

datablock AudioProfile(RYNO5_FireMusicSound)
{
	filename = "./1812_Overture.wav";
	description = AudioCloseLooping3d;
	preload = true;
};

datablock ParticleData(RYNO5_FlashParticle)
{
	dragCoefficient = 0;
	gravityCoefficient = 0;
	inheritedVelFactor = 1;
	constantAcceleration = 0;
	lifetimeMS = 100;
	lifetimeVarianceMS = 99;
	textureName = "base/data/particles/star1";
	spinSpeed= 10;
	spinRandomMin= -500;
	spinRandomMax= 500;
	useInvAlpha = false;
	colors[0] = "1 1 0.5 1";
	colors[1] = "1 1 0 1";
	sizes[0] = 0.5;
	sizes[1] = 0;
};
datablock ParticleEmitterData(RYNO5_FlashEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.25;
   velocityVariance = 0;
   ejectionOffset = 0.35;
   thetaMin = 85;
   thetaMax = 105;
   phiReferenceVel = 0;
   phiVariance = 360;
   overrideAdvance = false;
   particles = RYNO5_FlashParticle;
};

datablock ParticleData(RYNO5_SmokeParticle)
{
	dragCoefficient = 5;
	gravityCoefficient = -0.25;
	inheritedVelFactor = 0.2;
	constantAcceleration = 0;
	lifetimeMS = 500;
	lifetimeVarianceMS = 100;
	textureName = "base/data/particles/cloud";
	spinSpeed = 10;
	spinRandomMin = -500;
	spinRandomMax = 500;
	useInvAlpha = false;
	colors[0] = "0.3 0.3 0.3 0.5";
	colors[1] = "0.3 0.3 0.3 0";
	sizes[0] = 0.15;
	sizes[1] = 0.15;
};
datablock ParticleEmitterData(RYNO5_SmokeEmitter : RYNO5_FlashEmitter)
{
	ejectionPeriodMS = 3;
	particles = RYNO5_SmokeParticle;
};

datablock ParticleData(RYNO5_SmallBullet_Particle)
{
	dragCoefficient = 3;
	gravityCoefficient = -0.5;
	inheritedVelFactor = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS = 25;
	lifetimeVarianceMS = 15;
	textureName = "base/data/particles/dot";
	spinSpeed = 10;
	spinRandomMin = -500;
	spinRandomMax = 500;
	useInvAlpha = false;
	colors[0] = "1 0.5 0 1";
	colors[1] = "1 1 0 0.9";
	sizes[0] = 0.3;
	sizes[1] = 0.1;
};
datablock ParticleEmitterData(RYNO5_SmallBulletEmitter)
{
	ejectionPeriodMS = 3;
	periodVarianceMS = 0;
	ejectionVelocity = 1;
	velocityVariance = 1;
	ejectionOffset = 0.0;
	thetaMin = 0;
	thetaMax = 90;
	phiReferenceVel = 0;
	phiVariance = 360;
	overrideAdvance = false;
	particles = RYNO5_SmallBullet_Particle;
};

datablock ParticleData(RYNO5_RocketTrail_Particle)
{
	dragCoefficient = 5;
	gravityCoefficient = 0;
	inheritedVelFactor = 0;
	constantAcceleration = 0;
	lifetimeMS = 1000;
	lifetimeVarianceMS = 100;
	textureName = "base/data/particles/cloud";
	spinSpeed = 10;
	spinRandomMin = -200;
	spinRandomMax = 200;
	useInvAlpha = true;
	colors[0] = "1 1 0 0.9";
	colors[1] = "0.9 0.6 0.15 0.8";
	colors[2] = "0.8 0.5 0.3 0.8";
	colors[3] = "0.35 0.32 0.3 0";
	sizes[0] = 0.3;
	sizes[1] = 0.5;
	sizes[2] = 0.6;
	sizes[3] = 0.8;
	times[0] = 0;
	times[1] = 0.2;
	times[2] = 0.4;
	times[3] = 1;
};
datablock ParticleEmitterData(RYNO5_RocketTrailEmitter)
{
	ejectionPeriodMS = 10;
	periodVarianceMS = 0;
	ejectionVelocity = 0;
	velocityVariance = 0;
	ejectionOffset = 0.2;
	thetaMin = 135;
	thetaMax = 180;
	phiReferenceVel = 0;
	phiVariance = 360;
	overrideAdvance = false;
	particles = RYNO5_RocketTrail_Particle;
};

datablock ParticleData(RYNO5_SmallExplosionParticle)
{
   dragCoefficient = 8;
   windCoefficient = 0;
   gravityCoefficient = -0.2;
   inheritedVelFactor = 0;
   constantAcceleration = 0;
   lifetimeMS = 50;
   lifetimeVarianceMS = 35;
   spinSpeed = 10;
   spinRandomMin = -500;
   spinRandomMax = 500;
   useInvAlpha = false;
   textureName = "base/data/particles/cloud";
   colors[0] = "1 1 0.5 0.8";
   colors[1] = "1 1 0.5 0";
   sizes[0] = 1;
   sizes[1] = 0;
   times[0] = 0;
   times[1] = 1;
};
datablock ParticleEmitterData(RYNO5_SmallExplosionEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0;
   ejectionOffset = 0;
   thetaMin = 0;
   thetaMax = 90;
   phiReferenceVel = 0;
   phiVariance = 360;
   particles = RYNO5_SmallExplosionParticle;
   lifetimeMS = 50;
   lifetimeVarianceMS = 0;
};

datablock ExplosionData(RYNO5_SmallExplosion)
{
   //soundProfile = ;
   faceViewer = true;
   particleEmitter = RYNO5_SmallExplosionEmitter;
   particleDensity = 50;
   particleRadius = 0.5;
   explosionScale = "1 1 1";
   playSpeed = 1;
   emitter[0] = RYNO5_SmallExplosionEmitter;
   lifetimeMS = 50;
   lifetimeVariance = 0;
   shakeCamera = true;
   cameraShakeFalloff = 11;
   camShakeFreq = "10 10 10";
   camShakeAmp = "2 2 2";
   camShakeDuration = 0.5;
   camShakeRadius = 10;
   camShakeFalloff = 10;
   lightStartRadius = 1;
   lightEndRadius = 3;
   lightStartColor = "1 1 1";
   lightEndColor = "1 1 0";
};

AddDamageType("RynoV", '<bitmap:Add-Ons/Weapon_RYNO_V/CI_RYNO5> %1', '%2 <bitmap:Add-Ons/Weapon_RYNO_V/CI_RYNO5> %1', 1, 1);
AddDamageType("RynoVradius", '<bitmap:Add-Ons/Weapon_RYNO_V/CI_RYNO5> %1', '%2 <bitmap:Add-Ons/Weapon_RYNO_V/CI_RYNO5> %1', 1, 0);

datablock ExplosionData(RYNO5_RocketExplosion : GravityRocketExplosion)
{
	damageRadius = 5;
	radiusDamage = 40;
	impulseRadius = 7;
	impulseForce = 2500;
	playerBurnTime = 0;
};

datablock ProjectileData(RYNO5_SmallProjectile)
{
	projectileShapeName = "base/data/shapes/empty.dts";
	directDamage = 10;
	directDamageType = $DamageType::RynoV;
	radiusDamageType = $DamageType::RynoVradius;

	brickExplosionRadius = 2;
	brickExplosionImpact = true;
	brickExplosionForce  = 20;
	brickExplosionMaxVolume = 20;
	brickExplosionMaxVolumeFloating = 30;

	impactImpulse = 400;
	verticalImpulse = 400;
	explosion = RYNO5_SmallExplosion;
	particleEmitter = RYNO5_SmallBulletEmitter;

	muzzleVelocity = 125;
	velInheritFactor = 0;

	armingDelay = 0;
	lifetime = 4000;
	fadeDelay = 3500;
	bounceElasticity = 0.5;
	bounceFriction = 0.20;
	isBallistic = false;
	gravityMod = 0;

	hasLight = true;
	lightRadius = 2;
	lightColor = "1 1 0";
};

datablock ProjectileData(RYNO5_RocketProjectile)
{
	projectileShapeName = "./RYNOmissile.dts";
	directDamage = 10;
	directDamageType = $DamageType::RynoV;
	radiusDamageType = $DamageType::RynoVradius;

	brickExplosionRadius = 5;
	brickExplosionImpact = true;
	brickExplosionForce  = 35;
	brickExplosionMaxVolume = 30;
	brickExplosionMaxVolumeFloating = 45;

	impactImpulse = 2000;
	verticalImpulse = 1000;
	explosion = RYNO5_RocketExplosion;
	particleEmitter = RYNO5_RocketTrailEmitter;

	muzzleVelocity = 125;
	velInheritFactor = 0;

	armingDelay = 0;
	lifetime = 5000;
	fadeDelay = 5000;
	bounceElasticity = 0.5;
	bounceFriction = 0.20;
	isBallistic = false;
	gravityMod = 0;
	hasLight = true;
	lightRadius = 2;
	lightColor = "1 0.5 0";
};

datablock ItemData(RYNO5_Item)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./RYNO5.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "RYNO  V";
	iconName = "./Icon_RYNO_V";
	doColorShift = true;
	colorShiftColor = "1 1 1 1";

	image = RYNO5_Image;
	canDrop = true;
};

datablock ShapeBaseImageData(RYNO5_Image)
{
	shapeFile = "./RYNO5.dts";
	emap = true;

	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = "0.8 0.8 -0.5";
	rotation = "0 0 0";

	correctMuzzleVector = true;

	className = "WeaponImage";

	item = RYNO5_Item;
	ammo = " ";
	projectile = RYNO5_SmallProjectile;
	projectileType = Projectile;

	melee = false;
	armReady = true;

	doColorShift = true;
	colorShiftColor = RYNO5_Item.colorShiftColor;

	stateName[0]                   = "Activate";
	stateTimeoutValue[0]           = 0.15;
	stateTransitionOnTimeout[0]    = "Ready";
	stateSound[0]                  = weaponSwitchSound;

	stateName[1]                   = "Ready";
	stateTransitionOnTriggerDown[1]= "Fire";
	stateAllowImageChange[1]       = true;
	stateSequence[1]               = "Idle";

	stateName[2]                   = "Fire";
	stateTransitionOnTimeout[2]    = "Fire";
	stateTransitionOnTriggerUp[2]  = "Smoke";
	stateTimeoutValue[2]           = 0.02;
	stateFire[2]                   = true;
	stateAllowImageChange[2]       = false;
	stateSequence[2]               = "Fire";
	stateScript[2]                 = "onFire";
	stateWaitForTimeout[2]         = true;
	stateEmitter[2]                = RYNO5_FlashEmitter;
	stateEmitterTime[2]            = 0.05;
	stateEmitterNode[2]            = "muzzleNode";
	stateSound[2]                  = RYNO5_FireMusicSound;

	stateName[3]                   = "Smoke";
	stateEmitter[3]                = RYNO5_SmokeEmitter;
	stateEmitterTime[3]            = 2;
	stateEmitterNode[3]            = "muzzleNode";
	stateTimeoutValue[3]           = 0.5;
	stateTransitionOnTimeout[3]    = "Ready";
	stateSequence[3]               = "Slow";
};

function RYNO5_Image::onFire(%this,%obj,%slot)
{
	if(!%obj.lastRYNO5rocket)
	{
		%obj.lastRYNO5rocket = getSimTime();
	}
	%spread = 0.2;
	%vector = %obj.getMuzzleVector(%slot);
	%vector = VectorScale(%vector, 130);
	%x = (getRandom() - 0.5) * %spread;
	%y = (getRandom() - 0.5) * %spread;
	%z = (getRandom() - 0.5) * %spread;
	%mat = MatrixCreateFromEuler(%x SPC %y SPC %z);
	%velocity = MatrixMulVector(%mat, %vector);
	%p = new projectile()
	{
		dataBlock = RYNO5_SmallProjectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	if((%obj.lastRYNO5rocket + 1000) <= getSimTime())
	{
		%obj.lastRYNO5rocket = getSimTime();
		new projectile()
		{
			dataBlock = RYNO5_RocketProjectile;
			initialVelocity = vectorScale(vectorNormalize(%velocity), 50);
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}