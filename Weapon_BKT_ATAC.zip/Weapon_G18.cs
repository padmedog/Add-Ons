datablock AudioProfile(G18FAOFireSound)
{
   filename    = "./G18FAOFire.wav";
   description = GunShotRange3d;
   preload = true;
};
datablock ProjectileData(G18FAOProjectile)
{
	directDamage		= 12;
	gravityMod			= 0.6;
	muzzleVelocity		= 185;
	brickExplosionForce	= 6;
	impactImpulse		= 100;
	verticalImpulse		= 100;
	lifetime			= 1500;
	fadeDelay			= 1000;
	particleEmitter		= "ShortVaporTrailEmitter";

	radiusDamage		= 0;
	damageRadius		= 0;
	projectileShapeName	= "add-ons/weapon_gun/bullet.dts";
	directDamageType	= $DamageType::UniversalHeadshot;
	radiusDamageType	= $DamageType::UniversalHeadshot;
	brickExplosionRadius			= 0;
	brickExplosionImpact			= true;
	brickExplosionMaxVolume			= 3;
	brickExplosionMaxVolumeFloating	= 10;
	explosion			= GBImpact2Explosion;
	sound				= BulletWhizzingSound;
	velInheritFactor	= 0;
	armingDelay			= 10;
	bounceElasticity	= 0.5;
	bounceFriction		= 0.1;
	isBallistic			= true;
	hasLight			= false;
	lightRadius			= 3.0;
	lightColor			= "0 0 0";
};
function G18FAOProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	%damageType = $DamageType::Direct;
	if(%this.DirectDamageType)
	{
		%damageType = %this.DirectDamageType;
	}
	%scale = getWord(%obj.getScale(), 2);
	%directDamage = 5*5;
	%damage = %directDamage;
	%sobj = %obj.sourceObject;
	if(%col.getType() & $TypeMasks::PlayerObjectType)
	{
		%directDamage = 12;
		%colscale = getWord(%col.getScale(),2);
		if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale && $BKT::HS)
		{
			%directDamage = 25;
			%damageType = $DamageType::UniversalHeadshot;
		}
		%col.damage(%obj, %pos, %directDamage, %damageType);
	}
	else
	{
		%col.damage(%obj,%pos,%directDamage,%damageType);
	}
}
datablock ItemData(G18FAOItem)
{
	shapeFile	= "./G18FAO.dts";
	iconName	= "./icon_G18FAO";
	image		= G18FAOImage;
	uiName			= "Machine P.";
	maxAmmo			= 33;

	category		= "Weapon";
	className		= "Weapon";
	rotate			= false;
	mass			= 1;
	density			= 1.5;
	elasticity		= 0.2;
	friction		= 0.75;
	emap			= true;
	doColorShift	= true;
	colorShiftColor	= "0.7 0.72 0.7 1.000";
	canDrop			= true;
	canReload		= 1;
};
datablock ShapeBaseImageData(G18FAOImage)
{
	shapeFile	= "./G18FAO.dts";
	item		= G18FAOItem;
	projectile	= G18FAOProjectile;
	shellVelocity	= 10.0;
	shellExitDir	= "1.0 0.0 0.5";
	minShotTime		= 40; //WO THATS FAST
	eyeOffset		= "0 0 0";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= G18FAOItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.2;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.05;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.01;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "SlideBack";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.01;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= G18FAOFireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "FireLoadCheckA";
	stateTimeoutValue[3]		= 0.0;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.05;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateAllowImageChange[6]	= true;
	stateTimeoutValue[6]		= 1.6;
	stateScript[6]				= "OnReload";
	stateTransitionOnTimeout[6]	= "Reloaded";
	stateWaitForTimeout[6]		= true;
	
	stateName[7]				= "Reloaded";
	stateSequence[7]			= "SlideForward";
	stateAllowImageChange[7]	= false;
	stateTimeoutValue[7]		= 0.3;
	stateScript[7]				= "onReloaded";
	stateTransitionOnTimeout[7]	= "Ready";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= true;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.3;
	stateTransitionOnTimeout[9]	= "Reload";

	stateName[10]					= "TriggerCheck";

	stateName[11]					= "slideforward";
	stateTimeoutValue[11]			= 0.0;
	stateTransitionOnTimeout[11]	= "Ready";
	stateAllowImageChange[11]		= true;
	stateSequence[11]				= "SlideForward";

	stateName[12] 					= "FireLoadCheckA";
	stateScript[12]					= "onLoadCheck";
	stateAllowImageChange[12]		= false;
	stateTimeoutValue[12]			= 0.0035;
	stateTransitionOnTimeout[12]	= "FireLoadCheckB";

	stateName[13]				= "FireLoadCheckB";
	stateAllowImageChange[13]	= false;
	stateTransitionOnAmmo[13]	= "slideforward";
	stateTransitionOnNoAmmo[13]	= "ReloadWait";
};
function G18FAOImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
}
function G18FAOADSImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::CH)
	{
		crossHair.setBitmap("add-ons/weapon_blockombat/empty.png");
	}
}
function G18FAOImage::onFire(%this,%obj,%slot)
{
	G18FAOFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function G18FAOImage::onWeaponLoop(%this,%obj,%slot)
{
	if(%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function G18FAOFire(%this,%obj,%slot,%val)
{
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%obj.client.player.getEyeVector(),"-0.625")));
	%projectile = G18FAOProjectile;
	if(%obj.heat >= 13)
	{
		%obj.playThread(3, rotccw);
	}
	else if(%obj.heat >= 4)
	{
		%obj.playThread(3, plant);
	}
	if(%obj.isImageMounted(G18FAOImage))
	{
		%spread = 0.00145 + (%obj.heat * 0.0002);
	}
	else if(%obj.isImageMounted(G18FAOADSImage))
	{
		%spread = 0.00085 + (%obj.heat * 0.0002);
	}
	%obj.maxHeat = 14;
	if(%obj.heat < %obj.maxHeat)
		%obj.heat += 2;
	%shellcount = 1;
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	if($BKT::Flash)
	{
		%projectile = "ATACFlashProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function G18FAOImage::onReload(%this,%obj,%slot)
{
	%obj.client.quantity["9mmRounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;%obj.heat = 0;%obj.heat = 0;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
	if(%obj.client.quantity["9mmRounds"] >= 1)
	{
		%obj.playThread(2, activate);
		%obj.playThread(3, plant);
		serverPlay3D(pistolmagOutSound,%obj.getPosition()); 
	}
}
function G18FAOImage::onReloaded(%this,%obj,%slot)
{
	if(%obj.client.quantity["9mmRounds"] >= 1)
	{
		if(%obj.client.quantity["9mmRounds"] > %this.item.maxAmmo)
		{
			%obj.client.quantity["9mmRounds"] -= %this.item.maxAmmo;
			%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
			%obj.setImageAmmo(%slot,1);
			%obj.playThread(2, shiftleft);
			%obj.playThread(3, leftrecoil);
			%obj.playThread(4, shiftdown);
			serverPlay3D(pistolMagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
		}
		else if(%obj.client.quantity["9mmRounds"] <= %this.item.maxAmmo)
		{
			%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["9mmRounds"];
			%obj.setImageAmmo(%slot,1);
			%obj.client.quantity["9mmRounds"] = 0;	
			%obj.playThread(2, shiftleft);
			%obj.playThread(3, leftrecoil);
			%obj.playThread(4, shiftdown);
			serverPlay3D(pistolMagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
			return;
		}
	}
}
datablock ShapeBaseImageData(G18FAOADSImage)
{
	shapeFile	= "./G18FAO.dts";
	item		= G18FAOItem;
	projectile	= G18FAOProjectile;
	shellVelocity	= 10.0;
	shellExitDir	= "1 0 0.5";
	minShotTime		= 40;
	eyeOffset		= "0 0.9 -1.05";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= G18FAOItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.05;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.01;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "SlideBack";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.01;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= G18FAOFireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "FireLoadCheckA";
	stateTimeoutValue[3]		= 0.0;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.05;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateScript[6]				= "OnReload";
	
	stateName[7]				= "Reloaded";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= true;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.3;
	stateTransitionOnTimeout[9]	= "Reload";

	stateName[10]					= "TriggerCheck";

	stateName[11]					= "slideforward";
	stateTimeoutValue[11]			= 0.0;
	stateTransitionOnTimeout[11]	= "Ready";
	stateAllowImageChange[11]		= true;
	stateSequence[11]				= "SlideForward";

	stateName[12] 					= "FireLoadCheckA";
	stateScript[12]					= "onLoadCheck";
	stateAllowImageChange[12]		= false;
	stateTimeoutValue[12]			= 0.0035;
	stateTransitionOnTimeout[12]	= "FireLoadCheckB";

	stateName[13]				= "FireLoadCheckB";
	stateAllowImageChange[13]	= false;
	stateTransitionOnAmmo[13]	= "slideforward";
	stateTransitionOnNoAmmo[13]	= "ReloadWait";
};
function G18FAOADSImage::onWeaponLoop(%this,%obj,%slot)
{
	if (%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function G18FAOADSImage::onFire(%this,%obj,%slot)
{
	G18FAOFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function G18FAOADSImage::onReload(%this,%obj,%slot)
{
	%obj.mountImage(G18FAOImage,0);
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>9mm Para. MP  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["9mmRounds"]+0 @ "", 4, 2, 3, 4);}
}
package G18FAOSights
{
	function armor::onTrigger(%this,%obj,%triggerNum,%val)
	{
		%client = %obj.client;		
		if(%obj.getMountedImage(0) $= G18FAOImage.getID() && %triggerNum == 4 && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(G18FAOADSImage, 0);
			%client.setControlCameraFov(80);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		else if(%triggerNum == 4 && %obj.getMountedImage(0) $= G18FAOADSImage.getID() && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(G18FAOImage, 0);
			%client.setControlCameraFov(90);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		Parent::onTrigger(%this,%obj,%triggerNum,%val);
	}
	function servercmdDropTool(%client,%slot)
	{
		if(%client.player.getMountedImage(0) $= G18FAOADSImage.getID())
		{
		 	%client.player.unmountImage(0);
			%client.setControlCameraFov(90);
			if($BKT::CH)
			{
				crossHair.setBitmap("base/client/ui/crosshair.png");
			}
		}
		return Parent::servercmdDropTool(%client,%slot);
	}
};
activatePackage(G18FAOSights);
function G18FAOADSImage::onUnMount(%this,%obj,%slot)
{
	%obj.client.setControlCameraFov(90);
	if($BKT::CH)
	{
		crossHair.setBitmap("base/client/ui/crosshair.png");
	}
}