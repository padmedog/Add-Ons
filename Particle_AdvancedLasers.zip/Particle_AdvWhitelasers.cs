//The special angular WhiteLaser particles may be difficult to use. To use them correctly, make sure to use East, West, South and North directions
//only. Using the Up and Down directions work, but will not shoot the WhiteLasers in the right directions (choosing Up for any Down-going WhiteLaser
//will cause the WhiteLaser to shoot upwards instead at a strange angle)

datablock ParticleEmitterData(halfDegDwnWhiteLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 45;
   thetaMax         = 45.1;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "L 45o Dwn Laser";
};

datablock ParticleEmitterData(twothirdDegDwnWhiteLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 22.5;
   thetaMax         = 22.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;

   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "L 67o Dwn Laser";
};

datablock ParticleEmitterData(thirdsDegDwnWhiteLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 67.5;
   thetaMax         = 67.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "L 22o Dwn Laser";
};

//The Up angular particles will shoot out in the Opposite direction specified by the emission point (i.e., the brick in this case).
//If the emitter is shooting West, the Up-going WhiteLaser will shoot East instead, at the correct specified angle.

datablock ParticleEmitterData(halfDegUpWhiteLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = -37;
   thetaMax         = -37.1;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "L 45o Up Laser";
};

datablock ParticleEmitterData(thirdDegUpWhiteLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = -12.5;
   thetaMax         = -12.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "L 22o Up Laser";
};

datablock ParticleEmitterData(twothirdsDegUpWhiteLaserEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 6.0;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = -58.5;
   thetaMax         = -58.6;
   phiReferenceVel  = 368640;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = AdvLaserParticleB;   

	uiName = "L 67o Up Laser";
};




datablock ParticleEmitterData(duoWhiteLaserUpEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserUpParticle";
   useEmitterColors = True;
    uiName = "L Dual Up Laser";
};

datablock ParticleEmitterData(duoWhiteLaserDwnEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserDwnParticle";
   useEmitterColors = True;
    uiName = "L Dual Dwn Laser";
};

datablock ParticleEmitterData(duoWhiteLaserMidEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserMidParticle";
   useEmitterColors = True;
    uiName = "L Dual Mid Laser";
};

datablock ParticleEmitterData(triWhiteLaserDwnEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = LaserDwnParticle;   

	uiName = "L Tri Dwn Laser";
};

datablock ParticleEmitterData(triWhiteLaserUpEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = LaserUpParticle;   

	uiName = "L Tri Up Laser";
};

datablock ParticleEmitterData(triWhiteLaserMidEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = LaserMidParticle;   

	uiName = "L Tri Mid Laser";
};

datablock ParticleEmitterData(quadraWhiteLaserUpEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserUpParticle";
   useEmitterColors = True;
    uiName = "L Quadra Up Laser";
};

datablock ParticleEmitterData(quadraWhiteLaserDwnEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserDwnParticle";
   useEmitterColors = True;
    uiName = "L Quadra Dwn Laser";
};

datablock ParticleEmitterData(quadraWhiteLaserMidEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "LaserMidParticle";
   useEmitterColors = True;
    uiName = "L Quadra Mid Laser";

};

datablock ParticleEmitterData(hexaWhiteLaserUpEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = LaserUpParticle;   

	uiName = "L Hexa Up Laser";
};

datablock ParticleEmitterData(hexaWhiteLaserDwnEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = LaserDwnParticle;   

	uiName = "L Hexa Dwn Laser";
};

datablock ParticleEmitterData(hexaWhiteLaserMidEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   ejectionoffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = LaserMidParticle;   

	uiName = "L Hexa Mid Laser";
};

//Rotating WhiteLasers

datablock ParticleEmitterData(slowrotatingWhiteLaserEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 10;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "AdvLaserParticleB";
   useEmitterColors = True;
    uiName = "L Slow Scanning Laser";
};

datablock ParticleEmitterData(medrotatingWhiteLaserEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 20;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "AdvLaserParticleB";
   useEmitterColors = True;
    uiName = "L Med Scanning Laser";
};

datablock ParticleEmitterData(fastrotatingWhiteLaserEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionoffset   = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 30;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "AdvLaserParticleB";
   useEmitterColors = True;
    uiName = "L Fast Scanning Laser";
};


//offset Lasers

datablock ParticleEmitterData(offsetCloseWhiteLaserEmitter)
{
   ejectionPeriodMS = 8.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.0;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;   

	uiName = "L offset BarLaser";
};

datablock ParticleEmitterData(offsetCloseWhiteLaserPointEmitter)
{
   ejectionPeriodMS = 200.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.0;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;   

	uiName = "L offset CornerLaser";
};

//offset circular WhiteLasers

datablock ParticleEmitterData(offsetClosecirScleWhiteLaserEmitter)
{
   ejectionPeriodMS = 8.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.02;
   velocityVariance = 0.0;
   thetaMin         = 10;
   thetaMax         = 10.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;   

	uiName = "L offset Small CircleLaser";
};

datablock ParticleEmitterData(offsetClosecirMcleWhiteLaserEmitter)
{
   ejectionPeriodMS = 5.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.15;
   velocityVariance = 0.0;
   thetaMin         = 30;
   thetaMax         = 30.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = offsetLaserParticleC;   

	uiName = "L offset Medium CircleLaser";
};

datablock ParticleEmitterData(offsetClosecirLcleWhiteLaserEmitter)
{
   ejectionPeriodMS = 3.0;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 1.42;
   velocityVariance = 0.0;
   thetaMin         = 45;
   thetaMax         = 45.1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   useEmitterColors = True;
   //lifetimeMS = 5000;
   particles = offsetLaserParticleD;   

	uiName = "L offset Large CircleLaser";
};