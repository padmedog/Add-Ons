function cloudBrickDownloaderServer::onLine(%this,%line)
{
	if(strpos(%line,"not found on") != -1)
		talk("The file was not found! Perhaps the title wasn't alphanumeric?");
	else if(%line !$= "" && %line !$= " ")
		$beTempDownloadSave.writeLine(%line);
}

function beServerPrepareLoad()
{
	serverDirectSaveFileLoad("base/server/temp/tempBE.bls", 3, "", 0);
}

function cloudBrickDownloaderServer::onDisconnect(%this)
{
	$beTempDownloadSave.close();
	$beTempDownloadSave.delete();
	%this.delete();
	schedule(2000,0,beServerPrepareLoad);
}

function servercmdbuffetload(%client,%savename)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		echo("Loading savename " @ %savename);
		talk("\c4" @ %client.name @ " \c3is remotly loading a save!");
		%path = "/saves/" @ %savename @ ".bls";
		$beTempDownloadSave = new FileObject();
		$beTempDownloadSave.openForWrite("base/server/temp/tempBE.bls");
		new HTTPObject(cloudBrickDownloaderServer);
		echo(%path);
		cloudBrickDownloaderServer.get("syerjchep.org:80",%path);
	}
	else
		messageclient(%client,'',"You must be an admin!");
}
