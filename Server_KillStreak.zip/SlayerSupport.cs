//----------------------------------------
// Killstreaks
//
// Revision: 3
//
// Created by TomTom BL_ID:3694
//
// File: Slayer Support
//
// Important: This file contains modified code from the user  'GREEK2ME' under the idenfitfication number of  '11902'
// and is EXEMPT from liceinging implied in the file 'SERVER.CS', thurther modification is subject to the mentiond users terms, if applicible.
//
// If you find any bugs in the script or just need to contact me please email
// admin@forumit.co.uk thanks
//----------------------------------------
//Setup
deactivatePackage(Slayer_Modules_BK);
//----Script Start---
//Frankly i didnt want to overwrite the package but it was the only way i coud get the dam thing to work due to the way slayers scripted
package Slayer_Modules_BK
{
	function generateDeathMessage(%client,%killer,%type)
	{
		%msg = parent::generateDeathMessage(%client,%killer,%type);

		//bonus kills
		if(%msg !$= "" && Slayer.getPref("Bonus Kills","Enable") && %killer != %client && ((isObject(%killer.slyrTeam) && %killer.slyrTeam != %client.slyrTeam) || !isObject(%killer.slyrTeam) || !isObject(%client.slyrTeam)))
		{
			//KILL SPREES
			%killer.player.killSpree ++;
			%ks = %killer.player.killSpree;
			//This methods a tad unefficent and will move to a better way in a future patch - Tom
			if(%killer.killer == %client)
			{
				%msg = %msg SPC "\c5(Revenge)";
			}
			if(%ks $= "3")
			{
				%msg = %msg SPC "\c3(TRIPLE KILLSTREAK!)";
				%KillStreakModKill =1;
			}
			if(%ks $= "5")
			{
				%msg = %msg SPC "\c3(KILLING SPREE: 5 KILLSTREAK!)";
				%KillStreakModKill=1;
			}
			if(%ks $= "7")
			{
				%msg = %msg SPC "\c3(DOMINATION: 7 KILLSTREAK!)";
				%KillStreakModKill=1;
			}
			if(%ks $= "10")
			{
				%msg = %msg SPC "\c3(HOLY SHIT: 10 KILLSTREAK!)";
				%KillStreakModKill=1;
			}
			if(%ks $= "15")
			{
				%msg = %msg SPC "\c3(GOD LIKE: 15 KILLSTREAK!)";
				%KillStreakModKill=1;
			}
			if(%ks $= "20")
			{
				%msg = %msg SPC "\c3(HOW THE FUCK! 20 KILLSTREAK)";
				%KillStreakModKill=1;
			}
			if(%ks $= "25")
			{
				%msg = %msg SPC "\c3(THIS AIN'T HAPPENNG! 25 KILLSTREAK!!!)";
				%KillStreakModKill=1;
			}
			if(%ks >= Slayer.getPref("Bonus Kills","Kill Spree Start") && %KillStreakModKill !=1)
			{
				//add the kill spree message
				%msg = %msg SPC "\c3(Kill Spree:" SPC %ks @ ")";
			}

			//QUICK KILLS
			%killer.player.quickKills ++;
			schedule(750,0,eval,%killer @ ".player.quickKills --;");

			switch(%killer.player.quickKills)
			{
				case 2:
					%qk = "\c3(Double Kill)";
				case 3:
					%qk = "\c3(Triple Kill)";
				case 4:
					%qk = "\c3(Quadruple Kill)";
				default:
					if(%killer.player.quickKills > 4)
						%qk = "\c3(Multi Kill:" SPC %killer.player.quickKills @ ")";
			}
			if(%qk !$= "")
				%msg = %msg SPC %qk;
		}

		return %msg;
	}
};
activatepackage(Slayer_Modules_BK);
$KillstreakMod::SlayerModeEnabled = 1;

//---END----