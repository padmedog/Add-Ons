datablock ParticleData(RedSheildSParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 2000;
	lifetimeVarianceMS   = 55;
	textureName          = "./square";//	textureName          = "base/data/particles/dot";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.9 0.5 0.3 0.4";
	colors[1]     = "0.9 0.3 0.1 0.1";
	colors[2]     = "0.9 0.0 0.0 0.2";
	colors[3]     = "0.9 0.0 0.0 0.0";
	sizes[0]      = 0.35;
	sizes[1]      = 0.25;
	sizes[2]      = 0.20;
	sizes[3]      = 0.10;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.1;
	times[2]      = 0.9;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleData(RedSheildMParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 55;
	textureName          = "./square";//	textureName          = "base/data/particles/dot";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.9 0.5 0.3 0.4";
	colors[1]     = "0.9 0.3 0.1 0.1";
	colors[2]     = "0.9 0.0 0.0 0.2";
	colors[3]     = "0.9 0.0 0.0 0.0";
	sizes[0]      = 0.85;
	sizes[1]      = 0.75;
	sizes[2]      = 0.70;
	sizes[3]      = 0.60;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.15;
	times[2]      = 0.85;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleData(RedSheildLParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 55;
	textureName          = "./square";//	textureName          = "base/data/particles/dot";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.9 0.5 0.3 0.4";
	colors[1]     = "0.9 0.3 0.1 0.1";
	colors[2]     = "0.9 0.0 0.0 0.3";
	colors[3]     = "0.9 0.0 0.0 0.0";
	sizes[0]      = 1.35;
	sizes[1]      = 1.25;
	sizes[2]      = 1.20;
	sizes[3]      = 1.10;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.2;
	times[2]      = 0.8;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleData(ImpulseEngineParticle)
{
	dragCoefficient      = 0.1;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 3.0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 20.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.9 0.4";
	colors[1]     = "0.5 0.5 0.9 0.6";
	colors[2]     = "0.5 0.5 0.9 0.2";
	colors[3]     = "0.5 0.5 0.9 0.0";
	sizes[0]      = 0.05;
	sizes[1]      = 0.55;
	sizes[2]      = 0.65;
	sizes[3]      = 1.05;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.3;
	times[2]      = 0.4;
	times[3]      = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ImpulseEngineEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 3;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.5;
   thetaMin         = 20;
   thetaMax         = 32;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ImpulseEngineParticle";

   useEmitterColors = True;

    uiName = "SF Impulse Engine";
};

datablock ParticleData(ColorWaveAParticle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1625;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";//thinring;
	spinSpeed		= 20.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.2 0.0 0.5 0.4";
	colors[1]     = "0.0 0.0 0.3 0.2";
	colors[2]     = "0.2 0.0 0.6 0.3";
	colors[3]     = "0.2 0.0 0.2 0.0";
	sizes[0]      = 0.55;
	sizes[1]      = 0.50;
	sizes[2]      = 0.25;
	sizes[3]      = 0.20;
	windCoefficient = 0.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(SpinningWaveAEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 90000;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "ColorWaveAParticle";

   useEmitterColors = True;

    uiName = "SF Spinning Wave A";
};

datablock ParticleData(ColorWaveBParticle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1625;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/thinring";//thinring;
	spinSpeed		= 20.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.2 0.0 0.5 0.4";
	colors[1]     = "0.0 0.0 0.3 0.2";
	colors[2]     = "0.2 0.0 0.6 0.3";
	colors[3]     = "0.2 0.0 0.2 0.0";
	sizes[0]      = 0.55;
	sizes[1]      = 0.50;
	sizes[2]      = 0.25;
	sizes[3]      = 0.20;
	windCoefficient = 0.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(SpinningWaveBEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 10.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 90000;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "ColorWaveBParticle";

   useEmitterColors = True;

    uiName = "SF Spinning Wave B";
};

datablock ParticleData(BlackHoleSParticle)
{
	dragCoefficient      = 10;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 200;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 20.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.1 0.1 0.1 0.2";
	colors[1]     = "0.01 0.01 0.01 0.1";
	colors[2]     = "0.01 0.01 0.01 0.5";
	colors[3]     = "0.01 0.01 0.01 0.0";
	sizes[0]      = 7.35;
	sizes[1]      = 4.25;
	sizes[2]      = 3.20;
	sizes[3]      = 4.10;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.2;
	times[2]      = 0.8;
	times[3]      = 1.0;

	useInvAlpha = true;
};

datablock ParticleEmitterData(BlackHoleSEmitter)
{
   ejectionPeriodMS = 100;
   periodVarianceMS = 2;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "BlackHoleSParticle";

    uiName = "SF Black Hole";
};


datablock ParticleData(PerimeterShieldParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 0;
	textureName          = "./square";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.7 0.5 0.2 0.4";
	colors[1]     = "0.7 0.0 0.0 0.2";
	colors[2]     = "0.7 0.0 0.0 0.2";
	colors[3]     = "0.7 0.0 0.0 0.0";
	sizes[0]      = 0.30;
	sizes[1]      = 0.25;
	sizes[2]      = 0.20;
	sizes[3]      = 0.15;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.33;
	times[2]      = 0.9;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(PerimeterShieldEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 2.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PerimeterShieldParticle";

   useEmitterColors = True;

    uiName = "SF Perimeter Shield";
};

//Red Column Shields ---------------------------------------------------------
//None/removed
//Blue Column Shields --------------------------------------------------------------------

datablock ParticleData(SBlueColumnShieldParticle)
{
	textureName          = "./square";
	dragCoefficient      = 10.0;
	gravityCoefficient   = 0.0025;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 10;
	lifetimeMS           = 4000;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = 0.0;
	spinRandomMax = 0.0;
	useInvAlpha   = false;

	colors[0]	= "0.0 0.0 0.9 0.0";
	colors[1]	= "0.2 0.2 0.9 0.5";
	colors[2]	= "0.2 0.2 0.9 0.5";
	colors[3]	= "0.0 0.0 0.9 0.0";

	sizes[0]	= 0.5;
	sizes[1]	= 0.5;
	sizes[2]	= 0.5;
	sizes[3]	= 0.5;

	times[0]	= 0.0;
	times[1]	= 0.3;
	times[2]	= 0.7;
	times[3]	= 1.0;
};

datablock ParticleData(LBlueColumnShieldParticle)
{
	textureName          = "./square";
	dragCoefficient      = 10.0;
	gravityCoefficient   = 0.0025;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 10;
	lifetimeMS           = 3330;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = 0.0;
	spinRandomMax = 0.0;
	useInvAlpha   = false;

	colors[0]	= "0.0 0.0 0.9 0.0";
	colors[1]	= "0.2 0.2 0.9 0.5";
	colors[2]	= "0.2 0.2 0.9 0.5";
	colors[3]	= "0.0 0.0 0.9 0.0";

	sizes[0]	= 0.5;
	sizes[1]	= 0.5;
	sizes[2]	= 0.5;
	sizes[3]	= 0.5;

	times[0]	= 0.0;
	times[1]	= 0.3;
	times[2]	= 0.7;
	times[3]	= 1.0;
};

datablock ParticleData(XLBlueColumnShieldParticle)
{
	textureName          = "./square";
	dragCoefficient      = 10.0;
	gravityCoefficient   = 0.0025;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 10;
	lifetimeMS           = 3000;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = 0.0;
	spinRandomMax = 0.0;
	useInvAlpha   = false;

	colors[0]	= "0.0 0.0 0.9 0.0";
	colors[1]	= "0.2 0.2 0.9 0.5";
	colors[2]	= "0.2 0.2 0.9 0.5";
	colors[3]	= "0.0 0.0 0.9 0.0";

	sizes[0]	= 0.5;
	sizes[1]	= 0.5;
	sizes[2]	= 0.5;
	sizes[3]	= 0.5;

	times[0]	= 0.0;
	times[1]	= 0.3;
	times[2]	= 0.7;
	times[3]	= 1.0;
};

//extras

datablock ParticleEmitterData(SColumnShieldEmitter)
{
   ejectionPeriodMS = 62.5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionoffset   = 1.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = SBlueColumnShieldParticle;

   useEmitterColors = True;

    uiName = "SF Column Shield S";
};

datablock ParticleEmitterData(LColumnShieldEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionoffset   = 3.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 2880;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = LBlueColumnShieldParticle;

   useEmitterColors = True;

    uiName = "SF Column Shield L";
};

datablock ParticleEmitterData(XLColumnShieldEmitter)
{
   ejectionPeriodMS = 31.25;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionoffset   = 4.0;
   velocityVariance = 0.0;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiReferenceVel  = 1920;
   phiVariance      = 0;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = XLBlueColumnShieldParticle;   

   useEmitterColors = True;

	uiName = "SF Column Shield XL";
};

datablock ParticleEmitterData(SheildSEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 2.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 720;
   phiVariance      = 10;
   overrideAdvance = false;
   particles = "RedSheildSParticle";

   useEmitterColors = True;

    uiName = "SF Sheild S";
};

datablock ParticleEmitterData(SheildMEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 10.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 720;
   phiVariance      = 10;
   overrideAdvance = false;
   particles = "RedSheildMParticle";

   useEmitterColors = True;

    uiName = "SF Sheild M";
};

datablock ParticleEmitterData(SheildLEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 20.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 720;
   phiVariance      = 10;
   overrideAdvance = false;
   particles = "RedSheildLParticle";

   useEmitterColors = true;

    uiName = "SF Sheild L";
};

//------------------------------------------------------------------------------------
//Additions
//------------------------------------------------------------------------------------