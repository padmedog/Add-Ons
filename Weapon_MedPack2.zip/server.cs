%error = forceRequiredAddOn("Weapon_Spear");
if(%error $= $Error::AddOn_NotFound)
{
	error("ERROR: Weapon_MedPack2 - required add-on Weapon_Spear not found");
}
else
{
	exec("./server2.cs");
}