datablock PlayerData(SurvivorArmor : PlayerStandardArmor)
{
   cameramaxdist = 3;
   cameraVerticalOffset = 1;
   cameraHorizontalOffset = 0.8;
   cameraTilt = 0.2;
   maxfreelookangle = 2;

   runForce = 100 * 60;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 8;
   maxBackwardSpeed = 5;
   maxSideSpeed = 6;

   maxForwardCrouchSpeed = 5;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 2;

   jumpForce = 10 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;
   //firstpersononly = 1;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Survivor";
	canRide = true;
	showEnergyBar = false;

   runSurfaceAngle  = 55;
   jumpSurfaceAngle = 55;
   isSurvivor = 1;
};
datablock PlayerData(SurvivorMidHealthArmor : PlayerStandardArmor)
{
   cameramaxdist = 3;
   cameraVerticalOffset = 1;
   cameraHorizontalOffset = 0.8;
   cameraTilt = 0.2;
   maxfreelookangle = 2;

   runForce = 100 * 60;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 6;
   maxBackwardSpeed = 4;
   maxSideSpeed = 4;

   maxForwardCrouchSpeed = 4;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 2;

   jumpForce = 10 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;
   //firstpersononly = 1;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	canRide = true;
	showEnergyBar = false;

   runSurfaceAngle  = 55;
   jumpSurfaceAngle = 55;
   isSurvivor = 1;
};
datablock PlayerData(SurvivorLowHealthArmor : PlayerStandardArmor)
{
   cameramaxdist = 3;
   cameraVerticalOffset = 1;
   cameraHorizontalOffset = 0.8;
   cameraTilt = 0.2;
   maxfreelookangle = 2;

   runForce = 100 * 60;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 4;
   maxBackwardSpeed = 3;
   maxSideSpeed = 3;

   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 2;
   maxSideCrouchSpeed = 2;

   jumpForce = 10 * 90; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;
   //firstpersononly = 1;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "";
	canRide = true;
	showEnergyBar = false;

   runSurfaceAngle  = 55;
   jumpSurfaceAngle = 55;
   isSurvivor = 1;
};
function SurvivorArmor::onDamage(%this,%obj,%am)
{
	parent::onDamage(%this,%obj,%am);
	if(%obj.getdamagelevel() >= 75)
	{
		%obj.setdatablock("SurvivorLowHealthArmor");
		SurvivorNearDeathLoop(%obj);
		return;
	}
	if(%obj.getdamagelevel() >= 50)
	{
		%obj.setdatablock("SurvivorMidHealthArmor");
	}
}
function SurvivorMidHealthArmor::onDamage(%this,%obj,%am)
{
	parent::onDamage(%this,%obj,%am);
	if(%obj.getdamagelevel() >= 75)
	{
		%obj.setdatablock("SurvivorLowHealthArmor");
		SurvivorNearDeathLoop(%obj);
		return;
	}
	if(%obj.getdamagelevel() <= 50)
	{
		%obj.setdatablock("SurvivorArmor");
	}
}
function SurvivorLowHealthArmor::onDamage(%this,%obj,%am)
{
	parent::onDamage(%this,%obj,%am);
	if(%obj.getdamagelevel() <= 75)
	{
		%obj.setdatablock("SurvivorMidHealthArmor");
	}
	if(%obj.getdamagelevel() <= 50)
	{
		%obj.setdatablock("SurvivorArmor");
	}
}
function SurvivorNearDeathLoop(%obj)
{
	cancel(%obj.NearDeathSchedule);
	if(isobject(%obj) && %obj.getstate() !$= "Dead" && %obj.getdatablock().getname() $= "SurvivorLowHealthArmor")
	{
		//%obj.playpain();
		%obj.setdamageflash(0.5);
		%obj.NearDeathSchedule = schedule(5000,%obj,SurvivorNearDeathLoop,%obj);
	}
}
datablock PlayerData(DownPlayerSurvivorArmor : PlayerStandardArmor)
{
   cameramaxdist = 3;
   cameraVerticalOffset = 1;
   cameraHorizontalOffset = 0.8;
   cameraTilt = 0.2;
   maxfreelookangle = 2;
	
	mass = 500;
   runForce = 100 * 60;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;
   drag = 0.7;
   density = 0.7;

   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;

   jumpForce = 0; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	firstpersononly = 1;

	uiName = "";
	maxenergy = 100;
	maxDamage = 300;
	showEnergyBar = true;
	canRide = false;

   runSurfaceAngle  = 5;
   jumpSurfaceAngle = 5;
   isSurvivor = 1;
   boundingbox = "5 5 7.5";
   rechargerate = 0;
};
function DownPlayerSurvivorArmor::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	if(%player.ispilot())
	{
		Armor::DoDismount(%player.getdatablock(),%player);
		return;
	}
	Parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function energydamageloop(%obj)
{ 
	if(!isobject(%obj) || %obj.getstate() $= "Dead")
	{
		return;
	}
	if(%obj.getenergylevel() == 0)
	{
		%obj.kill();
		return;
	}
	if(%obj.getenergylevel() == 50)
	{
		%obj.mountimage(SaveMeMiddleImage,2);
	}
	if(%obj.getenergylevel() == 20)
	{
		%obj.mountimage(SaveMeRedImage,2);
		%obj.playpain();
	}
	%obj.setenergylevel(%obj.getenergylevel()-5);
	%obj.setdamageflash(3/%obj.getenergylevel());
	//%obj.playpain();
	%obj.energydeath = schedule(2000,0,energydamageloop,%obj);
}
function downplaykill(%obj)
{
	%obj.kill();
}
function DownPlayerSurvivorArmor::ondisabled(%this,%obj,%n)
{	
	//%obj.changedatablock("DownPlayerSurvivorArmor");
	//%obj.sethealth(100);
	//%obj.playthread(1,sit);
	%obj.mountimage(DeathXImage,2);
	parent::ondisabled(%this,%obj,%n);
	%obj.downer = 0;
	if(%obj.client.minigame.PlayersCanRespawn == 1)
	{
		%obj.client.NoRespawn = 1;
		%obj.client.lastplayerobserved = 0;
		%obj.isdowned = 0;
		zIsEveryoneDead(%obj.client.minigame);
	}
}
function ResetBottomP(%minmemb,%n)
{
	if(isobject(%minmemb))
	{
	if(%n == 0)
		{
			%minmemb.bottomprint("<just:center><color:FFBBBB>Minigame Reset.",5);
			return;
		}
	%minmemb.bottomprint("<just:center><color:FFBBBB>The survivors have been overwhelmed, Minigame Resetting in" SPC %n SPC "seconds.",2);
	}
}
function AllPlayerDeadRestart(%minigame)
{
	if(isobject(%minigame))
	{
		%minigame.reset(%minigame.owner);
	}
}
function DownPlayerSurvivorArmor::onAdd(%this,%obj)
{
	echo("Yeah I'm an idiot");
	if(isobject(%obj.downer))
	{
		chatMessageTeam(%obj.client,'fakedeathmessage',"Zombie" SPC %obj.downer.name SPC "Downed <bitmapk:add-ons/gamemode_zombie/zombieci>" SPC %obj.client.name);
	}
	%obj.playthread(1,sit);
	parent::onAdd(%this,%obj);

}
function DownTimeout(%this)
{
	if(isobject(%this))
	{
	%this.downtimeout = 0;
	}
}
function MeleeTimeout(%this)
{
	if(isobject(%this))
	{
	%this.meleetimeout = 0;
	}
}
function centerprintcounter(%obj,%amount)
	{
		%client = %obj.client;
		%per = %amount/4*100;
		%maxcounters = 20;
		%char = "|";for(%a =0; %a<%per/5; %a++){%fchar = %char @ %fchar;}
		centerprint(%client,"<just:center><color:FF0000>Get Up! <color:FFFFFF>: <just:left><color:FFFF00>" @ %fchar,1);
	}

function MeleeMe(%this)
	{
		if(%this.isdowned == 0 && IsInMinigame(%this))
		{
			%eyeVec = %this.getEyeVector();

			%startPos = %this.getEyePoint();
			%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,3));

			%mask = $TypeMasks::PlayerObjectType;
			%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
			if(%target)
			{
				%this.playaudio(1,ZombieAttackSound);
				//if(IsInMinigame(%obj) && MinigameIncludesPlayerBricks(%col) && %col.iszombie && %obj.getstate() !$= "Dead")
				//{if(IsInMinigame(%obj) && IsInSameMinigame(%col,%obj) && %obj.getstate() !$= "Dead" && %obj.spawnbrick.getgroup().client.minigame.EnableZombies == 1)
				if(IsInMinigame(%target) && IsInSameMinigame(%this,%target))
				{
					if(%target.getclassname() $= "AiPlayer")
					{
						%target.applyimpulse(%target.getposition(),vectoradd(vectorscale(%this.getforwardvector(),2000),"0 0 500"));
						%dam = 20;
						if(%target.getdatablock().getname() $= RotBoomerZombie)
						{
							%dam = 2;
						}
						%target.damage(%this,0,%dam,$DamageType::zombiebite);
						if(%target.getdamagepercent() != 1)
						{
							%target.playaudio(0,ZombiePainSound);
						}
					}
					if(%target.getclassname() $= "Player")
					{
						if(isobject(%target.strangler))
						{		
							cancel(%target.strangler.fspecsched);
							%target.client.setcontrolobject(%target);
							%target.strangler.tongue.delete();
							%target.strangler.isstrangling = 0;
							%target.strangler = "";
						}
						if(%this.client.minigame.weapondamage)
						{
							%target.applyimpulse(%target.getposition(),vectoradd(vectorscale(%this.getforwardvector(),500),"0 0 500"));
						}
					}
				}
					//%obj.playthread(2,activate2);
				//}
			}
		}
	}

function Getupnow(%this)
	{
		if(%this.isdowned == 0 && IsInMinigame(%this))
		{
			%eyeVec = %this.getEyeVector();

			%startPos = %this.getEyePoint();
			%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,3));

			%mask = $TypeMasks::PlayerObjectType;
			%target = ContainerRayCast(%startPos, %endPos, %mask,%this);
			if(%target)
			{
				if (%target.getclassname() $= "Player" && %target.isdowned && IsInSameMinigame(%this,%target) && %this.savetimer < 4)
				{	
					
					%this.savetimer += 1;
					if(%this.issavior != 1)
					{
						%this.issavior = 1;
						%this.playthread(1,armreadyright);
					}
					centerprintcounter(%this,%this.savetimer);
					centerprintcounter(%target,%this.savetimer);
					%this.savesched = schedule(1000,0,Getupnow,%this);
					//return;
				}
				if (%target.getclassname() $= "Player" && %target.isdowned && IsInSameMinigame(%this,%target) && %this.savetimer == 4)
				{
					centerprintcounter(%this,%this.savetimer);
					%target.isdowned = 0;
					%target.changedatablock(%target.lastknowndatablock);
					//%target.sethealth(100);

					//%this.stopthread(1);
					//%this.issavior = 0;
					%this.hadlasttarget = 0;

					%target.playthread(0,root);
					%target.unmountimage(2);
					%target.setdamagelevel(1);
					%target.setdamagelevel(0);
					%target.temporaryHPSet = 75;
					%target.doHPBleed();
					%target.client.centerprint("<color:AAFFAA>You were saved by " @ %this.client.name,5);
					%this.client.incscore(%this.client.minigame.Points_HelpPlayer);
					%this.savetimer = 0;
					cancel(%target.energydeath);
					%target.mountimage(LoveImage,2);
					return;
				}
			}
			//else
			//{
			//	if(%this.issavior == 1 && %this.hadlasttarget == 1)
				//	{
					//	%this.issavior = 0;
					//	%this.stopthread(1);
					//	%this.hadlasttarget = 0;
				//	}
			//}
		}
	}


function findNextMinigamePlayer(%minigame,%client)
{
	%playernum = %minigame.numMembers;

	%client.lastplayerobserved+=1;
	if(%client.lastplayerobserved >= %playernum)
	{
		%client.lastplayerobserved = 0;
	}
	return %minigame.member[%client.lastplayerobserved];
	
}
function findPrevMinigamePlayer(%minigame,%client)
{
	%playernum = %minigame.numMembers;

	%client.lastplayerobserved-=1;
	if(%client.lastplayerobserved < 0)
	{
		%client.lastplayerobserved = %playernum-1;
	}
	return %minigame.member[%client.lastplayerobserved];
}
function zIsEveryoneDead(%minigame)
{
	if(%minigame.survivorsOverwhelmed)
	{
		return;
	}
	%base = 0;
	for(%a = 0; %a < %minigame.numMembers; %a++)
	{
		%player = %minigame.member[%a].player;
		if(%player.isdowned || !isobject(%player))
		{
			%base+=1;
		}
		if(isobject(%player) && %player.getstate() $= "Dead")
		{
			%base+=1;
		}
	}
	if(%base == %minigame.numMembers)
	{
		%minigame.play2dSoundAll("DirectorGameOversound");
		for(%a= 0;%a <= %minigame.numMembers-1; %a++)
		{
			%minmemb = %minigame.member[%a];
			ResetBottomP(%minmemb,5);
			schedule(1000,0,ResetBottomP,%minmemb,4);
			schedule(2000,0,ResetBottomP,%minmemb,3);
			schedule(3000,0,ResetBottomP,%minmemb,2);
			schedule(4000,0,ResetBottomP,%minmemb,1);
			schedule(5000,0,ResetBottomP,%minmemb,0);
		}
		%minigame.survivorsOverwhelmed = 1;
		schedule(5000,0,AllPlayerDeadRestart,%minigame);
	}
}