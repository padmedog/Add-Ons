// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-----------------------------+-------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

//CURRENT BUGS:
// - On test map #4, bot diverts from path en route to 2nd rally node, jumping barrier. Possible bug.

//TO-DO
// - Check for new objectives once we run out.
// - Implement jump-search pathfinding

if(($AddOnLoaded__["Bot_Hole"] != 1 && $AddOn__["Bot_Hole"] != 1) || ($AddOnLoaded__["Bot_Blockhead"] != 1 && $AddOn__["Bot_Blockhead"] != 1))
{
	Slayer_Support::Debug(0,"\c2Failed to load bots.cs","Bot_Hole and Bot_Blockhead must be enabled.");
	return;
}

$Slayer::Server::Bots::Priority["CP"] = 200;
$Slayer::Server::Bots::Priority["RN"] = 100;

//POSSIBLY REMOVE THIS
Slayer.Prefs.addPref("Bots","Complete Objectives En Route","%mini.bots_objectivesEnRoute","bool",1,0,0,-1,"Advanced");

//Slayer.Prefs.addPref("Bots","Automatic Set Type","%mini.bots_autoSetType","bool",1,0,0,-1,"Advanced");
//Slayer.Prefs.addPref("Bots","Preferred Player Count","%mini.botFillLimit","int 0 99",0,0,1,2,"Rules ALL Mode");


//Instead of deleting the AiConnection, this recycles it and places it in a SimSet to await use.
//Blockland crashes once ~3500 AiConnections have been created.
function AiConnection::recycle(%this)
{
	cancel(%this.respawnSchedule);

	if(isObject(%this.minigame))
		%this.minigame.removeMember(%this);

	if(isObject(%this.camera))
		%this.camera.delete();
	if(isObject(%this.player))
		%this.player.delete();
	if(isObject(%this.tempBrick))
		%this.tempBrick.delete();
	if(isObject(%this.brickGroup) && %this.brickGroup.client == %this)
		%this.brickGroup.client = -1;

	%index = 0;
	while((%field = %this.getTaggedField(%index)) !$= "")
	{
		//some fields cannot be changed once set.... Thanks, Badspot.
		if(%lastField $= %field)
		{
			%index ++;
			continue;
		}
		%lastField = %field;
		%field = getField(%field,0);

		//Prevent people from breaking things
		if(%field !$= stripChars(%field," `~!@#$%^&*()-=+[{]}\\|;:\'\",<.>/?"))
		{
			Slayer_Support::Error("AiConnection::recycle","Invalid field! Skipping...");
			%index ++;
			continue;
		}

		Slayer_Support::setDynamicVariable(%this @ "." @ %field,"");
	}

	if(!isObject(aiRecycler))
	{
		new SimSet(aiRecycler);
		missionCleanup.add(aiRecycler);
	}

	aiRecycler.add(%this);
}

//Tasks the bot with a series of objectives to complete.
//Objectives can include rally nodes, capture points, CTF flags, etc.
//Default objective priorities: RN 100; CP 200;
//@return	bool	Whether any objectives were added.
//@see	AiConnection::addObjective
function AiConnection::assignObjectives(%this)
{
	%numObjectives = %this.numObjectives;
	%mini = %this.minigame;
	%team = %this.slyrTeam;

	if(isFunction("Slayer_" @ %mini.mode @ "_assignBotObjectives"))
	{
		%callback = call("Slayer_" @ %mini.mode @ "_assignBotObjectives",%mini,%this);
		if(%callback == -1)
			return (%this.numObjectives > %numObjectives);
	}

	//Rally nodes are now assigned every time the bot spawns.

	if(isObject(%team))
	{
		//Capture Points
		%count = Slayer.capturePoints.getCount();
		for(%i = 0; %i < %count; %i ++)
		{
			%cp = Slayer.capturePoints.getObject(%i);

			%blid = %cp.getGroup().bl_id;
			if(%canUse[%blid] $= "")
				%canUse[%blid] = miniGameCanUse(%this,%cp);

			if(%canUse[%blid])
			{
				if(%cp.getControl() != %team.color)
				{
					%this.addObjective(%cp,$Slayer::Server::Bots::Priority["CP"],"CP");
				}
			}
		}
	}

	return (%this.numObjectives > %numObjectives);
}

//Adds an objective to the bot's objective queue.
//@param	fxDtsBrick objective	This brick will be added to the queue. It must be in range of the node graph.
//@param	int priority	The importance of this objective, 0 being the lowest priority.
//@param	string callbackID	The ID for the completion callback. If the callbackID is "test", the callback would be "Slayer_onBotObjectiveReached_test(%mini,%bot,%obj)"
//@return	bool	Whether the objective was successfully added.
//@see	AiConnection::removeObjective
//@see	AiConnection::isObjective
//@see	AiConnection::assignObjectives
function AiConnection::addObjective(%this,%objective,%priority,%callbackID)
{
	if(!isObject(%objective) || %this.isObjective(%objective))
		return false;

	if(%this.numObjectives $= "")
		%this.numObjectives = 0;

	%this.objectiveID[%objective] = %this.numObjectives;
	%this.objective[%this.numObjectives] = %objective;
	%this.objectivePriority[%this.numObjectives] = %priority;
	%this.objectiveCallbackID[%this.numObjectives] = %callbackID;
	%this.numObjectives ++;

	return true;
}

//Checks whether a bot has an object in its objective array.
//@param	fxDtsBrick objective	The objective to check.
//@return	bool	Whether the bot has the objective.
//@see	AiConnection::addObjective
//@see	AiConnection::removeObjective
function AiConnection::isObjective(%this,%objective)
{
	for(%i = 0; %i < %this.numObjectives; %i ++)
	{
		if(nameToID(%this.objective[%i]) == nameToID(%objective))
			return true;
	}
	return false;
}

//Removes an objective from the bot's objective array.
//@param	fxDtsBrick objective	The objective to remove.
//@return	bool	Whether the objective was successfully removed.
//@see	AiConnection::addObjective
//@see	AiConnection::removeAllObjectives
//@see	AiConnection::isObjective
function AiConnection::removeObjective(%this,%objective)
{
	%found = false;

	for(%i = 0; %i < %this.numObjectives; %i++)
	{
		if(%found)
		{
			%this.objectiveID[%this.objective[%i]] --;
			%this.objective[%i] = %this.objective[%i + 1];
			%this.objectivePriority[%i] = %this.objectivePriority[%i + 1];
			%this.objectiveCallbackID[%i] = %this.objectiveCallbackID[%i + 1];
		}
		else if(nameToID(%this.objective[%i]) == nameToID(%objective))
		{
			%found = true;
			%i --;
			continue;
		}
	}

	if(%found)
	{
		%this.numObjectives --;
		%this.objectiveID[%objective] = "";
		%this.objective[%this.numObjectives] = "";
		%this.objectivePriority[%this.numObjectives] = "";
		%this.objectiveCallbackID[%this.numObjectives] = "";
	}
	else
	{
		Slayer_Support::Error("AiConnection::removeObjective","Objective does not exist.");
	}

	return %found;
}

//Removes all objectives
//@see	AiConnection::removeObjective
function AiConnection::removeAllObjectives(%this)
{
	for(%i = %this.numObjectives - 1; %i >= 0; %i --)
		%this.removeObjective(%this.objective[%i]);
}

//Finds the current objective that the bot is trying to reach.
//@return	fxDtsBrick	The objective.
function AiConnection::getCurrentObjective(%this)
{
	if(!isObject(%this.player))
		return 0;
	if(!isObject(%this.player.objective))
		return 0;
	return %this.player.objective;
}

//Finds the next objective for the bot to complete.
//@param	bool closestFirst	If true, will find the closest, highest-priority objective rather than highest-priority in order of addition.
//@return	fxDtsBrick	Returns the object ID of the objective that was found.
//@see	AiConnection::goToNextObjective
function AiConnection::getNextObjective(%this,%closestFirst)
{
	%priority = -1;
	%objective = 0;
	if(1 == 0 && %closestFirst && isObject(%this.player))
	{
		%distance = 999999;
		for(%i = 0; %i < %this.numObjectives; %i ++)
		{
			if(%this.objectivePriority[%i] > %priority)
			{
				%priority = %this.objectivePriority[%i];
				%distance = pathDistance(%this,%this.objective[%i]);
				%objective = %this.objective[%i];
			}
			else if(%this.objectivePriority[%i] == %priority)
			{
				%dist = pathDistance(%this,%this.objective[%i]);
				if(%dist > %distance)
				{
					%distance = %dist;
					%objective = %this.objective[%i];
				}
			}
		}
	}
	else
	{
		for(%i = %this.numObjectives - 1; %i >= 0; %i --)
		{
			if(%this.objectivePriority[%i] >= %priority)
			{
				%priority = %this.objectivePriority[%i];
				%objective = %this.objective[%i];
			}
		}
	}
	return %objective;
}

//Sends the bot to its next objective.
//@param	bool closestFirst	Please see AiConnection::getNextObjective for more information.
//@see	AiConnection::getNextObjective
//@see	AiPlayer::goToObjective
function AiConnection::goToNextObjective(%this,%closestFirst)
{
	if(!isObject(%this.player))
		return;

	%objective = %this.getNextObjective(%closestFirst);
	if(!isObject(%objective))
		return;

	%this.player.goToObjective(%objective);
}

//Called when a bot reaches its objective.
//If a callback exists (Slayer_onBotObjectiveReached_callbackID), it will be called.
//If the callback returns true, or if there is no callback, the bot will proceed to the next objective.
//@param	fxDtsBrick objective	The objective that was reached.
//@see	AiConnection::onObjectiveFailed
//@see	Slayer_NodeTriggerData::onEnterTrigger
function AiConnection::onObjectiveReached(%this,%objective)
{
	Slayer_Support::Debug(2,"AiConnection::onObjectiveReached",%this TAB %objective);

	//restore bot properties
	%this.player.hWander = %this.player.hOldWander;

	%callbackID = %this.objectiveCallbackID[%this.objectiveID[%objective]];
	%callback = "Slayer_onBotObjectiveReached_" @ %callbackID;

	if(isFunction(%callback))
		%callbackReturn = call(%callback,%this.minigame,%this,%objective);

	%removed = %this.removeObjective(%objective);

	if(!%removed)
	{
		Slayer_Support::Error("AiConnection::onObjectiveReached","Cannot remove objective, stopping!");
		return;
	}

	if(%callbackReturn != -1)
	{
		if(isObject(%this.player))
			%this.player.objective = "";
		%this.goToNextObjective(true);
	}
}

//Called when a bot is unable to reach its objective.
//If a callback exists (Slayer_onBotObjectiveFailed_callbackID), it will be called.
//If the callback returns true, or if there is no callback, the bot will proceed to the next objective.
//@param	fxDtsBrick objective	The objective that was reached.
//@see	AiConnection::onObjectiveReached
//@see	Slayer_NodeTriggerData::onEnterTrigger
function AiConnection::onObjectiveFailed(%this,%objective)
{
	Slayer_Support::Debug(2,"AiConnection::onObjectiveFailed",%this TAB %objective);

	%callbackID = %this.objectiveCallbackID[%this.objectiveID[%objective]];
	%callback = "Slayer_onBotObjectiveFailed_" @ %callbackID;

	if(isFunction(%callback))
		%callbackReturn = call(%callback,%this.minigame,%this,%objective);

	if(%callbackReturn != -1)
	{
		%removed = %this.removeObjective(%objective);
		if(!%removed)
		{
			Slayer_Support::Error("AiConnection::onObjectiveFailed","Cannot remove objective, stopping!");
			return;
		}

		if(isObject(%this.player))
			%this.player.objective = "";
		%this.goToNextObjective(true);
	}
}

//Sends the bot to an objective.
//@param	fxDtsBrick objective
//@return	fxDtsBrick	The path the bot will use.
//@see	AiConnection::goToNextObjective
//@see	Slayer_onBotPathFound
function AiPlayer::goToObjective(%this,%objective)
{
	%position = %this.getHackPosition();
	%closestNode = Slayer.PathHandler.findClosestNode(%position,true);
	if(!isObject(%closestNode))
		%closestNode = Slayer.PathHandler.findClosestNode(%position,false);
	if(!isObject(%closestNode))
	{
		Slayer_Support::Error("AiPlayer::goToObjective","No nearby node found!");
		return 0;
	}

	%this.objective = %objective;
	%this.objectiveReached = false;

	if(%objective.position $= "")
	{
		Slayer_Support::Error("AiPlayer::goToObjective","Invalid objective, position undefined");
		return 0;
	}
	else if(!Slayer.PathHandler.nodes.isMember(%objective))
	{
		Slayer.PathHandler.addNode(%objective);
	}

	%this.hPathBrick = 0;

	%path = Slayer.PathHandler.findPath(%closestNode,%objective,"Slayer_onBotPathFound");
	%path.bot = %this;
	%this.path = %path;

	Slayer_Support::Debug(2,"AiPlayer::goToObjective","Using path" SPC %path);

	return %path;
}

//Sends the bot to the next node in their path.
//@return	fxDtsBrick	The next node in the path.
//@private
function AiPlayer::pathStep(%this)
{
	if(!isObject(%this.path))
		return 0;

	%node = getWord(%this.path.result,%this.pathIndex);
	if(!isObject(%node))
		return 0;

	Slayer_Support::Debug(2,"AiPlayer::pathStep",%this.pathIndex SPC %node);

	%this.hPathBrick = %node;

	cancel(%this.hSched);
	%this.hSched = 0;

	%this.hLoop();
	%this.hSkipOnReachLoop = true;

	return %node;
}

//Causes the AiPlayer to equip a pseudo-random tool from their inventory.
//Lower items in the tool array will have a higher probability of being chosen.
//For example, tool[0] has a higher probability than tool[4].
//@return	Item	The tool that was selected.
function AiPlayer::useRandomTool(%this)
{
	%maxTools = %this.getDatablock().maxTools;
	for(%i = 0; %i < %maxTools; %i ++)
	{
		if(isObject(%this.tool[%i]))
			%indexEnd = %i + 1;
	}

	for(%i = 0; %i < %indexEnd; %i ++)
	{
		if(isObject(%this.tool[%i]) && (getRandom(0,1) || %i == %indexEnd - 1))
		{
			%this.setWeapon(%this.tool[%i]);
			return %this.tool[%i];
		}
	}

	return 0;
}

//Detects when a bot has reached the next node.
//@param	Trigger trigger	The trigger that was reached. %trigger.brick is the actual node.
//@param	AiPlayer bot	The AIPlayer that reached the trigger.
//@see	AiConnection::onObjectiveReached
//@private
function Slayer_NodeTriggerData::onEnterTrigger(%this,%trigger,%bot)
{
	if(!%bot.isSlayerBot)
		return;

	%brick = %trigger.brick;
	if(!isObject(%brick))
	{
		Slayer_Support::Error("Slayer_NodeTriggerData::onEnterTrigger","Rogue node trigger found! Deleting...");
		%trigger.delete();
		return;
	}

	%ai = %bot.client;
	if(!isObject(%ai))
		return;

	Slayer_Support::Debug(2,"Slayer_NodeTriggerData::onEnterTrigger",%trigger TAB %brick TAB %bot TAB %ai);

	if(%bot.hPathBrick == %brick)
	{
		%bot.hPathBrick = 0;
		%bot.hLoop();
		%bot.hSkipOnReachLoop = true;

		if(%bot.objective == %brick)
		{
			if(!%bot.objectiveReached)
			{
				%bot.objectiveReached = true;
				%ai.onObjectiveReached(%brick);
			}
		}
		else if(%mini.bots_objectivesEnRoute && %ai.isObjective(%brick))
		{
			if(!%bot.objectiveReached)
			{
				%bot.objective = %brick;
				%bot.objectiveReached = true;
				%ai.onObjectiveReached(%brick);
			}
		}
		else
		{
			%bot.pathIndex ++;
			%bot.pathStep();
		}
	}
}

//Called when a path has been completely calculated.
//@param	ScriptObject path	The path object.
//@param	string result	A space-delimited list of nodes in the path.
//@see	AiPlayer::goToObjective
//@private
function Slayer_onBotPathFound(%path,%result)
{
	%bot = %path.bot;
	if(!isObject(%bot) || %bot.path != %path)
		return;

	%ai = %bot.client;
	if(!isObject(%ai))
		return;

	if(%result $= "")
	{
		%ai.onObjectiveFailed(%bot.objective);
		%path.delete();
	}
	else
	{
		//Check if the bot is already at the first node
		%start = firstWord(%result);
		%trigger = %start.nodeTrigger;
		if(isObject(%trigger))
		{
			for(%i = 0; %i < %trigger.getNumObjects(); %i ++)
			{
				%obj = %trigger.getObject(%i);
				if(%obj == %bot)
				{
					%skip0 = true;
					break;
				}
			}
		}

		//Disable wandering while on the path.
		%bot.hOldWander = %bot.hWander;
		%bot.hWander = false;

		%bot.pathIndex = (%skip0 ? 1 : 0);
		%bot.pathStep();
	}
}

// +--------------------+
// | Packaged Functions |
// +--------------------+
package Slayer_Dependencies_Bots
{
	//Creates an AiPlayer object for the AiConnection.
	//@param	transform transform	The initial transform for the new player.
	//@return	AiPlayer	The AiPlayer object that was created.
	//@see	AiConnection::spawnPlayer
	//@private
	function AiConnection::createPlayer(%this,%transform)
	{
		%mini = getMinigameFromObject(%this);
		if(isSlayerMinigame(%mini) && %this.isHoleBot)
		{
			if(isObject(%this.lastSpawnBrick))
			{
				%spawnBrick = %this.lastSpawnBrick;
			}
			else
			{
				//This is a hack to allow Hole Bots to spawn without a spawnbrick.
				if(!isObject(SlayerFakeBrick))
				{
					new fxDtsBrick(SlayerFakeBrick)
					{
						datablock = brick1x1Data;
						isPlanted = false;
						itemPosition = 1;
						position = "0 0 -2000";
					};
					Slayer.add(SlayerFakeBrick);
				}
				%spawnBrick = SlayerFakeBrick;
				%useFakeBrick = true;
			}

			%this.hName = "";

			%team = %this.getTeam();
			%handler = (isObject(%team) ? %team : %mini);

			%pos = getWords(%transform,0,2);
			%rot = getWords(%transform,3,6);
			%hBotType = BlockheadHoleBot; //this should be changeable
			%hDamageType = %hBotType.hMeleeCI;

			%player = new AiPlayer()
			{
				client = %this;
				dataBlock = %handler.playerDatablock;
				isHoleBot = 1;
				isSlayerBot = 1;
				path = "";
				spawnBrick = %spawnBrick;

				position = %pos;
				hGridPosition = %pos;
				rotation = %rot;
						
				//Apply attributes to Bot
				Name = %hBotType.hName;
				hType = "mercenary"; //%hBotType.hType;
				hDamageType = (strLen(%damageType) > 0 ? $DamageType["::" @ %damageType] : $DamageType::HoleMelee);
				hSearchRadius = %hBotType.hSearchRadius;
				hSearch = %hBotType.hSearch;
				hSight = %hBotType.hSight;
				hWander = %hBotType.hWander;
				hGridWander = %hBotType.hGridWander;
				hReturnToSpawn = !%useFakeBrick; //%hBotType.hReturnToSpawn;
				hSpawnDist = %hBotType.hSpawnDist;
				hMelee = %hBotType.hMelee;
				hAttackDamage = %hBotType.hAttackDamage;
				hSpazJump = %hBotType.hSpazJump;
				hSearchFOV = %hBotType.hSearchFOV;
				hFOVRadius = %hBotType.hFOVRadius;
				hTooCloseRange = %hBotType.hTooCloseRange;
				hAvoidCloseRange = %hBotType.hAvoidCloseRange;
				hShoot = %hBotType.hShoot;
				hMaxShootRange = %hBotType.hMaxShootRange;
				hStrafe = %hBotType.hStrafe;
				hAlertOtherBots = %hBotType.hAlertOtherBots;
				hIdleAnimation = %hBotType.hIdleAnimation;
				hSpasticLook = %hBotType.hSpasticLook;
				hAvoidObstacles = %hBotType.hAvoidObstacles;
				hIdleLookAtOthers = %hBotType.hIdleLookAtOthers;
				hIdleSpam = false; //%hBotType.hIdleSpam;
				hAFKOmeter = %hBotType.hAFKOmeter + getRandom( 0, 2 );
				hHearing = %hBotType.hHearing;
				hIdle = %hBotType.hIdle;
				hSmoothWander = %hBotType.hSmoothWander;
				hEmote = %hBotType.hEmote;
				hSuperStacker = %hBotType.hSuperStacker;
				hNeutralAttackChance = %hBotType.hNeutralAttackChance;
				hFOVRange = %hBotType.hFOVRange;
				hMoveSlowdown = %hBotType.hMoveSlowdown;
				hMaxMoveSpeed = 1.0;
				hActivateDirection = %hBotType.hActivateDirection;
			};
			%this.player = %player;
			missionCleanup.add(%player);

			for(%i = 0; %i < %handler.playerDatablock.maxTools; %i ++)
				%this.forceEquip(%i,%handler.startEquip[%i]);

			if(%handler == %team)
			{
				%ps = %team.playerScale;
				if(%ps != 1)
					%player.setScale(%ps SPC %ps SPC %ps);
	
				%this.applyUniform();
			}

			%player.setShapeNameColor(%handler.colorRGB);

			%spawnBrick.hBot = %player;
			%spawnBrick.onBotSpawn();

			return %player;
		}
		else
			return parent::createPlayer(%this,%transform);
	}

	//Picks a spawn point and then spawns an AiPlayer.
	//@return	AiPlayer	The AiPlayer object that was created.
	//@see	AiConnection::onSpawn
	//@see	AiConnection::createPlayer
	function AiConnection::spawnPlayer(%this)
	{
		if(%this.isSlayerBot)
		{
			if(%this.isHoleBot && isObject(%this.spawnBrick))
				return %this.spawnBrick.spawnHoleBot();

			%mini = getMinigameFromObject(%this);
			if(isSlayerMinigame(%mini))
			{
				if(isObject(%this.player))
					%this.player.delete();

				%player = %this.createPlayer(%mini.pickSpawnPoint(%this));
				if(!isObject(%player))
					return 0;

				%this.onSpawn();

				return %player;
			}
			else
			{
				Slayer_Support::Error("AiConnection::spawnPlayer","Rogue AiConnection! Deleting...");
				%this.recycle();
				return 0;
			}
		}
		return parent::spawnPlayer(%this);
	}

	//Called after an AiPlayer has been spawned.
	function AiConnection::onSpawn(%this)
	{
		if(%this.isSlayerBot)
		{
			%mini = %this.minigame;
			%team = %this.slyrTeam;

			%this.player.useRandomTool();

			//Add rally nodes to the bot's objective queue.
			%count = Slayer.PathHandler.rallyNodes.getCount();
			for(%i = 0; %i < %count; %i ++)
			{
				%node = Slayer.PathHandler.rallyNodes.getObject(%i);

				%blid = %node.getGroup().bl_id;
				if(%canUse[%blid] $= "")
					%canUse[%blid] = miniGameCanUse(%this,%node);

				if(%canUse[%blid])
				{
					%control = %node.getControl();
					if(%control == %team.color || %mini.teams.isNeutralColor(%control))
					{
						%this.addObjective(%node,$Slayer::Server::Bots::Priority["RN"],"RN");
					}
				}
			}

			//We need to direct bots to their objectives.
			//Let's make sure that we don't have to
			//direct all the bots at once.
			%time = 100 + getRandom(900);
			%this.scheduleNoQuota(%time,"goToNextObjective",true);
		}
		else
			return parent::onSpawn(%this);
	}

	//Called when an AiConnection's AiPlayer is killed.
	function AiConnection::onDeath(%this,%obj,%killer,%type,%area)
	{
		parent::onDeath(%this,%obj,%killer,%type,%area);
		%mini = getMinigameFromObject(%this);
		if(isSlayerMinigame(%mini) && %this.isSlayerBot && !isObject(%this.spawnBrick))
		{
			if(!%this.dead())
			{
				%spawnTime = %mini.botRespawnTime;
				%this.respawnSchedule = %this.scheduleNoQuota(%spawnTime,"spawnPlayer");
			}
		}
	}

	//Called when an AiConnection leaves the game (is deleted).
	function AiConnection::onDrop(%this,%a)
	{
		if(isSlayerMinigame(%this.minigame))
			%this.minigame.removeMember(%this);
		if(isObject(%this.player))
			%this.player.delete();
		return parent::onDrop(%this,%a);
	}

	//@private
	function AiPlayer::hLoop(%this)
	{
		if(%this.isSlayerBot)
		{
			//Prevent the bot from being deleted when its owner leaves.
			%itemPos = %this.spawnBrick.itemPosition;
			%this.spawnBrick.itemPosition = 1;

			//Allow bots to work when "Include All Players' Bricks" is disabled.
			//Slayer minigames have an owner of 0. That both causes this problem
			//and makes it easy to fix.
			%brickClient = %this.spawnBrick.getGroup().client;
			%this.spawnBrick.getGroup().client = 0;

			%parent = parent::hLoop(%this);

			//Course correction
			if(%this.hOffCourse && (%this.hState !$= "Following" || !isObject(%this.hFollowing)))
			{
				%this.hOffCourse = false;
				%this.goToObjective(%this.objective);
			}

			//Check if we are off-course
			if((%this.hState $= "Following" || isObject(%this.hFollowing)) && isObject(%this.objective) && !%this.objectiveReached)
				%this.hOffCourse = true;

			//Restore the old values.
			%this.spawnBrick.itemPosition = %itemPos;
			%this.spawnBrick.getGroup().client = %brickClient;

			return %parent;
		}

		return parent::hLoop(%this);
	}

	//Used by events to change the bot's name.
	//@param	name	The new name of the bot.
	function AiPlayer::setBotName(%this,%name)
	{
		parent::setBotName(%this,%name);
		if(%this.isSlayerBot && isObject(%this.client))
			%this.client.hName = %name;
	}

	//Determines whether hole bots are on the same team.
	//This is for hole bot compatibility.
	//@see minigameCanDamage
	//@private
	function checkHoleBotTeams(%obj,%target,%neutralAttack,%melee)
	{
		%mini = getMinigameFromObject(%obj);
		if(isSlayerMinigame(%mini) && %mini.Gamemode.teams)
		{
			%clientA = Slayer_Support::getClientFromObject(%obj);
			%clientB = Slayer_Support::getClientFromObject(%target);
			%teamA = (isObject(%clientA) ? %clientA.getTeam() : 0);
			%teamB = (isObject(%clientB) ? %clientB.getTeam() : 0);
			if(isObject(%teamA))
			{
				if(%teamA.isAlliedTeam(%teamB))
					return 0;
			}
		}
		return parent::checkHoleBotTeams(%obj,%target,%neutralAttack,%melee);
	}

//	function fxDtsBrick::onBotSpawn(%this)
//	{
//		parent::onBotSpawn(%this);
//
//		%bot = %this.hBot;
//		if(isObject(%bot))
//		{
//			%mini = getMinigameFromObject(%this);
//			if(isSlayerMinigame(%mini))
//			{
//				if(!isObject(%bot.client))
//				{
//					if(!isObject(%this.aiClient))
//					{
//						%this.aiClient = new AiConnection()
//						{
//							bl_id = getBL_IDFromObject(%this);
//							spawnBrick = %this;
//							isHoleBot = 1;
//						};
//					}
//					%bot.client = %this.aiClient;
//					%bot.client.player = %bot;
//					%bot.client.bot = %bot;
//				}
//
//				if(!%mini.isMember(%bot.client))
//					%mini.addMember(%bot.client);
//
//				if(%this.getDatablock().slyrType $= "TeamBotHole")
//				{
//					%color = %this.getColorID();
//					%team = getField(%mini.Teams.getTeamsFromColor(%color),0);
//					if(isObject(%team) && %team != %bot.client.slyrTeam)
//						%team.addMember(%bot.client,"",1);
//					if(isObject(%bot.client.slyrTeam))
//					{
//						%bot.client.applyUniform();
//						if(%mini.bots_autoSetType)
//							%bot.hType = "mercenary";
//					}
//				}
//			}
//		}
//	}

	//@deprecated
	function fxDtsBrick::spawnHoleBot(%this)
	{
		if(!%this.getDatablock().isBotHole || (isObject(%this.aiClient) && %this.aiClient.dead()))
			return 0;
		else
			return parent::spawnHoleBot(%this);
	}
};
activatePackage(Slayer_Dependencies_Bots);

$Slayer::Server::Dependencies::Bots = 1;
Slayer_Support::Debug(2,"Dependency Loaded","Bots");