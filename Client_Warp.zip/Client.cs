$remapDivision[$remapCount]	= "Warp Keybind";
$remapName[$remapCount]		= "Warp";
$remapCmd[$remapCount]		= "Warp";
$remapCount++;

function Warp(%on)
{
	if(!%on)
	{
		return;
	}
	commandToServer('warp');
}
