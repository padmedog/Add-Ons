package SupportPlayerPersistencePackage
{
   function RegisterPersistenceVar(%name, %matchAll, %matchDataBlock)
   {
      if(%matchAll)
      {
         //we need these in a list
         $Persistence::MatchAll_Count = mFloor($Persistence::MatchAll_Count);
         
         //see if it is already registered;
         for(%i = 0; %i < $Persistence::MatchAll_Count; %i++)
         {
            if($Persistence::MatchAll_Entry[%i] $= %name)
               return;
         }

         //not registered yet, add it
         $Persistence::MatchAll_Entry[$Persistence::MatchAll_Count] = %name;
         $Persistence::MatchAll_Count++;
      }
      else
      {
         //simple name match
         $Persistence::MatchName[%name] = true;
         $Persistence::MatchDatablock[%name] = %matchDataBlock;
      }      
   }

};
activatePackage(SupportPlayerPersistencePackage);

