function blrs_selectNone()
{
	blrs_playerS.visible = false;
	blrs_adminS.visible = false;
}

function blrs_selectAdmin()
{
	blrs_selectNone();
	blrs_adminS.visible = true;
}

function blrs_selectPlayer()
{
	blrs_selectNone();
	blrsGetPlayers();
	blrs_playerS.visible = true;
}
