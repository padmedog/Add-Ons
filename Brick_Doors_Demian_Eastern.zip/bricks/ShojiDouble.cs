datablock fxDTSBrickData ( brickDoor_ShojiDouble_OpenCWData )
{
	brickFile = "./ShojiDouble_openCW.blb";
	uiName = "Shoji Double Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_ShojiDouble_ClosedCWData";
	openCW = "brickDoor_ShojiDouble_OpenCWData";
	
	closedCCW = "brickDoor_ShojiDouble_ClosedCWData";
	openCCW = "brickDoor_ShojiDouble_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_ShojiDouble_OpenCCWData : brickDoor_ShojiDouble_OpenCWData )
{
	brickFile = "./ShojiDouble_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_ShojiDouble_ClosedCWData : brickDoor_ShojiDouble_OpenCWData )
{
	brickFile = "./ShojiDouble_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Eastern/bricks/ShojiDouble";

	isOpen = 0;
};