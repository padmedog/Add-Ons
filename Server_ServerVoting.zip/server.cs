//Server Voting

function servercmdnewVote(%client, %var1, %var2, %var3, %var4, %var5, %var6, %var7, %var8, %var9, %var10, %var11, %var12, %var13, %var14, %var15, %var16, %var17, %var18, %var19, %var20)
{
	for(%a = 1; %a < 21; %a++)
	{
		if(%var[%a] !$= "")
		{
			%vote = %vote SPC %var[%a];
		}
	}
	if(%client.isadmin && !$SV::isVote)
	{
		messageall('', "\c6There is a new vote for \"\c3" @ %vote @ "\c6\"! Type \c3/SV Yes \c3\c6or\c3 /SV No");
		$SV::Sch = schedule(60000, 0, "SV_End");
		$SV::isVote = 1;
	}
}

function servercmdSV(%client, %a)
{
	if(%client.hasvoted)
		return;

	if(%a $= "No")
	{
		warn(%client.name @ " voted No");
		%client.hasvoted = 1;
		$SV::Average--;
		messageAll('', "\c3" @ %client.name @ "\c6 voted No!");
	}
	else if(%a $= "Yes")
	{
		warn(%client.name @ " voted Yes");
		%client.hasvoted = 1;
		$SV::Average++;
		messageAll('', "\c3" @ %client.name @ "\c6 voted Yes!");
	}
}

function SV_End()
{
	if($SV::isVote)
	{
		cancel($SV::Sch);
		if($SV::Average == 0)
		{
			Messageall('', "\c6The vote was a \c3Tie\c6!");
		}
		else if($SV::Average < 0)
		{
			Messageall('', "\c6The greater vote was \c3no\c6, by \c3" @ $SV::Average @ " \c6person(s)!");
		}
		else if($SV::Average > 0)
		{
			Messageall('', "\c6The greater vote was \c3yes\c6, by \c3" @ $SV::Average @ " \c6person(s)!");
		}
		for(%a = 1; %a < ClientGroup.getcount(); %a++)
		{
			%client = ClientGroup.getObject(%a);
			%client.hasvoted = 0;
		}
		$SV::Average = 0;
		$SV::isVote = 0;
	}
}

