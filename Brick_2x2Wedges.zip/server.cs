datablock fxDTSBrickData(brick2x2wedgeleftData)
{
	brickFile = "./2x2wedgeleft.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "2x2 Wedge Left";
	iconName = "Add-Ons/Brick_2x2Wedges/2x2wedgeleft";
	collisionShapeName = "./2x2wedgeleft.dts";
};
datablock fxDTSBrickData(brick2x2wedgerightData)
{
	brickFile = "./2x2wedgeright.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "2x2 Wedge Right";
	iconName = "Add-Ons/Brick_2x2Wedges/2x2wedgeright";
	collisionShapeName = "./2x2wedgeright.dts";
};
datablock fxDTSBrickData(brick2x2fwedgeleftData)
{
	brickFile = "./2x2fwedgeleft.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "2x2F Wedge Left";
	iconName = "Add-Ons/Brick_2x2Wedges/2x2fwedgeleft";
	collisionShapeName = "./2x2fwedgeleft.dts";
};
datablock fxDTSBrickData(brick2x2fwedgerightData)
{
	brickFile = "./2x2fwedgeright.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "2x2F Wedge Right";
	iconName = "Add-Ons/Brick_2x2Wedges/2x2fwedgeright";
	collisionShapeName = "./2x2fwedgeright.dts";
};
datablock fxDTSBrickData(brick2x2x5wedgeleftData)
{
	brickFile = "./2x2x5wedgeleft.blb";
	category = "Wedges";
	subCategory = "5x Height";
	uiName = "2x2x5 Wedge Left";
	iconName = "Add-Ons/Brick_2x2Wedges/2x2x5wedgeleft";
	collisionShapeName = "./2x2x5wedgeleft.dts";
};
datablock fxDTSBrickData(brick2x2x5wedgerightData)
{
	brickFile = "./2x2x5wedgeright.blb";
	category = "Wedges";
	subCategory = "5x Height";
	uiName = "2x2x5 Wedge Right";
	iconName = "Add-Ons/Brick_2x2Wedges/2x2x5wedgeright";
	collisionShapeName = "./2x2x5wedgeright.dts";
};