package WaterFXPackage {
	function waterPaintProjectile::onCollision(%this, %a, %b, %c, %d, %e) {
		if(%b.getClassName() $= "fxDTSBrick") {
			%shapeFx = %b.getShapeFxId();

			if(getTrustLevel(%a, %b) < $TrustLevel::FXPaint) {
				commandToClient(%a.client, 'centerPrint', %b.getGroup().name @ " does not trust you enough to do that!", 2);
			} else if(%shapeFx != 2) {
				%a.client.undoStack.push(%b TAB "SHAPEFX" TAB %shapeFx);
				%b.setShapeFX(2);
			}
		} else {
			Parent::onCollision(%this, %a, %b, %c, %d, %e);
		}
	}
};

activatePackage(WaterFXPackage);

function serverCmdWaterFx(%client) {
	%player = %client.player;

	if(isObject(%player)) {
		if(isObject(%client.miniGame) && !%client.miniGame.enablePainting) {
			commandToClient(%client, 'centerPrint', "\c5Painting is currently disabled.", 2);
			return;
		}

		%player.updateArm(waterSprayCanImage);
		%player.mountImage(waterSprayCanImage, 0);
	}
}

datablock ParticleData(waterPaintExplosionParticle : jelloPaintExplosionParticle) {
	colors[0] = "0.533333 0.666667 1.000000 0.466667";
	colors[1] = "0.533333 0.666667 1.000000 0.000000";
	colors[2] = "1.000000 1.000000 1.000000 1.000000";
	colors[3] = "1.000000 1.000000 1.000000 1.000000";
};

datablock ParticleData(waterPaintDropletParticle : jelloPaintDropletParticle) {
	colors[0] = "0.800000 0.800000 0.800000 0.466667";
	colors[1] = "0.800000 0.800000 0.800000 0.000000";
	colors[2] = "1.000000 1.000000 1.000000 1.000000";
	colors[3] = "1.000000 1.000000 1.000000 1.000000";
};

datablock ParticleEmitterData(waterPaintExplosionEmitter : jelloPaintExplosionEmitter) {
	particles = waterPaintExplosionParticle;
};

datablock ParticleEmitterData(waterPaintDropletEmitter : jelloPaintDropletEmitter) {
	particles = waterPaintDropletParticle;
};

datablock ExplosionData(waterPaintExplosion : jelloPaintExplosion) {
	emitter[0] = waterPaintExplosionEmitter;
	emitter[1] = waterPaintDropletEmitter;
	
};

datablock ProjectileData(waterPaintProjectile : jelloPaintProjectile) {
	explosion = waterPaintExplosion;
};

datablock ParticleData(waterPaintParticle : jelloPaintParticle) {
	colors[0] = "0.533333 0.666667 1.000000 0.466667";
	colors[1] = "0.533333 0.666667 1.000000 0.000000";
	colors[2] = "1.000000 1.000000 1.000000 1.000000";
	colors[3] = "1.000000 1.000000 1.000000 1.000000";
};

datablock ParticleEmitterData(waterPaintEmitter : jelloPaintEmitter) {
	particles = waterPaintParticle;
};

datablock ShapeBaseImageData(waterSprayCanImage : jelloSprayCanImage) {
	projectile = waterPaintProjectile;
	stateEmitter[2] = waterPaintEmitter;
	colorShiftColor = "0.533333 0.666667 1.000000 1.000000";
	item = waterPaintItem;
};

datablock ItemData(waterPaintItem) {
	category = "Tools";
	className = "Weapon";

	shapeFile = "base/data/shapes/spraycan.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "WaterFX Can";
	iconName = "./icon_waterfx";
	doColorShift = true;
	colorShiftColor = waterSprayCanImage.colorShiftColor;

	image = waterSprayCanImage;
	canDrop = true;
};