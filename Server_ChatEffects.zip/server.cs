$allowrainbowchat = 0;
$allowreferencechat = 0;
$allowcolorcodechat = 0;
$allowmlchars = 0;
$usewordreplacers = 0;
$editwordfilters = 1;
$namecolor = 1;
$clantagcolor = 7;
$messagecolor = 6;
$chatwaittime = 250;
$allowrepeatchats = true;

RTB_registerPref("Can use rainbow chat","Chat","$allowrainbowchat","list Anyone 0 Admin 1 SuperAdmin 2 Host 3","Server_ChatEffects",0,0,0);
RTB_registerPref("Can use reference chat","Chat","$allowreferencechat","list Anyone 0 Admin 1 SuperAdmin 2 Host 3","Server_ChatEffects",0,0,0);
RTB_registerPref("Can use color code chat","Chat","$allowcolorcodechat","list Anyone 0 Admin 1 SuperAdmin 2 Host 3","Server_ChatEffects",0,0,0);
RTB_registerPref("Can bypass word changing","Chat","$usewordreplacers","list Anyone 0 Admin 1 SuperAdmin 2 Host 3","Server_ChatEffects",0,0,0);
RTB_registerPref("Can edit word filters","Chat","$editwordfilters","list Admin 1 SuperAdmin 2 Host 3","Server_ChatEffects",0,0,0);
RTB_registerPref("Can use ML tags","Chat","$allowmlchars","list Anyone 0 Admin 1 SuperAdmin 2 Host 3","Server_ChatEffects",0,0,0);
RTB_registerPref("Name color","Chat","$namecolor","int 0 9","Server_ChatEffects",0,0,0);
RTB_registerPref("Clan tag color","Chat","$clantagcolor","int 0 9","Server_ChatEffects",0,0,0);
RTB_registerPref("Message color","Chat","$messagecolor","int 0 9","Server_ChatEffects",0,0,0);
RTB_registerPref("Min chat wait time(ms)","Chat","$chatwaittime","int 0 100000","Server_ChatEffects",0,0,0);
RTB_registerPref("Allow repeat chats","Chat","$allowrepeatchats","bool","Server_ChatEffects",0,0,0);

function allowance(%client,%level)		//support function, tells us if a client is allowed to do an action
{
	if(%level == 0)				//if we wanted to see if %client could rainbow chat we'd do this: if(allowance(%client,$allowrainbowchat))
		return true;
	
	if((%client.isAdmin || %client.isSuperAdmin || %client.isLocalConnection()||%client.bl_id==getNumKeyID()) && %level == 1)
		return true;

	if((%client.isSuperAdmin || %client.isLocalConnection()||%client.bl_id==getNumKeyID()) && %level == 2)
		return true;

	if((%client.isLocalConnection()||%client.bl_id==getNumKeyID()) && %level == 3)
		return true;

	return false;
}

$numwordreplacers = 0;

function addwordreplacer(%oldword,%newword)
{
	$oldwords[$numwordreplacers] = %oldword;
	$newwords[$numwordreplacers] = %newword;
	$numwordreplacers++;	
}

function striReplace(%source, %search, %replace)	//support function, a case insensitive string replace, idea from Truce
{
    if(strlen(%search) < 1)
      return;
    %len = strlen(%search);
    %i = 0;
    while((%i = stripos(%source, %search, %i)) >= 0)
    {
        %source = getSubStr(%source, 0, %i) @ %replace @ getSubStr(%source, %i + %len, strlen(%source) - %i - %len);
        %i += strlen(%replace); 
    }
    return %source;
}

function numtoescapecolor(%a)				//Support function, takes a number from 0-7 and turns it into an color code e.g. \c0
{
	if(%a == 0)return "\c0";
	if(%a == 1)return "\c1";
	if(%a == 2)return "\c2";
	if(%a == 3)return "\c3";
	if(%a == 4)return "\c4";
	if(%a == 5)return "\c5";
	if(%a == 6)return "\c6";
	if(%a == 7)return "\c7";
	if(%a == 8)return "\c8";
}

function rainbow(%in)					//Takes a string an outputs that string littered with color codes
{
	%currentcolor = 0;
	%tmpstring = "";
    	for(%a = 0; %a<strlen(%in); %a++)
    	{
		%tmpstring = %tmpstring @ numtoescapecolor(%currentcolor) @ getSubStr(%in,%a,1);
		%currentcolor++;
		if(%currentcolor == 9)
			%currentcolor = 0;
	}
	return %tmpstring;
}

function nec(%a){return numtoescapecolor(%a);}

deactivatepackage(nogvod);
package nogvod
{
	function servercmdmessagesent(%client,%message)
	{
		if(getSubStr(%message,0,1)$="@" && allowance(%client,$usewordreplacers))	//support for an unedited eval, or whatever else
		{
			Parent::servercmdmessagesent(%client,%message);	
			return;
		}
		else if(getSubStr(%message,0,1)$="$" && allowance(%client,$usewordreplacers))
		{
			Parent::servercmdmessagesent(%client,getsubstr(%message,1,strlen(%message)-1));	
			return;			
		}
		else
		{
			if(%client.lastmessage $= %message && !$allowrepeatchats)
			{
				messageclient(%client,'',"Please do not repeat yourself.");
				return;
			}
			if(%client.lastchattime > 0)
			{
				if(%client.lastchattime+$chatwaittime >= getsimtime())
				{
					messageclient(%client,'',"You are talking to fast.");
					return;
				}
			}
			%client.lastmessage = %message;
			%client.lastchattime = getsimtime();

			if(!allowance(%client,$allowmlchars))
				%message = stripmlcontrolchars(%message);

			for(%a = 0; %a<$numwordreplacers; %a++)
				%message = strireplace(%message,$oldwords[%a],$newwords[%a]);
			
			
			if(getSubStr(%message,0,1)$="!" && allowance(%client,$allowrainbowchat))
			{										//rainbow chat
				%message = rainbow(getsubstr(%message,1,strlen(%message)-1));
				%entiremessage =   '\c7%1\c3%2\c7%3\c6: %4' @  numtoescapecolor($clantagcolor) @ %client.clanprefix @ numtoescapecolor($namecolor) @ %client.name @ numtoescapecolor($clantagcolor) @ %client.clansuffix @ numtoescapecolor($messagecolor) @ ": " @ %message;
				commandToAll('chatMessage',%client,'','',%entiremessage,numtoescapecolor($clantagcolor) @ %client.clanprefix,numtoescapecolor($namecolor) @ %client.getPlayerName(),numtoescapecolor($clantagcolor) @ %client.clansuffix,numtoescapecolor($messagecolor) @ %message);
			}
			else
			{
				if(allowance(%client,$allowcolorcodechat))
				{
					%message = strireplace(%message,"\\c0","\c0");				//color code replacement
					%message = strireplace(%message,"\\c1","\c1");
					%message = strireplace(%message,"\\c2","\c2");
					%message = strireplace(%message,"\\c3","\c3");
					%message = strireplace(%message,"\\c4","\c4");
					%message = strireplace(%message,"\\c5","\c5");
					%message = strireplace(%message,"\\c6","\c6");
					%message = strireplace(%message,"\\c7","\c7");
					%message = strireplace(%message,"\\c8","\c8");
				}

				for(%a = 0; %a<clientgroup.getcount(); %a++)
				{
					%lient = clientgroup.getobject(%a);	
					if(allowance(%client,$allowreferencechat))
						%vessage = strireplace(%message,"%1",%lient.name);
					%entiremessage =   '\c7%1\c3%2\c7%3\c6: %4' @  numtoescapecolor($clantagcolor) @ %client.clanprefix @ numtoescapecolor($namecolor) @ %client.name @ numtoescapecolor($clantagcolor) @ %client.clansuffix @ numtoescapecolor($messagecolor) @ ": " @ %vessage;
					commandToclient(%lient,'chatMessage',%client,'','',%entiremessage,numtoescapecolor($clantagcolor) @ %client.clanprefix,numtoescapecolor($namecolor) @ %client.getPlayerName(),numtoescapecolor($clantagcolor) @ %client.clansuffix,numtoescapecolor($messagecolor) @ %vessage);
				}
			}
		}	
	}
};

//function activatepackagenogvod()
//{
	activatepackage(nogvod);
//}
//schedule(10000,0,activatepackagenogvod);

function servercmdnewwordfilter(%client,%old,%new)
{
	if(allowance(%client,$editwordfilters))
		addwordreplacer(%old,%new);
	else messageclient(%client,'',"You are not authorized to do that.");
}

function servercmdremovewordfilter(%client,%old)
{
	if(allowance(%client,$editwordfilters))
	{
		%numfiltersremoved = 0;
		for(%a = 0; %a<$numwordreplacers; %a++)
		{
			if($oldwords[%a] $= %old)
			{
				$oldwords[%a] = "";
				%numfiltersremoved++;
			}
		}

		for(%a = 0; %a<$numwordreplacers; %a++)
		{
			if($oldwords[%a] $= "")
			{
				$oldwords[%a] = $oldwords[%a+1];
				$oldwords[%a+1] = "";
				$newwords[%a] = $newwords[%a+1];
				$newwords[%a+1] = "";
			}
		}

		$numwordreplacers -= %numfiltersremoved;
	}
	else messageclient(%client,'',"You are not authorized to do that.");
}

function servercmdlistwordfilters(%client)
{
	for(%a = 0; %a<$numwordreplacers; %a++)
		messageclient(%client,'',$oldwords[%a] SPC "-" SPC $newwords[%a]);
}

