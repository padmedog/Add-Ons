//sawTomahawks.cs

datablock AudioProfile(sawTomahawkExplosionSound)
{
   filename    = "./tomahawk_tching2.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(sawTomahawkThrowSound)
{
   filename    = "./tomahawk_littlethrow.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(sawTomahawkFlySound)
{
   filename    = "./tomahawk_bigthrow.wav";
   description = AudioCloseLooping3d;
   preload = true;
};
datablock AudioProfile(sawTomahawkOpenSound)
{
   filename    = "./zukeen.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(sawTomahawkParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 50;
    lifetimeVarianceMS   = 0;
    textureName          = "./blastFlash2";
    spinSpeed        = 0.0;
    spinRandomMin        = 0;
    spinRandomMax        = 0;

    colors[0]     = "1.0 0.5 0 0.9";
    colors[1]     = "0.9 0.4 0 0.8";
    colors[2]     = "1 0.5 0.2 0.6";
    colors[3]     = "1 0.5 0.2 0.4";

    sizes[0]      = 3.65;
   sizes[1]      = 0.3;
    sizes[2]      = 0.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(sawTomahawkEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "sawTomahawkParticle";
};


datablock ParticleData(shinSawTomahawkParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 50;
    lifetimeVarianceMS   = 0;
    textureName          = "./blastFlash2";
    spinSpeed        = 0.0;
    spinRandomMin        = 0.0;
    spinRandomMax        = 0.0;

    colors[0]     = "1.0 0.5 0 0.9";
    colors[1]     = "0.9 0.4 0 0.8";
    colors[2]     = "1 0.5 0.2 0.6";
    colors[3]     = "1 0.5 0.2 0";

    sizes[0]      = 6.65;
   sizes[1]      = 6.3;
    sizes[2]      = 6.10;
    sizes[3]      = 6.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(shinSawTomahawkEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "shinSawTomahawkParticle";
};

datablock ParticleData(sawTomahawkSliceParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 150;
    lifetimeVarianceMS   = 0;
    textureName          = "./blastFlash2";
    spinSpeed        = 0.0;
    spinRandomMin        = 0;
    spinRandomMax        = 0;

    colors[0]     = "0 0 0 0.4";
    colors[1]     = "0 0 0 0.4";
    colors[2]     = "0 0 0 0.4";
    colors[3]     = "0 0 0 0";

    sizes[0]      =2.65;
   sizes[1]      = 2.3;
    sizes[2]      = 2.10;
    sizes[3]      = 2.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = true;
};
datablock ParticleEmitterData(sawTomahawkSliceEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "sawTomahawkSliceParticle";
};

datablock DebrisData(sawTomahawkDebris)
{
	shapeFile = "./spacer_tomahawk.dts";

	lifetime = 1.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;
	spinSpeed			= 300.0;
	minSpinSpeed = -600.0;
	maxSpinSpeed = 600.0;

	gravModifier = 6;
};

datablock ExplosionData(sawTomahawkExplosion : quakeShotgunExplosion)
{
   //explosionShape = "";
	soundProfile = sawTomahawkExplosionSound;

   lifeTimeMS = 150;

   particleEmitter = shinSawTomahawkEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   debris = sawTomahawkDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 45;
   debrisThetaMax = 115;
   debrisVelocity = 18;
   debrisVelocityVariance = 8;

   emitter[0] = quakeImpactExplosionRingEmitter;
   emitter[1] = sawTomahawkSliceEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";

   impulseRadius = 2;
   impulseForce = 1000;
};

AddDamageType("sawTomahawks",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_tomohawk> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_tomohawk> %1',0.05,1);
datablock ProjectileData(sawTomahawksProjectile)
{
   projectileShapeName = "./spacer_tomahawk_proj.dts";
   directDamage        = 100;
   directDamageType    = $DamageType::sawTomahawks;
   radiusDamageType    = $DamageType::sawTomahawks;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   sound = sawTomahawkFlySound;
   explosion           = sawTomahawkExplosion;
   particleEmitter     = "";

   explodeOnPlayerImpact = true;
   explodeondeath = true;

   muzzleVelocity      = 55;
   velInheritFactor    = 0;

   armingDelay         = 000;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(sawTomahawksItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./spacer_tomahawk.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Saw! Tomahawk!!";
	iconName = "./tomahawk";
	doColorShift = true;
	colorShiftColor = "0.5 0.5 0.5 1.000";

	 // Dynamic properties defined by the scripts
	image = sawTomahawksImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(sawTomahawksImage)
{
   // Basic Item properties
	shapeFile = "./spacer_tomahawk.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = sawTomahawksProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = sawTomahawksItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.4;
	stateScript[0] = "onOpen";
	stateSequence[0] = "ready";
   	stateEmitter[0]					=  sawTomahawkEmitter;
	stateEmitterTime[0]				= 0.01;
	stateEmitterNode[0]				= "shineJoint";
	stateSound[0] = sawTomahawkOpenSound;

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Windup";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Reload";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.50;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = sawTomahawkThrowSound;

   stateName[3] = "Windup";
	stateTimeoutValue[3]            = 0.10;
	stateScript[3] = "onWindup";
	stateTransitionOnTimeout[3]     = "Fire";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTimeout[4] = "Ready";
	stateSequence[4] = "ready";
};

function sawTomahawksImage::onOpen(%this,%obj,%slot)
{
		%obj.playThread(2, shiftAway);
}

function sawTomahawksImage::onWindup(%this,%obj,%slot)
{
		%obj.playThread(2, shiftAway);
		%obj.playThread(0, shiftAway);
		%obj.playThread(3, shiftRight);
}

function sawTomahawksImage::onFire(%this,%obj,%slot)
{
		%obj.playThread(2, shiftTo);
		%obj.playThread(0, shiftTo);
		%obj.playThread(3, shiftLeft);
	%projectile = sawTomahawksProjectile;
	%spread = 0.0016;
	%shellcount = 1;

	%obj.playThread(2, shiftDown);
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	%obj.spawnExplosion(QuakeLittleRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
   //%obj.setImageTrigger(1,1);
}
