$MTPass=0;
$PrevPass=0;
$switch=1;
$EChDP=1;
$Start=0;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function PTG_GUI_StartRoutine()
{
	if($PrevPass==0 && $Bnds==1 && $MTPass==0)
		CreateChunk_Boundaries();

	if($MTPass==1)
		messageAll('',"PTG: Overlaying ModTer");

	$Start = 1;
	$EChDP = 0;
	$Pause = 0;
	$switch = 1;
	$IChDP = 1;
	$NN = 0;
	$ChPx = $GSx;
	$ChPy = $GSy;

	if($BioA==1)
		$NN++;
	if($BioC==1)
		$NN++;
	if($BioD==1)
		$NN++;
	if($BioE==1)
		$NN++;

	PTGPass();
}
function PTGPass()
{		
	if($IChDP == 0)
	{
		$ChPx = $ChPx+$ChS;
	
		if($ChPx >= $GEx)
		{
			$ChPx = $GSx;
			$ChPy = $ChPy+$ChS;
		}
		if($ChPy >= $GEy)
		{
			if($ModTer==1 && $MTPass==1 && $Start=1)
			{
				commandToServer('EndPTG');
				return;
			}
			if($ModTer==0 && $MTPass==0 && $Start=1)
			{
				commandToServer('EndPTG');
				return;
			}
			if($ModTer==1 && $MTPass==0 && $Start=1)
			{
				if($PrevPass==1)
				{
					commandToServer('EndPTG');
					return;
				}
				if($PrevPass!=1)
				{
					$MTPass=1;
					PTG_GUI_StartRoutine();
					return;
				}
			}
		}
	}
	$IChDP = 0;
	
	if($EChDP==0 && $Start==1)
	{
		if($UseSd==0)
			GetCustomHeightValues();
		else
			GetHeightValues();
	}
}