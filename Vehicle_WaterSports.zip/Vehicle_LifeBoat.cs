datablock TSShapeConstructor(LifeBoatDts)
{
	baseShape  = "./lifeboat.dts";
	sequence0  = "./lifeboat_root.dsq root";

	sequence1  = "./lifeboat_root.dsq run";
	sequence2  = "./lifeboat_root.dsq walk";
	sequence3  = "./lifeboat_root.dsq back";
	sequence4  = "./lifeboat_root.dsq side";

	sequence5  = "./lifeboat_root.dsq crouch";
	sequence6  = "./lifeboat_root.dsq crouchRun";
	sequence7  = "./lifeboat_root.dsq crouchBack";
	sequence8  = "./lifeboat_root.dsq crouchSide";

	sequence9  = "./lifeboat_root.dsq look";
	sequence10 = "./lifeboat_root.dsq headside";
	sequence11 = "./lifeboat_root.dsq headUp";

	sequence12 = "./lifeboat_root.dsq jump";
	sequence13 = "./lifeboat_root.dsq standjump";
	sequence14 = "./lifeboat_root.dsq fall";
	sequence15 = "./lifeboat_root.dsq land";

	sequence16 = "./lifeboat_root.dsq armAttack";
	sequence17 = "./lifeboat_root.dsq armReadyLeft";
	sequence18 = "./lifeboat_root.dsq armReadyRight";
	sequence19 = "./lifeboat_root.dsq armReadyBoth";
	sequence20 = "./lifeboat_root.dsq spearready";  
	sequence21 = "./lifeboat_root.dsq spearThrow";

	sequence22 = "./lifeboat_root.dsq talk";  

	sequence23 = "./lifeboat_root.dsq death1"; 
	
	sequence24 = "./lifeboat_root.dsq shiftUp";
	sequence25 = "./lifeboat_root.dsq shiftDown";
	sequence26 = "./lifeboat_root.dsq shiftAway";
	sequence27 = "./lifeboat_root.dsq shiftTo";
	sequence28 = "./lifeboat_root.dsq shiftLeft";
	sequence29 = "./lifeboat_root.dsq shiftRight";
	sequence30 = "./lifeboat_root.dsq rotCW";
	sequence31 = "./lifeboat_root.dsq rotCCW";

	sequence32 = "./lifeboat_root.dsq undo";
	sequence33 = "./lifeboat_root.dsq plant";

	sequence34 = "./lifeboat_root.dsq sit";

	sequence35 = "./lifeboat_root.dsq wrench";

   sequence36 = "./lifeboat_root.dsq activate";
   sequence37 = "./lifeboat_root.dsq activate2";

   sequence38 = "./lifeboat_root.dsq leftrecoil";
};    

datablock ParticleEmitterData(LifeboatFoamEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 80;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlayerFoamParticle";

   useEmitterColors = true;

   uiName = "";
};

datablock PlayerData(LifeBoatArmor : PlayerStandardArmor)
{
	cameraVerticalOffset = 3;
	shapefile = "./Lifeboat.dts";
	canJet = 0;
	mass = 100;
   drag = 0.03;
   density = 0.4;
   runSurfaceAngle = 1;
   jumpSurfaceAngle = 1;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxForwardCrouchSpeed = 0;
   maxSideSpeed = 0;
   maxSideCrouchSpeed = 0;
   maxStepHeight = 0;
   maxUnderwaterSideSpeed = 2;
    maxUnderwaterForwardSpeed = 10;
    maxUnderwaterBackwardSpeed = 8;

	uiName = "Lifeboat";
	showEnergyBar = false;
	
   jumpForce = 0;
   jumpEnergyDrain = 10000;
   minJumpEnergy = 10000;
   jumpDelay = 127;
   minJumpSpeed = 0;
   maxJumpSpeed = 0;
	
	rideable = true;
	canRide = false;
	paintable = true;
	
   boundingBox			= vectorScale("2.5 2.5 1", 4); 
   crouchBoundingBox	= vectorScale("2.5 2.5 1", 4);
	
   lookUpLimit = 0.65;
	lookDownLimit = 0.45;
	
   numMountPoints = 3;
   mountThread[0] = "sit";
   mountThread[1] = "sit";
   mountThread[2] = "sit";

   splashEmitter[0] = LifeboatFoamEmitter;
   splashEmitter[1] = LifeboatFoamEmitter;
   splashEmitter[2] = LifeboatFoamEmitter;
   
   upMaxSpeed = 1;
   upResistSpeed = 1;
   upResistFactor = 1;
   maxdamage = 100;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   useCustomPainEffects = true;
   PainHighImage = "";
   PainMidImage  = "";
   PainLowImage  = "";
   painSound     = "";
   deathSound    = "";
};
