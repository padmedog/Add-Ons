datablock AudioProfile(stimpackHealSound)
{
   filename    = "./stimpack.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ItemData(stimpackItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./stimpack.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Syringe";
	iconName = "./syringe";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = stimpackImage;
	canDrop = true;
};

datablock ProjectileData(stimpackProjectile)
{
   projectileShapeName = "";
   directDamage        = 0;
   directDamageType    = $DamageType::medigun;
   radiusDamageType    = $DamageType::medigun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = bulletExplosion;
   particleEmitter     = medigunFlashEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 100;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ShapeBaseImageData(stimpackImage)
{
   // Basic Item properties
   shapeFile = "./stimpack.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0.1";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
minshottime = 5000;

   className = "WeaponImage";
   item = stimpackItem;

   //raise your arm up or not
   armReady = true;

   doColorShift = false;

   // Initial start up state
	stateName[0]                     = "Ready";
	stateTransitionOnTriggerDown[0]  = "Fire";
	stateAllowImageChange[0]         = true;

	stateName[1]                     = "Fire";
	stateTransitionOnTimeout[1]      = "Ready";
	stateAllowImageChange[1]         = true;
	stateScript[1]                   = "onFire";
	stateTimeoutValue[1]		   = 1;
};

function stimpackProjectile::onCollision(%this,%obj,%col,%pos,%fade)
	{
		if(isObject(%col.client.minigame))
		{
			if(%obj.client.minigame $= %col.client.minigame)
			{
				if(%col.getClassName() $= "Player")
				{
					if(%col.getDamageLevel() >= 30)
					{
						%col.setDamageLevel(%col.getDamageLevel()-30);
						%col.spawnExplosion(healCrossProjectile,"1 1 1");
					}
					else
					{
						%col.setDamageLevel(0);
					}
					bottomPrint(%obj.client,"\c6<font:impact:32>" @ %col.client.name @ "<font:impact:18> was healed by you.",1,3);
					bottomPrint(%col.client,"\c6<font:impact:32>" @ %obj.client.name @ "<font:impact:18> is healing you.",1,3);
					%col.emote(medigunhealImage);
				}
				Parent::onCollision(%this,%obj,%col,%pos,%fade);
			}
		}
	}

function canFireStim(%obj)
{
		centerprint(%obj.client,"<color:fff000>Syringe recharged!<br><color:ffffff>You can use it again." ,5);
            		serverPlay3D(medigunReloadSound,%obj.getPosition());
}

function stimpackImage::onFire(%this,%obj,%slot)
{
	if((%obj.lastStimTime+%this.minShotTime) > getSimTime() && %this.usedstimpack == 1)
		{
		centerprint(%obj.client,"Can't reuse your Syringe yet!<br><br>Give it a while to recharge..." ,5);
		return;
		%obj.playThread(2, undo);
		}
		%obj.playThread(2, shiftDown);
	%obj.lastStimTime = getSimTime();
	%this.usedstimpack = 1;
            		serverPlay3D(stimpackHealSound,%obj.getPosition());
		schedule(5000, 0, "canFireStim", %obj);	
					if(%obj.getDamageLevel() >= 20)
					{
		%obj.setDamageLevel(%obj.getDamageLevel()-20);
		%obj.emote(medigunhealImage);
		%obj.spawnExplosion(healCrossProjectile,"1 1 1");
					}
					else
					{
						%obj.setDamageLevel(0);
					}
}

package Stimpack
{
	function armor::onTrigger(%this,%player,%slot,%val)
	{
		if(%player.getMountedImage(0) $= StimpackImage.getID() && %slot $= 4 && %val)
		{
		%player.playThread(2, shiftDown);
            		serverPlay3D(stimpackHealSound,%player.getPosition());

		%projectile = StimpackProjectile;
		%vector = %player.getMuzzleVector(0);
		%objectVelocity = %player.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new Projectile()
			{
				dataBlock = %projectile;
				initialVelocity = %velocity;
				initialPosition = %player.getMuzzlePoint(0);
				sourceObject = %player;
				sourceSlot = 0;
				client = %player.client;
			};
			return %p;	
		%obj.lastStimTime = getSimTime();

		
		}
		else
			Parent::onTrigger(%this,%player,%slot,%val);
	}
};
ActivatePackage(Stimpack);