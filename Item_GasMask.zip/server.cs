exec("./weapon_ChemGrenade.cs");
exec("./item_Gasmask.cs");