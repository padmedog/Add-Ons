registerOutputEvent(fxDTSbrick,"getRandom","int 1 9 1\tint 1 9 1\tint 1 9 1",1);
registerInputEvent(fxDTSBrick, "onRandomTrue", "Self fxDTSBrick\tPlayer Player\tClient GameConnection\tMiniGame MiniGame",1);
registerInputEvent(fxDTSBrick, "onRandomFalse", "Self fxDTSBrick\tPlayer Player\tClient GameConnection\tMiniGame MiniGame",1);		

function fxDTSbrick::getRandom(%brick, %min, %max, %check, %client)
{
	%random = getrandom(%min, %max);
	
	if(%random == %check)
	{
		%brick.onRandomTrue(%client);
	}
	else
	{
		%brick.onRandomFalse(%client);
	}
}

function fxDTSBrick::onRandomTrue(%this, %client)
{
	$inputTarget_self = %this;
	$inputTarget_client = %client;
	$inputTarget_player = %client.player;
	$inputTarget_miniGame = getMiniGameFromObject(%this);
	%this.processInputEvent("onRandomTrue", %client);
}

function fxDTSBrick::onRandomFalse(%this, %client)
{
	$inputTarget_self = %this;
	$inputTarget_client = %client;
	$inputTarget_player = %client.player;
	$inputTarget_miniGame = getMiniGameFromObject(%this);
	%this.processInputEvent("onRandomFalse", %client);
}