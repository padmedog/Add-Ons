

if(!isObject(BRPG_Client_Targeting_Gui)) {

	new GuiControl(BRPG_Client_Targeting_Gui) {
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "0 0";
		extent = getWords(getRes(), 0, 1);
		minExtent = "8 8";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
	
		new GuiBitmapButtonCtrl() {
			profile = "InventorySlotProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "0 0";
			extent = getWords(getRes(), 0, 1);
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			command = "BRPG_Client_TargetingDone();";
			buttonType = "PushButton";
			bitmap = "./blank";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			mKeepCached = "0";
			mColor = "255 255 255 255";

			text = "";
		};
	};
}

activatePackage(BRPG_Client_Controls_Package);
