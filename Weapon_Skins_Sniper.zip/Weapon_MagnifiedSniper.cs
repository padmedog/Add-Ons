datablock AudioProfile(SilencedSniperFireSound)
{
   filename    = "./sht.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("MagnifiedSniperRifle",   '<bitmap:add-ons/Weapon_Skins_Sniper/CI_Magnified_Sniper> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Sniper/CI_Magnified_Sniper> %1',0.75,1);
AddDamageType("MagnifiedSniperRifleHeadshot",   '<bitmap:add-ons/Weapon_Skins_Sniper/CI_Magnified_Sniper> <bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Sniper/CI_Magnified_Sniper> <bitmap:add-ons/Weapon_Package_Tier2/CI_tactheadshot> %1',0.75,1);

datablock ProjectileData(magmilTracerProjectile : pistolTracerProjectile)
{
   directDamage        = 2;
   directDamageType    = $DamageType::MagnifiedSniperRifleHeadshot;
   muzzleVelocity      = 200;
   radiusDamageType    = $DamageType::MagnifiedSniperRifleHeadshot;
};

//////////
// item //
//////////
datablock ItemData(MagnifiedSniperRifleItem : MilitarySniperItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Silenced_Sniper.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Silenced Sniper";
	iconName = "./magnifiedsniper";
	doColorShift = true;
	colorShiftColor = "0.64 0.64 0.6 1.000";

	 // Dynamic properties defined by the scripts
	image = MagnifiedSniperRifleImage;
	canDrop = true;
    
   //Ammo Guns Parameters
   maxAmmo = 4;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(MagnifiedSniperRifleImage : MilitarySniperImage)
{
   raycastWeaponRange = 700;
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = shotgunBlastProjectile;
   raycastTracerProjectile = magmilTracerProjectile;
   raycastCritTracerProjectile = magmilTracerProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastCritDirectDamageType = $DamageType::MagnifiedSniperRifleHeadshot;
   raycastDirectDamage = 100; //Varies
   raycastDirectDamageType = $DamageType::MagnifiedSniperRifle;
   raycastSpreadAmt = 0; //Varies
	shapeFile = "./Silenced_Sniper.dts";
   emap = true;
   item = MagnifiedSniperRifleItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;
   doColorShift = true;
   colorShiftColor = MagnifiedSniperRifleItem.colorShiftColor;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Wait2";
	stateTimeoutValue[2]            = 0.1;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		  = true;
	stateEmitter[2]			  = gunFlashEmitter;
	stateEmitterTime[2]		  = 0.05;
	stateEmitterNode[2]		  = "muzzleNode";
	stateSound[2]			  = silencedsniperfireSound;

	stateName[3] 			  = "Smoke";
	stateSequence[3]			  = "reload";
	stateSound[3]			  = boltriflereloadSound;
	stateTimeoutValue[3]            = 0.8;
	stateTransitionOnTimeout[3]     = "Wait3";

};

function MagnifiedSniperRifleImage::onReloadStart(%this,%obj,%slot)
{           		
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
	%obj.playThread(2, plant);
		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
}

function MagnifiedSniperRifleImage::onReloaded1(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
		%obj.playThread(2, shiftleft);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function MagnifiedSniperRifleImage::onReloadWait(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
		serverPlay3D(block_ChangeBrick_Sound,%obj.getPosition());
		%obj.playThread(2, shiftRight);
	}
}

function MagnifiedSniperRifleImage::onSmoke(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["308rounds"] >= 1)
	{
		%obj.playThread(2, plant);
	}
}


function MagnifiedSniperRifleImage::onReloaded(%this,%obj,%slot)
{
	%obj.lastFireTime = getSimTime() - 400;
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["308rounds"] >= 1)
	{
	%obj.client.quantity["308rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["308rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["308rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["308rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["308rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["308rounds"] = 0;

		
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

function MagnifiedSniperRifleImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
	}
   %obj.lastFireTime = getSimTime() - 500;
}

function MagnifiedSniperRifleImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
	if((%obj.lastFireTime+%this.minShotTime) > getSimTime())
	{
		%thread = "plant";
		%this.raycastExplosionProjectile = MagnifiedSniperRifleProjectile;
		%this.raycastSpreadAmt = ((%obj.lastFireTime+%this.minShotTime) - getSimTime())/%this.minShotTime*0.005;
		%this.raycastDirectDamage = 30;
	}
	else
	{
		%thread = "plant";
		%this.raycastExplosionProjectile = shotgunBlastProjectile;
		%this.raycastSpreadAmt = 0;
		%this.raycastDirectDamage = 33;
	}
	
	Parent::onFire(%this,%obj,%slot);

	if(!%obj.fireTrace)
	{
		%obj.lastFireTime = getSimTime();

		%obj.playThread(2, %thread);

			if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool] -= 1;
		%obj.AmmoSpent[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>.270 Huge Rifle<font:impact:34>\c6 " @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["308rounds"] @ "", 4, 2, 3, 4); 
	}
	}
}

function MagnifiedSniperRifleImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(%this.raycastSpreadAmt > 0)
      return 0;
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}