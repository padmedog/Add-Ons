// +-------------------------------------------+
// |  ___   _     _____   __  __  ____   ____  |
// | | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
// | |__ | | |_  |  _  |   \  /  | __|  | \/ / |
// | |___| |___| |_| |_|   |__|  |____| |_| \\ |
// |  Greek2me              Blockland ID 11902 |
// +-------------------------------------------+

$Slayer::Server::Debug = 0;

// +-----------------------------+
// | DO NOT EDIT BELOW THIS LINE |
// +-----------------------------+

$Slayer::Version = "3.9.4+release-20151024";

$Slayer::Server::Version = $Slayer::Version;
$Slayer::Server::CompatibleVersion = "3.9.0+release-20140829";

$Slayer::Platform = ($Server::Dedicated ? "DedicatedServer" : "IntegratedServer");

$Slayer::Path = filePath(expandFileName("./server.cs"));
$Slayer::Common::Path = $Slayer::Path @ "/common";
$Slayer::Server::Path = $Slayer::Path @ "/server";

$Slayer::Common::ConfigDir = "config/common/Slayer";
$Slayer::Server::ConfigDir = "config/server/Slayer";

$Slayer::Server::GameModeArg = $Slayer::Path @ "/gamemode.txt";
$Slayer::Server::CurGameModeArg = $gameModeArg;

// +------+
// | Core |
// +------+
exec($Slayer::Common::Path @ "/main.cs"); //load common scripts
exec($Slayer::Server::Path @ "/main.cs"); //load server scripts

// +--------------+
// | Fully Loaded |
// +--------------+
warn("Slayer Version" SPC $Slayer::Server::Version);