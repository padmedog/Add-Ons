function updateStatOne(%client,%value)
{
	commandtoall('setStatOne',%client,%value);
}

function updateStatTwo(%client,%value)
{
	commandtoall('setStatTwo',%client,%value);
}

$statOneName = "One";
$statTwoName = "Two";

function sendSystemAddonInfo(%client)
{
	commandtoclient(%client,'statOneName',$statOneName);
	commandtoclient(%client,'statTwoName',$statTwoName);
	commandtoclient(%client,'systemAck',$systemVersion::server);
}

package sendStatNames
{
	function GameConnection::autoAdminCheck(%this)
	{
		sendSystemAddonInfo(%this);
		%ret = parent::autoAdminCheck(%this);
		sendSystemAddonInfo(%this);
		return %ret;
	}
};
activatepackage(sendStatNames);

if(isFile("add-ons/gamemode_slayer/server.cs"))
	exec("./stat_killsDeaths.cs");
//comment that out
//if you want to do something else

exec("./vceStatSupport.cs");
