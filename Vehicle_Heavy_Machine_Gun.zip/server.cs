%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Vehicle_Heavy_Machine_Gun - required add-on Weapon_Gun not found");
}
else
{
   exec("./Vehicle_Heavy_Machine_Gun.cs"); 
}

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
   if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");

	RTB_registerPref("Maximum Ammo","Heavy Machine Gun","HMG::Maxammo","int 100 5000","Vehicle_Heavy_Machine_Gun","750",0,0);
}
else
{
	$HMG::Maxammo = 750;
}