datablock fxDTSBrickData(brick1x2fVerticalPrintData)
{
	brickFile = "./1x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fVerticalPrintData)
{
	brickFile = "./2x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1fVerticalPrintEdgeData)
{
	brickFile = "./1x1fVerticalPrintEdge.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x1F Vertical Edge Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1fVerticalPrintEdge";

	hasPrint = 1;
	printAspectRatio = "2x2f";

};

datablock fxDTSBrickData(brick1x2x2fVerticalPrintData)
{
	brickFile = "./1x2x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_2x2fVerticalPrintData)
{
	brickFile = "./1f_2x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fVerticalDoublePrintData)
{
	brickFile = "./2x2fVerticalDoublePrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F Vertical Double Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1fVerticalPrintCornerData)
{
	brickFile = "./1x1fVerticalPrintCorner.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1fVerticalPrintCorner";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x2fVerticalPrintData)
{
	brickFile = "./1x1x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x2fVerticalPrintData)
{
	brickFile = "./1f_1x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x1fVerticalPrintEdgeData)
{
	brickFile = "./1x1x1fVerticalPrintEdge.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 1x1F Vertical Edge Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x1fVerticalPrintEdge";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x1fVerticalPrintEdgeData)
{
	brickFile = "./1f_1x1fVerticalPrintEdge.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 1x1F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x1fVerticalPrintEdge";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x1fVerticalPrintCornerData)
{
	brickFile = "./1x1x1fVerticalPrintCorner.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x1fVerticalPrintCorner";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x1fVerticalPrintCornerData)
{
	brickFile = "./1f_1x1fVerticalPrintCorner.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x1fVerticalPrintCorner";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};