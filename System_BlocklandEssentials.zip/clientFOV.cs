function changeClientFOV()
{
	$pref::OpenGL::clientFov = mFloor($pref::OpenGL::clientFov);
	$fovSlider.setValue($pref::OpenGL::clientFov);
	setFov($pref::OpenGL::clientFov);
}

if(!($pref::OpenGL::clientFov > 0) && !($pref::OpenGL::clientFov < 0))
	$pref::OpenGL::clientFov = 90;

schedule(2500,0,changeClientFOV,$pref::OpenGL::clientFov);

function addSliderFOV()
{
	%pane = OptAdvGraphicsPane;
	%scroll = %pane.getObject(2);
	%swatchone = %scroll.getObject(0);
	%swatchtwo = %swatchone.getObject(0);

	if(isObject(%swatchtwo))
	{
		if(!isObject($fovSlider))
		{
			$fovSlider = new GuiSliderCtrl()
			{
				position = "300 158";
				extent = "250 64";
				minExtent = "250 64";
				enabled = true;
				visible = true;
				clipToParent = true;
				variable = "$pref::OpenGL::clientFov";
				command = "changeClientFOV();";
				range = "10 150";
				ticks = "14";
				value = $pref::OpenGL::clientFov;
			};

			%swatchtwo.add($fovslider);

			$fovText = new GuiTextCtrl()
			{
				text = "Field of View:";
				position = "230 158";
				extent = "67 18";
				minExtent = "67 18";
				horizSizing = "right";
				vertSizing = "bottom";
				profile = "GuiTextProfile";
				enabled = true;
				visible = true;
				clipToParent = true;
			};

			%swatchtwo.add($fovText);
		}
	}
}

addSliderFOV();

package fovzoom
{
	function toggleZoom(%arg)
	{
		parent::togglezoom(%arg);
		if(%arg == 0)
			setFov($pref::OpenGL::clientFov);
	}
};
activatepackage(fovzoom);








