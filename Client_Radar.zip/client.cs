function radarso_tick()
{
	if(!isobject(radarso) || !isobject(radarhud) || !isobject(serverconnection.getcontrolobject()))
	{
		togradar(1);
		return;
	}
	radarso.origin = serverconnection.getcontrolobject().getposition();
	%res = mfloor((288/256)*$radarsize);
	radarhud.resize($radarx, $radary, %res, %res);
	//radarhud.clear();
	%hres = mfloor(%res/2);
	%adj = ($radarsize/2)/$radarmaxdist;

	if(!isobject(radarso.centerdot))
	{
		%dot = new GuiBitmapCtrl()
		{
			profile = "GuiDefaultProfile";
				horizSizing = "right";
		vertSizing = "bottom";
			position = %hres-4 SPC %hres-4;
			extent = "8 8";
			minExtent = "8 8";
			visible = "1";
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			keepCached = "0";
			bitmap = "add-ons/client_radar/ui/center.png";
		};
		radarso.centerdot = %dot;
		radarhud.add(%dot);
	}
	%pos = radarso_getgridpos(getword(radarso.origin, 0) SPC getword(radarso.origin, 1) + $radarmaxdist);
	%x = mfloor(getword(%pos, 0)*%adj) + %hres-7;
	%y = mfloor(getword(%pos, 1)*%adj*-1) + %hres-6;

	
	if(!isobject(radarso.northdot))
	{
		%dot = new GuiBitmapCtrl()
		{
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = %x SPC %y;
			extent = "15 13";
			minExtent = "5 5";
			visible = "1";
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			keepCached = "0";
			bitmap = "add-ons/client_radar/ui/north.png";
		};
		radarso.northdot = %dot;
		radarhud.add(%dot);
	}
	radarso.northdot.resize(%x, %y, 15, 13);
	

	for(%a=0; %a<radarso.waypointcount; %a++)
	{
		%ipos = radarso.waypoint[%a];
		%pos = radarso_getgridpos(%ipos);
		%x = mfloor(getword(%pos, 0)*%adj) + %hres-2;
		%y = mfloor(getword(%pos, 1)*%adj*-1) + %hres-2;

		if(!isobject(radarso.waypointgui[%a]))
		{
			%dot = new GuiBitmapCtrl()
			{
				profile = "GuiDefaultProfile";
				horizSizing = "right";
				vertSizing = "bottom";
				position = %x SPC %y;
				extent = "5 5";
				minExtent = "5 5";
				visible = "1";
				wrap = "0";
				lockAspectRatio = "0";
				alignLeft = "0";
				overflowImage = "0";
				keepCached = "0";
				bitmap = "add-ons/client_radar/ui/dot"@ radarso.waypointcolor[%a] @".png";
			};
			radarso.waypointgui[%a] = %dot;
			radarhud.add(%dot);
		}
		radarso.waypointgui[%a].resize(%x, %y, 5, 5);
	}

	if($radarso::generatedots)
	{
		for(%a=0; %a<radarso.ohdearcount; %a++)
		{
			if(!getrandom(0, 10000) || vectordist(radarso.origin, radarso.ohdear[%a]) < 50)
			{
				for(%c=%a; %c<radarso.playercount; %c++)
					radarso.ohdear[%c] = radarso.ohdear[%c+1];
				radarso.ohdearcount--;
				continue;
			}
			radarso.ohdear[%a] = vectoradd(radarso.ohdear[%a], radarso.ohdearvel[%a]);
			%ipos = radarso.ohdear[%a];
			%pos = radarso_getgridpos(%ipos);
			%x = mfloor(getword(%pos, 0)*%adj) + %hres-2;
			%y = mfloor(getword(%pos, 1)*%adj*-1) + %hres-2;

			if(!isobject(radarso.ohdeargui[%a]))
			{
				%dot = new GuiBitmapCtrl()
				{
					profile = "GuiDefaultProfile";
					horizSizing = "right";
					vertSizing = "bottom";
					position = %x SPC %y;
					extent = "5 5";
					minExtent = "5 5";
					visible = "1";
					wrap = "0";
					lockAspectRatio = "0";
					alignLeft = "0";
					overflowImage = "0";
					keepCached = "0";
					bitmap = "add-ons/client_radar/ui/dotblue.png";
				};
				radarso.ohdeargui[%a] = %dot;
				radarhud.add(%dot);
			}
			radarso.ohdeargui[%a].resize(%x, %y, 5, 5);
		}

		if(!getrandom(0, 100+500*radarso.ohdearcount))
		{
			radarso.ohdear[radarso.ohdearcount] = vectoradd(serverconnection.getcontrolobject().getposition(), (getrandom(0, 300)-150) SPC (getrandom(0, 300)-150));
			radarso.ohdearvel[radarso.ohdearcount] = (getrandom(0,100)/100-0.5) SPC (getrandom(0,100)/100-0.5);
			radarso.ohdearcount++;
		}
	}
	radarso.schedule = schedule(1, 0, radarso_tick);
}

function radarso_getgridpos(%pos)
{
	%xa=getword(%pos,0) - getword(radarso.origin,0);
	%ya=getword(%pos,1) - getword(radarso.origin,1);
	%v=serverconnection.getcontrolobject().getforwardvector();
	return radarso_polartogrid(matan(getword(%v,1),getword(%v,0))-matan(%ya,%xa), msqrt(mpow(%xa,2)+mpow(%ya,2)));
}

function radarso_polartogrid(%yaw, %dist)
{
	if(%dist > $radarmaxdist)
		%dist = $radarmaxdist;
	return msin(%yaw)*%dist SPC mcos(%yaw)*%dist;
}

function togradar(%x)
{
	if(%x)
	{
		if(isobject(radarhud))
		{
			radarhud.delete();
			cancel(radarso.schedule);
			radarso.delete();
		}
		else
		{
			if(!$radarso_versionchecked)
			{
				$radarso_versionchecked = 1;
				radarso_versioncheck();
			}
			%size = mfloor((288/256)*$radarsize);

			if(isobject(radarhud))
				radarhud.delete();

			new GuiBitmapCtrl(radarhud)
			{
				profile = "GuiDefaultProfile";
				horizSizing = "right";
				vertSizing = "bottom";
				position = $radarx SPC $radary;
				extent = %size SPC %size;
				minExtent = "32 32";
				visible = "1";
				wrap = "0";
				lockAspectRatio = "0";
				alignLeft = "0";
				overflowImage = "0";
				keepCached = "0";
				bitmap = "add-ons/client_radar/ui/radar.png";
			};

			if(isobject(radarso))
				radarso.delete();

			new scriptobject(Radarso)
			{
				waypointcount = 0;
				ohdearcount = 0;
				lockon = 0;
			};
			playgui.add(radarhud);
			radarso_tick();
		}
	}
}

function radarso_addwaypoint(%pos, %color)
{
	if(!isobject(radarso))
		togradar(1);
	radarso.waypoint[radarso.waypointcount] = %pos;

	if(%color $= "")
		%color = "red";
	radarso.waypointcolor[radarso.waypointcount] = %color;
	radarso.waypointcount++;
}

function radarso_dropwaypoint(%x)
{
	if(%x)
		radarso_addwaypoint(serverconnection.getcontrolobject().getposition(), $radarso::waypointcolor);
}


function radarso_lookat(%posb)
{
	%posa = serverconnection.getcontrolobject().getposition();
	%xa = getword(%posb, 0) - getword(%posa, 0);
	%ya = getword(%posb, 1) - getword(%posa, 1);
	%za = getword(%posb, 2) - getword(%posa, 2) - getword(serverconnection.getcontrolobject().getdatablock().boundingbox, 2)/5 + $iamcrouching*1.5;
	%la = msqrt(mpow(%xa, 2) + mpow(%ya, 2) + mpow(%za, 2));
	%pitcha = macos(%za/%la);
	%yawa = matan(%xa, %ya);

	%v = serverconnection.getcontrolobject().getmuzzlevector(0);
	%xb = getword(%v, 0);
	%yb = getword(%v, 1);
	%zb = getword(%v, 2);
	%pitchb = macos(%zb);
	%yawb = matan(%xb, %yb);

	%pitch = %pitcha - %pitchb;
	%yaw = %yawa - %yawb;

	$mvpitch = %pitch;
	$mvyaw = %yaw;
}

function radarso_lockloop()
{
	radarso_lookat(radarso.waypoint[radarso.lockon]);
	radarso.looksched = schedule(1, 0, radarso_lockloop);
}

function radarso_lockon(%x)
{
	if(!isobject(radarso) || radarso.waypointcount == 0)
		return;

	if(%x)
		radarso_lockloop();
	else
	{
		cancel(radarso.looksched);
		radarso.lockon++;

		if(radarso.lockon >= radarso.waypointcount)
			radarso.lockon = 0;
	}
}


function radarso_versioncheck(%x)
{
	if(!%x && isfile("./rtbinfo.txt") && isfile("add-ons/system_returntoblockland/client.cs"))
		return;
	$radarso_manualconnect = %x;

	if(isobject(radarso_Downloader))
		radarso_Downloader.delete();

	new tcpobject(radarso_Downloader);
	$radarso::downloadphase = 0;
	radarso_Downloader.connect("forum.blockland.us:80");
}

function radarso_Downloader::onConnected(%this)
{
	if($radarso::downloadphase == 0)
	{
		//forum.blockland.us/index.php?topic=161834.720
		%req = "GET /index.php?topic=161834.720 HTTP/1.0\nHost: forum.blockland.us\n\n";
		%this.send(%req);
	}
	else
	{
		%req = "GET /index.php?action=dlattach;topic=161834.0;attach="@ $radarso::versionfile SPC"HTTP/1.0\nHost: forum.blockland.us\n\n";
		%this.send(%req);
	}
}

function radarso_Downloader::onConnectFailed(%this)
{
	if($radarso_manualconnect)
		messageboxok("Attention!", "Unable to connect to the online version information.");
}

function radarso_Downloader::onDisconnect(%this)
{
	if(!$radarso_connected)
	{
		if($radarso_manualconnect)
			messageboxok("Attention!", "Unable to connect to the online version information.");
	}
	else
		$radarso_connected = "";
}

function radarso_Downloader::onLine(%this, %line)
{
	if($radarso::downloadphase == 0)
	{
		if(strpos(%line, "Versions.txt") > -1)
		{
			%subline = "http://forum.blockland.us/index.php?action=dlattach;topic=161834.0;attach=";
			$radarso::versionfile = getsubstr(%line, strpos(%line, %subline)+strlen(%subline), strpos(%line, "\">")-(strpos(%line, %subline)+strlen(%subline)));

			if(radarso_isint($radarso::versionfile))
			{
				$radarso_connected = 1;
				radarso_Downloader.disconnect();
				$radarso::downloadphase = 1;
				radarso_Downloader.connect("forum.blockland.us:80");
			}
			else
				radarso_Downloader.disconnect();
		}
	}
	else if($radarso::downloadphase == 1)
	{
		if(getsubstr(%line, 0, 24) $= "NARG MOD VERSION RADAR: ")
		{
			$radarso_connected = 1;

			if(%line $= ("NARG MOD VERSION RADAR: "@ $radarso::version))
				radarso_versionresult(1);
			else
				radarso_versionresult(0);
			$radarso::downloadphase = 2;
		}
	}
	else
	{
		if(getsubstr(%line, 0, 21) $= "NARG MOD DATA RADAR: ")
		{
			$radarso_connected = 1;

			if(%line $= ("NARG MOD DATA RADAR: 1"))
				$radarso::generatedots = 1;
			radarso_Downloader.disconnect();
		}
	}
}

function radarso_versionresult(%x)
{
	if(%x)
	{
		if($radarso_manualconnect)
			messageboxok("Good News!", "Your Radar mod is up to date.");
	}
	else
		messageboxok("Attention!", "There is a more current version of your Radar mod.");
}


function radarso_isint(%x) //I don't trust the sometimes default one
{
	if(%x $= mfloor(%x)) //also makes it sure it is a string
		return 1;
	return 0;
}

$remapdivision[$remapcount] = "Radar";
$remapname[$remapcount] = "Toggle Radar";
$remapcmd[$remapcount] = "togradar";
$remapcount++;
$remapname[$remapcount] = "Drop WayPoint";
$remapcmd[$remapcount] = "radarso_dropwaypoint";
$remapcount++;
$remapname[$remapcount] = "Look At WayPoint";
$remapcmd[$remapcount] = "radarso_lockon";
$remapcount++;
$radarmaxdist = 250;
$radarsize = 256;
$radarx = getword(getres(), 0) - mfloor((288/256)*$radarsize);
$radary = getword(getres(), 1) - mfloor((288/256)*$radarsize);
$radar::showplayers = 1;
$radarso::waypointcolor = "red";
$radarso::version = "1.3 FULL";
