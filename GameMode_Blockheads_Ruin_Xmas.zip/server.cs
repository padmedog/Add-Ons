
if($GameModeArg !$= "Add-Ons/Gamemode_Blockheads_Ruin_Xmas/gamemode.txt" )
{
   error("Error: Gamemode_Blockheads_Ruin_Xmas cannot be used in custom games");
   return;
}


exec("./support.cs");
exec("./datablocks.cs");
exec("./santa.cs");


if(isPackage(snowballPackage))
   deactivatePackage(snowballPackage);


RuinXmas_BeginWaitForPlayers();
