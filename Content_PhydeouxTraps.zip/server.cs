%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("Content_PhydeouxTraps: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/BearTrap.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/PressurePlateSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/PressurePlateSwitchSmooth.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/PressurePlateSmall.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/PressurePlateSmallSmooth.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/FloorSpikeTrap.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/WallSpikeTrap.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/CeilingSpikeTrap.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/SpinningSawBlade.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxtraps/types/SpinningSawBladeHorizontal.cs");
}