//audio

AddDamageType("ScopedMagnum",   '<bitmap:add-ons/Weapon_Package_Tier2/CI_ScopedMagnum> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2/CI_ScopedMagnum> %1',0.75,1);
datablock ProjectileData(ScopedMagnumProjectile)
{
   projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = ($BushidoL4DGuns::UsingRotZombies ? 90 : 50);
   directDamageType    = $DamageType::ScopedMagnum;
   radiusDamageType    = $DamageType::ScopedMagnum;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 14;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 22;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 1800;
   verticalImpulse	  = 800;
   explosion           = ShotgunExplosion;
   particleEmitter     = "MagnumTrailEmitter";

   muzzleVelocity      = 180;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 8000;
   fadeDelay           = 7200;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(ScopedMagnumItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Scoped_Magnum.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Scoped Magnum";
	iconName = "./iconScopedMagnum";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.75 1.000";

	 // Dynamic properties defined by the scripts
	image = ScopedMagnumImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 4;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(ScopedMagnumImage)
{

   // Basic Item properties
   shapeFile = "./Scoped_Magnum.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = ScopedMagnumItem;
   ammo = " ";
   projectile = ScopedMagnumProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = ScopedMagnumItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= MagnumfireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.4;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.65;
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 0.6;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	stateSound[8]				= Block_MoveBrick_Sound;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.3;
	stateScript[9]				= "onReloaded";
	stateTransitionOnTimeout[9]		= "Ready";
	stateSound[9]				= Block_PlantBrick_Sound;
};

function ScopedMagnumImage::onFire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, activate);

	%obj.toolAmmo[%obj.currTool]--;

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%spread = 0.0001;
	}
	else
	{
		%spread = 0;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}

function ScopedMagnumImage::onReloadStart(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, shiftDown);
	%obj.playThread(3, plant);
}

function ScopedMagnumImage::onReloaded(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
	%obj.playThread(3, shiftLeft);
	
	%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
	%obj.setImageAmmo(%slot,1);
}

//needs more critical headshots. the ScopedMagnum feels like a posing pistol right now :(
//using a weird offshoot of the huntsman's code for the moment

function ScopedMagnumProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 40;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 2;
         %damageType = $DamageType::ScopedMagnum;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}