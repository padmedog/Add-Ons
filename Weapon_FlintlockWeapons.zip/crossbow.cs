//########## Crossbow

//### Sounds

datablock AudioProfile(gc_CrossbowFireSound)
{
  filename = "./crossbow.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Projectile

AddDamageType("gc_Crossbow",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_crossbow> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_crossbow> %1',0.2,1);

datablock ProjectileData(gc_CrossbowProjectile)
{
  uiName = "";
  projectileShapeName = "./bolt.dts";
  directDamage = 50;
  directDamageType = $DamageType::gc_Crossbow;
  radiusDamageType = $DamageType::gc_Crossbow;
  brickExplosionRadius = 0;
  brickExplosionImpact = false;
  impactImpulse = 500;
  verticalImpulse = 0;
  particleEmitter = "";
  explosion = gunExplosion;
  particleEmitter = gc_GrenadeTrailEmitter;
  muzzleVelocity = 150;
  armingDelay = 0;
  lifetime = 2000;
  fadeDelay = 2000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 0.2;
};

//### Item

datablock ItemData(gc_CrossbowItem)
{
  uiName = "Crossbow";
  iconName = "./icon_crossbow";
  image = gc_CrossbowImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./crossbow.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_CrossbowImage)
{
  shapeFile = "./crossbow.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_CrossbowItem;
  ammo = "";
  projectile = gc_CrossbowProjectile;
  projectilespread = 0;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;
  stateSequence[0] = "Ready";

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";
  stateSequence[1] = "Ready";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "AmmoCheck";
  stateTimeoutValue[2] = 0.1;
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateSound[2] = gc_CrossbowFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Fire";

  stateName[3] = "AmmoCheck";
  stateTransitionOnTimeout[3] = "Ready";
  stateAllowImageChange[3] = true;
  stateScript[3] = "onAmmoCheck";

  stateName[4] = "Reload";
  stateTimeoutValue[4] = 2;
  stateTransitionOnTimeout[4] = "Done";
  stateWaitForTimeout[4] = true;
  stateAllowImageChange[4] = true;
  stateScript[4] = "onReloadStart";
  stateSequence[4] = "Reload";

  stateName[5] = "Done";
  stateTransitionOnTimeout[5] = "Ready";
  stateTimeoutValue[5] = 0.1;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReload";
};

//### Functions

function gc_CrossbowImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %spread = %this.projectilespread;
  if(vectorLen(%obj.getVelocity()) >= 5 && !isObject(%obj.getObjectMount())) %spread += 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
}
function gc_CrossbowImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_CrossbowImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,shiftRight); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }
function gc_CrossbowImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(0,1); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }

function gc_CrossbowProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(miniGameCanDamage(%obj,%col) && getMiniGameFromObject(%col) != -1) {
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
  if(%col.isCrouched() != 1) {
  %colscale = getWord(%col.getScale(),2);
  if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale)
  { %col.damage(%obj,%pos,%this.directDamage,%this.directDamageType); } } }
  if(%col.getType() & $TypeMasks::VehicleObjectType)
  { %col.damage(%obj,%pos,5,%this.directDamageType); return 1; } }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}
