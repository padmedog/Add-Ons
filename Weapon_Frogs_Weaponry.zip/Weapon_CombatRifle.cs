//audio


AddDamageType("CombatRifle",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_CombatRifle> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_CombatRifle> %1',0.75,1);
AddDamageType("CombatRifleHeadshot",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_CombatRifle>  <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_FWHeadshot>%1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_CombatRifle> <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_FWHeadshot>%1',0.75,1);
datablock ProjectileData(CombatRifleProjectile1)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 30;
   directDamageType    = $DamageType::CombatRifle;
   radiusDamageType    = $DamageType::CombatRifle;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 20;
   verticalImpulse     = 10;
   explosion           = gunExplosion;

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.05; //0.7

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(CombatRifleItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./CombatRifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Combat-Rifle";
	iconName = "./icon_CombatRifle";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = CombatRifleImage;
	canDrop = true;
	
	maxAmmo = 12;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(CombatRifleImage)
{
   // Basic Item properties
   shapeFile = "./CombatRifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = CombatRifleItem;
   ammo = " ";
   projectile = CombatRifleProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 -1.0 1.0"; //1.0 0.1 1.0
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = CombatRifleItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= CombatRiflefireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.05;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[2]              = true;
	stateTimeoutValue[4]		= 0.2;
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 2.1;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.3;
	stateScript[9]				= "onReloaded";
        stateTransitionOnTimeout[9]		= "Ready";
};

function CombatRifleImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
}

function CombatRifleImage::onFire(%this,%obj,%slot)
{
	%projectile = CombatRifleProjectile1;
	
	if(vectorLen(%obj.getVelocity()) < 0.1)
	{
		%spread = 0.00025; //0.0010
	}
	else
	{
		%spread = 0.001; //0.0050
	}
	
	%shellcount = 1;

	%obj.playThread(2, plant);
	%shellcount = 1;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function CombatRifleImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["708rounds"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function CombatRifleImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["708rounds"] >= 1)
	{

	%obj.playThread(2, plant);
        if(%obj.client.quantity["708rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["708rounds"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
            serverPlay3D(FWReload1sound,%obj.getPosition());
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["708rounds"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["708rounds"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.client.quantity["708rounds"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}
function CombatRifleProjectile1::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = 30;
   %damage = %directDamage;

   %sobj = %obj.sourceObject;
   if(%sobj.getType() & $TypeMasks::PlayerObjectType)
   {
      if(isObject(%sobj.client))
         %sobj.client.play2d(bulletHitSound);
   }
   
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale)
      {
         %directDamage = %directDamage * 3;
         %damageType = $DamageType::CombatRifleHeadshot;
         
         %col.spawnExplosion(critProjectile,%colscale);
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         
         if(%sobj.getType() & $TypeMasks::PlayerObjectType)
         {
            serverplay3d(critFireSound,%sobj.getHackPosition());
            if(isObject(%sobj.client))
               %sobj.client.play2d(critHitSound);
         }
      }
      
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
}
//statescript onBounce