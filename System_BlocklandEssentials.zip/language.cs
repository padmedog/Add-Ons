function isInteger(%string){ return (stripChars(%string, "-0123456789") $= ""); } //this function is from Mr. Doom

function dolanguageFile(%filepath)
{
	echo("LANG --- Switching languages!");

	if(!isFile(%filepath))
	{
		warn("LANG --- Invalid file");
		return;
	}

	%file = new FileObject();
	%file.openForRead(%filepath);
	
	%currentElement = -1;
	%numline = 0;

	while(!%file.isEOF())
	{
		%line = %file.readLine();
		if(getField(%line,0) $= "element")
		{
			if(getFieldCount(%line) < 2)
				warn("LANG --- Not enough arguments, line " @ %numline @ " : " @ %line);
			else
			{
				%currentElement = getField(%line,1);
				if(getFieldCount(%line) > 2)
				{
					if(isObject(%currentElement))
						%currentElement.setText(getField(%line,2));
					else
						warn("LANG --- Could not find object, line " @ %numline @ " : " @ %line);
				}
			}
		}
		else if(getField(%line,0) $= "child")
		{
			if(getFieldCount(%line) < 2)
				warn("LANG --- Not enough arguments, line " @ %numline @ " : " @ %line);
			else
			{
				if(!isObject(%currentElement))
					warn("LANG --- Element is invalid can not access child, line " @ %numline @ " : " @ %line);
				else
				{
					%currentElement = %currentElement.getObject(getField(%line,1));
					if(getFieldCount(%line) > 2)
					{
						if(isObject(%currentElement))
							%currentElement.setText(getField(%line,2));
						else
							warn("LANG --- Could not find object, line " @ %numline @ " : " @ %line);
					}
				}
			}
		}
		else if(isInteger(getField(%line,0)))
		{
			if(getFieldCount(%line) < 2)
				warn("LANG --- Not enough arguments, line " @ %numline @ " : " @ %line);
			else
			{
				if(!isObject(%currentElement))
					warn("LANG --- Element is invalid can not access child, line " @ %numline @ " : " @ %line);
				else
				{
					%object = %currentElement.getObject(getField(%line,0));
					if(!isObject(%object))
						warn("LANG --- Could not find object, line " @ %numline @ " : " @ %line);	
					else
						%object.setText(getField(%line,1));
				}
			}
		}
		else if(getField(%line,0) $= "#name" || getField(%line,0) $= "#author")
		{
			
		}
		else
			warn("LANG --- Invalid command, line " @ %numline @ " : " @ %line);

		%numline++;
	}

	%file.close();
	%file.delete();
}

function fileCopyFromZIP(%source,%dest)
{
	if(!isFile(%source))
		return 0;
	
	%sourcefile = new FileObject();
	%destfile = new FileObject();

	%sourcefile.openForRead(%source);
	%destfile.openForWrite(%dest);

	while(!%sourcefile.isEOF())
		%destfile.writeLine(%sourcefile.readline());

	%sourcefile.close();
	%destfile.close();

	%sourcefile.delete();
	%destfile.delete();

	return 1;
}

function copylanguageFile(%file)
{
	%name = "config/client/languages/" @ fileName(%file);
	echo("Moving " @ %file @ " to " @ %name);

	if(!isFile(%file))
	{
		warn("Couldn't copy language file, source invalid.");
		return;
	}

	if(isFile(%name))
		fileDelete(%name);

	fileCopyFromZIP(%file,%name);	
}

function copyLanguageFiles()
{
	if(isFile("config/client/languages/language.cs"))
		exec("config/client/languages/language.cs");
	else
		$language = "config/client/languages/english.txt";

	export("$language","config/client/languages/language.cs");

	%firstFile = findFirstfile("Add-Ons/System_BlocklandEssentials/languages/*");
	copyLanguageFile(%firstFile);
	%tmp = "";
	while(isFile(%tmp = findNextFile("Add-Ons/System_BlocklandEssentials/languages/*")))
		copylanguageFile(%tmp);
}

copyLanguageFiles();

function getLanguageFiles()
{
	$langs = 0;
	%first = findFirstFile("config/client/languages/*");
	if(!isFile(%first))
	{
		echo("No languages found!");
		return;
	}

	%fileObject = new FileObject();
	%fileObject.openForRead(%first);
	%name = "Unknown";
	while(!%fileObject.isEOF())
	{
		%line = %fileObject.readLine();
		if(getfield(%line,0) $= "#name")
		{
			%name = getField(%line,1);
			break;
		}
	}

	%fileObject.close();
	%fileObject.delete();

	$langFile[$langs] = %first;
	$langName[$langs] = %name;
	$langs++;

	%next = "";
	while(isFile(%next = findNextFile("config/client/languages/*")))
	{
		%fileObject = new FileObject();
		%fileObject.openForRead(%next);
		%name = "Unknown";
		while(!%fileObject.isEOF())
		{
			%line = %fileObject.readLine();
			if(getfield(%line,0) $= "#name")
			{
				%name = getField(%line,1);
				break;
			}
		}
		$langFile[$langs] = %next;
		$langName[$langs] = %name;
		$langs++;
		%fileObject.close();
		%fileObject.delete();
	}
	echo($langs-1 SPC "languages found.");

	languageButton.clear();
	for(%a=0;%a<$langs;%a++)
		if($langname[%a] !$= "" && $langname[%a] !$= " " && $langfile[%a] !$= "config/client/languages/language.cs")
			languageButton.add($langname[%a],%a);
}

schedule(2000,0,getLanguageFiles);

function languageButton::onSelect(%this,%that)
{
	$language = $langfile[%that];
	doLanguageFile($language);
	export("$language","config/client/languages/language.cs");
}

function lastLanguageCall()
{
	languageButton.setValue(fileName($language));
	doLanguageFile($language);	 
}

schedule(3000,0,lastLanguageCall);
