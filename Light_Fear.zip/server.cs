datablock fxLightData(FearLight)
{
	uiName = "FearLights-Alien Light";

	LightOn = true;
	radius = 50;
	brightness = 6;
	color = "0.2 1 0.8 1";

	flareOn = true;
	flarebitmap = "Add-Ons/Light_Fear/alienlight";
	NearSize = 1;
	FarSize = 1;
};
datablock fxLightData(WhirlLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-Whirl Light";
	color = "0 0.96 0.72 1";
	flarebitmap = "Add-Ons/Light_Eksi/morphinglight";
};
datablock fxLightData(WorldLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-World Light";
	color = "0.64 0.88 0.88 1";
	flarebitmap = "Add-Ons/Light_Eksi/worldlight";
};
datablock fxLightData(SunLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-Sun Light";
	color = "1 0.2 0 1";
	flarebitmap = "Add-Ons/Light_Eksi/sunlight";
};
datablock fxLightData(DrawnBubbleLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-Drawn Bubble Light";
	color = "0 0 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/drawnbubblelight";
};
datablock fxLightData(DrawnBubbleLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-Drawn Bubble Light";
	color = "0 0 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/drawnbubblelight";
};
datablock fxLightData(RoundLight : FearLight)
{
	brightness=5;
	uiName = "FearLights-Round Light";
	color = "0 0 0.9 1";
	flarebitmap = "Add-Ons/Light_Eksi/roundlight";
};
datablock fxLightData(DecentGlowLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-Decent Glow Light";
	color = "0 0.2 0.7 1";
	flarebitmap = "Add-Ons/Light_Eksi/decentglow";
};
datablock fxLightData(DecentLight : FearLight)
{
	brightness=7;
	uiName = "FearLights-Decent Light";
	color = "0 0.2 0.7 1";
	flarebitmap = "Add-Ons/Light_Eksi/decentlight";
};
//AmpLights
datablock fxLightData(FearLightAmp)
{
	uiName = "FearLightsAmp-Alien Light";

	LightOn = true;
	radius = 50;
	brightness = 12;
	color = "0.2 1 0.8 1";

	flareOn = false;
	flarebitmap = "Add-Ons/Light_Fear/alienlight";
	NearSize = 1;
	FarSize = 1;
};
datablock fxLightData(WhirlLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-Whirl Light";
	color = "0 0.96 0.72 1";
	flarebitmap = "Add-Ons/Light_Eksi/morphinglight";
};
datablock fxLightData(WorldLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-World Light";
	color = "0.64 0.88 0.88 1";
    flarecolor = "0.5 0.5 0.5";
	flarebitmap = "Add-Ons/Light_Eksi/worldlight";
};
datablock fxLightData(SunLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-Sun Light";
	color = "1 0.2 0 1";
	flarebitmap = "Add-Ons/Light_Eksi/sunlight";
};
datablock fxLightData(DrawnBubbleLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-Drawn Bubble Light";
	color = "0 0 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/drawnbubblelight";
};
datablock fxLightData(DrawnBubbleLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-Drawn Bubble Light";
	color = "0 0 1 1";
	flarebitmap = "Add-Ons/Light_Eksi/drawnbubblelight";
};
datablock fxLightData(RoundLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-Round Light";
	color = "0 0 0.9 1";
	flarebitmap = "Add-Ons/Light_Eksi/roundlight";
};
datablock fxLightData(DecentGlowLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLightsAmp-Decent Glow Light";
	color = "0 0.2 0.7 1";
	flarebitmap = "Add-Ons/Light_Eksi/decentglow";
};
datablock fxLightData(DecentLight : FearLightAmp)
{
	brightness=14;
	uiName = "FearLights-Decent Light";
	color = "0 0.2 0.7 1";
	flarebitmap = "Add-Ons/Light_Eksi/decentlight";
};
