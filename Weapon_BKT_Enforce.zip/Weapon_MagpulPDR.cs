datablock AudioProfile(MPDRFireSound)
{
   filename    = "./MPDRFire.wav";
   description = GunShotRange3d;
   preload = true;
};
datablock ProjectileData(MPDRProjectile)
{
	directDamage		= 22;
	gravityMod			= 0.3;
	muzzleVelocity		= 190;
	brickExplosionForce	= 10;
	impactImpulse		= 100;
	verticalImpulse		= 200;
	lifetime			= 4000;
	fadeDelay			= 3000;
	particleEmitter		= "ShortVaporTrailEmitter";

	radiusDamage		= 0;
	damageRadius		= 0;
	projectileShapeName	= "add-ons/weapon_gun/bullet.dts";
	directDamageType	= $DamageType::UniversalHeadshot;
	radiusDamageType	= $DamageType::UniversalHeadshot;
	brickExplosionRadius			= 0;
	brickExplosionImpact			= true;
	brickExplosionMaxVolume			= 3;
	brickExplosionMaxVolumeFloating	= 10;
	explosion			= GBImpact2Explosion;
	sound				= BulletWhizzingSound;
	velInheritFactor	= 0;
	armingDelay			= 10;
	bounceElasticity	= 0.5;
	bounceFriction		= 0.1;
	isBallistic			= true;
	hasLight			= false;
	lightRadius			= 3.0;
	lightColor			= "0 0 0";
};
function MPDRProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	%damageType = $DamageType::Direct;
	if(%this.DirectDamageType)
	{
		%damageType = %this.DirectDamageType;
	}
	%scale = getWord(%obj.getScale(), 2);
	%directDamage = 14*5;
	%damage = %directDamage;
	%sobj = %obj.sourceObject;
	if(%col.getType() & $TypeMasks::PlayerObjectType)
	{
		%directDamage = 22;
		%colscale = getWord(%col.getScale(),2);
		if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale && $BKT::HS)
		{
			%directDamage = 60;
			%damageType = $DamageType::UniversalHeadshot;
		}
		%col.damage(%obj, %pos, %directDamage, %damageType);
	}
	else
	{
		%col.damage(%obj,%pos,%directDamage,%damageType);
	}
}
datablock ItemData(MPDRItem)
{
	shapeFile	= "./MPDR.dts";
	iconName	= "./icon_MPDR";
	image		= MPDRImage;
	uiName			= "PDR";
	maxAmmo			= 20;

	category		= "Weapon";
	className		= "Weapon";
	rotate			= false;
	mass			= 1;
	density			= 1.5;
	elasticity		= 0.2;
	friction		= 0.75;
	emap			= true;
	doColorShift	= true;
	colorShiftColor	= "0.5 0.5 0.52 1";
	canDrop			= true;
	canReload		= 1;
};
datablock ShapeBaseImageData(MPDRImage)
{
	shapeFile	= "./MPDR.dts";
	item		= MPDRItem;
	projectile	= MPDRProjectile;
	shellVelocity	= 12.0;
	shellExitDir	= "1 -0.0 0.1";
	minShotTime		= 75;
	eyeOffset		= "0 0 0";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 6.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= MPDRItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.225;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.05;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.05;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "fire";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.05;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= MPDRFireSound;

	stateName[3]				= "Smoke";
	stateSequence[3]			= "Reload";
	stateEjectShell[3]			= true;
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "LoadCheckA";
	stateTimeoutValue[3]		= 0.015;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.01;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateAllowImageChange[6]	= true;
	stateTimeoutValue[6]		= 1.2;
	stateScript[6]				= "OnReload";
	stateTransitionOnTimeout[6]	= "Reloaded";
	stateWaitForTimeout[6]		= true;
	
	stateName[7]				= "Reloaded";
	stateAllowImageChange[7]	= false;
	stateTimeoutValue[7]		= 0.3;
	stateScript[7]				= "onReloaded";
	stateTransitionOnTimeout[7]	= "Ready";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.3;
	stateTransitionOnTimeout[9]	= "Reload";
};
function MPDRImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
}
function MPDRADSImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::CH)
	{
		crossHair.setBitmap("add-ons/weapon_blockombat/empty.png");
	}
}
function MPDRImage::onFire(%this,%obj,%slot)
{
	MPDRFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function MPDRImage::onWeaponLoop(%this,%obj,%slot)
{
	if(%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function MPDRFire(%this,%obj,%slot,%val)
{
	%projectile = MPDRProjectile;
	if(%obj.heat >= 6)
	{
		%obj.playThread(3, plant);
	}
	if(%obj.isImageMounted(MPDRImage))
	{
		%spread = 0.0012 + (%obj.heat * 0.00015);
	}
	else if(%obj.isImageMounted(MPDRADSImage))
	{
		%spread = 0.0006 + (%obj.heat * 0.00015);
	}
	%obj.maxHeat = 10;
	if(%obj.heat < %obj.maxHeat)
		%obj.heat += 2;
	%shellcount = 1;
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	if($BKT::Flash)
	{
		%projectile = "ATACFlashProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function MPDRImage::onReload(%this,%obj,%slot)
{
	%obj.client.quantity["556rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;%obj.heat = 0;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if(%obj.client.quantity["556rounds"] >= 1)
	{
		%obj.playThread(2, shiftdown);
		%obj.playThread(3, plant);
		serverPlay3D(rifleMagOutSound,%obj.getPosition()); 
	}
}
function MPDRImage::onReloaded(%this,%obj,%slot)
{
	if(%obj.client.quantity["556rounds"] >= 1)
	{
		if(%obj.client.quantity["556rounds"] > %this.item.maxAmmo)
		{
			%obj.client.quantity["556rounds"] -= %this.item.maxAmmo;
			%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
			%obj.setImageAmmo(%slot,1);
			%obj.playThread(2, shiftright);
			%obj.playThread(3, plant);
			serverPlay3D(rifleMagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
		}
		else if(%obj.client.quantity["556rounds"] <= %this.item.maxAmmo)
		{
			%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["556rounds"];
			%obj.setImageAmmo(%slot,1);
			%obj.client.quantity["556rounds"] = 0;	
			%obj.playThread(2, shiftright);
			%obj.playThread(3, plant);
			serverPlay3D(rifleMagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
			return;
		}
	}
}
datablock ShapeBaseImageData(MPDRADSImage)
{
	shapeFile	= "./MPDR.dts";
	item		= MPDRItem;
	projectile	= MPDRProjectile;
	shellVelocity	= 12.0;
	shellExitDir	= "1 -0.0 0.1";
	minShotTime		= 75;
	eyeOffset		= "0 0.9 -0.83";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 6.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= MPDRItem.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.15;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.05;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.05;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "fire";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.05;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= MPDRFireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "LoadCheckA";
	stateTimeoutValue[3]		= 0.015;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.01;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateScript[6]				= "OnReload";
	
	stateName[7]				= "Reloaded";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.4;
	stateTransitionOnTimeout[9]	= "Reload";
};
function MPDRADSImage::onWeaponLoop(%this,%obj,%slot)
{
	if (%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function MPDRADSImage::onFire(%this,%obj,%slot)
{
	MPDRFire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function MPDRADSImage::onReload(%this,%obj,%slot)
{
	%obj.mountImage(MPDRImage,0);
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 PDW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
}
package MPDRSights
{
	function armor::onTrigger(%this,%obj,%triggerNum,%val)
	{
		%client = %obj.client;		
		if(%obj.getMountedImage(0) $= MPDRImage.getID() && %triggerNum == 4 && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(MPDRADSImage, 0);
			%client.setControlCameraFov(80);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		else if(%triggerNum == 4 && %obj.getMountedImage(0) $= MPDRADSImage.getID() && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(MPDRImage, 0);
			%client.setControlCameraFov(90);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		Parent::onTrigger(%this,%obj,%triggerNum,%val);
	}
	function servercmdDropTool(%client,%slot)
	{
		if(%client.player.getMountedImage(0) $= MPDRADSImage.getID())
		{
		 	%client.player.unmountImage(0);
			%client.setControlCameraFov(90);
			if($BKT::CH)
			{
				crossHair.setBitmap("base/client/ui/crosshair.png");
			}
		}
		return Parent::servercmdDropTool(%client,%slot);
	}
};
activatePackage(MPDRSights);
function MPDRADSImage::onUnMount(%this,%obj,%slot)
{
	%obj.client.setControlCameraFov(90);
	if($BKT::CH)
	{
		crossHair.setBitmap("base/client/ui/crosshair.png");
	}
}