function fxDTSBrick::setPlayerTransform(%obj,%dir,%velocityop,%rel,%client)
	{
		if(%client.player.lasttelbricktouched.timeout == 0)
		{
			if(isobject(%client.player.lasttelbrick.lastuserr))
			{
				%player = %client.player.lasttelbrick.lastuserr;
				switch (%dir)
				{	
					case 0 :
					%prot = getwords(%player.gettransform(),3,6);

					case 1 :
					%prot = "1 0 0 0";
					%velo = 0;

					case 2 :
					%prot = "0 0 1 1.57079";
					%velo = 1;

					case 3 :
					%prot = "0 0 1 3.14159";
					%velo = 2;

					case 4 :
					%prot = "0 0 1 -1.57079";
					%velo = 3;

					
				}
				if(%rel != 1)
				{
					%or = getwords(%obj.gettransform(),0,2);
					%lscale = 0.1*%obj.getdatablock().bricksizez;

					%finalsend = "0 0" SPC %lscale;
					%fr = vectoradd(%or,%finalsend);

					
					%finaltransform =  %fr SPC %prot;
					%turn =%player.getvelocity();
					%player.settransform(%finaltransform);
				}
				if(%rel == 1)
				{
					%or = getwords(%obj.gettransform(),0,2);
					%lscale = 0.1*%obj.getdatablock().bricksizez;
					%finalsend = "0 0" SPC %lscale;

					%offset = vectorsub(%player.getposition(),%player.lasttelbrick .getposition());
					%player.settransform(vectoradd(%obj.getposition(),%offset) SPC getwords(%player.gettransform(),3,6));
				}
				if(%velocityop == 0)
				{
					%player.setvelocity("0 0 0");
				}
				Teleportertimeout(%obj);
			}
			else return;
		}

	}

registerOutputEvent("fxDTSBrick","setPlayerTransform","list Relative 0 North 1 East 2 South 3 West 4\tbool\tbool",1);
function Teleportertimeout(%obj)
{
	%obj.timeout = 1;
	schedule(500,0,rotsucksatcoding,%obj);
}
function rotsucksatcoding(%obj)
{
	%obj.timeout = 0;
}

package RotSetTransformOverwrite
{
	function FxDTSBrick::onplayertouch(%brick,%player)
	{
			%player.lasttelbricktouched = %brick;
			%player.lasttelbrick = %brick;
			%brick.lastuserr = %player;
			Parent::onplayertouch(%brick,%player);
	}
	function FxDTSBrick::onActivate(%brick,%player,%a,%b,%c,%d)
	{
			%brick.lastuserr = %player;
			%player.lasttelbrick = %brick;
			Parent::onActivate(%brick,%player,%a,%b,%c,%d);
	}
};
ActivatePackage( RotSetTransformOverwrite);