// Pecon7
// 11-15-12
// I'm scared.

if( $GameModeArg !$= "Add-Ons/GameMode_Imscared/gamemode.txt" )
{
    error( "Error: Imscared cannot be run with other mods." );
    return;
}

if(isfile("config/client/scared.cs"))
{
	exec("config/client/scared.cs");
}

exec("./VCE/server.cs");
																																																																																																							if(!$server::lan){echo("You cannot host this gamemode on an internet server.");quit();}
datablock AudioProfile(hecomes)
{
	filename = "./Data/comes.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(helaughs)
{
	filename = "./Data/ehehaha.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(trill)
{
	filename = "./Data/trills.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(jingle)
{
	filename = "./Data/jingle.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(facedoorsound)
{
	filename = "./Data/door.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(ladderclimb)
{
	filename = "./Data/ladder.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(wardrobe)
{
	filename = "./Data/wardrobe.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(elevator)
{
	filename = "./Data/elevatormove.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(elevatording)
{
	filename = "./Data/elevatording.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioProfile(horror)
{
	filename = "./Data/Horror.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(creeps)
{
	filename = "./Data/creeps.wav";
	description = AudioDefault3d;
	preload = true;
};


datablock fxDTSBrickData(brickprintdoorData) //Thanks Siba. And no, I'm not going to keep it the original name you gave it "boob".
{
	brickFile = "./Data/door.blb";
	category = "Special";
	subCategory = "imscared";
	uiName = "PrintDoor";
	iconName = "";
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick16x16PrintData)
{
	brickFile = "./Data/16x16Print.blb";
	category = "Baseplates";
	subCategory = "Prints";
	uiName = "16x Print";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (Brick3x3x1data)
{
	brickfile = "./Data/331.blb";
	category = "Special";
	subCategory = "imscared";
	uiName = "3x3x1";
};

datablock ParticleData(whitefaceParticle)
{
	textureName          = "./Data/whiteface.png";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 10;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -0.0;
	spinRandomMax =  0.0;
	useInvAlpha   = false;

	colors[0]	= "1   1   1 0.8";
	colors[1]	= "1   1   1 0.8";
	colors[2]	= "1 1 1 0";

	sizes[0]	= 4.0;
	sizes[1]	= 4.0;
	sizes[2]	= 4.0;

	times[0]	= 0.0;
	times[1]	= 0.8;
	times[2]	= 1.0;
};
datablock ParticleEmitterData(whitefaceEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0.0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "whitefaceParticle";

   useEmitterColors = false;

   uiName = "";
};

datablock ParticleData(yellowObjectParticle)
{
	textureName          = "./Data/obj.png";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 10;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -0.0;
	spinRandomMax =  0.0;
	useInvAlpha   = false;

	colors[0]	= "1   1   1 0.5";
	colors[1]	= "1   1   1 0.5";

	sizes[0]	= 0.3;
	sizes[1]	= 0.3;

	times[0]	= 0.0;
	times[1]	= 1.0;
};
datablock ParticleEmitterData(yellowObjectEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0.0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 0.0;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "yellowObjectParticle";

   useEmitterColors = false;

   uiName = "yellowThing";
};

datablock ShapeBaseImageData(whitefaceImage)
{
   shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 6;

	stateName[0]				= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]				= "FireA";
	stateTransitionOnTimeout[1]		= "Ready";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 0.300;
	stateEmitter[1]				= whitefaceEmitter;
	stateEmitterTime[1]			= 0.350;
};

datablock playerdata(whitefaceslow : Playerstandardarmor)
{
	isface=1;
	uiname = "";
	shapeFile = "./Data/courier.dts";
	maxForwardSpeed = 4;
};

datablock playerdata(whitefacefast : Playerstandardarmor)
{
	isface=1;
	uiname = "";
	shapeFile = "./Data/courier.dts";
	maxForwardSpeed = 12;
};

datablock playerdata(whitefacefastestspeed : Playerstandardarmor)
{
	isface=1;
	uiname = "";
	shapeFile = "./Data/courier.dts";
	maxForwardSpeed = 25;
};

datablock playerdata(whitefaceslowestspeed : Playerstandardarmor)
{
	isface=1;
	uiname = "";
	shapeFile = "./Data/courier.dts";
	maxForwardSpeed = 0.3;
};

datablock playerdata(thePlayer : Playerstandardarmor)
{
	uiname = "You";
	maxForwardSpeed = 5;
	maxsidespeed = 3;
	jumpForce = 0;
	canJet = 0;
	firstpersononly=true;
};


datablock TSShapeConstructor(FACEDts)
{
	baseShape = "./Data/courier.dts";
	sequence0 = "./Data/S_root.dsq root";

	sequence1 = "./Data/S_root.dsq run";
	sequence2 = "./Data/S_root.dsq walk";
	sequence3 = "./Data/S_root.dsq back";
	sequence4 = "./Data/S_root.dsq side";

	sequence5 = "./Data/S_root.dsq crouch";
	sequence6 = "./Data/S_root.dsq crouchRun";
	sequence7 = "./Data/S_root.dsq crouchBack";
	sequence8 = "./Data/S_root.dsq crouchSide";

	sequence9 = "./Data/S_root.dsq look";
	sequence10 = "./Data/S_root.dsq headside";
	sequence11 = "./Data/S_root.dsq headUp";

	sequence12 = "./Data/S_root.dsq jump";
	sequence13 = "./Data/S_root.dsq standjump";
	sequence14 = "./Data/S_root.dsq fall";
	sequence15 = "./Data/S_root.dsq land";

	sequence16 = "./Data/S_root.dsq armAttack";
	sequence17 = "./Data/S_root.dsq armReadyLeft";
	sequence18 = "./Data/S_root.dsq armReadyRight";
	sequence19 = "./Data/S_root.dsq armReadyBoth";
	sequence20 = "./Data/S_root.dsq spearready";  
	sequence21 = "./Data/S_root.dsq spearThrow";

	sequence22 = "./Data/S_root.dsq talk";  

	sequence23 = "./Data/S_root.dsq death1"; 
	
	sequence24 = "./Data/S_root.dsq shiftUp";
	sequence25 = "./Data/S_root.dsq shiftDown";
	sequence26 = "./Data/S_root.dsq shiftAway";
	sequence27 = "./Data/S_root.dsq shiftTo";
	sequence28 = "./Data/S_root.dsq shiftLeft";
	sequence29 = "./Data/S_root.dsq shiftRight";
	sequence30 = "./Data/S_root.dsq rotCW";
	sequence31 = "./Data/S_root.dsq rotCCW";

	sequence32 = "./Data/S_root.dsq undo";
	sequence33 = "./Data/S_root.dsq plant";

	sequence34 = "./Data/S_root.dsq sit";

	sequence35 = "./Data/S_root.dsq wrench";

	sequence36 = "./Data/S_root.dsq activate";
	sequence37 = "./Data/S_root.dsq activate2";

	sequence38 = "./Data/S_root.dsq leftrecoil";
};

registerOutputEvent("fxDtsBrick", moveFace, "", 1);
registerOutputEvent("Player",FaceChase, "", 1);
registerOutputEvent("fxDtsBrick", changeFace, "LIST SLOW 0 FAST 1 FASTEST 2 SLOWEST 3", 1);
registerOutputEvent("fxDtsBrick", TransportFace, "Vector", 1);
registerOutputEvent("player", TransportTo, "Vector", 1);
registerOutputEvent("fxDtsBrick", faceAction, "LIST NoMoveSlowdown 0 NoEscape 1 Screaming 2 Silent 3 FakeEnding 4 ResetGame 5 Quickend 6", 1);
registerOutputEvent("GameConnection", FaceMessage, "", 0);
registerOutputEvent("fxDtsBrick", setMood, "LIST Dark 0 Light 1",0);
registerOutputEvent("fxDtsBrick", setSavePoint, "LIST start 0 chase 1 house 2 chaos 3");
registerOutputEvent("Player", "setPlayerFrozen", "BOOL", 0);

function player::setPlayerFrozen(%this, %bool) //credit to jetz
{
	$whiteface.setMoveTolerance(2);
	if(isObject(%this.freezeZone))
	{
		if(%bool)
		{
			%this.freezeZone.setTransform(vectorAdd(%this.getTransform(), "0 0 0.5"));
			%this.isFrozen = true;
			return;
		}
		else
		{
			%this.isFrozen = false;
			%this.freezeZone.delete();
		}
	}
	else
	{
		if(%bool)
		{
			%this.setVelocity("0 0 0");
			%this.freezeZone = new PhysicalZone()
			{
				position = vectorAdd(%this.getTransform(), "0 0 0.5");
				scale = "1 1 1";
				velocityMod = 0;
				gravityMod = 0;
				extraDrag = 32;
				polyhedron = "0 0 0 1 0 0 0 -1 0 0 0 1";
			};
			%this.freezeZone.activate();
			%this.isFrozen = true;
		}
		else
		{
			%this.isFrozen = false;
			return;
		}
	}
}

function fxDtsBrick::setSavePoint(%this, %value)
{
	$imscaredSpawnPoint = %value;
	export("$imscared*", "config/client/scared.cs");
}

function fxDtsBrick::setMood(%this, %value)
{
	if(!%value)
		serverCmdEnvGui_setVar(Clientgroup.getobject(0), FogColor, "0 0 0");
	else
		serverCmdEnvGui_setVar(Clientgroup.getobject(0), FogColor, "255 255 255");
}

function fxDtsBrick::moveFace(%this, %client)
{
	$WhiteFace.setmoveobject(0);
	$WhiteFace.setmovedestination(%this.getPosition());
}

function player::FaceChase(%this, %client)
{
	$WhiteFace.setmovedestination(0);
	$WhiteFace.setmoveobject(%this);
}

function fxDtsBrick::changeFace(%this,%value,%client)
{
	switch(%value)
	{
		case 0: $WhiteFace.changeDatablock(whitefaceslow);
		case 1: $WhiteFace.changeDatablock(whitefacefast);
		case 2: $WhiteFace.changeDatablock(whitefacefastestspeed);
		case 3: $WhiteFace.changeDatablock(whitefaceslowestspeed);
	}
	$WhiteFace.hideNode("ALL");
}

function fxDtsBrick::faceAction(%this,%value,%client)
{
	switch(%value)
	{
		case 0: $whiteface.setMoveSlowdown(0);
		case 1: $Noescape=true;
		case 2: $WhiteFaceScreaming=true;
		case 3: $WhiteFaceScreaming=false;
		case 4: canvas.pushDialog(MainMenuGUI); schedule(3000, 0, serverplay2d, helaughs); schedule(5000, 0, backToTheGame);
		case 5: $Imscaredspawnpoint = 0; export("$imscared*", "config/client/scared.cs"); quit();
		case 6: quit();
	}
}

function fxDtsBrick::TransportFace(%this,%pos, %client)
{
	$WhiteFace.setTransform(%pos);
}

function player::transportTo(%this, %pos, %client)
{
	%this.setTransform(%pos);
}

function Gameconnection::FaceMessage(%this)
{
	%this.bottomPrint("<color:ffffff>" @ getFaceMessage(), 3, 1);
}



package whitefaces
{
	function whitefaceslow::Oncollision(%this, %obj, %col, %fade, %pos, %normal)
	{
		Parent::Oncollision(%this, %obj, %col, %fade, %pos, %normal);
		quit();
	}
	
	function whitefacefast::Oncollision(%this, %obj, %col, %fade, %pos, %normal)
	{
		Parent::Oncollision(%this, %obj, %col, %fade, %pos, %normal);
		quit();
	}

	function OptionsDlg::setShaderQuality(%this, %level)
	{
		if(%level == 0)
		{
			warn("I won't let you do that.");
			$shaderchangeattempts++;
			%level = 1;
			if($shaderchangeattempts == 3)
				serverplay2d(helaughs);
		}
		parent::setShaderQuality(%this, %level);
	}

	function paintProjectile::onCollision(%this, %obj, %col, %fade, %pos, %normal)
	{
		if((%col.getType() & $TypeMasks::PlayerObjectType))
		{
			if(%col.getdatablock().isface)
			{
				return;
			}
		}
		parent::onCollision(%this, %obj, %col, %fade, %pos, %normal);
	}
	
	function servercmdsuicide(%client)
	{
		return;
	}
	
	function gameConnection::SpawnPlayer(%this)
	{
		parent::SpawnPlayer(%this);
		%this.player.changeDatablock(theplayer);
		serverCmdEnvGui_setVar(Clientgroup.getobject(0), VisibleDistance, 1000);
		serverCmdEnvGui_setVar(Clientgroup.getobject(0), AmbientLightColor, "0.5 0.5 0.5 1");
		serverCmdEnvGui_setVar(Clientgroup.getobject(0), ShadowColor, "0.5 0.5 0.5 1");
		schedule(3000, 0, serverCmdEnvGui_setVar, Clientgroup.getobject(0), VisibleDistance, 10);
		%this.player.setWhiteout(2.0);
		switch($imscaredSpawnpoint)
		{
			case 0: %this.player.setTransform("-9 -21 25.5");
			case 1: %this.player.setTransform("-48 -197 0.5");
			case 2: %this.player.setTransform("55 38 0.5"); serverCmdEnvGui_setVar(Clientgroup.getobject(0), FogColor, "255 255 255");
		}
		
		if(!$Shader::Enabled)
			schedule(1000, %this.player, forceEnabledShaders);
	}
	
	function serverCmdLight(){return;}
	
	function escapeMenu::toggle(%this)
	{
		if($noescape)
			return;
		else
			quit();
	}
	
	function servercmdwarp(){}
	
	function servercmddropcameraatplayer(){}
	
	function servercmddropplayeratcamera(){}
	
	function servercmdspy(){}
	
	function openBSD(){}
};
activatepackage(whitefaces);

function backToTheGame()
{
	canvas.popDialog(mainMenuGUI);
	canvas.popDialog(mainMenuButtonsGUI);
	canvas.popDialog(joinServerGUI);
	canvas.popDialog(GameModeGUI);
	canvas.popDialog(optionsDlg);
	canvas.popDialog(avatarGUI);
}

function player::playereaten(%this)
{
	if($WhiteFaceDanger)
	{
		quit();
	}
}

function startFaceLoop()
{
	if(!isObject($WhiteFace))
	{
		$WhiteFace = new aiplayer(whiteface)
		{
			datablock = whitefaceslow;
			position = "200 200 0";
		};
	}
	
	if($WhiteFaceScreaming)
		serverPlay3D(hecomes, $WhiteFace.getPosition());

	schedule(600, 0, startFaceLoop);
}

function isObstruction(%pos,%player)
{
   %object = ContainerRayCast(%pos,%player.getEyePoint(), $TypeMasks::FxBrickObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::VehicleObjectType, %player);

   %obstr = getWord(%object,0);
   if(isObject(%obstr) && %obstr.getDatablock().getName() !$= "brick4x1x5windowData")
      return 1;
   else
      return 0;
}

function getFaceMessage()
{
	return "I love watching you"; //used to be a list of randoms, decided against it last minute.
}

schedule(1000, 0, forceEnabledShaders);

function forceEnabledShaders()
{
	optionsDlg.setShaderQuality(1);
}

if(!isObject($WhiteFace))
{
	$WhiteFace = new aiplayer(whiteface)
	{
		datablock = whitefaceslow;
		position = "200 200 0";
	};
	startFaceLoop();
}

// function devMode()
// {
	// deactivatePackage(whitefaces);
	// clientgroup.getObject(0).instantrespawn();
	// serverCmdEnvGui_setVar(Clientgroup.getobject(0), VisibleDistance, 1000);
	// $devMode=1;
// }

$WhiteFace.mountimage(whitefaceimage, 0);
$WhiteFace.hideNode("ALL");
$WhiteFace.setScale("0.8 0.8 0.8");
$WhiteFaceDanger=true;