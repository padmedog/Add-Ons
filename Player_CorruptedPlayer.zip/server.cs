datablock TSShapeConstructor(CorruptDts)
{
	baseShape = "./content/player/m.dts";
	sequence0 = "./content/player/m_root.dsq root";
	sequence1 = "./content/player/m_run.dsq run";
	sequence2 = "./content/player/m_run.dsq walk";
	sequence3 = "./content/player/m_back.dsq back";
	sequence4 = "./content/player/m_side.dsq side";
	sequence5 = "./content/player/m_crouch.dsq crouch";
	sequence6 = "./content/player/m_crouchRun.dsq crouchRun";
	sequence7 = "./content/player/m_crouchBack.dsq crouchBack";
	sequence8 = "./content/player/m_crouchSide.dsq crouchSide";
	sequence9 = "./content/player/m_look.dsq look";
	sequence10 = "./content/player/m_headSide.dsq headside";
	sequence11 = "./content/player/m_headup.dsq headUp";
	sequence12 = "./content/player/m_standjump.dsq jump";
	sequence13 = "./content/player/m_standjump.dsq standjump";
	sequence14 = "./content/player/m_fall.dsq fall";
	sequence15 = "./content/player/m_root.dsq land";
	sequence16 = "./content/player/m_armAttack.dsq armAttack";
	sequence17 = "./content/player/m_armReadyLeft.dsq armReadyLeft";
	sequence18 = "./content/player/m_armReadyRight.dsq armReadyRight";
	sequence19 = "./content/player/m_armReadyBoth.dsq armReadyBoth";
	sequence20 = "./content/player/m_spearReady.dsq spearready";
	sequence21 = "./content/player/m_spearThrow.dsq spearThrow";
	sequence22 = "./content/player/m_talk.dsq talk";
	sequence23 = "./content/player/m_death1.dsq death1";
	sequence24 = "./content/player/m_shiftUp.dsq shiftUp";
	sequence25 = "./content/player/m_shiftDown.dsq shiftDown";
	sequence26 = "./content/player/m_shiftAway.dsq shiftAway";
	sequence27 = "./content/player/m_shiftTo.dsq shiftTo";
	sequence28 = "./content/player/m_shiftLeft.dsq shiftLeft";
	sequence29 = "./content/player/m_shiftRight.dsq shiftRight";
	sequence30 = "./content/player/m_rotCW.dsq rotCW";
	sequence31 = "./content/player/m_rotCCW.dsq rotCCW";
	sequence32 = "./content/player/m_undo.dsq undo";
	sequence33 = "./content/player/m_plant.dsq plant";
	sequence34 = "./content/player/m_sit.dsq sit";
	sequence35 = "./content/player/m_wrench.dsq wrench";
	sequence36 = "./content/player/m_activate.dsq activate";
	sequence37 = "./content/player/m_activate2.dsq activate2";
	sequence38 = "./content/player/m_leftrecoil.dsq leftrecoil";
};

datablock AudioProfile(CorruptDeathSound)
{
	fileName = "./content/sound/death.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(CorruptJumpSound)
{
    fileName = "./content/sound/jump.wav";
    description = AudioClose3d;
    preload = true;
};
datablock AudioProfile(CorruptPainSound)
{
    fileName = "./content/sound/pain.wav";
    description = AudioClose3d;
    preload = true;
};
datablock PlayerData(corruptPlayer : PlayerStandardArmor)
{
	shapeFile = "./content/player/m.dts";
	zDeathSound = "CorruptDeathSound";
	useCustomPainEffects = true;
	jumpsound = "CorruptJumpSound";
	PainSound = CorruptPainSound;
	DeathSound = CorruptDeathSound;
	JumpSound = CorruptJumpSound;
	uiName = "Corrupted Player";
};
function servercmdheed(%c,%t){%c.player.setArmThread(%t);}
function servercmdthread(%c,%t,%s){%c.player.playThread(%s,%t);}
