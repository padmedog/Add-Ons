//Original (and main) Credits to Siba


package BRPG_BattleMembers_Package {

	function BRPG_BattleMembers_ResetSize() {
		if(!isObject(BRPG_BattleMembers_Body))
			return;

		%posX = getWord(getRes(), 0)/2 - 29.5 * BRPG_BattleMembers_Body.count;
		%width = 59 * BRPG_BattleMembers_Body.count;
		BRPG_BattleMembers_Body.resize(%posX, 4, %width, 84);
	}

	function clientCmdBRPG_BattleMembers_AddPlayer(%name, %faceID, %faceColor, %health, %borderColor) {
		if(%faceID $= "" || %faceID $= "0")
			%faceID = "base/data/shapes/player/faces/smiley";

		if(!isObject(BRPG_BattleMembers_Body)) {
			new GuiSwatchCtrl(BRPG_BattleMembers_Body) {
				profile = "GuiDefaultProfile";
				horizSizing = "center";
				vertSizing = "bottom";
				position = "290 4";
				extent = "59 84";
				minExtent = "8 2";
				enabled = "1";
				visible = "1";
				clipToParent = "1";
				color = "20 20 20 120";

				count = 0;
			};

			PlayGui.add(BRPG_BattleMembers_Body);
		}

		%slotNum = BRPG_BattleMembers_Body.getCount();

		%pos = 2+(59 * %slotNum) SPC 2;
		%slot = new GuiSwatchCtrl("BRPG_BattleMembers_Slot_" @ %slotNum) {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = %pos;
			extent = "55 80";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			color = "20 20 20 120";

			new GuiSwatchCtrl("BRPG_BattleMembers_FaceBorder_" @ %slotNum) {
				profile = "GuiDefaultProfile";
				horizSizing = "right";
				vertSizing = "bottom";
				position = "0 0";
				extent = "55 63";
				minExtent = "8 2";
				enabled = "1";
				visible = "1";
				clipToParent = "1";
				color = %BorderColor;

				new GuiSwatchCtrl("BRPG_BattleMembers_FaceColor_" @ %slotNum) {
					profile = "GuiDefaultProfile";
					horizSizing = "center";
					vertSizing = "bottom";
					position = "1 1";
					extent = "53 53";
					minExtent = "8 2";
					enabled = "1";
					visible = "1";
					clipToParent = "1";
					color = %faceColor SPC "255";

					new GuiBitmapCtrl("BRPG_BattleMembers_FaceImg_" @ %slotNum) {
						profile = "GuiDefaultProfile";
						horizSizing = "right";
						vertSizing = "bottom";
						position = "0 0";
						extent = "53 53";
						minExtent = "8 2";
						enabled = "1";
						visible = "1";
						clipToParent = "1";
						bitmap = %faceID;
						wrap = "0";
						lockAspectRatio = "0";
						alignLeft = "0";
						alignTop = "0";
						overflowImage = "0";
						keepCached = "0";
						mColor = "255 255 255 255";
						mMultiply = "0";
					};
				};

				new GuiSwatchCtrl() {
					profile = "GuiDefaultProfile";
					horizSizing = "center";
					vertSizing = "bottom";
					position = "1 55";
					extent = "53 7";
					minExtent = "8 2";
					enabled = "1";
					visible = "1";
					clipToParent = "1";
					color = "255 0 0 255";

					new GuiSwatchCtrl("BRPG_BattleMembers_FaceHealth_" @ %slotNum) {
						profile = "GuiDefaultProfile";
						horizSizing = "right";
						vertSizing = "bottom";
						position = "0 0";
						extent = mFloatLength(%health / 100 * 53, 0) SPC 7;
						minExtent = "8 2";
						enabled = "1";
						visible = "1";
						clipToParent = "1";
						color = "0 255 0 255";
					};
				};
			};

			new GuiMLTextCtrl("BRPG_BattleMembers_FaceName_" @ %slotNum) {
				profile = "GuiMLTextProfile";
				horizSizing = "center";
				vertSizing = "bottom";
				position = "0 62";
				extent = "55 18";
				minExtent = "8 2";
				enabled = "1";
				visible = "1";
				clipToParent = "1";
				lineSpacing = "2";
				allowColorChars = "0";
				maxChars = "-1";
				text = "<just:center><font:impact:18><color:FFFFFF>" @ %name;
				maxBitmapHeight = "-1";
				selectable = "1";
				autoResize = "1";
			};
		};
		BRPG_BattleMembers_Body.add(%slot);

		if(%slotNum > getWord(getRes(), 0) / 59 - 10)
			%slot.setVisible(0);
		else
			BRPG_BattleMembers_Body.count++;


		BRPG_BattleMembers_ResetSize();
	}

	function clientCmdBRPG_BattleMembers_SwapSlots(%s1, %s2) {
		if(isObject("BRPG_BattleMembers_Slot_" @ %s1) && isObject("BRPG_BattleMembers_Slot_" @ %s2)) {
			%borderColor1 = ("BRPG_BattleMembers_FaceBorder_" @ %s1).color;
			%faceColor1 = ("BRPG_BattleMembers_FaceColor_" @ %s1).color;
			%faceID1 = ("BRPG_BattleMembers_FaceImg_" @ %s1).bitmap;
			%name1 = stripMLControlChars(("BRPG_BattleMembers_FaceName_" @ %s1).getText());
			%health1 = ("BRPG_BattleMembers_FaceHealth_" @ %s1).extent / 53 * 100;

			%borderColor2 = ("BRPG_BattleMembers_FaceBorder_" @ %s2).color;
			%faceColor2 = ("BRPG_BattleMembers_FaceColor_" @ %s2).color;
			%faceID2 = ("BRPG_BattleMembers_FaceImg_" @ %s2).bitmap;
			%name2 = stripMLControlChars(("BRPG_BattleMembers_FaceName_" @ %s2).getText());
			%health2 = ("BRPG_BattleMembers_FaceHealth_" @ %s2).extent / 53 * 100;

			if(%s1 > getWord(getRes(), 0) / 59 - 10)
				("BRPG_BattleMembers_Slot_" @ %s1).setVisible(0);
			if(%s2 > getWord(getRes(), 0) / 59 - 10)
				("BRPG_BattleMembers_Slot_" @ %s2).setVisible(0);

			clientCmdBRPG_BattleMembers_SetSlot(%s1, %name2, %faceID2, %faceColor2, %health2, %borderColor2);
			clientCmdBRPG_BattleMembers_SetSlot(%s2, %name1, %faceID1, %faceColor1, %health1, %borderColor1);
		}
	}

	function clientCmdBRPG_BattleMembers_ShiftLeft() {
		if(isObject("BRPG_BattleMembers_Slot_0")) {
			%name = stripMLControlChars(("BRPG_BattleMembers_FaceName_0").getText());
			%faceID = ("BRPG_BattleMembers_FaceImg_0").bitmap;
			%faceColor = ("BRPG_BattleMembers_FaceColor_0").color;
			%health = ("BRPG_BattleMembers_FaceHealth_0").extent / 53 * 100;
			%borderColor = ("BRPG_BattleMembers_FaceBorder_0").color;

			clientCmdBRPG_BattleMembers_RemoveSlot(0);
			clientCmdBRPG_BattleMembers_AddPlayer(%name, %faceID, %faceColor, %health, %borderColor);
		}
	}

	function clientCmdBRPG_BattleMembers_SetSlot(%num, %name, %faceID, %faceColor, %health, %borderColor) {
		if(isObject("BRPG_BattleMembers_Slot_" @ %num)) {
			if(%borderColor !$= "")
				("BRPG_BattleMembers_FaceBorder_" @ %num).setColor(%borderColor SPC 255);

			if(%faceColor !$= "")
				("BRPG_BattleMembers_FaceColor_" @ %num).setColor(%faceColor SPC 255);

			if(%faceID !$= "")
				("BRPG_BattleMembers_FaceImg_" @ %num).setBitmap(%faceID);

			if(%name !$= "")
				("BRPG_BattleMembers_FaceName_" @ %num).setText("<just:center><font:impact:18><color:FFFFFF>" @ %name);

			if(%health !$= "")
				("BRPG_BattleMembers_FaceHealth_" @ %num).extent = mFloatLength(%health / 100 * 53, 0) SPC 7;
		}
	}

	function clientCmdBRPG_BattleMembers_RemoveSlot(%num) {
		if(isObject("BRPG_BattleMembers_Slot_" @ %num)) {
			("BRPG_BattleMembers_Slot_" @ %num).delete();

			for(%i=%num+1; %i < BRPG_BattleMembers_Body.getCount()+1; %i++) {
				if(!isObject("BRPG_BattleMembers_Slot_" @ %i))
					continue;

				%pos = getWord(("BRPG_BattleMembers_Slot_" @ %i).position, 0)-59 SPC 2;
				("BRPG_BattleMembers_Slot_" @ %i).position = %pos;

				("BRPG_BattleMembers_Slot_" @ %i).setName("BRPG_BattleMembers_Slot_" @ %i-1);
				("BRPG_BattleMembers_FaceBorder_" @ %i).setName("BRPG_BattleMembers_FaceBorder_" @ %i-1);
				("BRPG_BattleMembers_FaceColor_" @ %i).setName("BRPG_BattleMembers_FaceColor_" @ %i-1);
				("BRPG_BattleMembers_FaceImg_" @ %i).setName("BRPG_BattleMembers_FaceImg_" @ %i-1);
				("BRPG_BattleMembers_FaceName_" @ %i).setName("BRPG_BattleMembers_FaceName_" @ %i-1);
				("BRPG_BattleMembers_FaceHealth_" @ %i).setName("BRPG_BattleMembers_FaceHealth_" @ %i-1);
			}

			BRPG_BattleMembers_Body.count = BRPG_BattleMembers_Body.getCount();
			for(%i=0; %i < BRPG_BattleMembers_Body.getCount(); %i++) {
				if(%i > getWord(getRes(), 0) / 59 - 10) {
					BRPG_BattleMembers_Body.count--;
					("BRPG_BattleMembers_Slot_" @ %i).setVisible(0);
				} else
					("BRPG_BattleMembers_Slot_" @ %i).setVisible(1);
			}
		}

		BRPG_BattleMembers_ResetSize();

		if(%num $= "ALL" && isObject(BRPG_BattleMembers_Body))
			BRPG_BattleMembers_Body.delete();
	}

};
