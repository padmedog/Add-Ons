//------------------------------
// Title: ClearTempBrick
// Author: Swollow
// Version 1.0.0.0
// Clear a players temp brick
// after a period of time
//------------------------------
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::Hooks::ServerControl)
	Exec("Add-Ons/System_ReturnToBlockland/Hooks/serverControl.cs");
	RTB_registerPref("Enabled", "Clear Temp Brick", "$Swollow::ClearTempBrickEnabled", "bool", "Server_ClearTempBrick", 1, 0, 0, 0);
	RTB_registerPref("Delay", "Clear Temp Brick", "$Swollow::ClearTempBrickTime", "int 6000 80000", "Server_ClearTempBrick", 10000, 0, 0);
}
else
{
	$Swollow::ClearTempBrickTime = 10000;
	$Swollow::ClearTempBrickEnabled = 1;
	
	if(isFile("Add-ons/Server_ClearTempBrick/ServerCmd.cs"))
	{
		Exec("Add-ons/Server_ClearTempBrick/ServerCmd.cs");
	}
	else
	{
		Warn("Missing File: ServerCmd.cs");
	}
}

package ClearTempBrick
{
	function BrickDeployProjectile::OnCollision(%This,%Obj,%Col,%Fade,%Pos,%Normal)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::OnCollision(%This,%Obj,%Col,%Fade,%Pos,%Normal);
		}

		%Client = %Obj.Client;
		
		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}

		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::OnCollision(%This,%Obj,%Col,%Fade,%Pos,%Normal);
	}
	function ServerCmdShiftBrick(%Client,%a,%b,%c)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::ServerCmdShiftBrick(%Client,%a,%b,%c);
		}

		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}
		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::ServerCmdShiftBrick(%Client,%a,%b,%c);
	}
	function ServerCmdRotateBrick(%Client,%a)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::ServerCmdRotateBrick(%Client,%a);
		}

		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}
		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::ServerCmdRotateBrick(%Client,%a);
	}
	function ServerCmdUseInventory(%Client,%a)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::ServerCmdUseInventory(%Client,%a);
		}

		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}
		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::ServerCmdUseInventory(%Client,%a);
	}
	function ServerCmdPlantBrick(%Client)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::ServerCmdPlantBrick(%Client);
		}

		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}
		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::ServerCmdPlantBrick(%Client);
	}
	function ServerCmdUseFXCan(%Client,%a)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::ServerCmdUseFXCan(%Client,%a);
		}

		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}
		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::ServerCmdUseFXCan(%Client,%a);
	}
	function ServerCmdUseSprayCan(%Client,%a)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return	parent::ServerCmdUseSprayCan(%Client,%a);
		}

		if(isEventPending(%Client.ClearTempBrickSched))
		{	
			cancel(%Client.ClearTempBrickSched);
		}
		%Client.ClearTempBrickSched = schedule($Swollow::ClearTempBrickTime,0,SwolClearTempBrick,%Client);
		parent::ServerCmdUseSprayCan(%Client,%a);
	}
	function SwolClearTempBrick(%Client)
	{
		if(!$Swollow::ClearTempBrickEnabled)
		{
			return;
		}

		ServerCmdCancelBrick(%Client);
	}
};
ActivatePackage(ClearTempBrick);