exec("./Support_SpecialKills.cs");

addSpecialDamageMsg("Assisted","%2 + %4%3%1","%4 finished off %5%1");

package AssistKills
{
	function Armor::damage(%data, %obj, %sourceObject, %pos, %directDamage, %damageType)
	{
		if(isObject(%sourceObject.client) && %sourceObject.client != %obj.client)
		{
			//source object could be a projectile so i get the owner's player 
			if(isObject(%sourceObject.client.player.lastTF2Healer.client) && %sourceObject.client.player.beingHealed)
			{
				%obj.lastAssistAttacker = %sourceObject.client.player.lastTF2Healer.client;
				%obj.lastAttacker = %sourceObject.client;
			}
			else if(!isObject(%obj.lastAssistAttacker))
			{
				%obj.lastAssistAttacker = %sourceObject.client;
				%obj.lastAttacker = %sourceObject.client;
			}
			else if(%obj.lastAttacker != %sourceObject.client)
			{
				%obj.lastAssistAttacker = %obj.lastAttacker;
				%obj.lastAttacker = %sourceObject.client;
			}
			%obj.lastAssistDamageType = %damageType;
			%obj.lastAssistDamageTime = getSimTime();
		}
		return Parent::damage(%data, %obj, %sourceObject, %pos, %directDamage, %damageType);
	}
};activatepackage(assistkills);

function isSpecialKill_Assisted(%this,%sourceObject,%sourceClient,%mini)
{
	%obj = %this.player;
	if(isObject(%obj.lastAssistAttacker) && %obj.lastAssistAttacker != %sourceClient && (getSimTime() - %obj.lastAssistDamageTime) < 10000)
	{
		%obj.lastAssistAttacker.incScore(%mini.Points_KillPlayer);
		
		if(%obj.lastAssistAttacker.isSpaceBotAI)
			%name = %obj.lastAssistAttacker.getBotName();
		else
			%name = %obj.lastAssistAttacker.getPlayerName();
		
		if(%name $= "")
			return 0;
		
		if(!isObject(%sourceObject.client) || %sourceObject.client == %this)
		{
			%msg = getTaggedString($DeathMessage_Murder[%obj.lastAssistDamageType]);
			%msg = strReplace(%msg,"%2 ","");
			%msg = strReplace(%msg,"%2 ","");
			
			%pos1 = strPos(%msg,"%1");
			%ciString = getSubStr(%msg,0,%pos1);
			
			return 2 TAB %name TAB %cistring;
		}
		
		if(%obj.lastAssistAttacker != %obj.lastAttacker)
			return 2 TAB %name;
	}
	return 0;
}