package Dmusicserver
{
	function GameConnection::autoAdminCheck(%this)
	{
		%r = Parent::autoAdminCheck(%this);
		commandToClient(%this,'2dMusicCheck');
		%this.dmusicschedule = %this.schedule(10000,dMusicCheck);
		return %r;
	}
};

function serverCmd2dMusicCheck(%client)
{
	cancel(%client.dmusicSchedule);
	%client.dmusicSchedule = "";
	%client.has2dmusic = 1;
}

function GameConnection::dMusicCheck(%this)
{
	%client.dmusicSchedule = "";
	%client.has2dmusic = 0;
}

function GameConnection::dMusicPlay(%this,%df)
{
	//This will allow it to be used through events or script.
	//For scripts, you can just use the filename for %df, rather than the datablock.
	if(getSubStr(%df.getName(),0,9) $= "musicData")
		%fileName = strReplace(%df.uiName," ","_");
	else
		%fileName = %df;
	commandToClient(%this,'playMusic',%filename);
	if(!%this.dnotice && !%this.has2dMusic)
	{
		messageClient(%this,'',"The server tried to play a song to you, but you do not have the <a:forum.returntoblockland.com/dlm/viewFile.php?id=3024>System_2DMusic</a> add-on.");
		%this.dnotice = 1;
	}
}

function GameConnection::dMusicStop(%this)
{
	commandToClient(%this,'stopMusic');
}

activatepackage(Dmusicserver);
registerOutputEvent(GameConnection,"dMusicPlay","datablock Music");
registerOutputEvent(GameConnection,"dMusicStop");