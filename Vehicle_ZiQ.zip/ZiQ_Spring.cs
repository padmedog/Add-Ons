datablock WheeledVehicleSpring(ZiQSpring)
{
   // Wheel suspension properties
   length = 0.3;			 // Suspension travel
   force = 3000; //3000;		 // Spring force
   damping = 400; //600;		 // Spring damping
   antiSwayForce = 3; //3;		 // Lateral anti-sway force
};


