datablock ExplosionData(A10MissileExplosion : vehicleFinalExplosion)
{
	debris = "";
	damageRadius = 20;
	radiusDamage = 1000;
};
AddDamageType("A10MissileExp",   '<color:FFFF00>[A-10 Hellfire Missile]<color:FF0000> %1',    '%2 <color:FFFF00>[A-10 Hellfire Missile]<color:FF0000> %1',0.2,1);
datablock ProjectileData(A10MissileExplosionProjectile : vehicleFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 20;
   damageRadius        = 500;
   explosion           = A10MissileExplosion;

   directDamageType  = $DamageType::A10MissileExp;
   radiusDamageType  = $DamageType::A10MissileExp;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 0;


};

datablock ShapeBaseImageData(A10MissileABImage)
{
   shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 1;
   rotation = "1 0 0 180";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= A10MissileABEmitter;
	stateEmitterTime[1]				= 10000;

	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function A10MissileABImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
datablock WheeledVehicleData(A10MissileVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./shapes/TVMissile.dts"; //"~/data/shapes/skivehicle.dts"; //
	emap = true;
	minMountDist = 3;
   
    numMountPoints = 1;
    mountThread[0] = "sit";

	maxDamage = 1.00;
	destroyedLevel =  2.00;
	extradamagethreshold = 2;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0";

	maxSteeringAngle = 0.9;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = true;         // Roll the camera with the vehicle
	cameraMaxDist = 10;         // Far distance from vehicle
	cameraOffset = 0.5;        // Vertical offset from camera mount point
	cameraLag = 0.5;           // Velocity lag of camera
	cameraDecay = 0.5;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.0;
   collisionTol = 1.0;        // Collision distance tolerance
   contactTol = 1.0;

	useEyePoint = false;	

	defaultTire	  = "";
	defaultSpring = "";
	//flatTire	     = jeepFlatTire;
	//flatSpring	  = jeepFlatSpring;

   numWheels = 3;

	// Rigid Body
	mass = 200;
	density = 5.0;
	drag = 0.0;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 1;       // Play SoftImpact Sound
	hardImpactSpeed = 1;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 0; //4000;       // Engine power
	engineBrake = 50;         // Braking when throttle is 050
	brakeTorque = 4000;        // When brakes are applied
	maxWheelSpeed = 60;        // Engine scale by current speed / max speed




	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

   isSled = false;

   forwardThrust		= 10000;
	reverseThrust		= 2000;
	lift			= 1;
	maxForwardVel		= 600;
	maxReverseVel		= 0;//2
	horizontalSurfaceForce	= 200;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 200; 

	rollForce		= 2200;
	yawForce		= 2600;
	pitchForce		=2200;
	rotationalDrag		= 3;
	stallSpeed		= 0;


	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "";
	rideable = true;
		lookUpLimit = 0.5;
		lookDownLimit = 0.5;

	paintable = true;
  

   numDmgEmitterAreas = 1;



   initialExplosionProjectile = jeepExplosionProjectile;
   initialExplosionOffset = 0;         //offset only uses a z value for now

   burnTime = 10;

   finalExplosionProjectile = A10MissileExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now


   minRunOverSpeed    = 2;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 50;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 0; //how hard a person you're running over gets pushed

   steeringUseStrafeSteering = false; //this vehicle has pitch control, so we can't use strafe steering
   
	minContrailSpeed = 50;
	mincollisionSpeed = 20;
};
function A10Missilevehicle::onAdd(%this,%obj)
{
	%obj.playThread(0,"activate");
	%obj.schedule(9000,"finalexplosion");
	%obj.mountImage(A10MissileABImage,1);
	%obj.creationtime=getSimTime();
}
function A10MissileVehicle::onImpact(%this,%obj,%col)
{
	if(getSimTime() < %obj.creationtime+1000)
	return;

		if(%obj.destroyed)
            return;
			
		%obj.setDamageLevel(0);
		%obj.destroyed = 1;

		%trans = %obj.getTransform();
		%p = new Projectile()
		{
			dataBlock = A10MissileExplosionProjectile;
			initialVelocity  = "0 0 0";
			initialPosition  = %trans;
			client = %obj.owner.client;
            sourceClient = %obj.owner.client;
		};
		MissionCleanup.add(%p);
	
		%obj.schedule(10,"delete");
}