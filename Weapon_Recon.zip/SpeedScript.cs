package BKTBF3ProjSpeedPackage
{
	function Projectile::onAdd(%obj,%a,%b)
	{
		if(%obj.dataBlock.getID() == MK11Projectile.getID())
		{
			%obj.initialvelocity = vectorscale(vectorNormalize(%obj.initialvelocity),1000);
		}
		else
		{
			return;
		}
		Parent::onAdd(%obj,%a,%b);
	}
};
activatePackage(BKTBF3ProjSpeedPackage);