exec("./supports.cs"); // Some supports.

if(requireAddOn("weapon_rocket_launcher") == false || requireAddOn("sound_beeps") == false)
	return false;

datablock decalData(boomBeltIcon) // Icon Stuff
{
	textureName = "./boomBeltIcon";
};

datablock decalData(boomBeltCI) // CI Stuff
{
	textureName = "./boomBeltCI";
};

addDamageType("boomBelt",
	'<bitmap:add-ons/weapon_boomBelt/boomBeltCI> %1',
	'%2 <bitmap:add-ons/weapon_boomBelt/boomBeltCI> %1',
	0.05, 1
);

datablock explosionData(boomBeltExplosion : rocketExplosion)
{
	damageRadius = 10;
	radiusDamage = 500;
};

datablock projectileData(boomBeltProjectile : rocketLauncherProjectile) // Explosion Stuff
{
	projectileShapeName = "";
	uiName              = "";
	directDamageType    = $damageType::boomBelt;
	radiusDamageType    = $damageType::boomBelt;
	
	lifetime       = 0;
	explodeOnDeath = true;
	directDamage   = 100;
	
	explosion = boomBeltExplosion;
};

datablock itemData(boomBeltItem) // Item Stuff
{
	category     = "item";
	shapeFile    = "./boomBelt.dts";
	mass         = 1;
	density      = 0.2;
	elasticity   = 0.2;
	friction     = 0.6;
	emap         = true;
	doColorShift = false;
	canDrop      = true;
	image        = detonatorImage;
	equipment    = true;
	
	uiName   = "Boom Belt";
	iconName = "./boomBeltIcon";
};

datablock shapeBaseImageData(detonatorImage) // Detonator Image Stuff
{
	className    = "weaponImage";
	doColorShift = false;
	shapeFile    = "./detonator.dts";
	emap         = true;
	mountPoint   = 0;
	item         = boomBeltItem;
	offset       = "0 -0.01 0.1";
	
	correctMuzzleVector = false;
	melee               = true;
	armReady            = true;
	
	
	// State Stuff
	
	stateName[0]                = "activate";
	stateTimeoutValue[0]        = 0.5;
	stateTransitionOnTimeout[0] = "ready";
	stateAllowImageChange[1]    = false;
	
	stateName[1]                    = "ready";
	stateTransitionOnTriggerDown[1] = "fire";
	stateAllowImageChange[1]        = true;
	
	stateName[2]                = "fire";
	stateScript[2]              = "onFire";
	stateSequence[2]            = "pushButton";
	stateTimeoutValue[2]        = 0;
	stateTransitionOnTimeout[2] = "explodeWait";
	stateAllowImageChange[2]    = false;
	
	stateName[3]                = "explodeWait";
	stateTimeoutValue[3]        = 2;
	stateTransitionOnTimeout[3] = "explodeDone";
	stateAllowImageChange[3]    = false;
	
	stateName[4]             = "explodeDone";
	stateAllowImageChange[4] = true;
};

datablock shapeBaseImageData(boomBeltImage) // Belt Image Stuff
{
	shapeFile  = "./boomBelt.dts";
	emap       = true;
	mountPoint = 7;
	
	offset    = "0 0 0.5";
	eyeOffset = "-10 0 0";
};


// Script Stuff

function detonatorImage::onMount(%this, %obj, %slot)
{
	parent::onMount(%this, %obj, %slot);
	
	return %obj.mountImage(boomBeltImage, 2);
}

function detonatorImage::onUnmount(%this, %obj, %slot)
{
	return %obj.unmountImage(2);
}

function detonatorImage::onFire(%this, %obj, %slot)
{
	%obj.exploding = %obj.schedule(2000, "beltExplode");
	
	return serverPlay3D(beep_key_sound, getWords(%obj.getTransform(), 0, 2));
}


// Player Stuff

package boomBelt
{
	function serverCmdunUseTool(%client)
	{
		if(isObject(%client.player) == true && isEventPending(%client.player.exploding) == true)
			return false;
		else
			return parent::serverCmdunUseTool(%client);
	}
	
	function serverCmddropTool(%client, %toolSlot)
	{
		if(isObject(%client.player) == true && isEventPending(%client.player.exploding) == true)
			return false;
		else
			return parent::serverCmddropTool(%client, %toolSlot);
	}
};

activatePackage(boomBelt);

function player::beltExplode(%this)
{
	if(isObject(%this) == false)
		return false;
	
	%scaleFactor = getWord(%this.getScale(), 2);
	
	%p = new projectile()
	{
		datablock = boomBeltProjectile;
		initialPosition = getWords(%this.getTransform(), 0, 2);
		sourceObject = %this;
		client = %this.client;
		sourceSlot = 0;
		originPoint = getWords(%this.getTransform(), 0, 2);
	};
	
	missionCleanup.add(%p);
	%p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
	
	return %p;
}