//           ___                     ___     
//  	    /  /\        ___        /  /\    
//         /  /  \      /  /\      /  / /_   
//	  /  / /\ \    /  / /     /  / / /\  
//	 /  / /-/ /   /  / /   __/  / /_/  \ 
//	/__/ / / /   /  /  \  / /__/ /__\/\ \
//     _\  \ \/ /   /__/ /\ \/  \  \ \ /__/ /
//  __/	 \  \  /\   \__\/  \ \   \  \ \  / / 
// /	  \  \ \ \__  /  \  \ \   \  \ \/ /\  
///	   \  \ \   \/    \__\/    \  \  /  \_
//	    \__\/    \	            \__\/     \
//	Made by: [GSF]Ghost (ID: 3195)

////////////////////////////////////////////////////////////////////////////////

exec("Add-Ons/System_PTG/Scripts/Defaults.cs");
exec("Add-Ons/System_PTG/Scripts/ChunkPass_DetectChunk.cs");
exec("Add-Ons/System_PTG/Scripts/GetHeightValues.cs");
exec("Add-Ons/System_PTG/Scripts/Slopes_SmoothingCo.cs");
exec("Add-Ons/System_PTG/Scripts/CreateChunk.cs");
exec("Add-Ons/System_PTG/Scripts/CreateChunk_ModTer.cs");

////////////////////////////////////////////////////////////////////////////////

//If ModTer is enabled, boundaries and water bricks revert to print bricks:
datablock fxDTSBrickData(brick16Cube1PTGMTData)
{
	brickFile = "Add-Ons/System_PTG/Bricks_Prints/16c.blb";
	category = "";
	subCategory = "";
	uiName = "16x PTG MT ";
	iconName = "base/client/ui/brickicons/Unknown";
	collisionShapeName = "Add-Ons/System_PTG/Bricks_Prints/16cCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = false;
};
datablock fxDTSBrickData (brick32wPTGMTData)
{
	brickFile = "Add-Ons/System_PTG/Bricks_Prints/32w.blb";
	category = "";
	subCategory = "";
	uiName = "32w PTG MT ";
	iconName = "base/client/ui/brickicons/Unknown";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	alwaysShowWireFrame = true;
	isWaterBrick = true;
};
function brick32wPTGMTData::onPlant(%data, %brick)
{
   brick8xWaterData::onPlant(%data, %brick);
}
function brick32wPTGMTData::onLoadPlant(%data, %obj)
{
   brick32wPTGMTData::onPlant(%data, %obj); 
}
function brick32wPTGMTData::onTrustCheckFinished(%data, %brick)
{
   %brick.createWaterZone();  
}
function brick32wPTGMTData::onDeath(%data, %brick)
{
   brick8xWaterData::onDeath(%data, %brick);
}
function brick32wPTGMTData::onRemove(%data, %brick)
{
   brick8xWaterData::onRemove(%data, %brick);
}
function brick32wPTGMTData::onColorChange(%data, %brick)
{
   brick8xWaterData::onColorChange(%data, %brick);
}
function brick32wPTGMTData::onFakeDeath(%data, %brick)
{
   brick8xWaterData::onFakeDeath(%data, %brick);
}
function brick32wPTGMTData::onClearFakeDeath(%data, %brick)
{
   brick8xWaterData::onClearFakeDeath(%data, %brick);
}
function brick32wPTGMTData::disappear(%data, %brick, %time)
{
   brick8xWaterData::disappear(%data, %brick, %time);
}
function brick32wPTGMTData::reappear(%data, %brick)
{
   brick8xWaterData::reappear(%data, %brick);
}

////////////////////////////////////////////////////////////////////////////////

function serverCmdPTG_GUI_RestrictionCheck(%client)
{
	if($Server::Lan)
	{
		if(%client.bl_id==999999)
			return;
	}
	if(!$Server::Lan)
	{
		if(%client.bl_id==getNumKeyID())
			return;
	}
	if(($Server::Lan && %client.bl_id!=999999) || (!$Server::Lan && %client.bl_id!=getNumKeyID()))
	{
		commandtoclient(%client,'messageboxOK',"PTG: ACCESS DENIED","Only the Server Host can access the PTG GUI.");
		commandtoclient(%client,'Cl_RestrictionFail');
	}
}

////////////////////////////////////////////////////////////////////////////////

//End Routine
function serverCmdEndPTG(%client)
{
	if($Server::Lan)
	{
		if(%client.bl_id!=999999)
		{
			commandtoclient(%client,'messageboxOK',"PTG: ACCESS DENIED","You are not allowed to end the Routine.");
			return;
		}
	}
	if(!$Server::Lan)
	{
		if(%client.bl_id!=getNumKeyID())
		{
			commandtoclient(%client,'messageboxOK',"PTG: ACCESS DENIED","You are not allowed to end the Routine.");
			return;
		}
	}
	if($Start==0 && $PrevPass==0)
	{
		commandtoclient(%client,'messageboxOK',"PTG: ERROR","Routine not started!");
		return;
	}
	if($PrevPass==0)
		messageAll('',"PTG: Routine Complete ");

	$EChDP = 1;
	$switch = 1;
	$MTPass = 0;
	$Start = 0;
	$PrevPass = 0;
	$DetPass = 0;
}

////////////////////////////////////////////////////////////////////////////////

//Clear Terrain
function serverCmdClearPTG(%client)
{
	if($Server::Lan && %client.bl_id!=999999)
	{
		commandtoclient(%client,'messageboxOK',"PTG: ACCESS DENIED","You are not allowed to clear terrain.");
		return;
	}
	if(!$Server::Lan && %client.bl_id!=getNumKeyID())
	{
		commandtoclient(%client,'messageboxOK',"PTG: ACCESS DENIED","You are not allowed to clear terrain.");
		return;
	}
	messageAll('',"PTG: " @ %client.Name @ " cleared the terrain."); //When Super Admin support is added, msg will refer to client's bricks, not entire terrain
	%clBLID = %client.bl_id;
	%SG = "BrickGroup_" @ %clBLID;

	for(%a=%SG.getCount()-1;%a>=0;%a--)
      	{
            	 %brick = %SG.getObject(%a);

              	if(%brick.ptg==1)
			%brick.delete();
	}
}

////////////////////////////////////////////////////////////////////////////////

//Initial Start Relay
function ServerCmdPTG_GUI_IntStartRoutine(%client)
{
	PTG_GUI_IntStartRoutine_Relay(%client);
}

////////////////////////////////////////////////////////////////////////////////

function serverCmdPausePTG(%client)
{
	if($Start==0)
	{
		commandtoclient(%client,'messageboxOK',"PTG: ERROR","Routine not started!");
		return;
	}
	if($PrevPass!=1)
	{
		if($switch==0)
		{
			$EChDP=0;
			$switch=1;
			messageAll('',"PTG: Routine Resuming >>");
			GetHeightValues();
			return;
		}
		if($switch==1)
		{
			$EChDP=1;
			$switch=0;
			messageAll('',"PTG: Routine Paused ||");
		}
	}
	if($PrevPass==1)
	{
		commandtoclient(%client,'messageboxOK',"PTG: ERROR","You can't pause a preview routine.");
		return;
	}
}