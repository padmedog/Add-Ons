//gun.cs

datablock AudioProfile(shotgunMissileFireSound)
{
   filename    = "./shotgun_missiles.wav";
   description = AudioClose3d;
   preload = true;
};
datablock ExplosionData(quakeMisShotgunExplosion : quakeRocketExplosion)
{
   //explosionShape = "";

   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";
   damageRadius = 5;
   radiusDamage = 40;

   impulseRadius = 6;
   impulseForce = 400;
};

AddDamageType("quakeMisShotgun",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_drunkenrockets> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_drunkenrockets> %1',0.2,1);
datablock ProjectileData(quakeMisShotgunProjectile : gunProjectile)
{
   projectileShapeName = "./rocket_1.dts";

   directDamage        = 70;
   directDamageType    = $DamageType::quakeMisShotgun;
   radiusDamageType    = $DamageType::quakeMisShotgun;

   impactImpulse	     = 500;
   verticalImpulse	  = 1000;
   explosion           = quakeMisShotgunExplosion;
   particleEmitter     = quakeMisStormTrailEmitter; //bulletTrailEmitter;

   muzzleVelocity      = 80;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.9;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0.5;
   explodeOnPlayerImpact = true;
   explodeondeath = true;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   uiName = "";
};

//////////
// item //
//////////
datablock ItemData(quakeMisShotgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./drunken_missiles.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Drunken Rockets";
	iconName = "./drunkenrockets";
	doColorShift = true;
	colorShiftColor = "0.45 0.48 0.48 1.000";

	 // Dynamic properties defined by the scripts
	image = quakeMisShotgunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(quakeMisShotgunImage)
{
   // Basic Item properties
	shapeFile = "./drunken_missiles.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = quakeMisShotgunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = quakeMisShotgunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakerocketFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= shotgunMissileFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakeMissileSmokeEmitter;
	stateEmitterTime[3]				= 0.04;
	stateEmitterNode[3]				= "tailNode";
	stateTimeoutValue[3]            = 0.18;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Fire";
	stateScript[5]                  = "onBoltback";
	stateTimeoutValue[5]            = 0.5;
	stateTransitionOnTimeout[5]     = "Wait";
	stateSound[5]					= quakeShotgunReloadSound;
	//stateEjectShell[5]       = true;

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.04;
	stateTransitionOnTimeout[6]     = "Ready";
};

function quakeMisShotgunImage::onFire(%this,%obj,%slot)
{
	%projectile = quakeMisShotgunProjectile;
	%spread = 0.008;
	%shellcount = 3;

	%obj.playThread(2, shiftleft);
	%obj.playThread(0, shiftright);
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-6")));
	%obj.spawnExplosion(QuakeBigRecoilProjectile,"1 1 1");
            serverPlay3D(quakeRocketFireSound,%obj.getPosition());
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
			scale = "0.5 0.5 0.5";
		};
		MissionCleanup.add(%p);
	}

	%projectile = quakeMisShotgunProjectile;
	%spread = 0.0002;
	%shellcount = 1;
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
			scale = "0.75 0.75 0.75";
		};
		MissionCleanup.add(%p);
	}
}

function quakeMisShotgunImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, plant);	
	%obj.playThread(0, shiftleft);
}
