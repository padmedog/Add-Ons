AddDamageType("Missilelauncher",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Missilelauncher> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Missilelauncher> %1',0.75,1);

datablock AudioProfile(WHMissilelauncherFireSound)
{
   filename    = "./Missilelauncher_Fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(WHMissilelauncherHitSound)
{
   filename    = "./Missilelauncher_hit.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(WHMissilelauncherTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.125;
	constantAcceleration	= 0.0;
	lifetimeMS		= 1000;
	lifetimeVarianceMS	= 500;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 0.375 0.1 0.75";
	colors[1]	= "0.5 0.5 0.5 0.25";
	colors[2]	= "0.2 0.2 0.2 0.0";
	sizes[0]	= 0.75;
	sizes[1]	= 0.375;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.4;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(WHMissilelauncherTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = WHMissilelauncherTrailParticle;

   useEmitterColors = true;
};

datablock DebrisData(WHMissilelauncherDebris)
{
   emitters = "WHMissilelauncherTrailEmitter";

	shapeFile = "base/data/shapes/empty.dts";
	lifetime = 0.5;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 1.0;
	friction = 0.0;
	numBounces = 0;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 1;
};

datablock ExplosionData(WHMissilelauncherExplosion)
{
   explosionShape = "";
   soundProfile = WHMissilelauncherHitSound;

   lifeTimeMS = 750;

   debris = WHMissilelauncherDebris;
   debrisNum = 30;
   debrisNumVariance = 10;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 180;
   debrisVelocity = 50;
   debrisVelocityVariance = 25;

   particleEmitter = IGGrenadeLauncherExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = IGGrenadeLauncherSmokeEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "5.0 5.5 5.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.25;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 2.5;
   lightStartColor = "1 0.875 0.5 1";
   lightEndColor = "1 0.75 0 0";

   damageRadius = 18;
   radiusDamage = 150;

   impulseRadius = 5;
   impulseForce = 1000;
};

datablock ProjectileData(WHMissilelauncherProjectile)
{
 projectileShapeName = "./missilelauncherprojectile.dts";
   directDamage        = 100;
   directDamageType    = $DamageType::WHMissilelauncher;
   radiusDamageType    = $DamageType::WHMissilelauncher;

   brickExplosionRadius = 8;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 45;             
   brickExplosionMaxVolume = 60;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 90;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   impactImpulse	     = 1000;
   verticalImpulse	  = 1000;
   explosion           = WHMissilelauncherExplosion;
   particleEmitter     = "WHMissilelauncherTrailEmitter";

   muzzleVelocity      = 100;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.5;

   hasLight    = true;
   lightRadius = 6.0;
   lightColor  = "1 0.5 0";
   
   uiName = "Missile Launcher Missile";
};


//////////
// item //
//////////
datablock ItemData(WHMissilelauncherItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Missilelaunchermounted.dts";
	rotate = false;
	mass = 10;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Missile Launcher";
	iconName = "./Missilelauncher";
	doColorShift = false;
	colorShiftColor = "0.2 0.2 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = WHMissilelauncherImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 1;
	
};




datablock ShapeBaseImageData(WHMissilelauncherproneImage)
{

   // Basic Item properties
   shapeFile = "./Missilelaunchermounted.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0.4 1.4 -0.65"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = WHMissilelauncherItem;
   ammo = " ";
   projectile = WHMissilelauncherProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "10 -1.3 0.3";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 10.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = False;
   colorShiftColor = WHMissilelauncherItem.colorShiftColor;//"0.400 0.196 0 1.000";
   

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
// Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 1.35;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= BoltgunflashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= WHMissilelauncherFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 1;
	stateTransitionOnTimeout[4]	= "Ready";
	
};
datablock ShapeBaseImageData(WHMissilelauncherImage)
{


   shapeFile = "./Missilelaunchercarry.dts";
   emap = false;
mountPoint = 0;
offset = "0 0 0";
   eyeOffset = "0 0 0"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";



melee = false;
armReady = false;
 doColorShift = False;
   colorShiftColor = WHMissilelauncherItem.colorShiftColor;//"0.400 0.196 0 1.000";



	stateName[0]                     = "Activate";
		statesequence[0]                     = "ready";
};


function WHMissilelauncherproneImage::onfire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(3, plant);

	%obj.spawnExplosion(TTHugeRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0006;
	}
	else
	{
		%spread = 0.0012;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}

package WHMissilelauncher
{
function Armor::onTrigger(%this, %player, %slot, %val)

	{
	if(isObject(%player.getMountedImage(0)))

		{

			if((%player.getMountedImage(0).getName() $= "WHMissilelauncherImage" || %player.getMountedImage(0).getName() $= "WHMissilelauncherproneImage") && %slot $= 4 && %val)
			{
			switch$(%player.getMountedImage(0).getName())
				{
				case "WHMissilelauncherimage":
				%player.mountImage(WHMissilelauncherproneimage,0);
					%player.playthread(1, armready);
					%player.playthread(0, sit);
				
				case "WHMissilelauncherproneimage":
				%player.mountImage(WHMissilelauncherimage,0);
					%player.playthread(0, root);
					%player.playthread(1, armready);
				//%player.playthread(2, armready);
				}
			}
		else
			{
			Parent::onTrigger(%this, %player, %slot, %val);
			}
		}
		else
		{
		Parent::onTrigger(%this, %player, %slot, %val);
	}
}
};	
ActivatePackage(WHMissilelauncher);	



function WHMissilelauncherproneImage::onMount(%this,%obj,%slot)
{
   
	%obj.playthread(1, armready);
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;
	%client.player.setDataBlock("WHproneArmor"); 
	
	   Parent::onMount(%this,%obj,%slot);
}


function WHMissilelauncherproneImage::onUnMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;

		%obj.playthread(0, root);
		%obj.playthread(3, root);
		if(!isObject(%client.minigame))
		{
			%client.player.setDataBlock("PlayerStandardArmor");

		}
		else
		{
			%client.player.setdatablock(%client.minigame.playerDatablock);

		}
}
function WHMissilelauncherImage::onMount(%this,%obj,%slot)
{
%obj.playthread(1, armreadyboth);
	Parent::onMount(%this,%obj,%slot);	




}

function WHMissilelauncherImage::onUnMount(%this,%obj,%slot)
{
//%obj.playthread(1, armready);
	Parent::onMount(%this,%obj,%slot);	

}
