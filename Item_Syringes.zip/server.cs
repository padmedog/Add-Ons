//########## Syringes

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
  if(!$RTB::RTBR_ServerControl_Hook) exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
  RTB_registerPref("Effect Duration in Seconds","Syringes","$GCStuff::SyringeDuration","int 1 120","Item_Syringes",60,0,0);
}
else
{
  $GCStuff::SyringeDuration = 60;
}

AddDamageType("gc_Syringe",'<bitmap:Add-ons/Item_Syringes/CI_syringe> %1','%2 <bitmap:Add-ons/Item_Syringes/CI_syringe> %1',0.2,1);

// exec("./baton.cs");
exec("./syringered.cs");
exec("./syringeyellow.cs");
exec("./syringecyan.cs");
exec("./syringegreen.cs");
exec("./syringeviolet.cs");

package gc_SyringesPackage
{
  function Armor::onTrigger(%this,%player,%slot,%val)
  {
    if(isObject(%player) && isObject(%player.getMountedImage(0))) {
      %image = %player.getMountedImage(0);
      if(%image.item.gc_syringe && %player.getImageState(0) $= "Ready" && %slot $= 4 && %val) %image.onSelfUse(%player,0);
    }
    parent::onTrigger(%this,%player,%slot,%val);
  }
};
activatePackage(gc_SyringesPackage);
