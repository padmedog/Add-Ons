$RSC::Revision += 4;

package JetpackControls
{
	function moveForward(%tog) { if($RSC::Jetpack) { $RSC::JetpackF = %tog; commandToServer('useJetpack', "F", %tog ? ServerConnection.getControlCameraFOV() / 75 : 0); } else Parent::moveForward(%tog); }
	function moveBackward(%tog) { if($RSC::Jetpack) { $RSC::JetpackB = %tog; commandToServer('useJetpack', "B", %tog ? ServerConnection.getControlCameraFOV() / 75 : 0); } else Parent::moveBackward(%tog); }
	function moveLeft(%tog) { if($RSC::Jetpack) { $RSC::JetpackL = %tog; commandToServer('useJetpack', "L", %tog ? ServerConnection.getControlCameraFOV() / 75 : 0); } else Parent::moveLeft(%tog); }
	function moveRight(%tog) { if($RSC::Jetpack) { $RSC::JetpackR = %tog; commandToServer('useJetpack', "R", %tog ? ServerConnection.getControlCameraFOV() / 75 : 0); } else Parent::moveRight(%tog); }
	function jump(%tog) { if($RSC::Jetpack) { $RSC::JetpackU = %tog; commandToServer('useJetpack', "U", %tog ? ServerConnection.getControlCameraFOV() / 75 : 0); } else Parent::jump(%tog); }
	function crouch(%tog) { if($RSC::Jetpack) { $RSC::JetpackD = %tog; commandToServer('useJetpack', "D", %tog ? ServerConnection.getControlCameraFOV() / 75 : 0); } else Parent::crouch(%tog); }
};
activatePackage(JetpackControls);

function updateJetpack(%lastFOV)
{
	cancel($UpdateJetpack);
	if(isObject(ServerConnection))
	{
		%fov = ServerConnection.getControlCameraFOV();
		if(%fov != %lastFOV)
		{
			if($RSC::JetpackF) commandToServer('useJetpack', "F", ServerConnection.getControlCameraFOV() / 75);
			if($RSC::JetpackB) commandToServer('useJetpack', "B", ServerConnection.getControlCameraFOV() / 75);
			if($RSC::JetpackL) commandToServer('useJetpack', "L", ServerConnection.getControlCameraFOV() / 75);
			if($RSC::JetpackR) commandToServer('useJetpack', "R", ServerConnection.getControlCameraFOV() / 75);
			if($RSC::JetpackU) commandToServer('useJetpack', "U", ServerConnection.getControlCameraFOV() / 75);
			if($RSC::JetpackD) commandToServer('useJetpack', "D", ServerConnection.getControlCameraFOV() / 75);
		}
	}
	$UpdateJetpack = schedule(16, 0, "updateJetpack", %fov);
}

function toggleJetpack(%tog)
{
	if($RSC::RealSpaceServer && %tog)
	{
		$RSC::Jetpack = !$RSC::Jetpack;
		clientcmdCenterPrint("\c6"@($RSC::Jetpack?"E":"Dise")@"ngaged jetpack movement.", 3);
		if(!$RSC:Jetpack)
		{
			if($RSC::JetpackF) { commandToServer('useJetpack', "F", 0); $RSC::JetpackF = 0; }
			if($RSC::JetpackB) { commandToServer('useJetpack', "B", 0); $RSC::JetpackB = 0; }
			if($RSC::JetpackL) { commandToServer('useJetpack', "L", 0); $RSC::JetpackL = 0; }
			if($RSC::JetpackR) { commandToServer('useJetpack', "R", 0); $RSC::JetpackR = 0; }
			if($RSC::JetpackU) { commandToServer('useJetpack', "U", 0); $RSC::JetpackU = 0; }
			if($RSC::JetpackD) { commandToServer('useJetpack', "D", 0); $RSC::JetpackD = 0; }
			cancel($UpdateJetpack);
		}
		updateJetpack(ServerConnection.getControlCameraFOV());
	}
}

function toggleAstroHelmet(%tog)
{
	if($RSC::RealSpaceServer && %tog)
	{
		if($Pref::Avatar::Hat != 1 || $Pref::Avatar::Accent != 1)
		{
			$Pref::Avatar::OldHat = $Pref::Avatar::Hat;
			$Pref::Avatar::OldAccent = $Pref::Avatar::Accent;
			$Pref::Avatar::Hat = 1; $Pref::Avatar::Accent = 1;
			clientcmdCenterPrint("\c6Put on your helmet.", 3);
		}
		else
		{
			$Pref::Avatar::Hat = $Pref::Avatar::OldHat + 0;
			$Pref::Avatar::Accent = $Pref::Avatar::OldAccent + 0;
			clientcmdCenterPrint("\c6Took off your helmet.", 3);
		}
		clientcmdUpdatePrefs();
	}
}

if(!$RealisticSpaceClientBound)
{
	$remapName[$remapCount++] = "Toggle Jetpack";
	$remapCmd[$remapCount] = "toggleJetpack";
	$remapName[$remapCount++] = "Toggle Helmet";
	$remapCmd[$remapCount] = "toggleAstroHelmet";
}