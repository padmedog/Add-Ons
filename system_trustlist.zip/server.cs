function reltrustlistserver() {
	exec("./server.cs");
}
