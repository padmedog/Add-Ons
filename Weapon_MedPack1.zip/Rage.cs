//Rage.cs
datablock AudioProfile(RageDrawSound)
{
   filename    = "./WeaponDraw.wav";
   description = AudioClosest3d;
   preload = true;
};
datablock AudioProfile(RageHitSound)
{
   filename    = "./WeaponHit.wav";
   description = AudioClosest3d;
   preload = true;
};


//effects
datablock ParticleData(RageExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = -1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/cloud";
   colors[0]     = "0.8 0.4 0 0.8";
   colors[1]     = "0.2 0.0 0 0.8";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};

datablock ParticleEmitterData(RageExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 4.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "RageExplosionParticle";

   uiName = "Rage Hit";
};

datablock ExplosionData(RageExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 500;

   soundProfile = RageHitSound;

   particleEmitter = RageExplosionEmitter;
   particleDensity = 30;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "00.0 0.2 0.6";
   lightEndColor = "0 0 0";
};

//projectile
AddDamageType("Rage",  'Destroyed %1',    '%2 Destroyed %1!',1,1);
datablock ProjectileData(RageProjectile)
{
   directDamage        = 45;
   directDamageType  = $DamageType::Rage;
   radiusDamageType  = $DamageType::Rage;
   explosion           = RageExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Rage Slice";
};

//////////
// item //
//////////
datablock ItemData(RageItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Rage.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotation = "0 0 180";

	//gui stuff
	uiName = "Rage";
	iconName = "./icon_Rage";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = RageImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(RageImage)
{
   // Basic Item properties
   shapeFile = "./Rage.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = "0 0 0";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = RageItem;
   ammo = " ";
   projectile = RageProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                   = "Activate";
	stateTimeoutValue[0]           = 0.5;
	stateTransitionOnTimeout[0]    = "Ready";
	stateSound[0]                  = weaponSwitchSound;

	stateName[1]                   = "Ready";
	stateTransitionOnTriggerDown[1]= "Fire";
	stateAllowImageChange[1]       = true;
	stateEmitter[1]                = RageExplosionEmitter;
	stateEmitterTime[1]            = 300;

	stateName[2]                   = "Fire";
	stateTransitionOnTimeout[2]    = "Reload";
	stateTimeoutValue[2]           = 0.5;
	stateFire[2]                   = true;
	stateAllowImageChange[2]       = false;
	stateSequence[2]               = "Fire";
	stateScript[2]                 = "onFire";
	stateWaitForTimeout[2]         = true;
	stateSound[2]                  = RageDrawSound;

	stateName[3]                   = "Reload";
	stateTransitionOnTriggerUp[3]  = "Ready";
};


function RageImage::onFire(%this, %obj, %slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, ShiftDown);
	Parent::onFire(%this,%obj,%slot);	
}

function RageImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
