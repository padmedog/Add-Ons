%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("Content_PhydeouxMedieval: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/DoubleWoodenDoors.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/WoodenGate.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/WoodenGateDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/GrateGate.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/GrateDropGate.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/CircularGrate.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/TrapDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/BookshelfDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/BookshelfDoor2.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/BookshelfDoor3.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/FenceGate.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/FenceGate2.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/ShojiDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/PullChainSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/PeggedWheelSwitch.cs");
	ContentTypesSO.addContentType("Add-Ons/content_phydeouxMedieval/types/LargeLeverSwitch.cs");
}