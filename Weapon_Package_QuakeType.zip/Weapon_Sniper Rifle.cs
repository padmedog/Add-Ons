//gun.cs

datablock AudioProfile(boltCycleSound)
{
   filename    = "./bolt_boltrifle.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(sniperrifleFireSound)
{
   filename    = "./sniperriflefire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(sniperrifleFireParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 90;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/star1";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "1.0 0.5 0 0.9";
    colors[1]     = "0.9 0.4 0 0.8";
    colors[2]     = "1 0.5 0.2 0.6";
    colors[3]     = "1 0.5 0.2 0.4";

    sizes[0]      = 2.75;
   sizes[1]      = 0.3;
    sizes[2]      = 0.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(sniperrifleFireEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 64.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "sniperrifleFireParticle";
};

datablock ParticleData(sniperrifleSmokeParticle)
{
    dragCoefficient      = 3;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 100;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/cloud";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "0.6 0.6 0.6 0.0";
    colors[1]     = "0.7 0.7 0.7 0.3";
    colors[2]     = "1 1 1 0.2";
    colors[3]     = "1 1 1 0";

    sizes[0]      = 0.15;
   sizes[1]      = 0.4;
    sizes[2]      = 0.10;
    sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(sniperrifleSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 9.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "sniperrifleSmokeParticle";
};

AddDamageType("sniperRifle",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_sniperrifle> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_sniperrifle> %1',0.2,1);

datablock ProjectileData(RaycastModelProjectile : gunProjectile)
{
   projectileShapeName = "./raycastline_beam.dts";
};

function drawRaylineSniperrifle(%pos1, %pos2)
{
	//should be the dimensions of the model in torque units
	%modelwidth = 0.1;
	%modeldepth = 0.1;
	%modelheight = 1.2;
	
	if(isObject($lastShape))
		$lastShape.delete();

	//find the point halfway between the two points, this will be our position
	%point = vectorAdd(vectorScale(vectorSub(%pos2, %pos1), 0.5), %pos1);
	
	//rotation
	%xRot = 0;
	
	//mAtan(z/len(x and y))
	%yRot = 90 - mRadToDeg(mAtan(getWord(%pos2, 2) - getWord(%pos1, 2), vectorLen(vectorSub(getWords(%pos2, 0, 1), getWords(%pos1, 0, 1)))));
	//%yRot = 90;
	
	//mAtan(x/y)
	%zRot = mRadToDeg(mAtan(getWord(%pos2, 1) - getWord(%pos1, 1), getWord(%pos2, 0) - getWord(%pos1, 0)));
	
	
	echo("Rot: " @ %xRot SPC %yRot SPC %zRot);
	
	%rot = eulerToAxis(%xRot SPC %yRot SPC %zRot);
	
	
	//scaling
	%width = 0.3 / %modelWidth;
	%depth = 0.3 / %modeldepth;
	%height = vectorLen(vectorSub(%pos2, %pos1)) / %modelheight;
	
	
	//create it
	%shape = new TSStatic() {
		shapeName = "./raycastline_beam.dts";
	};
	
	%shape.setTransform(%point SPC %rot);
	%shape.setScale(%width SPC %depth SPC %height);
	
	$lastShape = %shape;
	
	return %shape;
}

//////////
// item //
//////////
datablock ItemData(sniperrifleItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./anti_materiel_rifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Sniper Rifle";
	iconName = "./icon_sniperrifle";
	doColorShift = true;
	colorShiftColor = "0.2 0.2 0.21 1.000";

	 // Dynamic properties defined by the scripts
	image = sniperrifleImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(sniperrifleImage)
{
   // Basic Item properties
	shapeFile = "./anti_materiel_rifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = sniperrifleItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 300; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 50; //10
   raycastDirectDamageType = $DamageType::sniperRifle;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.15;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= sniperrifleFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= sniperrifleFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= sniperrifleSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.28;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Boltback";
	stateSequence[5]	= "Boltback";
	stateTimeoutValue[5]            = 0.38;
	stateScript[5]                  = "onBoltback";
	stateTransitionOnTimeout[5]     = "Boltforward";
	stateSound[5]					= boltCycleSound;
	stateEjectShell[5]       = true;

	stateName[6] = "Boltforward";
	stateSequence[6]	= "Boltfor";
	stateScript[6]                  = "onBoltfor";
	stateTimeoutValue[6]            = 0.28;
	stateTransitionOnTimeout[6]     = "Wait";

	stateName[7] = "Wait";
	stateTimeoutValue[7]            = 0.18;
	stateTransitionOnTimeout[7]     = "Ready";
};

function sniperrifleImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, shiftright);	
}

function sniperrifleImage::onBoltfor(%this,%obj,%slot)
{
	%obj.playThread(2, plant);	
}

function sniperrifleImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(QuakeBigRecoilProjectile,"1 1 1");
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-8")));
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	Parent::onFire(%this,%obj,%slot);

	%obj.playThread(2, shiftLeft);
	%obj.playThread(0, shiftRight);

	////////////////////////////////////////////////////
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylineSniperrifle(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylineSniperrifle(%start, %end);
	}
	%line.schedule(50, delete);
}

function sniperrifleImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}
