datablock ParticleData(shieldHIOOParticle)
{
	dragCoefficient      = 6;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	spinRandomMin = -90;
	spinRandomMax = 90;
	lifetimeMS           = 140;
	lifetimeVarianceMS   = 120;
	textureName          = "add-ons/weapon_package_support2/shield_fx";
   	colors[0]     = "1 1 1 0.1";
	colors[1]     = "1 0 0 0.2";
	colors[2]     = "1 1 1 0.1";
	colors[3]     = "0.0 0.0 0.0 0.0";
	sizes[0]      = 7.6;
	sizes[1]      = 6.8;
	sizes[2]      = 6.8;
	sizes[3]      = 6.80;
};

datablock ParticleEmitterData(shieldHIOOEmitter)
{
	ejectionPeriodMS = 60;
	periodVarianceMS = 0;
	ejectionVelocity = 0;
	velocityVariance = 0;
	ejectionOffset   = 0.5;
	thetaMin         = -180;
	thetaMax         = 180;
	phiReferenceVel  = -180;
	phiVariance      = 180;
	overrideAdvance = false;
	particles = "shieldHIOOParticle";
};

datablock ExplosionData(shieldHIOOExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 100;

   emitter[0] = shieldHIOOEmitter;
   emitter[1] = LaserPistolFlashEmitter;
   emitter[2] = shockDebuffExplosionEmitter;

   soundProfile = electrocuteHitSound;

   faceViewer     = true;
   explosionScale = "1 1 1";

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 1;
   lightStartColor = "00.0 0.6 0.9";
   lightEndColor = "0 0 0";
};

datablock ProjectileData(shieldHIOOProjectile : gunProjectile)
{
   explosion           = shieldHIOOExplosion;
   projectileShapeName = "";

   armingDelay         = 100;
   lifetime            = 100;
   fadeDelay           = 100;
};

//////////
// item //
//////////
datablock ItemData(shieldHIOOItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./energy_shield.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "400-HP Shield";
	iconName = "./icon_shield400";
	doColorShift = false;
	colorShiftColor = "0.61 0.61 0.65 1.000";

	 // Dynamic properties defined by the scripts
	image = dummyshieldimage;
	canDrop = true;

	 // Shield variables; 'light' shield.
	is_dmshield = 1;
	dmshield_amount = 400;
	dmshield_rechargeincrement = 2;

	dmshield_rechargerate = 60;
	dmshield_hurtrechargerate = 3000;
	dmshield_explosiontype = shieldHIOOProjectile;
};

////////////////
//weapon image//
////////////////