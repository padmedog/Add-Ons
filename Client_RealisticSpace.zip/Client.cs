function clientcmdRSC_Handshake()
{
	commandToServer('RSC_Handshake', $RSC::Revision);
	$RSC::RealSpaceServer = 1;
	showDirectionMarkers();
	RSC_HUDLoop();
	RSC_TransponderPing();
	RSC_Ambience();
}

function clientcmdUpdateMaterial(%amt, %mat)
{
	$RSC::MatRecord[-1+$RSC::MatRecords++] = %mat;
	$RSC::MatAmount[%mat] = %amt;
}

package RealSpaceClient
{
	function GameConnection::setConnectArgs(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j)
	{
		%j = %j@(%j$=""?"":"\t")@"RSC "@$RSC::Revision;
		$RSC::Jetpack = 0;
		%count = RSC_DirMarkers.getCount();
		for(%i=0;%i<%count;%i++)
		{
			%marker = RSC_DirMarkers.getObject(%i);
			if(getSubStr(%marker.markerName, 0, 7) $= "Player_")
				RSC_UpdateDirMarker(%marker.markerName, "DELETE");
		}
		RSC_PlayerList.delete();
		new ScriptObject(RSC_PlayerList);
		$RSC::MatRecords = 0;
		$RSC::RealSpaceServer = 0;
		cancel($RSC::TransponderPing);
		cancel($RSC::HUDLoop);
		cancel($RSC::Ambience);
		cancel($RSC::Ambience);
		for(%i=0;%i<$RSC::AmbVolume;%i++)
			alxStop($RSC::AmbHandle[%i]);
		Parent::setConnectArgs(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j);
	}
	
	function disconnect(%a)
	{
		$RSC::Jetpack = 0;
		%count = RSC_DirMarkers.getCount();
		for(%i=0;%i<%count;%i++)
		{
			%marker = RSC_DirMarkers.getObject(%i);
			if(getSubStr(%marker.markerName, 0, 7) $= "Player_")
				RSC_UpdateDirMarker(%marker.markerName, "DELETE");
		}
		RSC_PlayerList.delete();
		new ScriptObject(RSC_PlayerList);
		$RSC::MatRecords = 0;
		$RSC::RealSpaceServer = 0;
		cancel($RSC::TransponderPing);
		cancel($RSC::HUDLoop);
		cancel($RSC::Ambience);
		cancel($RSC::Ambience);
		for(%i=0;%i<$RSC::AmbVolume;%i++)
			alxStop($RSC::AmbHandle[%i]);

		Parent::disconnect(%a);
	}
};
activatePackage("RealSpaceClient");

if(!$RealisticSpaceClientBound) { $remapDivision[$remapCount] = "Realistic Space Client"; $remapCount--; }

$RSC::Revision = 0;
exec("./GUIs/Main.cs");

exec("./Ambience.cs");
exec("./ByteArraySO.cs");
exec("./Float16.cs");
exec("./Radio Chat.cs");
//exec("./Ghost Chat.cs");
exec("./Jetpack.cs");
exec("./Move Inds.cs");

if(!$RealisticSpaceClientBound) { $RealisticSpaceClientBound = 1; $remapCount++; }