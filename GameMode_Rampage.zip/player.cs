// player.cs contains everything related to the godzilla mode playertype

//Godzilla Playertype, grows bigger the more you blow up
datablock PlayerData( PlayerGodzilla : PlayerStandardArmor )
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Godzilla Player";
	showEnergyBar = false;
	
	minImpactSpeed = 3;
	groundImpactShakeFreq = "0 0 0";
	
	// no tools or items for now
	maxItems = 0;
	maxTools = 0;
	maxWeapons = 0;
};

datablock ProjectileData( godzillaImpactProjectile )
{
   directDamage        = 0;
   directDamageType  = 0;
   radiusDamageType  = 0;
   explosion           = "";

   brickExplosionRadius = 1.6;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 1;             
   brickExplosionMaxVolume = 50;//50;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 10;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)
   
   muzzleVelocity      = 0;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;
   explodeOnDeath = 0;

   hasLight    = false;

   uiName = "";
};

function godzillaImpactProjectile::onExplode( %this, %obj, %pos )
{
	%count = parent::onExplode( %this, %obj, %pos );
	
	%client = %obj.client;
	
	// this calculates what sound we should play if any
	gCalculateBreakSound( %client, %count, %pos );
}

function PlayerGodzilla::onImpact( %this, %obj, %col, %vec, %vel )
{
	// Delay things so that you don't spawn a ton of explosions back to back
	if( getSimTime() < %obj.gLastImpactTime+500 )
		return;

	%pos = %obj.getHackPosition();
	
	// spawn explosion to destroy bricks when we impact
	%p = new Projectile()
	{
		dataBlock = godzillaImpactProjectile;
		initialPosition = %pos;
		initialVelocity = 0;
		client = %obj.client;
		scale = %obj.getScale();
	};
	missionCleanup.add( %p );
	
	%p.setTransform( %pos );

	%p.explode();
	
	// now that we've exploded things and got points, let's see where we're at
	calculateGodzillaSize( %obj.client );
	
	// remember what time we impacted
	%obj.gLastImpactTime = getSimTime();
}

function PlayerGodzilla::onAdd( %this, %obj )
{
	parent::onAdd( %this, %obj );
	
	// reset level
	%obj.client.curLevel = 1;
	
	// to make checks a bit faster
	%obj.isGodzilla = 1;
	
	// set up the playertype
	//%obj.clearTools();
	%obj.mountImage( godzillaWeaponImage, 0 );
	%obj.setScale( "1 1 1" );
	
	// tell them how to play
	if( %obj.client.gHasLearned > 2 )
		return;
		
	%font = "<font:impact:40>";
	%color = "<color:FFFF00>";
	
	%text = %font @ %color @ "\nHold left click to smash bricks!";
	
	%obj.client.schedule( 50, centerPrint,%text, 5 );
	
	%obj.client.gHasLearned++;
}

