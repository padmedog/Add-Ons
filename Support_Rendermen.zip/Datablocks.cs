// DATA //
datablock ParticleData(RendermanAParticle)
{
   dragCoefficient      = 5.0;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.0;
   windCoefficient      = 0;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 0;
   useInvAlpha          = false;
   textureName          = "./images/hello2";
   colors[0]     = "0.1 0.1 0.1 0.7";
   colors[1]     = "1 0 0 0.8";
   colors[2]     = "1 1 1 0.5";
   sizes[0]      = 1;
   sizes[1]      = 1.5;
   sizes[2]      = 1.3;
   times[0]      = 0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(RendermanAEmitter)
{
   ejectionPeriodMS = 35;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 1.8;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   lifeTimeMS = 100;
   particles = "RendermanAParticle";

   doFalloff = true; //if we do fall off with this emitter it ends up flickering, for most emitters you want this TRUE

   emitterNode = GenericEmitterNode;        //used when placed on a brick
   pointEmitterNode = TenthEmitterNode; //used when placed on a 1x1 brick

   //uiName = "Scary Face";
};

datablock ExplosionData(RendermanAExplosion)
{
   lifeTimeMS = 2000;
   emitter[0] = RendermanAEmitter;
   soundProfile = Glimpse2;
};

datablock ProjectileData(RendermanAProjectile)
{
   explosion           = RendermanAExplosion;

   armingDelay         = 0;
   lifetime            = 50;
   explodeOnDeath		= true;

   //uiName = "Face Scary";
};

datablock ParticleData(RendermanBParticle)
{
   dragCoefficient      = 5.0;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.0;
   windCoefficient      = 0;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 0;
   useInvAlpha          = false;
   textureName          = "./images/hello1";
   colors[0]     = "0.1 0.1 0.1 0.7";
   colors[1]     = "1 0 0 0.8";
   colors[2]     = "1 1 1 0.5";
   sizes[0]      = 1;
   sizes[1]      = 1.5;
   sizes[2]      = 1.3;
   times[0]      = 0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(RendermanBEmitter)
{
   ejectionPeriodMS = 35;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 1.8;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   lifeTimeMS = 100;
   particles = "RendermanBParticle";

   doFalloff = true; //if we do fall off with this emitter it ends up flickering, for most emitters you want this TRUE

   emitterNode = GenericEmitterNode;        //used when placed on a brick
   pointEmitterNode = TenthEmitterNode; //used when placed on a 1x1 brick

   //uiName = "Scary Face";
};

datablock ExplosionData(RendermanBExplosion)
{
   lifeTimeMS = 2000;
   emitter[0] = RendermanBEmitter;
   soundProfile = Glimpse2;
};

datablock ProjectileData(RendermanBProjectile)
{
   explosion           = RendermanBExplosion;

   armingDelay         = 0;
   lifetime            = 50;
   explodeOnDeath		= true;

   //uiName = "Face Scary";
};

///////////////////
// detector item //
///////////////////
datablock ItemData(RenderDetector)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./models/detector.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Renderman Detector";
	iconName = "./images/detector";
	doColorShift = false;
	colorShiftColor = "1.0 1.0 1.0 1.0";

	 // Dynamic properties defined by the scripts
	image = RenderDetectorImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(RenderDetectorImage)
{
   // Basic Item properties
   shapeFile = "./models/detector.dts";
   emap = true;


   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeoffset = "0.7 1.2 -1";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = RenderDetector;
   ammo = " ";
   projectile = gunProjectile; // the detector doesn't shoot bullets but we have to define some anyway
   projectileType = Projectile;

	casing = gunShellDebris;  // whatever
	shellExitDir        = "0.0 0.0 0.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 0.0;	
	shellVelocity       = 0.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = RenderDetector.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";


   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.0;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;
};

///////////////////
//glitchgun item //
///////////////////
datablock ItemData(GlitchGun)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "base/data/shapes/printGun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Renderman GlitchGun";
	iconName = " ";
	doColorShift = true;
	colorShiftColor = "0.0 1.0 1.0 1.0";

	 // Dynamic properties defined by the scripts
	image = GlitchGunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(GlitchGunImage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/printGun.dts";
   emap = true;


   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeoffset = "0.7 1.2 -1";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = GlitchGun;
   ammo = " ";
   projectile = gunProjectile; // the ggun doesn't shoot any real bullets either but again we have to give it some
   projectileType = Projectile;

	casing = gunShellDebris;  // whatever
	shellExitDir        = "0.0 0.0 0.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 0.0;	
	shellVelocity       = 0.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = GlitchGun.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";


   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.0;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;
    
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "initiate";
	stateAllowImageChange[1]        = true;
    
    stateName[2]                = "initiate";
	stateScript[2]              = "onInit";
	stateTimeoutValue[2]        = 1;
	stateTransitionOnTimeout[2] = "Ready";
	stateAllowImageChange[2]    = false;
};

// Add a playertype to "freeze" the player
datablock PlayerData(PlayerRenderFrozenArmor : PlayerStandardArmor)
{
   runForce = 0;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;
   horizResistFactor = 1.0; // no moar slidies
   firstPersonOnly = 1; // no moar peakies
   thirdPersonOnly = 0;

   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;

   jumpForce = 0; //8.3 * 90;
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Frozen Player";
	showEnergyBar = false;
};

datablock AudioProfile(Ambient1)
{
	filename = "./soond/ambient1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(RenderDeath)
{
	filename = "./soond/fuckingshit.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(CatchSound)
{
	filename = "./soond/HESRIGHTTHERE.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(RenderAbduct)
{
	filename = "./soond/playertaken.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Ambient2)
{
	filename = "./soond/ambient2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(AmbientBoom)
{
	filename = "./soond/quietboom.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Creak1)
{
	filename = "./soond/creak1.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Creak2)
{
	filename = "./soond/creak2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Creak3)
{
	filename = "./soond/creak3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(BotVanish)
{
	filename = "./soond/botvanish.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Glimpse)
{
	filename = "./soond/glimpse.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Glimpse2)
{
	filename = "./soond/noticevanish.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(RenGrowl)
{
	filename = "./soond/indoorgrowl.wav";
	description = AudioClosest3d;
	preload = false;
};


datablock AudioProfile(MapLightsOff)
{
	filename = "./soond/lightsgo.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(MapLightsOn)
{
	filename = "./soond/lightsback.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(RenderChaseSound)
{
	filename = "./soond/boom.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(RenderChaseSound2)
{
	filename = "./soond/boom2.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(RenderChaseSound3)
{
	filename = "./soond/boom3.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Detector)
{
	filename = "./soond/detectorSound.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(GlitchGunSound)
{
	filename = "./soond/glitchgunfire.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock fxDtsBrickData(brickRenderSafe : brick2x2Data)
{
	uiName = "Anti-Renderman Shrine";
	category = "Special";
	subCategory = "Renderman Mod";
	indestructable = 1;
};

datablock fxDtsBrickData(brickRenderLight : brick2x2fRoundData)
{
	uiName = "Anti-Renderman Light";
	category = "Special";
	subCategory = "Renderman Mod";
	indestructable = 1;
};

datablock fxDtsBrickData(brickRenderDetect : brick1x1fData)
{
	uiName = "Detector Brick";
	category = "Special";
	subCategory = "Renderman Mod";
	indestructable = 1;
};