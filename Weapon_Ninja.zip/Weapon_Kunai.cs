//Script by: Hatakare, CI and ItemIcon and Model by Kaje.

//bullet trail effects
datablock ParticleData(KunaiTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 10;
	lifetimeVarianceMS   = 5;
	textureName          = "base/data/particles/Dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.3 0.3 0.9 0.4";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.20;
	sizes[1]      = 0.10;

	useInvAlpha = false;
};

datablock ParticleEmitterData(KunaiTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "KunaiTrailParticle";
};

datablock ParticleData(KunaiExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 200;
	textureName          = "base/data/particles/Star1";
	spinSpeed		   = 10.0;
	spinRandomMin	   = -50.0;
	spinRandomMax	   = 50.0;
	colors[0]     = "0.9 0.9 0.6 0.9";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 1.0;

	useInvAlpha = true;
};

datablock ExplosionData(KunaiExplosion)
{
   explosionShape = "add-ons/Weapon_Rocket Launcher/explosionSphere1.dts";
   soundProfile = rocketExplodeSound;

   lifeTimeMS = 150;

   particleEmitter = rocketExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "0.5 0.5 0.5";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 0;
   lightStartColor = "0.9 0.9 0";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 9;
   impulseForce = 1500;

   //radius damage
   damageRadius = 6;
   radiusDamage = 50;

};

AddDamageType("Kunai",   '<bitmap:add-ons/Weapon_Ninja/Ci_Kunai> %1',    '%2 <bitmap:add-ons/Weapon_Ninja/Ci_Kunai> %1',0.5,1);
datablock ProjectileData(KunaiProjectile)
{
   projectileShapeName = "./Kunaiprojectile.dts";
   directDamage        = 20;
   directDamageType    = $DamageType::Kunai;
   radiusDamageType    = $DamageType::Kunai;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 1;
   brickExplosionMaxVolume = 2;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 3;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse   = 600;
   explosion	     = KunaiExplosion;
   particleEmitter     = KunaiTrailEmitter;
   explodeOnDeath	     = true;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 1200;
   lifetime            = 1250;
   fadeDelay           = 2000;
   bounceElasticity    = 0.0;
   bounceFriction      = 0.20;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   isBallistic         = true;
   gravityMod = 0.5;

   hasLight    = true;
   lightRadius = 1;
   lightColor  = "0.9 0.9 0";

   uiName = "Kunai";
};

//////////
// item //
//////////
datablock ItemData(KunaiItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Kunai.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	cost = 200;

	//gui stuff
	uiName = "Incediary S.";
	iconName = "./Icon_Kunai";
	doColorShift = true;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = KunaiImage;
	canDrop = true;
	cost = 300;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(KunaiImage)
{
   // Basic Item properties
   shapeFile = "./Kunai.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0 0 0"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = KunaiItem;
   ammo = " ";
   projectile = KunaiProjectile;
   projectileType = Projectile;

//	casing = KunaiShellDebris;
//	shellExitDir        = "1.0 -1.3 1.0";
//	shellExitOffset     = "0 0 0";
//	shellExitVariance   = 15.0;	
//	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = KunaiItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.2;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Wait";
	stateTimeoutValue[2]            = 0.05;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";

	stateName[3]			= "Wait";
	stateTransitionOnTimeout[3]	= "Ready";
	statetimeoutValue[3]		= 1.2;
};

function KunaiImage::onFire(%this,%obj,%slot)
{
	%obj.addVelocity("0 0 3");
	%obj.playThread(2, shiftTo);
	Parent::onFire(%this,%obj,%slot);
}