%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_DoorsPack0: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/BoysBathroom.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/GirlsBathroom.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/UnisexBathroom.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/FridgeDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/FutureDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/MechanicalDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_DaleksDoors/types/AirVent.cs");
}