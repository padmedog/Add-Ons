//audio
datablock AudioProfile(SniperCarbineFireSound)
{
   filename    = "./SniperCarbine_fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(SniperCarbineTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 220;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 1 1";
	colors[1]	= "1 1 0.4 1";
	colors[2]	= "1 1 0 1";
	sizes[0]	= 0.05;
	sizes[1]	= 0.15;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(SniperCarbineTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = SniperCarbineTrailParticle;

   useEmitterColors = true;
};

datablock ProjectileData(SniperCarbineTracerProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 100;
   verticalImpulse	  = 50;
   explosion           = gunExplosion;
   particleEmitter     = "SniperCarbineTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 400;
   fadeDelay           = 400;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(SniperCarbineItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./sniper_carbine.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Sniper Carbine";
	iconName = "./snipercarbine";
	doColorShift = true;
	colorShiftColor = "0.33 0.33 0.33 1.000";

	 // Dynamic properties defined by the scripts
	image = SniperCarbineImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 11;
	canReload = 1;
};

AddDamageType("SniperCarbine",   '<bitmap:add-ons/Weapon_Package_Tier2A/snipercarb_ci> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2A/snipercarb_ci> %1',0.75,1);

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(SniperCarbineImage)
{

   // Basic Item properties
   shapeFile = "./sniper_carbine.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = SniperCarbineItem;
   ammo = " ";
   projectile = PumpShotgunProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = SniperCarbineItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 70; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 12; //10
   raycastDirectDamageType = $DamageType::SniperCarbine;
   raycastSpreadAmt = 0.0028; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = SniperCarbineTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTransitionOnTriggerUp[2] = "Smoke";
	stateWaitForTimeout[2]		= false;
	stateTimeoutValue[2]            = 0.02;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= SniperCarbinefireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[2]              = true;
	stateTimeoutValue[4]		= 0.001;
	stateScript[4]                  = "onBounce";
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	stateSound[4]			= SniperCarbineClickSound;
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 1.8;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.7;
	stateScript[9]				= "onReloaded";
	stateTransitionOnTimeout[9]		= "Ready";
};

function SniperCarbineImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	
	%obj.playThread(2, shiftAway);	
}

function SniperCarbineImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["708rounds"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function SniperCarbineImage::onBounce(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
	}
	%obj.playThread(2, plant);
}

function SniperCarbineImage::onReady(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
	}
}

function SniperCarbineImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["708rounds"] >= 1)
	{
	%obj.client.quantity["708rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["708rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["708rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["708rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["708rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["708rounds"] = 0;

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//sniper carbine image II: 'zoomed in' version

datablock ParticleData(SniperCarbineLaserParticle)
{
   dragCoefficient      = 5;
   gravityCoefficient   = -0.0;
   inheritedVelFactor   = 0;
   constantAcceleration = 0.0;
   lifetimeMS           = 66;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/dot";
   spinSpeed           = 0.0;
   spinRandomMin        = 0.0;
   spinRandomMax        = 0.0;
   colors[0]     = "1 0.5 0.5 1";
   colors[1]     = "1 1 1 0.2";
   colors[2]     = "1 1 1 0";

   sizes[0]      = 0.35;
   sizes[1]      = 0.05;
   sizes[2]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 1.0;

   useInvAlpha = false;
};

datablock ParticleEmitterData(SniperCarbineLaserEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 88.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "SniperCarbineLaserParticle";
};


////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(SniperCZoomedImage)
{

   // Basic Item properties
   shapeFile = "./sniper_carbine.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
eyeoffset = "0 0.5 -0.2629";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = SniperCarbineItem;
   ammo = " ";
   projectile = PumpShotgunProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = SniperCarbineItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 70; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = GunProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 14; //10
   raycastDirectDamageType = $DamageType::SniperCZoomed;
   raycastSpreadAmt = 0.0001; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = SniperCarbineTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTimeout[1]      = "Ready";
	stateTimeoutValue[1]             = 0.05;
	stateWaitForTimeout[1]           = 0;
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";
	stateEmitter[1]			= SniperCarbineLaserEmitter;
	stateEmitterTime[1]		= 0.05;
	stateEmitterNode[1]		= "laserNode";
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTransitionOnTriggerUp[2] = "Smoke";
	stateWaitForTimeout[2]		= false;
	stateTimeoutValue[2]            = 0.2;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Activate";
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= SniperCarbinefireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[2]              = true;
	stateTimeoutValue[4]		= 0.001;
	stateScript[4]                  = "onBounce";
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	stateSound[4]			= SniperCZoomedClickSound;
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 1.1;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.3;
	stateScript[9]				= "onReloaded";
	stateTransitionOnTimeout[9]		= "Ready";
};

function SniperCZoomedImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
   %obj.pushDatablock(LMGArmor.getID());
}

function SniperCZoomedImage::onUnMount(%this,%obj,%slot)
{
   Parent::onUnMount(%this,%obj,%slot);
   %obj.popDatablock(LMGArmor.getID());
}

function SniperCZoomedImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	
	%obj.playThread(2, plant);	
}

function SniperCZoomedImage::onReloadStart(%this,%obj,%slot)
{
	%obj.mountImage(SniperCarbineImage,0);
}

function SniperCZoomedImage::onBounce(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
	}
	%obj.playThread(2, plant);
}

function SniperCZoomedImage::onReady(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>7.08 Heavy Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["708rounds"] @ "", 1, 2, 3, 4); 
	}
}

function SniperCZoomedImage::isRaycastCritical(%this, %obj, %slot, %col, %pos, %normal, %hit)
{
   if(!isObject(%col))
      return 0;
   if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
      %dmg = 1;
   if(miniGameCanDamage(%obj,%col) != 1 && !%dmg)
      return 0;
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %colscale = getWord(%col.getScale(),2);
      return(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale);
      //return (getWord(%col.getDamageLocation(%pos),0) $= "head");
   }
   return 0;
}

//////////////////////////////////////////////


package SniperCarbine
{
  	function Armor::onTrigger(%this, %player, %slot, %val)
	{
		if(%player.getMountedImage(0) $= SniperCarbineImage.getID() && %slot $= 4 && %val)
		{
		  %player.mountImage(SniperCZoomedImage,0);
		}     
		
		else if(%player.getMountedImage(0) $= SniperCZoomedImage.getID() && %slot $= 4 && %val)
		{
		  %player.mountImage(SniperCarbineImage,0);
		}
		Parent::onTrigger(%this, %player, %slot, %val);
	}

	function servercmdDropTool(%client,%slot)
	{
		if(%client.player.getMountedImage(0) $= SniperCZoomedImage.getID())
		{
		  %client.player.unmountImage(0);
		}
		return Parent::servercmdDropTool(%client,%slot);
	}
};	
ActivatePackage(SniperCarbine);	