if(!isObject(RLC_WindowProfile)) new GuiControlProfile(RLC_WindowProfile : BlockWindowProfile)
{
	fontType = "Arial";
	fontSize = "14";
	opaque = false;
	fillColor = "242 241 240";
	fillColorHL = "221 221 221";
	fillColorNA = "200 200 200";
	fontColor = "50 50 50";
	fontColorHL = "0 0 0";
	textOffset = "8 4";
	bitmap = "Add-Ons/Client_Rising_Lava/res/images/uiWindow.png";
};

if(!isObject(RLC_HeaderText)) new GuiControlProfile(RLC_HeaderText)
{
	fontColor = "50 50 50";
	fontSize = 16;
	fontType = "Arial";
	justify = "Left";
	fontColors[1] = "100 100 100";
	fontColors[2] = "0 255 0";  
	fontColors[3] = "0 0 255"; 
	fontColors[4] = "255 255 0";   
};

if(!isObject(RLC_ButtonText)) new GuiControlProfile(RLC_ButtonText)
{
	fontColor = "50 50 50";
	fontSize = 16;
	fontType = "Arial";
	justify = "Center";
	fontColors[1] = "100 100 100";
	fontColors[2] = "0 255 0";  
	fontColors[3] = "0 0 255"; 
	fontColors[4] = "255 255 0";   
};

if(!isObject(RLC_VoteButtonText)) new GuiControlProfile(RLC_VoteButtonText)
{
	fontColor = "250 252 251";
	fontSize = 14;
	fontType = "Arial";
	justify = "Left";
	doFontOutline = false;

	textOffset = "8 0";
};

if(!isObject(RLC_ScrollProfile)) new GuiControlProfile(RLC_ScrollProfile)
{
	fontType = "Book Antiqua";
	fontSize = 22;
	justify = "Center";
	fontColor = "0 0 0";
	fontColorHL = "130 130 130";
	fontColorNA = "255 0 0";
	fontColors[0] = "0 0 0";
	fontColors[1] = "0 255 0";  
	fontColors[2] = "0 0 255"; 
	fontColors[3] = "255 255 0";
	hasBitmapArray = true;
	
	bitmap = "Add-Ons/Client_Rising_Lava/res/images/uiScroll.png";
};

if(!isObject(RLC_TextEditProfile)) new GuiControlProfile(RLC_TextEditProfile : GuiTextEditProfile)
{
	fillColor = "255 255 255 255";
	borderColor = "188 191 193 255";
	fontSize = 12;
	fontType = "Arial";
	fontColor = "50 50 50";
	fontColors[0] = "64 64 64 255";
	fontColors[1] = "0 0 0";
};

if(!isObject(RLC_MLEditProfile)) new GuiControlProfile(RLC_MLEditProfile : GuiMLTextEditProfile)
{
	fontSize = 12;
	fontType = "Arial";
	fontColor = "50 50 50";
	fontColors[0] = "64 64 64 255";
};

if(!isObject(RLC_CheckBoxProfile)) new GuiControlProfile(RLC_CheckBoxProfile : GuiCheckBoxProfile)
{
	bitmap = "Add-Ons/Client_Rising_Lava/res/images/checkboxArray";
};