datablock fxDTSBrickData (brick4xPoleBrickBarData)
{
	brickFile = "./4xpolebarbrick.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "P Bar 4x";
	iconName = "Add-Ons/Brick_ExtraBars/4x";
};
datablock fxDTSBrickData (brick3xPoleBrickBarData)
{
	brickFile = "./3xpolebarbrick.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "P Bar 3x";
	iconName = "Add-Ons/Brick_ExtraBars/3x";
};
datablock fxDTSBrickData (brick2xPoleBrickBarData)
{
	brickFile = "./2xpolebarbrick.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "P Bar 2x";
	iconName = "Add-Ons/Brick_ExtraBars/2x";
};
datablock fxDTSBrickData (brick1xPoleBrickBarData)
{
	brickFile = "./1xpolebarbrick.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "P Bar 1x";
	iconName = "Add-Ons/Brick_ExtraBars/1x";
};