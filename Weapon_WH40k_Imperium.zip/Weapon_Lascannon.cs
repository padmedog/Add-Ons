AddDamageType("Lascannon",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Lascannon> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Lascannon> %1',0.75,1);

datablock AudioProfile(LascannonFireSound)
{
   filename    = "./Lascannon_Fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(LascannonTrailParticle)
{
	dragCoefficient		= 0.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0625;
	constantAcceleration	= 0.0;
	lifetimeMS		= 360;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "0.275 0.125 1.0 0.75";
	colors[1]	= "0.15 0.1 1.0 0.5";
	sizes[0]	= 0.75;
	sizes[1]	= 0.5;
};

datablock ParticleEmitterData(LascannonTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = LascannonTrailParticle;

   useEmitterColors = true;
};

datablock ParticleData(LascannonExplosionParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 250;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]	= "0.15 0.1 1.0 1.0";
	colors[1]	= "0.65 0.5 1.0 0.0";
	sizes[0]      = 1.5;
	sizes[1]      = 0.375;

	useInvAlpha = false;
};
datablock ParticleEmitterData(LascannonExplosionEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 12;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "LascannonExplosionParticle";

   useEmitterColors = false;
   uiName = "Lascannon Hit Dust";
};

datablock ParticleData(LascannonExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 50;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	  = "0.15 0.1 1.0 1.0";
	colors[1]     = "0.4 0.25 1.0 0";
	sizes[0]      = 3.0;
	sizes[1]      = 4.5;

	useInvAlpha = false;
};
datablock ParticleEmitterData(LascannonExplosionRingEmitter)
{
	lifeTimeMS = 400;

   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "LascannonExplosionRingParticle";

   useEmitterColors = true;
   uiName = "Lascannon Hit Flash";
};

datablock ExplosionData(LascannonExplosion)
{
   //explosionShape = "";
	soundProfile = MeltagunHitSound;

   lifeTimeMS = 100;

   particleEmitter = LascannonExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = LascannonExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "2.0 2.0 2.0";
   camShakeAmp = "2.0 2.0 2.0";
   camShakeDuration = 0.5;
   camShakeRadius = 2.5;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 4;
   lightStartColor = "0.5 0.25 1.0 1.0";
   lightEndColor = "0 0 0";
   playerBurnTime = 2000;
   
   damageRadius = 0.5; 
   radiusDamage = 90;                                           
   impulseRadius = 2;  
   impulseForce = 2000; 
  
};

datablock ProjectileData(LascannonTracerProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   particleEmitter     = "LascannonTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 2000;
   fadeDelay           = 1400;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "0.15 0.1 1";
   
};

datablock ProjectileData(LascannonExplosionProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = LascannonExplosion;
   particleEmitter     = "";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 2000;
   fadeDelay           = 1400;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "0.25 0.1 1";
   
};


//////////
// item //
//////////
datablock ItemData(LascannonItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Lascannonmounted.dts";
	rotate = false;
	mass = 10;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Lascannon";
	iconName = "./Lascannon";
	doColorShift = false;
	colorShiftColor = "0.2 0.2 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = LascannonImage;
	canDrop = true;
	
	maxAmmo = 5;
	canReload = 1;
	
};




datablock ShapeBaseImageData(LascannonproneImage)
{

   // Basic Item properties
   shapeFile = "./Lascannonmounted.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0.4 1.4 -0.65"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = LascannonItem;
   ammo = " ";
   projectile = LascannonTracerProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "10 -1.3 0.3";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 10.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = False;
   colorShiftColor = LascannonItem.colorShiftColor;//"0.400 0.196 0 1.000";
   

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   
   raycastWeaponRange = 400; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = LascannonExplosionProjectile;
   raycastExplosionBrickSound = LascannonHitSound;
   raycastExplosionPlayerSound = LascannonHitSound;
   raycastDirectDamage = 250; //10
   raycastDirectDamageType = $DamageType::Lascannon;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = LascannonTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 1.35;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Warmup";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= "";
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 1.00;
	stateTransitionOnTimeout[4]	= "Ready";

	
	stateName[10]				= "Warmup";
	stateTimeoutValue[10]		= 0.5;
	stateTransitionOnTimeout[10]	= "Fire";
	stateSound[10]			= LascannonFireSound;
};
datablock ShapeBaseImageData(LascannonImage)
{


   shapeFile = "./Lascannoncarry.dts";
   emap = false;
mountPoint = 0;
offset = "0 0 0";
   eyeOffset = "0 0 0"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";



melee = false;
armReady = false;
 doColorShift = False;
   colorShiftColor = LascannonItem.colorShiftColor;//"0.400 0.196 0 1.000";



	stateName[0]                     = "Activate";
		statesequence[0]                     = "ready";
};


function LascannonproneImage::onfire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTHugeRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0050;
		%this.raycastWeaponRange = 50;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0000;
		%this.raycastWeaponRange = 400;
	}

		Parent::onFire(%this,%obj,%slot);

	%obj.playThread(3, plant);
}

package Lascannon
{
function Armor::onTrigger(%this, %player, %slot, %val)

	{
	if(isObject(%player.getMountedImage(0)))

		{

			if((%player.getMountedImage(0).getName() $= "LascannonImage" || %player.getMountedImage(0).getName() $= "LascannonproneImage") && %slot $= 4 && %val)
			{
			switch$(%player.getMountedImage(0).getName())
				{
				case "Lascannonimage":
				%player.mountImage(Lascannonproneimage,0);
					%player.playthread(2, armreadyboth);
					%player.playthread(0, sit);
				
				case "Lascannonproneimage":
				%player.mountImage(Lascannonimage,0);
					%player.playthread(0, root);
					%player.playthread(2, armreadyboth);
				//%player.playthread(2, armready);
				}
			}
		else
			{
			Parent::onTrigger(%this, %player, %slot, %val);
			}
		}
		else
		{
		Parent::onTrigger(%this, %player, %slot, %val);
	}
}
};	
ActivatePackage(Lascannon);	



function LascannonproneImage::onMount(%this,%obj,%slot)
{
   
  // %obj.playthread(0, armreadyboth);
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;
	%client.player.setDataBlock("WHproneArmor"); 
	
	   Parent::onMount(%this,%obj,%slot);
	
}


function LascannonproneImage::onUnMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;

		%obj.playthread(0, root);
		%obj.playthread(1, root);
		%obj.playthread(2, root);
		if(!isObject(%client.minigame))
		{
			%client.player.setDataBlock("PlayerStandardArmor");

		}
		else
		{
			%client.player.setdatablock(%client.minigame.playerDatablock);

		}
}
function LascannonImage::onMount(%this,%obj,%slot)
{
%obj.playthread(2, armreadyboth);
	Parent::onMount(%this,%obj,%slot);	




}

function LascannonImage::onUnMount(%this,%obj,%slot)
{
%obj.playthread(2, root);
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;
		if(!isObject(%client.minigame))
		{


		}

}

function LascannonproneImage::onRaycastDamage(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   %damageType = $DamageType::Direct;
   if(%this.raycastDirectDamageType)
      %damageType = %this.raycastDirectDamageType;
   
   %scale = getWord(%obj.getScale(), 2);
   %directDamage = mClampF(%this.raycastDirectDamage, -1000, 1000) * %scale;
   
   if(%crit)
   {
      if(%this.raycastCritDirectDamageType)
         %damageType = %this.raycastCritDirectDamageType;
      
      %directDamage = %directDamage * 3;
      
      %colscale = getWord(%col.getScale(),2);
      %col.spawnExplosion(critProjectile,%colscale);
      if(isObject(%col.client))
         %col.client.play2d(critRecieveSound);
   }
   
   if(%this.raycastImpactImpulse > 0)
      %col.applyImpulse(%pos,vectorScale(%shotVec,%this.raycastImpactImpulse));
   
   if(%this.raycastVerticalImpulse > 0)
      %col.applyImpulse(%pos,vectorScale("0 0 1",%this.raycastVerticalImpulse));
   
   %col.damage(%obj, %pos, %directDamage, %damageType);
}
