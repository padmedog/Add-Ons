//sound datablocks

datablock AudioProfile(MelodyFiring)
{
	fileName = "./Sound/MelodyFiring.wav";
	preload = true;
	description = AudioCloseLooping3D;
};

datablock AudioProfile(SoundSpinning)
{
	fileName = "./Sound/SoundSpinning.wav";
	preload = true;
	description = AudioClose3D;
};

datablock AudioProfile(SoundFireworkFlight)
{
	fileName = "./Sound/SoundFireworkFlight.wav";
	preload = true;
	description = AudioDefaultLooping3D;
};

datablock AudioProfile(SoundSpinOn)
{
	fileName = "./Sound/SoundSpinOn.wav";
	preload = true;
	description = AudioClose3D;
};

datablock AudioProfile(SoundSpinOff)
{
	fileName = "./Sound/SoundSpinOff.wav";
	preload = true;
	description = AudioClose3D;
};

//Particles

datablock ParticleData(amerigunMuzzleStarParticle)
{
	dragCoefficient      = 0.2;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 1.0;
	lifetimeMS           = 150;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.5";
	colors[1]     = "0.5 0.0 1.0 0.6";
	sizes[0]      = 1.0;
	sizes[1]      = 1.0;
	times[0]      = 0.0;
	times[1]	= 1.0;

	useInvAlpha = false;
};

datablock ParticleData(amerigunMuzzleNutParticle)
{
	dragCoefficient      = 0.8;
	gravityCoefficient   = 0.3;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.2;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/nut";
	spinSpeed		= 30.0;
	spinRandomMin		= -100.0;
	spinRandomMax		= 300.0;
	colors[0]     = "1.0 0.1 0.2 0.5";
	colors[1]     = "0.7 0.5 0.0 0.6";
	sizes[0]      = 0.4;
	sizes[1]      = 0.5;
	times[0]      = 0.0;
	times[1]	= 1.0;

	useInvAlpha = false;
};


datablock ParticleData(amerigunFireworkParticle)
{

	dragCoefficient      = 0.2;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 1.0;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 100;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.0 0.0 1.0 0.4";
	colors[1]     = "1.0 0.0 0.0 0.8";
	sizes[0]      = 0.2;
	sizes[1]      = 0.1;
	times[0]	= 0.0;
	times[1]	= 1.0;

	useInvAlpha = false;
};

datablock ParticleData(amerigunExplosionStarParticle)
{
	dragCoefficient      = 0.3;
	gravityCoefficient   = -0.2;
	inheritedVelFactor   = 0;
	constantAcceleration = 1;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 100;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1.0 0.3 0.4 0.5";
	colors[1]     = "0.8 0.8 0.8 0.8";
	colors[2]	= "0.2 0.0 1.0 0.9";
	sizes[0]      = 0.5;
	sizes[1]      = 0.75;
	sizes[2]	= 1;
	times[0]	= 0.0;
	times[1] = 0.3;
	times[2] = 1.0;

	useInvAlpha = true;
};

datablock ParticleData(amerigunExplosionCloudParticle)
{
	dragCoefficient      = 0.1;
	gravityCoefficient   = -0.1;
	inheritedVelFactor   = 0;
	constantAcceleration = 1.0;
	lifetimeMS           = 800;
	lifetimeVarianceMS   = 200;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1.0 0.7 0.7 0.5";
	colors[1]     = "0.2 0.2 0.2 0.8";
	colors[2]	= "0.1 0.1 0.9 0.2";
	sizes[0]      = 0.7;
	sizes[1]      = 1.5;
	sizes[2]	= 1.5;
	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;

	useInvAlpha = false;
};

//Particle Emitters

datablock ParticleEmitterData(amerigunMuzzleEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 7;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = true;
   particles[0] = "amerigunMuzzleStarParticle";
};

datablock ParticleEmitterData(amerigunNutEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 3;
   phiVariance      = 360;
   overrideAdvance = true;
   particles[0] = "amerigunMuzzleNutParticle";
};

datablock ParticleEmitterData(amerigunExplosionCloudEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 0.5;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "amerigunExplosionCloudParticle";
};

datablock ParticleEmitterData(amerigunExplosionStarEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 0.5;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "amerigunExplosionStarParticle";
};

datablock ParticleEmitterData(amerigunTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.3;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "amerigunFireworkParticle";
};	

//Explosion

datablock ExplosionData(amerigunExplosion)
{
   soundProfile = rocketExplodeSound;

   lifeTimeMS = 250;

   emitter[0] = "amerigunExplosionStarEmitter";
   emitter[1] = "amerigunExplosionCloudEmitter";
   particleDensity = 10;
   particleRadius = 12.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.6;
   camShakeRadius = 7.0;

   damageRadius = 6.5;
   radiusDamage = 40;

   impulseRadius = 7.0;
   impulseForce = 2500;
};

//Firework projectile
AddDamageType("AmericanFirework", '<bitmap:add-ons/Weapon_ManifestDestiny/IMG/CI_amerigun> %1', '%2 <bitmap:add-ons/Weapon_ManifestDestiny/IMG/CI_Amerigun> %1',0.2,1); 
datablock ProjectileData(AmericanFireworkProjectile : gunProjectile)
{
	ProjectileShapeName = "./Projectile/firework.dts";
	directDamage = 18;
	directDamageType    = $DamageType::AmericanFirework;
	radiusDamageType    = $DamageType::AmericanFirework;

	particleEmitter = amerigunTrailEmitter;

	impactImpulse = 800;
	verticalImpulse = 900;
	velInheritFactor  = 0.0;

	isBallistic	= true;
	gravityMod	= 0.4;
	armingDelay	= 450;
	lifetime	= 1200;

	muzzleVelocity	= 120;
	bounceElasticity	= 0.15;
	explodeOnDeath		= true;

	explosion = AmerigunExplosion;
	sound = SoundFireworkFlight;
};

//Dolla dolla bill y'all
datablock DebrisData(dollarstackDebris : gunShellDebris)
{
   shapeFile = "./Debris/dollarstack.dts";

   friction = 0.7;
   elasticity = 0;

   numBounces = 0;
   minSpinSpeed = 0;
   maxSpinspeed = 0;
};
   