//	--
//Title: PropSys
//Author: NiXiLL
//	--

//Packages
	package PropSys_Pack
	{
		function fxDtsBrick::onAdd(%b)
		{
			%a=Parent::onAdd(%b);
			
			%b.applyPS();
			
			return %a;
		}
		
		function fxDtsBrick::setTransform(%b,%trans)
		{
			Parent::setTransform(%b,%trans);
			
			if(isObject(%b.prop))
			{
				%b.prop.setTransform(vectorAdd(%b.getPosition(),%b.getDatablock().modelOffset) SPC IDToRot(%b.getAngleID()));
			}
		}
		
		function fxDtsBrick::setColor(%b,%id)
		{
			Parent::setColor(%b,%id);
			
			if(isObject(%b.prop))
			{
				%b.prop.applyPSColor(%b);
			}
		}
		
		function fxDtsBrick::onRemove(%b)
		{
			if(isObject(%b.prop))
			{
				%b.prop.delete();
			}
			
			return Parent::onRemove(%b);
		}
		
		function fxDtsBrick::killBrick(%b)
		{
			if(isObject(%b.prop))
			{
				%b.prop.delete();
			}
			
			return Parent::killBrick(%b);
		}
		
		function fxDtsBrick::setDatablock(%b,%db)
		{
			%a=Parent::setDatablock(%b,%db);
			
			%b.applyPS();
			
			return %a;
		}
	};ActivatePackage(PropSys_Pack);
//--

//Prop Properties
	function fxDtsBrick::applyPS(%b)
	{
		%db=%b.getDatablock();
		
		if(isObject(%b.prop)) {%b.prop.delete();}
		
		if(isObject(%db.spawnModel))
		{
			%b.prop=new ((%db.spawnType$="")?"StaticShape":%db.spawnType)()
			{
				datablock=%db.spawnmodel;
				spawnBrick=%b;
				client=%b.getGroup().client;
				position=vectorAdd(%b.getPosition(),%db.modelOffset) SPC IDToRot(%b.getAngleID());
			};
			
			if(%db.modelScale!$="")
			{
				%b.prop.setScale(%db.modelScale);
			}
			
			%b.prop.applyPSColor(%b);
		}
		
		if(%db.brickRaycast!$="")
		{
			%b.setRaycasting(%db.brickRaycast);
		}
		
		if(%db.brickRender!$="")
		{
			%b.setRendering(%db.brickRender);
		}
		
		if(%db.brickCollide!$="")
		{
			%b.setColliding(%db.brickCollide);
		}
	}
	
	function SimObject::applyPSColor(%s,%br)
	{
		%color=getColorIDTable(%br.getColorID());
		
		%r=getWord(%color,0);
		%g=getWord(%color,1);
		%b=getWord(%color,2);
		
		%db=%br.getDatablock();
		
		for(%i=0;%i<%db.colorCount;%i++)
		{
			switch$(%db.colorMode[%i])
			{
				case "Intensity":
					%color=%db.colorShift[%i];
					
					%rr=getWord(%color,0);
					%gg=getWord(%color,1);
					%bb=getWord(%color,2);
					%a=getWord(%color,3);
					
					%s.setNodeColor(%db.colorGroup[%i],%r*%rr SPC %g*%gg SPC %b*%bb SPC %a);
					
				case "Fix":
					%color=%db.colorShift[%i];
					
					%rr=getWord(%color,0);
					%gg=getWord(%color,1);
					%bb=getWord(%color,2);
					%a=getWord(%color,3);
					
					%s.setNodeColor(%db.colorGroup[%i],%rr SPC %gg SPC %bb SPC %a);
				
				default:
					error("[PropSys] Invalid coloring mode!");
			}
		}
	}
//--

//Support
	function IDtoRot(%id)
	{
		switch(%id)
		{
			case 0:
				%trans = %trans SPC " 1 0 0 0";
			case 1:
				%trans = %trans SPC " 0 0 1" SPC $pi/2;
			case 2:
				%trans = %trans SPC " 0 0 1" SPC $pi;
			case 3:
				%trans = %trans SPC " 0 0 -1" SPC $pi/2;
		}
		return %trans;
	}
//--