if($Pref::Updater::DisableStatistics)
	return;

$Updater::Stats::PostTimeOut = 10000;
$Updater::Stats::PostQueueLen = 0;

function addToStatsPostQueue(%name, %blid, %ip)
{
	//if($Updater::Stats::Posted[%blid])
	//	return;
	//echo("ADD STATS" SPC %name SPC %blid SPC %ip);
	//$Updater::Stats::Posted[%blid] = true;
	$Updater::Stats::PostQueue[$Updater::Stats::PostQueueLen, "name"] = %name;
	$Updater::Stats::PostQueue[$Updater::Stats::PostQueueLen, "addr"] = %ip;
	$Updater::Stats::PostQueueLen ++;
	
	cancel($Updater::Stats::PostSched);
	$Updater::Stats::PostSched = schedule($Updater::Stats::PostTimeOut, 0, postPlayerStatistics);
}

function postPlayerStatistics()
{
	cancel($Updater::Stats::PostSched);

	for(%i = 0; %i < $Updater::Stats::PostQueueLen; %i ++)
	{
		%name = urlEnc($Updater::Stats::PostQueue[%i, "name"]);
		%ip = $Updater::Stats::PostQueue[%i, "addr"];
		%data = setRecord(%data, %i, %name @ ";" @ %ip);
	}
	
	%tcp = TCPClient
	(
		"POST",
		"mods.greek2me.us",
		"80",
		"/statistics/bl-users-post.php",
		%data
	);
	
	deleteVariables("$Updater::Stats::PostQueue*");
	$Updater::Stats::PostQueueLen = 0;
}

package updaterStatistics
{
	function GameConnection::autoAdminCheck(%this)
	{
		%blid = %this.getBLID();
		if(%blid !$= getNumKeyID() && !$Server::LAN)
		{
			%ip = %this.isLAN() ? "LOCAL" : %this.getRawIP();
			addToStatsPostQueue(%this.getPlayerName(), %blid, %ip);
		}
		return parent::autoAdminCheck(%this);
	}
};
activatePackage(updaterStatistics);