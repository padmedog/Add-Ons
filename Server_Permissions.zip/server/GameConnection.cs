function GameConnection::getAdminLevel(%this) {
    if (%this.getName() $= "localclientconnection" || %this.bl_id == getNumKeyID())
        return 3;
    if (%this.isSuperAdmin)
        return 2;
    if (%this.isAdmin)
        return 1;
    return 0;
}

function GameConnection::getRole(%this) {
    return getPermissionManager().getRoleByClientBL_ID(%this.bl_id);
}

function GameConnection::setRole(%this, %role) {
    %pm = getPermissionManager();
    %pm.setRoleByClientBL_ID(%this.bl_id, %pm.getRole(%role));

    for(%i = 0; %i < ClientGroup.getCount(); %i++)
    {
        %c = ClientGroup.getObject(%i);
        PermGui_sendInfo(%c);
    }

    messageClient(%this, '', "\c2You have been set to role " @ %this.getRole().name);
}

function GameConnection::hasDirectPermission(%this, %permission) {
    return getPermissionManager().hasDirectPermissionByBL_ID(%permission, %this.bl_id);
}

function GameConnection::setDirectPermission(%this, %permission, %val) {
    return getPermissionManager().setDirectPermissionByBL_ID(%permission, %this.bl_id, %val);
}

function GameConnection::hasPermission(%this, %permission) {
    %perm = getPermissionManager().getPermission(%permission);
    if (!isObject(%perm)) {
        error("Permission" SPC %permission SPC "does not exist.");
        return false;
    }

    if ((%direct = %this.hasDirectPermission(%permission)) != 0) {
        return %direct > 0;
    }

    %accepted = %this.getRole().hasPermission(%permission);
    if (%accepted == 0)
        %accepted = %this.getAdminLevel() >= %perm.defaultAdminLevel;
    return %accepted > 0;
}

package PermissionsNameCache {
    function GameConnection::autoAdminCheck(%this) {
        getPermissionManager().getNameCache().add(%this.bl_id, %this.name);
        return parent::autoAdminCheck(%this);
    }
}; activatePackage(PermissionsNameCache);