function connectingGuiButtonPos()
{
	connectingGui.getObject(0).extent = "359 300";
	connectingGui.getObject(0).getObject(1).position = "14 249";
	connectingGui.getObject(0).getObject(2).position = "254 249";
	connectingGui.getObject(0).getObject(3).position = "142 254";
}


if(!isObject($retryButton))
{

$retryButton = new GuiBitmapButtonCtrl() 
{
         profile = "BlockButtonProfile";
         horizSizing = "center";
         vertSizing = "top";
         position = "254 167";
         extent = "91 38";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         command = "ConnectingGui::retry();";
         text = "Retry";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "base/client/ui/button2";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "0";
         mColor = "255 255 255 255";
};

connectingGui.getObject(0).add($retryButton);

}

if(!isObject($retryCheckbox))
{

$retryCheckbox = new GuiCheckboxCtrl()
{
	position = "142 171";
	extent = "69 30";
	minextent = "8 2";
	visible = true;
	enabled = true;
	clipToParent = true;
	text = "Auto Retry";
	buttonType = "ToggleButton";
	profile = "GuiCheckBoxProfile";
	horizSizing = "right";
	vertSizing = "bottom";
	command = "checkIfCancelConnect();";
};

connectingGui.getObject(0).add($retryCheckbox);

}

function checkIfCancelConnect()
{
	if($retryCheckbox.getValue() != true)
		cancel($retryConnect);
}

function ConnectingGui::retry()
{
	connecting_text.setText("");
	JoinServerGui.schedule(1000,join);
}

package autoReconnectOnFullServer
{
	function connectingGui::onWake(%this)
	{
		parent::onWake(%this);
		connectingGuiButtonPos();
		schedule(500,0,connectingGuiButtonPos);
	}

	function connectingGui::cancel()
	{
		$retryCheckbox.setValue(false);
		cancel($retryConnect);
		parent::cancel();
	}

	function GameConnection::onConnectRequestRejected(%this,%error,%arg)
	{
		if(%error $= "CR_SERVERFULL")
		{
			if($retryCheckbox.getValue() == true)
			{
				connecting_text.addText("\nServer full, trying again in 6 seconds.",true);
				cancel($retryconnect);
				$retryconnect = connectinggui.schedule(5000,retry);
			}
			else
				connecting_text.addText("\nServer full! Retry?",true);
		}
		else
			parent::onConnectRequestRejected(%this,%error,%arg);
	}

	function GameConnection::onConnectionAccepted(%this,%arg)
	{
		$retryCheckbox.setValue(false);
		cancel($retryConnect);
		return parent::onConnectionAccepted(%this,%arg);
	}
};
activatepackage(autoReconnectOnFullServer);
