Exec("./Player_Tactical.cs");
if($AddOn__Server_VignetteDamage == 1)
{
	deactivatePackage("vignetteDamagePackage");
	warn("Sorry Server_VignetteDamage is not compatible with Tactical Player");
}
