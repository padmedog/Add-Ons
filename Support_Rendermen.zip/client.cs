// INFOMANIAC //
RTB_addInfoTip("Rendermen can't move while you're looking at them. Try to keep them in your sight!","If you're seeing this, something's wrong.","Rendermen");
RTB_addInfoTip("Don't be scared of Rendermen. They're only creepy AI, right?","If you're seeing this, something's wrong.","Rendermen");
RTB_addInfoTip("Rendermen can't go near Anti-Renderman shrines. Use this to your advantage!","If you're seeing this, something's wrong.","Rendermen");
RTB_addInfoTip("It's best not to travel in groups when rendermen are nearby - if you're not careful, he could easily take all of you out!","If you're seeing this, something's wrong.","Rendermen");
RTB_addInfoTip("Don't look at Rendermen for too long - if you start hearing a high pitched sound, you're close to death.","If you're seeing this, something's wrong.","Rendermen");
RTB_addInfoTip("If you hear laughter or breathing behind you, do not investigate it!","If you're seeing this, something's wrong.","Rendermen");