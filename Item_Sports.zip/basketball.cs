//basketball.cs contains all functions related to the basketball


//Utilities 
function basketballPass(%obj)
{
	// there's still some remnants of an earlier script here, where you charged the ball with a meter
	%power = 20;//30;

	// not used?
	%playerVel = getWords(%obj.getVelocity(),0,1) SPC getWord(%obj.getVelocity(),2)/2;
	
	// make it a strong throw and add in some lift so it's easier to aim
	%vel =  vectorAdd( vectorScale( %obj.getEyeVector(), %power ), "0 0 4");

	%dataBlock = basketballProjectile;
	
	%p = %obj.spawnBall( %dataBlock, %vel );

	%obj.unMountImage(0);

	%obj.playThread(2,root);
	%obj.playThread(1,root);
	%obj.playThread(3,activate2);
}

// basketball steal functions
function stealBasketballChance( %target, %obj )
{	
	// kind of confusing looking, but we're just making sure we have something mounted on our player, and that it's one of the basketball images
	if( isObject( %target.getMountedImage(0) ) && %target.getMountedImage( 0 ).isBasketball ) // ( %target.getMountedImage(0).getName() $= "basketballImage" || %target.getMountedImage(0).getName() $= "basketballShootImage") )
	{
		// set the last time we tried to steal a ball, this is to prevent accidental steals from onBallCollision
		%obj.lastBasketballStealTime = getSimTime();
			
		// echo("stealing attempt");
		if( !getRandom(0,5) )
		{
			serverPlay3D( impact1ASound, %target.getEyePoint() );
			// get random vector
			// %rVec = sGetRandomFloat(0,10,1) SPC sGetRandomFloat(0,10,1) SPC sGetRandomFloat(0,10,1);
			
			// again playerVel here but not being used, what was the point of it?
			// %playerVel = getWords(%target.getVelocity(),0,1) SPC getWord(%target.getVelocity(),2)/2;
			
			// %vel =  vectorAdd( vectorScale( %rVec, getRandom( 2, 4) ), "0 0 4" );
			
			// let's try something new, first let's get our direction
			%fVec = %target.getForwardVector();
			%sVec = vectorScale( %fVec, 2 );
			
			%vec = vectorAdd( %sVec, sGetRandomFloat(5,10,1) SPC sGetRandomFloat(5,10,1) SPC 4 );
			
			// get the player velocity, make sure z velocity isn't too high divide that by 2
			%playerVel = getWords( %target.getVelocity(), 0, 1 ) SPC getWord( %target.getVelocity(), 2 )/2;
			
			%vel = vectorAdd( %playerVel, %vec );
			
			%dataBlock = basketballProjectile;
			
			%p = %target.spawnBall( %dataBlock, %vel );
	
			%target.unMountImage(0);
			
			%target.sbTimeout = getSimTime()+1000;
			
			%target.playThread(2,root);
			%target.playThread(1,root);
			%target.playThread(3,activate2);
		}
	}
}

// overall i think this needs to be made easier for the client
function stealBasketball(%obj)
{
	// check if we have an image mounted before we go
	if( isObject( %obj.getMountedImage( 0 ) ) )
		return;
	
	%type = $TypeMasks::PlayerObjectType;
	%pos = %obj.getEyePoint();
	%vec = vectorScale( %obj.getEyeVector(), 5 );
	%end = vectorAdd( %pos, %vec );

	%target = containerRayCast(%pos, %end, %type, %obj);
	
	// not sure if this check works 100%, should do this a better way or recheck it
	if( ( %col = getWord(%target,0) ) )
	{
		// if within if within if, this is bad form
		if( sportIsInSameMinigame( %obj, %col ) )
		{
			stealBasketballChance( %col, %obj );
		}
	}
}

function player::isGroundedSport(%obj)
{
	// need to figure out what the new ground planes typemask is
	%type = $TypeMasks::FxBrickObjectType |  $TypeMasks::TerrainObjectType ;
	%pos = vectorAdd( %obj.getPosition(), "0 0 0.1" );
	%end = vectorAdd(%pos, "0 0 -0.5");

	%target = containerRayCast(%pos, %end, %type, %obj);
	
	if( ( %targ = getWord(%target,0) ) )
	{
		return true;
	}
	return false;
}

//Datablocks

//Item only for testing will be removed later
datablock ItemData(basketballItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./basketball.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Ball Basketball";
	// iconName = "./icon_gun";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	isSportBall = 1;
	image = basketballImage;
	canDrop = true;
};

// this is called when someone collides with us while we have a ball, kind of confusing
function basketballItem::onBallCollision( %this, %obj, %col )
{			
	// if player is dead return
	if( %col.isDisabled() )
		return;
		
	// check if our attacker has something equipped, if so just return
	if( isObject( %col.getMountedImage( 0 ) ) )
		return;
		
	// we've been hit so toss the ball, check if we're attempting to steal first
	if( %col.lastBasketballStealTime+5000 > getSimTime() )
		stealBasketballChance( %obj, %col );
}

//Item onuse
function basketballItem::onUse(%this,%obj, %a)
{
	%obj.mountImage(basketballImage,0);
}

//Used when the player uses a basketball in a non jetting datablock
//Locks the player down so he can only jump
datablock PlayerData(BallShootPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxBackwardCrouchSpeed = 0;
	maxForwardCrouchSpeed = 0;
	maxSideSpeed = 0;
	maxSideCrouchSpeed = 0;
	maxStepHeight = 0;
    maxUnderwaterSideSpeed = 0;
	maxUnderwaterForwardSpeed = 0;
	maxUnderwaterBackwardSpeed = 0;

	uiName = "";
	showEnergyBar = false;
};

//Basketball bounce sound
datablock AudioProfile(basketballBounceSound)
{
   filename    = "./ballBasketBounce.wav";
   description = AudioClose3d;
   preload = true;
};

//Basketball projectile
datablock ProjectileData(basketballProjectile)
{
	sportBallImage = "basketballImage";
	projectileShapeName = "./basketball.dts";
	explosion           = "";
	bounceExplosion     = "";
	particleEmitter     = ballTrailEmitter;
	explodeOnDeath = true;

	brickExplosionRadius = 0;
	brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
	brickExplosionForce  = 0;             
	brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

	sound = "";

	muzzleVelocity      = 15;
	velInheritFactor    = 1.0;

	armingDelay         = 10000;
	lifetime            = 10000;
	fadeDelay           = 9500;
	bounceElasticity    = 0.80;
	bounceFriction      = 0.3;
	isBallistic         = true;
	gravityMod          = 1;
   ballRadius          = 0.3;

	hasLight    = false;

	uiName = "Ball Basketball"; 
};

// add spin to the basketball
function basketBallAddSpin( %obj, %normal )
{
	%vel = %obj.getVelocity();// vectorAdd(%obj.getVelocity(), "0 0 -5");
	// %vel = getWords( %vel, 0, 1 ) SPC -5;
	
	%xNorm = -mAbs( mCeil( getWord( %normal, 0 ) ) );
	%yNorm = -mAbs( mCeil( getWord( %normal, 1 ) ) );
	
	if( %xNorm == 0 )
		%xNorm = 1;
	if( %yNorm == 0 )
		%yNorm = 1;
	
	%xVel = ( getWord( %vel, 0 ) * %xNorm );
	%yVel = ( getWord( %vel, 1 ) * %yNorm );
	
	%vel = %xVel SPC %yVel SPC -3;
	
	%pos = %obj.getTransform();
	%source = %obj.sourceObject;
	%obj.delete();
	
	%p = spawnBall( %pos, basketballProjectile, %vel, %source, 1 );
	schedule( 100, 0, delayedVelEcho, %p );
	
	%p.hasSpin= 1;
	%spun = 1;
}

//Projectile on collision
function basketballProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	//Play bounce sound and check that we haven't played it too recently
	%obj.playSportBallSound( basketballBounceSound );
	
	// do onBallHit event, only call this on bricks obviously
	if( %col.getType() & $TypeMasks::FxBrickObjectType )
		%col.onBallHit( %obj.sourceObject, %obj );
		
	// if( %obj.ballCreationTime+50 > getSimTime() )
	// {
		// return;
	// }

	//Pass check
	if( passBallCheck(%obj,%col) )
		return;

	// %speed = vectorLen( %obj.getVelocity() );

	// this has been made obsolete with further tweaking of the basketball physics
	// Add "spin", makes it so it angles more like a basketball would in real life
	// to clarify on this, so when the ball hits the backboard the ball goes more downward
	// %zVel = getWord(%obj.getVelocity(),2);
	// %speed = getWords( %speed, 0, 1);
	// %zNorm = getWord(%normal,2);
	
	// if( isObject( %obj ) && !%obj.hasSpin && %zVel <= -0.25 && %zVel >= -5 && %speed > 2 && %zNorm != 1 && %zNorm != -1)
	// {
		// basketBallAddSpin( %obj, %normal );
	// }

	// %obj.lVelocity = %obj.getVelocity();
	parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);

}

//The image used for ball handling and dribbling
datablock ShapeBaseImageData(basketballImage)
{
	isBasketball = 1;
	isSportBall = 1;
	// Basic Item properties
	shapeFile = "./basketball.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 8;
	offset = "0.5 0.8 1.3";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	correctMuzzleVector = true;

	// Add the WeaponImage namespace as a parent, WeaponImage namespace
	// provides some hooks into the inventory system.
	className = "WeaponImage";

	// Projectile && Ammo.
	// balls need to know about their item in image, for certain methods
	item = basketballItem;
	ammo = " ";
	projectile = basketballProjectile;
	projectileType = Projectile;

	//melee particles shoot from eye node for consistancy
	melee = false;
	//raise your arm up or not
	armReady = false;

	doColorShift = false;
	colorShiftColor = gunItem.colorShiftColor;//"0.400 0.196 0 1.000";

	//casing = " ";

	// Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "dribble";
	// stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateSequence[1]		= "dribble";
	//stateScript[1]                  = "onCharge";
	stateAllowImageChange[1]	= true;

	stateName[2]			= "Fire";
	stateTransitionOnTimeout[2]	= "Ready";
	stateTimeoutValue[2]		= 0.01;
	stateFire[2]			= true;
	stateSequence[2]		= "fire";
	stateScript[2]			= "onFire";
	stateWaitForTimeout[2]		= true;
	stateAllowImageChange[2]	= false;

};

//Dribble states
function basketballImage::onMount(%this,%obj)
{
	%obj.hasSportBall = 1;
	// if(%obj.getDataBlock().isTurboSportPlayer)
		// delaySportPlayerCheck(%obj);
	
	// jet player check if we start out in air, this is to prevent the dribbling animation from playing too long in the air
	if( %obj.getDataBlock().canJet && getWord( %obj.getVelocity(), 2 ) != 0 )
	{
		%obj.mountImage(basketballShootImage,0);
		return;
	}

	%obj.playThread(2,armAttack);
	%obj.playThread(1,armReadyRight);
	parent::onMount(%this,%obj);
}
function basketballImage::onUnMount(%this,%obj)
{
	%obj.hasSportBall = 0;
	%obj.playThread(2,root);
	fixArmReady(%obj);
	//%obj.playThread(1,root);
}
function basketballImage::onFire(%this,%obj,%slot)
{
	// echo( "called" SPC %obj.sbShootTimeout );
	// echo( %obj.sbShootTimeout > getSimTime() );
	// this actually makes no sense, if we were able to pick up a ball how do we have sbTimeout active?
	// if( %obj.sbShootTimeout > getSimTime() )
		// return;
		
	// check if we just picked this up by clicking
	// if( %obj.sbPickupTrigger )
	// {
		// return;
	// }	
	
	%obj.mountImage(basketballShootImage,0);
}

function basketballImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	%canJet = %obj.getDataBlock().canJet;

	if( (%trigger == 2 || %trigger == 3 || %trigger == 4) && %val == 1)
	{
		%obj.mountImage(basketballShootImage,0);
		return;
	}

	if(%trigger == 4 && %val == 1 && !%canJet)
		basketballPass(%obj);
}

//The image used for shooting, can't move while this is equiped
datablock ShapeBaseImageData(basketballShootImage)
{
	isBasketball = 1;
	isSportBall = 1;
	// Basic Item properties
	shapeFile = "./basketball.dts";
	emap = true;

	mountPoint = 0;
	offset = "-0.5 0 -0";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	correctMuzzleVector = true;

	className = "WeaponImage";

	// Projectile && Ammo.
	// balls need to know about their item in image, for certain methods
	item = basketballItem;
	ammo = " ";
	projectile = basketballProjectile;
	projectileType = Projectile;

	//melee particles shoot from eye node for consistancy
	melee = false;
	//raise your arm up or not
	armReady = true;

	doColorShift = false;
	colorShiftColor = gunItem.colorShiftColor;//"0.400 0.196 0 1.000";

	//casing = " ";

	// Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.01;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "root";
	//stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	//stateScript[1]                  = "onCharge";
	stateAllowImageChange[1]	= true;

	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.1;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "Fire";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;

	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "Ready";
	stateTimeoutValue[3]		= 0.3;
	stateWaitForTimeout[3]		= true;
	stateScript[3]			= "onAbortCharge";
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateAllowImageChange[4]	= false;

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.5;
	stateFire[5]			= true;
	stateSequence[5]		= "fire";
	// stateSound[5]				= spearFireSound;
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;

};


//Image states for shooting 
function basketballShootImage::onMount(%this,%obj)
{	
	%obj.hasSportBall = 1;
	%dataBlock = %obj.getDataBlock();

	if( !%dataBlock.canJet && %dataBlock.shapeFile $= "base/data/shapes/player/m.dts" )
	{
		%obj.sportBallOriginalDataBlock = %obj.getDataBlock();
		%obj.setDataBlock(BallShootPlayer);
	}
	%obj.playThread(3,root);
	%obj.playThread(1,armReadyBoth);
	parent::onMount(%this,%obj);
}

function basketballShootImage::onUnMount(%this,%obj)
{
	%obj.hasSportBall = 0;
	%dataBlock = %obj.getDataBlock();

	if( !%dataBlock.canJet && %dataBlock.shapeFile $= "base/data/shapes/player/m.dts" )
		%obj.setDataBlock(%obj.sportBallOriginalDataBlock);

	%obj.playThread(2,root);
}
function basketballShootImage::onCharge(%this,%obj,%slot)
{
	%obj.sportBallCharge = getSimTime();
}

function basketballLobCheck(%obj)
{
	%type = $TypeMasks::FxBrickObjectType | $TypeMasks::PlayerObjectType;
	%pos = %obj.getEyePoint();
	%vec = vectorScale(%obj.getEyeVector(),20);
	%end = vectorAdd(%pos, %vec);

	%target = containerRayCast(%pos, %end, %type, %obj);
	
	if( ( %targetID = getWord(%target,0) ) )
	{
		%tPos = getWords(%target,1,3);
		%dist = vectorDist(%pos,%tPos);
	
		if( %targetID.getType() & $TypeMasks::PlayerObjectType )
			%dist = %dist SPC 1;
		
		return %dist;
	}
}

function basketballShootImage::onFire(%this,%obj,%slot)
{
	// check if we just picked this up by clicking
	if( %obj.sbPickupTrigger )
		return;

	// check if we're past the shoot timeout
	if( %obj.sbShootTimeout > getSimTime() )
		return;
	
	//Basketball autoaim
	//Check if we're grounded, this changes some factors a bit
	%isGrounded = %obj.isGroundedSport();
	
	//Get the distance so we can caluclate how fast we have to shoot, and how much z velocity we have to add
	%dist = basketballLobCheck(%obj);
	
	// find out if there is a player in our direct view
	%isPlayer = getWord( %dist, 1 );
	
	%dist = getWord( %dist, 0 );
	
	if(%dist > 11)
		%dist = 11;
		
	//Shot from freethrow line power = 7, lob 7.5
	if(%dist)
	{
		%scale = (%dist/11)+0.1;
		if(%scale > 1)
			%scale = 1;

		%zScale = %dist/11/2;
		if(%zScale > 1 || %zScale <= 0)
			%zScale = 1;
	}
	else
	{
		%scale = 1;
		%zScale = 1;
	}

	%power = 7*%scale;
	
	//If we're in the air we should scale down our velocity depending on how close we are to the basket
	if(!%isGrounded)
		%playerVel = vectorScale(getWords(%obj.getVelocity(),0,1) SPC getWord(%obj.getVelocity(),2)/2,%zScale);
	else
		%playerVel = %obj.getVelocity();
	
	%speed = vectorLen(%playerVel);

	if(!%isGrounded && %speed > 0 && %dist != 0 && %dist < 10)
		%zAdd = 5;
	else
		%zAdd = 7.5;
	
	// if it's a player let's do a pass lob, as long as we're grounded that is
	if( %isPlayer && %isGrounded )
	{
		%zAdd = 2;
		%power = 15;
	}
		
	%fVel =  vectorAdd( vectorScale(%obj.getMuzzleVector(0),%power) , "0 0" SPC %zAdd);
	%vel = vectorAdd(%fVel, %playerVel);
	
	// spawn the ball
	%dataBlock = basketballProjectile;
	%p = %obj.spawnBall( %dataBlock, %vel );
	
	%obj.unMountImage(0);

	%obj.playThread(2,root);
	%obj.playThread(1,root);
	%obj.playThread(3,activate2);
}
function basketballShootImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	%canJet = %obj.getDataBlock().canJet;
	if(%trigger == 4 && %val == 0 && !%canJet)
		basketballPass(%obj);
}
