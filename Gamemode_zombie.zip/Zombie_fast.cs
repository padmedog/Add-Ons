 datablock PlayerData(RotFastZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;

	maxDamage = 100;
	runforce = 100 * 90;
	maxForwardSpeed = 16;
	maxBackwardSpeed = 13;
	maxSideSpeed = 13;
	attackpower = 5;
	jumpsound = "ZombieJumpSound";
	
	BrickDestroyMaxVolume = 100;
	BrickMaxJumpHeight = 25;
	uiName = "Zombie Fast";
	rideable = true;
	canRide = true;
	BrickKillRadius = 1;
	skinColor = "0.784 0.922 0.490 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
};
function RotFastZombie::ondisabled(%this,%obj)
{
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotFastZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotFastZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotFastZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotFastZombie::onAdd(%this,%obj)
{
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
}