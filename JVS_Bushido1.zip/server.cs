%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_Disabled)
{
	error("JVS_Bushido1: JVS_Content is disabled and is required for this Add-On to work.");
}
else if(%error == $Error::AddOn_NotFound)
{
	error("JVS_Bushido1: JVS_Content is missing and is required for this Add-On to work.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_Bushido1/types/Door_HangarBushido.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_Bushido1/types/Door_BlastBushido.cs");
}
