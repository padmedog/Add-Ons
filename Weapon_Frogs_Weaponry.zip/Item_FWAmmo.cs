   datablock AudioProfile(FWammogetSound)
   {
      filename = "./FWammoget.wav";
      description = AudioClosest3d;
      preload = false;
   };

datablock ItemData(FWPilestaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammoPileB.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo Pile B";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 4*2;
};

datablock ItemData(FWHeavyPilestaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammoHeavyCache.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo Heavy Cache";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 4*2;
};

datablock ItemData(BlastRoundsStaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./AMMO_BlastRounds.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, Blast Rounds";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 8*1;
};

function BlastRoundsStaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}
   
datablock ItemData(TwentyOneGaugeStaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./AMMO_21gauge.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, 21 Gauge";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 6*2;
};

function TwentyOneGaugeStaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

datablock ItemData(ImpactGrenadeStaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./AMMO_ImpactGrenade.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, Impact Grenade";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 4*1;
};

function ImpactGrenadeStaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

datablock ItemData(fortyfivecaliberstaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_45caliber.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo,.45 Caliber";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 8*3;
};

function fortyfivecaliberstaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

datablock ItemData(SlugStaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./AMMO_Slugs.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, Slug";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 6*1;
};

function SlugStaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

package FWAmmoPileStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "FwPilestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
   %obj.client.quantity["21Gauge"] = 72;
   %obj.client.quantity["45Caliber"] = 192;
   %obj.client.quantity["ImpactGrenade"] = 12;
   %obj.client.quantity["Slugs"] = 30;   
   %obj.client.quantity["BlastRounds"] = 32;

	serverPlay3D(FWammogetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(FwAmmoPileStaticPackage);

package FWHeavyAmmoPileStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "FWHeavyPilestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
   %obj.client.quantity["Payload"] = 1;
   %obj.client.quantity["StrikeRocket"] = 6;
   %obj.client.quantity["50Cal"] = 200;   
	serverPlay3D(FWammogetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(FWHeavyAmmoPileStaticPackage);

package FWAmmoStaticPackage1
{
function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "twentyonegaugestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
		%obj.client.quantity["21Gauge"] += %col.ammocount;
		if(%obj.client.quantity["21Gauge"] > 72)
			{
			%obj.client.quantity["21Gauge"] = 72;
		}
		serverPlay3D(FWammogetSound,%obj.getPosition());

		if(isObject(%col.spawnbrick))
			{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
			}
		%this.onPickup(%obj, %player);
		return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};

activatePackage(FWAmmoStaticPackage1);

package FWAmmoStaticPackage2
{
function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "fortyfivecaliberstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
		%obj.client.quantity["45caliber"] += %col.ammocount;
		if(%obj.client.quantity["45caliber"] > 192)
			{
			%obj.client.quantity["45caliber"] = 192;
		}
		serverPlay3D(FWammogetSound,%obj.getPosition());

		if(isObject(%col.spawnbrick))
			{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
			}
		%this.onPickup(%obj, %player);
		return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(FWAmmoStaticPackage2);

package FWAmmoStaticPackage3
{
function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "ImpactGrenadestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
		%obj.client.quantity["ImpactGrenade"] += %col.ammocount;
		if(%obj.client.quantity["ImpactGrenade"] > 12)
			{
			%obj.client.quantity["ImpactGrenade"] = 12;
		}
		serverPlay3D(FWammogetSound,%obj.getPosition());

		if(isObject(%col.spawnbrick))
			{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
			}
		%this.onPickup(%obj, %player);
		return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(FWAmmoStaticPackage3);

package FWAmmoStaticPackage4
{
function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "SlugstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
		%obj.client.quantity["Slugs"] += %col.ammocount;
		if(%obj.client.quantity["Slugs"] > 30)
			{
			%obj.client.quantity["Slugs"] = 30;
		}
		serverPlay3D(FWammogetSound,%obj.getPosition());

		if(isObject(%col.spawnbrick))
			{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
			}
		%this.onPickup(%obj, %player);
		return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};

activatePackage(FWAmmoStaticPackage4);

package FWAmmoStaticPackage5
{
function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "BlastRoundsstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
		%obj.client.quantity["BlastRounds"] += %col.ammocount;
		if(%obj.client.quantity["BlastRounds"] > 32)
			{
			%obj.client.quantity["BlastRounds"] = 32;
		}
		serverPlay3D(FWammogetSound,%obj.getPosition());

		if(isObject(%col.spawnbrick))
			{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
			}
		%this.onPickup(%obj, %player);
		return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};

activatePackage(FWAmmoStaticPackage5);

package FWAmmoDropPackage
{
	function gameConnection::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA)
	{
		%pos = %client.player.getPosition();
		%posX = getWord(%pos,0);
		%posY = getWord(%pos,1);
		%posZ = getWord(%pos,2) + 1;

		%vec = %client.player.getVelocity();
		%vecX = getWord(%vec,0);
		%vecY = getWord(%vec,1);
		%vecZ = getWord(%vec,2);

		if(%client.quantity["21Gauge"] > 0 && $Pref::Server::FW1Drop == 1)
		{
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = TwentyOneGaugeStaticItem;
				canPickup = true;
				ammocount = %client.quantity["21Gauge"];
				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);
			MissionCleanup.add(%i);
			%i.setShapeName(%i.ammocount);
		}
		if(%client.quantity["45Caliber"] > 0 && $Pref::Server::FW2Drop == 1)
		{
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = fortyfivecaliberstaticItem;
				canPickup = true;
				ammocount = %client.quantity["45Caliber"];
				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);
			MissionCleanup.add(%i);
			%i.setShapeName(%i.ammocount);
		}
                  if(%client.quantity["ImpactGrenade"] > 0 && $Pref::Server::FW5Drop == 1)
		{
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = ImpactGrenadeStaticItem;
				canPickup = true;
				ammocount = %client.quantity["ImpactGrenade"];
				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);
			MissionCleanup.add(%i);
			%i.setShapeName(%i.ammocount);
		}
	             if(%client.quantity["Slugs"] > 0 && $Pref::Server::FW6Drop == 1)
		{
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = SlugStaticItem;
				canPickup = true;
				ammocount = %client.quantity["Slugs"];
				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);
			MissionCleanup.add(%i);
			%i.setShapeName(%i.ammocount);
		}
			if(%client.quantity["BlastRounds"] > 0 && $Pref::Server::FW7Drop == 1)
		{
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = BlastRoundsstaticItem;
				canPickup = true;
				ammocount = %client.quantity["BlastRounds"];
				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);
			MissionCleanup.add(%i);
			%i.setShapeName(%i.ammocount);
		}
		parent::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA);
	}
};
activatePackage(FWAmmoDropPackage);