$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "I gotta great idea... Letsh... drink on it...";
$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "You wanna gebba hubbah *snort* huuuh...";
$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "You know you know you can't... shtop THIS train!...";
$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "No no man... I'm good... No really, I'm guuuhhh...";
$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "Eh he hee, heeeh hee... I got the gigglesh...";
$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "Shtop the ride dad, I wanna get off...";
$Alcohol::DrunkMsg[$Alcohol::DrunkMsgCount++] = "Oh man... When did they paint THAT thing blue?";

$Alcohol::RandomWord[$Alcohol::RandomWordCount++] = "*burp*";
$Alcohol::RandomWord[$Alcohol::RandomWordCount++] = "guuuh";
$Alcohol::RandomWord[$Alcohol::RandomWordCount++] = "ehheee";
$Alcohol::RandomWord[$Alcohol::RandomWordCount++] = "heuur";

$Alcohol::Level[$Alcocohal::LevelCount++] = 0.08;
$Alcohol::Level[$Alcocohal::LevelCount++] = 0.3;
$Alcohol::Level[$Alcocohal::LevelCount++] = 0.6;

$Alcohol::TickTime = 1000 * 30;
$Alcohol::SoberAmount = 0.1;

if(!$DamageType::Alcohol)
{
	addDamageType("Alcohol", '%1 Died from alcohol poisoning.', '%2 Killed %1 with alcohol poisoning.', 1, 1);
}

function player::increaseAlcoholLevel(%player, %num)
{
	if(%num <= 0 || !isObject(%client = %player.client))
	{
		return;
	}

	%flash = %player.alcoholLevel * 1.75;

	%player.setDamageFlash(%flash);
	%player.setWhiteOut(%flash);

	%player.alcoholLevel += %num;

	if(%player.alcoholLevel < $Alcohol::Level[2])
	{
		%hp = mClampF(%num * 500, 5, 30);

		%player.addHealth(%hp);
		%player.emote(HealImage, 1);
	}

	else if(%player.alcoholLevel >= $Alcohol::Level[2])
	{
		%hp = mClampF(%num * 250, 5, 15);

		%player.damage(%player, "0 0 0", %hp, $DamageType::Alcohol);
		%player.emote(HurtImage, 1);
	}

	%player.alcoholTick(1);
}

function player::alcoholTick(%player, %first)
{
	cancel(%player.alcoholTick);

	if(%player.alcoholLevel <= 0 || !isObject(%client = %player.client))
	{
		return;
	}

	if(!%first)
	{
		%player.alcoholLevel -= $Alcohol::SoberAmount;
	}

	if(%player.alcoholLevel >= $Alcohol::Level[1])
	{
		if(getRandom(1, 3) == 1)
		{
			%client.alcoholChatMsg($Alcohol::DrunkMsg[getRandom(1, $Alcohol::DrunkMsgCount)]);
		}
	}

	if(%player.alcoholLevel >= $Alcohol::Level[2] && %player.alcoholLevel < $Alcohol::Level[3])
	{
		if(getRandom(1, 3) == 1)
		{
			tumble(%player, 10000);

			%flash = %player.alcoholLevel * 1.75;

			%player.setDamageFlash(%flash);
			%player.setWhiteOut(%flash);
		}
	}

	if(%player.alcoholLevel >= $Alcohol::Level[3])
	{
		%player.damage(%player, "0 0 0", %player.getDataBlock().maxDamage - %player.getDamageLevel(), $DamageType::Alcohol);
	}

	%color = "ff0000";

	if(%player.alcoholLevel < $Alcohol::Level[1])
	{
		%color = "00ff00";
	}

	commandToClient(%client, 'centerPrint', "<just:right><color:ffffff>Alcohol Level:<color:" @ %color @ ">" SPC %player.alcoholLevel @ "<color:ffffff>.", 10);

	%player.alcoholTick = %player.schedule($Alcohol::TickTime, alcoholTick, 0);
}

function gameConnection::alcoholChatMsg(%client, %msg)
{
	%msg = stripMLControlChars(trim(%msg));

	if(!strReplace(%msg, " ", "") $= "")
	{
		return;
	}

	%time = getSimTime();

	//URLs
	for(%i = 0; %i < getWordCount(%msg); %i ++)
	{
		%word = getWord(%msg, %i);
		%pos = strPos(%word, "://") + 3;
		%pro = getSubStr(%word, 0, %pos);
		%url = getSubStr(%word, %pos, strLen(%word));

		if((%pro $= "http://" || %pro $= "https://") && strPos(%url, ":") == -1)
		{
			%word = "<sPush><a:" @ %url @ ">" @ %url @ "</a><sPop>";
			%msg = setWord(%msg, %i, %word);
		}
	}

	//MESSAGE FORMAT
	%all  = '\c7%1\c3%2\c7%3\c6: %4';
	%name = %client.getPlayerName();
	%pre  = %client.clanPrefix;
	%suf  = %client.clanSuffix;

	commandToAll('chatMessage', %client, '', '', %all, %pre, %name, %suf, %msg);

	echo(%client.getSimpleName() @ ":" SPC %msg);

	if(isObject(%client.player))
	{
		%client.player.playThread(3, "talk");
		%client.player.schedule(strLen(%msg) * 50, playThread, 3, "root");
	}
}

package Support_Alcohol
{
	function observer::onTrigger(%data, %cam, %slot, %bool)
	{
		if(%slot == 0 && %bool && isObject(%client = %cam.getControllingClient()))
		{
			if(isObject(%player = %client.player))
			{
				if(isObject(%vehicle = %player.getObjectMount()))
				{
					if(isObject(%data = %vehicle.getDataBlock()))
					{
						if(%data.getName() $= "deathVehicle")
						{
							return;
						}
					}
				}
			}
		}

		parent::onTrigger(%data, %cam, %slot, %bool);
	}

	function serverCmdMessageSent(%client, %msg)
	{
		if(isObject(%player = %client.player))
		{
			if(%player.alcoholLevel >= $Alcohol::Level[1])
			{
				for(%i = 1; %i < $Alcohol::RandomWordCount + 1; %i++)
				{
					if(getRandom(1, 3) == 1)
					{
						%random = getRandom(0, getWordCount(%msg));

						%msg = getWords(%msg, 0, %random) SPC $Alcohol::RandomWord[%i] SPC getWords(%msg, %random + 1, getWordCount(%msg));
					}
				}
			}
		}

		parent::serverCmdMessageSent(%client, %msg);
	}
};
activatePackage(Support_Alcohol);