datablock fxDTSBrickData (BrickSharkBot_HoleSpawnData)
{
	brickFile = "Add-ons/Bot_Hole/8xspawn.blb";
	category = "Special";
	subCategory = "Holes";
	uiName = "Shark Hole";
	iconName = "Add-Ons/Bot_Shark/icon_shark";

	bricktype = 2;
	cancover = 0;
	orientationfix = 1;
	indestructable = 1;

	isBotHole = 1;
	holeBot = "SharkHoleBot";
};

// when the shark brick is initially planted hide it, as most of the time we don't want it to exist since we're in the water
function BrickSharkBot_HoleSpawnData::onPlant( %this, %obj )
{
	%obj.setRendering(0);
	%obj.setColliding(0);
	%obj.setRaycasting(0);
}

//shark melee icon
AddDamageType("SharkHoleBite",   '<bitmap:Add-Ons/Bot_Shark/CI_Shark> %1',    '%2 <bitmap:Add-Ons/Bot_Shark/CI_Shark> %1',0.5,1);

datablock PlayerData(SharkHoleBot : PlayerStandardArmor)
{
	shapeFile = "./shark.dts";
	uiName = "";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;
	maxWeapons = 0;
	maxTools = 0;

	rideable = false;
	canRide = false;

	mass = 120;
	drag = 0.02;//0.02
	density = 0.98;//0.6
	runSurfaceAngle = 1;
	jumpSurfaceAngle = 0;
	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxBackwardCrouchSpeed = 0;
	maxForwardCrouchSpeed = 0;
	maxSideSpeed = 0;
	maxSideCrouchSpeed = 0;
	maxStepHeight = 0;
    maxUnderwaterSideSpeed = 0;
	maxUnderwaterForwardSpeed = 0;
	maxUnderwaterBackwardSpeed = 0;
	showEnergyBar = false;

	jumpForce = 400;

	minJumpSpeed = 0;
	maxJumpSpeed = 1;

	boundingBox			= vectorScale("3.5 3.5 1.8", 4); //"2.5 2.5 2.4";
	crouchBoundingBox	= vectorScale("3.5 3.5 1.8", 4); //"2.5 2.5 2.4";
	proneBoundingBox		= vectorScale("3.5 3.5 1.8", 4); //"2.5 2.5 2.4";

	maxdamage = 300;//Bot Health
	jumpSound = "";//Removed due to bots jumping a lot
	
	//Hole Attributes
	isHoleBot = 1;

	//Spawning option
	hSpawnTooClose = 0;//Doesn't spawn when player is too close and can see it
	  hSpawnTCRange = 8;//above range, set in brick units
	hSpawnClose = 0;//Only spawn when close to a player, can be used with above function as long as hSCRange is higher than hSpawnTCRange
	  hSpawnCRange = 32;//above range, set in brick units

	hType = Shark; //Enemy,Friendly, Neutral
	  hNeutralAttackChance = 80;
	//can have unique types, nazis will attack zombies but nazis will not attack other bots labeled nazi
	hName = "Shark";//cannot contain spaces
	hTickRate = 3000;
	
	//Wander Options
	hWander = 1;//Enables random walking
	  hSmoothWander = 1;//This is in addition to regular wander, makes them walk a bit longer, and a bit smoother
	  hReturnToSpawn = 1;//Returns to spawn when too far
	  hSpawnDist = 48;//Defines the distance bot can travel away from spawnbrick
	  hGridWander = 0;//Locks the bot to a grid, overwrites other settings
	
	//Searching options
	hSearch = 1;//Search for Players
	  hSearchRadius = 128;//in brick units
	  hSight = 1;//Require bot to see player before pursuing
	  hStrafe = 1;//Randomly strafe while following player
	hSearchFOV = 0;//if enabled disables normal hSearch
	  hFOVRadius = 6;//max 10
	  hHearing = 1;//If it hears a player it'll look in the direction of the sound

	  hAlertOtherBots = 1;//Alerts other bots when he sees a player, or gets attacked

	//Attack Options
	hMelee = 1;//Melee
	  hAttackDamage = 0;//Melee Damage
	  hMeleeCI = "SharkHoleBite";
	hShoot = 0;
	  hWep = "gunImage";
	  hShootTimes = 4;//Number of times the bot will shoot between each tick
	  hMaxShootRange = 256;//The range in which the bot will shoot the player
	  hAvoidCloseRange = 1;//
		hTooCloseRange = 7;//in brick units

	//Misc options
	hAvoidObstacles = 1;
	hSuperStacker = 0;//When enabled makes the bots stack a bit better, in other words, jumping on each others heads to get to a player
	hSpazJump = 0;//Makes bot jump when the user their following is higher than them

	hAFKOmeter = 1;//Determines how often the bot will wander or do other idle actions, higher it is the less often he does things

	hIdle = 1;// Enables use of idle actions, actions which are done when the bot is not doing anything else
	  hIdleAnimation = 1;//Plays random animations/emotes, sit, click, love/hate/etc
	  hIdleLookAtOthers = 1;//Randomly looks at other players/bots when not doing anything else
	    hIdleSpam = 1;//Makes them spam click and spam hammer/spraycan
	  hSpasticLook = 1;//Makes them look around their environment a bit more.
	hEmote = 1;
};

function SharkHoleBot::onAdd(%this,%obj)
{
	armor::onAdd(%this,%obj);
	%obj.hIsShark = 1;
	%color[%a++] = "0.9 0.9 0.9 1";
	%color[%a++] = "0.5 0.5 0.5 1";
	%color[%a++] = "0 0.137 0.329 1";
	%color[%a++] = "0.1 0.45 0.76 1";
	%color[%a++] = "0.2 0.2 0.2 1";

	%choice = getRandom(1,%a);
	//detect if it's a white shark, make it more aggressive
	if(%choice == 1)
	{
		%obj.hStrafe = 0;
		//useful so that I can detect it easily in other functions without having to compare color
		//Also useful if other bots want to use this information
		%obj.hIsGreatWhite = 1;
		%obj.hNeutralAttackChance = 100;
	}
	if(%choice == 2)
	{
		%obj.setDataBlock(SharkHoleBotTop);
	}
	if(%choice == 3)
	{
		%obj.setDataBlock(SharkHoleBotBottom);
	}
	%obj.setNodeColor("ALL",%color[%choice]);
	%obj.hideNode(helmet);
	%obj.hideNode(visor);
	%obj.setNodeColor("lArm","1 1 1 1");
	%obj.setNodeColor("rArm","1 1 1 1");
	
	%obj.chestColor =  %color[%choice];
	%obj.lArmColor =  "1 1 1 1";
	%obj.rArmColor =  "1 1 1 1";
	
	scheduleNoQuota(10,%obj,delaySharkCheck,%obj);

	// %obj.invulnerable = 1;
	
	// if( isObject(%obj.spawnBrick) )
	// {
		// %obj.spawnBrick.setRendering(0);
		// %obj.spawnBrick.setColliding(0);
		// %obj.spawnBrick.setRaycasting(0);
	// }
}

function SharkHoleBot::onEnterLiquid(%data, %obj, %coverage, %type)
{
	// do nothing, hack for now to prevent sharks from being auto killed by water
	%obj.hFishOutOfWater = 0;
}
function SharkHoleBotBottom::onEnterLiquid(%data, %obj, %coverage, %type)
{
	// do nothing, hack for now to prevent sharks from being auto killed by water
	%obj.hFishOutOfWater = 0;
}
function SharkHoleBotTop::onEnterLiquid(%data, %obj, %coverage, %type)
{
	// do nothing, hack for now to prevent sharks from being auto killed by water
	%obj.hFishOutOfWater = 0;
}

function delaySharkCheck(%obj)
{
	if(isObject(%obj))
	{
		if(!getRandom(0,50) || %obj.name $= "Cool Shark")
		{
			%obj.setNodeColor("helmet","0.2 0.2 0.2 1");
			%obj.setNodeColor("visor", "0.2 0.2 0.2 1");
			%obj.unHideNode(helmet);
			%obj.unHideNode(visor);
			%obj.name = "Cool Shark";
			
			%obj.hat =  "1";
			%obj.accent =  "1";
		}
	}
}
function SharkHoleBot::onNewDataBlock(%this,%obj)
{
	%color[%a++] = "0.9 0.9 0.9 1";
	%color[%a++] = "0.5 0.5 0.5 1";
	%color[%a++] = "0 0.137 0.329 1";
	%color[%a++] = "0.1 0.45 0.76 1";
	%color[%a++] = "0.2 0.2 0.2 1";

	%obj.setNodeColor("ALL",%color[getRandom(1,%a)]);
	%obj.hideNode(helmet);
	%obj.hideNode(visor);
	%obj.setNodeColor("lArm","1 1 1 1");
	%obj.setNodeColor("rArm","1 1 1 1");
}
function SharkHoleBot::onBotLoop(%this,%obj)
{
	//Check if he's in water if he is play the swim animation
	if( isObject(%obj) && !%obj.getObjectMount() && !%obj.isDisabled() )//%obj.getState !$= "Dead")
	{
		if(%obj.getWaterCoverage() && !%obj.isSwimming)
		{
			%obj.playThread(0,swim);
			%obj.isSwimming = 1;
		}
		else if( !%obj.getWaterCoverage() && %obj.isSwimming )
		{
			%obj.playThread(0,root);
			%obj.isSwimming = 0;
		}
	}
	else if(!%obj.getObjectMount())
		%obj.playThread(0,root);
	
	//Checking if he's been out of water too long
	if( !%obj.getWaterCoverage() && isObject( getMiniGameFromObject( %obj ) ) )
	{
		%obj.hFishOutOfWater++;
	}
	else
		%obj.hFishOutOfWater = 0;
	
	//he has we have to kill him :(
	if(%obj.hFishOutOfWater >= 3)
		%obj.kill();

}

function SharkHoleBot::onBotCollision( %this, %obj, %col, %normal, %speed )
{
	 if( %obj.isDisabled() )
		return;

	%canDamage = miniGameCanDamage(%obj,%col);
		
	if( isObject(%obj.hEating) || %obj.getMountedObject( 0 ) || %col.isDisabled() || %canDamage == 0 || %canDamage == -1 ) // !checkHoleBotTeams(%obj,%col) ||
		return;
		
	//Check if we can attack, then check if it's a minifig, then eat him//%col.isHoleBot &&
	%oScale = getWord(%obj.getScale(),0);
	%cScale = getWord(%col.getScale(),0);
	// if( (!getRandom(0,1)|| %obj.hIsGreatWhite) && %obj.getState() !$= "Dead" && checkHoleBotTeams(%obj,%col) && !isObject(%obj.hEating) && %col.getState() !$= "Dead" && miniGameCanDamage(%obj,%col) == 1)
	
	// if we collide with a vehicle then eject the player
	// this may cause some funky things, but it should be entertaining
	%wasEjected = 0;
	
	// %checkTeam = checkHoleBotTeams(%obj,%col);
	
	if( %col.getMountedObjectCount() && ( !getRandom( 0, 2 ) || %obj.hIsGreatWhite || ( %col.getType() & $TypeMasks::VehicleObjectType ) ) )
	{
		if( %col.hIsShark && %col.getMountedObject( 0 ).hIsShark )
			return;
	
		%col = %col.ejectRandomPlayer();
		%wasEjected = 1;
		
		if( %col.client )
			%col.client.setControlObject( %col );
	}
	
	%checkTeam = checkHoleBotTeams(%obj,%col);
	
	if( ( !getRandom(0,2)|| %obj.hIsGreatWhite || %wasEjected ) && %checkTeam )
	{
		if(  %oScale+0.5 >= %cScale && %col.getDataBlock().shapeFile $= "base/data/shapes/player/m.dts")
		{
			if(%col.getClassName() $= "Player" && %col.client)
			{
				%col.client.camera.setOrbitMode(%obj, %obj.getTransform(), 0, 10, 0, 1);
				%col.client.setControlObject(%col.client.camera);
				//hSpazzClick(%col,0,1);
			}
			%obj.stopHoleLoop();
			%obj.hRunAwayFromPlayer(%col);
			// %obj.setImageTrigger(3,1);
			%obj.setCrouching(1);
			%obj.mountObject(%col,2);
			
			%obj.hIgnore = %col;
			%obj.hEating = %col;
			%obj.hLastEatTime = getSimTime();
			
			// temporarily set the shark to invulnerable when he eats someone to avoid getting
			%obj.invulnerable = true;
			schedule( 200, %obj, eval, %obj @ ".invulnerable = false;" );

			%obj.hSharkEatDelay = scheduleNoQuota(5000,0,holeSharkKill,%obj,%col);
			return;
		}	
		if(  %oScale >= %cScale+0.5 && %col.getDataBlock().shapeFile $= "Add-Ons/Bot_Shark/shark.dts")
		{
			if(%col.getClassName() $= "Player" && %col.client)
			{
				%col.client.camera.setOrbitMode(%obj, %obj.getTransform(), 0, 10, 0, 1);
				%col.client.setControlObject(%col.client.camera);
				//hSpazzClick(%col,0,1);
			}
			%obj.stopHoleLoop();
			%obj.hRunAwayFromPlayer(%col);
			%obj.mountObject(%col,3);

			%obj.playThread(1,biteReady);
			%col.playThread(0,biteFix);
			%obj.hIgnore = %col;
			%obj.hEating = %col;
			%obj.hLastEatTime = getSimTime();
			
			%obj.invulnerable = true;
			schedule( 200, %obj, eval, %obj @ ".invulnerable = false;" );
			
			%obj.hSharkEatDelay = scheduleNoQuota(5000,0,holeSharkKill,%obj,%col);
			return;
		}
	}
	
	if( %checkTeam )
	{
		%obj.hAttackDamage = 35;
		%obj.hMeleeAttack( %col );
		%obj.hAttackDamage = 0;
	}
}

function holeSharkKill(%obj,%col)
{
	if( !isObject(%obj) || %obj.isDisabled() )
		return;
		
	// we can no longer damage the guy release him
	if( miniGameCanDamage( %obj, %col ) != 1 )
	{
		%col.disMount();
		
		if( %col.client )
			%col.client.setControlObject( %col );
		
		return;
	}
		
	if(%obj.getMountedObject(0) == %col)
	{
		if(%col.getClassName() $= "Player" )
		{
			%col.damage(%obj.hFakeProjectile, %col.getposition(), 1000, $DamageType::SharkHoleBite);
		}
		else
		{
			if(%obj.hIsInfected && getRandom(0,2))
			{
				holeZombieInfect(%obj,%col);
				%col.dismount();
				%col.playThread(0,root);
				%obj.playThread(1,root);
				%obj.hIgnore = 0;
				%obj.hEating = 0;
			}
			else
			{
				%col.kill();
				%obj.playThread(1,root);
				%obj.hEating = 0;
			}
		}
	}
	%obj.startHoleLoop();
}

function sharkHoleBot::onRemove(%this,%obj)
{
	if( isObject( (%col = %obj.hEating) ) )
	{
		%col.playThread(0,root);
		if(%col.getClassName() $= "Player" && !%col.getControllingClient())
		{
			//cancel(%col.hSpazzClick);
			if( isObject(%col.client) )
				%col.client.setControlObject(%col);
		}
	}
}

function SharkHoleBot::onBotFollow(%this,%obj,%targ)
{
	//Called when the target follows a player each tick, or is running away
}

function SharkHoleBot::onDisabled(%this,%obj,%a)
{
	if( isObject(%obj.hEating) && %obj.hEating == %obj.getMountedObject(0) )
	{
		cancel(%obj.hSharkEatDelay);
		%targ = %obj.hEating;
		
		%obj.hEating = 0;
		%targ.dismount();
		%targ.playThread(0,root);
		//%obj.playThread(1,root);
		if(%targ.getClassName() $= "Player")
		{
			//cancel(%targ.hSpazzClick);
			if( isObject(%targ.client) )
				%targ.client.setControlObject(%targ);
		}
	}
	%obj.playThread(0,root);
	parent::onDisabled(%this,%obj,%a);
}

function SharkHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	if( %obj.hLastEatTime+200 > getSimTime() )
		return;

	//If the shark has a bot in his mouth and he gets hurt randomly dismount the bot
	if( (!getRandom(0,3) || %damage >= 50 ) && isObject(%obj.hEating) && %obj.hEating == %obj.getMountedObject(0) )
	{
		cancel(%obj.hSharkEatDelay);
		%targ = %obj.hEating;

		%obj.hEating = 0;
		%targ.dismount();
		%targ.playThread(0,root);
		%obj.playThread(1,root);
		%obj.hIgnore = 0;
		if(%targ.getClassName() $= "Player")
		{
			//cancel(%targ.hSpazzClick);
			%targ.client.setControlObject(%targ);
		}
		
		%obj.lastattacked = getsimtime()+1000;

		%obj.hRunAwayFromPlayer(%targ);
		%obj.scheduleNoQuota(2000,startHoleLoop);
	}
}

package holeSharkPackage
{
	function Observer::onTrigger(%this, %obj, %a, %b)
	{
		%client = %obj.getControllingClient();

		if( isObject(%client.player) && %client.player.getObjectMount().hIsShark )
		{
			if( %b )
				%client.player.activateStuff();
				
			return;
		}

		parent::onTrigger(%this, %obj, %a, %b);
	}
};
activatePackage(holeSharkPackage);