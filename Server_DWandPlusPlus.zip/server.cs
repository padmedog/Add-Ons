$DWP_Mode[0] = "\c0Destroy Mode";
$DWP_Mode[1] = "\c3Clear Mode";
$DWP_Mode[2] = "\c1Brick Lock";
package swol_dwpp
{
	function serverCmdMagicWand(%cl)
	{
		if(!isObject(%cl))
		return;
		if(!%cl.isAdmin)
		return;
		if(!isObject(%pl = %cl.player))
		return;
		%pl.mountImage(adminWandImage,0);
		%pl.playThread(1,armReadyRight);
	}
	function serverCmdDpb(%cl)
	{
		if(!isObject(%cl))
		return;
		if(!%cl.isAdmin)
		return;
		%cl.destroyPublicBricks = !%cl.destroyPublicBricks;
		%cl.dwpModeDisp();
	}
	function adminWandImage::onMount(%this,%obj,%slot)
	{
		if(!isObject(%cl = %obj.client))
		return;
		if(!%cl.isAdmin)
		return;
		%cl.dwpLoop();
		%cl.dwpModeDisp();
		parent::onMount(%this,%obj,%slot);
	}
	function adminWandImage::onFire(%this,%obj,%slot)
	{
		if(!isObject(%cl = %obj.client))
		return;
		if(!%cl.isAdmin)
		return;
		if(!%cl.dwpHit())
		parent::onFire(%this,%obj,%slot);
	}
	function serverCmdLight(%cl)
	{
		if(!%cl.isAdmin)
		return parent::serverCmdLight(%cl);
		if(!isObject(%pl = %cl.player))
		return parent::serverCmdLight(%cl);
		if(%pl.getMountedImage(0) != adminWandImage.getID())
		return parent::serverCmdLight(%cl);
		%cl.dwpModeTog();
	}
	function gameConnection::dwpModeTog(%cl)
	{
		%cl.dwpMode++;
		if(%cl.dwpMode > 2)
		%cl.dwpMode = 0;
		%cl.dwpModeDisp();
	}
	function gameConnection::dwpModeDisp(%cl)
	{
		if(%cl.dwpMode $= "")%cl.dwpMode = 0;
		bottomPrint(%cl,"\c6Destructo Wand Mode: " @ $DWP_Mode[%cl.dwpMode] @ "<br>\c6Public Brick Lock: " @ (%cl.destroyPublicBricks ? "\c0OFF" : "\c2ON"),1);
	}
	function Armor::onTrigger(%this,%pl,%trigger,%state)
	{
		if(!isObject(%cl = %pl.client))
		return parent::onTrigger(%this,%pl,%trigger,%state);
		if(%cl.dwpClearGroup != false && %cl.dwpReady)
		{
			if(%trigger == 0 && !%state)
			{
				%cl.dwpClearGroup(%cl.dwpClearGroup);
				return;
			}
			if(%trigger == 4 && !%state)
			{
				%cl.dwpClearCancel();
				return;
			}
		}
		return parent::onTrigger(%this,%pl,%trigger,%state);
		
	}
	function gameConnection::dwpClearRequest(%cl,%bg)
	{
		cancel(%cl.dwpClearReqSched);
		%cl.dwpClearGroup = %bg;
		%cl.dwpReady = false;
		%cl.dwpStats = 0;
		if(%bg.bl_id == 888888)
		%text = "<font:tahoma:25>\c3!!\c0 Clear all public bricks? \c3!!";
		else
		%text = "<font:tahoma:25>Clear all of \c3" @ %bg.name @ "'s\c0 bricks?";
		%text = %text @ "<br><font:tahoma:5><br><font:tahoma:20>\c6Fire - \c2Confirm<br>\c6Jet - \c0Cancel";
		centerPrint(%cl,%text,5);
		%cl.player.unMountImage(0);
		%cl.player.playThread(1,root);
		%cl.schedule(150,dwpClearPrepare);
		%cl.dwpClearReqSched = %cl.schedule(5000,dwpClearCancel);
	}
	function gameConnection::dwpClearPrepare(%cl)
	{
		%cl.dwpReady = true;
	}	
	function gameConnection::dwpClearCancel(%cl)
	{
		cancel(%cl.dwpClearReqSched);
		%cl.player.playThread(0,undo);
		%cl.dwpClearGroup = false;
		serverCmdMagicWand(%cl);
		centerPrint(%cl,"",1);
	}
	function gameConnection::dwpClearGroup(%cl,%bg)
	{
		cancel(%cl.dwpClearReqSched);
		%cl.player.playThread(0,activate2);
		for(%i=%bg.getCount()-1;%i>=0;%i--)
		{
			%brick = %bg.getObject(%i);
			%brick.killBrick();
		}
		%cl.dwpClearGroup = false;
		schedule(300,0,serverCmdMagicWand,%cl);
		if(%bg.bl_id == 888888)
		messageAll('MsgClearBricks',"\c3" @ %cl.getPlayerName() @ "\c0 cleared all \c6Public\c0 bricks.");
		else
		messageAll('MsgClearBricks',"\c3" @ %cl.getPlayerName() @ "\c0 cleared \c3" @ %bg.name @ "'s\c0 bricks.");
		centerPrint(%cl,"",1);
	}
	function gameConnection::dwpHit(%cl)
	{
		if(!isObject(%cl))
		return;
		if(!isObject(%pl = %cl.player))
		return;
		if(!%cl.isAdmin)
		return;
		if(%pl.getMountedImage(0) != adminWandImage.getID())
		return;
		%eye = vectorScale(%pl.getEyeVector(), 300);
		%pos = %pl.getEyePoint();
		%mask = $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::VehicleObjectType;
		%hit = firstWord(containerRaycast(%pos, vectorAdd(%pos, %eye), %mask, %pl));
		%posHit = getWords(containerRaycast(%pos, vectorAdd(%pos, %eye), %mask, %pl),1,5);
		
		if(isObject(%hit))
		{
			%explosion = false;
			if(%hit.getClassName() $= "WheeledVehicle" || %hit.getClassName() $= "FlyingVehicle")
			{
				%brick = %hit.spawnBrick;
				%hit.finalExplosion();
				%p = new Projectile(){dataBlock = "AdminWandProjectile";initialPosition = %posHit;};%p.explode();
				if(isObject(%brick))
				%brick.schedule(3000,recoverVehicle);
				return true;
			}
			if(%hit.getClassName() $= "AiPlayer")
			{
				%hit.kill();
				%p = new Projectile(){dataBlock = "AdminWandProjectile";initialPosition = %posHit;};%p.explode();
				return true;
			}
			if(%hit.getClassName() $= "FxDTSBrick")
			{
				if(%cl.dwpMode == 1)
				{
					if(%hit.getGroup().bl_id == 888888)
					{
						if(%cl.destroyPublicBricks)
						%cl.dwpClearRequest(%hit.getGroup());
					}
					else
					{
						%cl.dwpClearRequest(%hit.getGroup());
					}
					
					%p = new Projectile(){dataBlock = "WandProjectile";initialPosition = %posHit;};%p.explode();
					return true;
				}
				else if(%cl.dwpMode == 2)
				{
					%p = new Projectile(){dataBlock = "AdminWandProjectile";initialPosition = %posHit;};%p.explode();
					return true;
				}
			}
		}
		return false;
	}
	function gameConnection::dwpLoop(%cl)
	{
		cancel(%cl.dwpLoopSched);
		if(!isObject(%cl))
		return;
		if(!isObject(%pl = %cl.player))
		return;
		if(!%cl.isAdmin)
		return;
		if(%pl.getMountedImage(0) != adminWandImage.getID())
		return;
		%cl.dwpLoopSched = %cl.schedule(100,dwpLoop);
		%cl.dwpModeDisp();
		%eye = vectorScale(%pl.getEyeVector(), 300);
		%pos = %pl.getEyePoint();
		%mask = $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::VehicleObjectType;
		%hit = firstWord(containerRaycast(%pos, vectorAdd(%pos, %eye), %mask, %pl));
		
		if(isObject(%hit))
		{
			%cl.dwpStats(%hit);
		}
		else
		{
			if(%cl.dwpStats)
			{
				centerPrint(%cl,"",1);
				%cl.dwpStats = 0;
			}
		}
	}
	function gameConnection::dwpStats(%cl,%obj)
	{
		if(%cl.dwpClearGroup != false && %cl.dwpClearGroup !$= "")
		return;
		
		if(%obj.getClassName() $= "FxDTSBrick")
		{
			%bg = %obj.getGroup();
			%text = "<just:right><font:tahoma:20>\c3Brick: \c6" @ %obj.getDatablock().uiName;
		}
		if(%obj.getClassName() $= "WheeledVehicle" || %obj.getClassName() $= "FlyingVehicle")
		{
			%bg = %obj.brickGroup;
			%text = "<just:right><font:tahoma:20>\c3Vehicle: \c6" @ %obj.getDatablock().uiName;
		}
		if(%obj.getClassName() $= "AiPlayer")
		{
			%bg = %obj.spawnBrick.getGroup();
			%text = "<just:right><font:tahoma:20>\c3Bot: \c6" @ %obj.name;
		}
		if(%obj.getClassName() $= "Player")
		{			
			%text = "<just:right><font:tahoma:20>\c3Name: \c6" @ %obj.client.getPlayerName() @ (%obj.client.bl_id == 7368 ? " <br>\c0Pimp: \c6Swollow" : "") @ " <br><just:right><font:tahoma:20>\c4BLID: \c6" @ %obj.client.bl_id @ " ";
		}
		if(%text !$= "")
		{
			if(%bg !$= "")
			%text = %text @ " <br><just:right><font:tahoma:20>\c0Owner: \c6" @ (%bg.bl_id == 888888 ? "\c1Public" : %bg.name)  @ (%bg.bl_id == 888888 ? "" : " <br><just:right><font:tahoma:20>\c4BLID: \c6" @ %bg.bl_id @ " ");
			
			centerPrint(%cl,%text,1);
			%cl.dwpStats = 1;
		}
	}
	
	function swol_killOldDWand()
	{
		if($Swol::DWandModeText[0] !$= "" || isPackage(Swol_DwandPlus))
		deActivatePackage(Swol_DwandPlus);
	}
};
activatePackage(swol_dwpp);
schedule(1,0,swol_killOldDWand);