//audio
datablock AudioProfile(TAssaultRifleFire1Sound)
{
   filename    = "./Assault_Rifle_fire.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("ARifle",   '<bitmap:add-ons/Weapon_Package_Tier2/ci_arifle> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier2/ci_arifle> %1',0.75,1);
datablock ProjectileData(TAssaultRifleProjectile1)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 14;
   directDamageType    = $DamageType::ARifle;
   radiusDamageType    = $DamageType::ARifle;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 80;
   verticalImpulse     = 40;
   explosion           = gunExplosion;

   muzzleVelocity      = 180;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.2;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(TAssaultRifleProjectile2)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 25;
   directDamageType    = $DamageType::ARifle;
   radiusDamageType    = $DamageType::ARifle;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 80;
   verticalImpulse     = 40;
   explosion           = gunExplosion;

   muzzleVelocity      = 180;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.2;
   
   particleEmitter = pistolTracerEmitter;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(TAssaultRifleItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Assault_Rifle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Assault Rifle";
	iconName = "./Assaultrifle";
	doColorShift = true;
	colorShiftColor = "0.4 0.4 0.41 1.000";

	 // Dynamic properties defined by the scripts
	image = TAssaultRifleImage;
	canDrop = true;
	
	maxAmmo = 20;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TAssaultRifleImage)
{
   // Basic Item properties
   shapeFile = "./Assault_Rifle.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0.03";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = TAssaultRifleItem;
   ammo = " ";
   projectile = TAssaultRifleProjectile1;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = TAssaultRifleItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.05;
	stateTransitionOnTimeout[0]       = "LoadCheckA";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnNoAmmo[1]       = "Reload";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Delay";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateEjectShell[2]       	  = true;
	stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateWaitForTimeout[2]			= true;

	stateName[3]			= "Delay";
	stateTransitionOnTimeout[3]     = "FireLoadCheckA";
	stateTimeoutValue[3]            = 0.05;
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.03;
	stateEmitterNode[3]				= "muzzleNode";
	
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 1.6;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.8;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Smoke";
	stateTransitionOnNoAmmo[9]		= "ReloadSmoke";
	
	stateName[10] 				= "Smoke";
	stateEmitter[10]			= gunSmokeEmitter;
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Ready";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitter[11]			= gunSmokeEmitter;
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
	
	stateName[12]				= "Reloaded";
	stateTimeoutValue[12]			= 0.01;
	stateScript[12]				= "onReloaded";
	stateTransitionOnTimeout[12]		= "Ready";
};

function TAssaultRifleImage::onFire(%this,%obj,%slot)
{
	if((getSimTime() - %obj.lastShotTime) > 500)
	{
		%projectile = TAssaultRifleProjectile2;
		%spread = 0.0003;
	}
	else
	{
		%projectile = TAssaultRifleProjectile1;
		%spread = 0.0006;
	}

        serverPlay3D(TAssaultRifleFire1Sound,%obj.getPosition());
	
	%obj.lastShotTime = getSimTime();
	%shellcount = 1;

	%obj.playThread(2, plant);
	%shellcount = 1;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function TAssaultRifleImage::onReloadStart(%this,%obj,%slot)
{
           	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, shiftAway);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function TAssaultRifleImage::onReloadWait(%this,%obj,%slot)
{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.playThread(2, shiftRight);
            serverPlay3D(magazineOutSound,%obj.getPosition());
	}
}

function TAssaultRifleImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["556rounds"] >= 1)
	{
	%obj.client.quantity["556rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(reloadClick8Sound,%obj.getPosition());


        if(%obj.client.quantity["556rounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["556rounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["556rounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["556rounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["556rounds"] = 0;

		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
		return;
	}
	}
}

function TAssaultRifleImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>5.56 Little Rifle <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["556rounds"] @ "", 4, 2, 3, 4); 
	}
}

function TAssaultRifleImage::onUnMount(%this,%obj,%slot)
{
	%obj.playThread(2, root);
}