datablock AudioDescription(Audio2xMusicLooping3d : AudioMusicLooping3d)
{
	maxDistance = 60;
	referenceDistance = 20;
};

datablock fxDtsBrickData(brick2xMusicData : brickMusicData)
{
	uiName = "Music (2x Range)";
	musicRange = 60;
	musicDescription = Audio2xMusicLooping3d;
};

datablock AudioDescription(Audio5xMusicLooping3d : AudioMusicLooping3d)
{
	maxDistance = 150;
	referenceDistance = 50;
};

datablock fxDtsBrickData(brick5xMusicData : brickMusicData)
{
	uiName = "Music (5x Range)";
	musicRange = 150;
	musicDescription = Audio5xMusicLooping3d;
};

exec("./Support_CustomRangeMusic.cs");