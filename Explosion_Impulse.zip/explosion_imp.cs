datablock ExplosionData(impulseExplosion)
{
   //explosionShape = "";

   explosionScale = "1 1 1";
   
   // does the camera shake
   shakeCamera = true;
   
   // how often does the camera shake
   camShakeFreq = "1.0 1.0 1.0";
   
   // how hard does the camera shake
   camShakeAmp = "0.4 0.4 0.4";
   
   // how long does it last in bed
   camShakeDuration = 0.5;
   
   // how far does the shake go
   camShakeRadius = 20.0;

   // make it so it doesn't fuck niggas up when used
   damageRadius = 0;
   radiusDamage = 0;

	// don't send people flying and shit that's annoying
   impulseRadius = 0;
   impulseForce = 0;
};

// make a projectile because you can't spawn an explosion on it's own
datablock ProjectileData(impulseProjectile)
{
   explosion = impulseExplosion;
   uiName = "Impulse";
};