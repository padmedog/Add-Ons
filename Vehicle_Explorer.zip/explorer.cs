//########## Explorer (Inspired by the russian Lada Niva)

//### Effects

datablock ParticleData(gc_tireParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.4 0.4 0.4 0.3";
  colors[1] = "0.2 0.2 0.2 0";
  sizes[0] = 2;
  sizes[1] = 6;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_tireEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 25;
  ejectionVelocity = 2;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_tireParticle";
  useEmitterColors = true;
};

datablock ParticleData(gc_vehicleDamageParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = -2;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0 0 0 0";
  colors[1] = "0 0 0 0.5";
  colors[2] = "0 0 0 0";
  sizes[0] = 3;
  sizes[1] = 4;
  sizes[2] = 6;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_vehicleDamageEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 25;
  ejectionVelocity = 2;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_vehicleDamageParticle";
  useEmitterColors = true;
};

//### Vehicle

datablock WheeledVehicleTire(gc_ExplorerTire)
{
  shapeFile = "./tire.dts";
  mass = 5;
  radius = 0.85;
  staticFriction = 1;
  kineticFriction = 1;
  restitution = 0.5;
  lateralForce = 18000;
  lateralDamping = 4000;
  lateralRelaxation = 0.01;
  longitudinalForce = 14000;
  longitudinalDamping = 2000;
  longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleTire(gc_ExplorerOffroadTire)
{
  shapeFile = "./offroadtire.dts";
  mass = 5;
  radius = 0.85;
  staticFriction = 1.5;
  kineticFriction = 1.5;
  restitution = 0.5;
  lateralForce = 18000;
  lateralDamping = 4000;
  lateralRelaxation = 0.01;
  longitudinalForce = 14000;
  longitudinalDamping = 2000;
  longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleSpring(gc_ExplorerSpring)
{
  length = 0.3;
  force = 5000;
  damping = 1000;
  antiSwayForce = 30;
};

datablock WheeledVehicleSpring(gc_ExplorerOffroadSpring)
{
  length = 0.6;
  force = 5000;
  damping = 1500;
  antiSwayForce = 30;
};

datablock DebrisData(gc_ExplorerTireDebris)
{
  shapeFile = "./tire.dts";
  lifetime = 2;
  minSpinSpeed = -400;
  maxSpinSpeed = 200;
  elasticity = 0.5;
  friction = 0.2;
  numBounces = 3;
  staticOnMaxBounce = true;
  snapOnMaxBounce = false;
  fade = true;
  gravModifier = 2;
};

datablock ExplosionData(gc_ExplorerExplosion : vehicleExplosion)
{
  debris = gc_ExplorerTireDebris;
  debrisNum = 4;
  debrisNumVariance = 0;
  debrisPhiMin = 0;
  debrisPhiMax = 360;
  debrisThetaMin = 40;
  debrisThetaMax = 85;
  debrisVelocity = 14;
  debrisVelocityVariance = 3;
};

datablock ProjectileData(gc_ExplorerExplosionProjectile : vehicleExplosionProjectile)
{
  uiName = "";
  explosion = gc_ExplorerExplosion;
};

datablock WheeledVehicleData(gc_ExplorerVehicle)
{
  uiName = "Explorer";
  category = "Vehicles";
  displayName = "";
  shapeFile = "./explorer.dts";
  emap = true;
  minMountDist = 3;
  numMountPoints = 4;
  mountThread[0] = "sit";
  mountThread[1] = "sit";
  mountThread[2] = "sit";
  mountThread[3] = "sit";
  maxDamage = 200;
  destroyedLevel = 200;
  speedDamageScale = 1.04;
  collDamageThresholdVel = 20;
  collDamageMultiplier = 0.02;
  massCenter = "0 0 -0.5";
  maxSteeringAngle = 0.9;
  integration = 4;
  tireEmitter = gc_tireEmitter;
  cameraRoll = false;
  cameraMaxDist = 13;
  cameraOffset = 6;
  cameraLag = 0.0;
  cameraDecay = 0.75;
  cameraTilt = 0.4;
  collisionTol = 0.1;
  contactTol = 0.1;
  useEyePoint = false;
  defaultTire = gc_ExplorerTire;
  defaultSpring = gc_ExplorerSpring;
  numWheels = 4;
  mass = 300;
  density = 5;
  drag = 1.6;
  bodyFriction = 0.6;
  bodyRestitution = 0.6;
  minImpactSpeed = 10;
  softImpactSpeed = 10;
  hardImpactSpeed = 15;
  groundImpactMinSpeed = 10;
  engineTorque = 2000;
  engineBrake = 500;
  brakeTorque = 3000;
  maxWheelSpeed = 50;
  rollForce = 900;
  yawForce = 600;
  pitchForce = 1000;
  rotationalDrag = 0.2;
  maxEnergy = 100;
  jetForce = 3000;
  minJetEnergy = 30;
  jetEnergyDrain = 2;
  splash = vehicleSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 1.4;
  splashEmitter[0] = vehicleFoamDropletsEmitter;
  splashEmitter[1] = vehicleFoamEmitter;
  splashEmitter[2] = vehicleBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  softImpactSound = slowImpactSound;
  hardImpactSound = fastImpactSound;
  justcollided = 0;
  rideable = true;
  lookUpLimit = 0.5;
  lookDownLimit = 0.5;
  paintable = true;
  damageEmitter[0] = gc_vehicleDamageEmitter;
  damageEmitterOffset[0] = "0 3 0";
  damageLevelTolerance[0] = 0.5;
  damageEmitter[1] = VehicleBurnEmitter;
  damageEmitterOffset[1] = "0 3 0";
  damageLevelTolerance[1] = 0.9;
  numDmgEmitterAreas = 1;
  initialExplosionProjectile = gc_ExplorerExplosionProjectile;
  initialExplosionOffset = 0;
  burnTime = 4000;
  finalExplosionProjectile = vehicleFinalExplosionProjectile;
  finalExplosionOffset = 0;
  minRunOverSpeed = 4;
  runOverDamageScale = 25;
  runOverPushScale = 1.2;
  protectPassengersBurn = true;
  protectPassengersRadius = true;
  protectPassengersDirect = true;
};

datablock WheeledVehicleData(gc_ExplorerOffroadVehicle : gc_ExplorerVehicle)
{
  uiName = "Explorer Offroad";
  category = "Vehicles";
  displayName = "";
  shapeFile = "./exploreroffroad.dts";
  defaultTire = gc_ExplorerOffroadTire;
  defaultSpring = gc_ExplorerOffroadSpring;
  initialExplosionProjectile = gc_ExplorerExplosionProjectile;
};

//### Functions

function gc_ExplorerVehicle::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  %obj.setWheelPowered(0,true);
  %obj.setWheelPowered(1,true);
  %obj.setWheelPowered(2,true);
  %obj.setWheelPowered(3,true);
}

function gc_ExplorerOffroadVehicle::onAdd(%this,%obj)
{
  parent::onAdd(%this,%obj);
  %obj.setWheelPowered(0,true);
  %obj.setWheelPowered(1,true);
  %obj.setWheelPowered(2,true);
  %obj.setWheelPowered(3,true);
}
