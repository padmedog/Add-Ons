//we need the tier 1 package for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Package_Tier2");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Package_Tier2A - required add-on Weapon_Package_Tier1 not found");
}
else
{
   exec("./Support_AltDatablock.cs"); 
   exec("./Weapon_Crossbow.cs"); 
   exec("./Weapon_Bullpup.cs"); 
   exec("./Weapon_PDW.cs"); 
   exec("./Weapon_Sniper_Carbine.cs"); 
   //exec("./Weapon_SlamShotgun.cs"); 
   exec("./Weapon_Machinepistol.cs"); 
   //exec("./Weapon_Match_Pistol.cs"); 

// the scoped magnum: scrapped idea, simply because it's overpowered to go around one-shotting people as long as you hit them in their giant giant head. still kept in here though, as an easter egg. 

//remove the at the front to turn the scoped magnum back on
//   exec("./Weapon_ScopedMagnum.cs"); 
}
