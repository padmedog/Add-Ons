registerOutputEvent(Minigame,playSound,"dataBlock Sound",0);
function MinigameSO::playSound(%this,%sound)
{
 if(!isObject(%sound) || %sound.getClassName() !$= "AudioProfile")
  return;
 
 if(%sound.description.isLooping)
  return;
 
 for(%i=0;%i<%this.numMembers;%i++)
 {
  %cl=%this.member[%i];
  //check for hacky dedicated minigame mods or AIConnections
  if(isObject(%cl) && %cl.getClassName() $= "GameConnection")
  {
   %cl.play2d(%sound);
  }
 }
}