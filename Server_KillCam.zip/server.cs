package Server_KillCam
{
	function gameConnection::onDeath(%client,%source,%killer,%type,%pos)
	{
		Parent::onDeath(%client,%source,%killer,%type,%pos);
		if(!%client.minigame.tdmLivesLimit)
		{
			if(%killer != -1 && %killer != %client && isObject(%killer.player))
			{
				%client.camera.setMode("Corpse",%killer.player);
			}
		}
	}
};
activatePackage(Server_KillCam);