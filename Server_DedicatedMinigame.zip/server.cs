$DedicatedMinigame::AdminOnly = 1;

function serverCmdDedicateMinigame(%client)
{
    %mini = getMinigameFromObject(%client);
    if(!isObject(%mini))
    {
	messageClient(%client,'','You are not in a mini-game!');
	return;
    }

    if(isObject(%mini) && %mini.owner != %client)
    {
	messageClient(%client,'','Only the minigame owner may dedicate mini-games.');
	return;
    }

    if(%client.isAdmin || !$DedicatedMinigame::AdminOnly)
    {
	%mini.toggleDedicated(%client);
    }

    else
	messageClient(%client,'','Sorry, only admins may dedicate mini-games on this server.');
}

function serverCmdDedicatedMinigame(%client)
{
     serverCmdDedicateMinigame(%client);
}

function serverCmdSetDedicatedMinigame(%client)
{
     serverCmdDedicateMinigame(%client);
}

function serverCmdSetDedicateMinigame(%client)
{
     serverCmdDedicateMinigame(%client);
}

function MinigameSO::toggleDedicated(%mini,%client)
{
    if(%mini.isDedicated)
    {
	$DediMinigames[%client.BL_ID] = -1;
	%mini.chatMsgAll(%client.name@"\c6 has un-dedicated the mini-game.", %client);
	%mini.isDedicated = 0;
    }

    else
    {
	$DediMinigames[%client.BL_ID] = %mini;
	$DediMinigames[%client.BL_ID] = %mini;
	%mini.chatMsgAll(%client.name @"\c6 has dedicated the mini-game.", %client);
	%mini.isDedicated = 1;
    }
}

package DedicatedMinigame
{
    function CreateMinigameSO(%client,%title,%a,%b,%c,%d)
    {
	%mini = Parent::CreateMinigameSO(%client,%title,%a,%b,%c,%d);

	if(isObject(%mini))
	    %mini.ownerBL_ID = %client.BL_ID;

	return %mini;
    }

    function MinigameSO::addMember(%mini, %client)
    {
	if(%mini.ownerBL_ID == %client.BL_ID && %mini.isDedicated && isObject(%mini.fakeowner))
	{
	    %mini.fakeowner.delete();
	    %mini.owner = %client;
	    %client.minigame = %mini;
	    commandtoclient(%client, 'SetPlayingMinigame', 1);
	    commandtoclient(%client, 'SetRunningMinigame', 1);
	    %mini.member[%mini.numMembers] = %client;
	    %mini.numMembers++;
	    %client.setScore(0);
	    %client.instantrespawn();
	    %mini.chatmsgall("\c1"@ %client.name @" has joined the mini-game. (Mini-game owner)", %client);
	    return;
	}

	%data = %mini.owner.name TAB %mini.ownerBL_ID TAB %mini.title TAB %mini.inviteOnly;
	commandToClient(%client, 'AddMiniGameLine', %data, %mini, %mini.colorIdx);

	Parent::addMember(%mini,%client);
    }

    function MinigameSO::removeMember(%mini,%client)
    {
	//if there is only 1 member in the game, there will be 0 left if we remove one.
	//minigames kill themselves if they don't have any members, so we'll rewrite what happens
	//the leave minigame process
	if(%mini.ownerBL_ID == %client.BL_ID && %mini.isDedicated)
	{
	    %mini.fakeowner = new AiConnection();
	    %mini.fakeowner.fakename = %client.name;
	    %mini.fakeowner.name = %client.name;
	    %mini.fakeowner.brickgroup = %client.brickgroup;
	    %mini.owner = %mini.fakeowner;
	    for(%m=0;%m<%mini.numMembers;%m++)
	    {
		if(%mini.member[%m] == %client)
		{
		    %mini.member[%m] = "";
		    break;
		}
	    }

	    for(%i=%m+1;%i<%mini.numMembers;%i++)
		%mini.member[%i-1] = %mini.member[%i];

	    %mini.numMembers--;
	    %client.minigame = "";
	    commandtoclient(%client,'SetPlayingMinigame',0);
	    commandtoclient(%client,'SetRunningMinigame',0);
	    %client.setScore(0);
	    %client.instantrespawn();
	    %mini.chatmsgall("\c1"@%client.name@" has left the mini-game. (Mini-game owner)",%client);

	    %data = %mini.owner.name TAB %mini.ownerBL_ID TAB %mini.title TAB %mini.inviteOnly;
	    commandToClient(%client, 'AddMiniGameLine', %data, %mini, %mini.colorIdx);
	}

	else if(%mini.numMembers == 1 && %mini.isDedicated)
	{
	    for(%m=0;%m<%mini.numMembers;%m++)
	    {
		if(%mini.member[%m] == %client)
		{
		    %mini.member[%m] = "";
		    break;
		}
	    }

	    for(%i=%m+1;%i<%mini.numMembers;%i++)
		%mini.member[%i-1] = %mini.member[%i];

	    %mini.numMembers--;
	    %client.minigame = "";
	    commandtoclient(%client,'SetPlayingMinigame',0);
	    commandtoclient(%client,'SetRunningMinigame',0);
	    %client.setScore(0);
	    %client.instantrespawn();
	    %mini.chatmsgall("\c1"@%client.name@" has left the mini-game.",%client);

	    %data = %mini.owner.name TAB %mini.ownerBL_ID TAB %mini.title TAB %mini.inviteOnly;
	    commandToClient(%client, 'AddMiniGameLine', %data, %mini, %mini.colorIdx);
	}
	else
	    Parent::removeMember(%mini,%client);
    }

    function AiConnection::spawnPlayer(%ai)
    {
	if(%ai.fakename $= "")
	    return Parent::spawnPlayer(%ai);
    }

    function AiConnection::InstantRespawn(%ai)
    {
	if(%ai.fakename $= "")
	    return Parent::InstantRespawn(%ai);
    }
	
    function getMinigameFromObject(%obj)
    {
	if(!isObject(%obj))
	    return parent::getMinigameFromObject(%obj);

	//v1.1: Brickgroups now properly go to the correct minigame
	//Pipe wrench most notably checks the brickgroup
	if(%obj.getClassName() $= SimGroup)
	{
	    %brick_blid = %obj.bl_id;
	    %mini = $DediMinigames[%brick_blid];
	    if(isObject(%mini) && %brick_blid == %mini.ownerBL_ID)
		return %mini;
	}

	%classCheck["AIPlayer"] = 1;
	%classCheck["WheeledVehicle"] = 1;
	%classCheck["FlyingVehicle"] = 1;
	%classCheck["Item"] = 1;
	if(%classCheck[%obj.getClassName()] && isObject(%obj.spawnbrick))
	{
	    //if the spawnbrick's owner has a minigame under his BL_ID,
	    //we can assume it to be in owner's minigame
	    %brick_blid = %obj.spawnbrick.getGroup().bl_id;
	    %mini = $DediMinigames[%brick_blid];
	    if(isObject(%mini) && %brick_blid == %mini.ownerBL_ID)
		return %mini;
	}

	if(%obj.getClassName() $= FXDtsBrick)
	{
	    %brick_blid = %obj.getGroup().bl_id;
	    %mini = $DediMinigames[%brick_blid];
	    if(isObject(%mini) && %brick_blid == %mini.ownerBL_ID)
		return %mini;
	}
	return Parent::getMinigameFromObject(%obj);
    }


    function miniGameCanDamage(%obj1, %obj2)
    {
	if(!isObject(%obj1) || !isObject(%obj2))
	    return Parent::miniGameCanDamage(%obj1, %obj2);

	if((%mini = getMinigameFromObject(%obj1)) $= getMinigameFromObject(%obj2))
	{
	    //The "if" right after this was added in V1.1, as people who both aren't in a minigame would be
	    //treated as if they were in the same minigame, because their minigame has the same "value"
	    if(!isObject(%mini))
		return 0;

	    else if(!%mini.brickDamage && %obj2.getClassName() $= fxDTSBrick)
		return 0;

	    return 1;
	}

	return Parent::miniGameCanDamage(%obj1, %obj2);
    }

    function miniGameCanUse(%obj1, %obj2)
    {
	%classCheck["AIPlayer"] = 1;
	%classCheck["WheeledVehicle"] = 1;
	%classCheck["FlyingVehicle"] = 1;
	%classCheck["Item"] = 1;
	%obj = %obj2;
	
	if(%classCheck[%obj.getClassName()] && isObject(%obj.spawnbrick))
	{
	    //if the spawnbrick's owner has a minigame under his BL_ID,
	    //we can assume it to be in the minigame
	    %brick_blid = %obj.spawnbrick.getGroup().bl_id;
	     
	    %mini = $DediMinigames[%brick_blid];
	    if(isObject(%mini) && %brick_blid == %mini.ownerBL_ID)
	    {
		return 1;
	    }
	}

	if(%obj2.getClassName() $= FXDtsBrick)
	{
	    %brick_blid = %obj.getGroup().bl_id;
	    %mini = $DediMinigames[%brick_blid];
	    if(isObject(%mini) && %brick_blid == %mini.ownerBL_ID)
		return 1;
	}
	return Parent::miniGameCanUse(%obj1, %obj2);
    }
};
activatePackage(DedicatedMinigame);