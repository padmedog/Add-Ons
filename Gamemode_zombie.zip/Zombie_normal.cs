 datablock PlayerData(RotNormalZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;
	runforce = 100 * 90;
	maxForwardSpeed = 8;
	maxBackwardSpeed = 8;
	maxSideSpeed = 8;
	attackpower = 10;
	jumpsound = "ZombieJumpSound";
	
	BrickDestroyMaxVolume = 250;
	BrickMaxJumpHeight = 20;
	uiName = "Zombie Normal";
	rideable = true;
	canRide = true;
	BrickKillRadius = 2;
	skinColor = "0.55 0.7 0.55 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
};
function RotNormalZombie::ondisabled(%this,%obj)
{
	parent::ondisabled(%this,%obj);
	ZombieDefault::ondisabled(%this,%obj);
}
function RotNormalZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotNormalZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotNormalZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotNormalZombie::onAdd(%this,%obj)
{
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
}