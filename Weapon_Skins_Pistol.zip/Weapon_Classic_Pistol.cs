datablock ItemData(ClassicPistolItem : PistolItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
   shapeFile = "./CLASSIC_PISTOL.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Classic Pistol";
	iconName = "./Classicpistol";
	doColorShift = true;
	colorShiftColor = "0.51 0.43 0.36 1";
	l4ditemtype = "secondary";

	 // Dynamic properties defined by the scripts
	image = ClassicPistolImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 10;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
AddDamageType("ClassicL4Pistol",   '<bitmap:add-ons/Weapon_Skins_Pistol/ci_Classic_pistol> %1',    '%2 <bitmap:add-ons/Weapon_Skins_Pistol/ci_Classic_pistol> %1',0.75,1);
datablock ShapeBaseImageData(ClassicPistolImage : PistolImage)
{
   raycastDirectDamage = 15;

   shapeFile = "./CLASSIC_PISTOL.dts";
   // Projectile && Ammo.
   item = ClassicPistolItem;
   doColorShift = true;
   colorShiftColor = ClassicPistolItem.colorShiftColor;
};

function ClassicpistolImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTLittleRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0018;
		%this.raycastWeaponRange = 85;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0009;
		%this.raycastWeaponRange = 200;
	}
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	
	%obj.playThread(2, shiftAway);	
}

function classicPistolImage::onReloadWait(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
}
}

function classicPistolImage::onReloadStart(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.playThread(2, shiftLeft);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}
}

function classicPistolImage::onBounce(%this,%obj,%slot)
{	
if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
	%obj.playThread(2, plant);
}

function classicPistolImage::onReady(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
	}
}

function classicPistolImage::onReloaded(%this,%obj,%slot)
{
	//
	//
	// RELOAD SEQUENCE LOL
	// now 30% more modular or so
	///////////////////////////////////////////////////////////////////////////////////

    if(%obj.client.quantity["9MMrounds"] >= 1)
	{
	%obj.client.quantity["9MMrounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;
	%obj.playThread(2, plant);
        serverPlay3D(pistolClickSound,%obj.getPosition());

        if(%obj.client.quantity["9MMrounds"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["9MMrounds"] -= %this.item.maxAmmo;
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["9MMrounds"] <= %this.item.maxAmmo)
	{
		%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["9MMrounds"];
		%obj.AmmoSpent[%obj.currTool] = 0;
		%obj.setImageAmmo(%slot,1);
		%obj.client.quantity["9MMrounds"] = 0;

            	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>9mm <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["9MMrounds"] @ "", 1, 2, 3, 4); 
		return;
	}
	}
}