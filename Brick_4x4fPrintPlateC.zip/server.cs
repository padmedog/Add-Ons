datablock fxDTSBrickData (brick4x4FPrintPlateCData)
{
	brickFile = "./4x4FPrintPlateC.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "4x4F Ceiling Print Plate";
	iconName = "Add-Ons/Brick_4x4fPrintPlateC/4x4FPrintPlateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};