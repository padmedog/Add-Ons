datablock ParticleData(PyGunfireParticle)
{
	dragCoefficient      = 2.5;
	gravityCoefficient   = -0.17;
	inheritedVelFactor   = 1;
	constantAcceleration = 0;
	lifetimeMS           = 1250;
	lifetimeVarianceMS   = 750;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]	= "0.1 0.1 1 1";
	colors[1]	= "1 0.5 0 0.5";
	colors[2]	= "1 0.25 0 0.25";
	colors[3]	= "1 0 0 0";
	sizes[0]	= 0.25;
	sizes[1]	= 0.5;
	sizes[2]	= 0.55;
	sizes[3]	= 0.7;
	times[0]	= 0;
	times[1]	= 0.2;
	times[2]	= 0.8;
	times[3]	= 1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(PyGunfireEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 15;
   velocityVariance = 5;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PyGunfireParticle";

   uiName = "Pyro Gun Flame";
};

datablock ParticleData(PyGunambientParticle)
{
	dragCoefficient      = 1.5;
	gravityCoefficient   = -0.25;
	inheritedVelFactor   = 0.5;
	windCoefficient      = 0.1;
	constantAcceleration = 0;
	lifetimeMS           = 400;
	lifetimeVarianceMS   = 100;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 0.65 0 0.5";
	colors[1]     = "1 0 0 0";
	sizes[0]      = 0.1;
	sizes[1]      = 0.05;

	useInvAlpha = false;
};
datablock ParticleEmitterData(PyGunambientEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 0.5;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 10;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PyGunambientParticle";

   uiName = "Pyro Gun Ambient";
};

datablock ParticleData(PyGunExplosionParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.2;
	inheritedVelFactor   = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 500;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0 0 0 0.6";
	colors[1]     = "0 0 0 0";
	sizes[0]      = 0.35;
	sizes[1]      = 0.9;

	useInvAlpha = true;
};
datablock ParticleEmitterData(PyGunExplosionEmitter)
{
   ejectionPeriodMS = 25;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 1.5;
   ejectionOffset   = 0.1;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PyGunExplosionParticle";

   uiName = "Pyro Gun Burn";
};

datablock ExplosionData(PyGunExplosion)
{
   lifeTimeMS = 400;

   emitter[0] = PyGunexplosionEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10 10 10";
   camShakeAmp = "1 1 1";
   camShakeDuration = 0.5;
   camShakeRadius = 10;

   lightStartRadius = 4;
   lightEndRadius = 0;
   lightStartColor = "1 0.6 0";
   lightEndColor = "1 0.5 0";
};

AddDamageType("PyGun",'<bitmap:add-ons/Weapon_PyroGun/CI_PyGun_V2> %1','%2 <bitmap:add-ons/Weapon_PyroGun/CI_PyGun_V2> %1',0.05,1);
datablock ProjectileData(PyGunprojectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 4; //25 per second * 4 = 100 damage per second
   directDamageType    = $DamageType::PyGun;
   radiusDamageType    = $DamageType::PyGun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 2;
   brickExplosionMaxVolumeFloating = 5;

   impactImpulse	     = 100;
   verticalImpulse	  = 0;
   explosion           = PyGunExplosion;
   particleEmitter     = "";

   muzzleVelocity      = 18;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 700;
   fadeDelay           = 700;
   bounceElasticity    = 0.01;
   bounceFriction      = 0.99;
   isBallistic         = false;
   gravityMod          = 0;

   hasLight    = true;
   lightRadius = 1.5;
   lightColor  = "1 0.4 0";
};

datablock ItemData(PyGunItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./PyroGunV2.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "Pyro Gun";
	iconName = "./icon_PyGun_v2";
	doColorShift = false;
	colorShiftColor = "1 0.25 0 1";

	image = PyGunImage;
	canDrop = true;
};

datablock ShapeBaseImageData(PyGunImage)
{
   shapeFile = PyGunItem.shapeFile;
   emap = true;

   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0;
   rotation = "0 0 0";

   correctMuzzleVector = true;

   className = "WeaponImage";

   item = PyGunItem;
   ammo = " ";
   projectile = PyGunprojectile;
   projectileType = Projectile;

   melee = false;
   armReady = true;

   doColorShift = PyGunItem.doColorShift;
   colorShiftColor = PyGunItem.colorShiftColor;

   stateName[0]                   = "Activate";
   stateTimeoutValue[0]           = 0.15;
   stateTransitionOnTimeout[0]    = "Ready";
   stateWaitForTimeout[0]         = true;
   stateSound[0]                  = weaponSwitchSound;

   stateName[1]                   = "Ready";
   stateTransitionOnTriggerDown[1]= "Fire";
   stateAllowImageChange[1]       = true;
   stateEmitter[1]                = PyGunambientEmitter;
   stateEmitterTime[1]            = 1000;
   stateEmitterNode[1]            = "muzzlePoint";

   stateName[2]                   = "Fire";
   stateTransitionOnTimeout[2]    = "Fire";
   stateTransitionOnTriggerUp[2]  = "Ready";
   stateTimeoutValue[2]           = 0.04;
   stateFire[2]                   = true;
   stateAllowImageChange[2]       = false;
   stateScript[2]                 = "onFire";
   stateWaitForTimeout[2]         = true;
   stateEmitter[2]                = PyGunfireEmitter;
   stateEmitterTime[2]            = 0.07;
   stateEmitterNode[2]            = "muzzlePoint";
   stateSound[2]                  = sprayFireSound;
};

function PyGunProjectile::Damage(%this, %obj, %col, %fade, %pos, %normal)
{
   if(%col.getClassName() $="Player" || %col.getClassName() $="AIPlayer")
   {
      %col.burnPlayer(5);
   }
   parent::Damage(%this, %obj, %col, %fade, %pos, %normal);
}