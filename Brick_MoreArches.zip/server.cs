datablock fxDTSBrickData(brickEquilateralArchData)
{
	brickFile = "./Arch_Equilateral.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "Equilateral Arch";
	iconName = "Add-Ons/Brick_MoreArches/Icons/Equilateral";
};
datablock fxDTSBrickData(brickHorseshoeArchData)
{
	brickFile = "./Arch_HorseShoe.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "Horse Shoe Arch";
	iconName = "Add-Ons/Brick_MoreArches/Icons/HorseShoe";
};
datablock fxDTSBrickData(brickTudorArchData)
{
	brickFile = "./Arch_Tudor.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "Tudor Arch";
	iconName = "Add-Ons/Brick_MoreArches/Icons/Tudor";
};
datablock fxDTSBrickData(brickBasketHandleArchData)
{
	brickFile = "./Arch_BasketHandle.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "Basket Handle Arch";
	iconName = "Add-Ons/Brick_MoreArches/Icons/BasketHandle";
};