%errorA = forceRequiredAddOn("Sound_Phone");
%errorB = forceRequiredAddOn("Projectile_GravityRocket");

if(%errorA == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_PipeBomb - required add-on Sound_Phone not found");
}
else if(%errorB == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_PipeBomb - required add-on Projectile_GravityRocket not found");
}
else
{
   exec("./Weapon_PipeBomb.cs");
}