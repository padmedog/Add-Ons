datablock fxLightData(DDNegativeLightBlueVerySmall)
{
	uiName = "Anti Blue Very Small";
	LightOn = true;
	radius = 0;
	brightness = -10;
	color = "0 0 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightBlueSmall)
{
	uiName = "Anti Blue Small";
	LightOn = true;
	radius = 0;
	brightness = -25;
	color = "0 0 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightBlueMedium)
{
	uiName = "Anti Blue Medium";
	LightOn = true;
	radius = 0;
	brightness = -50;
	color = "0 0 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightBlueLarge)
{
	uiName = "Anti Blue Large";
	LightOn = true;
	radius = 0;
	brightness = -100;
	color = "0 0 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightBlueVeryLarge)
{
	uiName = "Anti Blue Very Large";
	LightOn = true;
	radius = 0;
	brightness = -200;
	color = "0 0 1 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};