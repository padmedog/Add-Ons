datablock fxDTSBrickData ( brickSecurityDoor2OpenCWData )
{
	brickFile = "./SecurityDoor2openCW.blb";
	uiName = "Security Door 2";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickSecurityDoor2CWData";
	openCW = "brickSecurityDoor2OpenCWData";
	
	closedCCW = "brickSecurityDoor2CWData";
	openCCW = "brickSecurityDoor2OpenCCWData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickSecurityDoor2OpenCCWData : brickSecurityDoor2OpenCWData )
{
	brickFile = "./SecurityDoor2openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickSecurityDoor2CWData : brickSecurityDoor2OpenCWData )
{
	brickFile = "./SecurityDoor2closed.blb";
	category = "special";
	subCategory = "Doors 2";

	iconName = "Add-Ons/Brick_LLDoors/SecurityDoor2";
	
	isOpen = 0;
};