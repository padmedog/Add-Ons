//########## Fire Musket

//### Effects

datablock ParticleData(gc_FireMusketIdleParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = -1;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 500;
  lifetimeVarianceMS = 100;
  textureName = "base/data/particles/cloud";
  spinSpeed = 1;
  spinRandomMin = -5;
  spinRandomMax = 5;
  colors[0] = "0.2 0.6 1 1";
  colors[1] = "1 0.5 0 1";
  colors[2] = "1 0 0 0";
  sizes[0] = 0.05;
  sizes[1] = 0.1;
  sizes[2] = 0.1;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FireMusketIdleEmitter)
{
  uiName = "";
  ejectionPeriodMS = 25;
  periodVarianceMS = 0;
  ejectionVelocity = 0.5;
  velocityVariance = 0.5;
  ejectionOffset = 0.1;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 7200;
  phiVariance = 0;
  overrideAdvance = false;
  particles = "gc_FireMusketIdleParticle";
};

datablock ParticleData(gc_FireMusketTrailParticle)
{
  dragCoefficient = 2;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1200;
  lifetimeVarianceMS = 800;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -150;
  spinRandomMax = 150;
  colors[0] = "1 1 0 0.4";
  colors[1] = "1 0.2 0 0.5";
  colors[2] = "0.2 0.2 0.2 0.3";
  colors[3] = "0 0 0 0";
  sizes[0] = 0.25;
  sizes[1] = 0.85;
  sizes[2] = 0.35;
  sizes[3] = 0.05;
  times[0] = 0;
  times[1] = 0.05;
  times[2] = 0.3;
  times[3] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FireMusketTrailEmitter)
{
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 0.25;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FireMusketTrailParticle";
  uiName = "";
};

//### Projectile

//AddDamageType("gc_FireMusket",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_musket> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_musket> %1',0.2,1);

datablock ProjectileData(gc_FireMusketProjectile)
{
  uiName = "";
  projectileShapeName = "Add-Ons/Weapon_FlintlockWeapons/lead.dts";
  directDamage = 10;
  directDamageType = $DamageType::gc_burning;
  radiusDamageType = $DamageType::gc_burning;
  brickExplosionRadius = 0;
  brickExplosionImpact = false;
  impactImpulse = 500;
  verticalImpulse = 0;
  particleEmitter = "";
  explosion = gunExplosion;
  particleEmitter = gc_FireMusketTrailEmitter;
  muzzleVelocity = 200;
  lifetime = 1500;
  fadeDelay = 1500;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
};

//### Item

datablock ItemData(gc_FireMusketItem)
{
  uiName = "Fire Musket";
  iconName = "./icon_firemusket";
  image = gc_FireMusketImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./firemusket.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_FireMusketImage)
{
  shapeFile = "./firemusket.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_FireMusketItem;
  ammo = "";
  projectile = gc_FireMusketProjectile;
  projectilespread = 0.002;
  projectilecount = 5;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";
  stateEmitter[1] = gc_FireMusketIdleEmitter;
  stateEmitterNode[1] = "eyes";
  stateEmitterTime[1] = 1000;
  stateTimeoutValue[1] = 1000;
  stateTransitionOnTimeout[1] = "Ready";
  stateWaitForTimeout[1] = false;

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Smoke";
  stateTimeoutValue[2] = "0.05";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_MusketMuzzleEmitter;
  stateEmitterTime[2] = 0.1;
  stateEmitterNode[2] = "muzzlePoint";
  stateSound[2] = gc_MusketFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Fire";

  stateName[3] = "Smoke";
  stateTransitionOnTimeout[3] = "AmmoCheck";
  stateTimeoutValue[3] = "0.15";
  stateAllowImageChange[3] = false;
  stateWaitForTimeout[3] = true;
  stateEmitter[3] = gc_MusketMuzzleEmitter;
  stateEmitterTime[3] = 0.02;
  stateEmitterNode[3] = "lockPoint";

  stateName[4] = "AmmoCheck";
  stateTransitionOnTimeout[4] = "Ready";
  stateAllowImageChange[4] = true;
  stateScript[4] = "onAmmoCheck";

  stateName[5] = "Reload";
  stateTimeoutValue[5] = 1.5;
  stateTransitionOnTimeout[5] = "Done";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReloadStart";
  stateSequence[5] = "Reload";

  stateName[6] = "Done";
  stateTransitionOnTimeout[6] = "Ready";
  stateTimeoutValue[6] = 0.1;
  stateAllowImageChange[6] = true;
  stateScript[6] = "onReload";
};

//### Functions

function gc_FireMusketImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %obj.spawnExplosion(gc_weaponRecoil,"1 1 1");
  %spread = %this.projectilespread;
  for(%shell=0;%shell<%this.projectilecount;%shell++) {
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  }; }
  MissionCleanup.add(%p);
}
function gc_FireMusketImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_FireMusketImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,shiftRight); serverPlay3D(gc_FLReloadStartSound,%obj.getPosition()); }
function gc_FireMusketImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(0,1); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); }

function gc_FireMusketProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(miniGameCanDamage(%obj,%col) && getMiniGameFromObject(%col) != -1) {
  gc_burning(%col,5,%obj);
  if(%col.getType() & $TypeMasks::PlayerObjectType) {
  if(%col.isCrouched() != 1) {
  %colscale = getWord(%col.getScale(),2);
  if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale)
  { %col.damage(%obj,%pos,%this.directDamage,%this.directDamageType); } } }
  if(%col.getType() & $TypeMasks::VehicleObjectType)
  { %col.damage(%obj,%pos,3,%this.directDamageType); return 1; } }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}
