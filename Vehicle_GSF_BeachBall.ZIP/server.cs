%error = forceRequiredAddOn("Vehicle_Jeep");
if(%error == $Error::AddOn_Disabled)
{
 jeepVehicle.uiName = "";
 jeepExplosionProjectile.uiName = "";
 jeepFinalExplosionProjectile.uiName = "";
}
else if(%error == $Error::AddOn_NotFound)
{
 error("Vehicle_WeightedCubes - Required Add-On Vehicle_Jeep not found.");
 return;
}

datablock ParticleData(GSFBeachBallParticleA)
{
	textureName          = "base/data/particles/cloud";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 3100;
	lifetimeVarianceMS   = 300;
	spinSpeed     = 0;
	spinRandomMin = -30.0;
	spinRandomMax =  30.0;
	useInvAlpha   = true;

	colors[0]	= "1 1 1 0.0";
	colors[1]	= "1 1 1 0.5";
	colors[2]	= "1 1 1 0.0";

	sizes[0]	= 1.5;
	sizes[1]	= 2.0;
	sizes[2]	= 1.6;

	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(GSFBeachBallEmitterA)
{
   ejectionPeriodMS = 75;
   periodVarianceMS = 4;
   ejectionVelocity = 1.2;
   ejectionOffset   = 0.4;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 0;
   particles = GSFBeachBallParticleA;   
   
   useEmitterColors = false;

	uiName = "";
};

datablock ExplosionData(GSFBeachBallFinalExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 300;
   
   emitter[0] = GSFBeachBallEmitterA;
   emitter[1] = GSFBeachBallEmitterA;

   particleEmitter = GSFBeachBallEmitterA;
   particleDensity = 20;
   particleRadius = 1.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.0 0.3 0.9";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 3;
   impulseForce = 100;
   impulseVertical = 200;

   //radius damage
   radiusDamage        = 10;
   damageRadius        = 2.0;

   //burn the players?
   playerBurnTime = 0;
};

datablock ProjectileData(GSFBeachBallFinalExplosionProjectile : vehicleFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = GSFBeachBallFinalExplosion;

   directDamageType  = $DamageType::VehicleExplosion;
   radiusDamageType  = $DamageType::VehicleExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 0;

   uiName = "";
};
datablock WheeledVehicleData(GSFBeachBallVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./GSFBeachBall.dts"; 
	emap = true;
	minMountDist = 3;
   
   numMountPoints = 0;
   mountThread[0] = "sit";
   mountThread[1] = "sit";
   mountThread[2] = "sit";
   mountThread[3] = "sit";
   mountThread[4] = "sit";
   mountThread[5] = "sit";
   mountThread[6] = "sit";
   mountThread[7] = "sit";

	maxDamage = 500.00;
	destroyedLevel = 500.00;
	energyPerDamagePoint = 160;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0";
   massBox = "1 1 1";

	maxSteeringAngle = 0.9785;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	//tireEmitter = TireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 13;         // Far distance from vehicle
	cameraOffset = 7.5;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.4;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

	//defaultTire	 = jeepTire;
	//defaultSpring = jeepSpring;
	//flatTire	    = jeepFlatTire;
	//flatSpring	 = jeepFlatSpring;

   numWheels = 0;

	// Rigid Body
	mass = 200;
	density = 0.3;
	drag = 3;
	bodyFriction = 0.6;
	bodyRestitution = 0.3;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 12000; //4000;       // Engine power
	engineBrake = 2000;         // Braking when throttle is 0
	brakeTorque = 4000;        // When brakes are applied
	maxWheelSpeed = 20;        // Engine scale by current speed / max speed

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

   isSled = false;

   forwardThrust		= 3000;
	reverseThrust		= 2000;
	lift			= 0;
	maxForwardVel		= 40;
	maxReverseVel		= 40;
	horizontalSurfaceForce	= 0;   // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 0; 
	rollForce		= 4000;
	yawForce		= 6000;
	pitchForce		= 6000;
	rotationalDrag		= 0.15;
	stallSpeed		= 10;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "GSF BeachBall ";
	rideable = true;
		lookUpLimit = 0.65;
		lookDownLimit = 0.45;

	paintable = true;
   
   damageEmitter[0] = GSFBeachBallEmitterA;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = GSFBeachBallEmitterA;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

   initialExplosionProjectile = GSFBeachBallFinalExplosionProjectile;
   initialExplosionOffset = 0;         //offset only uses a z value for now

   burnTime = 10;

   finalExplosionProjectile = GSFBeachBallFinalExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now

   minRunOverSpeed    = 2;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 5;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed
};


