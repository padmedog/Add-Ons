if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	//Gameplay
	RTB_registerPref("Brick Activate Range","Gameplay","$Game::BrickActivateRange","int 0 10","Script_GamePreferences",5,0,1);
	RTB_registerPref("Item Lifetime (miliseconds)","Gameplay","$Game::Item::PopTime","int 0 30000","Script_GamePreferences",10000,0,1);
	RTB_registerPref("Player Invulnerablility Time (miliseconds)","Gameplay","$Game::PlayerInvulnerabilityTime","int 100 10000","Script_GamePreferences",2500,0,1);
	RTB_registerPref("onTouch Immune Time (miliseconds)","Gameplay","$Game::OnTouchImmuneTime","int 0 10000","Script_GamePreferences",2000,0,1);
	RTB_registerPref("Vehicle Invulnerablility Time (miliseconds)","Gameplay","$Game::VehicleInvulnerabilityTime","int 0 10000","Script_GamePreferences",100,0,1);
	RTB_registerPref("Minimum Mount Time (miliseconds)","Gameplay","$Game::MinMountTime","int 0 5000","Script_GamePreferences",1000,0,1);

	//Max Values
	RTB_registerPref("(Brick)Max Item Respawn Time (miliseconds)","Max Values","$Game::Item::MaxRespawnTime","int 0 1200000","Script_GamePreferences",300000,0,1);
	RTB_registerPref("(Events)Max Events Per Brick","Max Values","$Game::MaxEventsPerBrick","int 0 500","Script_GamePreferences",100,0,1);
	RTB_registerPref("(Minigame)Max Brick Respawn Time (miliseconds)","Max Values","$Game::MaxBrickRespawnTime","int 0 1200000","Script_GamePreferences",300000,0,1);
	RTB_registerPref("(Minigame)Max Player Respawn Time (miliseconds)","Max Values","$Game::MaxPlayerRespawnTime","int 0 1200000","Script_GamePreferences",300000,0,1);
	RTB_registerPref("(Minigame)Max Vehicle Respawn Time (miliseconds)","Max Values","$Game::MaxVehicleRespawnTime","int 0 1200000","Script_GamePreferences",300000,0,1);
	RTB_registerPref("(Server)Max Admin Password Attempts","Max Values","$Game::MaxAdminTries","int 0 10","Script_GamePreferences",3,0,1);
}
else
{
	if(isobject(localclientconnection))
		clientCmdMessageBoxOk("Add-ons","Script_GamePreferences cannot run because you do not have RTB installed.");
	else
		error("Script_GamePreferences cannot run because you do not have RTB installed.");
}



// Copy Pasta, Yumm.
// Overwrite RTB's function, it has an error which causes crashes (by Ephialtes & SpaceGuy)
function serverCmdRTB_updatePrefs(%client,%prefArray)
{
   if(!%client.isSuperAdmin)
      return;
      
   for(%i=0;%i<getFieldCount(%prefArray);%i++)
   {
      %pref = strReplace(getField(%prefArray,%i),",","\t");
      %idA = getField(%pref,0);
      %idB = getField(%pref,1);
      %value = getField(%pref,2);
      
      %entry = $RTB::ServerPref[%idA,%idB];
      
      if(getField(%entry,5) $= 1 && (%client.bl_id !$= getNumKeyID() && findLocalClient() !$= %client))
         continue;
         
      %pref = getField(%entry,1);
      %type = getWord(getField(%entry,2),0);
      eval("%currVal = $"@%pref@";");
      
      if(%type $= "bool")
      {
         if(%value !$= 1 && %value !$= 0)
            continue;
      }
      else if(%type $= "string")
      {
         %max = getWord(getField(%entry,2),1);
         if(strLen(%value) > %max)
            %value = getSubStr(%value,0,%max);
         %value = strReplace(%value,"\"","\\\"");
      }
      else if(%type $= "int")
      {
         if(!isInt(%value))
            continue;
         %min = getWord(getField(%entry,2),1);
         %max = getWord(getField(%entry,2),2);
         
         if(%value < %min)
            %value = %min;
         if(%value > %max)
            %value = %max;
      }
      else if(%type $= "list") //this part edited
      {
         %list = restWords(getField(%entry,2));
         for(%j=0;%j<getWordCount(%list);%j++)
         {
            %word = getWord(%list,%j);
            if(%word $= %value && %j%2 $= 1)
            {
               %foundInList = 1;
               break;
            }
         }
         
         if(!%foundInList)
            continue;
      }
      
      if(%currVal !$= %pref)
      {
         eval("$"@%pref@" = \""@%value@"\";");
         %numChanged++;
         
         %newPrefArray = %newPrefArray@%idA@","@%idB@","@%value@"\t";
      }
   }
   
   commandtoclient(%client,'RTB_closeGui',"RTB_ServerControl");
   if(%numChanged <= 0)
      return;
      
   %newPrefArray = getFields(%newPrefArray,0,getFieldCount(%newPrefArray)-1);
   
   for(%i=0;%i<ClientGroup.getCount();%i++)
   {
      %cl = ClientGroup.getObject(%i);
      if(%cl.isSuperAdmin)
         commandtoclient(%cl,'RTB_updatePrefs',%newPrefArray);
   }
   
   messageAll('MsgAdminForce','\c3%1 \c0updated the server preferences.',%client.name);
   
   %file = new FileObject();
   %file.openForWrite("config/server/RTB/modPrefs.cs");
   for(%i=0;%i<$RTB::ServerPrefs;%i++)
   {
      for(%j=1;%j<$RTB::ServerPrefCount[%i];%j++)
      {
         eval("%prefValue = $"@getField($RTB::ServerPref[%i,%j],1)@";");
         %file.writeLine("$"@getField($RTB::ServerPref[%i,%j],1)@" = \""@%prefValue@"\";");
      }
   }
   %file.delete();
   
   export("$Pref::Server::*","config/server/prefs.cs");
}