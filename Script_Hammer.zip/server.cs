function servercmdhammer(%client)
{
   if(isObject(%client.player))
   {
      if(%Client.Minigame && !%Client.isAdmin && %Client.minigame.owner != %Client)
      {
	messageClient(%client, '', '\c6You cannot use this while in a minigame');
	return;
      }
      else
      {
	%player = %client.player;
	%player.updateArm(hammerImage);
	%player.mountImage(hammerimage, 0);
      }
   }
}
