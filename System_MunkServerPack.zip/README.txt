+---------------------------------------------+
+-
+-readme.txt
+-
+-Munk's Server Pack v3
+-By Munk
+-Server functionabilites 
+-
+---------------------------------------------+

+---------------------------------------------+
+-Table of Contents
+---------------------------------------------+

+- 1. Extended Information
+- 2. about main.cs
+- 3. Admin Commands
+- 4. Poke System
+- 5. Phone System
+- 6. Rotation Message
+- 8. Status
+- 9. Hidden Admin Commands
+- 10. Script Loader
+- 11. Future stuff to come 

+---------------------------------------------+
+-Table of Contents END
+---------------------------------------------+



+---------------------------------------------+
+- 1. Extended Information
+---------------------------------------------+

	MSP started as the fling command, my very first script. Then moved on to when I made launch, and slap.
	Then it turned into Utilites pack, which got up to version 12, with many different features. But also
	had a lot of features that didn't work, because I simply did not know how to do them at that time.
	Now it is a complete server pack with many things.

	
	Please email me all bug reports or post through rtb. My email: munkurious@gmail.com
	
	
	
+---------------------------------------------+
+- 2. about main.cs
+---------------------------------------------+

	Main.cs is the main file. It has the help commands, 
	and some of the support functions used in MSP. 
	You must execute it or many other things will break.
	
	
+---------------------------------------------+
+- 4. Admin Commands
+---------------------------------------------+

	Lots of admin commands, I suggest just reading the help command for information about each in-game.
	
	1. Fling
	2. Lauch
	3. Flash
	4. Slap
	5. Roast
	6. LaunchNTumble
	7. Tumble
	8. Talkas
	9. Kick
	10. Sparta
	11. FakeAdmin
	12. FakeSuperAdmin
	
	
	
+---------------------------------------------+
+- 5. Phone System
+---------------------------------------------+

	The Phone system has been taken out due to a better version on RTB, by JJStorm.
	The file is still there, it just doesn't execute it.
	
	Just put "exec("Add-ons/System_MunkServerPack/phonesystem.cs");" into console to exec.
	
	-------
	
	The phone system is basically private messaging without having to write a command
	each message, through the server.
	Say /call NAME to call a person.
	
+---------------------------------------------+
+- 6. Rotation Message
+---------------------------------------------+

	Quote from: Bopizku on September 15, 2011, 06:30:27 PM
		"The Server Info Bot is a add-on that gives information about the server. Every few moments, a chat message comes up saying 
		'Server Info Bot: Blah, blah, blah, server information here.' Obviously it doesn't say that EXACTLY, but you know what I mean. 
		For example, let's say you have a Jail RP, and new players don't know how to escape! 
		You can use this add-on to give hints to those players. It's useful and easier than having to explain it!"

	Will display information to the whole server, defined in RTB Pref's, every few minutes.
	You start with 5 information slots, but you can change them through RTB Pref's to up to 30 slots(Requires restart of server).
	You can also change how long between messages, and what is before the information through RTB Preferences.
	You can also say /forceRM to force a message.
	
	
+---------------------------------------------+
+- 8. Status System
+---------------------------------------------+

	The status system is a system to manage if you are at the game or not.
	You can say /afk to go afk, /afk [Reason] to go afk with that reason.
	Same goes for /brb.
	Say /back to "come back".
	There is an auto-announcer you can configure and toggle.
	
	These commands don't really do anything but announce it.
	
	
	
+---------------------------------------------+
+- 9. Hidden Admin Commands
+---------------------------------------------+

	Some hidden commands
	
	/fakeAdmin words
	/fakeSuperAdmin words
	/slapall
	/launchall
	/LNTall
	/LNT
	/tumbleAll
	/roastAll
	
	Most of the commands have the ability to do a all at the end.
	

+---------------------------------------------+
+- 10. Script Loader
+---------------------------------------------+

	Script loader can load scripts without needing to discover files and stuff, 
	and just .cs's so you can write them quickly and execute them ingame with a command.
	
	Just put the .cs's into Config/MunkServerPack/scriptfiles/ and say /loadScriptFile name to load.
	
+---------------------------------------------+
+- 11. Future plans and stuff
+---------------------------------------------+

	Some more admin commands that arent useless.
	Poke n pm better somehow
	(Maybe) A GUI for Admins.
	





