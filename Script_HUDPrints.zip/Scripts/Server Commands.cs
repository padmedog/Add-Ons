// Title: Server Commands.cs
// Author: Boom (9740)
// Creates Functions to Modify Preferences without RTB

// Toggles / Sets HUD Prints
function serverCmdToggleHUDPrints(%client, %flag)
{
	if(%client.isAdmin)
	{
		if(%flag $= "")
			$Pref::HUDPrints::Enabled = !$Pref::HUDPrints::Enabled;
		else
			$Pref::HUDPrints::Enabled = %flag;
	}
}

// Toggles / Sets HUD Formatting
function serverCmdToggleFormatting(%client, %flag)
{
	if(%client.isAdmin)
	{
		if(%flag $= "")
			$Pref::HUDPrints::Formatting = !$Pref::HUDPrints::Formatting;
		else
			$Pref::HUDPrints::Formatting = %flag;
	}
}

// Sets HUD Chat Message
function serverCmdSetChatMessage(%client, %text)
{
	if(%client.isAdmin)
		$Pref::HUDPrints::ChatMessage = %text;
}

// Sets HUD Center Print
function serverCmdSetCenterPrint(%client, %text)
{
	if(%client.isAdmin)
		$Pref::HUDPrints::CenterPrint = %text;
}

// Sets HUD Bottom Print
function serverCmdSetBottomPrint(%client, %text)
{
	if(%client.isAdmin)
		$Pref::HUDPrints::BottomPrint = %text;
}

// Sets HUD Chat Refresh Rate
function serverCmdSetChatLoopTime(%client, %time)
{
	if(%client.isAdmin)
		$Pref::HUDPrints::ChatDelay = %time;
}

// Sets HUD Print Refresh Rate
function serverCmdSetPrintLoopTime(%client, %time)
{
	if(%client.isAdmin)
		$Pref::HUDPrints::PrintDelay = %time;
}

// Displays all Colors in the Chat
function serverCmdColorTest(%client, %test)
{
	if(isObject(%client.player))
	{
		%message = "";

		for(%i = 0; %i < 10; %i++)
			if(%test $= "")
				%message = %message @ "%c" @ %i @ %i;
			else
				%message = %message @ "%c" @ %i @ %test @ " ";

		messageClient(%client, '', parsePrint(%message, true));
	}
}

// Displays all Fonts in the Chat
function serverCmdFontTest(%client, %test)
{
	if(isObject(%client.player))
	{
		%message = "";

		for(%i = 0; %i < 10; %i++)
			if(%test $= "")
				%message = %message @ "%f" @ %i @ %i;
			else
				%message = %message @ "%f" @ %i @ %test @ " ";

		messageClient(%client, '', parsePrint(%message, true));
	}
}

// Displays all Sizes in the Chat
function serverCmdSizeTest(%client, %test)
{
	if(isObject(%client.player))
	{
		%message = "";

		for(%i = 0; %i < 10; %i++)
			if(%test $= "")
				%message = %message @ "%f0s" @ %i @ %i;
			else
				%message = %message @ "%f0s" @ %i @ %test @ " ";

		messageClient(%client, '', parsePrint(%message, true));
	}
}