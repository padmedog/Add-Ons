function SetMinigame(%client)
{
    if(isObject($DefaultMini))
    {
	$DefaultMini.addmember(%client);
    }
}

package DefaultMini
{
    function ServerCmdLeaveMinigame(%client)
    {
	if(%client.minigame == $DefaultMini && !%client.isadmin && !%client.issuperadmin)
	    messageclient(%client, '', "You cannot leave the default minigame unless you are an admin.");

	else
	    parent::ServerCmdLeaveMinigame(%client);
    }

    function GameConnection::onClientEnterGame(%client)
    {
	schedule(0, 0, "SetMinigame", %client);
	parent::onClientEnterGame(%client);
    }

    function serverCmdCreateMinigame(%client,%a,%b,%c,%d,%e,%f,%g)
    {
	if(%client.issuperadmin || %client.isadmin || !isObject($DefaultMini))
	{
	    Parent::serverCmdCreateMinigame(%client,%a,%b,%c,%d,%e,%f,%g);
	}

	else
	    messageclient(%client, '', "Sorry, you are not an admin.");

    }
};




function ServerCmdSetDefaultMinigame(%client)
{
    if(isObject(%client.minigame))
    {
	if(%client.isadmin || %client.issuperadmin)
	{
	    $DefaultMini = %client.minigame;
	    activatepackage(DefaultMini);
	    for(%i = 0; %i < ClientGroup.getcount();%i++)
	    {
		%test = ClientGroup.getobject(%i);

		if(!%test.hasSpawnedOnce)
		    continue;

		if(%test.minigame != $DefaultMini)
		{
		    if(isObject(%test.minigame))
		    {
			%test.minigame.removemember(%test);
		    }

		    $DefaultMini.addmember(%test);
		}
	    }

	    messageall('', "A default minigame has been set by \c2"@ %client.getPlayerName());
	}

	else
	    messageclient(%client, '', "You are not an admin!");

    }

    else
	messageclient(%client, '', "You are not in a minigame!");
}

function ServerCmdSetStandardMinigame(%client)
{
    ServerCmdNoDefaultMinigame(%client);
}

function ServerCmdSetnoDefaultMinigame(%client)
{
    ServerCmdNoDefaultMinigame(%client);
}

function ServerCmdNoDefaultMinigame(%client)
{

    if(!$DefaultMini)
	messageClient(%client, '', "There is no default minigame");

    else if(isObject(%client.minigame) && $DefaultMini)
    {
	if(%client.isadmin || %client.issuperadmin)
	{
	    deactivatepackage(DefaultMini);

	    for(%i = 0; %i < ClientGroup.getcount();%i++)
	    {
		%test = ClientGroup.getobject(%i);
		if(!%test.hasSpawnedOnce)
		    continue;

		if(%test.minigame == $DefaultMini && %test != %client && %test != $DefaultMini.owner)
		{
		    if(isObject(%test.minigame))
			%test.minigame.removemember(%test);
		}
	    }

	    $DefaultMini = "";
	    messageall('', "The default minigame has been disbanded by \c2"@ %client.getPlayerName());
	}

	else
	    messageclient(%client, '', "You are not an admin!");
    }


    else
	messageclient(%client, '', "You are not in a minigame!");
}
