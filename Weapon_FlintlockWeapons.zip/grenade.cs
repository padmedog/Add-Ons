//########## Grenade

//### Sounds

datablock AudioProfile(gc_FuzeSound)
{
  filename = "./fuze.wav";
  description = AudioClosestLooping3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_FLGrenadeExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 150;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/star1";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 24;
  sizes[1] = 16;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_FLGrenadeExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 2;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 4;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLGrenadeExplosionParticle";
};

datablock ParticleData(gc_FLGrenadeSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 10;
  sizes[1] = 20;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_FLGrenadeSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 6;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 1;
  ejectionOffset = 4;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_FLGrenadeSmokeParticle";
};

datablock ExplosionData(gc_FLGrenadeExplosion)
{
  lifeTimeMS = 200;
  emitter[0] = gc_FLGrenadeExplosionEmitter;
  emitter[1] = gc_FLGrenadeSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 6;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 8;
  radiusDamage = 250;
  impulseRadius = 12;
  impulseForce = 100;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 16;
};

//### Projectile

AddDamageType("gc_FLGrenade",'<bitmap:Add-ons/Weapon_FlintlockWeapons/CI_grenade> %1','%2 <bitmap:Add-ons/Weapon_FlintlockWeapons/CI_grenade> %1',0.2,1);

datablock ProjectileData(gc_FLGrenadeProjectile)
{
  uiName = "";
  projectileShapeName = "./grenadeprojectile.dts";
  directDamage = 0;
  directDamageType = $DamageType::gc_FLGrenade;
  radiusDamageType = $DamageType::gc_FLGrenade;
  brickExplosionRadius = 6;
  brickExplosionImpact = false;
  brickExplosionForce = 20;
  brickExplosionMaxVolume = 50;
  brickExplosionMaxVolumeFloating = 50;
  impactImpulse = 0;
  explosion = gc_FLGrenadeExplosion;
  particleEmitter = gc_FLBombTrailEmitter;
  muzzleVelocity = 30;
  verInheritFactor = 0;
  armingDelay = 3000;
  lifetime = 3000;
  fadeDelay = 3000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
  explodeOnDeath = true;
  explodeOnPlayerImpact = true;
  sound = gc_FuzeSound;
};

//### Item

datablock ItemData(gc_FLGrenadeItem)
{
  uiName = "Bomb";
  iconName = "./icon_grenade";
  image = gc_FLGrenadeImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./grenade.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
  canPickupMultiple = true;
};

//### Item Image

datablock shapeBaseImageData(gc_FLGrenadeImage)
{
  shapeFile = "./grenade.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_FLGrenadeItem;
  ammo = "";
  projectile = gc_FLGrenadeProjectile;
  projectileType = Projectile;
  casing = "";
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Charge";
  stateAllowImageChange[1] = true;

  stateName[2] = "Charge";
  stateTransitionOnTimeout[2] = "Armed";
  stateTimeoutValue[2] = 0.2;
  stateWaitForTimeout[2] = false;
  stateTransitionOnTriggerUp[2] = "AbortCharge";
  stateScript[2] = "onCharge";
  stateAllowImageChange[2] = false;
  stateSound[2] = gc_FuzeSound;
  stateEmitter[2] = gc_FuzeImageEmitter;
  stateEmitterTime[2] = 0.2;
  stateEmitterNode[2] = "upPoint";

  stateName[3] = "AbortCharge";
  stateTransitionOnTimeout[3] = "Ready";
  stateTimeoutValue[3] = 0.3;
  stateWaitForTimeout[3] = true;
  stateScript[3] = "onAbortCharge";
  stateAllowImageChange[3] = false;

  stateName[4] = "Armed";
  stateTransitionOnTriggerUp[4] = "Fire";
  stateAllowImageChange[4] = false;
  stateSound[4] = gc_FuzeSound;
  stateEmitter[4] = gc_FuzeImageEmitter;
  stateEmitterTime[4] = 1;
  stateEmitterNode[4] = "upPoint";
  stateTransitionOnTimeout[4] = "Armed";
  stateTimeoutValue[4] = 1;
  stateWaitForTimeout[4] = false;

  stateName[5] = "Fire";
  stateTransitionOnTimeout[5] = "Ready";
  stateTimeoutValue[5] = 0.2;
  stateFire[5] = true;
  stateSequence[5] = "Fire";
  stateScript[5] = "onFire";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = false;
};

function gc_FLGrenadeImage::onCharge(%this,%obj,%slot)
{
  %obj.playthread(2,shiftLeft);
  %obj.lastGrenadeSlot = %obj.currTool;
  %obj.CookingTastyGrenades = schedule(3000,0,gc_CookedFLGrenade,%obj);
  %obj.CookingTime = getSimTime();
}

function gc_FLGrenadeImage::onAbortCharge(%this,%obj,%slot) {
  %obj.playthread(2,root);
  cancel(%obj.CookingTastyGrenades); }
function gc_FLGrenadeImage::onUnMount(%this,%obj,%slot) {
  cancel(%obj.CookingTastyGrenades);
  parent::onUnMount(%this,%obj,%slot); }

function gc_FLGrenadeImage::onFire(%this,%obj,%slot)
{
  %obj.playthread(2,activate);
  cancel(%obj.CookingTastyGrenades);
  if((getSimTime()-%obj.CookingTime) >= 2900) return;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity);
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  %p.schedule(3000-(getSimTime()-%obj.CookingTime),Explode);
  MissionCleanup.add(%p);
  %currSlot = %obj.lastGrenadeSlot;
  %obj.tool[%currSlot] = 0;
  %obj.weaponCount--;
  messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
  serverCmdUnUseTool(%obj.client);
}

function gc_CookedFLGrenade(%obj)
{
  %currSlot = %obj.lastGrenadeSlot;
  %obj.tool[%currSlot] = 0;
  %obj.weaponCount--;
  messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
  serverCmdUnUseTool(%obj.client);
  %p = new Projectile()
  {
    dataBlock = gc_FLGrenadeProjectile;
    initialVelocity = 0;
    initialPosition = %obj.getPosition();
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  %p.schedule(50,Explode);
  MissionCleanup.add(%p);
}
