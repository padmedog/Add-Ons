if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::Hooks::ServerControl)
		exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");
	RTB_registerPref( "First Person only", "Parkour Playertype", "$PlayerParkour::FirstPersonOnly", "bool", "Player_Parkour", true, true, false, "");
	RTB_registerPref( "Speed Vignette", "Parkour Playertype", "$PlayerParkour::speedVignette", "bool", "Player_Parkour", true, false, false, "");
	RTB_registerPref( "First-Person Hands", "Parkour Playertype", "$PlayerParkour::FPSHands", "bool", "Player_Parkour", true, false, true, "");
}
else
{
	if($Pref::Server::PlayerParkour::FirstPersonOnly $= "")
		$Pref::Server::PlayerParkour::FirstPersonOnly = 0;
	if($Pref::Server::PlayerParkour::speedVignette $= "")
		$Pref::Server::PlayerParkour::speedVignette = 1;
	if($Pref::Server::PlayerParkour::FPSHands $= "")
		$Pref::Server::PlayerParkour::FPSHands = 1;
}

//			v Datablocks v

datablock AudioDescription( AudioSilent3d : AudioClose3d )
{
	volume = 0.8;
	maxDistance = 15;
};

datablock audioProfile( ninjaImpactSound )
{
	fileName = "base/data/sound/northImpact.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( ninjaJumpSound )
{
	fileName = "base/data/sound/northToss.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( ninjaFootstepSound )
{
	fileName = "./sounds/step.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( parkourClimbSound )
{
	fileName = "./sounds/climb.wav";
	description = audioClosest3D;
	preload = true;
};
datablock audioProfile( parkourWalljumpSound )
{
	fileName = "./sounds/walljump.wav";
	description = audioClosest3D;
	preload = true;
};
datablock audioProfile( parkourGrabSound )
{
	fileName = "./sounds/grab.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( parkourLedgejumpSound )
{
	fileName = "./sounds/ledgejump.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( parkourSlipSound )
{
	fileName = "./sounds/slip.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( parkourSlideSound )
{
	fileName = "./sounds/slide.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( parkourFallSound )
{
	fileName = "./sounds/fall.wav";
	description = audioClosest3D;
	preload = true;
};
datablock audioProfile( parkourFallSoftSound )
{
	fileName = "./sounds/fallsoft.wav";
	description = audioClosest3D;
	preload = true;
};
datablock audioProfile( parkourRollSound )
{
	fileName = "./sounds/roll.wav";
	description = audioSilent3D;
	preload = true;
};
datablock audioProfile( parkourWallRun1Sound )
{
	fileName = "./sounds/concrete1.wav";
	description = audioClosest3D;
	preload = true;
};
datablock audioProfile( parkourWallRun2Sound )
{
	fileName = "./sounds/concrete2.wav";
	description = audioClosest3D;
	preload = true;
};

//Sexy visible hands thingy here.
datablock ShapeBaseImageData( parkourLeftHandImage )
{
	shapeFile = "./lHand.dts";
	emap = true;

	mountPoint = 1;

	doColorShift = true;
	colorShiftColor = "1.0 0.878 0.612 1.0";

	eyeoffset = "";
	offset = "0 0.2 0";
};

datablock ShapeBaseImageData( parkourRightHandImage )
{
	shapeFile = "./rHand.dts";
	emap = true;

	mountPoint = 0;

	doColorShift = true;
	colorShiftColor = "1.0 0.878 0.612 1.0";

	eyeoffset = "";
	offset = "0 0.2 0";
};

datablock ShapeBaseImageData( parkourLeftShoeImage )
{
	shapeFile = "./lfoot.dts";
	emap = true;

	mountPoint = 4;

	doColorShift = true;
	colorShiftColor = "0.2 0.2 0.2 1.0";

	eyeoffset = "";
	offset = "0 0.05 0.15";
};

datablock ShapeBaseImageData( parkourRightShoeImage )
{
	shapeFile = "./rfoot.dts";
	emap = true;

	mountPoint = 3;

	doColorShift = true;
	colorShiftColor = "0.2 0.2 0.2 1.0";

	eyeoffset = "";
	offset = "0 0.05 0.15";
};

datablock staticShapeData( cubeShapeData )
{
	shapeFile = "./cube.dts";
};


//			^ Datablocks ^

exec("./Player_Parkour.cs");
exec("./package.cs");
exec("./support.cs");