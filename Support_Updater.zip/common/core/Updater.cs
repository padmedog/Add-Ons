//Handles startup tasks and initializes update check.
function Updater::onAdd(%this)
{
	//Startup
	%this.add(%this.repositories = new ScriptGroup()
	{
		class = UpdaterRepoHandlerSG;
	});
	%this.add(%this.addons = new ScriptGroup()
	{
		class = UpdaterAddOnHandlerSG;
		parent = %this;
	});
	%this.add(%this.queue = new ScriptGroup()
	{
		class = UpdaterQueueSG;
	});
	
	//This repository is for "community updates".
	%repo = UpdaterRepoSO("http://mods.greek2me.us/third-party");
	%this.repositories.add(%repo);
	
	//Query
	%datetime = getDateTime();
	%last = $Pref::Updater::LastQueryDate;
	%interval = $Pref::Updater::QueryInterval;
	%this.addons.readLocalFiles();
	if($Updater::ManualQuery || !strLen(%last) || DT_getDayDifference(%last, %datetime) >= %interval)
	{
		$Pref::Updater::LastQueryDate = %datetime;
		%this.schedule(100, "checkForUpdates");
	}
	
	%this.checkDayTick(getWord(%datetime, 0));
}

//Handles cleanup tasks.
function Updater::onRemove(%this)
{

}

//Connects to repositories and looks for updates.
function Updater::checkForUpdates(%this)
{
	//clear the queue
	if(!isObject(%this.queue.currentDownload))
		%this.queue.removeAll();

	for(%i = %this.repositories.getCount() - 1; %i >= 0; %i --)
	{
		%repo = %this.repositories.getObject(%i);
		if(%repo.isFallback)
			continue;
		%repo.queried = false;
		%repo.queryRemote();
	}
}

//Downloads and installs selected updates.
function Updater::doUpdates(%this)
{
	%this.queue.downloadNext();
}

//Checks for updates on a large interval.
//@param	string date
function Updater::checkDayTick(%this, %date)
{
	%datetime = getDateTime();
	%newDate = getWord(%datetime, 0);
	
	if(%newDate !$= %date)
	{
		%last = $Pref::Updater::LastQueryDate;
		%interval = $Pref::Updater::QueryInterval;
		if(!strLen(%last) || DT_getDayDifference(%last, %datetime) >= %interval)
		{
			$Pref::Updater::LastQueryDate = %datetime;
			%this.checkForUpdates();
		}
	}
	
	if(isEventPending(%this.checkDaySched))
		cancel(%this.checkDaySched);
	%this.checkDaySched = %this.scheduleNoQuota(30000, checkDayTick, %newDate);
}