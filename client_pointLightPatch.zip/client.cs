//v7
function applyPointLightPatchShader()
{
	echo("Applying point light patch");
	%timeStart = getSimTime();

	%destFile = new FileObject();
	%destFile.openForWrite("shaders/common.glsl");

	%sourceFile = new FileObject();
	%sourceFile.openForRead("Add-Ons/client_pointLightPatch/common.glsl");

	while(!%sourceFile.isEOF())
	{
		%destFile.writeLine(%sourceFile.readLine());
	}

	%sourceFile.close();
	%sourceFile.delete();

	%destFile.close();
	%destFile.delete();

	%time = getSimTime() - %timeStart;

	echo("Done (" @ %time @ "ms)");
}

if(getBuildNumber() != 1715)
{
	warn("client_pointLightPatch: Point light patch not applied, game version not supported.");
	warn("   Game Version: " @ getBuildNumber());
	warn("   Patch Version: Revision 1715");
	return;
}
else
{
	applyPointLightPatchShader();
}