package ZombieOverwritePackage
{
	function paintprojectile::OnCollision(%this,%obj,%col,%a,%b,%c,%d)
	{
		parent::OnCollision(%this,%obj,%col,%a,%b,%c,%d);

		if(isobject(%col.attachment))
		%col.attachment.setnodecolor("ALL",getwords(getColorIdTable(%col.colorID),0,2) SPC "1");
	}

	function Armor::onCollision(%this, %obj, %col, %thing, %other)
	{
		if(%col.dataBlock $= "RMedKitItem" && isObject(%obj.client.minigame) && %col.pickupNow !$= 1)
		{
			if(!isObject(%col.spawnbrick))	
			{
				if((%obj.getDamageLevel() >= 1) && %obj.client.minigame $= %col.minigame)
				{
					%obj.setDamageLevel(0);
					%obj.emote(RHealImage);
					%col.delete();
				}
				else
					%col.pickupNow = 1;
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %thing, %others);
	}

	function servercmddropplayeratcamera(%client)
	{
		if(%client.minigame.playersCanRespawn == 1)
		{
			if(!isobject(%client.player) || %client.player.getstate $= "Dead")
			{
				messageclient(%client,'',"<color:FF00FF>By forcing respawn you hereby voided your warranty.");
			}
		}
		parent::servercmddropplayeratcamera(%client);
	}
	function servercmdDropCameraAtPlayer(%client)
	{
		if(%client.minigame.playersCanRespawn == 1)
		{
			//messageclient(%client,'',"<color:FF00FF>By forcing respawn you hereby void your warranty.");
		}
		parent::servercmdDropCameraAtPlayer(%client);
	}
	function Armor::onAdd(%this,%obj,%a,%b,%c,%d)
	{
		//echo(wtf);
		if(%obj.client.minigame.EnableZombies == 1)
		{
			//echo("ZombSurv onadd");
			%obj.client.NoRespawn = 0;
			if($newspawnsystem == 1)
			{
			//ZombieSpawnSearchLoop(%obj.client.minigame);
			}
		}
		parent::onAdd(%this,%obj,%a,%b,%c,%d);

	}
	function Armor::ondisabled(%this,%obj,%n,%a,%b,%c,%d,%e)
	{	
		//echo(wtfs);
		//%obj.getdatablock().isSurvivor && 
		if(%obj.isdowned != 1 && IsInMiniGame(%obj))
		{
			////echo("ZombSurv ondead");
			//echo(%n);
			if(%obj.ispilot())Armor::DoDismount(%obj.getdatablock(),%obj);

			if(%obj.iszombie == 1)
			{
				parent::ondisabled(%this,%obj,%n);
				return;
			}
			if(%obj.client.minigame.EnableDowned == 1)
			{
				if(isobject(%obj.downer))
				{
					chatMessageTeam(%obj.client,'fakedeathmessage',"<color:FFFF00>Zombie" SPC %obj.downer.name SPC "<bitmapk:add-ons/gamemode_zombie/downci2>" SPC %obj.client.name);
				}
				%obj.client.centerprint("<color:FFBBBB>You've been downed.",10);
				%obj.lastknowndatablock = %obj.getdatablock();
				%obj.changedatablock("DownPlayerSurvivorArmor");
				%obj.playaudio(2,helpmesound);
				%obj.setdamagelevel(0);
				%obj.playthread(0,sit);
				%obj.isdowned = 1;
				%obj.mountimage(SaveMeGreenImage,2);
				
				DownPlayerScramble(%obj);
				%obj.setenergylevel(100);
				//%obj.setrechargerate(0);
				%obj.playaudio(1,helpsound);
				energydamageloop(%obj);
				//parent::ondisabled(%this,%obj,%n);
				if(%obj.client.minigame.PlayersCanRespawn == 1 )
				{
					%obj.client.NoRespawn = 1;
					%obj.client.lastplayerobserved = 0;
					zIsEveryoneDead(%obj.client.minigame);
					%obj.client.minigame.NumDead+=1;
				}
				return;
			}
			if(%obj.client.minigame.EnableDowned == 0)
			{
					if(%obj.client.minigame.PlayersCanRespawn == 1 )
					{
						%obj.client.NoRespawn = 1;
						%obj.client.lastplayerobserved = 0;
						zIsEveryoneDead(%obj.client.minigame);
						%obj.client.minigame.NumDead+=1;
					}
			}
			
			//%obj.helpsched = schedule(10000,0,servercmdhelp,%obj.client);
			//%obj.deathsched = schedule(10000,0,downplaykill,%obj);
			//parent::ondisabled(%this,%obj);
			//echo("not too sure what to do here in ondisabled, just checking");
		}
		parent::ondisabled(%this,%obj,%n,%a,%b,%c,%d,%e);
		return;
	}
	function armor::onTrigger(%this,%obj,%a,%b)
	{
		if(%obj.getclassname() $= "Player")
		{
			if(isobject(%obj.getmountedimage(0)) && %obj.getmountedimage(0).getname() $= "RMedKitImage" && %obj.getDamageLevel() > 0 && %obj.isdowned != 1)
			{
				if(%a == 0 && %b == 1)
				{
					%obj.client.camera.setmode("Healing");
					%obj.client.setcontrolobject(%obj.client.camera);
					%obj.client.camera.setorbitmode(%obj,RotTestFive(%obj.client),2,6,2,0);
					%obj.playthread(3,shiftup);
					%obj.RMedKitS = schedule(3000,%obj,RMedKitHealDelay,%obj);
					%obj.imHealing = 1;
					%obj.playaudio(1,RBandageSound);
				}
				if(%a == 0 && %b == 0)
				{
					//%obj.client.camera.mode = "Observer";
					//%obj.client.setcontrolobject(%obj);
				}
				return;
			}
			//echo(%a SPC %b);
			if(%a == 4 && %obj.getdatablock().canJet != 1 && %b == 1 && %obj.meleetimeout != 1 && %obj.client.minigame.ZombieMelee)
			{
				//echo("Raycast from the world of TOMORROW!!!!");
				MeleeMe(%obj);
				if(%obj.isdowned != 1)
				{
					%obj.playthread(3,activate2);
				}
				%obj.meleetimeout = 1;
				schedule(300,0,MeleeTimeout,%obj);
			}
			//%a == 0 && %obj.getdatablock().isSurvivor == 1 && 
			if(%a == 0 && %b == 1)
			{
				//echo("Timer from the world of TOMORROW!!!!");
				//%obj.playthread(1,armreadyright);
				Getupnow(%obj);
			}
			if(%a == 0 && %b == 0)
			{
				//echo("Timer from the world of TOMORROW!!!!");
				if(%obj.issavior == 1)
				{
					if(%obj.getmountedimage(0) == 0)
					{
					%obj.stopthread(1);
					}
					%obj.issavior = 0;
					
				}
				%obj.savetimer = 0;
				//%obj.stopthread(1);
				cancel(%obj.savesched);
			}
		}
		parent::onTrigger(%this,%obj,%a,%b);
	}
	function Player::changedatablock(%a,%b,%c,%d,%e,%f)
	{
		//echo(%a SPC %b SPC %c SPC %d);
		//echo("This is a blank");
		parent::changedatablock(%a,%b,%c,%d,%e,%f);
	}
	function Armor::onImpact(%a,%b,%c,%d,%e,%f)
	{
		//echo(%b.getclassname());
		if(isobject(%b.spawnbrick) && %e >= 20 && %b.getstate() !$= "Dead")
		{
			if(%b.minigame.fallingdamage == 0)return;

			%b.damage(%b,%b,300,"suicide");
			return;
		}
		parent::onImpact(%a,%b,%c,%d,%e,%f);
	}
	//function MiniGameSO::updatePlayerDatablock(%minigame)
	//{

	//	parent::updatePlayerDatablock(%minigame);
	//}
	function servercmdCreateMinigame(%client,%name,%a,%b)
	{
		parent::servercmdCreateMinigame(%client,%name,%a,%b);
		//commandtoclient(%client,'SendZombieMinigamePrefs');
		//echo("MinigameCreate");
		%client.minigame.NumDead = 0;
		%client.minigame.survivorsOverwhelmed = 0;
		//echo(%client.minigame);
		if(%client.minigame.zombieDirectorEnabled)
		{
			ClearMinigameRotZombies(%client.minigame);
			cancel(%client.minigame.ZSS);
			ZombieSpawnSearchLoop(%client.minigame);
			%client.minigame.NumZombies = 0;
		}
		//commandtoclient(%client,'SendZombieMinigamePrefs');
	}
	function servercmdResetMinigame(%client,%a,%b)
	{
		//echo("ResetMinigame");
		if(%client.minigame.zombieDirectorEnabled)
		{
			ClearMinigameRotZombies(%client.minigame);
			%client.minigame.NumZombies = 0;
			%client.minigame.zombieIsPanic = 0;
			cancel(%client.minigame.ZPS);
			//cancel(%client.minigame.ZSS);
			//ZombieSpawnSearchLoop(%client.minigame);
		}
		%client.minigame.survivorsOverwhelmed = 0;
		%client.minigame.NumDead = 0;
		parent::servercmdResetMinigame(%client,%a,%b);
		//commandtoclient(%client,'SendZombieMinigamePrefs');
	}
	function ServerCmdSetMiniGameData(%client,%a,%b)
	{
		//echo("SetMinigameData");
		//%client.minigame.NumDead = 0;
		//%client.minigame.NumZombies = 0;
		parent::ServerCmdSetMiniGameData(%client,%a,%b);
		commandtoclient(%client,'SendZombieMinigamePrefs');
	}
	function MiniGameSO::Reset(%minigame,%a,%b,%c)
	{
		//echo("MinigameResetSO");
		if(%minigame.zombieDirectorEnabled)
		{
			ClearMinigameRotZombies(%minigame);
			%minigame.NumZombies = 0;
			//echo("Reset Minigame");
			cancel(%minigame.ZSS);
			%client.minigame.zombieIsPanic = 0;
			cancel(%client.minigame.ZPS);
			ZombieSpawnSearchLoop(%minigame);
		}
		//echo("john hughes");
		%minigame.NumDead = 0;
		%minigame.survivorsOverwhelmed = 0;
		parent::Reset(%minigame,%a,%b,%c);
	}
	//function CreateMiniGameSO(%a, %b, %c, %d, %e, %f)
	//{
	//	echo(%a SPC %b SPC %c SPC %d SPC %e SPC %f);
	///	parent::CreateMiniGameSO(%a, %b, %c, %d, %e, %f);
	//}
function WheeledVehicleData::onCollision(%a,%obj,%col,%b,%c)
{
	if(%col.isdowned)
	{
		return;
	}
	if(IsInMiniGame(%col))
	{
		if(%col.iszombie && %col.spawnbrick.getgroup().client.minigame.ZombieCanDrive == 0)
		{
			return;
		}
	}
	parent::onCollision(%a,%obj,%col,%b,%c);
}
function observer::onTrigger(%this,%observer,%a,%b)
{
	if(isobject(%observer.getcontrollingclient().player) && isobject(%observer.getcontrollingclient().player.getmountedimage(0)) && %observer.getcontrollingclient().player.imHealing && %observer.getcontrollingclient().player.getmountedimage(0).getname() $= "RMedKitImage" && %a == 0 && %b == 0)
	{
		cancel(%observer.getcontrollingclient().player.RMedKitS);
		//%observer.camera.mode = "Observer";
		%observer.getcontrollingclient().player.imHealing = 0;
		%observer.getcontrollingclient().player.playthread(3,undo);
		%observer.getcontrollingclient().player.playaudio(1,errorSound);
		%observer.getcontrollingclient().setcontrolobject(%observer.getcontrollingclient().player);
	}
	if(isobject(%observer.getcontrollingclient().minigame) && %observer.getcontrollingclient().minigame.PlayersCanRespawn == 1 && %observer.getcontrollingclient().NoRespawn == 1 && isobject(%observer.getcontrollingclient().player) != 1)
		{
			%client = %observer.getcontrollingclient();
			%minigame = %client.minigame;
			if(%observer.getcontrollingclient().NoRespawn == 1 && %a == 0 && %b == 1)
			{
				%targ = findNextMinigamePlayer(%minigame,%client);
				if(isobject(%targ.player))
				{
				%client.centerprint();
				%client.Bottomprint("<color:AAFFAA><just:center>Spectating :" SPC %targ.name,3);
				%observer.setmode(corpse,%targ.player);
				}
				else
				{
				%client.Centerprint("<color:FFBBBB>" @ %targ.name SPC ": Dead",3);
				}
				return;
			}
			if(%observer.getcontrollingclient().NoRespawn == 1 && %a == 4 && %b == 1)
			{
				%targ = findPrevMinigamePlayer(%minigame,%client);
				if(isobject(%targ.player))
				{
				%client.centerprint();
				%client.Bottomprint("<color:AAFFAA><just:center>Spectating :" SPC %targ.name,3);
				%observer.setmode(corpse,%targ.player);
				}
				else
				{
				%client.Centerprint("<color:FFBBBB>" @ %targ.name SPC ": Dead",3);
				}
				return;
			}
			return;
		}
		parent::onTrigger(%this,%observer,%a,%b);
	}
function ProjectileData::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	if(isobject(%col) && %col.getclassname() $= "AiPlayer" && %col.iszombie && IsInMinigame(%obj.sourceobject) && IsInSameMinigame(%obj.sourceobject,%col) && MinigameIncludesPlayerBricks(%col) == 1 && %col.spawnbrick.getgroup().client.minigame.EnableZombies == 1 && $pref::Server::ZombiesEnabled == 1 && %obj.sourceobject != %col)
	{
		%ret = 0;
		if(%obj.sourceobject.getclassname() $= "Player" && %col.isgoodguy == 1 && %obj.sourceobject.client.tdmTeam == %col.spawnbrick.getgroup().client.tdmTeam)%ret = 1;
		
		if(%ret != 1)
		{
			if(%col.getdatablock().OneAtATime != 1)
			{
				%col.zFollow(%obj.sourceobject);
			}
			if(%col.getdatablock().OneAtATime == 1 && %col.isfollowing == 0)
			{
				%col.zFollow(%obj.sourceobject);
			}
			if(%col.getdatablock().SpecialAttack ==1)
			{
				%col.SpecialAttack(1);
			}
			if(%col.spawnbrick.getgroup().client.minigame.ZombieCanJump)
			{
				ZombieJumpSearch(%col);
			}
			if(%player.isstrangling != 1)
			{
				cancel(%col.searchsched);
				%col.searchsched = schedule(3000,0,playersearchloop,%col);
			}
		}
	}

	if(%obj.sourceobject.getclassname() $= "AiPlayer" && %col.getclassname() $= "Player" && %obj.sourceobject.isGoodGuy == 1 && %obj.sourceobject.spawnbrick.getgroup().client.tdmTeam == %col.client.tdmTeam)return;
	if(isobject(%obj.sourceobject) && isobject(%col) && %obj.sourceobject.getclassname() $= "Player" && %col.iszombie)
	{
		%col.RLastA = %obj.sourceobject;
	}
	if(isobject(%obj.sourceobject) && isobject(%col) && %obj.sourceobject.getclassname() $= "Player" && %col.getclassname() $= "Player" && IsInSameMinigame(%obj.sourceobject,%col) && %obj.sourceobject.client.minigame.zombieFriendlyFire == 0)
	{
		return;
	}
	Parent::damage(%this,%obj,%col,%fade,%pos,%normal);
	if(%col.getclassname() $= "AiPlayer" && %col.iszombie && IsInMinigame(%obj.sourceobject) && IsInSameMinigame(%obj.sourceobject,%col) && MinigameIncludesPlayerBricks(%col) == 1 && %col.getstate() !$= "Dead")
	{
		%col.playaudio(0,ZombiePainSound);
	}
	if(%col.getclassname() $= "AiPlayer" && %col.getstate() $= "Dead" && %col.allinc != 1)
	{
		%col.allinc = 1;
		%obj.client.incscore(%col.spawnbrick.getgroup().client.minigame.Points_KillZombie);
	}
}
function ProjectileData::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt)
{
	if(isobject(%col) && %col.getclassname() $= "AiPlayer" && %col.getstate() !$= "Dead" && %col.iszombie && IsInMinigame(%obj.sourceobject) && IsInSameMinigame(%obj.sourceobject,%col) && MinigameIncludesPlayerBricks(%col) == 1 && %col.spawnbrick.getgroup().client.minigame.EnableZombies == 1 && $pref::Server::ZombiesEnabled == 1 && %obj.sourceobject != %col)
	{
		%ret = 0;
		if(%obj.sourceobject.getclassname() $= "Player" && %col.isgoodguy == 1 && %obj.sourceobject.client.tdmTeam == %col.spawnbrick.getgroup().client.tdmTeam)%ret = 1;
		
		if(%ret != 1)
		{
			if(%col.getdatablock().OneAtATime != 1)
			{
				%col.zFollow(%obj.sourceobject);
			}
			if(%col.getdatablock().OneAtATime == 1 && %col.isfollowing == 0)
			{
				%col.zFollow(%obj.sourceobject);
			}
			if(%col.getdatablock().SpecialAttack ==1)
			{
				%col.SpecialAttack(1);
			}
			if(%col.spawnbrick.getgroup().client.minigame.ZombieCanJump)
			{
				ZombieJumpSearch(%col);
			}
			if(%player.isstrangling != 1)
			{
				cancel(%col.searchsched);
				%col.searchsched = schedule(3000,0,playersearchloop,%col);
			}
		}
	}
	if(isobject(%obj.sourceobject) && %obj.sourceobject.getclassname() $= "AiPlayer" && %col.getclassname() $= "Player" && %obj.sourceobject.isGoodGuy == 1 && %obj.sourceobject.spawnbrick.getgroup().client.tdmTeam == %col.client.tdmTeam)return;
	//if(isobject(%obj.sourceobject) && %obj.sourceobject.getclassname() $= "AiPlayer" && %col.getclassname() $= "Player" && %obj.sourceobject.isGoodGuy == 1)return;
	if(isobject(%obj.sourceobject) && isobject(%col) && %obj.sourceobject.getclassname() $= "Player" && %col.iszombie)
	{
		%col.RLastA = %obj.sourceobject;
	}
	if(isobject(%obj.sourceobject) && isobject(%col) && %obj.sourceobject.getclassname() $= "Player" && %col.getclassname() $= "Player" && IsInSameMinigame(%obj.sourceobject,%col) && %obj.sourceobject.client.minigame.zombieFriendlyFire == 0)
	{
		//echo("This");
		return;
	}
	parent::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt);
	if(%col.getclassname() $= "AiPlayer" && %col.iszombie && IsInMinigame(%obj.sourceobject) && IsInSameMinigame(%obj.sourceobject,%col) && MinigameIncludesPlayerBricks(%col) == 1 && %col.getstate() !$= "Dead")
	{
		%col.playaudio(0,ZombiePainSound);
	}
	if(%col.getclassname() $= "AiPlayer" && %col.getstate() $= "Dead" && %col.allinc != 1)
	{
		%col.allinc = 1;
		%obj.client.incscore(%col.spawnbrick.getgroup().client.minigame.Points_KillZombie);
	}
}

function ProjectileData::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	if(%col.getclassname() $= "WheeledVehicle" && %col.getdatablock().getname() $= "PropaneTankCol")
	{
		%col.boom = new Projectile()
		{
			dataBlock = PropaneTankFinalExplosionProjectile;
			initialVelocity = "0 0 0";
			initialPosition = vectoradd(%col.getposition(),"0 0 1");
			Position = vectoradd(%col.getposition(),"0 0 2");
			originpoint = vectoradd(%col.getposition(),"0 0 1");
			scale = "1 1 1";
			client = %col.creator.client;
			sourceObject = %col.creator;
			sourceSlot = 0;
		};
		MissionCleanup.add(%col.boom);
		//%col.boom.dump();
		%col.boom.explode();
		%col.delete();
		return;
	}

	if(isobject(%obj.sourceobject) && isobject(%col) && %obj.sourceobject.getclassname() $= "Player" && %col.getclassname() $= "Player" && IsInSameMinigame(%obj.sourceobject,%col) && %obj.sourceobject.client.minigame.zombieFriendlyFire == 0)
	{
		return;
	}
	if(isobject(%obj.sourceobject) && %obj.sourceobject.getclassname() $= "AiPlayer")
	{
		//echo("100% called");
		%obj.client = %obj.sourceobject;
	}
	if(%col.getclassname() $= "AiPlayer" && %col.isGoodGuy && %obj.sourceobject.isGoodGuy && %obj.sourceobject.spawnbrick.getgroup().client.tdmTeam == %col.spawnbrick.getgroup().client.tdmTeam)return;

	parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
}



	function ItemData::onCollision(%data,%obj,%col)
	{
		parent::oncollision(%data,%obj,%col);
		
	}
	function armor::onCollision(%this, %obj, %col, %fade, %pos, %norm)
	{
		if(%col.getdatablock().getname() $= "RAmmoCrateItem" && %col.iszombie != 1)
		{
			if(isObject(%obj.getmountedimage(0)) && IsInMinigame(%obj) && %obj.getmountedimage(0).melee != 1  && MinigameIncludesItem(%col) && %col.isshutting != 1)
			{
				if(%obj.zombieammo[%obj.getmountedimage(0).projectile] == -1)
					{	
						%obj.zombieammo[%obj.getmountedimage(0).projectile] = 1;
						%obj.mountimage(%obj.getmountedimage(0).RWep,0);
						if(%col.isopen == 0)
						{
							HealthlockerAnim(%col,1);
						}
						cancel(%col.closedoor);
						%col.closedoor = schedule(600,0,HealthlockerAnim,%col,0);
					}
				if($zombie::ammo::Ammo[%obj.getmountedimage(0).projectile] > 0)
				{
					if(%obj.zombieammo[%obj.getmountedimage(0).projectile] < $zombie::ammo::Ammo[%obj.getmountedimage(0).projectile])
					{

						%obj.zombieammo[%obj.getmountedimage(0).projectile]++;
						if($zombie::ammo::Ammo[%obj.getmountedimage(0).projectile] >= 30 && %obj.getmountedimage(0).projectile.getname !$= "MiniGunProjectile")
						{
							%obj.zombieammo[%obj.getmountedimage(0).projectile]+=4;
						}
						if(%obj.getmountedimage(0).projectile.getname $= "MiniGunProjectile")
						{
							%obj.zombieammo[%obj.getmountedimage(0).projectile]++;
						}
						%obj.playaudio(1,ammocratesound);
						bottomprintremainingammo(%obj,%obj.getmountedimage(0));
						if(%col.isopen == 0)
						{
							HealthlockerAnim(%col,1);
						}
						cancel(%col.closedoor);
						%col.closedoor = schedule(600,0,HealthlockerAnim,%col,0);
					}
					if(%obj.zombieammo[%obj.getmountedimage(0).projectile] > $zombie::ammo::Ammo[%obj.getmountedimage(0).projectile])
					{
						%obj.zombieammo[%obj.getmountedimage(0).projectile] = $zombie::ammo::Ammo[%obj.getmountedimage(0).projectile];
						%obj.playaudio(1,ammocratesound);
						bottomprintremainingammo(%obj,%obj.getmountedimage(0));
						if(%col.isopen == 0)
						{
							HealthlockerAnim(%col,1);
						}
						cancel(%col.closedoor);
						%col.closedoor = schedule(600,0,HealthlockerAnim,%col,0);
					}
				}
				else
				{
					if(%obj.zombieammo[%obj.getmountedimage(0).projectile] < 20)
					{
						%obj.zombieammo[%obj.getmountedimage(0).projectile]++;
						%obj.playaudio(1,ammocratesound);
						bottomprintremainingammo(%obj,%obj.getmountedimage(0));
						if(%col.isopen == 0)
						{
							HealthlockerAnim(%col,1);
						}
						cancel(%col.closedoor);
						%col.closedoor = schedule(600,0,HealthlockerAnim,%col,0);
					}
				}
			}
			return;
		}
		if(%col.getdatablock().getname() $= "RHealthLockerItem" && %col.iszombie != 1)
		{
			if(IsInMinigame(%obj) && MinigameIncludesItem(%col) && %obj.getdamagelevel() > 0 && %obj.getstate() !$= "Dead" && %col.isshutting != 1)
			{
				%obj.addhealth(5);
				%obj.mountimage(RHealImage,2);
				%obj.playaudio(2,PrintFireSound);
				if(%col.isopen == 0)
				{
					HealthlockerAnim(%col,1);
				}
				cancel(%col.closedoor);
				%col.closedoor = schedule(600,0,HealthlockerAnim,%col,0);
			}
			return;
		}
		if(%obj.getclassname() $= "AiPlayer")
		{
			parent::onCollision(%this, %obj, %col, %fade, %pos, %norm);
			return;
		}
		if(IsInMinigame(%obj))
		{
			for(%i=0;%i<5;%i++)
				{
					%toolDB = %obj.tool[%i].image;
						if(%toolDB $= %col.getdatablock().image)
						{
							return;
							break;
						}
				}
			if(%col.getclassname()$= "Item" && isobject(%col.spawnbrick))
			{
				%col.RemAmmo = 0;
			}
			if(%col.getclassname() $= "Item" && %col.RemAmmo != 0)
			{
			%projectile = %col.getdatablock().image.projectile;
			%obj.zombieammo[%col.getdatablock().image.projectile] = %col.RemAmmo;
			}
		}
		parent::onCollision(%this, %obj, %col, %fade, %pos, %norm);
	}
	function ItemData::onAdd(%this,%item)
	{
		parent::onAdd(%this,%item);
		%projectile = %item.getdatablock().image.projectile;
		eval("%item.RemAmmo = $TempAmmohack" @ %projectile @ ";");
		eval("$TempAmmohack" @ %projectile @ "= 0;");
	}
	function servercmdDropTool(%client,%slot)
	{
		%projectile = %client.player.tool[%slot].image.projectile;
		if(%client.player.zombieammo[%projectile] == -1)
		{
			%client.player.unmountimage(0);
			%client.player.unmountimage(1);
		}
		eval("$TempAmmohack" @ %projectile @ "= %client.player.zombieammo[%projectile];");
		%client.player.zombieammo[%projectile] = 0;
		parent::servercmdDropTool(%client,%slot);
	}
	function WeaponImage::onMount(%this,%obj,%slot)
	{
		if(%obj.client.minigame.EnableAmmoMod == 1)
		{
			parent::onMount(%this,%obj,%slot);
			if(%this.melee == 1)
			{
				parent::onMount(%this,%obj,%slot);
				return;
			}
		//%obj.playthread(1,armreadyright);
		//	cancel(%obj.ateasesched);
		//	%obj.ateasesched = schedule(3000,0,atease,%obj);
			if(IsInMinigame(%obj))
			{
			if(%obj.zombieammo[%this.projectile] == -1)
			{
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				if(isobject(%obj.getmountedimage(0).getname() @ "NoFire"))
				{
				%obj.mountimage(%obj.getmountedimage(0).getname() @ "NoFire",0);
				}

				return;

			}
			if(%obj.zombieammo[%this.projectile] <=0)
			{
				for(%a = 0; %a <= $zombie::ammo::Listcount;  %a++)
				{
					if(%this.projectile $= $zombie::ammo::Gun[%a])
					{
						%gunname = $zombie::ammo::Gun[%a];
						%obj.zombieammo[%this.projectile] = $zombie::ammo::Ammo[%gunname];
						return;
					}
				}
				%obj.zombieammo[%this.projectile] = 20;
			}
			//bottomprint(%obj.client,"<just:center>Ammo : " SPC %obj.zombieammo[%this.projectile],5);
			bottomprintremainingammo(%obj,%this);
			}
		}
		parent::onMount(%this,%obj,%slot);
	}
	function WeaponImage::onFire(%this, %obj, %slot)
	{
		if(IsInMinigame(%obj) && %obj.client.minigame.EnableAmmoMod == 1)
		{
					if(%this.melee == 1){
				parent::onFire(%this, %obj, %slot);
				return ;
			}
			if(%obj.zombieammo[%this.projectile] == -1)
			{
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				//%obj.playthread(2,activate2);
				return;

			}
			if(%obj.zombieammo[%this.projectile] >= 1)
			{
				%obj.zombieammo[%this.projectile]--;
				bottomprintremainingammo(%obj,%this);
				parent::onFire(%this, %obj, %slot);
				if(%obj.zombieammo[%this.projectile] == 1 && %this.projectile $= "akimboGunProjectile")
				{
					%obj.zombieammo[%this.projectile]--;
					bottomprintremainingammo(%obj,%this);
				}
			}
			if(%obj.zombieammo[%this.projectile] <= 0)
			{
				%obj.zombieammo[%this.projectile] = -1;
				if(isobject(%obj.getmountedimage(0).getname() @ "NoFire"))
				{
				%obj.mountimage(%obj.getmountedimage(0).getname() @ "NoFire",0);
				}
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				%obj.playaudio(1,ammocratesound);
				%obj.playthread(2,activate2);
				return;
			}
		}
		else
		{
			parent::onFire(%this, %obj, %slot);
		}
	}
	function minigunImage::onFire(%this, %obj, %slot)
	{
		if(IsInMinigame(%obj) && %obj.client.minigame.EnableAmmoMod == 1)
		{
					if(%this.melee == 1){
				parent::onFire(%this, %obj, %slot);
				return ;
			}
			if(%obj.zombieammo[%this.projectile] == -1)
			{
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				//%obj.playthread(2,activate2);
				return;

			}
			if(%obj.zombieammo[%this.projectile] >= 1)
			{
				%obj.zombieammo[%this.projectile]--;
				bottomprintremainingammo(%obj,%this);
				parent::onFire(%this, %obj, %slot);
				if(%obj.zombieammo[%this.projectile] == 1 && %this.projectile $= "akimboGunProjectile")
				{
					%obj.zombieammo[%this.projectile]--;
					bottomprintremainingammo(%obj,%this);
				}
			}
			if(%obj.zombieammo[%this.projectile] <= 0)
			{
				%obj.zombieammo[%this.projectile] = -1;
				if(isobject(%obj.getmountedimage(0).getname() @ "NoFire"))
				{
				//%obj.schedule(1000,mountimage,%obj.getmountedimage(0).getname() @ "NoFire",0);
				%obj.mountimage(%obj.getmountedimage(0).getname() @ "NoFire",0);
				}
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				%obj.playaudio(1,ammocratesound);
				%obj.playthread(2,activate2);
				return;
			}
		}
		else
		{
			parent::onFire(%this, %obj, %slot);
		}
	}
	function shotgunImage::onFire(%this,%obj,%slot)
	{
		if(IsInMinigame(%obj) && %obj.client.minigame.EnableAmmoMod == 1)
		{
					if(%this.melee == 1){
				parent::onFire(%this, %obj, %slot);
				return ;
			}
			if(%obj.zombieammo[%this.projectile] == -1)
			{
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				//%obj.playthread(2,activate2);
				return;

			}
			if(%obj.zombieammo[%this.projectile] >= 1)
			{
				%obj.zombieammo[%this.projectile]--;
				bottomprintremainingammo(%obj,%this);
				parent::onFire(%this, %obj, %slot);
				if(%obj.zombieammo[%this.projectile] == 1 && %this.projectile $= "akimboGunProjectile")
				{
					%obj.zombieammo[%this.projectile]--;
					bottomprintremainingammo(%obj,%this);
				}
			}
			if(%obj.zombieammo[%this.projectile] <= 0)
			{
				%obj.zombieammo[%this.projectile] = -1;
				if(isobject(%obj.getmountedimage(0).getname() @ "NoFire"))
				{
				%obj.mountimage(%obj.getmountedimage(0).getname() @ "NoFire",0);
				}
				BottomPrint(%obj.client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000> NONE",3);
				%obj.playaudio(1,ammocratesound);
				%obj.playthread(2,activate2);
				return;
			}
		}
		else
		{
			parent::onFire(%this, %obj, %slot);
		}
	}
	function AmmoSYSFire(%this,%obj,%slot)
	{
		if(%this.melee == 1){
			return 1;
		}
		if(%obj.zombieammo[%this.projectile] >= 1)
		{
			%obj.zombieammo[%this.projectile]--;
			bottomprintremainingammo(%obj,%this);

		//return 1;
		}
		if(%obj.zombieammo[%this.projectile] <= 0)
		{
		for(%i=0;%i<5;%i++)
		{
		%toolDB = %obj.tool[%i].image;
		if(%toolDB $= %this.getname())
		{
			%obj.tool[%i] = 0;
			%obj.weaponCount--;
			messageClient(%obj.client,'MsgItemPickup','',%i,0);
			serverCmdUnUseTool(%obj.client);
			break;
		}
		}
		//return 1;
		}
	}
	function bottomprintremainingammo(%obj,%this)
	{
		%defammo = $zombie::ammo::Ammo[%this.projectile];
		%ammo = %obj.zombieammo[%this.projectile];
		%client = %obj.client;
		
		if(%defammo <= 0)
		{
			%defammo = 20;
		}
		%per = %ammo/%defammo*100;
		%maxcounters = 20;
		%char = "|";for(%a =0; %a<%per/5; %a++){%fchar = %char @ %fchar;}
		bottomprint(%client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000>" @ %fchar,5);
	}
	function centerprintRemainingCrateAmmo(%obj,%this)
	{
		%defammo = $zombie::ammo::Ammo[%this.projectile];
		%ammo = %obj.zombieammo[%this.projectile];
		%client = %obj.client;
		
		if(%defammo <= 0)
		{
			%defammo = 20;
		}
		%per = %ammo/%defammo*100;
		%maxcounters = 20;
		%char = "|";for(%a =0; %a<%per/5; %a++){%fchar = %char @ %fchar;}
		bottomprint(%client,"<just:center><color:FFFF00>Ammo <color:FFFFFF>: <just:left><color:FF0000>" @ %fchar,5);
	}
	function atease(%obj)
	{
		%obj.playthread(1,root);
	}
function Projectile::onAdd(%this, %obj, %pos,%a,%b,%c)
{
	if(%this.getdatablock().uiname $= "Player Spawn")
	{
		if(%this.sourceobject.iszombie)
		{
			%this.setdatablock(DirectorBlankProjectile);
			%this.sourceobject = "";
			%this.client = "";
			//%this.dump();
		}
	}
	parent::onAdd(%this, %obj, %pos,%a,%b,%c);
}
function ProjectileData::onExplode(%this, %obj, %pos,%a,%b,%c)
{
	if(%this.uiname $= "Player Spawn")
	{
		if(%obj.sourceobject.iszombie)
		{
			//%obj.schedule(0,delete);
			//%obj.delete();
		}
	}
	parent::onExplode(%this, %obj, %pos,%a,%b,%c);
}
};
activatepackage(ZombieOverwritePackage);