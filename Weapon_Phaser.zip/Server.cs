AddDamageType("Phaser_Kill", '%1 fragged himself!', '%2 fragged %1!', 1, 1);
$PhaserRecharge0 = 0.3;
$PhaserMax0 = 30;
$PhaserRecharge1 = 0.4;
$PhaserMax1 = 60;

package Phaser
{
	function AIPlayer::setAimLocation(%bot, %point)
	{
		if(!%bot.botStun)
			Parent::setAimLocation(%bot, %point);
	}
	
	function AIPlayer::setAimObject(%bot, %obj)
	{
		if(!%bot.botStun)
			Parent::setAimObject(%bot, %obj);
	}
	
	function AIPlayer::setImageTrigger(%bot, %slot, %tog)
	{
		if(!%bot.botStun)
			Parent::setImageTrigger(%bot, %slot, %tog);
	}
	
	function AIPlayer::setMoveDestination(%bot, %point)
	{
		if(!%bot.botStun)
			Parent::setMoveDestination(%bot, %point);
	}
	
	function AIPlayer::setMoveObject(%bot, %obj)
	{
		if(!%bot.botStun)
			Parent::setMoveObject(%bot, %obj);
	}
	
	function AIPlayer::setMoveSpeed(%bot, %speed)
	{
		if(!%bot.botStun)
			Parent::setMoveSpeed(%bot, %speed);
	}
	
	function AIPlayer::setMoveX(%bot, %speed)
	{
		if(!%bot.botStun)
			Parent::setMoveX(%bot, %speed);
	}
	
	function AIPlayer::setMoveY(%bot, %speed)
	{
		if(!%bot.botStun)
			Parent::setMoveY(%bot, %speed);
	}
	
	function Armor::onTrigger(%data, %this, %trig, %tog)
	{
		if(isObject(%img = %this.getMountedImage(0)) && (%img.getName() $= "TOS_PhaserI_Image_Stun" || %img.getName() $= "TOS_PhaserI_Image_Kill"))
		{
			if(%trig == 4)
			{
				if(%tog)
					%this.phaserTime = getSimTime();
				else if(vectorDist(%this.phaserTime, getSimTime()) <= 500)
				{
					%state = %this.getImageState(0);
					if(%state $= "Ready")
					{
						if(%img.getName() $= "TOS_PhaserI_Image_Stun")
						{
							%item = TOS_PhaserI_Item_Kill.getID();
							%mode = "Kill";
						}
						else if(%img.getName() $= "TOS_PhaserI_Image_Kill")
						{
							%item = TOS_PhaserI_Item_Stun.getID();
							%mode = "Stun";
						}
						%tool = %this.currTool;
						if(isObject(%cl = %this.client))
						{
							%cl.bottomPrint("\c2Now using phaser mode \c3"@%mode@"\c2!", 3);
							messageClient(%cl, 'MsgItemPickup', '', %tool, %item.getID(), 1);
						}
						%this.tool[%tool] = %item.getID();
						%this.mountImage(%item.image.getID(), 0);
					}
				}
			}
		}
		else if(isObject(%img = %this.getMountedImage(0)) && (%img.getName() $= "TOS_PhaserII_Image_Stun" || %img.getName() $= "TOS_PhaserII_Image_Kill"))
		{
			if(%trig == 4)
			{
				if(%tog)
					%this.phaserTime = getSimTime();
				else if(vectorDist(%this.phaserTime, getSimTime()) <= 500)
				{
					%state = %this.getImageState(0);
					if(%state $= "Ready")
					{
						if(%img.getName() $= "TOS_PhaserII_Image_Stun")
						{
							%item = TOS_PhaserII_Item_Kill.getID();
							%mode = "Kill";
						}
						else if(%img.getName() $= "TOS_PhaserII_Image_Kill")
						{
							%item = TOS_PhaserII_Item_Stun.getID();
							%mode = "Stun";
						}
						%tool = %this.currTool;
						if(isObject(%cl = %this.client))
						{
							%cl.bottomPrint("\c2Now using phaser mode \c3"@%mode@"\c2!", 3);
							messageClient(%cl, 'MsgItemPickup', '', %tool, %item.getID(), 1);
						}
						%this.tool[%tool] = %item.getID();
						%this.mountImage(%item.image.getID(), 0);
					}
				}
			}
		}
		Parent::onTrigger(%data, %this, %trig, %tog);
	}
	
	function GameConnection::bottomPrint(%cl, %msg, %time)
	{
		if(!%cl.dontRecordPrint)
		{
			%cl.lastBottomPrint = %msg;
			cancel(%cl.removeBottomSched);
			if(%time > 0)
				%cl.removeBottomSched = %cl.schedule(%time * 1000, "removePhaserBottomPrint");
		}
		if((%cl.lastBottomPrint@%cl.phaserPrint) $= "")
			commandToClient(%cl, 'clearBottomPrint');
		else
			Parent::bottomPrint(%cl, %msg@%cl.phaserPrint, 0);
	}
	
	function Observer::onTrigger(%data, %this, %trig, %tog)
	{
		if(isObject(%cl = %this.getControllingClient()) && isObject(%pl = %cl.player) && isEventPending(%pl.endPhaserStun))
			return 0;
		return Parent::onTrigger(%data, %this, %trig, %tog);
	}
	
	function servercmdShiftBrick(%cl, %x, %y, %z)
	{
		if(isObject(%pl = %cl.player) && isEventPending(%pl.endPhaserStun))
			return;
		Parent::servercmdShiftBrick(%cl, %x, %y, %z);
	}
	
	function servercmdSuicide(%cl)
	{
		if(isObject(%pl = %cl.player) && isEventPending(%pl.endPhaserStun))
			return;
		Parent::servercmdSuicide(%cl);
	}
	
	function servercmdSupershiftBrick(%cl, %x, %y, %z)
	{
		if(isObject(%pl = %cl.player) && isEventPending(%pl.endPhaserStun))
			return;
		Parent::servercmdSupershiftBrick(%cl, %x, %y, %z);
	}
	
	function servercmdUnuseTool(%cl)
	{
		if(isObject(%pl = %cl.player) && isEventPending(%pl.endPhaserStun))
		{
			return;
			%pl.unuseToolOnStunEnd = 1;
		}
		if(isObject(%cl.player))
			cancel(%cl.player.phaserLoop);
		Parent::servercmdUnuseTool(%cl);
	}
	
	function servercmdUseTool(%cl, %tool)
	{
		if(isObject(%pl = %cl.player) && isEventPending(%pl.endPhaserStun))
		{
			%pl.useToolOnStunEnd = %tool + 1;
			return;
		}
		if(isObject(%cl.player))
			cancel(%cl.player.phaserLoop);
		Parent::servercmdUseTool(%cl, %tool);
	}
	
	function TOS_PhaserI_Item_Stun::onPickup(%data, %item, %pl)
	{
		for(%i=0;%i<%pl.getDatablock().maxTools;%i++)
		{
			%tool = %pl.tool[%i];
			if(%tool == TOS_PhaserI_Item_Stun.getID() || %tool == TOS_PhaserI_Item_Kill.getID())
				return;
		}
		Parent::onPickup(%data, %item, %pl);
	}
	
	function TOS_PhaserI_Item_Kill::onPickup(%data, %item, %pl)
	{
		for(%i=0;%i<%pl.getDatablock().maxTools;%i++)
		{
			%tool = %pl.tool[%i];
			if(%tool == TOS_PhaserI_Item_Stun.getID() || %tool == TOS_PhaserI_Item_Kill.getID())
				return;
		}
		Parent::onPickup(%data, %item, %pl);
	}
	
	function TOS_PhaserII_Item_Stun::onPickup(%data, %item, %pl)
	{
		for(%i=0;%i<%pl.getDatablock().maxTools;%i++)
		{
			%tool = %pl.tool[%i];
			if(%tool == TOS_PhaserII_Item_Stun.getID() || %tool == TOS_PhaserII_Item_Kill.getID())
				return;
		}
		Parent::onPickup(%data, %item, %pl);
	}
	
	function TOS_PhaserII_Item_Kill::onPickup(%data, %item, %pl)
	{
		for(%i=0;%i<%pl.getDatablock().maxTools;%i++)
		{
			%tool = %pl.tool[%i];
			if(%tool == TOS_PhaserII_Item_Stun.getID() || %tool == TOS_PhaserII_Item_Kill.getID())
				return;
		}
		Parent::onPickup(%data, %item, %pl);
	}
};
activatePackage("Phaser");

function mMax(%a, %b)
{
	if(%a > %b)
		return %a;
	return %b;
}

function mMin(%a, %b)
{
	if(%a < %b)
		return %a;
	return %b;
}

datablock AudioProfile(PhaserSound_Stun)
{
	filename = "./Phaser_Stun.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(PhaserSound_FiringStun)
{
	filename = "./Phaser_FiringStun.wav";
	description = AudioClosestLooping3d;
	preload = false;
};

datablock ParticleData(PhaserTracePart_Stun)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;
	colors[0] = "0.0 0.0 1.0 0.9";
	colors[1] = "0.0 0.0 1.0 0.5";
	colors[2] = "0.0 0.0 1.0 0.0";
	sizes[0] = 0.1;
	sizes[1] = 0.1;
	sizes[2] = 0.1;
	times[0] = 0.0;
	times[1] = 0.3;
	times[2] = 1.0;
};

datablock ParticleEmitterData(PhaserTrace_Stun)
{
	ejectionPeriodMS = 1;
	periodVarianceMS = 0;
	ejectionVelocity = 50;
	velocityVariance = 0.0;
	ejectionOffset   = 0;
	thetaMin         = 0;
	thetaMax         = 0;
	phiReferenceVel  = 0;
	phiVariance      = 360;
	overrideAdvance = false;
	particles = "PhaserTracePart_Stun";
	useEmitterColors = false;
	uiName = "Phaser Stun Trace";
};

datablock fxLightData(PhaserLight_Stun : PlayerLight)
{
	color = "0.0 0.0 1.0 1.0";
	flareBitmap = "base/lighting/lightFalloffMono";
	flareColor = "0.0 0.0 1.0 1.0";
	lightOn = 0;
	nearSize = 3;
	uiName = "";   //I so fucked up here - the menu for lights only takes the last one, so these overwrite the default
};

datablock ShapeBaseImageData(TOS_PhaserI_Image_Stun)
{
	shapeFile = "Add-Ons/Weapon_Phaser/TOS Phaser I.dts";
	emap = true;
	mountPoint = 0;
	offset = "-0.015 0.105 0.275";
	eyeOffset = 0;
	rotation = "1 0 0 0";
	correctMuzzleVector = true;
	className = "WeaponImage";
	item = TOS_PhaserI_Item_Stun;
	melee = true;
	armReady = true;
	doRetraction = false;
	doColorShift = false;
	
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "Ready";
	
	stateName[1] = "Ready";
	stateSequence[1] = "Ready";
	stateAllowImageChange[1] = true;
	stateTransitionOnTriggerDown[1] = "Fire";
	
	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateScript[2] = "onFire";
	stateAllowImageChange[2] = false;
	stateTimeoutValue[2] = 0.01;
	stateTransitionOnTimeout[2] = "Fire";
	stateTransitionOnTriggerUp[2] = "Release";
	stateSound[2] = PhaserSound_FiringStun;
	stateEmitter[2] = PhaserTrace_Stun;
	stateEmitterTime[2] = 0.07;
	
	stateName[3] = "Release";
	stateAllowImageChange[3] = false;
	stateTransitionOnTimeout[3] = "Ready";
	stateTimeoutValue[3] = 0.05;
	stateSequence[3] = "Release";
	stateScript[3] = "onStopFire";
	
	phaserType = 0;
};

datablock ItemData(TOS_PhaserI_Item_Stun)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "Add-Ons/Weapon_Phaser/TOS Phaser I.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "TOS Phaser I (Stun)";
	iconName = "Add-Ons/Weapon_Phaser/TOS Phaser I";
	doColorShift = false;
	image = TOS_PhaserI_Image_Stun;
	canDrop = true;
};

function TOS_PhaserI_Image_Stun::onFire(%img, %pl, %slot)
{
	if(!isEventPending(%pl.phaserLoop))
		%pl.phaserLoop = %pl.schedule(50, "phaserILoop_Stun");
	%pl.setImageTrigger(1, 1);
}

function TOS_PhaserI_Image_Stun::onStopFire(%img, %pl, %slot)
{
	cancel(%pl.phaserLoop);
	if(isObject(%cl = %pl.client))
		%cl.phaserPrint = "";
	%pl.setImageTrigger(1, 0);
	%pl.firingPhaser = 0;
}

function Player::phaserILoop_Stun(%pl)
{
	if(!isObject(%pl) || %pl.getState() $= "DEAD")
		return;
	cancel(%pl.phaserLoop);
	%pl.firingPhaser = 1;
	if(%pl.phaserEnergy0 $= "")
		%pl.phaserEnergy0 = $PhaserMax0;
	if(%pl.phaserEnergy0 - 0.3 < 0)
	{
		if(isObject(%cl = %pl.client))
		{
			%cl.centerPrint("\c6Out of energy; stop firing!", 3);
			%cl.phaserPrint("<just:right>\c70 / \c6"@$PhaserMax0, 2);
		}
		%pl.phaserLoop = %pl.schedule(50, "phaserILoop_Stun");
		return;
	}
	else if(isObject(%cl = %pl.client))
		%cl.phaserPrint("<just:right><color:3333FF>"@mCeil(%pl.phaserEnergy0)@"\c7 / \c6"@$PhaserMax0, 2);
	%pl.phaserEnergy0 -= 0.3;
	if(!isEventPending(%pl.phaserRecharge0))
		%pl.phaserRecharge0 = %pl.schedule(100, "phaserLoop_Recharge", 0);
	%muzzle = %pl.getMuzzlePoint(0);
	%muzzVect = phaserSpread(%pl.getMuzzleVector(0), 1);
	%target = vectorAdd(%muzzle, vectorScale(%muzzVect, 250));
	%masks = $Typemasks::fxBrickObjectType | $Typemasks::PlayerObjectType | $Typemasks::StaticObjectType | $Typemasks::TerrainObjectType | $Typemasks::VehicleObjectType;
	%ray = containerRaycast(%muzzle, %target, %masks, %pl);
	%obj = firstWord(%ray);
	if(isObject(%obj))
	{
		%hitPos = getWords(%ray, 1, 3);
		if(minigameCanDamage(%pl, %obj) == 1 && isFunction(%obj.getClassName(), "damage"))
		{
			cancel(%obj.endPhaserStun);
			if(%obj.phaserStunTime == 0)
				serverPlay3D(PhaserSound_Stun, %obj.position);
			else
				%obj.phaserStunTime -= vectorDist(%obj.stunnedAt, getSimTime());
			%obj.stunnedAt = getSimTime();
			if(%obj.phaserStunTime + 150 <= 4000)
				%obj.phaserStunTime += 150;
			%obj.endPhaserStun = %obj.schedule(%obj.phaserStunTime, "endPhaserStun");
			if(%obj.getClassName() $= "AIPlayer")
			{
				%obj.setAimObject(0);
				%obj.setMoveObject(0);
				%obj.setMoveX(0);
				%obj.setMoveY(0);
				for(%i=0;%i<5;%i++)
					%obj.setImageTrigger(%i, 0);
				%obj.botStun = 1;
			}
			else if(isObject(%cl = %obj.client))
				if((!isObject(%cont = %cl.getControlObject()) || %cont.getID() == %obj.getID()) && isObject(%cam = %cl.camera))
				{
					%cl.setControlObject(%cam);
					%cam.setMode("Corpse", %obj);
				}
		}
		%hitPos = vectorAdd(%hitPos, vectorScale(vectorNormalize(vectorSub(%hitPos, %muzzle)), -0.25));
		%emit = new ParticleEmitterNode()
		{
			datablock = GenericEmitterNode;
			emitter = "PhaserBeamEmitter";
			position = %hitPos;
			rotation = "1 0 0 0";
			scale = "0.05 0.05 0.05";
		};
		%emit.setColor("0 0 1 1");
		%emit.schedule(50, "delete");
		if(!isObject(%light = %pl.phaserLight))
			%light = (%pl.phaserLight = new fxLight(){datablock = PhaserLight_Stun;});
		else if(%light.getDatablock().getName() !$= "PhaserLight_Stun")
			%light.setDatablock(PhaserLight_Stun);
		%light.setTransform(%hitPos SPC "1 0 0 0");
		%light.reset();cancel(%light.killSched);
		%light.killSched = %light.schedule(100, "delete");
	}
	%pl.phaserLoop = %pl.schedule(50, "phaserILoop_Stun");
}

datablock ShapeBaseImageData(TOS_PhaserII_Image_Stun)
{
	shapeFile = "Add-Ons/Weapon_Phaser/TOS Phaser II.dts";
	emap = true;
	mountPoint = 0;
	offset = "0.000 -0.325 0.500";
	eyeOffset = 0;
	rotation = "1 0 0 0";
	correctMuzzleVector = true;
	className = "WeaponImage";
	item = TOS_PhaserII_Item_Stun;
	melee = true;
	armReady = true;
	doRetraction = false;
	doColorShift = false;
	
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "Ready";
	
	stateName[1] = "Ready";
	stateSequence[1] = "Ready";
	stateAllowImageChange[1] = true;
	stateTransitionOnTriggerDown[1] = "Fire";
	
	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateScript[2] = "onFire";
	stateAllowImageChange[2] = false;
	stateTimeoutValue[2] = 0.01;
	stateTransitionOnTimeout[2] = "Fire";
	stateTransitionOnTriggerUp[2] = "Release";
	stateSound[2] = PhaserSound_FiringStun;
	stateEmitter[2] = PhaserTrace_Stun;
	stateEmitterTime[2] = 0.07;
	
	stateName[3] = "Release";
	stateAllowImageChange[3] = false;
	stateTransitionOnTimeout[3] = "Ready";
	stateTimeoutValue[3] = 0.05;
	stateSequence[3] = "Release";
	stateScript[3] = "onStopFire";
	
	phaserType = 1;
};

datablock ItemData(TOS_PhaserII_Item_Stun)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "Add-Ons/Weapon_Phaser/TOS Phaser II.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	uiName = "TOS Phaser II (Stun)";
	iconName = "Add-Ons/Weapon_Phaser/TOS Phaser II";
	doColorShift = false;
	image = TOS_PhaserII_Image_Stun;
	canDrop = true;
};

function TOS_PhaserII_Image_Stun::onFire(%img, %pl, %slot)
{
	if(!isEventPending(%pl.phaserLoop))
		%pl.phaserLoop = %pl.schedule(50, "phaserIILoop_Stun");
}

function TOS_PhaserII_Image_Stun::onStopFire(%img, %pl, %slot)
{
	cancel(%pl.phaserLoop);
	if(isObject(%cl = %pl.client))
		%cl.phaserPrint = "";
	%pl.firingPhaser = 0;
}

function Player::phaserIILoop_Stun(%pl)
{
	if(!isObject(%pl) || %pl.getState() $= "DEAD")
		return;
	cancel(%pl.phaserLoop);
	%pl.firingPhaser = 1;
	if(%pl.phaserEnergy1 $= "")
		%pl.phaserEnergy1 = $PhaserMax1;
	if(%pl.phaserEnergy1 - 0.5 < 0)
	{
		if(isObject(%cl = %pl.client))
		{
			%cl.centerPrint("\c6Out of energy; stop firing!", 3);
			%cl.phaserPrint("<just:right>\c70 / \c6"@$PhaserMax1, 2);
		}
		%pl.phaserLoop = %pl.schedule(50, "phaserIILoop_Stun");
		return;
	}
	else if(isObject(%cl = %pl.client))
		%cl.phaserPrint("<just:right><color:3333FF>"@mCeil(%pl.phaserEnergy1)@"\c7 / \c6"@$PhaserMax1, 2);
	%pl.phaserEnergy1 -= 0.5;
	if(!isEventPending(%pl.phaserRecharge1))
		%pl.phaserRecharge1 = %pl.schedule(100, "phaserLoop_Recharge", 1);
	%muzzle = %pl.getMuzzlePoint(0);
	%muzzVect = phaserSpread(%pl.getMuzzleVector(0), 1);
	%target = vectorAdd(%muzzle, vectorScale(%muzzVect, 250));
	%masks = $Typemasks::fxBrickObjectType | $Typemasks::PlayerObjectType | $Typemasks::StaticObjectType | $Typemasks::TerrainObjectType | $Typemasks::VehicleObjectType;
	%ray = containerRaycast(%muzzle, %target, %masks, %pl);
	%obj = firstWord(%ray);
	if(isObject(%obj))
	{
		%hitPos = getWords(%ray, 1, 3);
		if(minigameCanDamage(%pl, %obj) == 1 && isFunction(%obj.getClassName(), "damage"))
		{
			cancel(%obj.endPhaserStun);
			if(%obj.phaserStunTime == 0)
				serverPlay3D(PhaserSound_Stun, %obj.position);
			else
				%obj.phaserStunTime -= vectorDist(%obj.stunnedAt, getSimTime());
			%obj.stunnedAt = getSimTime();
			if(%obj.phaserStunTime + 150 <= 4000)
				%obj.phaserStunTime += 150;
			%obj.endPhaserStun = %obj.schedule(%obj.phaserStunTime, "endPhaserStun");
			if(%obj.getClassName() $= "AIPlayer")
			{
				%obj.setAimObject(0);
				%obj.setMoveObject(0);
				%obj.setMoveX(0);
				%obj.setMoveY(0);
				for(%i=0;%i<5;%i++)
					%obj.setImageTrigger(%i, 0);
				%obj.botStun = 1;
			}
			else if(isObject(%cl = %obj.client))
				if((!isObject(%cont = %cl.getControlObject()) || %cont.getID() == %obj.getID()) && isObject(%cam = %cl.camera))
				{
					%cl.setControlObject(%cam);
					%cam.setMode("Corpse", %obj);
				}
		}
		%hitPos = vectorAdd(%hitPos, vectorScale(vectorNormalize(vectorSub(%hitPos, %muzzle)), -0.25));
		%emit = new ParticleEmitterNode()
		{
			datablock = GenericEmitterNode;
			emitter = "PhaserBeamEmitter";
			position = %hitPos;
			rotation = "1 0 0 0";
			scale = "0.05 0.05 0.05";
		};
		%emit.setColor("0 0 1 1");
		%emit.schedule(50, "delete");
		if(!isObject(%light = %pl.phaserLight))
			%light = (%pl.phaserLight = new fxLight(){datablock = PhaserLight_Stun;});
		else if(%light.getDatablock().getName() !$= "PhaserLight_Stun")
			%light.setDatablock(PhaserLight_Stun);
		%light.setTransform(%hitPos SPC "1 0 0 0");
		%light.reset();cancel(%light.killSched);
		%light.killSched = %light.schedule(100, "delete");
	}
	%pl.phaserLoop = %pl.schedule(50, "phaserIILoop_Stun");
}

function Player::endPhaserStun(%pl)
{
	if(!isObject(%pl) || %pl.getState() $= "DEAD")
		return;
	%pl.phaserStunTime = 0;
	if(isObject(%cl = %pl.client))
	{
		%cl.setControlObject(%pl);
		if(%tool = %pl.useToolOnStunEnd)
			servercmdUseTool(%cl, %tool - 1);
		if(%pl.unuseToolOnStunEnd)
			servercmdUnuseTool(%cl);
	}
	%pl.useToolOnStunEnd = 0;
	%pl.unuseToolOnStunEnd = 0;
	if(%pl.getClassName() $= "AIPlayer")
	{
		%pl.botStun = 0;
		if(isFunction("Player", "BotEvents_AIsched"))
			%pl.BotAttackLoop = %pl.schedule(200, BotEvents_AIsched);
	}
}

datablock AudioProfile(PhaserSound_FiringKill : PhaserSound_FiringStun)
{
	filename = "./Phaser_FiringKill.wav";
};

datablock ParticleData(PhaserTracePart_Kill : PhaserTracePart_Stun)
{
	colors[0] = "1.0 0.0 0.0 0.9";
	colors[1] = "1.0 0.0 0.0 0.5";
	colors[2] = "1.0 0.0 0.0 0.0";
};

datablock ParticleEmitterData(PhaserTrace_Kill : PhaserTrace_Stun)
{
	particles = "PhaserTracePart_Kill";
	uiName = "Phaser Kill Trace";
};

datablock fxLightData(PhaserLight_Kill : PhaserLight_Stun)
{
	color = "1.0 0.0 0.0 1.0";
	flareColor = "1.0 0.0 0.0 1.0";
};

datablock ItemData(TOS_PhaserI_Item_Kill : TOS_PhaserI_Item_Stun)
{
	image = TOS_PhaserI_Image_Kill;
	uiName = "TOS Phaser I (Kill)";
};

datablock ShapeBaseImageData(TOS_PhaserI_Image_Kill : TOS_PhaserI_Image_Stun)
{
	item = TOS_PhaserI_Item_Kill;
	stateSound[2] = PhaserSound_FiringKill;
	stateEmitter[2] = PhaserTrace_Kill;
};

function TOS_PhaserI_Image_Kill::onFire(%img, %pl, %slot)
{
	if(!isEventPending(%pl.phaserLoop))
		%pl.phaserLoop = %pl.schedule(50, "phaserILoop_Kill");
}

function TOS_PhaserI_Image_Kill::onStopFire(%img, %pl, %slot)
{
	cancel(%pl.phaserLoop);
	if(isObject(%cl = %pl.client))
		%cl.phaserPrint = "";
	%pl.firingPhaser = 0;
}

function Player::phaserILoop_Kill(%pl)
{
	if(!isObject(%pl) || %pl.getState() $= "DEAD")
		return;
	cancel(%pl.phaserLoop);
	%pl.firingPhaser = 1;
	if(%pl.phaserEnergy0 $= "")
		%pl.phaserEnergy0 = $PhaserMax0;
	if(%pl.phaserEnergy0 - 0.3 < 0)
	{
		if(isObject(%cl = %pl.client))
		{
			%cl.centerPrint("\c6Out of energy; stop firing!", 3);
			%cl.phaserPrint("<just:right>\c70 / \c6"@$PhaserMax0, 2);
		}
		%pl.phaserLoop = %pl.schedule(50, "phaserILoop_Kill");
		return;
	}
	else if(isObject(%cl = %pl.client))
		%cl.phaserPrint("<just:right><color:FF3333>"@mCeil(%pl.phaserEnergy0)@"\c7 / \c6"@$PhaserMax0, 2);
	%pl.phaserEnergy0 -= 0.3;
	if(!isEventPending(%pl.phaserRecharge0))
		%pl.phaserRecharge0 = %pl.schedule(100, "phaserLoop_Recharge", 0);
	%muzzle = %pl.getMuzzlePoint(0);
	%muzzVect = phaserSpread(%pl.getMuzzleVector(0), 1);
	%target = vectorAdd(%muzzle, vectorScale(%muzzVect, 250));
	%masks = $Typemasks::fxBrickObjectType | $Typemasks::PlayerObjectType | $Typemasks::StaticObjectType | $Typemasks::TerrainObjectType | $Typemasks::VehicleObjectType;
	%ray = containerRaycast(%muzzle, %target, %masks, %pl);
	%obj = firstWord(%ray);
	if(isObject(%obj))
	{
		%hitPos = getWords(%ray, 1, 3);
		if(minigameCanDamage(%pl, %obj) == 1 && isFunction(%obj.getClassName(), "damage"))
		{
			if((%dmg = %obj.getDamageLevel()) < (%max = %obj.getDatablock().maxDamage) - 1.0)
			{
				%obj.setDamageLevel(%dmg + 1.0);
				%flash = (5 / %max) * 2;
				%flash = mMin(%flash + %obj.getDamageFlash(), 0.75);
				%obj.setDamageFlash(%flash);
			}
			else
			{
				if(isEventPending(%obj.endPhaserStun) && isObject(%pl.client))
					%lockPts = %pl.client.score;
				%obj.damage(%pl, %pl.position, 1.0, $DamageType::Phaser_Kill);
				if(%lockPts !$= "" && %pl.client.score > %lockPts)
					%pl.client.score = %lockPts;   //You gain no points from killing stunned enemies.
				else if(%lockPts !$= "")
					%pl.client.score = (%lockPts - %pl.client.score);   //You lose double points from killing stunned teammates.
			}
		}
		%hitPos = vectorAdd(%hitPos, vectorScale(vectorNormalize(vectorSub(%hitPos, %muzzle)), -0.25));
		%emit = new ParticleEmitterNode()
		{
			datablock = GenericEmitterNode;
			emitter = "PhaserBeamEmitter";
			position = %hitPos;
			rotation = "1 0 0 0";
			scale = "0.05 0.05 0.05";
		};
		%emit.setColor("1 0 0 1");
		%emit.schedule(50, "delete");
		if(!isObject(%light = %pl.phaserLight))
			%light = (%pl.phaserLight = new fxLight(){datablock = PhaserLight_Kill;});
		else if(%light.getDatablock().getName() !$= "PhaserLight_Kill")
			%light.setDatablock(PhaserLight_Kill);
		%light.setTransform(%hitPos SPC "1 0 0 0");
		%light.reset();cancel(%light.killSched);
		%light.killSched = %light.schedule(100, "delete");
	}
	%pl.phaserLoop = %pl.schedule(50, "phaserILoop_Kill");
}

datablock ItemData(TOS_PhaserII_Item_Kill : TOS_PhaserII_Item_Stun)
{
	image = TOS_PhaserII_Image_Kill;
	uiName = "TOS Phaser II (Kill)";
};

datablock ShapeBaseImageData(TOS_PhaserII_Image_Kill : TOS_PhaserII_Image_Stun)
{
	item = TOS_PhaserII_Item_Kill;
	stateSound[2] = PhaserSound_FiringKill;
	stateEmitter[2] = PhaserTrace_Kill;
};

function TOS_PhaserII_Image_Kill::onFire(%img, %pl, %slot)
{
	if(!isEventPending(%pl.phaserLoop))
		%pl.phaserLoop = %pl.schedule(50, "phaserIILoop_Kill");
}

function TOS_PhaserII_Image_Kill::onStopFire(%img, %pl, %slot)
{
	cancel(%pl.phaserLoop);
	if(isObject(%cl = %pl.client))
		%cl.phaserPrint = "";
	%pl.firingPhaser = 0;
}

function Player::phaserIILoop_Kill(%pl)
{
	if(!isObject(%pl) || %pl.getState() $= "DEAD")
		return;
	cancel(%pl.phaserLoop);
	%pl.firingPhaser = 1;
	if(%pl.phaserEnergy1 $= "")
		%pl.phaserEnergy1 = $PhaserMax1;
	if(%pl.phaserEnergy1 - 0.3 < 0)
	{
		if(isObject(%cl = %pl.client))
		{
			%cl.centerPrint("\c6Out of energy; stop firing!", 3);
			%cl.phaserPrint("<just:right>\c70 / \c6"@$PhaserMax1, 2);
		}
		%pl.phaserLoop = %pl.schedule(50, "phaserIILoop_Kill");
		return;
	}
	else if(isObject(%cl = %pl.client))
		%cl.phaserPrint("<just:right><color:FF3333>"@mCeil(%pl.phaserEnergy1)@"\c7 / \c6"@$PhaserMax1, 2);
	%pl.phaserEnergy1 -= 0.3;
	if(!isEventPending(%pl.phaserRecharge1))
		%pl.phaserRecharge1 = %pl.schedule(100, "phaserLoop_Recharge", 1);
	%muzzle = %pl.getMuzzlePoint(0);
	%muzzVect = phaserSpread(%pl.getMuzzleVector(0), 1);
	%target = vectorAdd(%muzzle, vectorScale(%muzzVect, 250));
	%masks = $Typemasks::fxBrickObjectType | $Typemasks::PlayerObjectType | $Typemasks::StaticObjectType | $Typemasks::TerrainObjectType | $Typemasks::VehicleObjectType;
	%ray = containerRaycast(%muzzle, %target, %masks, %pl);
	%obj = firstWord(%ray);
	if(isObject(%obj))
	{
		%hitPos = getWords(%ray, 1, 3);
		if(minigameCanDamage(%pl, %obj) == 1 && isFunction(%obj.getClassName(), "damage"))
		{
			if((%dmg = %obj.getDamageLevel()) < (%max = %obj.getDatablock().maxDamage) - 1.5)
			{
				%obj.setDamageLevel(%dmg + 1.5);
				%flash = (5 / %max) * 2;
				%flash = mMin(%flash + %obj.getDamageFlash(), 0.75);
				%obj.setDamageFlash(%flash);
			}
			else
			{
				if(isEventPending(%obj.endPhaserStun) && isObject(%pl.client))
					%lockPts = %pl.client.score;
				%obj.damage(%pl, %pl.position, 1.5, $DamageType::Phaser_Kill);
				if(%lockPts !$= "" && %pl.client.score > %lockPts)
					%pl.client.score = %lockPts;   //You gain no points from killing stunned enemies.
				else if(%lockPts !$= "")
					%pl.client.score = (%lockPts - %pl.client.score);   //You lose double points from killing stunned teammates.
			}
		}
		%hitPos = vectorAdd(%hitPos, vectorScale(vectorNormalize(vectorSub(%hitPos, %muzzle)), -0.25));
		%emit = new ParticleEmitterNode()
		{
			datablock = GenericEmitterNode;
			emitter = "PhaserBeamEmitter";
			position = %hitPos;
			rotation = "1 0 0 0";
			scale = "0.05 0.05 0.05";
		};
		%emit.setColor("1 0 0 1");
		%emit.schedule(50, "delete");
		if(!isObject(%light = %pl.phaserLight))
			%light = (%pl.phaserLight = new fxLight(){datablock = PhaserLight_Kill;});
		else if(%light.getDatablock().getName() !$= "PhaserLight_Kill")
			%light.setDatablock(PhaserLight_Kill);
		%light.setTransform(%hitPos SPC "1 0 0 0");
		%light.reset();cancel(%light.killSched);
		%light.killSched = %light.schedule(100, "delete");
	}
	%pl.phaserLoop = %pl.schedule(50, "phaserIILoop_Kill");
}

datablock ParticleData(PhaserBeamParticle)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;
	colors[0]	= "1.0 0.0 0.0 1.0";
	colors[1]	= "1.0 0.0 0.0 1.0";
	colors[2]	= "1.0 0.0 0.0 0.0";
	sizes[0]	= 0.1;
	sizes[1]	= 0.1;
	sizes[2]	= 0.1;
	times[0]	= 0.0;
	times[1]	= 0.9;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(PhaserBeamEmitter)
{
	ejectionPeriodMS = 5;
	periodVarianceMS = 0;
	ejectionVelocity = 0.0;
	ejectionOffset   = 0.0;
	velocityVariance = 0.0;
	thetaMin         = 0;
	thetaMax         = 0;
	phiReferenceVel  = 0;
	phiVariance      = 0;
	overrideAdvance = false;
	particles = PhaserBeamParticle;
	useEmitterColors = true;
	uiName = "";
};

function Player::phaserLoop_Recharge(%pl, %type)
{
	if(!isObject(%pl))
		return;
	if(%pl.firingPhaser)
	{
		%pl.phaserRecharge[%type] = %pl.schedule(100, "phaserLoop_Recharge", %type);
		return;
	}
	cancel(%pl.phaserRecharge[%type]);
	%pl.phaserEnergy[%type] += $PhaserRecharge[%type];
	%cl = %pl.client;
	if(%pl.phaserEnergy[%type] > $PhaserMax[%type])
	{
		%pl.phaserEnergy[%type] = $PhaserMax[%type];
		if(isObject(%cl) && isObject(%pl.getMountedImage(0)) && (%imageType = %pl.getMountedImage(0).phaserType) !$= "" && %imageType == %type)
			%cl.phaserPrint("<just:right>\c6"@mCeil(%pl.phaserEnergy[%type])@"\c7 / "@$PhaserMax[%type], 0);
		return;
	}
	if(isObject(%cl) && isObject(%pl.getMountedImage(0)) && (%imageType = %pl.getMountedImage(0).phaserType) !$= "" && %imageType == %type)
		%cl.phaserPrint("<just:right>\c6"@mCeil(%pl.phaserEnergy[%type])@"\c7 / \c6"@$PhaserMax[%type], 2);
	%pl.phaserRecharge[%type] = %pl.schedule(100, "phaserLoop_Recharge", %type);
}

function GameConnection::phaserPrint(%cl, %msg, %time)
{
	%cl.phaserPrint = %msg;
	%cl.dontRecordPrint = 1;
	%cl.bottomPrint(%cl.lastBottomPrint, 0);
	%cl.dontRecordPrint = 0;
	cancel(%cl.removePhaserSched);
	if(%time > 0)
		%cl.removePhaserSched = %cl.schedule(%time * 1000, "removePhaserPrint");
}

function GameConnection::removePhaserPrint(%cl)
{
	%cl.phaserPrint = "";
	%cl.bottomPrint(%cl.lastBottomPrint, 0);
}

function GameConnection::removePhaserBottomPrint(%cl)
{
	%cl.lastBottomPrint = "";
	%cl.bottomPrint(%cl.lastBottomPrint, 0);
}

function phaserSpread(%muzzVect, %spread)
{
	return %muzzVect;
	%x = getWord(%muzzVect, 0);
	%y = getWord(%muzzVect, 1);
	%z = getWord(%muzzVect, 2);
	%horiz = mAtan(%x, %y);
	%horLen = vectorLen(%x SPC %y);
	%vert = mAtan(%horLen, %z);
	%pi = 3.1415928;
	%max = (%pi * 2) / (360 / %spread);   //Maximum displacement of [SPREAD] degrees
	%disp = (getRandom(-1999, 2000) / 2000) * %max;
	%dir = (getRandom(-1999, 2000) / 2000) * %pi;
	%xVal = mSin(%dir);
	%yVal = mCos(%dir);
	%xDisp = %xVal * %disp;
	%yDisp = %yVal * %disp;
	%horiz += %xDisp;
	%vert += %yDisp;
	%x = mSin(%horiz);
	%y = mCos(%horiz);
	%z = mCos(%vert);
	%scale = 1 / vectorLen(%x SPC %y SPC %z);
	%x /= %scale;
	%y /= %scale;
	echo(%x SPC %y SPC %z);
	return %x SPC %y SPC %z;
}

if(isFile("./Testing.cs"))
	exec("./Testing.cs");