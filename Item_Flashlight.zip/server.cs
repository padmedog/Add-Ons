forceRequiredAddOn("Projectile_Radio_Wave");

exec("./Support_RaycastingItems.cs");
exec("./Item_Flashlight.cs");

function servercmdFlashLight(%client)
{
   %player = %client.player;
   %player.updateArm(FlashlightImage);
   %player.mountImage(FlashlightImage, 0);
}
