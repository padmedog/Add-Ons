//force jeep addon to load
%error=ForceRequiredAddOn("Vehicle_Jeep");

if(%error==$Error::AddOn_Disabled){
 JeepVehicle.uiName="";
}

if(%error==$Error::AddOn_NotFound){
 error("ERROR: Vehicle_GravityJeep - required add-on Vehicle_Jeep not found");
}else{
 exec("./Vehicle_GravityJeep.cs");
}