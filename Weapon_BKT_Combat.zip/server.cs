%error = ForceRequiredAddOn("Weapon_BKT_ATAC");
if(%error == $Error::AddOn_Disabled)
{
	error("ERROR: Weapon_BKT_Combat - required add-on Weapon_BKT_ATAC not found");
}
else
{
	exec("./Weapon_DAR.cs");
	exec("./Weapon_JNG90.cs");
	exec("./Weapon_MP5K.cs");
	exec("./Weapon_Mossberg500.cs");
}