//Functions that get the aiming vector of a projectile affected by gravity to hit a target

function getFireAimVector(%start,%end,%g,%u)
{   
   %vec = vectorSub(%end,%start);
   
   //If the projectile isn't actually affected by gravity, then return the direct vector
   if(%g <= 0)
      return vectorNormalize(%vec);
   
   %xx = getWord(%vec,0);
   %yy = getWord(%vec,1);
   
   //Convert the 3-space vector to (xy, z)
   %sx = mSqrt(%xx*%xx + %yy*%yy);
   %sy = getWord(%vec,2);
   
   if(%sx == 0 && %sy > 0)
   {
    return "0 0 1";
   }
   
   %a = (-0.5*%g*%sx*%sx) / (%u*%u);
   %b = %sx;
   %c = ((-0.5*%g*%sx*%sx) / (%u*%u)) - %sy;

   //This seems to be badly implemented and returns negative versions of the answers
   //%str = mSolveQuadratic(%a,%b,%c);
   
   %d = %b*%b - 4*%a*%c;
   
   if(%d > 0)
   {
      %s1 = mATan((-%b+mSqrt(%d)) / (2*%a),1);
      %s2 = mATan((-%b-mSqrt(%d)) / (2*%a),1);
      
      //A lower angle is more direct and will hit the target quicker, so it's preferable 
      if(%s1 < %s2)
         %ang = %s1;
      else
         %ang = %s2;
   }
   
   if(%d == 0)
   {
      %ang = mATan((-%b) / (2*%a),1);
   }
   
   if(%d < 0)
   {
      //No solution when sqrt(%d < 0).
      return "0 0 1";
   }
   
   //retVec must be normalized as it will return (0 0 -sin45) when directly below the point
   %nVec = vectorNormalize(%xx SPC %yy);
   %retVec = vectorNormalize(getWord(%nVec,0) * mCos(%ang) SPC getWord(%nVec,1) * mCos(%ang) SPC mSin(%ang));
   
   return %retVec;
}

function getProjectileAimVector(%start,%end,%projectile)
{
   %g = %projectile.gravityMod*10;
   %u = %projectile.muzzleVelocity;
   
   return getFireAimVector(%start,%end,%g,%u);
}