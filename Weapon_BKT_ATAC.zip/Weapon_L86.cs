datablock AudioProfile(HKL86FireSound)
{
   filename    = "./HKL86Fire.wav";
   description = GunShotRange3d;
   preload = true;
};
datablock ProjectileData(HKL86Projectile)
{
	directDamage		= 22;
	gravityMod			= 0.225;
	muzzleVelocity		= 195;
	brickExplosionForce	= 10;
	impactImpulse		= 150;
	verticalImpulse		= 200;
	lifetime			= 6000;
	fadeDelay			= 5000;
	particleEmitter		= "ShortVaporTrailEmitter";

	radiusDamage		= 1;
	damageRadius		= 0.1;
	projectileShapeName	= "add-ons/weapon_gun/bullet.dts";
	directDamageType	= $DamageType::UniversalHeadshot;
	radiusDamageType	= $DamageType::UniversalHeadshot;
	brickExplosionRadius			= 0;
	brickExplosionImpact			= true;
	brickExplosionMaxVolume			= 3;
	brickExplosionMaxVolumeFloating	= 10;
	explosion			= GBImpact2Explosion;
	sound				= BulletWhizzingSound;
	velInheritFactor	= 0;
	armingDelay			= 10;
	bounceElasticity	= 0.5;
	bounceFriction		= 0.1;
	isBallistic			= true;
	hasLight			= false;
	lightRadius			= 3.0;
	lightColor			= "0 0 0";
};
function HKL86Projectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	%damageType = $DamageType::Direct;
	if(%this.DirectDamageType)
	{
		%damageType = %this.DirectDamageType;
	}
	%scale = getWord(%obj.getScale(), 2);
	%directDamage = 14*5;
	%damage = %directDamage;
	%sobj = %obj.sourceObject;
	if(%col.getType() & $TypeMasks::PlayerObjectType)
	{
		%directDamage = 22;
		%colscale = getWord(%col.getScale(),2);
		if(getword(%pos, 2) > getword(%col.getWorldBoxCenter(), 2) - 3.3*%colscale && $BKT::HS)
		{
			%directDamage = 60;
			%damageType = $DamageType::UniversalHeadshot;
		}
		%col.damage(%obj, %pos, %directDamage, %damageType);
	}
	else
	{
		%col.damage(%obj,%pos,%directDamage,%damageType);
	}
}
datablock ItemData(HKL86Item)
{
	shapeFile	= "./HKL86.dts";
	iconName	= "./icon_HKL86";
	image		= HKL86Image;
	uiName			= "SAW";
	maxAmmo			= 50;

	category		= "Weapon";
	className		= "Weapon";
	rotate			= false;
	mass			= 1;
	density			= 1.5;
	elasticity		= 0.2;
	friction		= 0.75;
	emap			= true;
	doColorShift	= true;
	colorShiftColor	= "0.4 0.4 0.41 1.000";
	canDrop			= true;
	canReload		= 1;
};
datablock ShapeBaseImageData(HKL86Image)
{
	shapeFile	= "./HKL86.dts";
	item		= HKL86Item;
	projectile	= HKL86Projectile;
	shellVelocity	= 12.0;
	shellExitDir	= "1 0 0.25";
	minShotTime		= 75;
	eyeOffset		= "0 0 0";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= HKL86Item.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.4;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.05;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.05;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "fire";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.05;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= HKL86FireSound;

	stateName[3]				= "Smoke";
	stateSequence[3]			= "Reload";
	stateEjectShell[3]			= true;
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "LoadCheckA";
	stateTimeoutValue[3]		= 0.005;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.02;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateAllowImageChange[6]	= true;
	stateTimeoutValue[6]		= 2.1;
	stateScript[6]				= "OnReload";
	stateTransitionOnTimeout[6]	= "Reloaded";
	stateWaitForTimeout[6]		= true;
	
	stateName[7]				= "Reloaded";
	stateAllowImageChange[7]	= false;
	stateTimeoutValue[7]		= 0.6;
	stateScript[7]				= "onReloaded";
	stateTransitionOnTimeout[7]	= "Ready";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.5;
	stateTransitionOnTimeout[9]	= "Reload";
};
function HKL86Image::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
}
function HKL86ADSImage::onMount(%this,%obj,%slot)
{
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::CH)
	{
		crossHair.setBitmap("add-ons/weapon_blockombat/empty.png");
	}
}
function HKL86Image::onFire(%this,%obj,%slot)
{
	HKL86Fire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function HKL86Image::onWeaponLoop(%this,%obj,%slot)
{
	if(%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function HKL86Fire(%this,%obj,%slot,%val)
{
	%projectile = HKL86Projectile;
	if(%obj.heat >= 6)
	{
		%obj.playThread(3, plant);
	}
	if(%obj.isImageMounted(HKL86Image))
	{
		if(vectorLen(%obj.getVelocity()) < 4)
		{
			%spread = 0.0014 + (%obj.heat * 0.0002);
		}
		else
		{
			%spread = 0.0022 + (%obj.heat * 0.0002);
		}
	}
	else if(%obj.isImageMounted(HKL86ADSImage))
	{
		if(vectorLen(%obj.getVelocity()) < 4)
		{
			%spread = 0.0006 + (%obj.heat * 0.00008);
		}
		else
		{
			%spread = 0.0008 + (%obj.heat * 0.0001);
		}
	}
	%obj.maxHeat = 16;
	if(%obj.heat < %obj.maxHeat)
		%obj.heat += 2;
	%shellcount = 1;
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	if($BKT::Flash)
	{
		%projectile = "ATACFlashProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function HKL86Image::onReload(%this,%obj,%slot)
{
	%obj.client.quantity["556rounds"] += %obj.toolAmmo[%obj.currTool];
	%obj.toolAmmo[%obj.currTool] = 0;%obj.heat = 0;%obj.heat = 0;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if(%obj.client.quantity["556rounds"] >= 1)
	{
		%obj.playThread(2, wrench);
		%obj.playThread(3, plant);
		serverPlay3D(rifleMagOutSound,%obj.getPosition()); 
	}
}
function HKL86Image::onReloaded(%this,%obj,%slot)
{
	if(%obj.client.quantity["556rounds"] >= 1)
	{
		if(%obj.client.quantity["556rounds"] > %this.item.maxAmmo)
		{
			%obj.client.quantity["556rounds"] -= %this.item.maxAmmo;
			%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
			%obj.setImageAmmo(%slot,1);
			%obj.playThread(2, activate);
			%obj.playThread(3, plant);
			serverPlay3D(rifleMagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
		}
		else if(%obj.client.quantity["556rounds"] <= %this.item.maxAmmo)
		{
			%obj.toolAmmo[%obj.currTool] = %obj.client.quantity["556rounds"];
			%obj.setImageAmmo(%slot,1);
			%obj.client.quantity["556rounds"] = 0;	
			%obj.playThread(2, activate);
			%obj.playThread(3, plant);
			serverPlay3D(rifleMagInSound,%obj.getPosition());
			if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
			return;
		}
	}
}
datablock ShapeBaseImageData(HKL86ADSImage)
{
	shapeFile	= "./HKL86.dts";
	item		= HKL86Item;
	projectile	= HKL86Projectile;
	shellVelocity	= 12.0;
	shellExitDir	= "1 0 0.25";
	minShotTime		= 75;
	eyeOffset		= "0 1 -0.98";

	emap		= true;
	mountPoint	= 0;
	offset		= "0 0 0";
	rotation	= eulerToMatrix( "0 0 0" );
	correctMuzzleVector	= false;
	className			= "WeaponImage";
	ammo				= "";
	projectileType		= Projectile;
	casing				= gunshell2debris;
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 2.0;		
	melee			= false;
	armReady		= true;
	doColorShift	= true;
	colorShiftColor	= HKL86Item.colorShiftColor;

	stateName[0]				= "Activate";
	stateTimeoutValue[0]		= 0.3;
	stateTransitionOnTimeout[0]	= "LoadCheckA";

	stateName[1]					= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;
	stateSequence[1]				= "Ready";
	stateTransitionOnNoAmmo[1]		= "Reload";
	stateTransitionOnTimeout[1]		= "weaponLoop";
	stateTimeoutValue[1]			= 0.025;

	stateName[2]				= "Fire";
	stateTransitionOnTimeout[2]	= "Smoke";
	stateTimeoutValue[2]		= 0.05;
	stateSequence[2]			= "Fire";
	stateFire[2]				= true;
	stateAllowImageChange[2]	= false;
	stateSequence[2]			= "fire";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]				= ATACFlashEmitter;
	stateEmitterTime[2]			= 0.05;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= HKL86FireSound;

	stateName[3]				= "Smoke";
	stateEjectShell[3]			= true;
	stateEmitter[3]				= lightsmokeEmitter;
	stateEmitterTime[3]			= 0.125;
	stateEmitterNode[3]			= "muzzleNode";
	stateAllowImageChange[3]	= false;
	stateTransitionOnTimeout[3]	= "LoadCheckA";
	stateTimeoutValue[3]		= 0.005;

	stateName[4] 				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateAllowImageChange[4]	= false;
	stateTimeoutValue[4]		= 0.02;
	stateTransitionOnTimeout[4]	= "LoadCheckB";

	stateName[5]				= "LoadCheckB";
	stateAllowImageChange[5]	= false;
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "ReloadWait";

	stateName[6]				= "Reload";
	stateScript[6]				= "OnReload";
	
	stateName[7]				= "Reloaded";

	stateName[8]					= "weaponLoop";
	stateTransitionOnTriggerDown[8]	= "LoadCheckA";
	stateTimeoutValue[8]			= 0.0;
	stateTransitionOnTimeout[8]		= "Ready";
	stateAllowImageChange[8]		= True;
	stateScript[8]					= "onWeaponLoop";

	stateName[9]				= "ReloadWait";
	stateAllowImageChange[9]	= false;
	stateTimeoutValue[9]		= 0.4;
	stateTransitionOnTimeout[9]	= "Reload";
};
function HKL86ADSImage::onWeaponLoop(%this,%obj,%slot)
{
	if (%obj.heat > 0)
	{
		%obj.heat -= 1;
	}
}
function HKL86ADSImage::onFire(%this,%obj,%slot)
{
	HKL86Fire(%this,%obj,%slot);
	%obj.toolAmmo[%obj.currTool]--;
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
	if($BKT::Recoil)
	{
		%projectile = "ATACRecoilProjectile";	
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
	}
	MissionCleanup.add(%p);
	return %p;
}
function HKL86ADSImage::onReload(%this,%obj,%slot)
{
	%obj.mountImage(HKL86Image,0);
	if($BKT::DH){commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:FF0000>5.56x45 SAW  <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool]+0 @ " / " @ %obj.client.quantity["556rounds"]+0 @ "", 4, 2, 3, 4);}
}
package HKL86Sights
{
	function armor::onTrigger(%this,%obj,%triggerNum,%val)
	{
		%client = %obj.client;		
		if(%obj.getMountedImage(0) $= HKL86Image.getID() && %triggerNum == 4 && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(HKL86ADSImage, 0);
			%client.setControlCameraFov(85);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		else if(%triggerNum == 4 && %obj.getMountedImage(0) $= HKL86ADSImage.getID() && %val)
		{
			%newAmmo = %obj.toolAmmo[%obj.currTool];
			%obj.mountImage(HKL86Image, 0);
			%client.setControlCameraFov(90);
			%obj.toolAmmo[%obj.currTool] = %newAmmo;
		}
		Parent::onTrigger(%this,%obj,%triggerNum,%val);
	}
	function servercmdDropTool(%client,%slot)
	{
		if(%client.player.getMountedImage(0) $= HKL86ADSImage.getID())
		{
		 	%client.player.unmountImage(0);
			%client.setControlCameraFov(90);
			if($BKT::CH)
			{
				crossHair.setBitmap("base/client/ui/crosshair.png");
			}
		}
		return Parent::servercmdDropTool(%client,%slot);
	}
};
activatePackage(HKL86Sights);
function HKL86ADSImage::onUnMount(%this,%obj,%slot)
{
	%obj.client.setControlCameraFov(90);
	if($BKT::CH)
	{
		crossHair.setBitmap("base/client/ui/crosshair.png");
	}
}