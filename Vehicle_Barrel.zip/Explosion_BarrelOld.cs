datablock DebrisData(DB_barrelOld)
{
	shapeFile = "./barrelOldDebris.dts";
	lifetime = 2.0;
	minSpinSpeed = -200.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.2;
	friction = 0.3;
	numBounces = 3;
	staticOnMaxBounce = false;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 1;
};

datablock ExplosionData(EX_barrelOld)
{
	lifetimeMS = 8000;
	lifetimeVariance = 0;
	delayMS = 0;
	delayVariance = 0;
	
	radiusDamage = 0;
	damageRadius = 0;
	
	debris = DB_barrelOld;
	debrisNum = 3;
	debrisNumVariance = 0;
	debrisPhiMin = 45;
	debrisPhiMax = 360;
	debrisThetaMin = 45;
	debrisThetaMax = 180;
	debrisVelocity = 3;
	debrisVelocityVariance = 1;
	
	shakeCamera = false;
	lightStartRadius = 0;
	lightEndRadius = 0;
	faceViewer = true;
	explosionScale = "1 1 1";
	offset = 0;
};

datablock ProjectileData(PR_barrelOldExplosion)
{
	projectileShapeName = "base/data/shapes/empty.dts";
	Explosion = EX_barrelOld;
	
	uiName = "Barrel Old Break";
	lifetime = 0;
	armingDelay = 0;
	fadeDelay = 0;
	explodeOnDeath = true;	

	directDamage = 0;
	radiusDamage = 0;

	muzzleVelocity = 0;
	velInheritFactor = 0;
	minStickVelocity = 0;
	bounceAngle = 0;
	gravityMod = 0;
	isBallistic = false;
	impactImpulse = 0;
	verticalImpulse = 0;	
	brickExplosionRadius = 0;
	brickExplosionImpact = 0;
	brickExplosionForce = 0;
	brickExplosionMaxVolume = 0;
	brickExplosionMaxVolumeFloating = 0;
	hasLight = 0;
};