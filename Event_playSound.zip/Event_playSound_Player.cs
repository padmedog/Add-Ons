registerOutputEvent(Player,playSound,"dataBlock Sound",0);
function Player::playSound(%this,%sound)
{
 if(!isObject(%sound) || %sound.getClassName() !$= "AudioProfile")
  return;
 
 if(%sound.description.isLooping || !%sound.description.is3D)
  return;
 
 serverplay3d(%sound,%this.getHackPosition() SPC "0 0 1 0");
}