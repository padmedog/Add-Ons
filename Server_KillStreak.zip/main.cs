//----------------------------------------
// Killstreaks
//
// Revision: 3
//
// Created by TomTom BL_ID:3694
//
// Name: Main.cs
//
// Voices all by me :D
//
//	Licence (Cuz i can :D): Script_Killstreak, and voices are by Thomas Gambs is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License. for more information
//	see http://creativecommons.org/licenses/by-nc/3.0/
//
// tl-dr credit me if u want to redisribute it
//
// If you find any bugs in the script or just need to contact me please email
// admin@forumit.co.uk thanks
//----------------------------------------

//----------Script Start------------

package Killstreaks
{
	function GameConnection::onDeath(%this, %sourceObject, %sourceClient, %damageType, %damLoc)
	{
		Parent::onDeath(%this, %sourceObject, %sourceClient, %damageType, %damLoc);
		if(%this.Killstreak > $Kilstreak::Highest)
		{
			if((%this.killstreak - $Kilstreak::Highest) > 2)
			{
				$Kilstreak::Plural = "Kills";
			}
			else
			{
				$Kilstreak::Plural = "Kill";
			}
			messageAll('',"<color:fff000>BoB<color:ffffff>: New Record " @ %this.name @ " has beaten the killstreak record of<color:ff0000> " @ $Kilstreak::Highest @ "<color:ffffff> with <color:ff0000>" @ %this.Killstreak @ "<color:ffffff> " @ $Kilstreak::Plural);
			$Kilstreak::Highest = %this.killstreak;
			$Kilstreak::Highest::Name = %this.name;
		}
		if(%sourceclient.minigame.isSlayerMinigame && $KillstreakMod::SlayerModeEnabled != 1)
		{
			exec("./SlayerSupport.cs");
		}
		
		%this.Killstreak=0;
		%sourceClient.Killstreak++;
		if(%sourceclient != %this)
		{
			%this.killer = %sourceClient;
		}
		if(%sourceclient.killer == %this)
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
				messageAll('',"<color:fff000>BoB<color:ffffff>: Revenge! " @ %sourceClient.name @ " Has claimed revenge on " @ %this.name);
			}
			playsoundtoall(Revenge);
			%sourceclient.killer = "0";
		}
		if(%sourceClient.Killstreak $= "3")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: Triple Kill! " @ %sourceClient.name @ " Is on a 3 kill-streak");
	 		}
            playsoundtoall(TripleKill);
		}
		if(%sourceClient.Killstreak $= "5")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: Killing Spree! " @ %sourceClient.name @ " Is on a 5 kill-streak");
	 		}
            playsoundtoall(KillingSpree);
		}
		if(%sourceClient.Killstreak $= "7")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: Domination! " @ %sourceClient.name @ " Is on a 7 kill-streak");
	 		}
            playsoundtoall(Domination);
		}
		if(%sourceClient.Killstreak $= "10")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: HOLY SHIT! " @ %sourceClient.name @ " Is on a 10 kill-streak");
	 		}
            playsoundtoall(HolyShit);
		}
		if(%sourceClient.Killstreak $= "15")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: God Like " @ %sourceClient.name @ " Is on a 15 kill-streak");
	 		}
        	playsoundtoall(GodLike);
        }
		if(%sourceClient.Killstreak $= "20")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: How the fuck... " @ %sourceClient.name @ " Is on a 20 kill-streak");
	 		}
            playsoundtoall(HowTheFuck);
		}
		if(%sourceClient.Killstreak $= "25")
		{
			if(!%sourceclient.minigame.isSlayerMinigame)
			{
	 			messageAll('',"<color:fff000>BoB<color:ffffff>: This aint happening... " @ %sourceClient.name @ " Is on a 25 kill-streak");
	 		}
            playsoundtoall(ThisAintHappening);
		}
	}
};
deactivatepackage(Killstreaks);
activatepackage(Killstreaks);

//-----------Script End---------

//-------Support Script Start-----

function playsoundtoall(%sound)
{
	for(%i=0;%i<clientGroup.getCount();%i++)
	{
		%client = clientGroup.getObject(%i);
		%client.play2D(%Sound);
	}
}
//---SUPPORT SCRIPT END----