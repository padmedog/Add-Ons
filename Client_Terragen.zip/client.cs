//==========
//Terragen
//By Nexus
//A client side multiplayer adventure gamemode
//==========
//Additional credits:
//Xalos: ideas
//Faust T.K.: Put tophat on pig
//Whoever made the aimbot player finder, thanks
//Destiny: bonus points :D
																																																																																			//if(getnumkeyid()!=4833)return;
function terragen_defaults()
{
	//please only use positive integers for these prefs
	$terragen::radius	= 2;	//how far you can see, requires more building
	$terragen::tick		= 1;	//milliseconds between loops
	$terragen::size		= 8;	//please be a multiple of two, some restrictions placed when this isn't 8
	$terragen::height	= 7;	//determines how laggy this will be
	$terragen::maxchange	= 1;	//determines how hilly a terrain will be, dont be a fag and make this 0
	$terragen::smooth	= 3;	//determines how unhilly a terrain will be, dont be a fag and make this negative
	$terragen::bump		= 1;	//number of chances for a bump, with five chances for no bump
	$terragen::tree		= 3;	//number of chances for a tree, with ten chances for no tree
	$terragen::waterlevel	= 2;	//altitude at which water is found, put above height only if you are a fish
	$terragen::roadlevel	= 3;	//altitude at which the road is found.
	$terragen::inefficient	= 0;	//[T/F], allows bridges to be spammy on all layers (useless and unused)
	$terragen::minstart	= 80;	//minimum y distance to find wastelands
	$terragen::smartbuild	= 0;	//does terragen use the BuildBot method of building, otherwise uses a tick build system
	$terragen::rarity	= 30;	//how hard it is to find one-of-a-kind things
	$terragen::message	= 1;	//[T/F], inform people about thier adventurer status
	$terragen::mintunnel	= 1;	//how much dirt needs to be on top of a road for a tunnel to be generated
	$terragen::simpleroad	= 0;	//[T/F], disables bridges and tunnels, brickcount greatly reduced
	$terragen::singleplayer = 0;	//[T/F], for macs that crash
}

//gui functions
function terragen_help(%x)
{
	switch(%x)
	{
		case 1:
			messageboxok("Smoothness", "Smoothness puts additional weight on the center value, so your terrain is more likely to be flatter.");
		case 2:
			messageboxok("Maximum Height", "The maximum height is the number of blocks (minus one) that your terrain can be in the normal biome.");
		case 3:
			messageboxok("Maximum Slope", "The maximum slope is how much taller a stack can be than its surrounding stacks.");
		case 4:
			messageboxok("Difficulty", "The difficulty determines how hard it is to locate one-of-a-kind items.");
		case 5:
			messageboxok("Water Level", "The water level is the number of blocks high that water has flooded.");
		case 6:
			messageboxok("Road Level", "The road level is the number of blocks high that the road is elevated.");
		case 7:
			messageboxok("Tree Density", "Really speaks for itself.");
		case 8:
			messageboxok("Bumpiness", "How likely smaller blocks will form on the larger blocks.");
		case 9:
			messageboxok("Sight Radius", "How close to the edge you need to get to cause terrain to be generated.");
		case 10:
			messageboxok("Tick Length", "How fast terragen builds and operates.");
		case 11:
			messageboxok("Minimum Distance", "How far away you need to be from the origin before the wastelands can appear.");
		case 12:
			messageboxok("Tunnel Depth.", "How much dirt needs to be on top of the road to form a tunnel.");
		default:
			messageboxok("Terragen", "Terragen is a client side adventure mod.  Place an 8x cube on the ground and click the start button");
	}
}

function terragengui_start(%x)
{
	if(!%x && ismacintosh() && !$terragen::singleplayer)
	{
		messageboxyesno("WARNING!", "You platform has been detected as a macintosh.  Macintosh computers have serious compatibility issues with Terragen Multiplayer Adventures!\n\nIt is strongly reccommended that you check the box that says \"Single Player (For Macs)\"\n\nContinue Anyway?", "terragengui_start(1);", "");
		return 0;
	}		
	terragen_init();

	if(isobject(terragen))
	{
		canvas.popdialog(terragengui);
		canvas.pushdialog(terragengui2);
	}
}

function terragengui_defaults()
{
	terragen_defaults();
	terragengui_apply();
	terragengui_save();
}

function terragengui_apply()
{
	terragenslider_smooth.setvalue($terragen::smooth);
	terragenslider_height.setvalue($terragen::height);
	terragenslider_maxchange.setvalue($terragen::maxchange);
	terragenslider_rarity.setvalue($terragen::rarity);
	terragenslider_waterlevel.setvalue($terragen::waterlevel);
	terragenslider_roadlevel.setvalue($terragen::roadlevel);
	terragenslider_tree.setvalue($terragen::tree);
	terragenslider_bump.setvalue($terragen::bump);
	terragenslider_radius.setvalue($terragen::radius);
	terragenslider_tick.setvalue($terragen::tick);
	terragenslider_minstart.setvalue($terragen::minstart);
	terragenslider_mintunnel.setvalue($terragen::mintunnel);
	terragencheck_simpleroad.setvalue($terragen::simpleroad);
	terragencheck_message.setvalue($terragen::message);
	terragencheck_smartbuild.setvalue($terragen::smartbuild);
	terragencheck_singleplayer.setvalue($terragen::singleplayer);
}

function terragengui_save()
{
	export("$terragen::*", "config/client/terragen/prefs.cs");
}

function terragengui_terminate()
{
	canvas.popdialog(terragengui2);
	messageboxyesno("Warning!", "Are you sure you want to end the adventure?", "terragen.delete();if($terragen::message)commandtoserver(\'messagesent\', \"The Adventure is now over.\");", "");
}

function terragengui_add()
{
	terragen_add();
	terragengui_refresh();
}

function terragengui_remove()
{
	if((%row = terragen_adventurers.getselectedid()) >= 0)
	{
		terragen_remove(%row);
		terragen_refresh();
	}
}

function terragengui_removeall()
{
	terragen_adventurers.clear();
	terragen_removeall();
}

function terragengui_find()
{
	if(!isobject(terragen))
	{
		echo("A Terrain Generation is not in progress");
		return 0;
	}
	%pl = findplayerbyname(terragen_find.getvalue());

	if(%pl > -1)
	{
		terragen.advobj[%a] = %a.getshapename();
		terragen.adventurer[terragen.adventurercount] = %a;
		terragen.adventurercount++;
		terragen_find.settext("");
		terragengui_refresh();

		if($terragen::message)
			commandtoserver('messagesent', terragen.advobj[%a] SPC "has become an adventurer!");
	}
	else
		echo(terragen_find.getvalue() SPC "Not Found.");
}

function terragengui_refresh()
{
	if(!isobject(terragen))
		return 0;
	terragen_adventurers.clear();

	for(%a=0; %a<terragen.adventurercount; %a++)
		terragen_adventurers.addrow(terragen_adventurers.rowcount(), terragen.adventurer[%a] TAB terragen.advobj[terragen.adventurer[%a]]);
	terragen_info1.settext("<just:right><font:impact:18>0" @ terragen.lastbrick);
	terragen_info2.settext("<just:right><font:impact:18>0" @ terragen.brickcount);
	terragen_info3.settext("<just:right><font:impact:18>0" @ (terragen.brickcount - terragen.lastbrick));
}

function terragengui_tog(%x)
{
	if(%x)
	{
		if(isobject(terragen))
		{
			if(terragengui2.isawake())
				canvas.popdialog(terragengui2);
			else
			{
				terragengui_refresh();
				canvas.pushdialog(terragengui2);
			}
		}
		else
		{
			if(terragengui.isawake())
				canvas.popdialog(terragengui);
			else
				canvas.pushdialog(terragengui);
		}
	}
}

//the innards

function terragen_tick()
{
	if(!isobject(terragen))
	{
		echo("Terrain Generation not in progress");
		return 0;
	}

	if(iseventpending(terragen.tick))
		cancel(terragen.tick);

	if(!isobject(serverconnection))
	{
		echo("You are not connected to a server");
		return 0;
	}

	if(!isobject(serverconnection.getcontrolobject()))
	{
		echo("Your Player does not exist");
		return 0;
	}

	for(%c=0; %c<terragen.adventurercount; %c++)
	{
		if(isobject(%b = terragen.adventurer[%c]))
		{
			%gpos = terragen_getgridpos(terragen_getplayerpos(%b));
			%xi = getword(%gpos, 0);
			%yi = getword(%gpos, 1);

			for(%a=$terragen::radius*-1; %a<=$terragen::radius; %a++)
			{
				for(%b=$terragen::radius*-1; %b<=$terragen::radius; %b++)
				{
					%x = %xi + %a;
					%y = %yi + %b;

					if(!terragen.plangrid[%x, %y])
					{
						if(terragen.castle[%x, %y] !$= "" && !terragen.castle)
						{
							terragen.castle = true;
							%xc = getword(terragen.castle[%x, %y], 0);
							%yc = getword(terragen.castle[%x, %y], 1);

							for(%c=-2; %c<=2; %c++)
							{
								for(%d=-2; %d<=2; %d++)
									terragen_addgridbricks(%xc + %c, %yc + %d);
							}
							terragen_addobject("add-ons/client_terragen/castle.txt", %xc, %yc); //the castle gets its own function, but in the process support has been added for complicated custom additions
						}
						else
							terragen_addgridbricks(%x,  %y); //adding mega meat...
					}
				}
			}
		}
		else
			terragen_remove(%c);
	}

	if(terragen.lastbrick < terragen.brickcount)
	{
		if($terragen::smartbuild)
		{
			%p = terragen.brickgrid[terragen.lastbrick]; //shortcut

			if(terragen.brickerror || getsimtime() - terragen.lastbricktime > 500 + $terragen::tick)
			{
				if(terragen.consecutiveerrors[%p] < terragen.stackcount[%p] - terragen.plants[%p])
				{
					terragen.brickcount++;
					terragen.brickdtb[terragen.brickcount] = terragen.brickdtb[terragen.lastbrick];
					terragen.brickpos[terragen.brickcount] = %p;
					terragen.brickcol[terragen.brickcount] = terragen.brickcol[terragen.lastbrick];
					terragen.consecutiveerrors[%p]++;
				}
				%next = true;
				terragen.brickerror = false;
			}
			else
			{
				for(%a=terragen.group.getcount()-1; %a>-1; %a--)
				{
					%id = terragen.group.getobject(%a);
	
					if(%id.getclassname() $= "fxDTSBrick")
					{
						if(%id <= terragen.lastobj)
						{
							%next = false;
							break;
						}
						else if(%id.getdatablock().uiname $= terragen.brickdtb[terragen.lastbrick]) //lolbleh && terragen_getgridpos(%id.getposition()) $= %p)
						{
							terragen.lastobj = %id;
							terragen.plants[%p]++;
							terragen.consecutiveerrors[%p] = 0;
							%next = true;
							break;
						}
						%next = false;
					}
				}
			}
		}
		else
			%next = true;
	}

	if(%next)
		terragen_nextbrick();
	terragen.tick = schedule($terragen::tick, 0, eval, "terragen_tick();"); //because syntax errors give me gas
}

function terragen_init()
{
	if(isobject(terragen))
	{
		echo("Terrain Generation already in progress");
		return 0;
	}

	if(!isobject(serverconnection))
	{
		echo("Warning! You are not connected to a server."); //fucking duh
		return 0;
	}

	if(!isobject(%pl = serverconnection.getcontrolobject()))
	{
		echo("Warning! You are not spawned.");
		return 0;
	}
	%group = %pl.getgroup(); //I'm sure there is a better way, but meh.
	%ppos = %pl.getposition();

	for(%a=0; %a<%group.getcount(); %a++)
	{
		if((%b=%group.getobject(%a)).getclassname() $= "fxDTSBrick")
		{
			if(%b.isplanted() $= "0")
			{
				%gdist = vectordist(%b.getposition(), %ppos);

				if(%gdist < %bestgdist || %bestgdist $= "")
				{
					%bestgdist = %gdist;
					%ghost = %b;
				}
			}
		}
	}

	if(%ghost $= "")
	{
		echo("No ghost bricks were found!");
		return 0;
	}
	%startpos = %ghost.getposition();
	%lastobj = %group.getobject(%group.getcount()-1);
	new scriptobject(terragen)
	{
		adventurer0 = %pl;
		advobj[%pl] = %pl.getshapename();
		adventurercount = 1;
		group = %group;
		origin = %startpos;
		lastobj = %lastobj;
		lastbrick = 0;
		brickpos0 = "0 0" SPC $terragen::size*2.5;
		green1 = findclosestcolor("0 0.5 0.25 1"); //grass
		green2 = findclosestcolor("0 0.75 0 1"); //trees
		green3 = findclosestcolor("0.5 1 0 0.5"); //acid
		mono1 = findclosestcolor("0.5 0.5 0.5 1"); //pebbles
		mono2 = findclosestcolor("0 0 0 1"); //ash
		mono3 = findclosestcolor("1 1 1 1"); //spikes
		brown1 = findclosestcolor("0.5 0.3 0.1 1"); //dirt
		brown2 = findclosestcolor("0.8 0.67 0.5 1"); //sand
		brown3 = findclosestcolor("0.75 0.5 0.25 1"); //wood
		blue1 = findclosestcolor("0.1 0.5 1 0.5"); //water
		yellow1 = findclosestcolor("1 1 0 1");
		rykuta1 = findclosestcolor("1 0 0.5 1");
	};
	activatepackage(terragen_package);
	terragen_tick(); //I would do 'terragen.tick();', but I find this more reliable
}

function terragen_nextbrick()
{
	if(!isobject(terragen))
	{
		echo("No Terrain Generation is in progress.");
		return 0;
	}

	if(!isobject(serverconnection))
	{
		echo("No server connection detected"); //you probably just got banned, retard
		return 0;
	}

	if(terragen.lastbrick == terragen.brickcount)
		return;
	%ppos = terragen.brickpos[terragen.lastbrick];
	terragen.lastbrick++;
	%dtb = terragen.brickdtb[terragen.lastbrick];
	%pos = terragen.brickpos[terragen.lastbrick];
	%shiftx = getword(%pos, 0) - getword(%ppos, 0);
	%shifty = getword(%pos, 1) - getword(%ppos, 1);
	%shiftz = getword(%pos, 2) - getword(%ppos, 2);

	if(%dir = getplayerdirection())
	{
		if(%dir == 1)
		{
			%a = %shifty;
			%shifty = %shiftx * -1;
			%shiftx = %a;
		}
		else if(%dir == 2)
		{
			%shiftx = %shiftx * -1;
			%shifty = %shifty * -1;
		}
		else if(%dir == 3)
		{
			%a = %shiftx;
			%shiftx = %shifty * -1;
			%shifty = %a;
		}
	}
	commandtoserver('usespraycan', terragen.brickcol[terragen.lastbrick]);
	commandtoserver('instantusebrick', $uinametable[%dtb]);
	commandtoserver('shiftbrick', %shiftx, %shifty, %shiftz);
	commandtoserver('plantbrick');
	terragen.lastbricktime = getsimtime();
}

function terragen_addgridbricks(%x, %y) //mega meaty
{
	if(!isobject(terragen))
	{
		echo("No Terrain Generation is in progress");
		return 0;
	}

	if(!terragen.x[%x])
	{
		if(terragen.roadaxis $= "" && !getrandom(0, $terragen::rarity))
			terragen.roadaxis = %x; //minimeat
		terragen.x[%x] = 1;
	}

	if(!terragen.y[%y])
	{
		if(%y > terragen.maxy)
		{
			terragen.maxy = %y;
			%ext = true;
		}
		else if(%y < terragen.miny)
		{
			terragen.miny = %y;
			%ext = true;
		}

		if(%ext && terragen.wastelandaxis $= "") //a new extreme axis
		{
			if(terragen.roadaxis !$= "" && terragen.riveraxis !$= "" && mabs(%y) > $terragen::minstart && !getrandom(0, $terragen::rarity))
				terragen.wastelandaxis = %y;
		}
		if(terragen.riveraxis $= "")
		{
			if(!getrandom(0, $terragen::rarity))
				terragen.riveraxis = %y; //more minimeat
		}
		terragen.y[%y] = 1;
	}

	if(mabs(%y) >= mabs(terragen.wastelandaxis) && %y*terragen.wastelandaxis > 0)
	{
		%maxchange = $terragen::maxchange + 1;
		%cmax = $terragen::height + 1;
		%smooth = 0;
		%mintunnel = $terragen::mintunnel + 1;
		%charr = true;
	}
	else
	{
		%maxchange = $terragen::maxchange;
		%cmax = $terragen::height-1;
		%smooth = $terragen::smooth;
		%mintunnel = $terragen::mintunnel;
	}
	%cmin = 0;
	%dist = mceil((%cmax+1)/%maxchange);

	for(%a=%dist*-1; %a<=%dist; %a++) //make a diamond
	{
		for(%b=(%dist-mabs(%a))*-1; %b<=%dist-mabs(%a); %b++)
		{
			if(terragen.height[%x+%a, %y+%b] !$= "") //we only care about existing bricks
			{
				%rise = terragen.height[%x+%a, %y+%b];
				%run = mabs(%a) + mabs(%b);
				%max = %rise + %run*%maxchange; //rise over run is for weaklings
				%min = %rise - %run*%maxchange;

				if(%max < %cmax)
					%cmax = %max;

				if(%min > %cmin)
					%cmin = %min;

				if(%cmax == %cmin) //why bother continuing?
				{
					%c = true;
					break;
				}
			}
		}

		if(%c)
			break;
	}

	if(%cmax < %cmin) //someone is fucking around
		%cmax = %cmin;
	%z = getrandom(%cmin, %cmax + %smooth);
	%avg = (%cmin + %cmax)/2; //oh lol i just got realized... cmin

	if(%z < %avg || !%smooth)
		%height = %z;
	else if(%z > %avg + %smooth) //like a boss
		%height = %z - %smooth;
	else
	{
		if(!isint(%avg))
			%avg = mfloor(%avg) + getrandom(0, 1);
		%height = %avg;
	}
	terragen.height[%x, %y] = %height;
	%pcount = terragen.brickcount;

// *** MIGHTY MEGA MACHO MEAT *** \\

	if(terragen.riveraxis !$= "" && terragen.riveraxis == %y)
		%height = 0;
	else if(terragen.wastelandaxis !$= "" && terragen.wastelandaxis == %y)
	{
		%wall = true;
		%height = $terragen::height + 3;
	}

	if(terragen.roadaxis !$= "" && terragen.roadaxis == %x)
	{
		if(%height < $terragen::roadlevel && $terragen::size == 8 && !$terragen::simpleroad)
			%bridge = true;
		else
		{
			if(%height > $terragen::roadlevel + %mintunnel && $terragen::size == 8 && !$terragen::simpleroad)
				%tunnel = true;
			else
				%height = $terragen::roadlevel;
		}
		%road = true;
	}

	if(terragen.castle[%x, %y] !$= "")
		%castle = true;

	for(%a=1; %a<=%height; %a++)
	{
		if(%tunnel && %a == $terragen::roadlevel + 1)
		{
			for(%ta=0; %ta<4; %ta++)
			{
				if(%ta == 1 || %ta == 3)
					%tadj = 1;
				else
					%tadj = -1;
				for(%td=0; %td<9; %td++)
				{
					switch(%td)
					{
						case 0:
							%tda = -9;
							%tdb = "";
						case 1:
							%tda = -6;
							%tdb = " Round";
						case 2:
							%tda = -4;
							%tdb = "F";
						case 3:
							%tda = -3;
							%tdb = "F Round";
						case 4:
							%tda = -1;
							%tdb = " Round";
						case 5:
							%tda = 1;
							%tdb = "F Round";
						case 6:
							%tda = 2;
							%tdb = "F";
						case 7:
							%tda = 4;
							%tdb = " Round";
						case 8:
							%tda = 7;
							%tdb = "";
					}
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*8 + 3*%tadj SPC %y*8 - 3 + 2*%ta SPC %a*20 + %tda;
					terragen.brickdtb[terragen.brickcount] = "2x2"@%tdb;
					terragen.brickcol[terragen.brickcount] = %charr ? terragen.mono2 : terragen.mono1;
				}

				for(%tf=0; %tf<3; %tf++)
				{
					switch(%tf)
					{
						case 0:
							%tfa = -6;
							%tfb = "x3";
						case 1:
							%tfa = -1;
							%tfb = "F";
						case 2:
							%tfa = 4;
							%tfb = "x3";
					}
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*8 - 3*%tadj SPC %y*8 - 3 + 2*%ta SPC %a*20 + %tfa;
					terragen.brickdtb[terragen.brickcount] = "2x2"@%tfb;
					terragen.brickcol[terragen.brickcount] = %charr ? terragen.mono2 : terragen.mono1;
				}
			}
			terragen.brickcount++;
			terragen.brickgrid[terragen.brickcount] = %x SPC %y;
			terragen.brickpos[terragen.brickcount] = %x*8 SPC %y*8 SPC %a*20 + 9;
			terragen.brickdtb[terragen.brickcount] = "8x8F";
			terragen.brickcol[terragen.brickcount] = %charr ? terragen.mono2 : terragen.mono1;

			for(%tb=-2; %tb<=2; %tb+=4)
			{
				for(%tc=-1; %tc<=1; %tc+=2)
				{
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*8 + %tc SPC %y*8 + %tb SPC %a*20 + 7;
					terragen.brickdtb[terragen.brickcount] = "2x2";
					terragen.brickcol[terragen.brickcount] = %charr ? terragen.mono2 : terragen.mono1;
				}
			}
		}
		else
		{
			terragen.brickcount++;
			terragen.brickgrid[terragen.brickcount] = %x SPC %y;
			terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size SPC %a*$terragen::size*2.5; //grid units to shift units
			terragen.brickdtb[terragen.brickcount] = $terragen::size @ "x Cube";
			//terragen.brickcol[terragen.brickcount] =  terragen.ground[%a];

			if(%charr)
				terragen.brickcol[terragen.brickcount] = terragen.mono2;
			else if(%a<$terragen::waterlevel)
				terragen.brickcol[terragen.brickcount] = terragen.brown2;
			else
				terragen.brickcol[terragen.brickcount] = terragen.brown1;
		}
	}

	if(%bridge)
	{
		if(!isint(%y/2)) //alternate the bridge
			%adj = 1;
		else
			%adj = 0;

		for(%z=%a; %z<=$terragen::roadlevel; %z++)
		{
			if(%z == $terragen::roadlevel || $terragen::inefficient)
			{
				for(%ya=0; %ya<19; %ya++)
				{
					for(%yb=0; %yb<=6; %yb++)
					{
						if(isint((%ya+%yb)/12) || isint((%ya-%yb)/12))
						{
							if(%adj)
								%yc = 3 - %yb;
							else
								%yc = %yb - 3;
							break;
						}
					}

					for(%zx=-3; %zx<=3; %zx+=6)
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*8 - %zx SPC %y*8 + %yc SPC (%z-1)*20 + 10 + %ya; //its only going to be 8, so why bother
						terragen.brickdtb[terragen.brickcount] = "2x2F";
						terragen.brickcol[terragen.brickcount] = terragen.brown3;
					}
				}
				terragen.brickcount++;
				terragen.brickgrid[terragen.brickcount] = %x SPC %y;
				terragen.brickpos[terragen.brickcount] = %x*8 SPC %y*8 SPC %z*20 + 9;
				terragen.brickdtb[terragen.brickcount] = "8x8F";
				terragen.brickcol[terragen.brickcount] = terragen.brown3;
			}
			else //optional simpler bridge support
			{
				for(%zz=-3; %zz<=3; %zz+=6)
				{
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*8 + %zz SPC %y*8 - 3 + 6*%adj SPC %z*20 - 9;
					terragen.brickdtb[terragen.brickcount] = "2x2";
					terragen.brickcol[terragen.brickcount] = terragen.brown3;
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*8 + %zz SPC %y*8 - 3 + 6*%adj SPC %z*20;
					terragen.brickdtb[terragen.brickcount] = "2x2x5 Lattice";
					terragen.brickcol[terragen.brickcount] = terragen.brown3;

					for(%zy=0; %zy<2; %zy++)
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*8 + %zz SPC %y*8 - 3 + 6*%adj SPC %z*20 + 8 + %zy;
						terragen.brickdtb[terragen.brickcount] = "2x2F";
						terragen.brickcol[terragen.brickcount] = terragen.brown3;
					}
				}
			}
		}

		for(%za=-2; %za<=2; %za+=4)
		{
			for(%zb=-3; %zb<=3; %zb+=6)
			{
				terragen.brickcount++;
				terragen.brickgrid[terragen.brickcount] = %x SPC %y;
				terragen.brickpos[terragen.brickcount] = %x*8 + %zb SPC %y*8 + %za SPC $terragen::roadlevel*20 + 13;
				terragen.brickdtb[terragen.brickcount] = "2x2x2 Cone";
				terragen.brickcol[terragen.brickcount] = terragen.brown3;
			}
		}				
	} //phew

	if(%height < $terragen::waterlevel && $terragen::size == 8)
	{
		for(%w=%a; %w<=$terragen::waterlevel; %w++)
		{
			terragen.brickcount++;
			terragen.brickgrid[terragen.brickcount] = %x SPC %y;
			terragen.brickpos[terragen.brickcount] = %x*8 SPC %y*8 SPC %w*20;
			terragen.brickdtb[terragen.brickcount] = "8x Water";
			terragen.brickcol[terragen.brickcount] = %charr ? terragen.green3 : terragen.blue1;
		}

		if(!terragen.chest)
		{
			if(terragen.height[%x, %y] == 0 && !getrandom(0, $terragen::rarity))
			{
				terragen.chest = true;

				for(%ca=-1; %ca<=1; %ca+=2)
				{
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*8 + %ca SPC %y*8 SPC 11;
					terragen.brickdtb[terragen.brickcount] = "2x2";
					terragen.brickcol[terragen.brickcount] = terragen.brown3;

					for(%cb=0; %cb<2; %cb++)
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*8 + %ca SPC %y*8 SPC 13 + %cb;
						terragen.brickdtb[terragen.brickcount] = "2x2F";
						terragen.brickcol[terragen.brickcount] = %cb ? terragen.brown3 : terragen.yellow1;
					}
				}
			}
		}
		//add any underwater hotness here.
	}
	else
	{
		if($terragen::size >= 8)
		{
			if(!%road || %tunnel)
			{
				if($terragen::size >= 16)
					%ftype = " Base";
				else
					%ftype = "F";

				if($terragen::size/2 >= 16)
					%htype = " Base";
				else
					%htype = "F";

				for(%b=$terragen::size*-0.25; %b<=$terragen::size/4; %b+=$terragen::size/2) //laziness
				{
					for(%c=$terragen::size*-0.25; %c<=$terragen::size/4; %c+=$terragen::size/2)
					{
						if(getrandom(0, 5 + $terragen::bump) > 5 && !%castle) //this is a good place to add your exceptions
						{
							if(%charr)
							{
								%xs = getrandom($terragen::size/8*-1, $terragen::size/8);
								%ys = getrandom($terragen::size/8*-1, $terragen::size/8);
								%scount = getrandom(0, $terragen::size);

								for(%s=0; %s<%scount; %s++)
								{
									terragen.brickcount++;
									terragen.brickgrid[terragen.brickcount] = %x SPC %y;
									terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %b + %xs SPC %y*$terragen::size + %c + %ys SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 1 + %s*3;
									terragen.brickdtb[terragen.brickcount] = "2x2 Round";
									terragen.brickcol[terragen.brickcount] = terragen.mono3;
								}
								terragen.brickcount++;
								terragen.brickgrid[terragen.brickcount] = %x SPC %y;
								terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %b + %xs SPC %y*$terragen::size + %c + %ys SPC  (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 3 + %s*3;
								terragen.brickdtb[terragen.brickcount] = "2x2x2 Cone";
								terragen.brickcol[terragen.brickcount] = terragen.mono3;
							}
							else
							{
								terragen.brickcount++;
								terragen.brickgrid[terragen.brickcount] = %x SPC %y;
								terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %b SPC %y*$terragen::size + %c SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/8)*15;
								terragen.brickdtb[terragen.brickcount] = $terragen::size/2 @ "x Cube";
								terragen.brickcol[terragen.brickcount] = terragen.brown1;
								terragen.brickcount++;
								terragen.brickgrid[terragen.brickcount] = %x SPC %y;
								terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %b SPC %y*$terragen::size + %c SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/8)*15 + ($terragen::size/8)*5;
								terragen.brickdtb[terragen.brickcount] = $terragen::size/2 @ "x" @ $terragen::size/2 @ %htype;
								terragen.brickcol[terragen.brickcount] = terragen.green1;
							}
						}
						else
						{
							if(!%charr)
							{
								terragen.brickcount++;
								terragen.brickgrid[terragen.brickcount] = %x SPC %y;
								terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %b SPC %y*$terragen::size + %c SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5;
								terragen.brickdtb[terragen.brickcount] = $terragen::size/2 @ "x" @ $terragen::size/2 @ %htype;
								terragen.brickcol[terragen.brickcount] = terragen.green1;
							}
							%unbump++;
						}
					}
				}
			}
			else if(!%bridge && !%tunnel) //add pebbles to road
			{
				if(getrandom(0, 19))
				{
					for(%d=($terragen::size/2 - 1)*-1; %d<=$terragen::size/2 - 1; %d+=2)
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*$terragen::size + getrandom(($terragen::size/4)*-1, $terragen::size/4) SPC %y*$terragen::size + %d SPC $terragen::roadlevel*$terragen::size*2.5 + ($terragen::size/4)*5;
						terragen.brickdtb[terragen.brickcount] = "2x2F Round";
						terragen.brickcol[terragen.brickcount] = terragen.mono1;
					}
				}
			}

			if(%unbump == 4 && (!%road || %tunnel))
			{
				if(!%charr)
				{
					terragen.brickcount-=3;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5;
					terragen.brickdtb[terragen.brickcount] = $terragen::size @ "x" @ $terragen::size @ %ftype;
					terragen.brickcol[terragen.brickcount] = terragen.green1;

					if(getrandom(0, 10 + $terragen::tree) > 10 && !%castle)
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size SPC (%a-1)*$terragen::size*2.5 + 22;
						terragen.brickdtb[terragen.brickcount] = "Pine Tree";
						terragen.brickcol[terragen.brickcount] = terragen.green2;
					}
				}
				else if(terragen.chest && !terragen.rykuta && mabs(%x - terragen.roadaxis) > 8 && (%y - (terragen.wastelandaxis + 8))*%y > 0 && %height == $terragen::height + 1 && !getrandom(0, $terragen::rarity))
				{
					%padj = %y/mabs(%y);

					for(%pa=-1; %pa<=1; %pa+=2)
					{
						for(%pb=-3; %pb<=1; %pb+=4)
						{
							terragen.brickcount++;
							terragen.brickgrid[terragen.brickcount] = %x SPC %y;
							terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %pa SPC %y*$terragen::size - %pb*%padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 1;
							terragen.brickdtb[terragen.brickcount] = "2x2 Round";
							terragen.brickcol[terragen.brickcount] = terragen.mono2;
						}
					}

					for(%pc=0; %pc<2; %pc++)
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size + %pc*2*%padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 4 + 3*%pc;
						terragen.brickdtb[terragen.brickcount] = "4x4";
						terragen.brickcol[terragen.brickcount] = terragen.rykuta1;

						for(%pd=-1; %pd<=1; %pd+=2)
						{
							terragen.brickcount++;
							terragen.brickgrid[terragen.brickcount] = %x SPC %y;
							terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %pd SPC %y*$terragen::size + (3 - 4*%pc)*%padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 4 + 3*%pc;
							terragen.brickdtb[terragen.brickcount] = "2x2";
							terragen.brickcol[terragen.brickcount] = terragen.rykuta1;
						}
					}
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size - %padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 9;
					terragen.brickdtb[terragen.brickcount] = "4x4F";
					terragen.brickcol[terragen.brickcount] = terragen.rykuta1;

					for(%pf=0; %pf<=2; %pf+=2)
					{
						for(%pe=-2; %pe<=2; %pe+=2)
						{
							if(!%pe && %pf) //is it mouth?
								%pca = 1;
							else
								%pca = 0;
							terragen.brickcount++;
							terragen.brickgrid[terragen.brickcount] = %x SPC %y;
							terragen.brickpos[terragen.brickcount] = %x*$terragen::size + %pe SPC %y*$terragen::size - (%pf + %pca)*%padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 11;
							terragen.brickdtb[terragen.brickcount] = "2x2";
							terragen.brickcol[terragen.brickcount] = terragen.rykuta1;

						}
					}
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size - %padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 14;
					terragen.brickdtb[terragen.brickcount] = "4x4";
					terragen.brickcol[terragen.brickcount] = terragen.rykuta1;
					terragen.brickcount++;
					terragen.brickgrid[terragen.brickcount] = %x SPC %y;
					terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size + 3*%padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 10;
					terragen.brickdtb[terragen.brickcount] = "2x2 Round";
					terragen.brickcol[terragen.brickcount] = terragen.rykuta1;

					if(!getrandom(0, 2))
					{
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size - %padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 16;
						terragen.brickdtb[terragen.brickcount] = "2x2F";
						terragen.brickcol[terragen.brickcount] = terragen.mono2;
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size - %padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 17;
						terragen.brickdtb[terragen.brickcount] = "2x2F Round";
						terragen.brickcol[terragen.brickcount] = terragen.mono3;
						terragen.brickcount++;
						terragen.brickgrid[terragen.brickcount] = %x SPC %y;
						terragen.brickpos[terragen.brickcount] = %x*$terragen::size SPC %y*$terragen::size - %padj SPC (%a-1)*$terragen::size*2.5 + ($terragen::size/4)*5 + 19;
						terragen.brickdtb[terragen.brickcount] = "2x2 Round";
						terragen.brickcol[terragen.brickcount] = terragen.mono2;
					}
						
					terragen.rykuta = true;

					if(%padj > 0)
						%ps = terragen.miny;
					else
						%ps = terragen.maxy;

					%psy = getrandom(%ps, $terragen::rarity*2*%padj*-1) - $terragen::height*%padj;

					for(%psa=-2; %psa<=2; %psa++)
					{
						for(%psb=-2; %psb<=2; %psb++)
						{
							terragen.height[%x + %psa, %psy + %psb] = $terragen::height - 1; //force a flat surface for castle ahead of time
							terragen.castle[%x + %psa, %psy + %psb] = %x SPC %psy;
						}
					}
				}
			}
		}
	}
	terragen.stackcount[%x, %y] = terragen.brickcount - %pcount;
	terragen.plangrid[%x, %y] = 1;
}

//misc functions

function terragen_togpause()
{
	if(!isobject(serverconnection))
	{
		echo("You are not connected to a server.");
		return 0;
	}

	if(!isobject(terragen))
	{
		echo("A Terrain Generation is not in progress.");
		return 0;
	}

	if(iseventpending(terragen.tick))
	{
		cancel(terragen.tick);
		commandtoserver('messagesent', "The Adventure has been paused.");
		deactivatepackage(terragen_package);
	}
	else
	{
		activatepackage(terragen_package);
		terragen_tick();
		commandtoserver('messagesent', "The Adventure has resumed!");
	}
}

function terragen_addobject(%path, %x, %y)
{
	if(!isfile(%path))
	{
		echo("Filepath:" SPC %path SPC "not found!");
		echo("Skipping object...");
		return 0;
	}

	if(!isobject(serverconnection))
	{
		echo("You are not connected to a server.");
		return 0;
	}

	if(!isobject(terragen))
	{
		echo("A Terrain Generation is not in progress!");
		return 0;
	}
	%file = new fileobject();
	%file.openforread(%path);

	while(!%file.iseof())
	{
		%line = %file.readline();
		%a = strpos(%line, "\"");
		terragen.brickcount++;
		terragen.brickgrid[terragen.brickcount] = %x SPC %y;
		terragen.brickdtb[terragen.brickcount] = getsubstr(%line, 0, %a);
		%b = getsubstr(%line, %a+1, strlen(%line)); //all numbers, positions calculated in shifts plz
		terragen.brickpos[terragen.brickcount] = %x*$terragen::size + getword(%b, 0) SPC %y*$terragen::size + getword(%b, 1) SPC terragen.height[%x, %y]*$terragen::size*2.5 + ($terragen::size/4)*5 + getword(%b, 2);
		terragen.brickcol[terragen.brickcount] = findclosestcolor(getword(%b, 3) SPC getword(%b, 4) SPC getword(%b, 5) SPC getword(%b, 6));
	}
	%file.close();
	%file.delete();
}

function terragen_add()
{
	if(!isobject(serverconnection))
	{
		echo("You are not connected to a server");
		return 0;
	}

	if(!isobject(terragen))
	{
		echo("A Terrain Generation is not in progress");
		return 0;
	}

	if($terragen::singleplayer)
		return 0;

	if(!isobject(%p = serverconnection.getcontrolobject()))
	{
		echo("You are not spawned.");
		return 0;
	}
	%posa = %p.getposition();

	for(%a=terragen.group.getcount()-1; %a>-1; %a--)
	{
		if((%b = terragen.group.getobject(%a)).getclassname() $= "Player")
		{
			if(terragen.advobj[%b] $= "")
			{
				%dist = vectordist(%posa, terragen_getplayerpos(%b));

				if(%dist < %bestdist || %bestid $= "")
				{
					%bestdist = %dist;
					%bestid = %b;
				}
			}
		}
	}

	if(%bestid $= "")
	{
		echo("No new players found");
		return 0;
	}
	terragen.advobj[%bestid] = %bestid.getshapename();
	terragen.adventurer[terragen.adventurercount] = %bestid;
	terragen.adventurercount++;

	if($terragen::message)
		commandtoserver('messagesent', terragen.advobj[%bestid] SPC "has become an adventurer!");
}

function terragen_remove(%x)
{
	if($terragen::singleplayer)
		return 0;

	if(%x $= "")
		%x = 0;
	%a = terragen.advobj[terragen.adventurer[%x]];
	terragen.advobj[terragen.adventurer[%x]] = "";

	for(%d=%x; %d<terragen.adventurercount-1; %d++)
		terragen.adventurer[%d] = terragen.adventurer[%d+1];
	terragen.adventurer[terragen.adventurercount] = "";
	terragen.adventurercount--;

	if($terragen::message)
		commandtoserver('messagesent', %a SPC "is no longer an adventurer.");
}

function terragen_removeall()
{
	if($terragen::singleplayer)
		return 0;

	for(%a=0; %a<terragen.adventurercount; %a++)
	{
		terragen.advobj[terragen.adventurer[%a]] = "";
		terragen.adventurer[%a] = "";
	}
	terragen.adventurercount = 0;

	if($terragen::message)
		commandtoserver('messagesent', "All adventurers have been fired.");
}

function terragen_getplayerpos(%x) //based on aimbot, i cannot believe it has to be done this way
{
	if($terragen::singleplayer)
		return serverconnection.getcontrolobject().getposition();

	if(isObject(terragen_falseadventurer))
		terragen_falseadventurer.delete();
	%name = %x.getName();
	%x.setName(terragen_trueadventurer);

	new Player(terragen_falseadventurer : terragen_trueadventurer)
	{
		datablock = terragen_trueadventurer.getDatablock();
	};
	%pos = terragen_falseadventurer.getPosition();
	terragen_falseadventurer.delete();
	%x.setName("");
	%x.setName(%name);
	return %pos;
}

function terragen_getgridpos(%pos) //input unit position
{
	if(!isobject(terragen))
	{
		echo("No Terrain Generation in progress.");
		return 0;
	}
	%x = mround((getword(%pos, 0) - getword(terragen.origin, 0))/($terragen::size/2));
	%y = mround((getword(%pos, 1) - getword(terragen.origin, 1))/($terragen::size/2));
	return %x SPC %y; //output sexy grid position
}

function terragen_exportbuildbot() //converts the buildbot_loadingSO into a file that can be used by terragen
{
	if(!isobject(buildbot_loadingso))

		return 0;
	

%file = new fileobject();
	
%x=0;

	
while(isfile("config/buildbotexport" @ %x @ ".txt"))

		%x++;
	
%file.openforwrite("config/buildbotexport" @ %x @ ".txt");
	
%xi = getword(buildbot_loadingso.brickpos1, 0);
	
%yi = getword(buildbot_loadingso.brickpos1, 1);
	
%zi = getword(buildbot_loadingso.brickpos1, 2);

	

for(%a=1; %a<=buildbot_loadingso.brickcount; %a++)
		%file.writeline(buildbot_loadingso.brickdtb[%a] @ "\"" @ getword(buildbot_loadingso.brickpos[%a], 0) - %xi SPC getword(buildbot_loadingso.brickpos[%a], 1) - %yi SPC getword(buildbot_loadingso.brickpos[%a], 2) - %zi SPC buildbot_loadingso.colortable[buildbot_loadingso.brickcol[%a]]);
	
%file.close();

	%file.delete();
}

//package

package terragen_package
{
	function clientcmdservermessage(%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l)
	{
		if(isObject(terragen))
		{
			if(strpos(%a,"MsgPlantError") > -1)
				terragen.brickerror = true;
		}
		return parent::clientcmdservermessage(%a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l);
	}

//disabled functions

	function plantbrick(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::plantbrick(%x);
	}

	function mousefire(%x)
	{
		if(isobject(terragen) && !$terragen_mousefire)
			return 0;
		else
			parent::mousefire(%x);
	}

	function shiftbrickaway(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickaway(%x);
	}

	function shiftbricktowards(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbricktowards(%x);
	}

	function shiftbrickleft(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickleft(%x);
	}

	function shiftbrickright(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickright(%x);
	}

	function shiftbrickup(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickup(%x);
	}

	function shiftbrickdown(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickdown(%x);
	}

	function shiftbrickthirdup(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickthirdup(%x);
	}

	function shiftbrickthirddown(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::shiftbrickthirddown(%x);
	}

	function supershiftbrickawayproxy(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::supershiftbrickawayproxy(%x);
	}

	function supershiftbricktowardsproxy(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::supershiftbricktowardsproxy(%x);
	}

	function supershiftbrickleftproxy(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::supershiftbrickleftproxy(%x);
	}

	function supershiftbrickrightproxy(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::supershiftbrickrightproxy(%x);
	}

	function supershiftbrickupproxy(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::supershiftbrickupproxy(%x);
	}

	function supershiftbrickdownproxy(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::supershiftbrickdownproxy(%x);
	}

	function playbackbuildmacro(%x)
	{
		if(isobject(terragen))
			return 0;
		else
			parent::playbackbuildmacro(%x);
	}
};

//things not specific to terragen

function mround(%x) //why is this not default
{
	return mfloor(%x + 0.5);
}

function getplayerdirection()
{
	if(isObject(%p = serverconnection.getcontrolobject()))
	{
		%va = getword(%p.getforwardvector(),0);
		%vb = getword(%p.getforwardvector(),1);

		if(mabs(%va) > mabs(%vb))
		{
			if(%va > 0)
				return 0;
			else
				return 2;
		}
		else
		{
			if(%vb > 0)
				return 1;
			else
				return 3;
		}
	}
	else
		return 4;
}

function findclosestcolor(%x) //input four numbers between 0 and 1
{
	for(%a=0; %a<64; %a++)
	{
		%match = mabs(getword(getcoloridtable(%a),0) - getword(%x,0)) + mabs(getword(getcoloridtable(%a),1) - getword(%x,1)) + mabs(getword(getcoloridtable(%a),2) - getword(%x,2)) + mabs(getword(getcoloridtable(%a),3) - getword(%x,3))*4;

		if(%match < %bestmatch || %bestmatch $= "")
		{
			%bestmatch = %match;
			%bestid = %a;
		}
	}
	return %bestid; //trans may be messed up if you input a nearly-but-not-quite opaque color
}

function findplayerbyname(%name)
{
	if(!isobject(serverconnection))
	{
		echo("You are not connected to a server");
		return 0;
	}

	if(!isobject(serverconnection.getcontrolobject()))
	{
		echo("You cannot see other players at this time.");
		return 0;
	}
	%group = serverconnection.getcontrolobject().getgroup();

	for(%a=0; %a<%group.getcount(); %a++)
	{
		if((%b = %group.getobject(%a)).getclassname() $= "Player")
		{
			if(strPos(%b.getshapename(), %name) > -1) //case sensitive
				return %b;

		}
	}
	return -1;
}

//non-function code

exec("./TerragenGUI.gui");
exec("./TerragenGUI2.gui");

if(!$terragenbinds)
{
	$remapdivision[$remapcount] = "Terragen";
	$remapname[$remapcount] = "Toggle GUI";
	$remapcmd[$remapcount] = "terragengui_tog";
	$remapcount++;
	$terragenbinds = 1;
}
terragen_defaults(); //set defaults then read file, in case of missing variables in the file.

if(isfile("config/client/terragen/prefs.cs"))
	exec("config/client/terragen/prefs.cs");
terragengui_apply();
terragengui_save();