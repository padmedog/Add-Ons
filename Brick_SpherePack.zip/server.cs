datablock fxDTSBrickData(brick1xSphereSmoothData)
{
	brickFile = "./1xSphere_Smooth.blb";
	iconName = "Add-Ons/Brick_SpherePack/sphere2";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x Smooth Sphere";
};
datablock fxDTSBrickData(brick1xSphereFlatData)
{
	brickFile = "./1xSphere_Flat.blb";
	iconName = "Add-Ons/Brick_SpherePack/sphere1";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x Flat Sphere";
};

datablock fxDTSBrickData(brick2xSphereSmoothData)
{
	brickFile = "./2xSphere_Smooth.blb";
	iconName = "Add-Ons/Brick_SpherePack/sphere2";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x Smooth Sphere";
};
datablock fxDTSBrickData(brick2xSphereFlatData)
{
	brickFile = "./2xSphere_Flat.blb";
	iconName = "Add-Ons/Brick_SpherePack/sphere1";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x Flat Sphere";
};

datablock fxDTSBrickData(brick8xDomeSmoothData)
{
	brickFile = "./8xDome_Smooth.blb";
	iconName = "Add-Ons/Brick_SpherePack/dome2";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "8x Smooth Dome";
};
datablock fxDTSBrickData(brick8xDomeFlatData)
{
	brickFile = "./8xDome_Flat.blb";
	iconName = "Add-Ons/Brick_SpherePack/dome1";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "8x Flat Dome";
};
datablock fxDTSBrickData(brick16xDomeSmoothData)
{
	brickFile = "./16xDome_Smooth.blb";
	iconName = "Add-Ons/Brick_SpherePack/dome2";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "16x Smooth Dome";
};
datablock fxDTSBrickData(brick16xDomeFlatData)
{
	brickFile = "./16xDome_Flat.blb";
	iconName = "Add-Ons/Brick_SpherePack/dome1";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "16x Flat Dome";
};
datablock fxDTSBrickData(brick32xDomeSmoothData)
{
	brickFile = "./32xDome_Smooth.blb";
	iconName = "Add-Ons/Brick_SpherePack/dome2";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "32x Smooth Dome";
};
datablock fxDTSBrickData(brick32xDomeFlatData)
{
	brickFile = "./32xDome_Flat.blb";
	iconName = "Add-Ons/Brick_SpherePack/dome1";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "32x Flat Dome";
};
