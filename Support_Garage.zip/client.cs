//--- OBJECT WRITE BEGIN ---
if(isObject(Garage))
   Garage.delete();
$GarageClient::Path=filePath(expandFileName("./description.txt"));
new GuiControl(Garage) {
   profile = "GuiDefaultProfile";
   horizSizing = "right";
   vertSizing = "bottom";
   position = "0 0";
   extent = "640 480";
   minExtent = "8 2";
   enabled = "1";
   visible = "1";
   clipToParent = "1";

   new GuiWindowCtrl() {
      profile = "GuiWindowProfile";
      horizSizing = "right";
      vertSizing = "bottom";
      position = "95 59";
      extent = "371 370";
      minExtent = "8 2";
      enabled = "1";
      visible = "1";
      clipToParent = "1";
      accelerator = "escape";
      text = "Customize Vehicle";
      maxLength = "255";
      resizeWidth = "0";
      resizeHeight = "0";
      canMove = "1";
      canClose = "1";
      canMinimize = "0";
      canMaximize = "0";
      minSize = "50 50";
      closeCommand = "canvas.popdialog(\"Garage\");";

      new GuiScrollCtrl(Garage_TypeScroll) {
         profile = "GuiScrollProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "10 31";
         extent = "111 227";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         willFirstRespond = "0";
         hScrollBar = "alwaysOff";
         vScrollBar = "dynamic";
         constantThumbHeight = "0";
         childMargin = "0 0";
         rowHeight = "40";
         columnWidth = "30";
         
         new GuiSwatchCtrl(Garage_TypeSwatch) {
            profile = "GuiDefaultProfile";
            horizSizing = "right";
            vertSizing = "bottom";
            position = "0 0";
            extent = "111 2";
            minExtent = "8 2";
            enabled = "1";
            visible = "1";
            clipToParent = "1";
            color = "200 200 200 255";
         };
      };
      
      new GuiScrollCtrl(Garage_PartScroll) {
         profile = "GuiScrollProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "130 31";
         extent = "111 227";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         willFirstRespond = "0";
         hScrollBar = "alwaysOff";
         vScrollBar = "dynamic";
         constantThumbHeight = "0";
         childMargin = "0 0";
         rowHeight = "40";
         columnWidth = "30";
         
         new GuiSwatchCtrl(Garage_PartSwatch) {
            profile = "GuiDefaultProfile";
            horizSizing = "right";
            vertSizing = "bottom";
            position = "0 0";
            extent = "111 2";
            minExtent = "8 2";
            enabled = "1";
            visible = "1";
            clipToParent = "1";
            color = "200 200 200 255";
         };
      };
      
      new GuiScrollCtrl(Garage_NameScroll) {
         profile = "GuiScrollProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "250 31";
         extent = "111 227";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         willFirstRespond = "0";
         hScrollBar = "alwaysOff";
         vScrollBar = "dynamic";
         constantThumbHeight = "0";
         childMargin = "0 0";
         rowHeight = "40";
         columnWidth = "30";
         
         new GuiSwatchCtrl(Garage_NameSwatch) {
            profile = "GuiDefaultProfile";
            horizSizing = "right";
            vertSizing = "bottom";
            position = "0 0";
            extent = "111 2";
            minExtent = "8 2";
            enabled = "1";
            visible = "1";
            clipToParent = "1";
            color = "200 200 200 255";
         };
      };
      
      new GuiSliderCtrl(Garage_SliderB) {
         profile = "GuiSliderProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "101 332";
         extent = "124 32";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         command = "GarageGui_ColorUpdate();";
         variable = "$Garage::ColorB";
         range = "0.000000 255.000000";
         ticks = "16";
         value = "255";
         snap = "1";
      };
      
      new GuiSliderCtrl(Garage_SliderG) {
         profile = "GuiSliderProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "101 302";
         command = "GarageGui_ColorUpdate();";
         extent = "124 32";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         variable = "$Garage::ColorG";
         range = "0.000000 255.000000";
         ticks = "16";
         value = "255";
         snap = "1";
      };
      
      new GuiSliderCtrl(Garage_SliderR) {
         profile = "GuiSliderProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "101 272";
         command = "GarageGui_ColorUpdate();";
         extent = "124 32";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         variable = "$Garage::ColorR";
         range = "0.000000 255.000000";
         ticks = "16";
         value = "255";
         snap = "1";
      };
      
      new GuiSwatchCtrl(Garage_Swatch) {
         profile = "GuiDefaultProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "11 267";
         extent = "88 95";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         color = "255 255 255 255";
      };
   };
};
//--- OBJECT WRITE END ---
$Garage::CurrentColor="255 255 255";
function GarageGui_ColorUpdate()
{
   $Garage::ColorR=mFloor($Garage::ColorR);
   $Garage::ColorG=mFloor($Garage::ColorG);
   $Garage::ColorB=mFloor($Garage::ColorB);
   Garage_Swatch.color=$Garage::ColorR SPC $Garage::ColorG SPC $Garage::ColorB SPC 255;
   Garage_Swatch.refreshAllValues();
   $Garage::CurrentColor=$Garage::ColorR SPC $Garage::ColorG SPC $Garage::ColorB;
}
function clientcmdOpenGarage()
{
   if(!Garage.isAwake())
      canvas.pushDialog(Garage);
}
function clientcmdGarage_AddPart(%type,%part,%name)
{
   if(!$GarageClient::IsType[%type])
   {
      $GarageClient::Type[mFloor($GarageClient::Types)]=%type;
      $GarageClient::IsType[%type]=1;
      $GarageClient::Types++;
      //Garage_addListElement(%list,%name,%image,%command);
      Garage_addListElement(Garage_TypeSwatch,%type,%type,"Garage_SelectType(\""@%type@"\");");
   }
   if(!$GarageClient::IsPart[%type,%part])
   {
      $GarageClient::Part[%type,mFloor($GarageClient::Parts[%type])]=%part;
      $GarageClient::IsPart[%type,%part]=1;
      $GarageClient::Parts[%type]++;
   }
   if(!$GarageClient::IsName[%type,%part,%name])
   {
      $GarageClient::Name[%type,%part,mFloor($GarageClient::Names[%type,%part])]=%name;
      $GarageClient::IsName[%type,%part,%name]=1;
      $GarageClient::Names[%type,%part]++;
   }
}
function Garage::onWake(%this)
{
   if(!%this.LoadedParts)
   {
      Garage_TypeSwatch.deleteAll();
      Garage_TypeSwatch.extent="111 2";
      Garage_PartSwatch.deleteAll();
      Garage_PartSwatch.extent="111 2";
      Garage_NameSwatch.deleteAll();
      Garage_NameSwatch.extent="111 2";
      deleteVariables("$GarageClient::*");
      %this.LoadedParts=1;
      commandtoserver('Garage_GetPartList');
   }
}
function Garage_SelectType(%type)
{
   Garage_PartSwatch.deleteAll();
   Garage_PartSwatch.extent="111 2";
   //%type=Garage_TypeList.item[Garage_TypeList.getSelectedID()];
   $GarageClient::SelectedType=%type;
   for(%i=0;%i<$GarageClient::Parts[%type];%i++)
   {
      %part=$GarageClient::Part[%type,%i];
      //Garage_addListElement(%list,%name,%image,%command);
      Garage_addListElement(Garage_PartSwatch,%part,%type@"_"@%part@"_Default","Garage_SelectPart(\""@%part@"\");");
   }
}
function Garage_SelectPart(%part)
{
   Garage_NameSwatch.deleteAll();
   Garage_NameSwatch.extent="111 2";
   %type=$GarageClient::SelectedType;
   $GarageClient::SelectedPart=%part;
   for(%i=0;%i<$GarageClient::Names[%type,%part];%i++)
   {
      %name=$GarageClient::Name[%type,%part,%i];
      //Garage_addListElement(%list,%name,%image,%command);
      Garage_addListElement(Garage_NameSwatch,%name,%type@"_"@%part@"_"@%name,"Garage_SelectName(\""@%name@"\");");
   }
}
function Garage_SelectName(%name)
{
   %part=$GarageClient::SelectedPart;
   $GarageClient::SelectedName=%name;
   commandtoserver('Garage_ToggleMessages',1);
   commandtoserver('setPart',%part,%name);
   commandtoserver('colorPart',%part,$Garage::ColorR,$Garage::ColorG,$Garage::ColorB);
   commandtoserver('Garage_ToggleMessages',0);
}
function Garage_addListElement(%list,%name,%path,%command)
{
   if(%list.getCount()>0)
      %prev=%list.getObject(%list.getCount()-1);
   %path="*/"@%path@".png";
   if(strLen($GarageClient::FoundFile[%path]))
      %image=$GarageClient::FoundFile[%path];
   else
      $GarageClient::FoundFile[%path]=%image=findFirstFile(%path);
   if(!isFile(%image))
      %image="add-ons/Support_Garage/Unknown.png";
   %swatch = new GuiSwatchCtrl() {
      profile = "GuiDefaultProfile";
      horizSizing = "right";
      vertSizing = "bottom";
      position = "0 "@(isObject(%prev)?getWord(%prev.position,1)+48:0);
      extent = "111 48";
      minExtent = "8 2";
      enabled = "1";
      visible = "1";
      clipToParent = "1";
      color = "150 150 150 "@(%list.getCount()% 2?255:0);

      new GuiBitmapCtrl() {
         profile = "GuiDefaultProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "8 8";
         extent = "32 32";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         text = "";
         groupNum = "-1";
         buttonType = "PushButton";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "0";
         mColor = "255 255 255 255";
         bitmap=%image;
      };
      
      new GuiMLTextCtrl() {
         profile = "HUDChatTextEditSize4Profile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "48 8";
         extent = "52 20";
         minExtent = "8 2";
         enabled = "1";
         text = "<font:impact:18><color:ffffff>"@%name;
         visible = "1";
         clipToParent = "1";
         maxLength = "255";
      };
      
      new GuiBitmapButtonCtrl() {
         profile = "GuiDefaultProfile";
         horizSizing = "right";
         vertSizing = "bottom";
         position = "0 0";
         extent = "111 48";
         minExtent = "8 2";
         enabled = "1";
         visible = "1";
         clipToParent = "1";
         text = "";
         groupNum = "-1";
         buttonType = "PushButton";
         lockAspectRatio = "0";
         alignLeft = "0";
         alignTop = "0";
         overflowImage = "0";
         mKeepCached = "0";
         mColor = "255 255 255 0";
         command=%command;
      };
   };
   %list.add(%swatch);
   %list.extent="111 "@(getWord(%list.getObject(%list.getCount()-1).position,1)+48);
   %a=Garage.isAwake();
   if(%a)
      canvas.popDialog(Garage);
   canvas.pushDialog(Garage);
   if(!%a)
      canvas.pushDialog(Garage);
   return %swatch;
}