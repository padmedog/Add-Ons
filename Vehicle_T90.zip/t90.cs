//########## T-90

//### Sound

datablock AudioProfile(gc_t90FireSound)
{
  filename = "./t90fire.wav";
  description = AudioDefault3d;
  preload = true;
};

datablock AudioProfile(gc_T90MGFireSound)
{
  filename = "./mgfire.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_OverheatSound)
{
  filename = "./overheat.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_bulletBySound)
{
  filename = "./bulletby.wav";
  description = AudioClosestLooping3d;
  preload = true;
};

datablock AudioProfile(gc_bulletHit1Sound)
{
  filename = "./bulletImpact1.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_tireParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.4 0.4 0.4 0.3";
  colors[1] = "0.2 0.2 0.2 0";
  sizes[0] = 2;
  sizes[1] = 6;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_tireEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 25;
  ejectionVelocity = 2;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_tireParticle";
  useEmitterColors = true;
};

datablock ParticleData(gc_vehicleDamageParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = -2;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0 0 0 0";
  colors[1] = "0 0 0 0.5";
  colors[2] = "0 0 0 0";
  sizes[0] = 3;
  sizes[1] = 4;
  sizes[2] = 6;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_vehicleDamageEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 25;
  ejectionVelocity = 2;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_vehicleDamageParticle";
  useEmitterColors = true;
};

datablock ParticleData(gc_OverheatParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = -1.5;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 600;
  lifetimeVarianceMS = 200;
  textureName = "base/data/particles/cloud";
  spinSpeed = 1;
  spinRandomMin = -5;
  spinRandomMax = 5;
  colors[0] = "1 1 1 0.8";
  colors[1] = "1 1 1 0";
  sizes[0] = 0.2;
  sizes[1] = 0.8;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_OverheatEmitter)
{
  uiName = "";
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 1;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_OverheatParticle";
  useEmitterColors = true;
};

datablock ShapeBaseImageData(gc_OverheatMount1Image)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 1;

  stateName[0] = "Fire";
  stateTransitionOnTimeout[0] = "Done";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 2;
  stateEmitter[0] = gc_OverheatEmitter;
  stateEmitterTime[0] = 2;

  stateName[1] = "Done";
  stateScript[1] = "onDone";
};
function gc_OverheatMount1Image::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

datablock ParticleData(gc_BulletDebrisExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  textureName = "base/data/particles/chunk";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.2 0.2 0.2 1";
  colors[1] = "0.2 0.2 0.2 0";
  sizes[0] = 0.2;
  sizes[1] = 0.2;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_BulletDebrisExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 16;
  velocityVariance = 8;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 30;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_BulletDebrisExplosionParticle";
};

datablock ParticleData(gc_BulletExplosionSmokeParticle)
{
  dragCoefficient = 6;
  gravityCoefficient = 0.2;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1400;
  lifetimeVarianceMS = 200;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.6 0.6 0.6 1";
  colors[1] = "0.6 0.6 0.6 0.2";
  colors[2] = "0.4 0.4 0.4 0";
  sizes[0] = 0.5;
  sizes[1] = 0.6;
  sizes[2] = 5;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_BulletExplosionSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 8;
  periodVarianceMS = 0;
  ejectionVelocity = 9;
  velocityVariance = 8;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 30;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_BulletExplosionSmokeParticle";
};

datablock ExplosionData(gc_MGBulletExplosion)
{
  lifeTimeMS = 50;
  emitter[0] = gc_BulletExplosionSmokeEmitter;
  emitter[1] = gc_BulletDebrisExplosionEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "1 1 1";
  camShakeDuration = 0.5;
  camShakeRadius = 1;
  soundProfile = gc_BulletHit1Sound;
};

datablock ParticleData(gc_TracerParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 50;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/dot";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.9 0.4 0.5";
  colors[2] = "1 0.2 0.1 0.5";
  sizes[0] = 0.2;
  sizes[1] = 0;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_TracerEmitter)
{
  uiName = "";
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_TracerParticle";
};

datablock ParticleData(gc_T90FlashParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 50;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  spinSpeed = 50;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "1 0.5 0 1";
  colors[1] = "1 0.8 0.6 1";
  colors[2] = "1 0.3 0.1 0";
  sizes[0] = 10;
  sizes[1] = 6;
  sizes[2] = 4;
  times[9] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_T90FlashEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 250;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 10;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_T90FlashParticle";
};

datablock ParticleData(gc_T90SmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.2;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 800;
  lifetimeVarianceMS = 400;
  textureName = "base/data/particles/cloud";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0.3";
  colors[2] = "0 0 0 0";
  sizes[0] = 5;
  sizes[1] = 6;
  sizes[2] = 10;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = true;
};

datablock ParticleEmitterData(gc_T90SmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = 30;
  velocityVariance = 20;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 60;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_T90SmokeParticle";
};

datablock ShapeBaseImageData(gc_T90FireImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 1;

  stateName[0] = "FireA";
  stateTransitionOnTimeout[0] = "FireB";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 0.05;
  stateEmitter[0] = gc_T90FlashEmitter;
  stateEmitterTime[0] = 0.05;

  stateName[1] = "FireB";
  stateTransitionOnTimeout[1] = "Done";
  stateWaitForTimeout[1] = true;
  stateTimeoutValue[1] = 0.05;
  stateEmitter[1] = gc_T90SmokeEmitter; 
  stateEmitterTime[1] = 0.2;

  stateName[2] = "Done";
  stateScript[2] = "onDone";
};

function gc_T90FireImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

datablock ParticleData(gc_MGFlashParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 1;
  constantAcceleration = 0;
  lifetimeMS = 50;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/cloud";
  spinSpeed = 50;
  spinRandomMin = -500;
  spinRandomMax = 500;
  colors[0] = "1 0.5 0 1";
  colors[1] = "1 0.8 0.6 1";
  colors[2] = "1 0.3 0.1 0";
  sizes[0] = 0.1;
  sizes[1] = 1;
  sizes[2] = 0;
  times[9] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_MGFlashEmitter)
{
  uiName = "";
  ejectionPeriodMS = 3;
  periodVarianceMS = 0;
  ejectionVelocity = -100;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 0;
  thetaMax = 10;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_MGFlashParticle";
};

datablock ShapeBaseImageData(gc_MGFireImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = 1;

  stateName[0] = "Fire";
  stateTransitionOnTimeout[0] = "Done";
  stateWaitForTimeout[0] = true;
  stateTimeoutValue[0] = 0.05;
  stateEmitter[0] = gc_MGFlashEmitter;
  stateEmitterTime[0] = 0.05;

  stateName[1] = "Done";
  stateScript[1] = "onDone";
};

function gc_MGFireImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

datablock ParticleData(gc_T90ShellExplosionParticle)
{
  dragCoefficient = 0;
  gravityCoefficient = 0;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 100;
  lifetimeVarianceMS = 0;
  textureName = "base/data/particles/star1";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "1 0.6 0.2 1";
  colors[1] = "1 0 0 0";
  sizes[0] = 16;
  sizes[1] = 12;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_T90ShellExplosionEmitter)
{
  uiName = "";
  ejectionPeriodMS = 1;
  periodVarianceMS = 0;
  ejectionVelocity = 5;
  velocityVariance = 0;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_T90ShellExplosionParticle";
};

datablock ParticleData(gc_T90ShellSmokeParticle)
{
  dragCoefficient = 4;
  gravityCoefficient = 0.5;
  inheritedVelFactor = 0.2;
  constantAcceleration = 0;
  lifetimeMS = 3500;
  lifetimeVarianceMS = 1500;
  textureName = "base/data/particles/cloud";
  spinSpeed = 0;
  spinRandomMin = -1;
  spinRandomMax = 1;
  colors[0] = "0 0 0 1";
  colors[1] = "0 0 0 0";
  sizes[0] = 8;
  sizes[1] = 16;
  useInvAlpha = true;
  windCoefficient = 1;
};

datablock ParticleEmitterData(gc_T90ShellSmokeEmitter)
{
  uiName = "";
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 10;
  velocityVariance = 1;
  ejectionOffset = 2.5;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_T90ShellSmokeParticle";
};

datablock ExplosionData(gc_t90ShellExplosion)
{
  lifeTimeMS = 100;
  emitter[0] = gc_T90ShellExplosionEmitter;
  emitter[1] = gc_T90ShellSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  lightStartRadius = 6;
  lightEndRadius = 0;
  lightStartColor = "1 0.6 0.2";
  lightEndColor = "0 0 0";
  damageRadius = 6;
  radiusDamage = 200;
  impulseRadius = 6;
  impulseForce = 200;
  soundProfile = gc_ExplosionSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "8 8 8";
  camShakeDuration = 2;
  camShakeRadius = 12;
};

//### Projectile

AddDamageType("T90",'<bitmap:Add-Ons/Vehicle_T90/CI_t90>%1','%2<bitmap:Add-Ons/Vehicle_T90/CI_t90>%1',1,1);

datablock ProjectileData(gc_T90ShellProjectile)
{
  uiName = "";
  projectileShapeName = "./t90projectile.dts";
  directDamage = 250;
  directDamageType = $DamageType::T90;
  radiusDamageType = $DamageType::T90;
  brickExplosionRadius = 5;
  brickExplosionImpact = true;
  brickExplosionForce = 100;
  brickExplosionMaxVolume = 100;
  brickExplosionMaxVolumeFloating = 100;
  impactImpulse = 200;
  explosion = gc_T90ShellExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  armingDelay = 0;
  lifetime = 5000;
  fadeDelay = 5000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 0.25;
  hasLight = 1;
  lightRadius = 5;
  lightColor = "1 0.5 0";
  explodeOnDeath = 1;
};

AddDamageType("gc_T90MG",'<bitmap:Add-Ons/Vehicle_T90/CI_mg> %1','%2 <bitmap:Add-Ons/Vehicle_T90/CI_mg> %1',0.2,1);

datablock ProjectileData(gc_T90MGProjectile)
{
  uiName = "";
  projectileShapeName = "";
  directDamage = 30;
  directDamageType = $DamageType::gc_T90MG;
  radiusDamageType = $DamageType::gc_T90MG;
  brickExplosionRadius = 0;
  brickExplosionImpact = true;
  brickExplosionForce = 37;
  brickExplosionMaxVolume = 6;
  brickExplosionMaxVolumeFloating = 6;
  impactImpulse = 75;
  explosion = gc_MGBulletExplosion;
  particleEmitter = gc_TracerEmitter;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  lifetime = 4000;
  fadeDelay = 4000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 0.25;
  sound = gc_bulletBySound;
};

//### Turret & MG

datablock TSShapeConstructor(t90turretDts)
{
  baseShape = "./t90turret.dts";
  sequence0 = "./root.dsq root";
  sequence1 = "./root.dsq run";
  sequence2 = "./root.dsq walk";
  sequence3 = "./root.dsq back";
  sequence4 = "./root.dsq side";
  sequence5 = "./root.dsq crouch";
  sequence6 = "./root.dsq crouchRun";
  sequence7 = "./root.dsq crouchBack";
  sequence8 = "./root.dsq crouchSide";
  sequence9 = "./look.dsq look";
  sequence10 = "./root.dsq headside";
  sequence11 = "./root.dsq headUp";
  sequence12 = "./root.dsq jump";
  sequence13 = "./root.dsq standjump";
  sequence14 = "./root.dsq fall";
  sequence15 = "./root.dsq land";
  sequence16 = "./root.dsq armAttack";
  sequence17 = "./root.dsq armReadyLeft";
  sequence18 = "./root.dsq armReadyRight";
  sequence19 = "./root.dsq armReadyBoth";
  sequence20 = "./root.dsq spearready";
  sequence21 = "./root.dsq spearThrow";
  sequence22 = "./root.dsq talk";
  sequence23 = "./root.dsq death1";
  sequence24 = "./root.dsq shiftUp";
  sequence25 = "./root.dsq shiftDown";
  sequence26 = "./root.dsq shiftAway";
  sequence27 = "./root.dsq shiftTo";
  sequence28 = "./root.dsq shiftLeft";
  sequence29 = "./root.dsq shiftRight";
  sequence30 = "./root.dsq rotCW";
  sequence31 = "./root.dsq rotCCW";
  sequence32 = "./root.dsq undo";
  sequence33 = "./root.dsq plant";
  sequence34 = "./root.dsq sit";
  sequence35 = "./root.dsq wrench";
};

datablock TSShapeConstructor(t90mgDts)
{
  baseShape = "./t90mg.dts";
  sequence0 = "./mg_root.dsq root";
  sequence1 = "./mg_root.dsq run";
  sequence2 = "./mg_root.dsq walk";
  sequence3 = "./mg_root.dsq back";
  sequence4 = "./mg_root.dsq side";
  sequence5 = "./mg_root.dsq crouch";
  sequence6 = "./mg_root.dsq crouchRun";
  sequence7 = "./mg_root.dsq crouchBack";
  sequence8 = "./mg_root.dsq crouchSide";
  sequence9 = "./mg_look.dsq look";
  sequence10 = "./mg_root.dsq headside";
  sequence11 = "./mg_root.dsq headUp";
  sequence12 = "./mg_root.dsq jump";
  sequence13 = "./mg_root.dsq standjump";
  sequence14 = "./mg_root.dsq fall";
  sequence15 = "./mg_root.dsq land";
  sequence16 = "./mg_root.dsq armAttack";
  sequence17 = "./mg_root.dsq armReadyLeft";
  sequence18 = "./mg_root.dsq armReadyRight";
  sequence19 = "./mg_root.dsq armReadyBoth";
  sequence20 = "./mg_root.dsq spearready";
  sequence21 = "./mg_root.dsq spearThrow";
  sequence22 = "./mg_root.dsq talk";
  sequence23 = "./mg_root.dsq death1";
  sequence24 = "./mg_root.dsq shiftUp";
  sequence25 = "./mg_root.dsq shiftDown";
  sequence26 = "./mg_root.dsq shiftAway";
  sequence27 = "./mg_root.dsq shiftTo";
  sequence28 = "./mg_root.dsq shiftLeft";
  sequence29 = "./mg_root.dsq shiftRight";
  sequence30 = "./mg_root.dsq rotCW";
  sequence31 = "./mg_root.dsq rotCCW";
  sequence32 = "./mg_root.dsq undo";
  sequence33 = "./mg_root.dsq plant";
  sequence34 = "./mg_root.dsq sit";
  sequence35 = "./mg_root.dsq wrench";
  sequence36 = "./mg_fire.dsq fire";
};

datablock PlayerData(gc_t90TurretPlayer)
{
  renderFirstPerson = true;
  emap = false;
  className = Armor;
  shapeFile = "./t90turret.dts";
  cameraMaxDist = 8;
  cameraTilt = 0.261;
  cameraVerticalOffset = 2.3;
  cameraDefaultFov = 90;
  cameraMinFov = 5;
  cameraMaxFov = 120;
  aiAvoidThis = true;
  minLookAngle = -1.5708;
  maxLookAngle = 0.5;
  maxFreelookAngle = 3;
  mass = 200000;
  drag = 1;
  density = 5;
  maxDamage = 400;
  maxEnergy = 10;
  repairRate = 0.33;
  rechargeRate = 0.4;
  runForce = 1000;
  runEnergyDrain = 0;
  minRunEnergy = 0;
  maxForwardSpeed = 0;
  maxBackwardSpeed = 0;
  maxSideSpeed = 0;
  maxForwardCrouchSpeed = 0;
  maxBackwardCrouchSpeed = 0;
  maxSideCrouchSpeed = 0;
  maxUnderwaterForwardSpeed = 0;
  maxUnderwaterBackwardSpeed = 0;
  maxUnderwaterSideSpeed = 0;
  jumpForce = 0;
  jumpEnergyDrain = 0;
  minJumpEnergy = 0;
  jumpDelay = 0;
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
  minImpactSpeed = 250;
  speedDamageScale = 3.8;
  boundingBox = vectorScale("4.2 4.2 1.2",4);
  crouchBoundingBox = vectorScale("4.2 4.2 1.2",4);
  pickupRadius = 0.75;
  jetEmitter = "";
  jetGroundEmitter = "";
  jetGroundDistance = 4;
  splash = PlayerSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 0.1;
  splashEmitter[0] = PlayerFoamDropletsEmitter;
  splashEmitter[1] = PlayerFoamEmitter;
  splashEmitter[2] = PlayerBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  runSurfaceAngle = 85;
  jumpSurfaceAngle = 86;
  minJumpSpeed = 20;
  maxJumpSpeed = 30;
  horizMaxSpeed = 68;
  horizResistSpeed = 33;
  horizResistFactor = 0.35;
  upMaxSpeed = 80;
  upResistSpeed = 25;
  upResistFactor = 0.3;
  footstepSplashHeight = 0.35;
  JumpSound = "";
  groundImpactMinSpeed = 10;
  groundImpactShakeFreq = "4 4 4";
  groundImpactShakeAmp = "1 1 1";
  groundImpactShakeDuration = 0.8;
  groundImpactShakeFalloff = 10;
  maxItems = 10;
  maxWeapons = 5;
  maxTools = 5;
  uiName = "";
  rideable = true;
  lookUpLimit = 0.6;
  lookDownLimit = 0.4;
  canRide = false;
  showEnergyBar = false;
  paintable = true;
  brickImage = horseBrickImage;
  numMountPoints = 1;
  mountThread[0] = "sit";
  protectPassengersBurn = true;
  protectPassengersRadius = true;
  protectPassengersDirect = true;
  useCustomPainEffects = true;
  PainHighImage = "";
  PainMidImage = "";
  PainLowImage = "";
  painSound = "";
  deathSound = "";
  useEyePoint = 1;
};

datablock PlayerData(gc_t90MGPlayer : gc_t90TurretPlayer)
{
  shapeFile = "./t90mg.dts";
  cameraMaxDist = 6;
  cameraVerticalOffset = 1.5;
  boundingBox = "4 4 10";
  crouchBoundingBox = "4 4 10";
  uiName = "";
  numMountPoints = 1;
  mountThread[0] = "sit";
  protectPassengersBurn = true;
  protectPassengersRadius = true;
  protectPassengersDirect = true;
  useEyePoint = 1;
};

//### Vehicle

datablock WheeledVehicleTire(gc_t90Tire)
{
  shapeFile = "./emptyWheel.dts";
  mass = 10;
  radius = 0.8;
  staticFriction = 5;
  kineticFriction = 5;
  restitution = 0.5;
  lateralForce = 18000;
  lateralDamping = 4000;
  lateralRelaxation = 0.01;
  longitudinalForce = 14000;
  longitudinalDamping = 2000;
  longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleSpring(gc_t90Spring)
{
  length = 0.6;
  force = 4000;
  damping = 1000;
  antiSwayForce = 6;
};

datablock WheeledVehicleData(gc_t90Vehicle)
{
  uiName = "T-90";
  category = "Vehicles";
  displayName = "";
  shapeFile = "./t90.dts";
  emap = true;
  minMountDist = 3;
  numMountPoints = 3;
  mountThread[0] = "crouch";
  mountThread[1] = "sit";
  mountThread[2] = "sit";
  maxDamage = 400;
  destroyedLevel = 400;
  speedDamageScale = 1.04;
  collDamageThresholdVel = 20;
  collDamageMultiplier = 0.02;
  massCenter = "0 0 -0.5";
  maxSteeringAngle = 0.9;
  integration = 4;
  tireEmitter = gc_tireEmitter;
  cameraRoll = false;
  cameraMaxDist = 13;
  cameraOffset = 7.5;
  cameraLag = 0.0;
  cameraDecay = 0.75;
  cameraTilt = 0.4;
  collisionTol = 0.1;
  contactTol = 0.1;
  useEyePoint = false;
  defaultTire = gc_t90Tire;
  defaultSpring = gc_t90Spring;
  numWheels = 6;
  mass = 400;
  density = 5;
  drag = 1.6;
  bodyFriction = 0.6;
  bodyRestitution = 0.6;
  minImpactSpeed = 10;
  softImpactSpeed = 10;
  hardImpactSpeed = 15;
  groundImpactMinSpeed = 10;
  engineTorque = 5000;
  engineBrake = 500;
  brakeTorque = 5000;
  maxWheelSpeed = 25;
  rollForce = 900;
  yawForce = 600;
  pitchForce = 1000;
  rotationalDrag = 0.2;
  maxEnergy = 100;
  jetForce = 3000;
  minJetEnergy = 30;
  jetEnergyDrain = 2;
  splash = vehicleSplash;
  splashVelocity = 4;
  splashAngle = 67;
  splashFreqMod = 300;
  splashVelEpsilon = 0.6;
  bubbleEmitTime = 1.4;
  splashEmitter[0] = vehicleFoamDropletsEmitter;
  splashEmitter[1] = vehicleFoamEmitter;
  splashEmitter[2] = vehicleBubbleEmitter;
  mediumSplashSoundVelocity = 10;
  hardSplashSoundVelocity = 20;
  exitSplashSoundVelocity = 5;
  softImpactSound = slowImpactSound;
  hardImpactSound = fastImpactSound;
  justcollided = 0;
  rideable = true;
  lookUpLimit = 1;
  lookDownLimit = 0;
  paintable = true;
  damageEmitter[0] = gc_vehicleDamageEmitter;
  damageEmitterOffset[0] = "0 -4 1";
  damageLevelTolerance[0] = 0.5;
  damageEmitter[1] = VehicleBurnEmitter;
  damageEmitterOffset[1] = "0 -4 1";
  damageLevelTolerance[1] = 0.9;
  numDmgEmitterAreas = 1;
  initialExplosionProjectile = vehicleExplosionProjectile;
  initialExplosionOffset = 1;
  burnTime = 4000;
  finalExplosionProjectile = vehicleFinalExplosionProjectile;
  finalExplosionOffset = 0.5;
  minRunOverSpeed = 4;
  runOverDamageScale = 25;
  runOverPushScale = 1.2;
  protectPassengersBurn = true;
  protectPassengersRadius = true;
  protectPassengersDirect = true;
  useEyePoint = 1;
};

//### Functions

function gc_T90Vehicle::onAdd(%this,%obj)
{
  for(%i=0;%i<%this.numWheels;%i++)
  {
    %obj.setWheelTire(%i,%this.defaultTire);
    %obj.setWheelSpring(%i,%this.defaultSpring);
  }
  %obj.setWheelSteering(0,1);
  %obj.setWheelSteering(1,1);
  %obj.setWheelSteering(4,-1);
  %obj.setWheelSteering(5,-1);
  %obj.setWheelPowered(0,true);
  %obj.setWheelPowered(1,true);
  %obj.setWheelPowered(2,true);
  %obj.setWheelPowered(3,true);
  %obj.setWheelPowered(4,true);
  %obj.setWheelPowered(5,true);
  %t = new AIPlayer() { dataBlock = gc_T90TurretPlayer; };
  MissionCleanup.add(%t);
  %obj.mountObject(%t,1);
  %obj.turret = %t;
  %mg = new AIPlayer() { dataBlock = gc_T90MGPlayer; };
  MissionCleanup.add(%mg);
  %obj.mountObject(%mg,2);
  %obj.mg = %mg;
  schedule(500,0,gc_Overheating,%mg);
}

function gc_Overheating(%obj)
{
  if(!isObject(%obj)) return;
  schedule(500,0,gc_Overheating,%obj);
  if(%obj.temp > 0) %obj.temp -= 6;
  if(%obj.temp < 0) %obj.temp = 0;
  if(isObject(%obj.getMountNodeObject(0))) {
  %col = "<color:00ff00>";
  if(%obj.temp > 40) %col = "<color:ffff00>";
  if(%obj.temp > 60) %col = "<color:ff0000>";
  for(%i=0;%i<=(%obj.temp/5);%i++) { %a = %a @ "|"; }
  bottomPrint(%obj.getMountNodeObject(0).client,%col @ "Barrel Temp: " @ %a,2); }
}

function gc_T90Vehicle::onRemove(%this,%obj) { if(isObject(%obj.mg)) { %obj.mg.delete(); } if(isObject(%obj.turret)) { %obj.turret.delete(); } }

package gc_T90Package
{
  function Player::Burn(%obj,%time)
  {
    if(%obj.dataBlock $= gc_T90TurretPlayer) return;
    if(%obj.dataBlock $= gc_T90MGPlayer) return;
    parent::Burn(%obj,%time);
  }
  function ShapeBase::setNodeColor(%obj,%node,%color)
  {
    parent::setnodecolor(%obj,%node,%color);
    if(isObject(%obj.turret)) %obj.turret.setNodeColor("ALL",%color);
    if(isObject(%obj.mg)) %obj.mg.setNodeColor("ALL",%color);
  }
  function gc_T90Vehicle::Damage(%this,%obj,%source,%pos,%amount,%type)
  {
    if(%amount < 50) %amount = 0;
    if((%obj.getDamageLevel()+%amount) >= %this.maxDamage)
    {
      if(%obj.destroyed) return;
      %obj.setNodeColor("ALL","0 0 0 1");
      if(isObject(%obj.mg)) %obj.mg.delete();
      if(isObject(%obj.turret))  %obj.turret.delete();
      %p = new Projectile()
      {
        dataBlock = vehicleExplosionProjectile;
        initialPosition = vectorAdd(%obj.getPosition(),"0 0" SPC %this.initialExplosionOffset);
        initialVelocity = "0 0 1";
        client = %obj.lastDamageClient;
        sourceClient = %obj.lastDamageClient;
      };
      MissionCleanup.add(%p);
      if(%obj.destroyed) return;
      %obj.setDamageLevel(%this.maxDamage);
      %obj.destroyed = 1;
      %obj.schedule(%this.burnTime,"finalExplosion");
      if(isObject(%obj.spawnBrick.client.minigame)) %respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
      %obj.spawnBrick.schedule(%respawn,"spawnVehicle");
    }
    else
      parent::Damage(%this,%obj,%source,%pos,%amount,%type);
  }
  function Player::emote(%obj,%emote)
  {
    if(%obj.dataBlock $= gc_T90TurretPlayer) return;
    if(%obj.dataBlock $= gc_T90MGPlayer) return;
    parent::emote(%obj,%emote);
  }
  function gc_T90TurretPlayer::Damage(%this,%obj,%source,%pos,%amount,%type) { parent::Damage(%this,%obj,%source,%pos,0,%type); }
  function gc_T90MGPlayer::Damage(%this,%obj,%source,%pos,%amount,%type) { parent::Damage(%this,%obj,%source,%pos,0,%type); }
  function gc_T90TurretPlayer::onDisabled(%this,%obj,%state)
  {
    %pos = %obj.getHackPosition();
    %p = new Projectile()
    {
      dataBlock = vehicleFinalExplosionProjectile;
      initialPosition = %pos;
      initialVelocity = "0 0 1";
      client = %obj.lastDamageClient;
      sourceClient = %obj.lastDamageClient;
    };
    MissionCleanup.add(%p);
    %obj.schedule(10,"delete");
    if(isObject(%obj.spawnBrick))
    {
      %mg = getMiniGameFromObject(%obj);
      if(isObject(%mg)) %obj.spawnBrick.spawnVehicle(%mg.vehicleReSpawnTime);
      else
        %obj.spawnBrick.spawnVehicle(0);
    }
    parent::onDisabled(%this,%obj,%state);
  }
  function armor::onMount(%this,%obj,%col,%slot)
  {
    parent::onMount(%this,%obj,%col,%slot);
    if(isObject(%obj.client))
    {
      if(%col.getDataBlock() == gc_T90TurretPlayer.getId()) ServerCmdUnUseTool(%obj.client);
      if(%col.getDataBlock() == gc_T90MGPlayer.getId()) ServerCmdUnUseTool(%obj.client);
    }
  }
  function armor::onTrigger(%this,%obj,%triggerNum,%val)
  {
    %mount = %obj.getObjectMount();
    if(isObject(%mount))
    {
      if(!%val) cancel(%obj.gc_T90MGLoop);
      if(%mount.getDataBlock() == gc_T90MGPlayer.getId() && %triggerNum == 0 && %val)
      %obj.gc_t90MGFire(%val);
    }
    if(%obj.getDataBlock().getID() == gc_T90TurretPlayer.getID()) %mount = %obj;
    if(isObject(%mount))
    {
      if(%mount.getDataBlock() == gc_T90TurretPlayer.getId() && %triggerNum == 0 && %val)
      {
        %client = %obj.client;
        if(isObject(%client)) ServerCmdUnUseTool(%client);
        if(getSimTime() - %obj.lastShotTime < 4000) return;
        %scaleFactor = getWord(%mount.getScale(),2);
        %p = new Projectile()
        {
          dataBlock = gc_T90ShellProjectile;
          initialPosition = %mount.getSlotTransform(1);
          initialVelocity = vectorScale(%mount.getMuzzleVector(1),200);
          sourceObject = %obj;
          client = %obj.client;
          sourceSlot = 0;
          originPoint = %mount.getSlotTransform(1);
        };
        MissionCleanup.add(%p);
        %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
        %mount.mountImage(gc_t90FireImage,1);
        serverPlay3D(gc_t90FireSound,%obj.getPosition());
        %tank = %mount.getObjectMount();
        if(isObject(%tank))
        {
          %theVector = vectorAdd(%mount.getEyeVector(),"0 0 1");
          %theVector = vectorScale(%theVector,800);
          %theVector = vectorSub(%theVector,vectorScale(%thevector,2));
          %tank.applyImpulse(getWords(%mount.getEyeTransform(),0,2),%theVector);
        }
        %obj.lastShotTime = getSimTime();
        return;
      }
    }
    parent::onTrigger(%this,%obj,%triggerNum,%val);
  }
  function Player::gc_T90MGFire(%obj,%val)
  {
    if(!%val) { cancel(%obj.gc_T90MGLoop); return; }
    if(!isObject(%obj.getObjectMount())) { cancel(%obj.gc_T90MGLoop); return; }
    if(%obj.getObjectMount().getDataBlock() != gc_T90MGPlayer.getId()) { cancel(%obj.gc_T90MGLoop); return; }
    if(%obj.getObjectMount().temp >= 80 & %obj.getObjectMount().overheat == 0) { serverPlay3D(gc_OverheatSound,%obj.getPosition()); %obj.getObjectMount().overheat = 1; %obj.getObjectMount().mountImage(gc_OverheatMount1Image,1); cancel(%obj.gc_T90MGLoop); return; }
    if(%obj.getObjectMount().overheat == 1) {
      if(%obj.getObjectMount().temp >= 60) { cancel(%obj.gc_T90MGLoop); return; }
      else
        { %obj.getObjectMount().overheat = 0; } }
    %client = %obj.client;
    if(isObject(%client)) ServerCmdUnUseTool(%client);
    %mount = %obj.getObjectMount();
    %scaleFactor = getWord(%mount.getScale(),2);
    %p = new Projectile()
    {
      dataBlock = gc_T90MGProjectile;
      initialPosition = %mount.getSlotTransform(1);
      initialVelocity = MatrixMulVector(MatrixCreateFromEuler(((getRandom()-0.5)*0.01) SPC ((getRandom()-0.5)*0.01) SPC ((getRandom()-0.5)*0.01)),VectorScale(%mount.getMuzzleVector(1),150));
      sourceObject = %obj;
      client = %client;
      sourceSlot = 0;
      originPoint = %mount.getSlotTransform(1);
    };
    MissionCleanup.add(%p);
    %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
    %mount.mountImage(gc_MGFireImage,1);
    %mount.playThread(0,fire);
    serverPlay3D(gc_T90MGFireSound,%obj.getPosition());
    %mount.temp += 4;
    %col = "<color:00ff00>";
    if(%mount.temp > 40) %col = "<color:ffff00>";
    if(%mount.temp > 60) %col = "<color:ff0000>";
    for(%i=0;%i<=(%mount.temp/5);%i++) { %a = %a @ "|"; }
    bottomPrint(%obj.client,%col @ "Barrel Temp: " @ %a,2);
    %obj.gc_T90MGLoop = %obj.schedule(150,gc_T90MGFire,%val);
    return;
  }
};
activatepackage(gc_T90Package);
