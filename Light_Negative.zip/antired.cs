datablock fxLightData(DDNegativeLightRedVerySmall)
{
	uiName = "Anti Red Very Small";
	LightOn = true;
	radius = 0;
	brightness = -10;
	color = "1 0 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightRedSmall)
{
	uiName = "Anti Red Small";
	LightOn = true;
	radius = 0;
	brightness = -25;
	color = "1 0 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightRedMedium)
{
	uiName = "Anti Red Medium";
	LightOn = true;
	radius = 0;
	brightness = -50;
	color = "1 0 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightRedLarge)
{
	uiName = "Anti Red Large";
	LightOn = true;
	radius = 0;
	brightness = -100;
	color = "1 0 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightRedVeryLarge)
{
	uiName = "Anti Red Very Large";
	LightOn = true;
	radius = 0;
	brightness = -200;
	color = "1 0 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};