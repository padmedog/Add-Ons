//hevyboter
datablock AudioProfile(HeavyBolterFireSound)
{
   filename    = "./Heavybolter_Fire.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("Heavybolter",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Heavybolter> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Heavybolter> %1',0.75,1);
datablock ProjectileData(HeavybolterProjectile)
{
 projectileShapeName = "add-ons/Vehicle_Tank/tankbullet.dts";
   directDamage        = 50;
   directDamageType    = $DamageType::Heavybolter;
   radiusDamageType    = $DamageType::Heavybolter;

   brickExplosionRadius = 1;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 20;
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 44;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 120;
   verticalImpulse	  = 40;
   explosion           = BoltpistolExplosion;
   particleEmitter     = "BoltpistolTrailEmitter";

   muzzleVelocity      = 180;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 3.0;
   lightColor  = "1 0.5 0";
   
   sound = rocketLoopSound;
   
   uiName = "Heavy Bolter Round";
};


//////////
// item //
//////////
datablock ItemData(HeavybolterItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./heavyboltermounted.dts";
	rotate = false;
	mass = 10;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Heavy Bolter";
	iconName = "./Heavybolter";
	doColorShift = false;
	colorShiftColor = "0.2 0.2 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = HeavybolterImage;
	canDrop = true;
	
	maxAmmo = 100;
	canReload = 1;
	
};




datablock ShapeBaseImageData(HeavybolterproneImage)
{

   // Basic Item properties
   shapeFile = "./heavyboltermounted.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0.7 0.5 -0.5"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = HeavyBolterItem;
   ammo = " ";
   projectile = HeavybolterProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "10 -1.3 0.3";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 10.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = False;
   colorShiftColor = HeavybolterItem.colorShiftColor;//"0.400 0.196 0 1.000";
   
	maxAmmo = 100;
	canReload = 1;

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
// Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 1.35;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= BoltgunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= HeavybolterFireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateTimeoutValue[4]		= 0.15;
	stateTransitionOnTimeout[4]	= "Ready";
	
};
datablock ShapeBaseImageData(HeavybolterImage)
{


   shapeFile = "./heavyboltercarry.dts";
   emap = false;
mountPoint = 0;
offset = "0 0 0";
   eyeOffset = "0 0 0"; //"0.7 1.2 -0.5";
    // eyeOffset = "-0.0 1.3 -0.27"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   correctMuzzleVector = true;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";



melee = false;
armReady = false;
 doColorShift = False;
   colorShiftColor = HeavybolterItem.colorShiftColor;//"0.400 0.196 0 1.000";



	stateName[0]                     = "Activate";
		statesequence[0]                     = "ready";
};


function HeavybolterproneImage::onfire(%this,%obj,%slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(3, plant);

	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) < 0.1 && (getSimTime() - %obj.lastShotTime) > 500)
	{
		%spread = 0.0004;
	}
	else
	{
		%spread = 0.0004;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}

package Heavybolter
{
function Armor::onTrigger(%this, %player, %slot, %val)

	{
	if(isObject(%player.getMountedImage(0)))

		{

			if((%player.getMountedImage(0).getName() $= "HeavybolterImage" || %player.getMountedImage(0).getName() $= "HeavybolterproneImage") && %slot $= 4 && %val)
			{
			switch$(%player.getMountedImage(0).getName())
				{
				case "Heavybolterimage":
				%player.mountImage(Heavybolterproneimage,0);
					%player.playthread(1, armready);
					%player.playthread(0, sit);
				
				case "Heavybolterproneimage":
				%player.mountImage(Heavybolterimage,0);
					%player.playthread(0, root);
					%player.playthread(1, armready);
				//%player.playthread(2, armready);
				}
			}
		else
			{
			Parent::onTrigger(%this, %player, %slot, %val);
			}
		}
		else
		{
		Parent::onTrigger(%this, %player, %slot, %val);
	}
}
};	
ActivatePackage(Heavybolter);	



function HeavybolterproneImage::onMount(%this,%obj,%slot)
{
   
	%obj.playthread(1, armready);
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;
	%client.player.setDataBlock("WHproneArmor"); 
	
	   Parent::onMount(%this,%obj,%slot);
	
}

function HeavybolterproneImage::onUnMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
	%client = %obj.client;

		%obj.playthread(0, root);
		%obj.playthread(3, root);
		if(!isObject(%client.minigame))
		{
			%client.player.setDataBlock("PlayerStandardArmor");

		}
		else
		{
			%client.player.setdatablock(%client.minigame.playerDatablock);

		}
}
function HeavybolterImage::onMount(%this,%obj,%slot)
{
%obj.playthread(1, armreadyboth);
	Parent::onMount(%this,%obj,%slot);	




}

function HeavybolterImage::onUnMount(%this,%obj,%slot)
{
//%obj.playthread(1, armready);
	Parent::onMount(%this,%obj,%slot);	
	
}
