datablock WheeledVehicleData(barrelOldBreakVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./barrelOld.dts"; 
	emap = true;
	minMountDist = 3;

	uiName = "Barrel Old, Breakable";
	rideable = true;
		lookUpLimit = 0.65;
		lookDownLimit = 0.45;

	paintable = true;	
 
	numMountPoints = 0;
	mountThread[0] = "sit";
	mountThread[1] = "sit";
	mountThread[2] = "sit";
	mountThread[3] = "sit";
	mountThread[4] = "sit";
	mountThread[5] = "sit";
	mountThread[6] = "sit";
	mountThread[7] = "sit";

	maxDamage = 100;
	destroyedLevel = 1.00;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier	= 0.02;

	massCenter = "0 0 0";
	massBox = "3 3 3";

	maxSteeringAngle = 0.9785;  // Maximum steering angle, should match animation
	integration = 4;			  // Force integration time: TickSec/Rate
	//tireEmitter = TireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;			// Roll the camera with the vehicle
	cameraMaxDist = 13;			// Far distance from vehicle
	cameraOffset = 7.5;		  // Vertical offset from camera mount point
	cameraLag = 0.0;			  // Velocity lag of camera
	cameraDecay = 0.75;		  // Decay per sec. rate of velocity lag
	cameraTilt = 0.4;
	collisionTol = 0.15;		  // Collision distance tolerance
	contactTol = 0.15;

	useEyePoint = false;	

	//defaultTire	 = jeepTire;
	//defaultSpring = jeepSpring;
	//flatTire		 = jeepFlatTire;
	//flatSpring	 = jeepFlatSpring;

	numWheels = 0;

	// Rigid Body
	mass = 300;
	density = 5.0;
	drag = 1.6;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;		  // Impacts over this invoke the script callback
	softImpactSpeed = 10;		 // Play SoftImpact Sound
	hardImpactSpeed = 15;		// Play HardImpact Sound
	groundImpactMinSpeed	 = 10.0;

	// Engine
	engineTorque = 12000; //4000;		 // Engine power
	engineBrake = 2000;			// Braking when throttle is 0
	brakeTorque = 4000;		  // When brakes are applied
	maxWheelSpeed = 20;		  // Engine scale by current speed / max speed

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	isSled = false;

	forwardThrust		= 3000;
	reverseThrust		= 2000;
	lift			= 100;
	maxForwardVel		= 40;
	maxReverseVel		= 40;
	horizontalSurfaceForce	= 0;	// Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 0; 
	rollForce		= 4000;
	yawForce		= 6000;
	pitchForce		= 6000;
	rotationalDrag		= 0.15;
	stallSpeed		= 10;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;	
	hardSplashSoundVelocity = 20.0;	
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//	jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	explosion = "";
	justcollided = 0;
	
	damageEmitter[0] = "";
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

	damageEmitter[1] = "";
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

	numDmgEmitterAreas = 1;

	initialExplosionProjectile = PR_barrelOldExplosion;
	initialExplosionOffset = 0;			//offset only uses a z value for now

	burnTime = 0;

	finalExplosionProjectile = PR_barrelOldExplosion;
	finalExplosionOffset = 0.5;			 //offset only uses a z value for now

	minRunOverSpeed	 = 2;	//how fast you need to be going to run someone over (do damage)
	runOverDamageScale = 5;	//when you run over someone, speed * runoverdamagescale = damage amt
	runOverPushScale	= 1.2; //how hard a person you're running over gets pushed
};