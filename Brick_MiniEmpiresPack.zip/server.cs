datablock fxDTSBrickData(brickminievergreenforestData)
{
	brickFile = "./evergreenforest.blb";
	category = "Mini-Empires";
	subCategory = "Vegetation";
	uiName = "Evergreen Forest";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/evergreenforest";
};
datablock fxDTSBrickData(brickminievergreentreeData)
{
	brickFile = "./evergreentree.blb";
	category = "Mini-Empires";
	subCategory = "Vegetation";
	uiName = "Evergreen Tree";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/evergreentree";
};
datablock fxDTSBrickData(brickministumpsData)
{
	brickFile = "./stumps.blb";
	category = "Mini-Empires";
	subCategory = "Vegetation";
	uiName = "Stumps";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/stumps";
};
datablock fxDTSBrickData(brickministumpData)
{
	brickFile = "./stump.blb";
	category = "Mini-Empires";
	subCategory = "Vegetation";
	uiName = "Single Stump";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/stump";
};
datablock fxDTSBrickData(brickminiflagData)
{
	brickFile = "./flagpole.blb";
	category = "Mini-Empires";
	subCategory = "Misc";
	uiName = "Flag";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/flagpole";
};
datablock fxDTSBrickData(brickminibigflagData)
{
	brickFile = "./bigflagpole.blb";
	category = "Mini-Empires";
	subCategory = "Misc";
	uiName = "Big Flag";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/bigflagpole";
};
datablock fxDTSBrickData(brickminidockData)
{
	brickFile = "./dock.blb";
	category = "Mini-Empires";
	subCategory = "Misc";
	uiName = "Dock";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/dock";
};
datablock fxDTSBrickData(brickminicactusesData)
{
	brickFile = "./cactuses.blb";
	category = "Mini-Empires";
	subCategory = "Vegetation";
	uiName = "Cacti";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/cactuses";
};
datablock fxDTSBrickData(brickminicactusData)
{
	brickFile = "./cactus.blb";
	category = "Mini-Empires";
	subCategory = "Vegetation";
	uiName = "Cactus";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/cactus";
};
datablock fxDTSBrickData(brickminisuppliesData)
{
	brickFile = "./supplies.blb";
	category = "Mini-Empires";
	subCategory = "Misc";
	uiName = "Supplies";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/supplies";
};
datablock fxDTSBrickData(brickminihorseData)
{
	brickFile = "./horse.blb";
	category = "Mini-Empires";
	subCategory = "Animals";
	uiName = "Horse";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/horse";
};
datablock fxDTSBrickData(brickminiblockheadData)
{
	brickFile = "./blockhead.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Plain 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockhead";
};
datablock fxDTSBrickData(brickminiblockhead2Data)
{
	brickFile = "./blockhead2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Plain 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockhead2";
};
datablock fxDTSBrickData(brickminiblockheadaxeData)
{
	brickFile = "./blockheadaxe.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Axe 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadaxe";
};
datablock fxDTSBrickData(brickminiblockheadaxe2Data)
{
	brickFile = "./blockheadaxe2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Axe 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadaxe2";
};
datablock fxDTSBrickData(brickminiblockheadbowData)
{
	brickFile = "./blockheadbow.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Bow 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadbow";
};
datablock fxDTSBrickData(brickminiblockheadbow2Data)
{
	brickFile = "./blockheadbow2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Bow 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadbow2";
};
datablock fxDTSBrickData(brickminiblockheadclubData)
{
	brickFile = "./blockheadclub.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Club 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadclub";
};
datablock fxDTSBrickData(brickminiblockheadclub2Data)
{
	brickFile = "./blockheadclub2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Club 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadclub2";
};
datablock fxDTSBrickData(brickminiblockheadcrossbowData)
{
	brickFile = "./blockheadcrossbow.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Crossbow 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadcrossbow";
};
datablock fxDTSBrickData(brickminiblockheadcrossbow2Data)
{
	brickFile = "./blockheadcrossbow2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Crossbow 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadcrossbow2";
};
datablock fxDTSBrickData(brickminiblockheaddeadData)
{
	brickFile = "./blockheaddead.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Dead)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheaddead";
};
datablock fxDTSBrickData(brickminiblockheadfishData)
{
	brickFile = "./blockheadfish.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Fishing 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadfish";
};
datablock fxDTSBrickData(brickminiblockheadfish2Data)
{
	brickFile = "./blockheadfish2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Fishing 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadfish2";
};
datablock fxDTSBrickData(brickminiblockheadflagData)
{
	brickFile = "./blockheadflag.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Flag)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadflag";
};
datablock fxDTSBrickData(brickminiblockheadflintData)
{
	brickFile = "./blockheadflint.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Flintlock 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadflint";
};
datablock fxDTSBrickData(brickminiblockheadflint2Data)
{
	brickFile = "./blockheadflint2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Flintlock 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadflint2";
};
datablock fxDTSBrickData(brickminiblockheadhmgData)
{
	brickFile = "./blockheadhmg.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (HMG)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadhmg";
};

datablock fxDTSBrickData(brickminiblockheadknightData)
{
	brickFile = "./blockheadknight.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Knight 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadknight";
};
datablock fxDTSBrickData(brickminiblockheadknight2Data)
{
	brickFile = "./blockheadknight2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Knight 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadknight2";
};
datablock fxDTSBrickData(brickminiblockheadlaserrifleData)
{
	brickFile = "./blockheadlaserrifle.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Laser Rifle 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadlaserrifle";
};
datablock fxDTSBrickData(brickminiblockheadlaserrifle2Data)
{
	brickFile = "./blockheadlaserrifle2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Laser Rifle 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadlaserrifle2";
};
datablock fxDTSBrickData(brickminiblockheadmgData)
{
	brickFile = "./blockheadmg.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (MG 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadmg";
};
datablock fxDTSBrickData(brickminiblockheadmg2Data)
{
	brickFile = "./blockheadmg2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (MG 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadmg2";
};
datablock fxDTSBrickData(brickminiblockheadmusketData)
{
	brickFile = "./blockheadmusket.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Musket 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadmusket";
};
datablock fxDTSBrickData(brickminiblockheadmusket2Data)
{
	brickFile = "./blockheadmusket2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Musket 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadmusket2";
};
datablock fxDTSBrickData(brickminiblockheadpickData)
{
	brickFile = "./blockheadpick.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Pickaxe 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadpick";
};
datablock fxDTSBrickData(brickminiblockheadpick2Data)
{
	brickFile = "./blockheadpick2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Pickaxe 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadpick2";
};
datablock fxDTSBrickData(brickminiblockheadpistolData)
{
	brickFile = "./blockheadpistol.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Pistol 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadpistol";
};
datablock fxDTSBrickData(brickminiblockheadpistol2Data)
{
	brickFile = "./blockheadpistol2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Pistol 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadpistol2";
};
datablock fxDTSBrickData(brickminiblockheadradioData)
{
	brickFile = "./blockheadradio.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Radio)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadradio";
};
datablock fxDTSBrickData(brickminiblockheadrifleData)
{
	brickFile = "./blockheadrifle.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Rifle 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadrifle";
};
datablock fxDTSBrickData(brickminiblockheadrifle2Data)
{
	brickFile = "./blockheadrifle2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Rifle 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadrifle2";
};
datablock fxDTSBrickData(brickminiblockheadshotgunData)
{
	brickFile = "./blockheadshotgun.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Shotgun 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadshotgun";
};
datablock fxDTSBrickData(brickminiblockheadshotgun2Data)
{
	brickFile = "./blockheadshotgun2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Shotgun 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadshotgun2";
};
datablock fxDTSBrickData(brickminiblockheadsitData)
{
	brickFile = "./blockheadsit.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Sitting)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadsit";
};
datablock fxDTSBrickData(brickminiblockheadsniperData)
{
	brickFile = "./blockheadsniper.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Sniper 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadsniper";
};
datablock fxDTSBrickData(brickminiblockheadsniper2Data)
{
	brickFile = "./blockheadsniper2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Sniper 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadsniper2";
};
datablock fxDTSBrickData(brickminiblockheadspearData)
{
	brickFile = "./blockheadspear.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Spear 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadspear";
};
datablock fxDTSBrickData(brickminiblockheadspear2Data)
{
	brickFile = "./blockheadspear2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Spear 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadspear2";
};
datablock fxDTSBrickData(brickminiblockheadswordData)
{
	brickFile = "./blockheadsword.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Sword 1)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadsword";
};
datablock fxDTSBrickData(brickminiblockheadsword2Data)
{
	brickFile = "./blockheadsword2.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Sword 2)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadsword2";
};
datablock fxDTSBrickData(brickminiblockheadzombieData)
{
	brickFile = "./blockheadzombie.blb";
	category = "Mini-Empires";
	subCategory = "Blockheads";
	uiName = "Blockhead (Zombie)";
	iconName = "Add-Ons/Brick_MiniEmpiresPack/blockheadzombie";
};










