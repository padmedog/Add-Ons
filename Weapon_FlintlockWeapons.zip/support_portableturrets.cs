	//########## Support for Portable Turrets

if($GCStuff::Server::PortableTurretsVersion > 1) return;
$GCStuff::Server::PortableTurretsVersion = 1;

//### Playerdata properties

// gc_turretItem = ItemData;
// The above line in PlayerData defines which item is spawned
// when a turret is picked up again with right click.

//### ItemData properties

// gc_placementTurret = PlayerData;
// The above line in ItemData defines which turret is placed by
// this item.

// gc_placementBoxSize = "1 1 1.2";
// The above line in ItemData defines the area it checks if
// there's enough space to place the turret.

// !!! IMPORTANT !!!

// ALWAYS CALL gc_PTclear(%obj) IN THE IMAGES
// onUnMount(%this,%obj,%slot) OR ELSE THE PLACEMENT BOX WILL STAY!

//### Effects

datablock StaticShapeData(gc_TurretPlacementBoxGreenStatic)
{
  shapeFile = "./placementboxgreen.dts";
  hasLight = true;
  lightType = "ConstantLight";
  lightColor = "0 1 0 1";
  lightTime = "1000";
  lightRadius = "5";
};

datablock StaticShapeData(gc_TurretPlacementBoxRedStatic)
{
  shapeFile = "./placementboxred.dts";
  hasLight = true;
  lightType = "ConstantLight";
  lightColor = "1 0 0 1";
  lightTime = "1000";
  lightRadius = "5";
};

//### Functions

function gc_PTcheckPlacement(%this,%obj,%slot)
{
  if(!isObject(%obj)) return;
  if(%obj.getDamagePercent() == 1) { gc_PTclear(%obj); return; }
  %muzzlepoint = %obj.getMuzzlePoint(0);
  %muzzlevec = %obj.getMuzzleVector(0);
  %raycast = containerRayCast(%muzzlepoint,VectorAdd(%muzzlepoint,VectorScale(%muzzlevec,3)),$TypeMasks::fxBrickObjectType | $TypeMasks::StaticObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType,%obj);
  %col = firstWord(%raycast);
  if(%col != 0)
  {
    %x = getWord(%this.item.gc_placementBoxSize,0);
    %y = getWord(%this.item.gc_placementBoxSize,1);
    %z = getWord(%this.item.gc_placementBoxSize,2);
    %raypos = VectorAdd(posFromRaycast(%raycast),"0 0 0.1");
    if(ContainerBoxEmpty($TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::fxBrickObjectType | $TypeMasks::StaticObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType,VectorAdd(%raypos,"0 0" SPC %z),%x,%y,%z))
    {
      if(%obj.client.placementBox.dataBlock $= "gc_TurretPlacementBoxRedStatic") %obj.client.placementBox.delete();
      if(!isObject(%obj.client.placementBox))
      {
        %p = new StaticShape() { dataBlock = gc_TurretPlacementBoxGreenStatic; };
        MissionCleanup.add(%p);
        %obj.client.placementBox = %p;
        %obj.client.placementBox.setScale(%this.item.gc_placementBoxSize);
      }
      %obj.client.placementBox.setTransform(VectorAdd(%raypos,"0 0" SPC %z) SPC getWords(%obj.getTransform(),3,6));
    }
    else
    {
      if(%obj.client.placementBox.dataBlock $= "gc_TurretPlacementBoxGreenStatic") %obj.client.placementBox.delete();
      if(!isObject(%obj.client.placementBox))
      {
        %p = new StaticShape() { dataBlock = gc_TurretPlacementBoxRedStatic; };
        MissionCleanup.add(%p);
        %obj.client.placementBox = %p;
        %obj.client.placementBox.setScale(%this.item.gc_placementBoxSize);
      }
      %obj.client.placementBox.setTransform(VectorAdd(%raypos,"0 0" SPC %z) SPC getWords(%obj.getTransform(),3,6));
    }
  }
  else if(isObject(%obj.client.placementBox)) %obj.client.placementBox.delete();
}

function gc_PTplaceDown(%this,%obj,%slot)
{
  if(!isObject(%obj)) return;
  if(%obj.getDamagePercent() == 1) { gc_PTclear(%obj); return; }
  if(isObject(%obj.client.gc_portableturret)) { centerPrint(%obj.client,"\c0I already have a turret!",2); return; }
  %muzzlepoint = %obj.getMuzzlePoint(0);
  %muzzlevec = %obj.getMuzzleVector(0);
  %raycast = containerRayCast(%muzzlepoint,VectorAdd(%muzzlepoint,VectorScale(%muzzlevec,3)),$TypeMasks::fxBrickObjectType | $TypeMasks::StaticObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType,%obj);
  %col = firstWord(%raycast);
  if(%col != 0)
  {
    %x = getWord(%this.item.gc_placementBoxSize,0);
    %y = getWord(%this.item.gc_placementBoxSize,1);
    %z = getWord(%this.item.gc_placementBoxSize,2);
    %raypos = VectorAdd(posFromRaycast(%raycast),"0 0 0.1");
    if(ContainerBoxEmpty($TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::fxBrickObjectType | $TypeMasks::StaticObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType,VectorAdd(%raypos,"0 0" SPC %z),%x,%y,%z))
    {
      %t = new AIPlayer() { dataBlock = %this.item.gc_placementTurret; };
      MissionCleanup.add(%t);
      %t.gc_portable = 1;
      %t.setTransform(%raypos SPC getWords(%obj.getTransform(),3,6));
      %t.spawnExplosion(spawnProjectile,%t.getScale());
      %t.client = %obj.client;
      %obj.client.gc_portableturret = %t;
      %obj.tool[%obj.currTool] = 0;
      %obj.weaponCount--;
      messageClient(%obj.client,'MsgItemPickup','',%obj.currTool,0);
      serverCmdUnUseTool(%obj.client);
    }
    else
      centerPrint(%obj.client,"\c0Can't place turret here!",1);
  }
  else
    centerPrint(%obj.client,"\c0Can't place turret here!",1);
}

function gc_PTclear(%obj) { if(isObject(%obj.client.placementBox)) %obj.client.placementBox.delete(); }

package gc_PortableTurretsPackage
{
  function Armor::onTrigger(%this,%player,%slot,%val)
  {
    if(!isObject(%player.getObjectMount()) && !isObject(%player.getMountedImage(0)) && %slot $= 4 && %val)
    {
      %muzzlepoint = %player.getEyePoint();
      %muzzlevec = %player.getEyeVector();
      %raycast = containerRayCast(%muzzlepoint,VectorAdd(%muzzlepoint,VectorScale(%muzzlevec,3)),$TypeMasks::PlayerObjectType,%player);
      %col = firstWord(%raycast);
      if(isObject(%col) && %col.dataBlock.gc_portableTurret && %col.gc_portable)
      {
        %col.spawnExplosion(spawnProjectile,%col.getScale());
        %item = new Item()
        {
          dataBlock = %col.dataBlock.gc_turretItem;
          position = %col.getPosition();
        };
        MissionCleanup.add(%item);
        %item.setVelocity("0 0 5");
        %col.client.gc_portableturret = "";
        %col.delete();
      }
    }
    parent::onTrigger(%this,%player,%slot,%val);
  }
  function GameConnection::onClientLeaveGame(%client)
  {
    if(isObject(%client.gc_portableturret))
    {
      %client.gc_portableturret.spawnExplosion(spawnProjectile,%client.gc_portableturret.getScale());
      %client.gc_portableturret.delete();
    }
    if(isObject(%client.placementBox)) %client.placementBox.delete();
    parent::onClientLeaveGame(%client);
  }
  function GameConnection::spawnPlayer(%this)
  {
    if(isObject(%client.placementBox)) %client.placementBox.delete();
    parent::SpawnPlayer(%this);
  }
  function GameConnection::onDeath(%client,%a,%b,%c,%d)
  {
    if(isObject(%client.placementBox)) %client.placementBox.delete();
    parent::onDeath(%client,%a,%b,%c,%d);
  }
};
activatePackage(gc_PortableTurretsPackage);

function serverCmdclearturret(%client)
{
  if(isObject(%client.gc_portableturret))
  {
    %client.gc_portableturret.spawnExplosion(spawnProjectile,%client.gc_portableturret.getScale());
    %client.gc_portableturret.delete();
    messageClient(%client,'',"\c0You cleared your placeable turret!");
  }
}
