AddDamageType("Mace",   '<bitmap:add-ons/Weapon_RPGMaces/CI_rpgMace> %1',    '%2 <bitmap:add-ons/Weapon_RPGMaces/CI_rpgMace> %1',0.75,1);

%errorA = ForceRequiredAddOn("Weapon_sword");

if(%error == $Error::AddOn_Disabled)
{
   swordItem.uiName = "";
}

if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Weapons_RPGMaces - required add-ons not found");
else
{
    exec("./Weapon_BronzeMace.cs");
    exec("./Weapon_CopperMace.cs");
    exec("./Weapon_IronMace.cs");
    exec("./Weapon_SteelMace.cs");
    exec("./Weapon_HalaciteMace.cs");
}