	//fpBluesodabottle.cs

	//audio
	datablock AudioProfile(drinkSound)
	{
	   filename    = "./drink.wav";
	   description = AudioClose3d;
	   preload = true;
	};

	datablock ParticleData(fpBluesodabottledrinkParticle)
	{
	   dragCoefficient      = 5.0;
	   gravityCoefficient   = -0.2;
	   inheritedVelFactor   = 0.0;
	   constantAcceleration = 0.0;
	   lifetimeMS           = 1000;
	   lifetimeVarianceMS   = 500;
	   useInvAlpha          = false;
	   textureName          = "./drink";
	   colors[0]     = "1.0 1.0 1.0 1";
	   colors[1]     = "1.0 1.0 1.0 1";
	   colors[2]     = "0.0 0.0 0.0 0";
	   sizes[0]      = 0.4;
	   sizes[1]      = 0.6;
	   sizes[2]      = 0.4;
	   times[0]      = 0.0;
	   times[1]      = 0.2;
	   times[2]      = 1.0;
	};

	datablock ParticleEmitterData(fpBluesodabottledrinkEmitter)
	{
	   ejectionPeriodMS = 35;
	   periodVarianceMS = 0;
	   ejectionVelocity = 0.5;
	   ejectionOffset   = 1.0;
	   velocityVariance = 0.49;
	   thetaMin         = 0;
	   thetaMax         = 120;
	   phiReferenceVel  = 0;
	   phiVariance      = 360;
	   overrideAdvance = false;
	   particles = "fpBluesodabottledrinkParticle";

	};

	datablock ShapeBaseImageData(fpBluesodabottledrinkImage)
	{
		shapeFile = "base/data/shapes/empty.dts";
		emap = false;

		mountPoint = $HeadSlot;

		stateName[0]					= "Ready";
		stateTransitionOnTimeout[0]		= "FireA";
		stateTimeoutValue[0]			= 0.01;

		stateName[1]					= "FireA";
		stateTransitionOnTimeout[1]		= "Done";
		stateWaitForTimeout[1]			= True;
		stateTimeoutValue[1]			= 0.350;
		stateEmitter[1]					= fpBluesodabottledrinkEmitter;
		stateEmitterTime[1]				= 0.350;
		stateSound[1]					= drinkSound;

		stateName[2]					= "Done";
		stateScript[2]					= "onDone";
	};
	function fpBluesodabottledrinkImage::onDone(%this,%obj,%slot)
	{
		%obj.unMountImage(%slot);
	}

	datablock ItemData(fpBluesodabottleItem)
	{
		category = "Weapon";  // Mission editor category
		className = "Weapon"; // For inventory system

		 // Basic Item Properties
		shapeFile = "./fpBluesodabottle.dts";
		rotate = false;
		mass = 1;
		density = 0.2;
		elasticity = 0.2;
		friction = 0.6;
		emap = true;

		//gui stuff
		uiName = "Blue Soda Bottle";
		iconName = "./Icon_fpBluesodabottle";
		doColorShift = false;

		 // Dynamic properties defined by the scripts
		image = fpBluesodabottleImage;
		canDrop = true;
	};

	datablock ShapeBaseImageData(fpBluesodabottleImage)
	{
	   // Basic Item properties
	   shapeFile = "./fpBluesodabottle.dts";
	   emap = true;

	   // Specify mount point & offset for 3rd person, and eye offset
	   // for first person rendering.
	   mountPoint = 0;
	   offset = "-.05 0 0";
	   eyeOffset = 0; //"0.7 1.2 -0.5";
	   rotation = eulerToMatrix( "-90 90 0" );

	   className = "WeaponImage";
	   item = fpBluesodabottleItem;

	   //raise your arm up or not
	   armReady = true;

	   doColorShift = false;

	   // Initial start up state
		stateName[0]                     = "Ready";
		stateTransitionOnTriggerDown[0]  = "Fire";
		stateAllowImageChange[0]         = true;

		stateName[1]                     = "Fire";
		stateTransitionOnTimeout[1]      = "Ready";
		stateAllowImageChange[1]         = true;
		  stateScript[1]                   = "onFire";
		stateTimeoutValue[1]		   = 1;
		stateSound[1]					= drinkSound;
	};

	function fpBluesodabottleImage::onFire(%this,%obj,%slot)
	{
		

		for(%i=0;%i<5;%i++)
		{
			%toolDB = %obj.tool[%i];
			if(%toolDB $= %this.item.getID())
			{
				%obj.addhealth(30);
				%obj.emote(fpBluesodabottledrinkImage);
				%obj.tool[%i] = 0;
				%obj.weaponCount--;
				messageClient(%obj.client,'MsgItemPickup','',%i,0);
				serverCmdUnUseTool(%obj.client);
				break;
			}
		}
	}

	package fpBluesodabottlePackage
	{
	   function Armor::onCollision(%this, %obj, %col, %thing, %other)
	   {
		  if(%col.dataBlock $= "fpBluesodabottleItem" && %col.pickupNow !$= 1)
		  {
			 if(!isObject(%col.spawnbrick))   
			 {
				if((%obj.getDamageLevel() >= 1))
				{
				   %obj.setDamageLevel(0);
				   %obj.emote(fpBluesodabottledrinkImage);
				   %col.delete();
				}
				else
				   %col.pickupNow = 1;
				return;
			 }
		  }
		  Parent::onCollision(%this, %obj, %col, %thing, %others);
	   }
	};
	activatePackage(fpBluesodabottlePackage);