//Slay - Made by Clay Hanson BLID 15144
//Scripts
function TLSlay() {
	if(!isObject(TLSL_CurrentClient())) {
			TL_Error("TLSlay :: Select a client first.");
			return 0;
	}
	%cl = TLSL_CurrentClient();
	%cl.player.kill();
	messageclient(%cl,'',"\c6You were slain.");
}
//END SCRIPT