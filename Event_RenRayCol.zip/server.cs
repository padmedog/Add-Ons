registerSpecialVar(fxDTSbrick,"rendering","%this.isRendering()");

registerSpecialVar(fxDTSbrick,"raycasting","%this.isRayCasting()");

registerSpecialVar(fxDTSbrick,"colliding","%this.isColliding()");
