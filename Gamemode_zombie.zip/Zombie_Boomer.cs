 datablock PlayerData(RotBoomerZombie : PlayerStandardArmor)
{
	//category = "Vehicles";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 0;	//total number of bricks you can carry
	maxWeapons = 0;		//this will be controlled by mini-game code
	maxTools = 0;

	maxDamage = 10;
	runforce = 100 * 90;
	maxForwardSpeed = 9;
	maxBackwardSpeed = 9;
	maxSideSpeed = 9;
	attackpower = 12;
	jumpsound = "ZombieJumpSound";

	BrickDestroyMaxVolume = 200;
	BrickKillRadius = 2;
	BrickMaxJumpHeight = 20;
	uiName = "Zombie Boomer";
	rideable = true;
	canRide = true;
	skinColor = "0.8 0.3 0.3 1";
	FollowAnim = "ArmReadyBoth";
	randomwalk = 1;
	ignorePipeBombs = 1;
};
function RotBoomerZombie::ondisabled(%this,%obj)
{
	
	parent::ondisabled(%this,%obj);
	if(IsInMinigame(%obj))
	{
		BoomerExplode(%obj);
	}
	ZombieDefault::ondisabled(%this,%obj);
}
function RotBoomerZombie::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	parent::oncollision(%this, %obj, %col, %fade, %pos, %norm);
	ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm);
}
function RotBoomerZombie::onMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotBoomerZombie::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
	ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f);
	parent::onUnMount(%a,%player,%vehicle,%d,%e,%f);
}
function RotBoomerZombie::onAdd(%this,%obj)
{
	parent::onAdd(%this,%obj);
	ZombieDefault::onAdd(%this,%obj);
	%obj.setscale("1.6 1.6 1.1");
}

function BoomerExplode(%bot)
{
	%bot.minigame = %bot.spawnbrick.getgroup().client.minigame;
	%bot.boom = new Projectile()
	{
		dataBlock = rocketLauncherProjectile;
		initialVelocity = "0 0 0";
		initialPosition = vectoradd(%bot.getposition(),"0 0 1");
		Position = vectoradd(%bot.getposition(),"0 0 2");
		originpoint = vectoradd(%bot.getposition(),"0 0 1");
		scale = "1 1 1";
		spawnbrick = %bot.spawnbrick;
	};
	MissionCleanup.add(%bot.boom);
	%bot.boom.explode();
	schedule(20,0,BoomerRadiusDamage,%bot);
}
function BoomerRadiusDamage(%player)
{
	if(isobject(%player) && IsInMiniGame(%player) && MinigameIncludesPlayerBricks(%player))
	{
   %searchMasks = $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType;
   %radius = 7;
   %pos = %player.getPosition();
   InitContainerRadiusSearch(%pos, %radius, %searchMasks);
  
	   while ((%targetid = containerSearchNext()) != 0 )
		{

			%id = %targetid.getId();
			
			if(%id != %player && IsInMinigame(%player) && IsInSameMinigame(%player,%id))
			{
				//messageall("","Found : " @ %id.client.name);
				%dist = containerSearchCurrRadiusDist();
				%dam = 50/%dist;
				
				if(%dist <= 1)
				{
					%dam = 100;
				}
				%halfRadius = %radius / 3;
				%distScale = (%dist < %halfRadius)? 1.0:
				1.0 - ((%dist - %halfRadius) / %halfRadius);
				%impulseVec = VectorSub(%id.getWorldBoxCenter(), vectoradd(%pos,"0 0 4"));
				%impulseVec = VectorNormalize(%impulseVec);
				%impulseVec = VectorScale(%impulseVec, 3000 * %distScale);
				//%id.applyImpulse(%pos, %impulseVec);
				if(%id.iszombie != 1 && BoomerLOSCheck(%player,%id))
				{
					schedule(10,0,BoomerHorde,%id);
					%id.setwhiteout(%dam/8);
					//BoomerBlackout(%id.client.getserverconnection(),%dam);
				}
			}
			

		}
	}
}
function BoomerLOSCheck(%this,%obj)
{
	if(!isobject(%obj))
	{
		return 0;
	}
	if(isobject(%this))
	{
		%tPos = %this.getPosition();
	}
	if(isobject(%obj))
	{
		%oPos = %obj.getposition();
	}
	%dis = VectorSub(%oPos, %tPos);
	%normVec = VectorNormalize(%dis);
	//%eyeVec = %this.getEyeVector();
	%eyevec = %normVec;
			
	%startPos = vectoradd(%tpos,"0 0 2");
	%endPos = VectorAdd(%startPos,vectorscale(%eyeVec,30));
		
	%mask = $TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType;
	%target = ContainerRayCast(%startPos, %endPos, %mask,%this);

	if(%target == %obj)
	{
		return 1;
	}
	if(%target.getclassname() $= "AiPlayer" || %target.getclassname() $= "Player")
	{
		return 1;
	}
	if(isobject(%target))
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
function BoomerBlackout(%id,%dam)
{
	%id.setblackout(true,1);
	%id.schedule(%dam*500,setblackout,false,100);

}
function BoomerHorde(%player)
{
	if($pref::Server::ZombiesEnabled == 1)
	{
		if(isobject(%player) && %player.client.minigame.EnableZombies != 0)
		{
			%searchMasks = $TypeMasks::PlayerObjectType;
			%radius = 50;
			%pos = %player.getPosition();
			InitContainerRadiusSearch(%pos, %radius, %searchMasks);
	  
			while ((%targetid = containerSearchNext()) != 0 ) 
			{

				%id = %targetid.getId();
				if(%id.getclassname() $= "AiPlayer" && IsInMinigame(%player) && IsInSameMinigame(%player,%id) && MinigameIncludesPlayerBricks(%id) == 1 && %id.iszombie == 1)
				{
					%rot = getrandom(0,1);
					if(%id.isstrangling != 1 && %rot == 1)
					{
						%id.zFollow(%player);
						cancel(%id.searchsched);
						id.searchsched = schedule(5000,0,playersearchloop,%id);
					}
				}
			}  
		}
	}
}