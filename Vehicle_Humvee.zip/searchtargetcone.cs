//########## SearchTargetCone Function

function gc_searchTargetCone(%obj,%vector,%degree,%distance,%ignore,%typemasks)
{
  %V = VectorScale(%vector,10);
  %mag2 = VectorLen(%V);
  InitContainerRadiusSearch(%obj.getPosition(),%distance,%typemasks);
  while((%target = containerSearchNext()) != 0)
  {
    if(!isObject(%target)) continue;
    if(%target $= %ignore) continue;
    %x = (getWord(%obj.getPosition(),0) - getWord(%target.getPosition(),0));
    %y = (getWord(%obj.getPosition(),1) - getWord(%target.getPosition(),1));
    %z = (getWord(%obj.getPosition(),2) - getWord(%target.getPosition(),2));
    %U = %x @ " " @ %y @ " " @ %z;
    %mag1 = VectorLen(%U);
    %result = VectorDot(%V,%U) / (%mag1*%mag2);
    %angle = mRadtoDeg(mACos(%result));
    %angle -= 180;
    if(%angle < 0) %angle *= -1;
    if(%angle <= %degree)
      return %target;
  }
  return -1;
}
