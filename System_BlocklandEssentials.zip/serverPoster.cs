$blrs::pref::master = "syerjchep.org:80";

if(!isObject(blrsPoster))
	new HTTPObject(blrsPoster);

function BLRScom_postserver()
{
	//echo("Posting to BLRS server.");  this got annoying!
	blrsPoster.get($blrs::pref::master,"/blrs/post.html?first=" @ $blrs::pref::port @ "&second=" @ $pref::server::name);
}

function BLRScom_loop()
{
	BLRScom_postserver();
	schedule(90000,0,BLRScom_loop);
}

if(!$blrsloop)
{
	$blrsloop = 1;
	BLRScom_loop();
}
