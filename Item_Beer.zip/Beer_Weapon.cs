datablock AudioProfile(GlassBreakSound)
{
	filename = "./GlassBreak.wav";
	description = AudioClosest3d;
	preload = true;
};

addDamageType("BeerGlass", '<bitmap:Add-Ons/Item_Beer/CI_BeerGlass> %1', '%2 <bitmap:Add-Ons/Item_Beer/CI_BeerGlass> %1', 1, 1);
addDamageType("BeerBottle", '<bitmap:Add-Ons/Item_Beer/CI_BeerBottle> %1', '%2 <bitmap:Add-Ons/Item_Beer/CI_BeerBottle> %1', 1, 1);
addDamageType("BrokenBeerBottle", '<bitmap:Add-Ons/Item_Beer/CI_BrokenBeerBottle> %1', '%2 <bitmap:Add-Ons/Item_Beer/CI_BrokenBeerBottle> %1', 1, 1);
//=========================================================================
// Beer Glass
//=========================================================================
datablock ExplosionData(BeerGlassExplosion)
{
   soundProfile = bulletHitSound;

   lifeTimeMS = 150;

   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = gunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0 0 0";
   lightEndColor = "0 0 0";

   damageRadius = 0;
   radiusDamage = 0;

   impulseRadius = 0;
   impulseForce = 4000;
};

datablock ProjectileData(BeerGlassProjectile)
{
   projectileShapeName = "./Glass.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::BeerBottle;
   radiusDamageType    = $DamageType::BeerBottle;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;
   brickExplosionMaxVolumeFloating = 0;

   impactImpulse       = 5;
   verticalImpulse     = 10;
   explosion           = BeerGlassExplosion;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 5000;
   lifetime            = 5000;
   fadeDelay           = 5000;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.6;
   isBallistic         = true;
   gravityMod = 1;
   explodeOnDeath = false;

   hasLight    = false;
};

datablock ProjectileData(BeerGlassProjectileCol)
{
   projectileShapeName = "./Glass.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::BeerGlass;
   radiusDamageType    = $DamageType::BeerGlass;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;
   brickExplosionMaxVolumeFloating = 0;

   impactImpulse       = 5;
   verticalImpulse     = 10;
   explosion           = BeerGlassExplosion;

   muzzleVelocity      = 1;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 1000;
   fadeDelay           = 1000;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.6;
   isBallistic         = true;
   explodeOnDeath      = true;
   gravityMod          = 1; 

   hasLight    = false;
};

function BeerGlassProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
	if(%col.getClassName() $= "Player")
		%obj.setDataBlock(BeerGlassProjectileCol);
	else
	{
		%obj.numBounces++;
		serverPlay3D(hammerHitSound,%obj.getTransform());
		if(vectorDist(%obj.lastBounce,getSimTime()) < 200)
		{
			%obj.schedule(10,"delete");
			return;
		}
		%obj.lastBounce = getSimTime();
	}
	Parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}

function BeerGlassProjectile::Damage(%this,%obj,%col,%fade,%pos,%norm)
{
	%bounces = %obj.numBounces;
	%velocity = %obj.getVelocity();
	%damage = %this.directDamage-(%bounces*3)+mFloor((%velocity/2));

	%col.damage(%obj,%pos,%damage,%this.directDamageType);
}

function BeerGlassProjectileCol::Damage(%this,%obj,%col,%fade,%pos,%norm)
{
	%bounces = %obj.numBounces;
	%velocity = %obj.getVelocity();

	%damage = %this.directDamage-(%bounces*3)+mFloor((%velocity/2));
	
	%col.damage(%obj,%pos,%damage,%this.directDamageType);
}

function randNegate(%x)
{
   %rand = getRandom(1,100);
   if(%rand >= 50)
      return %x;

   if(%rand < 50)
   {
      %x = %x * (-1);
      return %x;
   }
}
//=========================================================================
// Beer Weapon
//=========================================================================
datablock ParticleData(Beer_WeaponExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/chunk";
   colors[0]     = "0.7 0.7 0.9 0.9";
   colors[1]     = "0.9 0.9 0.9 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};

datablock ParticleEmitterData(Beer_WeaponExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "Beer_WeaponExplosionParticle";

   uiName = "Beer Bottle Hit";
};

datablock ExplosionData(Beer_WeaponExplosion)
{
   lifeTimeMS = 500;

   soundProfile = glassBreakSound;

   particleEmitter = Beer_WeaponExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   lightStartRadius = 3;
   lightEndRadius = 0;
   lightStartColor = "00.0 0.2 0.6";
   lightEndColor = "0 0 0";
};

datablock ProjectileData(Beer_WeaponProjectile)
{
   directDamage        = 40;
   directDamageType  = $DamageType::BeerBottle;
   radiusDamageType  = $DamageType::BeerBottle;
   explosion           = Beer_WeaponExplosion;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 125;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0;

   hasLight    = false;

   uiName = "Beer Bottle Hit";
};

datablock ItemData(Beer_WeaponItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./Bottle.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "Beer - Weapon";
	iconName = "./Icon_Beer_Weapon";
	doColorShift = false;

	image = Beer_WeaponImage;
	canDrop = true;
};

datablock ShapeBaseImageData(Beer_WeaponImage)
{
	shapeFile = "./Melee_Bottle.dts";
	emap = true;

	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0;
	rotation = eulerToMatrix("0 0 0");

	className = "WeaponImage";

	item = Beer_WeaponItem;
	ammo = " ";
	projectile = Beer_WeaponProjectile;
	projectileType = Projectile;

	melee = false; 		//It actually is melee but the aiming works
	doRetraction = false;	//better this way.
	armReady = true;

	doColorShift = false;

	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5; //0.5
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = WeaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.5; //0.1
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateTimeoutValue[3]            = 0.5; //0.2
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]			= "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "Fire";

	
	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2; //0.2
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";
};

function Beer_WeaponImage::onPreFire(%data, %player, %slot)
{
	%player.playThread(2, armAttack);
}

function Beer_WeaponImage::onStopFire(%data, %player, %slot)
{
	%player.playThread(2, root);
}

function Beer_WeaponProjectile::onCollision(%data, %obj, %col, %fade, %pos, %normal)
{
	if(!isObject(%col))
	{
		return;
	}

	%player = %obj.sourceObject;

	%shrapData = BeerGlassProjectile;

	%shards = getRandom(10, 25);

	for(%numbar = 0; %numbar < %shards; %numbar++)
	{
		%vector = %position;

		%x = getRandom(-4, 4) - 0.5;
		%y = getRandom(-4, 4) - 0.5;
		%z = getRandom(-4, 4) - 0.5;

		//spawn them in random sphere locations.

		if(%z < 0)
		{
			%z = randNegate(%z); //Randomly Negates Negative Z (Up/Down) Velocities to make it spread more evenly
		}

		%velocity = %x SPC %y SPC %z;

		%shraps = new projectile()
		{
			dataBlock = %shrapData;
			initialVelocity = %velocity;
			initialPosition = %pos;
			sourceObject = %player;
			sourceSlot = %player.lastBeerGlassSlot;
			client = %player.client;
		};

		missionCleanup.add(%shraps);
	}

	if(isObject(%player))
	{
		%player.tool[%player.currTool] = Beer_BrokenWeaponItem.getID();
	}

	if(isObject(%client = %player.client))
	{
		messageClient(%client, 'MsgItemPickup', '', %player.currTool, Beer_BrokenWeaponItem.getID(), 1);
	}
}
//=========================================================================
// Broken Beer Weapon
//=========================================================================
datablock ProjectileData(Beer_BrokenWeaponProjectile : Beer_WeaponProjectile)
{
   directDamage        = 20;
   directDamageType  = $DamageType::BrokenBeerBottle;
   radiusDamageType  = $DamageType::BrokenBeerBottle;

   uiName = "Broken Beer Bottle Hit";
};

datablock ItemData(Beer_BrokenWeaponItem : Beer_WeaponItem)
{
	shapeFile = "./Broken_Bottle.dts";

	//uiName = "";
	uiName = "Broken Beer Bottle";
	iconName = "./Icon_Beer_BrokenWeapon";

	image = Beer_BrokenWeaponImage;
};

datablock ShapeBaseImageData(Beer_BrokenWeaponImage : Beer_WeaponImage)
{
	shapeFile = "./Broken_Bottle.dts";

	item = Beer_BrokenWeaponItem;
	projectile = Beer_BrokenWeaponProjectile;
};

function Beer_BrokenWeaponImage::onPreFire(%data, %player, %slot)
{
	%player.playThread(2, armAttack);
}

function Beer_BrokenWeaponImage::onStopFire(%data, %player, %slot)
{
	%player.playThread(2, root);
}