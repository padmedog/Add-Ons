//Made by: Lordician
//Preferences
$Server::HeightControl::delay=100;

//Ping-Pong is from the compass mod. All credits go to the original creator for this.
//This is a safe and good way to check if the server has the mod and if the client has the clientside.
function servercmdHC_client_pong(%client,%x)
{
	if(%x == %client.HCchecknumber)
	{
		%client.hasHeightControlClient = 1;
	}
}
package HeightControlServer
{
	function GameConnection::loadMission(%client,%a,%b,%d,%e,%f)
	{
		Parent::loadMission(%client,%a,%b,%d,%e,%f);
		%client.HCchecknumber = getRandom(0,100);
		commandtoclient(%client,'HC_client_ping',%client.HCchecknumber);
	}

	//Slight support for people who don't have the client. :3
	//People without the client will only be able to 'spam' the jump key to go up.
	//They will have to rely on gravity to go down. :S
	function FlyingVehicleData::onTrigger(%this,%obj,%client)
	{
		if(!%client.hasHeightControlClient)
		{
			%data= %obj.getDatablock();
			if(%data.heightcontrol)
			{
				if(getsimtime() >= %obj.lastHoverMove+$Server::HeightControl::delay)
				{
					%velocity= "0 0 "@%data.ascendVelocity;
					%obj.setVelocity(vectorAdd(%obj.getVelocity(),%velocity));
					%obj.lastHoverMove=getsimtime();
				}
			}
		}
	}
	
	function Armor::onMount(%this,%player,%obj,%a,%b,%c,%d,%e,%f)
	{
		Parent::onMount(%this,%player,%obj,%a,%b,%c,%d,%e,%f);
		if(isObject(%player.client) && %obj.getDatablock().heightcontrol)
		{
			%player.client.bottomPrint("\c6Heightcontrol has been detected in this vehicle. Type /HChelp for help.",3);
		}
	}
};
ActivatePackage(HeightControlServer);

function servercmdHChelp(%client)
{
	if(%client.hasHeightControlClient)
	{
		messageclient(%client,'',"When in a vehicle with Heightcontrol enabled, press your jump-key to ascend and your crouch-key to descend.");
		messageclient(%client,'',"You can also hold the keys to automatically ascend/descend.");
	}
	else
	{
		messageclient(%client,'',"You do not have the add-on Support_HeightControl and thus you can only ascend by clicking the jump key to ascend.");
		messageclient(%client,'',"People with the add-on have the following extra's (due to client sided code):");
		messageclient(%client,'',"- Descend using crouch key.");
		messageclient(%client,'',"- Ascend/Descend automatically by holding the jump/crouch key.");
		if(%client.hasRTB)
			messageclient(%client,'',"<a:rtb-3612>Click here to use RTB to download Support_HeightControl.</a>");
		else
			messageclient(%client,'',"\c6You can download Support_HeightControl by visiting the following link: <a:http://forum.returntoblockland.com/dlm/viewFile.php?id=3612>Support_HeightControl on RTB</a>.");
	}
}

function servercmdhoverAscend(%client)
{
	%client.hoverTrigger = 1;
	hoverLoop(%client,1);
}
function servercmdhoverDescend(%client)
{
	%client.hoverTrigger = 1;
	hoverLoop(%client,0);
}

function hoverLoop(%client,%dir)
{
	if(%client.hoverTrigger)
	{
		%player=%client.player;
		if(!%player)
			return;
		%mnt= %player.getObjectMount();
		if(!isObject(%mnt))
			return;
		%mountObj= %mnt.getMountNodeObject(0);
		if(%mountObj!$=%player)
			return;
		%data= %mnt.getDatablock();
		if(%data.heightcontrol)
		{
			if(getsimtime() >= %mnt.lastHoverMove+$Server::HeightControl::delay)
			{
				if(%dir==1)
					%velocity= "0 0 "@%data.ascendVelocity;
				else
					%velocity= "0 0 "@%data.descendVelocity;
				%mnt.setVelocity(vectorAdd(%mnt.getVelocity(),%velocity));
				%mnt.lastHoverMove=getsimtime();
				%client.HChoverMove = schedule($Server::HeightControl::delay,0,hoverLoop,%client,%dir);
			}
		}
	}
}

function servercmdhoverStop(%client)
{
	cancel(%client.HChoverMove);
	%client.hoverTrigger=0;
}