    //########## M27
datablock AudioProfile(M27WhizSound){filename="./Sounds/whiz.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(M27DeploySound){filename="./Sounds/equip.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(M27HitSound){filename="./Add-Ons/Weapon_Gun/bulletHit.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(M27MetalHitSound){filename="./Add-Ons/Weapon_Gun/bulletHit.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(M27FireSounds){filename="./Sounds/M27fire.wav";description=AudioClose3d;preload=true;};

datablock AudioProfile(M27ClickSound){filename="./Sounds/empty.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(M27Reload1Sound){filename="./Sounds/M27Reload1.wav";description=AudioClosest3d;preload=true;};

datablock AudioProfile(M27Reload2Sound){filename="./Sounds/M27Reload2.wav";description=AudioClosest3d;preload=true;};
//
datablock AudioProfile(M27CockSound){filename="./Sounds/M27Cock.wav";description=AudioClosest3d;preload=true;};

datablock ParticleData(M27bulletExplosionParticle){dragCoefficient=8;gravityCoefficient=0;inheritedVelFactor=0.2;constantAcceleration=0;lifetimeMS=1000;lifetimeVarianceMS=0;textureName="base/data/particles/cloud";spinSpeed=10;spinRandomMin=-50;spinRandomMax=50;colors[0]="0.4 0.4 0.4 0.5";colors[1]="0.2 0.2 0.2 0";sizes[0]=0.5;sizes[1]=2;useInvAlpha=true;};

datablock ParticleEmitterData(M27bulletExplosionEmitter){uiName="";ejectionPeriodMS=8;periodVarianceMS=0;ejectionVelocity=2;velocityVariance=1;ejectionOffset=0;thetaMin=89;thetaMax=90;phiReferenceVel=0;phiVariance=360;overrideAdvance=false;particles="M27bulletExplosionParticle";};

datablock ParticleData(M27bulletDebrisExplosionParticle){dragCoefficient=0;gravityCoefficient=5;inheritedVelFactor=0.2;constantAcceleration=0;lifetimeMS=1000;lifetimeVarianceMS=500;textureName="base/data/particles/chunk";spinSpeed=10;spinRandomMin=-50;spinRandomMax=50;colors[0]="0.2 0.2 0.2 1";colors[1]="0.2 0.2 0.2 0";sizes[0]=0.2;sizes[1]=0.2;useInvAlpha=true;};

datablock ParticleEmitterData(M27bulletDebrisExplosionEmitter){uiName="";ejectionPeriodMS=3;periodVarianceMS=0;ejectionVelocity=16;velocityVariance=8;ejectionOffset=0;thetaMin=0;thetaMax=30;phiReferenceVel=0;phiVariance=360;overrideAdvance=false;particles="M27bulletDebrisExplosionParticle";};

datablock ParticleData(M27bulletExplosionSmokeParticle : M27bulletExplosionParticle){dragCoefficient=6;gravityCoefficient=0.2;inheritedVelFactor=0;lifetimeMS=1400;lifetimeVarianceMS=200;textureName="base/data/particles/cloud";colors[0]="0.6 0.6 0.6 1";colors[1]="0.6 0.6 0.6 0.2";colors[2]="0.4 0.4 0.4 0";sizes[0]=0.5;sizes[1]=0.6;sizes[2]=5;times[0]=0;times[1]=0.1;times[2]=1;useInvAlpha=true;};

datablock ParticleEmitterData(M27bulletExplosionSmokeEmitter : M27bulletExplosionEmitter){uiName="";ejectionPeriodMS=8;ejectionVelocity=9;velocityVariance=8;thetaMin=0;thetaMax=30;overrideAdvance=false;particles="M27bulletExplosionSmokeParticle";};

datablock ExplosionData(M27bulletExplosion){lifeTimeMS=50;emitter[0]=M27bulletExplosionSmokeEmitter;emitter[1]=M27bulletDebrisExplosionEmitter;faceViewer=true;explosionScale="1 1 1";shakeCamera=true;camShakeFreq="2 2 2";camShakeAmp="1 1 1";camShakeDuration=0.5;camShakeRadius=1;};

datablock ExplosionData(M27RecoilExplosion){lifeTimeMS=1;explosionScale="1 1 1";shakeCamera=true;camShakeFreq="1.5 1.5 1.5";camShakeAmp="0.1 0.21 0.28";camShakeDuration=0.6;camShakeRadius=1;};

datablock ProjectileData(M27Recoil){uiName="";explosion=M27RecoilExplosion;muzzleVelocity=0;velInheritFactor=1;lifetime=1;fadeDelay=1;explodeOnDeath=true;};

datablock ParticleData(M27FlashParticle : M27bulletExplosionParticle){dragCoefficient=0;inheritedVelFactor=1;lifetimeMS=30;textureName="base/data/particles/cloud";spinSpeed=50;spinRandomMin=-500;spinRandomMax=500;colors[0]="1 0.5 0 1";colors[1]="1 0.8 0.6 1";colors[2]="1 0.6 0.3 0";sizes[0]=0.1;sizes[1]=0.5;sizes[2]=0;times[9]=0;times[1]=0.3;times[2]=1;useInvAlpha=false;};

datablock ParticleEmitterData(M27FlashEmitter : M27bulletExplosionEmitter){ejectionPeriodMS=3;ejectionVelocity=50;velocityVariance=0;thetaMin=0;thetaMax=10;particles="M27FlashParticle";uiName="";};

datablock DebrisData(M27ShellDebris){shapeFile="./Models/modernShell.dts";lifetime=2;minSpinSpeed=-400;maxSpinSpeed=200;elasticity=0.5;friction=0.2;numBounces=3;staticOnMaxBounce=true;snapOnMaxBounce=false;fade=true;gravModifier=2;};

datablock ParticleData(SupportTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 120;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 1 0 1";
	colors[1]	= "1 1 0.4 1";
	colors[2]	= "1 1 1 1";
	sizes[0]	= 0.15;
	sizes[1]	= 0.1;
	sizes[2]	= 0.0;
	times[0]	= 0.0;
	times[1]	= 0.5;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(SupportTracer)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 30.0;  

   particles = SupportTrailParticle;

   useEmitterColors = true;
};

AddDamageType("M27",'<bitmap:Add-ons/Weapon_Support/CI_M27>%1','%2<bitmap:Add-ons/Weapon_Support/CI_M27> %1',0.2,1);

datablock ProjectileData(M27Projectiles){uiName="";
projectileShapeName="./Models/modernBullet.dts";
directDamage=35;
directDamageType=$DamageType::M27;
radiusDamageType=$DamageType::M27;brickExplosionRadius=0;
brickExplosionImpact=true;
brickExplosionForce=30;brickExplosionMaxVolume=1;
brickExplosionMaxVolumeFloating=2;
impactImpulse=60;
explosion=M27bulletExplosion;
particleEmitter     = "SupportTracer";
muzzleVelocity=500;
verInheritFactor=1;
lifetime=4000;
fadeDelay=2000;
bounceElasticity=0.5;
bounceFriction=0.2;
isBallistic=true;
gravityMod=0.20;
sound=M27WhizSound;

};

datablock ItemData(M27Items){uiName="M27";iconName="./M27";

image=M27Image;category=Weapon;className=Weapon;shapeFile="./Models/M27Display.dts";
mass=1;
density=0.2;
elasticity=0;
friction=0.6;
emap=true;
doColorShift=true;
colorShiftColor="1 1 1 1";
canDrop=true;M27reload=1;M27maxmag=46;};
datablock shapeBaseImageData(M27Image){shapeFile="./Models/M27.dts";
emap=true;
correctMuzzleVector=true;className="WeaponImage";
item=M27Items;
ammo="";
projectile=M27Projectiles;
projectileType=Projectile;
casing=M27ShellDebris;
shellExitDir="1 0.5 0.5";
shellExitVariance=10;
shellVelocity=6;
melee=false;
doReaction=false;
armReady=true;
doColorShift=true;
colorShiftColor="1 1 1 1";

//#########################################################################################
//#-Sequences-										#
//#											#
//#	fire / fire the weapon								#
//#	reload / reloads the weapon -clipIn and clipOut combined-			#
//#	use / When you equip the weapon -I added this-					#	
//#											#		
//#########################################################################################	
	
    offset = "0 0.1 0";

	stateName[0]="Activate";
	stateTimeoutValue[0]=0.2;
	stateTransitionOnTimeout[0]="AmmoCheck";
	stateSequence[0]="use";
	stateSound[0]=M27DeploySound;

	stateName[1]="Ready";
	stateTransitionOnTriggerDown[1]="Fire1";
	stateAllowImageChange[1]=true;
	stateTransitionOnNoAmmo[1]="Empty";
	
	stateName[2]="Fire1";
	stateTransitionOnTimeout[2]="AmmoCheck";
	stateTimeoutValue[2]="0.08";
	stateFire[2]=true;
	stateAllowImageChange[2]=false;
	stateWaitForTimeout[2]=true;
	stateEmitter[2]=M27FlashEmitter;
	stateEmitterTime[2]=0.05;
	stateEmitterNode[2]="muzzlePoint";
	stateSound[2]=M27FireSounds;
	stateScript[2]="onFire1";
	stateEjectShell[2]=true;
	stateSequence[2]="Fire";

	stateName[3]="Fire2";
	stateTransitionOnTimeout[3]="AmmoCheck";
	stateTimeoutValue[3]="0.23";
	stateFire[3]=true;
	stateAllowImageChange[3]=false;
	stateWaitForTimeout[3]=true;
	stateEmitter[3]=M27FlashEmitter;
	stateEmitterTime[3]=0.05;
	stateEmitterNode[3]="muzzlePoint";
	stateSound[3]=M27FireSounds;
	stateScript[3]="onFire2";
	stateEjectShell[3]=true;
	stateSequence[3]="Fire";
	
	stateName[4]="AmmoCheck";
	stateTransitionOnTimeout[4]="Ready";
	stateAllowImageChange[4]=true;
	stateScript[4]="onAmmoCheck";
	
	stateName[5]="Reload";
	stateTimeoutValue[5]=0.7;
	stateSequence[5]="Reload1";
	stateTransitionOnTimeout[5]="Reload2";
	stateWaitForTimeout[5]=true;
	stateSound[5]=M27Reload1Sound;
	stateAllowImageChange[5]=true;

	stateName[9]="Reload2";
	stateTimeoutValue[9]=0.9;
	stateSequence[9]="Reload2";
	stateTransitionOnTimeout[9]="Cock";
	stateWaitForTimeout[9]=true;
	stateSound[9]=M27Reload2Sound;
	stateAllowImageChange[9]=true;
	
	stateName[10]="Cock";
	stateTimeoutValue[10]=1.0;
	stateSequence[10]="Cock";
	stateTransitionOnTimeout[10]="Done";
	stateWaitForTimeout[10]=true;
	stateSound[10]=M27CockSound;
	stateAllowImageChange[10]=true;
	
	stateName[6]="Done";
	stateTransitionOnTimeout[6]="Ready";
	stateTimeoutValue[6]=0.1;
	stateAllowImageChange[6]=true;
	stateScript[6]="onReload";stateName[7]="Empty";
	
	stateTransitionOnTriggerDown[7]="EmptyFire";
	stateAllowImageChange[7]=true;
	stateTransitionOnAmmo[7]="Reload";
	
	stateName[8]="EmptyFire";
	stateTransitionOnTriggerUp[8]="Ready";
	stateTimeoutValue[8]="0.15";
	stateAllowImageChange[8]=false;
	stateWaitForTimeout[8]=true;
	stateSound[8]=M27ClickSound;

};		
	
	datablock shapeBaseImageData(M27ImageScoped : M27Image)
{
	offset = "-0.2 0.1 0"; //-Left +Right, -Back +Front, -Down +Up
   	eyeOffset="0.0 1.5 -0.95"; //-Left +Right, -Back +Front, -Down +Up


	stateName[0]="Activate";
	stateTimeoutValue[0]=0.3;
	stateTransitionOnTimeout[0]="AmmoCheck";
	//stateSequence[0]="Sight";
	
	stateName[1]="Ready";
	stateTransitionOnTriggerDown[1]="Fire1";
	stateAllowImageChange[1]=true;
	stateTransitionOnNoAmmo[1]="Empty";
	stateSequence[1]="Ready";
	
	stateName[2]="Fire1";
	stateTransitionOnTimeout[2]="AmmoCheck";
	stateTimeoutValue[2]="0.08";
	stateFire[2]=true;
	stateAllowImageChange[2]=false;
	stateWaitForTimeout[2]=true;
	stateEmitter[2]=M27FlashEmitter;
	stateEmitterTime[2]=0.10;
	stateEmitterNode[2]="muzzlePoint";
	stateSound[2]=M27FireSounds;
	stateScript[2]="onFire1";
	stateEjectShell[2]=true;
	stateSequence[2]="Fire";
	
	stateName[3]="Fire2";
	stateTransitionOnTimeout[3]="AmmoCheck";
	stateTimeoutValue[3]="0.25";
	stateFire[3]=true;
	stateAllowImageChange[3]=false;
	stateWaitForTimeout[3]=true;
	stateEmitter[3]=M27FlashEmitter;
	stateEmitterTime[3]=0.05;
	stateEmitterNode[3]="muzzlePoint";
	stateSound[3]=M27FireSounds;
	stateScript[3]="onFire2";
	stateEjectShell[3]=true;
	stateSequence[3]="Fire";
	
	stateName[4]="AmmoCheck";
	stateTransitionOnTimeout[4]="Ready";
	stateAllowImageChange[4]=true;
	stateScript[4]="onAmmoCheck";
	
	stateName[5]="Reload";
	stateTimeoutValue[5]=0.7;
	stateSequence[5]="Reload";
	stateTransitionOnTimeout[5]="Reload2";
	stateWaitForTimeout[5]=true;
	stateSound[5]=M27Reload1Sound;
	stateAllowImageChange[5]=true;
	stateSequence[5]="Reload1";

	stateName[10]="Reload2";
	stateTimeoutValue[10]=0.9;
	stateSequence[10]="Reload2";
	stateTransitionOnTimeout[10]="Cock";
	stateWaitForTimeout[10]=true;
	stateSound[10]=M27Reload2Sound;
	stateAllowImageChange[10]=true;
	
	stateName[11]="Cock";
	stateTimeoutValue[11]=1.0;
	stateSequence[11]="Cock";
	stateTransitionOnTimeout[11]="Done";
	stateWaitForTimeout[11]=true;
	stateSound[11]=M27CockSound;
	stateAllowImageChange[11]=true;

	stateName[6]="Done";
	stateTransitionOnTimeout[6]="Ready";
	stateTimeoutValue[6]=0.1;
	stateAllowImageChange[6]=true;
	stateScript[6]="onReload";

	stateName[7]="Empty";
	stateTransitionOnTriggerDown[7]="EmptyFire";
	stateAllowImageChange[7]=true;
	stateTransitionOnAmmo[7]="Reload";
	stateName[8]="EmptyFire";
	stateTransitionOnTriggerUp[8]="Ready";
	stateTimeoutValue[8]="0.15";
	stateAllowImageChange[8]=false;
	stateWaitForTimeout[8]=true;
	stateSound[8]=M27ClickSound;

	stateName[9]="ReadyWeap";
	stateSequence[9]="Ready";
	stateTimeoutValue[9]=0.95;
	stateSound[9]=M27DeploySound;
	stateTransitionOnTimeout[9]="Ready";

};
   
function M27Image::onAmmoCheck(%this,%obj,%slot)
{
	if(%obj.toolMag[%obj.currTool]<1)
	{	
		%obj.toolMag[%obj.currTool]=0;

	}
	if(%obj.toolMag[%obj.currTool]>%this.item.M27maxmag)
	
	{
		%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;
	
	}
	if(%obj.toolMag[%obj.currTool]<1)
	
	{

		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

}
}
function M27Image::onReload(%this,%obj,%slot)
	
{
	%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;%obj.setImageAmmo(0,1);

}
function M27Image::onFire1(%this,%obj,%slot)

	{
		%obj.toolMag[%obj.currTool]-=1;if(%obj.toolMag[%obj.currTool]<1)

	{
		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

	}
		M27Fire(%this,%obj,%slot,0.0015,1,0.02);

}
function M27Image::onFire2(%this,%obj,%slot)
	{
		%obj.toolMag[%obj.currTool]-=1;

	if(%obj.toolMag[%obj.currTool]<1)
	{
		%obj.toolMag[%obj.currTool]=0;%obj.setImageAmmo(0,0);

	}
		M27Fire(%this,%obj,%slot,0.0030,1,0.04);
}
	function M27Image::onMount(%this,%obj,%slot)
	
{
	if(%obj.toolMag[%obj.currTool]$="")
	{

		%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;
}

		parent::onMount(%this,%obj,%slot);

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
}
function M27Image::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);
			%obj.unhideNode("ALL");

	if(isObject(%obj.client))
	{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();
	}
	else{applyDefaultCharacterPrefs(%obj);

	}

			%obj.client.setControlCameraFov(90);

}
function M27ImageScoped::onAmmoCheck(%this,%obj,%slot)

{
	if(%obj.toolMag[%obj.currTool]<1)

	{
			%obj.toolMag[%obj.currTool]=0;

	}
	if(%obj.toolMag[%obj.currTool]>%this.item.M27maxmag)

	{
			%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;

	}
	if(%obj.toolMag[%obj.currTool]<1)

	{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

}
}
function M27ImageScoped::onReload(%this,%obj,%slot)

		{
			%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;
			%obj.setImageAmmo(0,1);

}
	function M27ImageScoped::onFire1(%this,%obj,%slot)

		{
			%obj.toolMag[%obj.currTool]-=1;
	
	if(%obj.toolMag[%obj.currTool]<1)
		
		{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

	}
		M27Fire(%this,%obj,%slot,0.0015,1,0.02);

}
function M27ImageScoped::onFire2(%this,%obj,%slot)

{
			%obj.toolMag[%obj.currTool]-=1;

	if(%obj.toolMag[%obj.currTool]<1)

		{
			%obj.toolMag[%obj.currTool]=0;
			%obj.setImageAmmo(0,0);

	}
		M27Fire(%this,%obj,%slot,0.0030,1,0.04);

}

function M27ImageScoped::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);

			%obj.unhideNode("ALL");

	if(isObject(%obj.client))

		{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();

		}
			else{applyDefaultCharacterPrefs(%obj);

		}
			%obj.client.setControlCameraFov(90);

}
function M27Projectiles::onCollision(%this,%obj,%col,%fade,%pos,%norm)

{
	if(%col.getClassName()$="WheeledVehicle"||%col.getClassName()$="FlyingVehicle")serverPlay3D(M27MetalHitSound,%obj.getTransform());


			else{serverPlay3D(M27HitSound,%obj.getTransform());

	}
		parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);

}
function M27Fire(%this,%obj,%slot,%spread,%shellcount,%recoil)


{
	if(%obj.isCrouched()==1){%spread=%spread-0.00001;%recoil=%recoil/2;

}
	if(vectorLen(%obj.getVelocity()) >= 0.1 && !isObject(%obj.getObjectMount()))

		{
			%spread=%spread+0.0001;}%vector=%obj.getMuzzleVector(%slot);%p=new Projectile()

{
dataBlock=M27Recoil;initialVelocity=%obj.getVelocity();

	initialPosition=%obj.getEyePoint();
	sourceObject=%obj;sourceSlot=%slot;client=%obj.client;};
	for(%shell=0;%shell<%shellcount;
	%shell++){%x=(getRandom()-0.5)*31.415926*%spread;
	%y=(getRandom()-0.5)*30.415926*%spread;
	%z=(getRandom()-0.5)*30.415926*%spread;
	%p=new Projectile(){dataBlock=M27Projectiles;
	initialVelocity=MatrixMulVector(MatrixCreateFromEuler(%x@" "@%y@" "@%z),VectorScale(%obj.getMuzzleVector(%slot),M27Projectiles.muzzleVelocity));
	initialPosition=%obj.getMuzzlePoint(%slot);
	sourceObject=%obj;sourceSlot=%slot;
	client=%obj.client;};
	MissionCleanup.add(%p);

}
	if(isObject(%obj.getObjectMount()))

	{
		return %p;}%a=%obj.getTransform();

			%rnd=getRandom(1);if(%rnd==1)

		{
			%recoil=%recoil*-1;

		}
			%obj.setTransform(getWord(%a,0)@" "@getWord(%a,1)@" "@getWord(%a,2)@" "@getWord(%a,3)@" "@getWord(%a,4)@" "@getWord(%a,5)@" "@getWord(%a,6)+%recoil);

	return %p;}package M27

{
function GameConnection::onDeath(%this,%killerPlayer,%killer,%damageType,%damageLoc)

{
		%this.player.client.setControlCameraFov(90);

		parent::onDeath(%this,%killerPlayer,%killer,%damageType,%damageLoc);

}
function Armor::onTrigger(%this,%player,%slot,%val){if(isObject(%player.getMountedImage(0)))

	{
		%item=%player.getMountedImage(0).getName();if((%item $= "M27Image" || %item $= "M27ImageScoped") && %slot $= 4 && %val)

{
	if(%item$="M27Image"){%player.mountImage(M27ImageScoped,0);

			%player.client.setControlCameraFov(80);
}
	if(%item$="M27ImageScoped")

	{
		%player.mountImage(M27Image,0);

			%player.client.setControlCameraFov(90);

		}
		}
		else{parent::onTrigger(%this,%player,%slot,%val);

		}
		}
		else{parent::onTrigger(%this,%player,%slot,%val);

}
}
function Player::pickUp(%this,%item)

	{
			%data=%item.dataBlock;
			%mag=%item.mag;
			%status=parent::pickUp(%this,%item);

	if(!%status==1)

	{
		return %status;}
			%slot=-1;
	
	for(%i=0;%i<%this.dataBlock.maxTools;%i++)


	if(isObject(%this.tool[%i])&&%this.tool[%i].getID()==%data.getID()){%slot=%i;break;
}	

	if(%slot == -1)
	
{
		return %val;

}
	if(%mag $= "")

		{
			%this.toolMag[%slot]=%data.M27maxmag;

		}
			else%this.toolMag[%slot]=%mag;

}
function serverCmdDropTool(%client,%slot)

{
	if(!isObject(%client.player))

	{
		return parent::serverCmdDropTool(%client,%slot);

}
	$weaponMag=%client.player.toolMag[%client.player.currTool];

			%client.player.toolMag[%client.player.currTool]="";

		return parent::serverCmdDropTool(%client,%slot);

}
function ItemData::onAdd(%this,%obj){if($weaponMag!$="")

{
			%obj.mag=$weaponMag;$weaponMag="";

	}
		parent::onAdd(%this,%obj);

}
function serverCmdLight(%client)

	{
		%player=%client.player;

			%image=%player.getMountedImage(0);

	if(%image.item.M27reload)

{
	if(%player.getImageState(0)$="Ready"||%player.getImageState(0)$="Empty")

{
	if(%player.toolMag[%player.currTool]<%image.item.M27maxmag)

{
		%player.setImageAmmo(0,0);

			%player.Schedule(50,setImageAmmo,0,1);

		}
			else{parent::serverCmdLight(%client);

	}
	}
		return;}parent::serverCmdLight(%client);

}
}
;activatePackage(M27);  

function M27Image::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);

			%obj.unhideNode("ALL");
            crossHair.setBitmap("base/client/ui/crosshair.png");

	if(isObject(%obj.client))

		{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();

		}
			else{applyDefaultCharacterPrefs(%obj);

		}
			%obj.client.setControlCameraFov(90);

}
function M27ImageScoped::onUnMount(%this,%obj,%slot)

	{
		parent::onUnMount(%this,%obj,%slot);

			%obj.unhideNode("ALL");
            crossHair.setBitmap("base/client/ui/crosshair.png");

	if(isObject(%obj.client))

		{
			%obj.client.applyBodyParts();
			%obj.client.applyBodyColors();

		}
			else{applyDefaultCharacterPrefs(%obj);

		}
			%obj.client.setControlCameraFov(90);

}

function M27ImageScoped::onMount(%this,%obj,%slot)
{
    if(%obj.toolMag[%obj.currTool]$="")
{
			%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;
}

	
		crossHair.setBitmap("add-ons/weapon_Support/empty.png");
	
    
                parent::onMount(%this,%obj,%slot);
		    	
			    %obj.hideNode("LHand");
			    %obj.hideNode("RHand");
			    %obj.hideNode("LHook");
			    %obj.hideNode("RHook");

}

function M27Image::onMount(%this,%obj,%slot)
{
    if(%obj.toolMag[%obj.currTool]$="")
{
			%obj.toolMag[%obj.currTool]=%this.item.M27maxmag;
}

	
		crossHair.setBitmap("base/client/ui/crosshair.png");
	
    
                parent::onMount(%this,%obj,%slot);
		    	
			    %obj.hideNode("LHand");
			    %obj.hideNode("RHand");
			    %obj.hideNode("LHook");
			    %obj.hideNode("RHook");

}