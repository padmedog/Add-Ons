datablock fxLightData(DDNegativeLightGreenVerySmall)
{
	uiName = "Anti Green Very Small";
	LightOn = true;
	radius = 0;
	brightness = -10;
	color = "0 1 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightGreenSmall)
{
	uiName = "Anti Green Small";
	LightOn = true;
	radius = 0;
	brightness = -25;
	color = "0 1 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightGreenMedium)
{
	uiName = "Anti Green Medium";
	LightOn = true;
	radius = 0;
	brightness = -50;
	color = "0 1 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightGreenLarge)
{
	uiName = "Anti Green Large";
	LightOn = true;
	radius = 0;
	brightness = -100;
	color = "0 1 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};

datablock fxLightData(DDNegativeLightGreenVeryLarge)
{
	uiName = "Anti Green Very Large";
	LightOn = true;
	radius = 0;
	brightness = -200;
	color = "0 1 0 0";
	flareOn = false;
	flaretp = false;
	flarebitmap = "";
	NearSize	= 2;
	FarSize = 1;
};