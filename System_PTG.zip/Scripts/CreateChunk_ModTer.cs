// -------------
// | A | B | C |
// -------------
// | D | E | F |
// -------------
// | G | H | I |
// -------------

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_ModTer_DetPass()
{
	$MTH = $TerHO+((mFloor($RHfs/$TerHS))*$TerHS)+1;

	%pos = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);
	
	if(%brick = containerSearchNext())
		%BiZe=2;
	else
		%BiZe=1;

	if(%BiZe==1)
	{
		%pos = ($ChPx+$CX) @ " " @ (($ChPy+$CY)+2) @ " " @ ($MTH);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZb=2;
			else
				%BiZb=1;
		}
		else
			%BiZb=1;

		%pos = (($ChPx+$CX)-2) @ " " @ ($ChPy+$CY) @ " " @ ($MTH);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);
	
		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZd=2;
			else
				%BiZd=1;
		}
		else
			%BiZd=1;

		%pos = (($ChPx+$CX)+2) @ " " @ ($ChPy+$CY) @ " " @ ($MTH);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZf=2;
			else
				%BiZf=1;
		}
		else
			%BiZf=1;

		%pos = ($ChPx+$CX) @ " " @ (($ChPy+$CY)-2) @ " " @ ($MTH);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZh=2;
			else
				%BiZh=1;
		}
		else
			%BiZh=1;
	}
	$Zbdfh = %BiZb @ %BiZd @ %BiZf @ %BiZh;
	CreateChunk_ModTer_DetPassB();
}
function CreateChunk_ModTer_DetPassB()
{		
	$db = NA;
	$rot = "0 0 0 0";
	$Hmod = 0;
		
	if($Zbdfh==2211) 
	{
		$db = brick4CornerB1Data;
		$rot = "0 0 1 270";
		$Hmod = 2;

		ZoneACGI();

		if($Zacgi==2111)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4CornerA1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
	}
	if($Zbdfh==2121) 
	{
		$db = brick4CornerB1Data;
		$rot = "0 0 0 0";
		$Hmod = 2;

		ZoneACGI();

		if($Zacgi==1211)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4CornerA1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
	}
	if($Zbdfh==1122) 
	{
		$db = brick4CornerB1Data;
		$rot = "0 0 1 90";
		$Hmod = 2;

		ZoneACGI();

		if($Zacgi==1112)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4CornerA1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
	}
	if($Zbdfh==1212) 
	{
		$db = brick4CornerB1Data;
		$rot = "0 0 1 180";
		$Hmod = 2;

		ZoneACGI();

		if($Zacgi==1121)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4CornerA1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
	}
	if($Zbdfh==2111)
	{
		$db = brick4Ramp1Data;
		$rot = "0 0 1 270";
		$Hmod = 0;

		ZoneACGI(); 

		if(getSubStr($Zacgi,2,1)==1 && getSubStr($Zacgi,3,1)==2)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 0 0";
		}
		if(getSubStr($Zacgi,2,1)==2 && getSubStr($Zacgi,3,1)==1)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 1 270";
		}
	}
	if($Zbdfh==1121)
	{
		$db = brick4Ramp1Data;
		$rot = "0 0 0 0";
		$Hmod = 0;

		ZoneACGI();
			
		if(getSubStr($Zacgi,0,1)==2 && getSubStr($Zacgi,2,1)==1)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 0 0";
		}
		if(getSubStr($Zacgi,0,1)==1 && getSubStr($Zacgi,2,1)==2)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 1 90";
		}
	}
	if($Zbdfh==1112)
	{
		$db = brick4Ramp1Data;
		$rot = "0 0 1 90";
		$Hmod = 0;

		ZoneACGI();
		
		if(getSubStr($Zacgi,0,1)==1 && getSubStr($Zacgi,1,1)==2)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 1 90";
		}
		if(getSubStr($Zacgi,0,1)==2 && getSubStr($Zacgi,1,1)==1)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 1 180";
		}
	}
	if($Zbdfh==1211) 
	{
		$db = brick4Ramp1Data;
		$rot = "0 0 1 180";
		$Hmod = 0;

		ZoneACGI();
			
		if(getSubStr($Zacgi,1,1)==2 && getSubStr($Zacgi,3,1)==1)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 1 270";
		}
		if(getSubStr($Zacgi,1,1)==1 && getSubStr($Zacgi,3,1)==2)
		{
			$db = brick4CornerB1Data;
			$rot = "0 0 1 180";
		}
	}
	if(getSubStr($Zbdfh,0,1)==2 && getSubStr($Zbdfh,3,1)==2)
	{
		$db = brick4Cube1Data;
		$rot = "0 0 0 0";
		$Hmod = 2;

		ZoneACGI();

		if($Zacgi==2211)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 1 270";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
		if($Zacgi==1212)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
		if($Zacgi==1122)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;angleID = 0;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 1 90";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
		if($Zacgi==2121)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 1 180";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
	}
	if(getSubStr($Zbdfh,1,1)==2 && getSubStr($Zbdfh,2,1)==2)
	{
		$db = brick4Cube1Data;
		$rot = "0 0 0 0";
		$Hmod = 2;

		ZoneACGI();

		if($Zacgi==2211)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 1 270";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
		if($Zacgi==1212)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 0 0";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
		if($Zacgi==1122)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 1 90";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
		if($Zacgi==2121)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Ramp1Data;
				position = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTH+$Hmod);
				rotation = "0 0 1 180";
				scale = "1 1 1";
				colorID = $ColDirt;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriDirt;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();

			if($FloI==1)
				$RHfsM=($MTH+$Hmod-$TerHO+$FISH);
			else
				$RHfsM=($MTH+$Hmod-$TerHO);
			CreateChunk_Biomes(%brick);
		}
	}
	if($Zbdfh==1111) 
	{
		$Hmod = 0;
		ZoneACGI();
			
		if($Zacgi==2111)
		{
			$db = brick4CornerA1Data;
			$rot = "0 0 1 270";
		}
		if($Zacgi==1211)
		{
			$db = brick4CornerA1Data;
			$rot = "0 0 0 0";
		}
		if($Zacgi==1112)
		{
			$db = brick4CornerA1Data;
			$rot = "0 0 1 90";
		}
		if($Zacgi==1121)
		{
			$db = brick4CornerA1Data;
			$rot = "0 0 1 180";
		}
		if($Zacgi==2211)
		{
			$db = brick4Ramp1Data;
			$rot = "0 0 1 270";
		}
		if($Zacgi==1212)
		{
			$db = brick4Ramp1Data;
			$rot = "0 0 0 0";
		}
		if($Zacgi==1122)
		{
			$db = brick4Ramp1Data;
			$rot = "0 0 1 90";
		}
		if($Zacgi==2121)
		{
			$db = brick4Ramp1Data;
			$rot = "0 0 1 180";
		}
		if($Zacgi==1221)
		{
			$db = brick4Cube1Data;
			$rot = "0 0 0 0";
		}
		if($Zacgi==2112)
		{
			$db = brick4Cube1Data;
			$rot = "0 0 0 0";
		}
	}
}
function ZoneACGI()
{
	%pos = (($ChPx+$CX)-2) @ " " @ (($ChPy+$CY)+2) @ " " @ ($MTH+$Hmod);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

	if(%brick = containerSearchNext())
	{
		%test = %brick.getDatablock().getName();

		if(%test $= brick4Cube1Data)
			%BiZa=2;
		else
			%BiZa=1;
	}
	else
		%BiZa=1;

	%pos = (($ChPx+$CX)+2) @ " " @ (($ChPy+$CY)+2) @ " " @ ($MTH+$Hmod);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);
	
	if(%brick = containerSearchNext())
	{
		%test = %brick.getDatablock().getName();

		if(%test $= brick4Cube1Data)
			%BiZc=2;
		else
			%BiZc=1;
	}
	else
		%BiZc=1;

	%pos = (($ChPx+$CX)-2) @ " " @ (($ChPy+$CY)-2) @ " " @ ($MTH+$Hmod);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

	if(%brick = containerSearchNext())
	{
		%test = %brick.getDatablock().getName();

		if(%test $= brick4Cube1Data)
			%BiZg=2;
		else
			%BiZg=1;
	}
	else
		%BiZg=1;

	%pos = (($ChPx+$CX)+2) @ " " @ (($ChPy+$CY)-2) @ " " @ ($MTH+$Hmod);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

	if(%brick = containerSearchNext())
	{
		%test = %brick.getDatablock().getName();

		if(%test $= brick4Cube1Data)
			%BiZi=2;
		else
			%BiZi=1;
	}
	else
		%BiZi=1;

	$Zacgi = %BiZa @ %BiZc @ %BiZg @ %BiZi;
}
function ZoneBDFHb()
{
	%pos = ($ChPx+$CX) @ " " @ ($ChPy+$CY) @ " " @ ($MTHb);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);
	
	if(!%brick = containerSearchNext())
	{
		%pos = ($ChPx+$CX) @ " " @ (($ChPy+$CY)+2) @ " " @ ($MTHb);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZb=2;
			else
				%BiZb=1;
		}
		else
			%BiZb=1;

		%pos = (($ChPx+$CX)-2) @ " " @ ($ChPy+$CY) @ " " @ ($MTHb);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZd=2;
			else
				%BiZd=1;
		}
		else
			%BiZd=1;

		%pos = (($ChPx+$CX)+2) @ " " @ ($ChPy+$CY) @ " " @ ($MTHb);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZf=2;
			else
				%BiZf=1;
		}
		else
			%BiZf=1;

		%pos = ($ChPx+$CX) @ " " @ (($ChPy+$CY)-2) @ " " @ ($MTHb);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(%brick = containerSearchNext())
		{
			%test = %brick.getDatablock().getName();

			if(%test $= brick4Cube1Data)
				%BiZh=2;
			else
				%BiZh=1;
		}
		else
			%BiZh=1;
	}

	$ZbdfhB = %BiZb @ %BiZd @ %BiZf @ %BiZh;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_ModTer_Normal_SolidG_Caves()
{	
	%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH-$TerHO);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

	if(!%brick=containerSearchNext())
	{
		if($MTH>1)
		{	
			%brick = new fxDTSbrick()
			{
				datablock = $db;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH-$TerHO);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColStone;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriStone;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
	for(%Cz=$MTH;%Cz>=(($MTH-2)+(-($MTH-$TerHO-2)*1.5))-1;%Cz=%Cz-2) //$TerHO+(-($MTH-$TerHO)*1.5)-1
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(!%brick=containerSearchNext())
		{
			if($MTH>1 && %Cz>=(($MTH-2)+(-($MTH-$TerHO-2)*1.5))-1)
			{
				if(%Cz<$MTH)
				{
					if($db $= brick4Ramp1Data)
						$db=brick4Ramp1invData;
					if($db $= brick4CornerA1Data)
						$db=brick4CornerA1invData;
					if($db $= brick4CornerB1Data)
						$db=brick4CornerB1invData;
				}
				%brick = new fxDTSbrick()
				{
					datablock = $db;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
					rotation = $rot;
					scale = "1 1 1";
					colorID = $ColStone;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriStone;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();

				if(%Cz==$MTH)
				{
					$RHfsM=($MTH-$TerHO);
					CreateChunk_Biomes(%brick);
				}
			}
		}
	}
	if($db $= brick4CornerB1invData)
	{
		$MTHb=%Cz;
		ZoneBDFHb();

		if($ZbdfhB==2211 || $ZbdfhB==2121 || $ZbdfhB==1122 || $ZbdfhB==1212)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Wedge1Data;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColStone;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriStone;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_ModTer_Normal_SolidG_NoCaves()
{
	%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

	if(!%brick=containerSearchNext() && $MTH>1)
	{
		%brick = new fxDTSbrick()
		{
			datablock = $db;
			position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH);
			rotation = $rot;
			scale = "1 1 1";
			colorID = $ColStone;
			colorFXID = 0;
			shapefxID = 0;
			printID = $PriStone;
			angleID = 0;
			client = $cl;
			stackBL_ID = $cl.bl_id;
			isPlanted = 1;
			PTG = 1;
		};
		$clBG.add(%brick);
		%brick.setTrusted(1);
		%brick.plant();
		$RHfsM=($MTH-$TerHO);

		CreateChunk_Biomes(%brick);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_ModTer_Normal_EmptyG_Caves()
{	
	%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH-$TerHO);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

	if(!%brick=containerSearchNext())
	{
		if(($MTH-$TerHO)<(($TerHO+(-($MTH-$TerHO)*1.5))-1))
		{
			if($MTH>1)
			{
				%brick = new fxDTSbrick()
				{
					datablock = $db;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH-$TerHO);
					rotation = $rot;
					scale = "1 1 1";
					colorID = $ColStone;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriStone;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();
			}
		}
	}
	for(%Cz=$MTH;%Cz>=$TerHO+(-($MTH-$TerHO)*1.5)+1;%Cz=%Cz-2)
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);

		if(!%brick=containerSearchNext())
		{
			if($MTH>1)
			{
				if((%Cz==$MTH || %Cz<=($TerHO+(-($MTH-$TerHO)*1.5)+3)) && ($MTH-$TerHO)<(($TerHO+(-($MTH-$TerHO)*1.5))+5))
				{
					if(%Cz<$MTH)
					{
						if($db $= brick4Ramp1Data)
							$db=brick4Ramp1invData;
						if($db $= brick4CornerA1Data)
							$db=brick4CornerA1invData;
						if($db $= brick4CornerB1Data)
							$db=brick4CornerB1invData;
					}
					%brick = new fxDTSbrick()
					{
						datablock = $db;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
						rotation = $rot;
						scale = "1 1 1";
						colorID = $ColStone;
						colorFXID = 0;
						shapefxID = 0;
						printID = $PriStone;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();

					if(%Cz==$MTH)
					{
						$RHfsM=($MTH-$TerHO);
						CreateChunk_Biomes(%brick);
					}
				}
			}
		}
	}
	if($db $= brick4CornerB1invData)
	{
		$MTHb=%Cz;
		ZoneBDFHb();

		if($ZbdfhB==2211 || $ZbdfhB==2121 || $ZbdfhB==1122 || $ZbdfhB==1212)
		{
			%brick = new fxDTSbrick()
			{
				datablock = brick4Wedge1Data;
				position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
				rotation = $rot;
				scale = "1 1 1";
				colorID = $ColStone;
				colorFXID = 0;
				shapefxID = 0;
				printID = $PriStone;
				angleID = 0;
				client = $cl;
				stackBL_ID = $cl.bl_id;
				isPlanted = 1;
				PTG = 1;
			};
			$clBG.add(%brick);
			%brick.setTrusted(1);
			%brick.plant();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_ModTer_Normal_EmptyG_NoCaves()
{
	%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH);
	%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
	initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

	if(!%brick=containerSearchNext() && $MTH>1)
	{
		%brick = new fxDTSbrick()
		{
			datablock = $db;
			position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ ($MTH);
			rotation = $rot;
			scale = "1 1 1";
			colorID = $ColStone;
			colorFXID = 0;
			shapefxID = 0;
			printID = $PriStone;
			angleID = 0;
			client = $cl;
			stackBL_ID = $cl.bl_id;
			isPlanted = 1;
			PTG = 1;
		};
		$clBG.add(%brick);
		%brick.setTrusted(1);
		%brick.plant();
		$RHfsM=($MTH-$TerHO);
		$RHfsM=($MTH-$TerHO);

		CreateChunk_Biomes(%brick);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function CreateChunk_ModTer_FloatingIslands_SolidGandEmptyG()
{
	for(%Cz=$MTH;%Cz>=($TerHO+(-($MTH-$TerHO)*1.5)+$FISH*3);%Cz=%Cz-2)
	{
		%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
		%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
		initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

		if(!%brick=containerSearchNext() && $MTH>1 && $MTH>$FISH)
		{
			if(%Cz==$MTH || %Cz<=($TerHO+(-($MTH-$TerHO)*1.5)+$FISH*3)+2)
			{
				if(%Cz<$MTH)
				{
					if($db $= brick4Ramp1Data)
						$db=brick4Ramp1invData;
					if($db $= brick4CornerA1Data)
						$db=brick4CornerA1invData;
					if($db $= brick4CornerB1Data)
						$db=brick4CornerB1invData;
				}
				%brick = new fxDTSbrick()
				{
					datablock = $db;
					position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz);
					rotation = $rot;
					scale = "1 1 1";
					colorID = $ColStone;
					colorFXID = 0;
					shapefxID = 0;
					printID = $PriStone;
					angleID = 0;
					client = $cl;
					stackBL_ID = $cl.bl_id;
					isPlanted = 1;
					PTG = 1;
				};
				$clBG.add(%brick);
				%brick.setTrusted(1);
				%brick.plant();

				if(%Cz==$MTH)
				{
					$RHfsM=($MTH-$TerHO);
					CreateChunk_Biomes(%brick);
				}
			}
			if(%Cz<=($TerHO+(-($MTH-$TerHO)*1.5)+$FISH*3)+2)
			{
				%pos = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz+2);
				%size = 1.5 @ " " @ 1.5 @ " " @ 1.5;	
				initContainerBoxSearch(%pos,%size,$TypeMasks::FxBrickObjectType);	

				if(!%brick=containerSearchNext())
				{
					if($db $= brick4CornerA1invData)
						$db=brick4Wedge1Data;
					else
						$db=brick4Cube1Data;
			
					%brick = new fxDTSbrick()
					{
						datablock = $db;
						position = ($ChPx+$Cx) @ " " @ ($ChPy+$Cy) @ " " @ (%Cz+2);
						rotation = $rot;
						scale = "1 1 1";
						colorID = $ColStone;
						colorFXID = 0;
						shapefxID = 0;
						printID = $PriStone;
						angleID = 0;
						client = $cl;
						stackBL_ID = $cl.bl_id;
						isPlanted = 1;
						PTG = 1;
					};
					$clBG.add(%brick);
					%brick.setTrusted(1);
					%brick.plant();

					if(%Cz==$MTH)
					{
						$RHfsM=($MTH-$TerHO);
						CreateChunk_Biomes(%brick);
					}
				}
			}
		}
	}
}