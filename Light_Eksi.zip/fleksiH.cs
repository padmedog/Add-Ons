datablock fxLightData(HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Ana blue";

	LightOn = false;

	flareOn = true;
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicblue";
	ConstantSizeOn = true;
	ConstantSize = 1.5;
	NearSize = 1;
	FarSize = 1;
	Fadetime = 0.03;
};
datablock fxLightData(HHflAnayel : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Ana yellow";
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicyellow";
};
datablock fxLightData(HflBleuhoriz : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Horiz blue";
	flarebitmap = "Add-Ons/Light_Eksi/bleuhorizontal";
};
datablock fxLightData(HflBleutonderayons : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Blue-rays";
	flarebitmap = "Add-Ons/Light_Eksi/bleutonderayons";
};
datablock fxLightData(HflClassicblue : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Blue 3";
	flarebitmap = "Add-Ons/Light_Eksi/classicblue";
};
datablock fxLightData(HflEtoilebleu : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Blue bright";
	flarebitmap = "Add-Ons/Light_Eksi/etoilebleu";
};
datablock fxLightData(HflJaunidiagonal : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Diag yellow";
	flarebitmap = "Add-Ons/Light_Eksi/jaunidiagonal";
};
datablock fxLightData(HflMultidirectionalcolor : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Teal multi";
	flarebitmap = "Add-Ons/Light_Eksi/multidirectionalcolor";
};
datablock fxLightData(HflNeutresunetoile : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Neutral star";
	flarebitmap = "Add-Ons/Light_Eksi/neutresunetoile";
};
datablock fxLightData(HflNormal20 : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Normal 20";
	flarebitmap = "Add-Ons/Light_Eksi/normal20";
};
datablock fxLightData(HflVertical : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - Vert yellow";
	flarebitmap = "Add-Ons/Light_Eksi/vertical";
};
datablock fxLightData(HflFlashlight : HflAnablue)
{
	uiName = "Eksi (IMG) 1/2 - White spectrum";
	flarebitmap = "Add-Ons/Light_Eksi/flashlight";
	ConstantSize = 2.5;
};