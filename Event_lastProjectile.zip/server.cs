%error = ForceRequiredAddOn("Event_Variables");

if(%error == $Error::AddOn_NotFound)
{
	error("ERROR: VCE_lastProjectile - required add-on Event_Variables not found");
}
else
{
	exec("./LastProj.cs");
}