//audio

datablock ParticleData(FWRLFlashParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 100.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.9 0.4 0.1 0.9";
	colors[1]     = "0.9 0.5 0.2 0.0";
	sizes[0]      = 3.0;
	sizes[1]      = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(FWRLFlashEmitter)
{
   ejectionPeriodMS = 2; //10
   periodVarianceMS = 0;
   ejectionVelocity = 40.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "FWRLFlashParticle";

   uiName = "FWRL Flash";
};

datablock ParticleData(FWRLSmokeParticle)
{
	dragCoefficient      = 15;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 250;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "1 0.4 0.1 0.0";
	colors[1]     = "1 0.7 0.3 0.9";
	colors[2]     = "1 0.7 0.3 0.9";
	colors[3]     = "1 1 1 0.0";

	sizes[0]      = 0.75; //0.25
   sizes[1]      = 1.0;  //1.0
	sizes[2]      = 2; //1.75
	sizes[3]      = 4;

   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 0.75;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(FWRLSmokeEmitter)
{
   ejectionPeriodMS = 10; //50
   periodVarianceMS = 0;
   ejectionVelocity = -70.0;
   velocityVariance = 10.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0; //25
   phiReferenceVel  = 0;
   phiVariance      = 1;
   overrideAdvance = false;
   particles = "FWRLSmokeParticle";

   uiName = "FWRL Smoke";
};


datablock ParticleData(LaserParticle)
{
	textureName          = "base/data/particles/dot";
	dragCoefficient      = 10;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 0;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1.0 0.0 0.0 0.8";
	colors[1]	= "1.0 0.0 0.0 1.0";
	colors[2]	= "1.0 0.15 0.15 0.0";

	sizes[0]	= 0.25;
	sizes[1]	= 0.2;
	sizes[2]	= 0;

	times[0]	= 0;
	times[1]	= 0.2;
    times[2]	= 1.0;
};
datablock ParticleEmitterData(LaserEmitter)
{
	//lifeTimeMS = 25;

   ejectionPeriodMS = 2; //3
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0; //89
   thetaMax         = 90; //90

   overrideAdvance = false;
   particles = "LaserParticle";

   useEmitterColors = true;
   uiName = "Laser Guide Hit";
};

datablock ExplosionData(LaserExplosion)
{
   //explosionShape = "";
   //soundProfile = bulletHitSound;

   lifeTimeMS = 100; //150

   particleEmitter = LaserEmitter;
   particleDensity = 5;
   particleRadius = 0;

   emitter[0] = LaserEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 0;
   lightStartColor = "1 0 0";
   lightEndColor = "1 0 0";
};

datablock ParticleData(StrikeLauncherTrailParticle)
{
	dragCoefficient      = 1.5; //3
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 1500;
	lifetimeVarianceMS   = 800;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 100.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "0.86 0.46 0.1 0.9";
	colors[1]     = "0.51 0.09 0 0.7";
	colors[2]     = "0.5 0.5 0.5 0.2";
	colors[3]     = "0.1 0.1 0.1 0.1";
	
	sizes[0]      = 0.8;
	sizes[1]      = 0.3;
	sizes[2]      = 0.3;
    sizes[3]      = 1.25;
    
	times[0]      = 0.0;
    times[1]      = 0.05;
    times[2]      = 0.1;
	times[3]      = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(StrikeLauncherTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180; //90
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "StrikeLauncherTrailParticle";

   uiName = "StrikeLauncher Trail";
};

datablock ParticleData(StrikeLauncherSparkParticle)
{
	dragCoefficient      = 4; //3
	gravityCoefficient   = 1;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 3000;
	lifetimeVarianceMS   = 1500;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 100.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1 1 0.86 0.9";
	colors[1]     = "0.78 0.34 0.04 0.7";
    colors[2]     = "0.1 0.1 0.1 0.0";
	
	sizes[0]      = 0.2;
	sizes[1]      = 0.2;
	sizes[2]      = 0.2;
    
	times[0]      = 0.0;
	times[1]      = 0.5;
    times[2]      = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(StrikeLauncherSparkEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 1;
   ejectionVelocity = 75;
   velocityVariance = 20.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180; //90
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "StrikeLauncherSparkParticle";

   uiName = "StrikeLauncher Sparks";
};

datablock ParticleData(StrikeLauncherExplosionParticle)
{
	dragCoefficient      = 7;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 3000;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.2 0.2 0.2 0.6";
	colors[1]     = "0.1 0.1 0.1 0.0";
	sizes[0]      = 10.0;
	sizes[1]      = 25.0;
    times[0]      = 0.0;
    times[1]      = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(StrikeLauncherExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 15;
   velocityVariance = 1.0;
   ejectionOffset   = 3.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "StrikeLauncherExplosionParticle";

   uiName = "StrikeLauncher Explosion Smoke";
   emitterNode = TenthEmitterNode;
};


datablock ParticleData(StrikeLauncherExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 10;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 70.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 0.91 0.59 0.9";
	colors[1]     = "0.7 0.25 0.02 0.9";
	sizes[0]      = 3;
	sizes[1]      = 30;
	times[1]      = 0.0;
	times[2]      = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(StrikeLauncherExplosionRingEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 10.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "StrikeLauncherExplosionRingParticle";

   uiName = "StrikeLauncher Explosion Flash";
};

datablock ExplosionData(StrikeLauncherExplosion)
{
   //explosionShape = "";
   explosionShape = "./explosionSphere1.dts";
	soundProfile = StrikeLauncherExplosionSound;

   lifeTimeMS = 150;

   particleEmitter = StrikeLauncherExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = StrikeLauncherExplosionRingEmitter;
   emitter[1] = StrikeLauncherSparkEmitter;

   faceViewer     = true;
   explosionScale = "2 2 2";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 20;
   lightEndRadius = 5;
   lightStartColor = "1 0.9 0 1";
   lightEndColor = "1 0.3 0.1 0";

   damageRadius = 3.5;
   radiusDamage = 195; //2000

   impulseRadius = 3;
   impulseForce = 2750;
};

datablock ProjectileData(NULLProjectile)
{
//   projectileShapeName = "./bullet.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::gun;
   radiusDamageType    = $DamageType::gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 0;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 0;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 1;
   lightColor  = "1 0 0";
};

datablock ProjectileData(LaserGuideProjectile)
{
   projectileShapeName = "./bullet.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::gun;
   radiusDamageType    = $DamageType::gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = LaserExplosion;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 1;
   lightColor  = "1 0 0";
};

AddDamageType("StrikeLauncherDirect",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_StrikeLauncher> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_StrikeLauncher> %1',1,1);
AddDamageType("StrikeLauncherRadius",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_StrikeLauncherRadius> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_StrikeLauncherRadius> %1',1,0);
datablock ProjectileData(StrikeRocketProjectile)
{
     projectileShapeName = "./StrikeLauncherRocket.dts";
   directDamage        = 30;
   directDamageType = $DamageType::StrikeLauncherDirect;
   radiusDamageType = $DamageType::StrikeLauncherRadius;
   impactImpulse	   = 4000;
   verticalImpulse	   = 4000;
   explosion           = StrikeLauncherExplosion;
   particleEmitter     = StrikeLauncherTrailEmitter;

   brickExplosionRadius = 2;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = StrikeLauncherRocketLoopSound;

   muzzleVelocity      = 150;
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 10000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod          = 0.005;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "StrikeLauncher Rocket";
};

//////////
// item //
//////////
datablock ItemData(StrikeLauncherItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./StrikeLauncher.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Strike Launcher";
	iconName = "./icon_StrikeLauncher";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = StrikeLauncherImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(StrikeLauncherImage)
{
   // Basic Item properties
   shapeFile = "./StrikeLauncher.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = StrikeLauncherItem;
   ammo = " ";
   projectile = LaserguideProjectile;
   projectileType = Projectile;

     //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = StrikeLauncherItem.colorShiftColor;
   
     raycastWeaponRange = 200; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = LaserGuideProjectile;
 // raycastExplosionBrickSound = bulletHitSound;
 // raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 0;
   raycastDirectDamageType = $DamageType::Laserguide;
   raycastSpreadAmt = 0; //varies
   raycastSpreadCount = 1;
  raycastTracerProjectile = StrikeRocketProjectile; //StrikeRocketProjectile / NULLProjectile
   raycastFromMuzzle = true;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateScript[0]                  = "onActivate";
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "LoadcheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTimeout[1]     = "Lasercycle";
	stateAllowImageChange[1]        = true;
	stateTimeoutValue[1]             = 1;
	stateScript[1]                  = "onReady";

	stateName[2]                    = "LaserFire";
	stateTransitionOnTimeout[2]     = "Lasercycle";
	stateTimeoutValue[2]            = 0.001;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onLaserFire";
	stateWaitForTimeout[2]		= true;
	stateSequence[2]        = "LaserShift";

    stateName[3]                  = "LaserCycle";
	stateTimeoutValue[3]          = 0;  //0.001
	stateSequence[3]              = "Lasershift";
	stateTransitiononTimeout[3]   = "LaserFire";
	stateTransitiononTriggerDown[3]  = "Fire";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "ReloadWait";
	
	stateName[6]				= "ReloadWait";
	stateTimeoutValue[6]			= 0.25;
	stateScript[6]				= "onReloadWait";
	stateTransitionOnTimeout[6]		= "ReloadStart";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "ReloadStart";
	stateTimeoutValue[7]			= 2;
	stateScript[7]				= "onReloadStart";
	stateTransitionOnTimeout[7]		= "Reloaded";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "Reloaded";
	stateTimeoutValue[8]			= 0.3;
	stateScript[8]				= "onReloaded";
    stateTransitionOnTimeout[8]  = "loadcheckA";

	stateName[9]                    = "Fire";
	stateTransitionOnTimeout[9]     = "Smoke";
	stateTimeoutValue[9]            = 0.025;
	stateFire[9]                    = true;
	stateAllowImageChange[9]        = false;
	stateScript[9]                  = "onFire";
	stateWaitForTimeout[9]		= true;
	stateSequence[9]         = "RocketShift";
	stateEmitter[9]			= FWRLFlashEmitter;
	stateEmitterTime[9]		= 0.05;
	stateEmitterNode[9]		= "muzzleNode";
	stateSound[9]			= StrikeLauncherFireSound;

	stateName[10] 			= "Smoke";
	stateEmitter[10]			= FWRLSmokeEmitter;
	stateEmitterTime[10]		= 0.05;
	stateEmitterNode[10]		= "ExtensionNode";
	stateTransitionOnTriggerUp[10] = "Wait";

	stateName[11]			= "Wait";
    stateTimeoutValue[11]		= 0.2;
	stateTransitionOnTimeout[11]	= "FireLoadCheckA";

    stateName[13]				= "FireLoadCheckA";
	stateScript[13]				= "onLoadCheck";
	stateTimeoutValue[13]			= 0.001; //0.01
	stateTransitionOnTimeout[13]		= "FireLoadCheckB";

	stateName[14]				    = "FireLoadCheckB";
	stateTransitionOnAmmo[14]		= "Ready";
	stateTransitionOnNoAmmo[14]		= "ReloadSmoke";
	
    stateName[15] 				= "ReloadSmoke";
	stateEmitter[15]			= gunSmokeEmitter;
	stateEmitterTime[15]			= 0.3;
	stateEmitterNode[15]			= "muzzleNode";
	stateTimeoutValue[15]			= 0.2;
	stateTransitionOnTimeout[15]		= "ReloadStart";

};

function StrikeLauncherImage::onActivate(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
}

function StrikeLauncherImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
	%obj.playThread(2, Plant);
	serverPlay3D(block_plantbrick_Sound,%obj.getPosition());
	
}

function StrikeLauncherImage::onLaserFire(%this,%obj,%slot)
{
		%this.raycastSpreadAmt = 0;
		%this.raycastWeaponRange = 200;
	    %this.raycastTracerProjectile = NULLProjectile;
	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
}

function StrikeLauncherImage::onReloadWait(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 

}

function StrikeLauncherImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["StrikeRocket"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function StrikeLauncherImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["StrikeRocket"] >= %this.item.maxAmmo)
	{

	%obj.playThread(2, plant);
        if(%obj.client.quantity["StrikeRocket"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["StrikeRocket"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["StrikeRocket"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["StrikeRocket"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
            serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.client.quantity["StrikeRocket"] = 0;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
		return;
	}
}
}

function StrikeLauncherImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;

		%this.raycastSpreadAmt = 0.0001;
		%this.raycastWeaponRange = 200;
		%this.raycastTracerProjectile = StrikeRocketProjectile;

	
	if(%obj.toolAmmo[%obj.currTool] > 0)
	{
		Parent::onFire(%this,%obj,%slot);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
		%obj.toolAmmo[%obj.currTool]--;
		%obj.AmmoSpent[%obj.currTool]++;
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Strike Rockets <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["StrikeRocket"] @ "", 1, 2, 3, 4); 
	}
	}
	else if(%this.item.maxAmmo == 0)
	{
		Parent::onFire(%this,%obj,%slot);
	}
	
	
	%obj.playThread(2, jump);	//shiftaway
}

//statescript onBounce