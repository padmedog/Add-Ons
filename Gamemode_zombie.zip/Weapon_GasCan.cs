datablock ItemData(GasCanItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./GasCan.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "GasCan";
	iconName = "add-ons/gamemode_zombie/Icons/Icon_GasCan";
	doColorShift = false;
		//colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = GasCanImage;
	canDrop = true;
};
function GasCanItem::onPickup(%this, %obj, %player)
{  
	ItemData::onPickup(%this, %obj, %player);
	for(%i=0;%i<5;%i++)
	{
		%toolDB = %player.tool[%i];
		if(%toolDB $= %this.getID())
		{
			servercmdUseTool(%player.client,%i);
			break;
		}
	}
}

datablock ShapeBaseImageData(GasCanImage)
{
   shapeFile = "./GasCan.dts";
   emap = true;

   mountPoint = 0;
   offset = "-0.53 0.05 -0.7";
   rotation = "0 0 1 90";

   correctMuzzleVector = true;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = GasCanItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

   melee = false;
   armReady = true;

   doColorShift = false;
   //colorShiftColor = "0.471 0.471 0.471 1.000";

	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]	= true;

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.5;
	stateFire[5]			= true;
	stateSequence[5]		= "fire";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;
	//stateSound[5]				= GasCanFireSound;
};

function GasCanImage::onFire(%this, %obj, %slot)
{
	if(%obj.client.minigame == 0 || %obj.client.minigame == -1)
	{
		return;
	}
	%obj.playThread(2, shiftdown);
	for(%i=0;%i<5;%i++)
	{
		%toolDB = %obj.tool[%i];
		if(%toolDB $= %this.item.getID())
		{
			%obj.tool[%i] = 0;
			%obj.weaponCount--;
			messageClient(%obj.client,'MsgItemPickup','',%i,0);
			serverCmdUnUseTool(%obj.client);
			break;
		}
	}
	%obj.sourcerotation = %obj.gettransform();

	%item = new WheeledVehicle(GasCan) 
	{  
		rotation = getwords(%obj.sourcerotation,3,6);
		datablock  = GasCanCol;
		creator = %obj.client.player;
	};
	%item.schedule(60000,delete);
	%item.startfade(5000,55000,1);
	%item.sourceobject = %obj;
	%second= getwords(%obj.gettransform(),3,6);
	%item.settransform(vectoradd(getwords(vectoradd(%obj.gettransform(),%obj.getforwardvector()),0,2),"0 0 1") SPC %second);
	%item.setvelocity(Vectoradd(vectorscale(%obj.getforwardvector(),2),%obj.getvelocity()));
}
datablock WheeledVehicleData(GasCanCol : PropaneTankCol)
{
	category = "Vehicles";
	displayName = "";
	shapeFile = "./GasCanCol.dts";
	emap = true;
	minMountDist = 0;
	numMountPoints = 0;
};
function GasCanCol::onAdd(%this,%obj)
{


}
function GasCanImage::onMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
		%obj.playThread(2, armreadyboth);
}

function GasCanImage::onUnMount(%this,%obj,%slot)
{
	Parent::onUnMount(%this,%obj,%slot);	
	%obj.playThread(2, root);
	for(%i=0;%i<5;%i++)
	{
		%toolDB = %obj.tool[%i];
		if(%toolDB $= %this.item.getID())
		{
			servercmdDropTool(%obj.client,%i);
			break;
		}
	}
}


datablock DebrisData(GasCanDebris)
{
   emitters = "JeepDebrisTrailEmitter";

	shapeFile = "./GasCan.dts";
	lifetime = 3.0;
	minSpinSpeed = -500.0;
	maxSpinSpeed = 500.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};



datablock ExplosionData(GasCanFinalExplosion : vehicleFinalExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   debris = GasCanDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 20;
   debrisVelocity = 18;
   debrisVelocityVariance = 3;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 10;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 1000;
   damageRadius        = 10.0;

   //burn the players?
   playerBurnTime = 4000;

};

datablock ProjectileData(GasCanFinalExplosionProjectile : vehicleFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = GasCanFinalExplosion;

   directDamageType  = $DamageType::GasCanExplosion;
   radiusDamageType  = $DamageType::GasCanExplosion;

    brickExplosionRadius = 8;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};

datablock ParticleData(GasCanFireParticle)
{
	textureName          = "base/data/particles/cloud";
	dragCoefficient      = 0.0;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.0;
	windCoefficient      = 0;
	constantAcceleration = 3.0;
	lifetimeMS           = 1200;
	lifetimeVarianceMS   = 100;
	spinSpeed     = 0;
	spinRandomMin = -90.0;
	spinRandomMax =  90.0;
	useInvAlpha   = false;

	colors[0]	= "1   1   0.3 0.0";
	colors[1]	= "1   1   0.3 1.0";
	colors[2]	= "0.6 0.0 0.0 0.0";

	sizes[0]	= 0.0;
	sizes[1]	= 2.0;
	sizes[2]	= 1.0;

	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(GasCanFireEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 4;
   ejectionVelocity = 0;
   ejectionOffset   = 1.00;
   velocityVariance = 0.0;
   thetaMin         = 30;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   //lifetimeMS = 5000;
   particles = GasCanFireParticle;   
};

datablock ShapeBaseImageData(GasCanBurnImage)
{
   	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 7;
	offset = "0 0 0";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]			= "FireA";
	stateTimeoutValue[0]				= 0.01;

	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]			= "Done";
	stateWaitForTimeout[1]				= True;
	stateTimeoutValue[1]				= 0.9;
	stateEmitter[1]					= GasCanFireEmitter;
	stateEmitterTime[1]				= 0.9;

	stateName[2]					= "Done";
	stateTransitionOnTimeout[2]			= "FireA";
	stateTimeoutValue[2]				= 0.01;
};

function Player::setonfire(%col)
{
	%col.schedule(8000,"stopBurn");
	%col.mountimage(GasCanBurnImage,2);
	%col.schedule(8000,unmountimage,2);
	//%col.schedule(1000,"emote",playerBurnImage);
	%col.schedule(500,"setTempColor","0 0 0 1",8500);
	//%col.schedule(5000,"burn");
}