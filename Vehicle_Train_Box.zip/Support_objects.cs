package TrainBoxObjectHandling
{

    function blowHorn(%obj)
    {
	%obj.hornApplied = 1;
	%obj.playAudio(2, hornBegin);
	toggleBellOn(%obj);
	%obj.sch = %obj.schedule(85,"playAudio", 2, hornMiddle);
    }

    function stopHorn(%obj)
    {
	cancel(%obj.sch);
	%obj.hornApplied = 0;
	%obj.playAudio(2, hornEnd);
    }


    function toggleBellOn(%obj)
    {
	%obj.bellIsOn = 1;
	%obj.playAudio(3, bell);
    }

    function toggleBellOff(%obj)
    {
	%obj.bellIsOn = 0;
	%obj.stopAudio(3);
    }

    function serverCmdboxtrainadmin(%client, %onOFF)
    {
	if(!%client.isAdmin || %client.isSuperAdmin)
	    return;

	else if(%onOFF $= "off")
	{
	    $BoxTrainVehicle_AdminOnly = 0;
	    messageAll('', "\c3"@ %client.getPlayerName() @"\c6 has turned \c3off\c6 admin only spawning of the box train.", 5);
	}

	else if(%onOFF $= "on")
	{
	    $BoxTrainVehicle_AdminOnly = 1;
	    messageAll('', "\c3"@ %client.getPlayerName() @"\c6 has turned \c3on\c6 admin only spawning of the box train.", 5);
	}

	else
	{
	    messageClient(%client, '', "You must use on/off as a parameter.");
	}
    }



    function fxDTSBrick::spawnVehicle(%brick)
    {
	%client = findclientbybl_id(%brick.stackBL_ID);
	%BoxTrainDBID = BoxTrain.getId();

	if(!$BoxTrainVehicle_AdminOnly || %client.isAdmin || %brick.vehicleDataBlock != %BoxTrainDBID)
	    parent::spawnVehicle(%brick);

	else
	    commandToClient(%client, 'centerPrint', "Spawning this vehicle is currently <color:FFFFFF>admin only.", 3);
    }


    function armor::onTrigger(%this, %obj, %triggerNum, %triggerVal)
    {

	//%mount	obj of our vehicle
	//%obj		obj of our player
	//%obj.client	client of the player

	%DataBlockName = BoxTrain.getId();
	%mount = %obj.getObjectMount();

	if(isObject(%mount))
	{
	    if(%mount.getDataBlock() == %DataBlockName && %triggerNum == 0 && !%mount.getControllingClient().canLeaveTrain)
	    {
		%client = %obj.client;
		if(isObject(%client) && !%client.player.getMountedImage(0))
		{

		    //Former bug: anyone in vehicle could hit horn
		    if(%mount.getControllingClient() != %obj.client)
			return;

		    if(getSimTime() - %mount.lastHornEndBlow < 430)
			return;

		    if(%triggerVal == 1)
		    {
			%mount.lastHornStartBlow = getSimTime();
		        blowHorn(%mount);
		    }

		    else if(%triggerVal == 0)
		    {			    
		        %mount.lastHornEndBlow = getSimTime();
			stopHorn(%mount);
		    }
		    return;
		}
	    }
	}
      
	Parent::onTrigger(%this,%obj,%triggerNum, %triggerVal);
    }


    function armor::onUnMount(%this, %obj, %mountedObj, %node)
    {
	%mount = %mountedObj;
	if(%mount.hornApplied == 1)
	{
	    %mount.lastHornEndBlow = getSimTime();
	    stopHorn(%mount);
	}

    	Parent::onUnMount(%this, %obj, %mountedObj, %node);
    }


    function servercmdtogglebell(%client)
    {
	%DataBlockName = BoxTrain.getId();
	%mount = %client.getcontrolobject().getObjectMount();
	if(isObject(%mount))
	{
	    if(%mount.getDataBlock() == %DataBlockName)
	    {
		if(isObject(%client) && !%client.player.getMountedImage(0))
		{

		    if(%mount.getControllingClient() != %client)
			return;

		    if(%mount.bellIsOn == 1)
		        toggleBellOff(%mount);

		    else
			toggleBellOn(%mount);

		    return;
		}
	    }
	}
      
	Parent::servercmdtogglebell(%client);
	//We want to parent it in case the player is not on the box train, and some other train vehicle exists
    }

    function serverCmdReverseTrain(%client)
    {
	%player = %client.player;
	%mount = %player.getObjectMount();
	// I combined some of the ifs and removed some unnecessary checks (%client should always exist and checking if %client is holding something is unnecessary)
	if(isObject(%mount) && %mount.getDataBlock() == BoxTrain.getId())
	{   echo("it's an object and it's the boxtrain");
	    if(%mount.getControllingClient() == %client)
	    {   echo("transing...");
		%trans = %mount.getTransform();
		%mount.setTransform(getWords(%trans, 0, 2) SPC -getWord(%trans, 3) SPC -getWord(%trans, 4) SPC -getWord(%trans, 5) SPC getWord(%trans, 6));
	    }
	    return;
	}
		// Other trains...
    }

    function serverCmdAlignTrain(%client, %dir)
    {
	%player = %client.player;
	%mount = %player.getObjectMount();
	if(isObject(%mount) && %mount.getDataBlock() == BoxTrain.getId())
	{
	    if(%mount.getControllingClient() == %client)
	    {
		if(%dir $= "n" || %dir $= "north")
		    %mount.setTransform(%mount.getPosition() SPC "1 0 0 0");

		else if(%dir $= "e" || %dir $= "east")
		    %mount.setTransform(%mount.getPosition() SPC "0 0 1" SPC $piover2); // "0 0 1 90"

		else if(%dir $= "w" || %dir $= "west")
		    %mount.setTransform(%mount.getPosition() SPC "0 0 -1" SPC $piover2);

		else if(%dir $= "s" || %dir $= "south")
		    %mount.setTransform(%mount.getPosition() SPC "0 0 1" SPC $pi);

		else
		    messageClient(%client, '', "You must use a direction. Example: \c6West \c3or \c6W");
	    }
	    return;
	}
    }

};

activatepackage(TrainBoxObjectHandling);