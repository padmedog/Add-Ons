if(isObject(NewPlayerListGui)) {
	NewPlayerListGui.delete();
}

exec("./NewPlayerListGui.gui");

package MutePackage {
	function GameConnection::onConnectionAccepted(%this) {
		Parent::onConnectionAccepted(%this);

		new ScriptObject(MuteList);

		for(%i = 0; %i < getWordCount($Pref::Chat::IgnoreList); %i++) {
			%bl_id = getWord($Pref::Chat::IgnoreList, %i);

			MuteList.bl_ids = (!%i ? %bl_id : MuteList.bl_ids SPC %bl_id);
			MuteList.entry[%bl_id] = 2;
		}
	}

	function NewPlayerListGui::clickList(%this) {
		Parent::clickList(%this);

		%bl_id = getField(NPL_List.getRowTextById(NPL_List.getSelectedId()), 3);

		NewPlayerListGui.bl_id = %bl_id;

		if(%bl_id $= getNumKeyId() || $Server::LAN) {
			NPL_IgnoreButton.setVisible(0);
			NPL_MuteBlocker.setVisible(1);
			NPL_UnMuteBlocker.setVisible(1);
		} else if(MuteList.entry[%bl_id] == 2) {
			NPL_IgnoreButton.setVisible(1);
			NPL_MuteBlocker.setVisible(1);
			NPL_UnMuteBlocker.setVisible(0);
		} else if(MuteList.entry[%bl_id] == 1) {
			NPL_IgnoreButton.setVisible(1);
			NPL_MuteBlocker.setVisible(0);
			NPL_UnMuteBlocker.setVisible(0);
		} else {
			NPL_IgnoreButton.setVisible(0);
			NPL_MuteBlocker.setVisible(0);
			NPL_UnMuteBlocker.setVisible(1);
		}
	}

	function clientCmdChatMessage(%client, %callback, %string, %tagged, %prefix, %name, %suffix, %message) {
		%entry = MuteList.entry[getField(NPL_List.getRowTextById(%client), 3)];

		if(%entry != 1 && %entry != 2) {
			Parent::clientCmdChatMessage(%client, %callback, %string, %tagged, %prefix, %name, %suffix, %message);
		}
	}

	function disconnectedCleanup(%bool) {
		parent::disconnectedCleanup(%bool);

		%bl_ids = MuteList.bl_ids;
		%count = 0;

		for(%i = 0; %i < getWordCount(%bl_ids); %i++) {
			%bl_id = getWord(%bl_ids, %i);

			if(MuteList.entry[%bl_id] == 2) {
				$Pref::Chat::IgnoreList = (!%count ? %bl_id : $Pref::Chat::IgnoreList SPC %bl_id);
				%count = 1;
			}
		}

		MuteList.delete();
	}
};

activatePackage(MutePackage);

function NewPlayerListGui::ClickIgnore(%this) {
	NPL_IgnoreButton.setVisible(1);
	NPL_MuteBlocker.setVisible(1);

	MuteList.entry[NewPlayerListGui.bl_id] = 2;
}

function NewPlayerListGui::ClickMute(%this) {
	NPL_IgnoreButton.setVisible(1);
	NPL_UnMuteBlocker.setVisible(0);

	%bl_id = NewPlayerListGui.bl_id;
	%entry = MuteList.entry[%bl_id];

	if(%entry $= "") {
		MuteList.bl_ids = (MuteList.bl_ids $= "" ? %bl_id : MuteList.bl_ids SPC %bl_id);
	}

	MuteList.entry[%bl_id] = 1;
}

function NewPlayerListGui::ClickUnMute(%this) {
	NPL_IgnoreButton.setVisible(0);
	NPL_MuteBlocker.setVisible(0);
	NPL_UnMuteBlocker.setVisible(1);

	MuteList.entry[NewPlayerListGui.bl_id] = 0;
}
