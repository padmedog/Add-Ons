//a new player datablock with faster, counterstrike-like movement

datablock PlayerData(PlayerFastDMArmor : PlayerStandardArmor)
{
   runForce = 100 * 80;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 10;
   maxBackwardSpeed = 10;
   maxSideSpeed = 10;

   maxForwardCrouchSpeed = 4;
   maxBackwardCrouchSpeed = 4;
   maxSideCrouchSpeed = 4;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Valve-Like Player";
	showEnergyBar = false;
};