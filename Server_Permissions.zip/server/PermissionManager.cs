$Permissions::Config::PathBase = "config/server/permissions/";
$Permissions::Config::Roles::PathBase = $Permissions::Config::PathBase @ "roles/";
$Permissions::Config::Players::PathBase = $Permissions::Config::PathBase @ "players/";
$Permissions::ValidRoleNameChars = "abcdefghijklmnopqrstuvwxyz1234567890_-";
$Permissions::ValidPermNameChars = "abcdefghijklmnopqrstuvwxyz1234567890.-";

function getPermissionManager() {
    if (!isObject(PermissionManager)) {
        new ScriptObject(PermissionManager) {
            knownClientCount = 0;
        };
    }
    return PermissionManager;
}

function PermissionManager::load(%this) {
    if (%this.isLoaded)
        return;
    %this.isLoaded = true;
    %this.knownClientCount = 0;
    %fo = new FileObject();
    %fo.openForRead($Permissions::Config::PathBase @ "userrolemappings.txt");
    while (!%fo.isEOF()) {
        %line = %fo.readLine();
        %sepPos = strPos(%line, "=");
        if (%sepPos == -1) {
            error("Malformed data for user<->role mapping file, culprit line:" SPC %line);
            continue;
        }
        %blid = getSubStr(%line, 0, %sepPos);
        %role = getSubStr(%line, %sepPos + 1, strLen(%line));
        %this.knownClient[PermissionManager.knownClientCount] = %blid;
        %this.knownClientCount++;
        %this.roleForBL_ID[%blid] = %this.getRole(%role);
    }

    %playerPattern = $Permissions::Config::Players::PathBase @ "*.txt";
    for (%file = findFirstFile(%playerPattern);%file !$= "";%file = findNextFile(%playerPattern)) {
        %blid = getSubStr(%file, strLen($Permissions::Config::Players::PathBase), strLen(%file));
        %blid = getSubStr(%blid, 0, strLen(%blid) - 4);

        %fo.openForRead(%file);

        while (!%fo.isEOF()) {
            %line = %fo.readLine();
            %sepPos = strPos(%line, "=");
            if (%sepPos == -1) {
                error("Malformed data for user<->directperm mapping file, culprit line:" SPC %line);
                continue;
            }
            %perm = getSubStr(%line, 0, %sepPos);
            %val = getSubStr(%line, %sepPos + 1, strLen(%line));
            %this.setDirectPermissionByBL_ID(%perm, %blid, %val);
        }
    }

    %fo.close();
    %fo.delete();

    %rolePattern = $Permissions::Config::Roles::PathBase @ "*.txt";
    for (%file = findFirstFile(%rolePattern);%file !$= "";%file = findNextFile(%rolePattern)) {
        %name = strReplace(%file, $Permissions::Config::Roles::PathBase, "");
        %name = strReplace(%name, ".txt", "");
        %this.getRole(%name); //Again, setting %this.role* variables for PermGui
        
    }
}

// Returns the same troolean as PermissionRoleBase::hasPermission
function PermissionManager::hasDirectPermissionByBL_ID(%this, %permission, %blid) {
    %this.load();
    %perm = %this.getPermission(%permission);
    if (!isObject(%perm)) {
        error("Permission" SPC %permission SPC "does not exist.");
        return false;
    }

    %id = %this.hasDirectPermissionByBL_ID[%blid, %permission];
    if (%id $= "")
        return 0;

    return %this.directPermissionValue[%id] + 0;
}

function PermissionManager::setDirectPermissionByBL_ID(%this, %permission, %blid, %val) {
    %this.load();
    %perm = %this.getPermission(%permission);
    if (!isObject(%perm)) {
        error("Permission" SPC %permission SPC "does not exist.");
        return false;
    }

    if ((%id = %this.hasDirectPermissionByBL_ID[%blid, %permission]) $= "") {
        %id = %this.directPermissionCount + 0;
        %this.directPermissionCount++;
    }

    %this.directPermissionPerm[%id] = %permission;
    %this.directPermissionBL_ID[%id] = %blid;
    %this.directPermissionValue[%id] = %val;

    %this.hasDirectPermissionByBL_ID[%blid, %permission] = %id;
}

function PermissionManager::hasPermissionByBL_ID(%this, %permission, %blid) {
    %this.load();
    %perm = %this.getPermission(%permission);
    if (!isObject(%perm)) {
        error("Permission" SPC %permission SPC "does not exist.");
        return false;
    }

    if ((%direct = %this.hasDirectPermissionByBL_ID(%permission, %blid)) != 0) {
        return %direct > 0;
    }

    %accepted = %this.getRoleByClientBL_ID(%blid).hasPermission(%permission);
    return %accepted > 0 || (%accepted == 0 && ((3 >= %perm.defaultAdminLevel && %blid == getNumKeyID()) || 0 >= %perm.defaultAdminLevel));
}

function PermissionManager::getRoleByClientBL_ID(%this, %blid) {
    %this.load();
    %ret = isObject(%this.roleForBL_ID[%blid]) ? %this.roleForBL_ID[%blid] : %this.getDefaultRole();

    if(%ret == %this.getDefaultRole() && !isObject(%this.roleForBL_ID[%blid]))
        %this.setRoleByClientBL_ID(%blid, %this.getDefaultRole());

    return %ret;
}

function PermissionManager::setRoleByClientBL_ID(%this, %blid, %role) {
    %this.load();
    %this.roleForBL_ID[%blid] = %role + 0; // Set the role for the blid, but force it to be an int
    %ind = -1;
    for (%i = 0;%i < %this.knownClientCount;%i++) {
        if (%this.knownClient[%i] == %blid) {
            %ind = %i;
            break;
        }
    }
    if (%ind == -1) {
        %ind = %this.knownClientCount;
        %this.knownClientCount++;
        %this.knownClient[%ind] = %blid;
    }
}

function PermissionManager::validateRoleName(%this, %name) {
    %nameLen = strLen(%name);
    if (%nameLen <= 0)
        return false;
    for (%i = 0;%i < %nameLen;%i++) {
        if (strIPos($Permissions::ValidRoleNameChars, getSubStr(%name, %i, 1)) == -1)
                return false;
    }
    return true;
}

function PermissionManager::validatePermName(%this, %name) {
    %nameLen = strLen(%name);
    if (%nameLen <= 0)
        return false;
    for (%i = 0;%i < %nameLen;%i++) {
        if (strIPos($Permissions::ValidPermNameChars, getSubStr(%name, %i, 1)) == -1)
                return false;
    }
    return true;
}


function PermissionManager::getRole(%this, %role) {
    %roleFilePath = $Permissions::Config::Roles::PathBase @ %role @ ".txt";
    if (%this.validateRoleName(%role) && %this.hasRole(%role)) {
        if (!isObject(%this.roleByName[%role])) {
            %roleData = new ScriptObject() {
                class = PermissionRoleBase;
                name = %role;
            };
            %this.roleByName[%role] = %roleData;
            %this.roleCount += 0;
            %this.role[%this.roleCount] = %roleData;
            %this.roleCount++;
            %fo = new FileObject();
            %fo.openForRead(%roleFilePath);
            %roleData.parent = %this.getRole(%fo.readLine());
            while (!%fo.isEOF()) {
                %line = %fo.readLine();
                %sepPos = strPos(%line, "=");
                if (%sepPos == -1) {
                    error("Malformed data file for role \"" @ %role @ "\", culprit line:" SPC %line);
                    continue;
                }
                %permName = getSubStr(%line, 0, %sepPos);
                %permVal = getSubStr(%line, %sepPos + 1, strLen(%line));
                %perm = %this.getPermission(%permName);
                if (!isObject(%perm)) {
                    error("Permission \"" @ %permName @ "\" not found, ignoring (" @ %role @ ").");
                    continue;
                }
                %roleData.setPermission(%permName, %permVal);
            }
            %fo.close();
            %fo.delete();
        }
        return %this.roleByName[%role];
    }
}

function PermissionManager::createRole(%this, %name) {
    if (!%this.validateRoleName(%name)) return;
    if (!%this.hasRole(%name)) {
        %fo = new FileObject();
        %fo.openForWrite($Permissions::Config::Roles::PathBase @ %name @ ".txt");
        %fo.close();
        %fo.delete();
        %roleSO = %this.getRole(%name); //Just for %this.role* variables to be set, for PermGui
        for(%i = 0; %i < ClientGroup.getCount(); %i++)
        {
            %c = ClientGroup.getObject(%i);
            if(%c.bl_id == getNumKeyId() || %c.hasPermission("permissions.modify"))
            {
                commandtoclient(%c, 'permgui', "ROLE", %name);
            }
        }

    }
    return %this.getRole(%name);
}

function PermissionManager::deleteRole(%this, %name) {
    if (%this.hasRole(%name)) {
        %this.getRole(%name).delete();
        fileDelete($Permissions::Config::Roles::PathBase @ %name @ ".txt");
        for(%i = 0; %i < ClientGroup.getCount(); %i++)
        {
            %c = ClientGroup.getObject(%i);
            if(%c.bl_id == getNumKeyId() || %c.hasPermission("permissions.modify"))
            {
                commandtoclient(%c, 'permgui', "REMROLE", %name);
            }
        }
    }
}

function PermissionManager::hasRole(%this, %name) {
    return isFile($Permissions::Config::Roles::PathBase @ %name @ ".txt");
}

function PermissionManager::getDefaultRole(%this) {
    return %this.createRole("Default");
}

function PermissionManager::getPermission(%this, %name) {
    %id = $Permissions::PermissionByName[%name];
    if (%id + 0 $= %id)
        return %this.getPermissionByID(%id);
}

function PermissionManager::getPermissionByID(%this, %id) {
    if ($Permissions::PermissionName[%id] $= "") return;
    if (!isObject(%this.permission[%id]))
        %this.permission[%id] = new ScriptObject() {
            name = $Permissions::PermissionName[%id];
            friendlyName = $Permissions::PermissionFriendlyName[%id];
            defaultAdminLevel = $Permissions::PermissionDefaultAdminLevel[%id];
        };
    return %this.permission[%id];
}

function PermissionManager::getNameCache(%this) {
    if (!isObject(%this.nameCache))
        %this.nameCache = new ScriptObject(PermissionNameCache);
    return %this.nameCache;
}

function PermissionManager::registerPermission(%this, %friendlyName, %name, %default) {
    if (%default $= "") {
        %default = %name;
        %name = %friendlyName;
        %friendlyName = "";
    }
    %default = mClamp(%default, 0, 4);
    if (%this.validatePermName(%name)) {
        %id = $Permissions::PermissionByName[%name];
        if (%id $= "") {
            %id = $Permissions::PermissionCount + 0;
            $Permissions::PermissionCount++;
            $Permissions::PermissionByName[%name] = %id;
        }
        $Permissions::PermissionFriendlyName[%id] = %friendlyName;
        $Permissions::PermissionName[%id] = %name;
        $Permissions::PermissionDefaultAdminLevel[%id] = %default;
        for(%i = 0; %i < ClientGroup.getCount(); %i++)
        {
            %c = ClientGroup.getObject(%i);
            if(%c.bl_id == getNumKeyId() || %c.hasPermission("permissions.modify"))
            {
                commandtoclient(%c, '', "PERM", %name);
            }
        }
    } else {
        error("Invalid permission name \"" @ %name @ "\".");
    }
}

function PermissionManager::saveDirectPerms(%this) {
    %fo = new FileObject();
    for (%i = 0;%i < %this.directPermissionCount;%i++) {
        %blid = %this.directPermissionBL_ID[%i];
        %permission = %this.directPermissionPerm[%i];
        %value = %this.directPermissionValue[%i];

        if (%hasSavedByBL_ID[%blid])
            %fo.openForAppend($Permissions::Config::Players::PathBase @ %blid @ ".txt");
        else
            %fo.openForWrite($Permissions::Config::Players::PathBase @ %blid @ ".txt");

        %fo.writeLine(%permission @ "=" @ %value);
        %fo.close();
    }
    %fo.delete();
}

function PermissionManager::doSave(%this) {
    cancel(%this.saveSched);
    %this.saveSched = 0;
    %this.load();
    %fo = new FileObject();
    %fo.openForWrite($Permissions::Config::PathBase @ "userrolemappings.txt");
    for (%i = 0;%i < %this.knownClientCount;%i++) {
        %fo.writeLine(%this.knownClient[%i] @ "=" @ %this.roleForBL_ID[%this.knownClient[%i]].name);
    }
    %fo.close();
    for (%i = 0;%i < %this.roleCount;%i++) {
        %role = %this.role[%i];
        if (!isObject(%role))
            continue;
        %fo.openForWrite($Permissions::Config::Roles::PathBase @ %role.name @ ".txt");
        %fo.writeLine(%role.parent.name);
        for (%j = 0;%j < $Permissions::PermissionCount;%j++) {
            %perm = %this.getPermissionByID(%j);
            if (%perm.name $= "")
                continue;
            %fo.writeLine(%perm.name @ "=" @ %role.hasPermission(%perm.name, false));
        }
        %fo.close();
    }
    %fo.delete();
    %this.saveDirectPerms();
    if (isObject(%this.nameCache))
        %this.nameCache.doSave();
    %this.saveSched = %this.schedule(60000, doSave);
}

package PermissionsSave {
    function onExit() {
        if (isObject(PermissionManager)) {
            PermissionManager.doSave();
            PermissionManager.delete();
        }
        parent::onExit();
    }

    function serverCmdChangeMap(%cl, %new) {
        if (isObject(PermissionManager)) { // No need to do auth since that's handled in DefaultRetrofits.cs
            PermissionManager.doSave();
            PermissionManager.delete();
        }
        return parent::serverCmdChangeMap(%cl, %new);
    }
}; activatePackage(PermissionsSave);
