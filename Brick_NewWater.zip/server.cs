
//////////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData (brick6xWaterRapidsData)
{
	brickFile = "./6xRapid.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "6x Rapids";
	iconName = "Add-Ons/Brick_NewWater/6xr";
   alwaysShowWireFrame = true;
};

datablock fxDTSBrickData (brickWaterFallData)
{
	brickFile = "./WaterFall.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "Waterfall";
	iconName = "Add-Ons/Brick_NewWater/WaterFall";
	alwaysShowWireFrame = true;
};

function brickWaterFallData::onLoadPlant(%data, %obj)
{
   brickWaterFallData::onPlant(%data, %obj);
}


function brickWaterFallData::onPlant(%data, %brick)
{
   %brick.setColliding(0);
   %brick.setRayCasting(0);
   %brick.setShapeFX(2);

   %brick.createWaterFallZone();  
}

function brickWaterFallData::onDeath(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWaterFallData::onRemove(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWaterFallData::onColorChange(%data, %brick)
{
   Parent::onColorChange(%data, %brick);
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.setWaterColor(%rgb SPC %a);
}

function brickWaterFallData::onFakeDeath(%data, %brick)
{
   Parent::onFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.deactivate();
}

function brickWaterFallData::onClearFakeDeath(%data, %brick)
{
   Parent::onClearFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

function brickWaterFallData::disappear(%data, %brick, %time)
{
   Parent::disappear(%data,%brick,%time);
   if(%time == 0)
   {
      //disappear(0) = instantly re-appear
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.activate();
      %brick.setColliding(0);
      %brick.setRayCasting(0);
   }
   else
   {
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.deactivate();
   }
}

function brickWaterFallData::reappear(%data, %brick)
{
   Parent::reappear(%data,%brick);

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}


///////////////////////////////////////////////////////////////////
// Waterfall Zone
///

function fxDTSBrick::createWaterFallZone(%brick)
{
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   %pz = new PhysicalZone()
   {
      isWater = true;
      waterViscosity = 40;
      waterDensity = -1;
      waterColor = %rgb SPC %a;
      polyhedron = "0 0 0 1 0 0 0 -1 0 0 0 1";
   };
   if(!isObject(%pz))
   {
      error("ERROR: Could not create physical zone for waterfall brick!");
      return;
   }
   missionCleanup.add(%pz);

   //set size
   %boxMin = getWords(%brick.getWorldBox(), 0, 2);
   %boxMax = getWords(%brick.getWorldBox(), 3, 5);
   %boxDiff = vectorSub(%boxMax, %boxMin);
   %boxDiff = vectorAdd(%boxDiff, "0 0 0.1"); 
   %pz.setScale(%boxDiff);
      
   //set position - this looks wierd because the the physical zone isn't positioned from it's center
   %posA = %brick.getWorldBoxCenter();
   %posB = %pz.getWorldBoxCenter();
   %posDiff = vectorSub(%posA, %posB);
   %posDiff = vectorSub(%posDiff, "0 0 0.1");
   %pz.setTransform(%posDiff);

   %brick.physicalZone = %pz;
}

//////////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData (brickWaterFallDeepData)
{
	brickFile = "./Waterfall_Deep.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "Waterfall Deep";
	iconName = "Add-Ons/Brick_NewWater/WaterFallD";
	alwaysShowWireFrame = true;
};

function brickWaterFallDeepData::onLoadPlant(%data, %obj)
{
   brickWaterFallDeepData::onPlant(%data, %obj);
}


function brickWaterFallDeepData::onPlant(%data, %brick)
{
   %brick.setColliding(0);
   %brick.setRayCasting(0);
   %brick.setShapeFX(2);

   %brick.createWaterFallZone();  
}

function brickWaterFallDeepData::onDeath(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWaterFallDeepData::onRemove(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWaterFallDeepData::onColorChange(%data, %brick)
{
   Parent::onColorChange(%data, %brick);
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.setWaterColor(%rgb SPC %a);
}

function brickWaterFallDeepData::onFakeDeath(%data, %brick)
{
   Parent::onFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.deactivate();
}

function brickWaterFallDeepData::onClearFakeDeath(%data, %brick)
{
   Parent::onClearFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

function brickWaterFallDeepData::disappear(%data, %brick, %time)
{
   Parent::disappear(%data,%brick,%time);
   if(%time == 0)
   {
      //disappear(0) = instantly re-appear
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.activate();
      %brick.setColliding(0);
      %brick.setRayCasting(0);
   }
   else
   {
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.deactivate();
   }
}

function brickWaterFallDeepData::reappear(%data, %brick)
{
   Parent::reappear(%data,%brick);

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

//////////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData (brickWater6xData)
{
	brickFile = "./6x.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "6x Water";
	iconName = "Add-Ons/Brick_NewWater/6x";
	alwaysShowWireFrame = true;
};

function brickWater6xData::onLoadPlant(%data, %obj)
{
   brickWater6xData::onPlant(%data, %obj);
}


function brickWater6xData::onPlant(%data, %brick)
{
   %brick.setColliding(0);
   %brick.setRayCasting(0);
   %brick.setShapeFX(2);

   %brick.createWaterZone(); 
}

function brickWater6xData::onDeath(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater6xData::onRemove(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater6xData::onColorChange(%data, %brick)
{
   Parent::onColorChange(%data, %brick);
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.setWaterColor(%rgb SPC %a);
}

function brickWater6xData::onFakeDeath(%data, %brick)
{
   Parent::onFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.deactivate();
}

function brickWater6xData::onClearFakeDeath(%data, %brick)
{
   Parent::onClearFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

function brickWater6xData::disappear(%data, %brick, %time)
{
   Parent::disappear(%data,%brick,%time);
   if(%time == 0)
   {
      //disappear(0) = instantly re-appear
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.activate();
      %brick.setColliding(0);
      %brick.setRayCasting(0);
   }
   else
   {
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.deactivate();
   }
}

function brickWater6xData::reappear(%data, %brick)
{
   Parent::reappear(%data,%brick);

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

//////////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData (brickWater12xData)
{
	brickFile = "./12x.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "12x Water";
	iconName = "Add-Ons/Brick_NewWater/12x";
	alwaysShowWireFrame = true;
};

function brickWater12xData::onLoadPlant(%data, %obj)
{
   brickWater12xData::onPlant(%data, %obj);
}


function brickWater12xData::onPlant(%data, %brick)
{
   %brick.setColliding(0);
   %brick.setRayCasting(0);
   %brick.setShapeFX(2);

   %brick.createWaterZone(); 
}

function brickWater12xData::onDeath(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater12xData::onRemove(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater12xData::onColorChange(%data, %brick)
{
   Parent::onColorChange(%data, %brick);
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.setWaterColor(%rgb SPC %a);
}

function brickWater12xData::onFakeDeath(%data, %brick)
{
   Parent::onFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.deactivate();
}

function brickWater12xData::onClearFakeDeath(%data, %brick)
{
   Parent::onClearFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

function brickWater12xData::disappear(%data, %brick, %time)
{
   Parent::disappear(%data,%brick,%time);
   if(%time == 0)
   {
      //disappear(0) = instantly re-appear
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.activate();
      %brick.setColliding(0);
      %brick.setRayCasting(0);
   }
   else
   {
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.deactivate();
   }
}

function brickWater12xData::reappear(%data, %brick)
{
   Parent::reappear(%data,%brick);

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

//////////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData (brickWater16x12Data)
{
	brickFile = "./16x12.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "16x12 Water";
	iconName = "Add-Ons/Brick_NewWater/16x12";
	alwaysShowWireFrame = true;
};

function brickWater16x12Data::onLoadPlant(%data, %obj)
{
   brickWater16x12Data::onPlant(%data, %obj);
}


function brickWater16x12Data::onPlant(%data, %brick)
{
   %brick.setColliding(0);
   %brick.setRayCasting(0);
   %brick.setShapeFX(2);

   %brick.createWaterZone(); 
}

function brickWater16x12Data::onDeath(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater16x12Data::onRemove(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater16x12Data::onColorChange(%data, %brick)
{
   Parent::onColorChange(%data, %brick);
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.setWaterColor(%rgb SPC %a);
}

function brickWater16x12Data::onFakeDeath(%data, %brick)
{
   Parent::onFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.deactivate();
}

function brickWater16x12Data::onClearFakeDeath(%data, %brick)
{
   Parent::onClearFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

function brickWater16x12Data::disappear(%data, %brick, %time)
{
   Parent::disappear(%data,%brick,%time);
   if(%time == 0)
   {
      //disappear(0) = instantly re-appear
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.activate();
      %brick.setColliding(0);
      %brick.setRayCasting(0);
   }
   else
   {
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.deactivate();
   }
}

function brickWater16x12Data::reappear(%data, %brick)
{
   Parent::reappear(%data,%brick);

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

//////////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData (brickWater64xData)
{
	brickFile = "./64x.blb";
	category = "Baseplates";
	subCategory = "Water";
	uiName = "64x Water";
	iconName = "Add-Ons/Brick_NewWater/64x";
	alwaysShowWireFrame = true;
};

function brickWater64xData::onLoadPlant(%data, %obj)
{
   brickWater64xData::onPlant(%data, %obj);
}


function brickWater64xData::onPlant(%data, %brick)
{
   %brick.setColliding(0);
   %brick.setRayCasting(0);
   %brick.setShapeFX(2);

   %brick.createWaterZone();  
}

function brickWater64xData::onDeath(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater64xData::onRemove(%data, %brick)
{
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.delete();
}

function brickWater64xData::onColorChange(%data, %brick)
{
   Parent::onColorChange(%data, %brick);
   %color = getColorIDTable(%brick.colorID);
   %rgb = getWords(%color, 0, 2);
   %a = getWord(%color, 3) / 0.5;

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.setWaterColor(%rgb SPC %a);
}

function brickWater64xData::onFakeDeath(%data, %brick)
{
   Parent::onFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.deactivate();
}

function brickWater64xData::onClearFakeDeath(%data, %brick)
{
   Parent::onClearFakeDeath(%data, %brick);
   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

function brickWater64xData::disappear(%data, %brick, %time)
{
   Parent::disappear(%data,%brick,%time);
   if(%time == 0)
   {
      //disappear(0) = instantly re-appear
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.activate();
      %brick.setColliding(0);
      %brick.setRayCasting(0);
   }
   else
   {
      if(isObject(%brick.physicalZone))
         %brick.physicalZone.deactivate();
   }
}

function brickWater64xData::reappear(%data, %brick)
{
   Parent::reappear(%data,%brick);

   if(isObject(%brick.physicalZone))
      %brick.physicalZone.activate();

   %brick.setColliding(0);
   %brick.setRayCasting(0);
}

///////////////////////////////////////////////////////////////////////////

function brick6xWaterRapidsData::onPlant(%data, %brick)
{
   brickWater6xData::onPlant(%data, %brick);
   %brick.physicalZone.setAppliedForce(vectorScale(%brick.getForwardVector(), 3000));
}

function brick6xWaterRapidsData::onDeath(%data, %brick)
{
   brickWater6xData::onDeath(%data, %brick);
}

function brick6xWaterRapidsData::onRemove(%data, %brick)
{
   brickWater6xData::onRemove(%data, %brick);
}

function brick6xWaterRapidsData::onColorChange(%data, %brick)
{
   brickWater6xData::onColorChange(%data, %brick);
}

function brick6xWaterRapidsData::onFakeDeath(%data, %brick)
{
   brickWater6xData::onFakeDeath(%data, %brick);
}

function brick6xWaterRapidsData::onClearFakeDeath(%data, %brick)
{
   brickWater6xData::onClearFakeDeath(%data, %brick);
}

function brick6xWaterRapidsData::disappear(%data, %brick, %time)
{
   brickWater6xData::disappear(%data, %brick, %time);
}

function brick6xWaterRapidsData::reappear(%data, %brick)
{
   brickWater6xData::reappear(%data, %brick);
}