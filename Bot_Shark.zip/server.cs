//Base Blockhead guy
if(LoadRequiredAddOn("Bot_Hole") == $Error::None)
{
	exec("./bot_base.cs");
	exec("./support.cs");
}