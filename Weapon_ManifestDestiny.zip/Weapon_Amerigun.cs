datablock ItemData(AmerigunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./HMGAmerigun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Manifest Destiny";
  	iconName = "./IMG/icon_Amerigun";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.7 1.000";

	 // Dynamic properties defined by the scripts
	image = AmerigunImage;
	canDrop = true;
};

datablock ShapeBaseImageData(AmerigunImage)
{
   // Basic Item properties
   shapeFile = "./HMGAmerigun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = AmerigunItem;
   ammo = " ";
   projectile = AmericanfireworkProjectile;
   projectileType = Projectile;

	casing = dollarstackDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = AmerigunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

	stateName[0]	= "Activate";
	stateSound[0]	= weaponSwitchSound;
	stateTimeoutValue[0]	= 0.3;
	stateTransitionOnTimeout[0]	= "Ready";

	stateName[1]	= "Ready";
	stateTransitionOnTriggerDown[1]	= "SpinUp";
	stateAllowImageChange[1]	= true;
  	stateSequence[1]		= "Root";

	stateName[2]	= "SpinUp";
	stateSound[2]	= SoundSpinOn;
	stateTimeoutValue[2]	= 0.3;
	stateWaitForTimeout[2]	= true;
	stateTransitionOnTimeout[2] = "Fire";

	stateName[3]	= "Fire";
	stateScript[3]	= "onFire";
	stateSound[3]	= MelodyFiring;
	stateTimeoutValue[3] = 0.06;
	stateWaitForTimeout[3]	= true;
	stateTransitionOnTimeout[3]	= "Fire";
	stateTransitionOnTriggerUp[3]	= "SpinDown";
 	stateSequence[3]	= "Fire";
	stateEjectShell[3]	= true;
	stateEmitter[3]	= amerigunMuzzleEmitter;
	stateEmitterNode[3]	= "muzzleNode";
	stateEmitterTime[3]	= 0.15;

	stateName[4]	= "SpinDown";
	stateScript[4]	= "onStop";
	statesequence[4]	= "Fire";
	stateTransitionOnTimeout[4]	= "Ready";
	stateWaitForTimeout[4]	= true;
	stateTimeoutValue[4]	= 0.3;
	stateEmitter[4]	= amerigunNutEmitter;
	stateEmitterTime[4]	= 0.1;
	stateEmitterNode[4]	= "muzzleNode";
	stateSound[4]	= SoundSpinOff;
};

function AmerigunImage::onFire(%this,%obj,%slot)
{
	serverPlay3D(SoundSpinning, %obj.getPosition());
	%obj.playthread(0, plant);
	%obj.schedule(95, playthread, 0, root);

	%spread = 0.1;
	%vector = %obj.getMuzzleVector(%slot);
	%vector = VectorScale(%vector, 130);
	%x = (getRandom() - 0.5) * %spread;
	%y = (getRandom() - 0.5) * %spread;
	%z = (getRandom() - 0.5) * %spread;
	%mat = MatrixCreateFromEuler(%x SPC %y SPC %z);
	%velocity = MatrixMulVector(%mat, %vector);
	%p = new projectile()
	{
		dataBlock = AmericanFireworkProjectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	missionCleanup.add(%p);
	return  %p;
}

function AmerigunImage::onStop(%this,%obj,%slot)
{
	%obj.schedule(100, playthread, 0, jump);
}