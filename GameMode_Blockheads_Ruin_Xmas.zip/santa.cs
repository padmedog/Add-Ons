datablock PlayerData(PlayerSanta : PlayerStandardArmor)
{
   maxForwardSpeed = 4.5;
   uiName = "";
};

datablock ShapeBaseImageData(SantaHatImage)
{
   shapeFile = "add-ons/Gamemode_Blockheads_Ruin_Xmas/santahat.dts";
   mountPoint = 5;
   offset = "0 0 0.15";
   eyeOffset = "0 -10 0";
   doColorShift = 1;
   colorShiftColor = "1 0.1 0.1 1";
};


function Santa_Spawn(%presentsLeft)
{
   if(isobject($santa))
      $santa.delete();

   $santa = new AIPlayer()
   {
      datablock = PlayerSanta;
      maxPitchSpeed = 40;
      maxYawSpeed = 40;
   };
   missionCleanup.add($santa);

   $santa.hidenode("ALL");
   $santa.unhidenode("headSkin");
   $santa.setnodecolor("headSkin", "0.9 0.75 0.6 1");
   $santa.unhidenode("lhand");
   $santa.setnodecolor("lhand", "0.9 0.75 0.6 1");
   $santa.unhidenode("rhand");
   $santa.setnodecolor("rhand", "0.9 0.75 0.6 1");
   $santa.unhidenode("chest");
   $santa.setnodecolor("chest", "1 0.1 0.1 1");
   // $santa.unhidenode("armor");
   // $santa.setnodecolor("armor", "1 0.1 0.1 1");
   $santa.unhidenode("larm");
   $santa.setnodecolor("larm", "1 0.1 0.1 1");
   $santa.unhidenode("rarm");
   $santa.setnodecolor("rarm", "1 0.1 0.1 1");
   $santa.unhidenode("pants");
   $santa.setnodecolor("pants", "0.9 0.9 0.9 1");
   $santa.unhidenode("lshoe");
   $santa.setnodecolor("lshoe", "0.1 0.1 0.1 1");
   $santa.unhidenode("rshoe");
   $santa.setnodecolor("rshoe", "0.1 0.1 0.1 1");
   $santa.setfacename("smileyEvil1");
   $santa.mountimage(santaHatImage, 2);
   $santa.setscale("1.2 1.1 1");

   while(%c++ < 100)
   {
      %tree = $xmastree[ getrandom(0, $xmastrees - 1) ];
      if(%tree.getname() !$= "_dontSpawn")
         break;
   }

   %c = 0;
   while(%c++ < 100)
   {
      %theta = getrandom() * 6.28318;
      %pos = vectoradd(%tree.getposition(), 2.3 * mcos(%theta) SPC 2.3 * msin(%theta) SPC 0);
      %test = 1;
      initcontainerboxsearch(%pos, "2 2 2", $typemasks::fxbrickobjecttype);
      while(%t = containersearchnext())
      {
         if(%t != %tree)
         {
            %test = 0;
            break;
         }
      }
      %pos2 = vectoradd(%pos, "0 0 100");
      if(containerraycast(%pos2, %pos, $typemasks::fxbrickobjecttype))
         %test = 0;
      if(%test)
         break;
   }

   $santa.settransform(%pos2 SPC "0 0 -1 1.2");
   $santa.ai = schedule(500, $santa, Santa_AI_Fall, %tree);
 
   if(%presentsLeft < 1)
      %presentsLeft = 20;
   $santa.presentsLeft = %presentsLeft;
   $santa.TimeOut = getSimTime() + 600000;
}


function Santa_AI_Fall(%tree)
{
   if(!isobject($santa)) 
      return;

   if(vectorlen($santa.getvelocity()) > 0)
   {
      $santa.ai = schedule(500, $santa, Santa_AI_Fall,%tree);
      return;
   }
   $santa.ai = schedule(500, $santa, Santa_AI_DropPresent, %tree);
}


function Santa_AI_DropPresent(%tree, %tick)
{
   if(!isobject($santa))
   {
      RuinXmas_RoundCountdown();
      return;
   }

   $santa.resumeAI = "Santa_AI_DropPresent";
   $santa.resumeAIParam = %tree;
   if(Santa_NaughtyCheck())
      return;
 
   if(!%tick)
   {
      if(isobject(%tree))
      {
         %eye = $santa.geteyetransform();
         $santa.clearaim();
         $santa.setaimlocation(vectoradd(%eye, vectornormalize(setword(vectorsub(%eye, %tree.getposition()), 2, 0))));
      }
   }
 
   %tick++;
   if(%tick == 6)
   {
      %pos = vectoradd($santa.getposition(), "0 0 0.5");
      for(%i = $presents - 1; %i > -1; %i--)
      {
         if(vectordist($present[%i].getposition(), %pos) < 8)
         {
            %fail = 1;
            break;
         }
      }

      if(!%fail)
      {
         %data = "presentItem" @ getrandom(0, $presentColors - 1);

         %pres = new Item()
         {
            datablock = %data;
            position = %pos;
            static = 1;
         };
         missionCleanup.add(%pres);

         $santa.presentsLeft--;
      }

      if($santa.presentsLeft < 1 || $santa.TimeOut < getSimTime())
      {
         $santa.clearaim();
         $santa.setmovey(3);
         $santa.ai = schedule(600, $santa, Santa_AI_GoAway);
         return;
      }
      $santa.ai = schedule(500, $santa, Santa_AI_FindTree);
      return;
   }
 
   $santa.ai = schedule(250, $santa, Santa_AI_DropPresent, %tree, %tick);
}


function Santa_AI_FindTree(%tree, %tick)
{
   if(!isobject($santa))
   {
      RuinXmas_RoundCountdown();
      return;
   }
 
   $santa.resumeAI = "Santa_AI_FindTree";
   $santa.resumeAIParam = %tree;
   if(Santa_NaughtyCheck())
      return;
   if(%tick % 4 == 3)
      $santa.naughtyTick = 0;
 
   if(!%tick)
   {
      $santa.stuck = "";
      $santa.lastPos = "";
      if(!isobject(%tree))
      {
         %eye = $santa.geteyetransform();
         %min = 999999;
         for(%i = $xmastrees - 1; %i > -1; %i--)
         {
            %t = $xmastree[%i];
            %pos = %t.getposition();
            %dist = vectordist(%eye, %pos);
            if(%dist > 40 || %dist < 6)
               continue;

            if(%dist < %min)
            {
               %min = %dist;
               %nearest = %t;
            }

            if(!Santa_LOS(%t))
               continue;

            %tree[%trees++ -1] = %t;
         }

         for(%i = %trees - 1; %i > -1; %i--)
            if($santa.treeVisits[%tree[%i]] > %max)
               %max = $santa.treeVisits[%tree[%i]];

         %max++;
         for(%i = %trees-1; %i > -1; %i--)
            %weight[%i] = %weight[%i+1] + (%max - $santa.treeVisits[%tree[%i]]);

         %r = getrandom(0, %weight0 - 1);

         for(%i = %trees - 1; %i > -1; %i--)
         {
            if(%weight[%i] > %r)
               break;
         }

         %tree=%tree[%i];
         $santa.treeVisits[%tree]++;
      }

      if(!isobject(%tree))
         %tree = %nearest;

      %pos = %tree.getposition();
      $santa.clearaim();
      $santa.setaimlocation(%pos);
      $santa.setmovedestination(%pos);  //$santa.setmovedestination(%pos,1);
   }
 
   if(isobject(%tree))
   {
      %dif = vectorlen(setword(vectorsub($santa.geteyetransform(), %tree.getposition()), 2, 0));
      if(%dif < 2.2)
      {
         if(mAbs(getword(%dif, 2)) < 2)
         {
            $santa.stop();
            $santa.ai = schedule(500, $santa, Santa_AI_DropPresent, %tree);
            return;
         }
      }

      //echo(%dif@" - "@$santa.lastDif@" = "@(%dif-$santa.lastDif));
      if($santa.lastDif - %dif < 0.5)
      {
         $santa.stuck++;
         if($santa.stuck > 9)
            Santa_AI_Teleport(%tree);
         else if($santa.stuck == 4)
            Santa_AI_JumpStrafe();
      }
      else
      {
         $santa.stuck = "";
         if($santa.strafing)
         {
            $santa.strafing = "";
            $santa.setmovex(0);
         }
      }
      $santa.lastDif = %dif;
   }

   $santa.ai = schedule(250, $santa, Santa_AI_FindTree, %tree, %tick + 1);
}


function Santa_AI_JumpStrafe()
{
   if(!isobject($santa))
      return;
   $santa.addvelocity("0 0 13");
   $santa.setmovex(3 * getrandom(0, 1) * 2 - 1);
   $santa.strafing = 1;
}


function Santa_AI_Teleport(%tree)
{
   if(!isobject($santa))
     return;
   if(!isobject(%tree))
      return;

   %pos = %tree.getposition();
   %pos = vectoradd(%pos, vectorscale(vectornormalize(setword(vectorsub($santa.getposition(), %pos), 2, 0)), 2.3));
   $santa.settransform(%pos);
   $santa.teleportEffect();
   $santa.stuck = "";
}


function Santa_AI_GoAway(%tick)
{
   if(!isobject($santa))
   {
      RuinXmas_RoundCountdown();
      return;
   }
   if(%tick > 12)
   {
      %pos = $santa.getposition();
      %p = new projectile()
      {
         datablock = vehicleFinalExplosionProjectile;
         initialPosition = %pos;
      };
      missionCleanup.add(%p);

      $santa.delete();
      return;
   }

   $santa.ai = schedule(600, $santa, Santa_AI_GoAway, %tick + 1);
 
   if(%tick > 0)
   {
      %v = $santa.getobjectmount();
      %v.setvelocity("0 0 " @ (16 + %tick));
      %v.setangularvelocity(vectorscale($santa.flip, 12 - 0.4 * %tick));
      return;
   }
 
   $santa.clearaim();
   $santa.stop();
   tumble($santa);

   %v = $santa.getobjectmount();
   $santa.flip = vectorcross($santa.getupvector(), $santa.getforwardvector());
   %v.setvelocity("0 0 16");
   %v.setangularvelocity(vectorscale($santa.flip, 12));

   RuinXmas_RoundCountdown();
}


function Santa_TargetNearest()
{
   if(!isobject($santa))
      return;

   %eye = $santa.geteyetransform();
   %min = 999999;

   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
   {
      if(!isobject(%p = clientgroup.getobject(%i).player))
         continue;

      %dist = vectordist(%p.geteyetransform(), %eye);
      if(%dist < %min)
      {
         if(Santa_LOS(%p, 1))
         {
            %min = %dist;
            %target = %p;
         }
      }
   }

   if(isobject(%target))
      $santa.naughty = %target;
}


function Santa_NaughtyCheck(%resume)
{
   if(!isobject($santa))
      return;
 
   if($santa.naughtyTick > 1)
   {
      if(%resume)
         $santa.ai = schedule(250, $santa, $santa.resumeAI, $santa.resumeAIParam);
      return(0);
   }
 
   %naughty = $santa.naughty;
   $santa.naughty = "";
   %pos = $santa.getposition();

   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
   {
      %cl = clientgroup.getobject(%i);
      if(!isobject(%p = %cl.player))
         continue;
      if(%p.stunned)
         continue;

      %dist = vectordist(%p.getposition(), %pos);
      if(%dist > 45)
         continue;

      if(%dist < 3)
      {
         %naughty = %p;
         break;
      }
      if(!%p.hasPresent)
         continue;
      if(!Santa_LOS(%p))
         continue;

      %naughty = %p;
   }
 
   if(!isobject(%naughty))
   {
      if(%resume)
         $santa.ai = schedule(250, $santa, $santa.resumeAI, $santa.resumeAIParam);
      return(0);
   }
 
   $santa.naughtyTick++;
   $santa.stop();
   $santa.clearaim();
   $santa.setaimobject(%naughty);
   schedule(450, $santa, Santa_ThrowCoal, %naughty);

   schedule(600, $santa, Santa_NaughtyCheck, 1);
   return(1);
}


function Santa_ThrowCoal(%target)
{
   //$santa.spawnProjectile(100,coalProjectile,0,1);
   %eye = $santa.geteyetransform();
   %pos = vectoradd(%eye, $santa.geteyevector());
   %tpos = %target.geteyetransform();
   %dist = vectordist(%tpos, %eye);
   %loc = vectoradd(%tpos, vectorscale(%target.getvelocity(), %dist * 0.011));
   %vel = vectorscale(vectornormalize(vectorsub(%loc, %eye)), 80);

   %p = new projectile()
   {
      datablock = coalProjectile;
      initialPosition = %pos;
      initialVelocity = %vel;
   };
   missionCleanup.add(%p);

   $santa.playthread(0, shiftAway);
}


function Santa_LOS(%obj, %seeBehind)
{
   %eye = $santa.geteyetransform();

   if(%obj.getclassname() $= "Player")
   {
      %pos = %obj.geteyetransform();

      if(!%seeBehind)
         if(vectordist($santa.getforwardvector(), vectornormalize(vectorsub(%obj.geteyetransform(), %eye))) > 1.41421)
            return(0);

      if(containerraycast(%eye,%pos,$typemasks::fxbrickobjecttype))
         return(0);

      return(1);
   }
 
   %pos = %obj.getposition();
   if(%t = containerraycast(%eye, %pos, $typemasks::fxbrickobjecttype))
      if(%t != %obj)
         return(0);

   return(1);
}
