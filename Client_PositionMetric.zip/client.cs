if(!isObject(positionGUI))
{
	exec("./positionGUI.gui");
	playGUI.add("positionGUI");
}


if(!$pref::HUD::positionGUIupdateSpeed)
	$pref::HUD::positionGUIupdateSpeed = 32;

function updatePositionGUI()
{
	if(isObject(serverConnection))
		if(isObject(%player = serverConnection.getControlObject()))
		{
			if(%player.getClassName() $= "Player")
			{
				%position = %player.getPosition();
				%speed = %player.getVelocity();
			}
			
			else if(%player.getClassName() $= "Camera")
			{
				if(%player.isOrbitMode())
				{
					%position = %player.getOrbitPoint();
					%player = %player.getOrbitObject();
				}
				else
					%position = %player.getTransform();
				
				if(isObject(%player))
					%speed = %player.getVelocity();
			}
				
			
			%x = mFloatLength(getWord(%position, 0), 0);
			%y = mFloatLength(getWord(%position, 1), 0);
			%z = mFloatLength(getWord(%position, 2), 0);
			
			
			
			%sx = mFloatLength(getWord(%speed, 0), 0);
			%sy = mFloatLength(getWord(%speed, 1), 0);
			%sz = mFloatLength(getWord(%speed, 2), 0);
			
			if(mAbs(%sx) > 28 || mAbs(%sy) > 28 || mAbs(%sz) > 28)
				%velColor = "ff2222";

			else
				%velColor = "ffffff";
			
			
			positionGUIText.setText("<color:ffffff>" @ %x SPC %y SPC %z NL "<br><color:" @ %velColor @ ">" @ %sx SPC %sy SPC %sz);
		}
		
	schedule($pref::HUD::positionGUIupdateSpeed, positionGUI, updatePositionGUI);
}

updatePositionGUI();