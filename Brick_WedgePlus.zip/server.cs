datablock fxDTSBrickData(brick1x1x5wedgeData)
{
	brickFile = "./bricks/1x1x5wedge.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "1x1x5 Wedge";
	iconName = "Add-Ons/Brick_WedgePlus/icons/1x1x5wedge";
	collisionShapeName = "./shapes/1x1x5wedge.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData(brick2x3x5wedgeLData)
{
	brickFile = "./bricks/2x3x5wedgeright.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "2x3x5 Wedge L";
	iconName = "Add-Ons/Brick_WedgePlus/icons/2x3x5wedgeright";
	collisionShapeName = "./shapes/2x3x5wedgeright.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x3x5wedgeRData)
{
	brickFile = "./bricks/2x3x5wedgeleft.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "2x3x5 Wedge R";
	iconName = "Add-Ons/Brick_WedgePlus/icons/2x3x5wedgeleft";
	collisionShapeName = "./shapes/2x3x5wedgeleft.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4x5wedgeLData)
{
	brickFile = "./bricks/2x4x5wedgeright.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "2x4x5 Wedge L";
	iconName = "Add-Ons/Brick_WedgePlus/icons/2x4x5wedgeright";
	collisionShapeName = "./shapes/2x4x5wedgeright.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4x5wedgeRData)
{
	brickFile = "./bricks/2x4x5wedgeleft.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "2x4x5 Wedge R";
	iconName = "Add-Ons/Brick_WedgePlus/icons/2x3x5wedgeleft";
	collisionShapeName = "./shapes/2x4x5wedgeleft.dts";
	orientationFix = 3;
};


datablock fxDTSBrickData(brick2x4x5wedgeRData)
{
	brickFile = "./bricks/2x4x5wedgeleft.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "2x4x5 Wedge R";
	iconName = "Add-Ons/Brick_WedgePlus/icons/2x3x5wedgeleft";
	collisionShapeName = "./shapes/2x3x5wedgeleft.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x3x5wedgeData)
{
	brickFile = "./bricks/3x3x5wedge.blb";
	category = "Wedges";
	subCategory = "x5";
	uiName = "3x3x5 Wedge";
	iconName = "Add-Ons/Brick_WedgePlus/icons/3x3x5wedge";
	collisionShapeName = "./shapes/3x3x5wedge.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData(brick1x1FwedgeData)
{
	brickFile = "./bricks/1x1Fwedge.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "1x1F Wedge";
	iconName = "Add-Ons/Brick_WedgePlus/icons/1x1Fwedge";
	collisionShapeName = "./shapes/1x1Fwedge.dts";
	orientationFix = 2;
};


datablock fxDTSBrickData(brick1x1wedgeData)
{
	brickFile = "./bricks/1x1wedge.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "1x1 Wedge";
	iconName = "Add-Ons/Brick_WedgePlus/icons/1x1wedge";
	collisionShapeName = "./shapes/1x1wedge.dts";
	orientationFix = 2;
};