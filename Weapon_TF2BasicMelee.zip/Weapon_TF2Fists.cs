AddDamageType("TF2Fists",   '<bitmap:Add-Ons/Weapon_TF2BasicMelee/ci_tf2fists> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2BasicMelee/ci_tf2fists> %1',0.75,1);

//////////
// item //
//////////
datablock ItemData(tf2FistsItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./FistsItem.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Fists";
	iconName = "./icon_tf2Fists";
	doColorShift = true;
	colorShiftColor = "0.3 0.3 0.3 1.000";

	 // Dynamic properties defined by the scripts
	image = tf2FistsImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(tf2FistsImage)
{
   // Basic Item properties
   shapeFile = "./RightFist.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0.2";
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = tf2FistsItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;
   
   doTF2FistsAltFire = 1;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = tf2FistsItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = tf2MeleeHitPlayerSound;
   raycastExplosionPlayerSound = tf2MeleeHitPlayerSound;
   raycastDirectDamage = 35;
   raycastDirectDamageType = $DamageType::TF2Fists;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.3;
	stateSequence[0]                = "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]                   = weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnAmmo[1]        = "PreFireA";
	stateAllowImageChange[1]        = true;

	stateName[2]			= "PreFireA";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTransitionOnTimeout[2]     = "PreFireB";
	stateWaitForTimeout[2]          = true;
	stateTimeoutValue[2]            = 0.1;

	stateName[3]			= "PreFireB";
	stateTransitionOnLoaded[3]      = "FireA";
        stateTransitionOnNotLoaded[3]   = "FireLeftA";
	stateAllowImageChange[3]        = false;
	
	stateName[4]                    = "FireA";
	stateTransitionOnTimeout[4]     = "FireB";
	stateTimeoutValue[4]            = 0.2;
	stateFire[4]                    = true;
	stateSequence[4]		= "RightPunch";
	stateAllowImageChange[4]        = false;
	stateSound[4]			= tf2MeleeSwingSound;
	stateWaitForTimeout[4]		= true;
        
	stateName[5]                    = "FireLeftA";
	stateTransitionOnTimeout[5]     = "FireB";
	stateTimeoutValue[5]            = 0.2;
	stateFire[5]                    = true;
	stateAllowImageChange[5]        = false;
	stateSound[5]			= tf2MeleeSwingSound;
	stateWaitForTimeout[5]		= true;

	stateName[6]                    = "FireB";
	stateTransitionOnTimeout[6]     = "CheckFire";
	stateTimeoutValue[6]            = 0.5;
	stateFire[6]                    = true;
	stateAllowImageChange[6]        = false;
	stateScript[6]                  = "onFire";
	stateWaitForTimeout[6]		= true;

	stateName[7]			= "CheckFire";
	stateTransitionOnNoAmmo[7]	= "StopFire";
	stateTransitionOnAmmo[7]	= "PreFireA";
	
	stateName[8]                    = "StopFire";
	stateTransitionOnTimeout[8]     = "Ready";
	stateTimeoutValue[8]            = 0.2;
	stateAllowImageChange[8]        = false;
	stateWaitForTimeout[8]		= true;
	stateSequence[8]                = "StopFire";
};

datablock ShapeBaseImageData(TF2FistsAltImage)
{
   // Basic Item properties
   shapeFile = "./LeftFist.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0.2";
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = tf2FistsItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = tf2FistsItem.colorShiftColor;
   
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.3;
	stateSequence[0]                = "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]                   = "";

	stateName[1]                    = "Ready";
	stateTransitionOnAmmo[1]        = "PreFire";
	stateAllowImageChange[1]        = true;

	stateName[2]			= "PreFire";
	stateAllowImageChange[2]        = false;
	stateTransitionOnTimeout[2]     = "FireA";
	stateTimeoutValue[2]            = 0.05;
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "FireB";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateSequence[3]		= "LeftPunch";
	stateScript[3]                  = "onFire";
	stateAllowImageChange[3]        = false;
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "FireB";
	stateTransitionOnTimeout[4]     = "Ready";
	stateTimeoutValue[4]            = 0.5;
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = false;
	stateWaitForTimeout[4]		= true;
};

function TF2FistsImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   
   %obj.mountImage(TF2FistsAltImage, 1);
   %obj.hideNode("lhand");
   %obj.hideNode("rhand");
   %obj.hideNode("lhook");
   %obj.hideNode("rhook");
   
   %obj.setImageAmmo(0,0);
   %obj.setImageAmmo(1,0);
   
   fixArmReady(%obj);
}

function TF2FistsImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   
   %obj.unMountImage(1);
   if(isObject(%obj.client))
   {
      %obj.client.applyBodyParts();
      %obj.client.applyBodyColors();
   }
   else
   {
      %obj.unHideNode("lhand");
      %obj.unHideNode("lhook");
   }
   
   fixArmReady(%obj);
}

function TF2FistsImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit)
{
   return tf2MeleeWeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit);
}

function TF2FistsImage::onPreFire(%this,%obj,%slot)
{
   if(%obj.getDamagePercent() >= 1.0)
   {
      %obj.setImageLoaded(0,0);
      %obj.setImageAmmo(1,0);
      return;
   }
   
   if(%obj.fistsHoldRight)
   {
      %obj.setImageLoaded(0,1);
      %obj.setImageAmmo(1,0);
   }
   else if(%obj.fistsHoldLeft)
   {
      %obj.setImageLoaded(0,0);
      %obj.setImageAmmo(1,1);
   }
}

function TF2FistsImage::onStopFire(%this,%obj,%slot)
{
}

function TF2FistsAltImage::onFire(%this,%obj,%slot)
{
   %obj.setImageAmmo(%slot,0);
}

package TF2Fists
{
	function armor::onTrigger(%this,%player,%slot,%val)
	{
		if(%player.getMountedImage(0).doTF2FistsAltFire)
		{
			if(%slot == 0)
				%player.fistsHoldLeft = %val;
			else if(%slot == 4)
				%player.fistsHoldRight = %val;
			else
				Parent::onTrigger(%this,%player,%slot,%val);
			
			%player.setImageAmmo(0,(%player.fistsHoldLeft || %player.fistsHoldRight));
		}
		else
			Parent::onTrigger(%this,%player,%slot,%val);
	}
	
	function ShapeBase::unHideNode(%this,%node)
	{
		if(%this.getMountedImage(0).doTF2FistsAltFire && (strStr(%node,"hand") != -1 || strStr(%node,"hook") != -1))
			return;
		
		Parent::unHideNode(%this,%node);
	}
};
ActivatePackage(TF2Fists);