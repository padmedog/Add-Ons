//########## Zombies Pirates

Slayer.Prefs.addPref("EZM","Allow Pirate Zombies","%mini.EZM_AllowPirateZombies","bool",1,0,1,-1,"Rules EZM Mode");

//### Player Datablocks

datablock PlayerData(EZM_PiratePlayer : PlayerStandardArmor)
{
  uiName = "";
  maxDamage = 50;
  canJet = false;
};

//### Zombies

EZM_addZombie("Pirate Zombie","Pirate Zombie",EZM_PiratePlayer,"1 1 1","EZM_SwordImage","gc_FLPistolImage gc_FLPistolAkimboImage gc_MusketImage gc_CrossbowImage gc_BlunderbussImage gc_FLHandmortarImage",0,10,"EZM_AllowPirateZombies");
EZM_addAppearance("Pirate Zombie","headskin 0.56 0.93 0.96 1 lhand 0.56 0.93 0.96 1 rhand 0.56 0.93 0.96 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lshoe 0.3 0.2 0.1 1 rshoe 0.3 0.2 0.1 1",0,"Skull smileyEvil1 smileyEvil2 smileyPirate1 smileyPirate2 smileyPirate3 smileyRedBeard smileyRedBeard2","Archer DKnight LinkTunic Knight");
EZM_addAppearance("Pirate Zombie","headskin 0.56 0.93 0.96 1 lhook 0.5 0.5 0.5 1 rhand 0.56 0.93 0.96 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lshoe 0.3 0.2 0.1 1 rshoe 0.3 0.2 0.1 1","lhand","Skull smileyEvil1 smileyEvil2 smileyPirate1 smileyPirate2 smileyPirate3 smileyRedBeard smileyRedBeard2","Archer DKnight LinkTunic Knight");
EZM_addAppearance("Pirate Zombie","headskin 0.56 0.93 0.96 1 lhand 0.56 0.93 0.96 1 rhook 0.5 0.5 0.5 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lshoe 0.3 0.2 0.1 1 rshoe 0.3 0.2 0.1 1","rhand","Skull smileyEvil1 smileyEvil2 smileyPirate1 smileyPirate2 smileyPirate3 smileyRedBeard smileyRedBeard2","Archer DKnight LinkTunic Knight");
EZM_addAppearance("Pirate Zombie","headskin 0.56 0.93 0.96 1 lhand 0.56 0.93 0.96 1 rhand 0.56 0.93 0.96 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lpeg 0.3 0.2 0.1 1 rshoe 0.3 0.2 0.1 1","lshoe","Skull smileyEvil1 smileyEvil2 smileyPirate1 smileyPirate2 smileyPirate3 smileyRedBeard smileyRedBeard2","Archer DKnight LinkTunic Knight");
EZM_addAppearance("Pirate Zombie","headskin 0.56 0.93 0.96 1 lhand 0.56 0.93 0.96 1 rhand 0.56 0.93 0.96 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lshoe 0.3 0.2 0.1 1 rpeg 0.3 0.2 0.1 1","rshoe","Skull smileyEvil1 smileyEvil2 smileyPirate1 smileyPirate2 smileyPirate3 smileyRedBeard smileyRedBeard2","Archer DKnight LinkTunic Knight");

//### Bosses

EZM_addBoss("Captain Redbeard","Captain Redbeard",EZM_BossPlayer,"1.5 1.5 1.5",-1,"gc_BlunderbussImage gc_RevCrossbowImage gc_RevMusketImage gc_FLHandmortarImage gc_FLBazookaImage",10,"EZM_AllowPirateZombies");
EZM_addAppearance("Captain Redbeard","headskin 0.56 0.93 0.96 1 lhand 0.56 0.93 0.96 1 rhook 0.56 0.93 0.96 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lpeg 0.3 0.2 0.1 1 rshoe 0.3 0.2 0.1 1 epaulets 0.1 0.1 0.1 1 bicorn 0.3 0.2 0.1 1","rhand lshoe","smileyRedBeard","Archer DKnight LinkTunic Knight");

EZM_addBoss("Captain Fleshhook","Captain Fleshhook",EZM_BossPlayer,"1.5 1.5 1.5",-1,"gc_BlunderbussImage gc_RevCrossbowImage gc_RevMusketImage gc_FLHandmortarImage gc_FLBazookaImage",10,"EZM_AllowPirateZombies");
EZM_addAppearance("Captain Fleshhook","headskin 0.56 0.93 0.96 1 lhook 0.8 0 0 1 rhand 0.56 0.93 0.96 1 chest 0.2 0.4 0.2 1 larm 0.2 0.4 0.2 1 rarm 0.2 0.4 0.2 1 lshoe 0.3 0.2 0.1 1 rshoe 0.3 0.2 0.1 1 epaulets 0.8 0 0 1 bicorn 0.1 0.1 0.1 1","lhand","smileyPirate2","Archer DKnight LinkTunic Knight");
