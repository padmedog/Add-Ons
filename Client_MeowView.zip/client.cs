
$meowView = 0;
function delete360()
{
	if(!$meowView)
		return;
	for(%i=0;%i<30;%i++)
	{
		%d = "t" @ %i;
		%d.delete();
	}
	$meowView = 0;
}
function create360()
{
	if($meowView)
		return;
	for(%i=-15;%i<15;%i++)
	{
		%b="t" @ %i+15;
		%a=new GameTSCtrl(%b)
		{
			profile = "GuiContentProfile";
			position = ((getword(getRes(),0)/30)*(%i+15)) SPC 0;
			extent = (getword(getRes(),0)/30+1) SPC getword(getRes(),1);
			visible = "1";
			cameraZRot = %i*12;
			forceFOV = 12;
			noCursor = "1";
		};
		PlayGUI.add(%a);
	}
	for(%i=0;%i<30;%i++)
	{
		%d = "t" @ %i;
		%d.extent=getword(%d.extent,0) SPC getWord(getres(),1);
	}
	$meowView = 1;
}
if (!$backviewbind)
{
   $remapDivision[$remapCount] = "View Changer";
   $remapName[$remapCount] = "Create 360 View";
   $remapCmd[$remapCount] = "create360";
   $remapCount++;
   $remapName[$remapCount] = "Delete 360 View";
   $remapCmd[$remapCount] = "delete360";
   $remapCount++;
   $backviewbind=true;
}