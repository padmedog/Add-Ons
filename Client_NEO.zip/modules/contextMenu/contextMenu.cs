//contextMenu.cs
//by Nexus 4833

if($narg_contextmenu_version >= 1)
{
	echo("NARG ContextMenu [v" @ $narg_contextmenu_version @ "] already in place, no need to execute.");
	return;
}
$narg_contextmenu_version = 1;

//promptUserContext() - The primary function that you need to call.
//%contextObj - A ScriptObject set up with all the information needed by this module.
//   This parameter is optional.  If provided, then you do not need to do anything else.
//   Otherwise, see NARGContextMenu::addButton() and NARGContextMenu::display() for more information.
//   Example:
//		%obj = new scriptobject()
//		{
//			buttonCount = 3;
//			buttonName0 = "Yes";
//			buttonCmd0 = "say_yes();";
//			buttonName1 = "No";
//			buttonCmd1 = "say_no();";
//			buttonName2 = "Maybe";
//			buttonCmd2 = "say_maybe();";
//			position = "108 318";
//			callback = "done_talking();";
//		};
//%requestUnique - (Boolean) Request a freshly created GUI rather than a recycled one.
//   If you use this parameter, please note that the GUI will be deleted once the user has interacted with it.
//   Feel free to delete this object if you change your mind about using it for whatever reason.

function promptUserContext(%contextobj, %requestUnique)
{
	if(%requestUnique)
		%gui = NARG_getNewContextMenu();
	else
	{
		%gui = $NARG_Context_GUI;

		if(%gui.isAwake())
			%gui.allDone();
	}

	if(isobject(%contextobj))
	{
		%gui.setData(%contextobj);
	}
	return %gui;
}

function NARG_getNewContextMenu()
{
	%gui = new GuiControl(NARGContextMenu)
	{
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "0 0";
		extent = "640 480";
		minExtent = "8 2";
		enabled = "1";
		visible = "1";
		clipToParent = "1";

		new GuiSwatchCtrl()
		{
			profile = "GuiDefaultProfile";
			horizSizing = "width";
			vertSizing = "height";
			position = "0 0";
			extent = "640 480";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			color = "0 0 0 0";

			new GuiMouseEventCtrl(narg_contextclickout)
			{
				profile = "GuiDefaultProfile";
				horizSizing = "width";
				vertSizing = "height";
				position = "0 0";
				extent = "640 480";
				minExtent = "8 2";
				enabled = "1";
				visible = "1";
				clipToParent = "1";
				lockMouse = "0";
			};

			new GuiSwatchCtrl()
			{
				profile = "GuiDefaultProfile";
				horizSizing = "right";
				vertSizing = "bottom";
				position = "0 0";
				extent = "130 2";
				minExtent = "8 2";
				enabled = "1";
				visible = "1";
				clipToParent = "1";
				color = "0 0 0 255";
			};
		};
	};
	return %gui;
}

//you do not need to call addButton if you provided a contextObject
//%text - The text to display on the button
//%command - A piece of code to be evaluated when the button is pressed.

function NARGContextMenu::addButton(%this, %text, %command)
{
	%swatch = %this.getobject(0).getobject(1);

	if(%command $= "")
		%acc = "escape";
	else
		%acc = "";

	%gui = new GuiBitmapButtonCtrl()
	{
		profile = "BlockButtonProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "1" SPC (1 + 30*%swatch.getCount());
		extent = "128 30";
		minExtent = "8 2";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
		command = %this @ ".pressCommand(\"" @ %command @ "\");";
		accelerator = %acc;
		text = %text;
		groupNum = "-1";
		buttonType = "PushButton";
		bitmap = "./rightclick";
		lockAspectRatio = "0";
		alignLeft = "0";
		alignTop = "0";
		overflowImage = "0";
		mKeepCached = "0";
		mColor = "255 255 255 255";
	};
	%swatch.add(%gui);
	%swatch.resize(getword(%swatch.getposition(), 0), getword(%swatch.getposition(), 1), 130, 2 + 30*%swatch.getCount());
}

//you do not need to call display if you provided a contextObject
//%pos - The pixel coordinates to display the context menu at, with (0, 0) in the top left.
//   This will normally be the top left corner of the menu, but may be repositioned based on the viewport.
//%callback - A callback provided when the menu is closed for any reason.
//   This will be called after after the button's command is evaluated.

function NARGContextMenu::display(%this, %pos, %callback)
{
	%this.callback = %callback;
	%swatch = %this.getobject(0).getobject(1);
	%extx = getword(%swatch.getextent(), 0);
	%exty = getword(%swatch.getextent(), 1);

	if(%exty + getword(%pos, 1) > getword(getres(), 1))
	{
		if(%extx + getword(%pos, 0) > getword(getres(), 0))
		{
			//bottom right
			%swatch.resize(getword(%pos, 0) - %extx, getword(%pos, 1) - %exty, %extx, %exty);
		}
		else
		{
			//bottom left
			%swatch.resize(getword(%pos, 0), getword(%pos, 1) - %exty, %extx, %exty);
		}
	}
	else
	{
		if(%extx + getword(%pos, 0) > getword(getres(), 0))
		{
			//top right
			%swatch.resize(getword(%pos, 0) - %extx, getword(%pos, 1), %extx, %exty);
		}
		else
		{
			//top left
			%swatch.resize(getword(%pos, 0), getword(%pos, 1), %extx, %exty);
		}
	}
	canvas.pushdialog(%this);
}

function NARGContextMenu::setData(%this, %obj)
{
	for(%i=0; %i<%obj.buttonCount; %i++)
	{
		%this.addButton(%obj.name[%i], %obj.cmd[%i]);
	}
	%this.display(%obj.position, %obj.callback);
	
}

function NARGContextMenu::pressCommand(%this, %command)
{
	eval(%command);
	%this.alldone();
}

function NARGContextMenu::allDone(%this)
{
	if(isfunction(%this.callback))
		call(%this.callback);
	canvas.popdialog(%this);

	if(!%this.isOriginal)
		%this.delete();
	else
	{
		%swatch = %this.getobject(0).getobject(1);
		%swatch.clear();
	}
}

function narg_contextclickout::onmousedown(%this, %key, %pos, %count)
{
	%this.getGroup().getGroup().allDone();
}

function narg_contextclickout::onrightmousedown(%this, %key, %pos, %count)
{
	%this.getGroup().getGroup().allDone();
}

while(isObject(NARGContextMenu))
	NARGContextMenu.delete();

$NARG_Context_GUI = NARG_getNewContextMenu();
$NARG_Context_GUI.isOriginal = true;

