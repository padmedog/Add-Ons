//########## Pistols Akimbo

//### Item

datablock ItemData(gc_FLPistolAkimboItem)
{
  uiName = "Flintlock Pistols";
  iconName = "./icon_pistolakimbo";
  image = gc_FLPistolAkimboImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./pistol.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(gc_FLPistolAkimboImage)
{
  shapeFile = "./pistol.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_FLPistolAkimboItem;
  ammo = "";
  projectile = gc_FLPistolProjectile;
  projectilespread = 0.003;
  projectilecount = 3;
  projectileType = Projectile;
  mountPoint = 0;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Smoke";
  stateTimeoutValue[2] = "0.05";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_MusketMuzzleEmitter;
  stateEmitterTime[2] = 0.1;
  stateEmitterNode[2] = "muzzlePoint";
  stateSound[2] = gc_MusketFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Fire";

  stateName[3] = "Smoke";
  stateTransitionOnTimeout[3] = "LeftFire";
  stateTimeoutValue[3] = "0.15";
  stateAllowImageChange[3] = false;
  stateWaitForTimeout[3] = true;
  stateEmitter[3] = gc_MusketMuzzleEmitter;
  stateEmitterTime[3] = 0.02;
  stateEmitterNode[3] = "lockPoint";
  stateScript[3] = "onFireAkimbo";

  stateName[4] = "LeftFire";
  stateTransitionOnTimeout[4] = "AmmoCheck";
  stateTimeoutValue[4] = "0.1";
  stateAllowImageChange[4] = false;
  stateWaitForTimeout[4] = true;

  stateName[5] = "AmmoCheck";
  stateTransitionOnTimeout[5] = "Ready";
  stateAllowImageChange[5] = true;
  stateScript[5] = "onAmmoCheck";

  stateName[6] = "Reload";
  stateTimeoutValue[6] = 1.6;
  stateTransitionOnTimeout[6] = "Done";
  stateWaitForTimeout[6] = true;
  stateAllowImageChange[6] = true;
  stateScript[6] = "onReloadStart";
  stateSequence[6] = "Reload";

  stateName[7] = "Done";
  stateTransitionOnTimeout[7] = "Ready";
  stateTimeoutValue[7] = 0.1;
  stateAllowImageChange[7] = true;
  stateScript[7] = "onReload";
};

datablock shapeBaseImageData(gc_FLPistolAkimboLeftImage)
{
  shapeFile = "./pistol.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = "";
  ammo = "";
  projectile = gc_FLPistolProjectile;
  projectilespread = 0.003;
  projectilecount = 3;
  projectileType = Projectile;
  mountPoint = 1;
  offset = "0 0 0";
  eyeOffset = "0 0 0";
  melee = false;
  doReaction = false;
  armReady = false;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnTimeout[0] = "AmmoCheck";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Smoke";
  stateTimeoutValue[2] = "0.05";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateEmitter[2] = gc_MusketMuzzleEmitter;
  stateEmitterTime[2] = 0.1;
  stateEmitterNode[2] = "muzzlePoint";
  stateSound[2] = gc_MusketFireSound;
  stateScript[2] = "onFire";
  stateSequence[2] = "Fire";

  stateName[3] = "Smoke";
  stateTransitionOnTimeout[3] = "AmmoCheck";
  stateTimeoutValue[3] = "0.15";
  stateAllowImageChange[3] = false;
  stateWaitForTimeout[3] = true;
  stateEmitter[3] = gc_MusketMuzzleEmitter;
  stateEmitterTime[3] = 0.02;
  stateEmitterNode[3] = "lockPoint";

  stateName[4] = "AmmoCheck";
  stateTransitionOnTimeout[4] = "Ready";
  stateAllowImageChange[4] = true;
  stateScript[4] = "onAmmoCheck";

  stateName[5] = "Reload";
  stateTimeoutValue[5] = 1.6;
  stateTransitionOnTimeout[5] = "Done";
  stateWaitForTimeout[5] = true;
  stateAllowImageChange[5] = true;
  stateScript[5] = "onReloadStart";
  stateSequence[5] = "Reload";

  stateName[6] = "Done";
  stateTransitionOnTimeout[6] = "Ready";
  stateTimeoutValue[6] = 0.1;
  stateAllowImageChange[6] = true;
  stateScript[6] = "onReload";
};

//### Functions

function gc_FLPistolAkimboImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(0,0);
  }
  %obj.spawnExplosion(gc_weaponRecoil,"1 1 1");
  %obj.playThread(2,shiftAway);
  %spread = %this.projectilespread;
  for(%shell=0;%shell<%this.projectilecount;%shell++) {
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  }; }
  MissionCleanup.add(%p);
}
function gc_FLPistolAkimboImage::onFireAkimbo(%this,%obj,%slot) { %obj.setImageTrigger(1,1); }

function gc_FLPistolAkimboImage::onMount(%this,%obj,%slot) { parent::onMount(%this,%obj,%slot); %obj.mountImage(gc_FLPistolAkimboLeftImage,1); }
function gc_FLPistolAkimboImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(0,0); } }
function gc_FLPistolAkimboImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,plant); serverPlay3D(gc_FLReloadStartSound,%obj.getPosition()); }
function gc_FLPistolAkimboImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(0,1); }
function gc_FLPistolAkimboImage::onUnMount(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.unMountImage(1); }

function gc_FLPistolAkimboLeftImage::onFire(%this,%obj,%slot)
{
  %obj.toolMag[%obj.currTool] -= 1;
  if(%obj.toolMag[%obj.currTool] < 1)
  {
    %obj.toolMag[%obj.currTool] = 0;
    %obj.setImageAmmo(1,0);
  }
  %obj.spawnExplosion(gc_weaponRecoil,"1 1 1");
  %obj.playThread(2,leftrecoil);
  %spread = %this.projectilespread;
  for(%shell=0;%shell<%this.projectilecount;%shell++) {
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(1),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(1);
    sourceObject = %obj;
    sourceSlot = 1;
    client = %obj.client;
  }; }
  MissionCleanup.add(%p);
}
function gc_FLPistolAkimboLeftImage::onMount(%this,%obj,%slot) { parent::onMount(%this,%obj,%slot); %obj.playThread(1,armreadyboth); }
function gc_FLPistolAkimboLeftImage::onAmmoCheck(%this,%obj,%slot) { if(%obj.toolMag[%obj.currTool] > 1) { %obj.toolMag[%obj.currTool] = 1; } if(%obj.toolMag[%obj.currTool] < 1) { %obj.toolMag[%obj.currTool] = 0; %obj.setImageAmmo(1,0); } }
function gc_FLPistolAkimboLeftImage::onReloadStart(%this,%obj,%slot) { %obj.playThread(2,plant); serverPlay3D(gc_FLReloadStartSound,%obj.getPosition()); }
function gc_FLPistolAkimboLeftImage::onReload(%this,%obj,%slot) { %obj.playThread(2,plant); serverPlay3D(gc_FLReloadEndSound,%obj.getPosition()); %obj.toolMag[%obj.currTool] = 1; %obj.setImageAmmo(1,1); }
