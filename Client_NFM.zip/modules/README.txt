These modules are designed to be able to be used as standalone mods.
getName and zoomImage are able to run standalone
getFile is dependent on the other modules being in place
Feel free to use these modules in your own code as provided!

By Nexus 4833