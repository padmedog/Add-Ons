

package BRPG_Client_Controls_Package {
	function clientCmdBRPG_Targeting(%bool) {
		if(%bool) {
			BRPG_Client_TargetingTick();
			canvas.pushDialog(BRPG_Client_Targeting_Gui);
		} else {
			BRPG_Client_TargetingEnd();
		}
	}

	function BRPG_Client_TargetingTick() {
		//Used for mouse aiming
	
		//Range is -1 to 1, with 0 being in the middle of the screen
		//Pitch is not normalized to screen height, but rather width
	
		%res = getRes();
		%width = getWord(%res, 0);
		%height = getWord(%res, 1);
		%mousePos = canvas.getCursorPos();
		%mousePosX = getWord(%mousePos, 0) * 2 - %width;
		%mousePosY = getWord(%mousePos, 1) * 2 - %height;
	
		%yaw = %mousePosX / %width;
		%pitch = %mousePosY / %width;
	
		commandToServer('BRPG_Targeting_Set', %yaw, -%pitch);
	
		cancel($BRPG::Client::TargetingTick);
		$BRPG::Client::TargetingTick = schedule(100, 0, BRPG_Client_TargetingTick);
	}
	function BRPG_Client_TargetingEnd() {
		cancel($BRPG::Client::TargetingTick);
		canvas.popDialog(BRPG_Client_Targeting_Gui);
	}
	function BRPG_Client_TargetingDone() {
		%res = getRes();
		%width = getWord(%res, 0);
		%height = getWord(%res, 1);
		%mousePos = canvas.getCursorPos();
		%mousePosX = getWord(%mousePos, 0) * 2 - %width;
		%mousePosY = getWord(%mousePos, 1) * 2 - %height;
	
		%yaw = %mousePosX / %width;
		%pitch = %mousePosY / %width;
	
		commandToServer('BRPG_Targeting_Done', %yaw, -%pitch);
	}


	function clientCmdBRPG_SetCrouched(%bool) {
		//No hax pls, changing this wont actually give you any advantages
		//your speed is set server sided, even animations

		$mvTriggerCount3 = %bool;
	}

	function crouch(%bool) {
		walk(%bool);
		return;
	}
};