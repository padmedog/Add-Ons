// ============================================================
// Project				:	Weapon_Molotov
// Author				:	Iban
// ============================================================
// Table of Contents
// 
// 1. Objects
// 2. Package
// 3. Script
// ============================================================

// ============================================================
// Section 1 : Objects
// ============================================================
if($DamageType::Burning $= "")
{
	AddDamageType("Burning", '<bitmap:Add-Ons/Weapon_Molotov/CI_Fire> %1', '%2 <bitmap:Add-Ons/Weapon_Molotov/CI_Fire> %1', 0.2, 1);
}

// Player Burn Particle
if(!isObject(PlayerNapalmFireParticle))
{
	datablock ParticleData(PlayerNapalmFireParticle)
	{
		textureName				= "base/data/particles/cloud";
		dragCoefficient			= 0.0;
		gravityCoefficient		= -1.0;
		inheritedVelFactor		= 0.0;
		windCoefficient			= 0;
		constantAcceleration	= 3.0;
		lifetimeMS				= 1200;
		lifetimeVarianceMS		= 100;
		spinSpeed				= 0;
		spinRandomMin			= -90.0;
		spinRandomMax			=  90.0;
		useInvAlpha				= false;
		
		colors[0]	= "1.0 1.0 0.3 0.0";
		colors[1]	= "1.0 1.0 0.3 1.0";
		colors[2]	= "0.6 0.0 0.0 0.0";
		
		sizes[0]	= 0.0;
		sizes[1]	= 2.0;
		sizes[2]	= 1.0;
		
		times[0]	= 0.0;
		times[1]	= 0.2;
		times[2]	= 1.0;
	};
}

// Molotov Whick Fire
if(!isObject(ZombieMolotovFlameParticle))
{
	datablock ParticleData(ZombieMolotovFlameParticle)
	{
		textureName          = "base/data/particles/cloud";
		dragCoefficient      = 0.0;
		gravityCoefficient   = 0.0;
		inheritedVelFactor   = 0.0;
		windCoefficient      = 0;
		constantAcceleration = 3.0;
		lifetimeMS           = 400;
		lifetimeVarianceMS   = 050;
		spinSpeed     = 0;
		spinRandomMin = -90.0;
		spinRandomMax =  90.0;
		useInvAlpha   = false;

		colors[0]	= "1   1   0.3 0.0";
		colors[1]	= "1   1   0.3 1.0";
		colors[2]	= "0.6 0.0 0.0 0.0";

		sizes[0]	= 0.0;
		sizes[1]	= 0.2;
		sizes[2]	= 0.12;

		times[0]	= 0.0;
		times[1]	= 0.2;
		times[2]	= 1.0;
	};
}

// Player Flame Emitter
if(!isObject(PlayerNapalmFireEmitter))
{
	datablock ParticleEmitterData(PlayerNapalmFireEmitter)
	{
		ejectionPeriodMS	= 5;
		periodVarianceMS	= 4;
		ejectionVelocity	= 0;
		ejectionOffset		= 1.00;
		velocityVariance	= 0.0;
		thetaMin			= 30;
		thetaMax			= 90;
		phiReferenceVel		= 0;
		phiVariance			= 360;
		overrideAdvance		= false;
		
		particles = playerNapalmFireParticle;  
		
		uiName = "Player Napalm"; 
	};
}

// Molotov Whick Fire
if(!isObject(ZombieMolotovFlameEmitter))
{
	datablock ParticleEmitterData(ZombieMolotovFlameEmitter)
	{
		ejectionPeriodMS = 14;
		periodVarianceMS = 4;
		ejectionVelocity = 3;
		ejectionOffset   = 0.00;
		velocityVariance = 0.0;
		thetaMin         = 0;
		thetaMax         = 5;
		phiReferenceVel  = 0;
		phiVariance      = 360;
		overrideAdvance = false;
		
		particles = ZombieMolotovFlameParticle;   
		
		uiName = "Molotov Trail";
	};
}

// Molotov Firey Debris
if(!isObject(ZombieMolotovFireDebris))
{
	datablock DebrisData(ZombieMolotovFireDebris)
	{
		emitters = "PlayerNapalmFireEmitter";
		shapeFile = "base/data/shapes/empty.dts";
		lifetime = 10.0;
		minSpinSpeed = -400.0;
		maxSpinSpeed = 200.0;
		elasticity = 0.1;
		friction = 0.2;
		numBounces = 3;
		staticOnMaxBounce = true;
		snapOnMaxBounce = false;
		fade = false;
		gravModifier = 2;
	};
}

// Molotov Explosion
if(!isObject(ZombieMolotovExplosion))
{
	datablock ExplosionData(ZombieMolotovExplosion : vehicleFinalExplosion)
	{
		burnPlayerTime = 0;
		damageRadius = 6;
		impulseForce = 0;
		impulseRadius = 0;
		radiusDamage = 20;
		uiName = "";
		soundProfile = "glassExplosionSound";
		
		lifetimeMS = 10000;
		
		debris = "ZombieMolotovFireDebris";
		debrisNum = 14;
		debrisNumVariance = 4;
		debrisPhiMin = 0;
		debrisPhiMax = 360;
		debrisThetaMin = 30;
		debrisThetaMax = 30;
		debrisVelocity = 10;
		debrisVelocityVariance = 3;
		
		emitter[0] = "";//"PlayerNapalmFireEmitter";
		emitter[1] = "";//"PlayerNapalmFireEmitter";
		emitter[2] = "";//"PlayerNapalmFireEmitter";
		emitter[3] = "";//"PlayerNapalmFireEmitter";
		times[0] = "0";//"0";
		times[1] = "0";//"1";
		times[2] = "0";//"1";
		times[3] = "0";//"1";
		sizes[0] = "1 1 1";
		sizes[1] = "1 1 1";
		sizes[2] = "1 1 1";
		sizes[3] = "1 1 1";
	};
}

// Molotov Projectile
if(!isObject(ZombieMolotovProjectile))
{
	datablock ProjectileData(ZombieMolotovProjectile)
	{
		projectileShapeName				= "Add-Ons/Weapon_Molotov/molotovProjectile.1.dts";
		directDamage					= 0;
		directDamageType				= $DamageType::Burning;
		radiusDamageType				= $DamageType::Burning;
		
		brickExplosionRadius			= 0;
		brickExplosionImpact			= false;
		brickExplosionForce				= 0;
		brickExplosionMaxVolume			= 0;
		brickExplosionMaxVolumeFloating	= 0;
		
		impactImpulse					= 400;
		verticalImpulse					= 400;
		explosion						= ZombieMolotovExplosion;
		particleEmitter					= ZombieMolotovFlameEmitter;
		
		muzzleVelocity					= 25;
		velInheritFactor				= 0;
		
		armingDelay						= 0;
		lifetime						= 10000;
		fadeDelay						= 10000;
		bounceElasticity				= 0.4;
		bounceFriction					= 0.3;
		isBallistic						= true;
		gravityMod						= 1.0;
		
		hasLight						= false;
		lightRadius						= 3.0;
		lightColor						= "0 0 0.5";
		
		uiName							= "";
	};
}

// Molotov Item
if(!isObject(ZombieMolotovItem))
{
	datablock ItemData(ZombieMolotovItem)
	{
		category = "Weapon";
		className = "Weapon";
		
		// Basic Item Properties
		shapeFile = "Add-Ons/Weapon_Molotov/molotov.1.dts";
		mass = 1;
		density = 0.2;
		elasticity = 0.2;
		friction = 0.6;
		emap = true;
		
		// GUI Stuff
		uiName = "Molotov";
		iconName = "Add-Ons/Weapon_Molotov/Icon_Molotov";
		doColorShift = false;
		
		// Script Properties
		image = ZombieMolotovImage;
		canDrop = true;
	};
}

// Player Burn Image
if(!isObject(PlayerNapalmBurnImage))
{
	datablock ShapeBaseImageData(PlayerNapalmBurnImage)
	{
		shapeFile = "base/data/shapes/empty.dts";
		emap = false;

		mountPoint = $HeadSlot;
		offset = "0 0 -2";

		stateName[0]				= "Ready";
		stateTimeoutValue[0]		= 0.01;
		stateTransitionOnTimeout[0]	= "FireA";

		stateName[1]				= "FireA";
		stateEmitter[1]				= playerNapalmFireEmitter;
		stateEmitterTime[1]			= 0.9;
		stateTimeoutValue[1]		= 0.9;
		stateTransitionOnTimeout[1]	= "Done";
		stateWaitForTimeout[1]		= true;

		stateName[2]				= "Done";
		stateTimeoutValue[2]		= 0.01;
		stateTransitionOnTimeout[2]	= "FireA";
	};
}

// Weapon Image
if(!isObject(ZombieMolotovImage))
{
	datablock ShapeBaseImageData(ZombieMolotovImage)
	{
		shapeFile = "Add-Ons/Weapon_Molotov/molotov.1.dts";
		emap = true;
		mountPoint = 0;
		offset = "0 0 0";
		correctMuzzleVector = true;
		className = "WeaponImage";
		
		item = ZombieMolotovItem;
		ammo = "";
		projectile = ZombieMolotovProjectile;
		projectileType = Projectile;
		
		melee = false;
		armReady = true;
		
		doColorShift = false;
		
		// States
		stateName[0]					= "Activate";
		stateSequence[0]				= "ready";
		stateSound[0]					= weaponSwitchSound;
		stateTimeoutValue[0]			= 0.1;
		stateTransitionOnTimeout[0]		= "Ready";

		stateName[1]					= "Ready";
		stateAllowImageChange[1]		= true;
		stateTransitionOnTriggerDown[1]	= "Charge";

		stateName[2]					= "Charge";
		stateEmitter[2]					= ZombieMolotovFlameEmitter;
		stateEmitterTime[2]				= 999999;
		stateTimeoutValue[2]			= 0.7;
		stateTransitionOnTimeout[2]		= "Charged";
		stateTransitionOnTriggerUp[2]	= "AbortCharge";
		stateScript[2]					= "onCharge";
		stateWaitForTimeout[2]			= true;

		stateName[3]					= "Charged";
		stateAllowImageChange[3]		= false;
		stateEmitter[3]					= ZombieMolotovFlameEmitter;
		stateEmitterTime[3]				= 999999;
		stateTransitionOnTriggerUp[3]	= "Fire";

		stateName[4]					= "Fire";
		stateAllowImageChange[4]		= false;
		stateFire[4]					= true;
		stateScript[4]					= "onFire";
		stateTimeoutValue[4]			= 0.5;
		stateTransitionOnTimeout[4]		= "Done";
		stateWaitForTimeout[4]			= true;
		
		stateName[5]					= "Done";
		stateScript[5]					= "onDone";
		
		stateName[6]					= "AbortCharge";
		stateScript[6]					= "onChargeAbort";
		stateTimeoutValue[6]			= 0;
		stateTransitionOnTimeout[6]		= "Ready";
	};
}

// ============================================================
// Section 2 : Package
// ============================================================
// Usually, I keep all existing functions packaged and new functions unpackaged.
// Not the case here.
//
// ZAPT will have /all/ of these, and most likely an updated version.
// Thus, it's benefial to keep everything in a package that only activates
// if ZAPT is not active itself.

package Weapon_Molotov_Package
{
	// Put out the Fire
	function Armor::onEnterLiquid(%this, %obj)
	{
		if(isEventPending(%obj.damageBurnSched))
		{
			cancel(%obj.damageBurnSched);
			%obj.damageBurnLoops = 0;
			%obj.damageBurnDamage = 0;
			%obj.unMountImage(3);
		}
		
		%obj.zombieInWater = true;
		return parent::onEnterLiquid(%this, %obj);
	}
	
	function Armor::onLeaveLiquid(%this, %obj)
	{
		%obj.zombieInWater = false;
		return parent::onLeaveLiquid(%this, %obj);
	}
	
	// Burn, Baby, Burn!
	function Player::burnLoop(%obj, %loopRuns, %loopDamage, %source)
	{
		if(%obj.getType() & $TypeMasks::PlayerObjectType && %obj.getState() !$= "Dead")
		{
			%db = %obj.getDatablock();
			
			if(!%obj.zombieInWater)
			{
				if(!%obj.isZombie)
				{
					%damage = %loopDamage;
					%damageType = $DamageType::Burning;
					%loopRuns--;
					%pos = %obj.getPosition();
				}
				else
				{
					%damage = %loopDamage * 1.25;
					%damageType = $DamageType::Burning;
					%pos = %obj.getPosition();
					
					// Algorithm to recalculate damage if it would not kill the zombie in 45s.
					if(%damage * 45 < %db.maxDamage)
					{
						%damage = mCeil((%db.maxDamage / 45) * getWord(%obj.getScale(), 2));
					}
				}
				
				%obj.mountImage("PlayerNapalmBurnImage", 3);
				%obj.damage(%source, %pos, %damage, %damageType);
				
				if(isObject(%obj) && %obj.getState() !$= "Dead")
				{
					%obj.setTempColor("0 0 0 1", 1000);
					%obj.setDamageFlash(50);
					
					cancel(%obj.damageBurnSched);
					
					if(!%db.fireRetardant && %loopRuns > 0)
					{
						%obj.damageBurnSched = %obj.schedule(1000, "burnLoop", %loopRuns, %loopDamage, %source);
						%obj.damageBurnLoops = %loopRuns;
						%obj.damageBurnDamage = %loopDamage;
					}
					else
					{
						%obj.damageBurnLoops = 0;
						%obj.damageBurnDamage = 0;
						%obj.unMountImage(3);
					}
				}
			}
			else if(%obj.zombieOnFire())
			{
				%obj.damageBurnLoops = 0;
				%obj.damageBurnDamage = 0;
				%obj.unMountImage(3);
			}
		}
	}

	function Player::zombieOnFire(%obj)
	{
		if(isEventPending(%obj.damageBurnSched) ||
			(isObject(%obj.getMountedImage(3) && %obj.getMountedImage(3).getID() == PlayerNapalmBurnImage.getID())))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// This function is specific to ZAPT's Friendly-Fire system.
	// Without ZAPT, there can NEVER be an instance of Friendly-Fire in my system.
	// TDM FF detection works entirely independantly of this.
	function zombieFriendlyFire(%obj1, %obj2)
	{
		return false;
	}
	
	// Saves time.
	function zombieSameGame(%obj1, %obj2)
	{
		if(isObject(%obj1) && isObject(%obj2))
		{
			%obj1mini = getMiniGameFromObject(%obj1);
			
			if(isObject(%obj1mini))
			{
				%obj2mini = getMiniGameFromObject(%obj2);
				
				if(isObject(%obj2mini) && %obj1mini.getID() == %obj2mini.getID())
				{
					return true;
				}
			}
		}
		
		return false;
	}
};

// ============================================================
// Section 3 : Script
// ============================================================
// Molotov Image
function ZombieMolotovImage::onCharge(%this, %obj, %slot)
{
	%obj.playThread(2, "spearReady");
	%obj.zombieMolotovSlot = %obj.currTool;
}

function ZombieMolotovImage::onChargeAborted(%this, %obj, %slot)
{
	%obj.playThread(2, "ready");
}

function ZombieMolotovImage::onDone(%this, %obj, %slot)
{
	%obj.unMountImage(%slot);
}

function ZombieMolotovImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, "spearThrow");
	%molotovSlot = %obj.zombieMolotovSlot;
	%obj.zombieMolotovSlot = -1;
	%client = %obj.client;
	
	%proj = parent::onFire(%this, %obj, %slot);
	
	%obj.tool[%molotovSlot] = 0;
	%obj.weaponCount--;
	
	if(isObject(%client))
	{
		messageClient(%client, 'MsgItemPickup', '', %molotovSlot, 0);
		serverCmdUnUseTool(%client);
	}
	
	return %proj;
}

// Molotov Projectile
function ZombieMolotovProjectile::continuousDamage(%this, %obj, %source, %pos, %radius, %damage, %damageType, %duration)
{
	if(%damage > 0)
	{
		%searchMask = $TypeMasks::PlayerObjectType;
		%rayMasks = ($TypeMasks::FxBrickObjectType | $TypeMasks::StaticObjectType);
		initContainerRadiusSearch(%pos, %radius, %searchMask);
		
		%col = containerSearchNext();
		
		while(isObject(%col))
		{
			if(!zombieSameGame(%source, %col) || !miniGameCanDamage(%source, %col))
			{
				%col = containerSearchNext();
				continue;
			}
			
			%hit = getWord(containerRayCast(%pos, %col.getEyePoint(), %rayMasks), 0);
			
			if(!isObject(%hit))
			{
				// Friendly Fire and/or Self Damage
				if(zombieFriendlyFire(%source, %col) || (isObject(%source) && %source.getID() == %col.getID()))
				{
					// Just damage them.
					%col.damage(%source, %pos, %damage, $DamageType::Fire);
					%col.burn(1000);
				}
				else
				{
					%col.burnLoop(6, %damage, %source);
				}
			}
			
			%col = containerSearchNext();
		}
		
		// Keep looping.
		if(%duration > 0)
		{
			%this.schedule(250, "continuousDamage", %obj, %source, %pos, %radius, %damage, %damagetype, %duration - 250);
		}
	}
}

function ZombieMolotovProjectile::onExplode(%this, %obj, %pos, %fade)
{
	%this.continuousDamage(%obj, %obj.client, %pos, %this.explosion.damageRadius, %this.explosion.radiusDamage / 4, %this.radiusDamageType, 10000);
	return parent::onExplode(%this, %obj, %pos, %fade);
}

if($AddOn__GameMode_ZAPT !$= "1" || !isFile("Add-Ons/GameMode_ZAPT/server.cs"))
{
	activatePackage(Weapon_Molotov_Package);
}