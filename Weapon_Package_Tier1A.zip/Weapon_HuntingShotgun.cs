
datablock AudioProfile(SingleShotgunFireSound)
{
   filename    = "./super_Shotgun_fire2.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("SingleShotgun",   '<bitmap:add-ons/Weapon_Package_Tier1A/huntingshotgun_CI> %1',    '%2 <bitmap:add-ons/Weapon_Package_Tier1A/huntingshotgun_CI> %1',0.75,1);
datablock ProjectileData(SingleShotgunProjectile : PumpShotgunProjectile)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 9; //14
   directDamageType    = $DamageType::SingleShotgun;
};

datablock ProjectileData(SingleShotgunBlastProjectile : ShotgunBlastProjectile)
{
   directDamage        = 98; //14
   directDamageType    = $DamageType::SingleShotgun;
};

//////////
// item //
//////////
datablock ItemData(SingleShotgunItem : PumpShotgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	 // Basic Item Properties
	shapeFile = "./Single_Shotgun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	//gui stuff
	uiName = "Single Shotgun";
	iconName = "./SingleShotgun";
	doColorShift = true;
	colorShiftColor = "0.43 0.38 0.3 1";
	 // Dynamic properties defined by the scripts
	image = SingleShotgunImage;
	canDrop = true;
	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(SingleShotgunImage)
{
   // Basic Item properties
	shapeFile = "./Single_Shotgun.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0.03 -.02";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
   correctMuzzleVector = true;
   className = "WeaponImage";
   item = SingleShotgunItem;
   ammo = " ";
   projectile = SingleShotgunProjectile;
   projectileType = Projectile;
   casing = PumpShotgunShellDebris;
	armready = true;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;
   doColorShift = true;
   colorShiftColor = SingleShotgunItem.colorShiftColor;

	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.05;
	stateTransitionOnTimeout[0]       = "FireLoadCheckA";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnNoAmmo[1]		= "ReloadStart";
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Delay";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                  = "Fire";
	stateScript[2]                  = "onFire";
	stateSound[2]					= SingleShotgunFireSound;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateWaitForTimeout[2]			= true;

	stateName[3]			= "Delay";
	stateTransitionOnTimeout[3]     = "ReloadStart";
	stateTimeoutValue[3]            = 0.1;
	stateSequence[3]                  = "Reload";
	stateEmitterTime[3]				= 0.03;
	stateEmitterNode[3]				= "muzzleNode";
	
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 0.3;
	stateScript[6]				= "onReloadStart";
	stateSequence[6]                  = "reload_Open";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.3;
	stateSequence[7]                  = "reload_Close";
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadStart";
	
	stateName[10] 				= "Smoke";
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Halt";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
	
	stateName[12]				= "Reloaded";
	stateTimeoutValue[12]			= 0.04;
	stateScript[12]				= "onReloaded";
	stateTransitionOnTimeout[12]		= "Ready";

	stateName[13]			= "Halt";
	stateTransitionOnTimeout[13]     = "Ready";
	stateTimeoutValue[13]            = 0.9;
	stateEmitterTime[13]				= 0.48;
	stateEmitterNode[13]				= "muzzleNode";
	stateScript[13]                  = "onHalt";

	stateName[14]                    = "Charge";
	stateTransitionOnTimeout[14]	= "Armed";
	stateTimeoutValue[14]            = 0.8;
	stateWaitForTimeout[14]		= false;
	stateScript[14]                  = "onCharge";
	stateAllowImageChange[14]        = false;
	stateSound[14]					= SingleShotgunFireSound;

	stateName[15]			= "Armed";
	stateTransitionOnTriggerUp[15]	= "Fire";
	stateAllowImageChange[15]	= false;
	stateScript[15]                  = "onArmed";
	stateSound[15]				= Block_PlantBrick_Sound;

	stateName[16]                     = "ReloadStart";
	stateTransitionOnTimeout[16]  = "ReloadStartB";
	stateTimeoutValue[16]            = 0.1;
	stateAllowImageChange[16]         = false;

	stateName[17]                     = "ReloadStartB";
	stateTransitionOnTimeout[17]  = "LoadCheckA";
	stateTimeoutValue[17]            = 0.01;
	stateAllowImageChange[17]         = true;
};

function SingleShotgunImage::onFire(%this,%obj,%slot)
{

	if(%obj.toolAmmo[%obj.currTool] > 0)
	{

  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
            serverPlay3D(SingleShotgunfireSound,%obj.getPosition());
	%obj.playThread(2, activate);
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.toolAmmo[%obj.currTool]--;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-4")));
	%obj.spawnExplosion(TTBigRecoilProjectile,"1 1 1");

	%projectile = %this.projectile;
	%spread = 0.0014;
	%shellcount = 5;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	
	//shotgun blast projectile: only effective at point blank, sends targets flying off into the distance
	//
	//more or less represents the concussion blast. i can only assume such a thing exists because
	// i've never stood infront of a fucking shotgun before
	///////////////////////////////////////////////////////////

	%projectile = "SingleShotgunBlastProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;

	//just the muzzleflash
	//
	//nothing really special about this
	///////////////////////////////////////////////////////////

	%projectile = "shotgunFlashProjectile";
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	

	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	MissionCleanup.add(%p);
	return %p;
}
	else
	{
            serverPlay3D(PumpShotgunJamSound,%obj.getPosition());
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}
}

function SingleShotgunImage::onEject(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
           		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}
}

function SingleShotgunImage::onReloadStart(%this,%obj,%slot)
{
    if(%obj.client.quantity["shotgunrounds"] >= 1)
	{
	%obj.playThread(2, shiftDown);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
}

function SingleShotgunImage::onReloadWait(%this,%obj,%slot)
{
	%obj.playThread(2, shiftUp);
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
}

function SingleShotgunImage::onReady(%this,%obj,%slot)
{	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}
}

function SingleShotgunImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["shotgunrounds"] >= 1)
	{
		%obj.client.quantity["shotgunrounds"]--;
		%obj.toolAmmo[%obj.currTool]++;
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>12-gauge shotgun <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["shotgunrounds"] @ "", 4, 2, 3, 4); 
	}
}