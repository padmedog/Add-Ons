//Seeing how well executing other bots in one archive works
if(LoadRequiredAddOn("Bot_Hole") == $Error::None)
	exec("./bot_scientist.cs");
	exec("./bot_chef.cs");
	exec("./bot_cop.cs");
	exec("./bot_prisoner.cs");
	exec("./bot_businessman.cs");
	exec("./bot_spaceman.cs");