%error = ForceRequiredAddOn("JVS_Content");

if(%error == $Error::AddOn_NotFound)
{
	error("JVS_DoorsPack0: JVS_Content is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack2/types/GlassDoubleDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack2/types/ManholeCover.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack2/types/RollingVaultDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack2/types/SlidingDoor.cs");
	ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack2/types/WoodenDoubleDoor.cs");
}
