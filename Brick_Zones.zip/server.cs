


%errorA = ForceRequiredAddOn("Brick_Large_Cubes");
%errorB = ForceRequiredAddOn("Event_Zones");





if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Brick_Zones - required add-on Brick_Large_Cubes not found");
else if(%errorB == $Error::AddOn_NotFound)
   error("ERROR: Brick_Zones - required add-on Event_zones not found");
else
   exec("./Bricks.cs"); 