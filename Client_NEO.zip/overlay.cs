//overlay.cs
$neo_dragging = false;

if(EscapeMenu.isAwake())
{
	//in case of this being executed at a weird point
	canvas.popdialog(EscapeMenu);
}

while(isobject(NARGEscapeOverlay))
	NARGEscapeOverlay.delete();
exec("./overlay.gui");

function EscapeOverlay_List::newButton(%this, %row, %column, %command)
{
	%icon = %command.icon;

	if($neo::pref::buttonsize > $neo::defaultpref::buttonsize && $neo::pref::imageScaling)
	{
		%largepath = nfm_trimFileName(%command.icon) @ "large/" @ filename(%command.icon);
		%medpath = nfm_trimFileName(%command.icon) @ "medium/" @ filename(%command.icon);

		if(isfile(%medpath))
			%icon = %medpath;

		if($neo::pref::buttonsize > 144 && isfile(%largepath)) //I try to avoid hard coded values but making a pref for this is dumb
			%icon = %largepath;
	}

	%gui = new GuiSwatchCtrl()
	{
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = (4 + ($neo::pref::buttonsize + 8)*%column) SPC (4 + ($neo::pref::buttonsize + 8)*%row);
		extent = $neo::pref::buttonsize SPC $neo::pref::buttonsize;
		minExtent = "8 2";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
		color = $neo::pref::buttonColorIdle;

		new GuiBitmapCtrl()
		{
			profile = "GuiDefaultProfile";
			horizSizing = "center";
			vertSizing = "center";
			//position = "16 16";
			//extent = "64 64";
			position = mfloor($neo::pref::buttonsize/6) SPC mfloor($neo::pref::buttonsize/6);
			extent = mceil(($neo::pref::buttonsize*2)/3) SPC mceil(($neo::pref::buttonsize*2)/3);
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			bitmap = %icon;
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};

		new GuiMLTextCtrl()
		{
			profile = "GuiMLTextProfile";
			horizSizing = "width";
			vertSizing = "top";
			//position = "0 78";
			//extent = "96 18";
			position = 0 SPC $neo::pref::buttonsize - 18;
			extent = $neo::pref::buttonsize SPC 18;
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "-1";
			text = "<font:impact:18><just:center><color:ffffff>" @ %command.name;
			maxBitmapHeight = "-1";
			selectable = "1";
			autoResize = "1";
		};

		new GuiMouseEventCtrl(neobutton)
		{
			profile = "GuiDefaultProfile";
			horizSizing = "width";
			vertSizing = "height";
			position = "0 0";
			extent = $neo::pref::buttonsize SPC $neo::pref::buttonsize;
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lockMouse = "0";
			commandObj = %command;
		};
	};
	%this.add(%gui);

	%mltext = %gui.getobject(1);
	%mltext.forceReflow();
	%height = getword(%mltext.getextent(), 1);

	if(%height > $neo::pref::buttonsize)
		%height = $neo::pref::buttonsize;
	%mltext.resize(0, $neo::pref::buttonsize - %height, $neo::pref::buttonsize, %height);
}

function NARGEscapeOverlay::playAnimation(%this)
{
	if(iseventpending(%this.animationsched))
		cancel(%this.animationsched);

	if($neo::pref::animate)
	{
		$neo_animating = true;
		neo_dragdisplay.setVisible(1);

		while(EscapeOverlay_List.getCount() > 0)
		{
			%obj = EscapeOverlay_List.getObject(0);
			%obj.originalpos = %obj.getposition();
			%obj.destpos = %obj.nfm_getscreenpos();
			%obj.startpos = (getRandom()*(getword(getres(), 0) + 32 + 2*$neo::pref::buttonsize) - 16 - $neo::pref::buttonsize) SPC (-2*$neo::pref::buttonsize - 64);
			neo_dragdisplay.add(%obj);
		}
	}
	%this.tickAnimation(0, $neo::pref::animationticks);
}

function NARGEscapeOverlay::tickAnimation(%this, %tick, %maxticks)
{
	if(iseventpending(%this.animationsched))
		cancel(%this.animationsched);

	if(%tick >= %maxticks)
	{
		%this.endAnimation();
		return;
	}

	if($neo::pref::fadein)
	{
		%this.getobject(0).setColor(getwords($neo::pref::backgroundColor, 0, 2) SPC mceil(getword($neo::pref::backgroundColor, 3)*(%tick/%maxticks)));
		%this.getobject(0).getobject(0).setColor(getwords($neo::pref::backgroundColor, 0, 2) SPC mceil(getword($neo::pref::backgroundColor, 3)*(2/3)*(%tick/%maxticks)));
	}

	for(%i=0; %i<neo_dragdisplay.getCount(); %i++)
	{
		//asdf to do
		%obj = neo_dragdisplay.getobject(%i);
		%factor = mpow((%tick/%maxticks), 0.125);
		%pos = vectoradd(vectorscale(%obj.startpos, 1-%factor), vectorscale(%obj.destpos, %factor));
		%obj.resize(getword(%pos, 0), getword(%pos, 1), $neo::pref::buttonsize, $neo::pref::buttonsize);
	}
	%this.animationsched = %this.schedule(16, "tickAnimation", %tick + 1, %maxticks);
}

function NARGEscapeOverlay::endAnimation(%this)
{
	if(iseventpending(%this.animationsched))
		cancel(%this.animationsched);
	%this.getobject(0).setColor($neo::pref::backgroundColor);
	%this.getobject(0).getobject(0).setColor(getwords($neo::pref::backgroundColor, 0, 2) SPC mceil(getword($neo::pref::backgroundColor, 3)*(2/3)));

	while(neo_dragdisplay.getCount() > 0)
	{
		%obj = neo_dragdisplay.getobject(0);
		EscapeOverlay_List.add(%obj);
		%obj.resize(getword(%obj.originalpos, 0), getword(%obj.originalpos, 1), $neo::pref::buttonsize, $neo::pref::buttonsize);
	}
	neo_dragdisplay.setvisible(0);
	$neo_animating = false;
}

//we can't package onWake since the gui is not resized at the time onwake is called
//we also can't just do this after pushing the dialog since apparently the resizing is asynchronous
function NARGEscapeOverlay::onRender(%this)
{
	neo_debug("render");
	neomain.maintain();
	neomain.draw();

	if(neomain.firstload)
	{
		neomain.firstload = false;
		canvas.pushdialog(neo_tutorial);
		neomain.savedata();
	}

	if(!$neo_versionchecked && $neo::pref::versioncheck)
	{
		narg_versioncheck(0, "NEO", $neo_version);
		$neo_versionchecked = true;
	}

	if($neo::pref::fadein || $neo::pref::animate)
		NARGEscapeOverlay.playAnimation();
}

function NARGEscapeOverlay::onSleep(%this)
{
	//for some reason .isawake() is true but the console will complain that its not
	if(iseventpending(%this.animationsched))
		%this.endAnimation();
	%this.schedule(1, "verifysleep");
}

function NARGEscapeOverlay::verifysleep(%this)
{
	if(EscapeMenu.isAwake())
		canvas.popdialog(EscapeMenu);
}

if(!isfunction("EscapeMenu", "onSleep"))
	eval("function EscapeMenu::onSleep(%this){}");

package NARGEscapeOverlay
{
	function EscapeMenu::onWake(%this)
	{
		//apparently you can't directly set the guicontrol to be invisible
		%this.getObject(0).setVisible(0);

		parent::onWake(%this);
		canvas.pushdialog(NARGEscapeOverlay);
	}

	function optionsDlg::applyGraphics(%this)
	{
		%ret = parent::applyGraphics(%this);
		neomain.forcedraw();
		return %ret;
	}

	function EscapeMenu::onSleep(%this)
	{
		parent::onSleep(%this);
		canvas.popdialog(NARGEscapeOverlay);
	}
};
activatepackage(NARGEscapeOverlay);

//package NARGEscapeOverlay_EMOS
//{
//	function EscapeMenu::onSleep(%this)
//	{
//		parent::onSleep(%this);
//		canvas.popdialog(NARGEscapeOverlay);
//	}
//};
//
//if(isfunction("EscapeMenu", "onSleep") && !$neo_emos)
//{
//	activatepackage(NARGEscapeOverlay_EMOS);
//	return;
//}
//$neo_emos = true;
//
//function EscapeMenu::onSleep(%this)
//{
//	canvas.popdialog(NARGEscapeOverlay);
//}

