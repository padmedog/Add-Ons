//////////
// item //
//////////
datablock ItemData(LaspistolItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "Add-Ons/Weapon_WH40k_Imperium/Laspistol.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Laspistol";
	iconName = "./Laspistol";
	doColorShift = false;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = LaspistolImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 25;
	canReload = 1;
};

AddDamageType("Laspistol",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_Laspistol> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_Laspistol> %1',0.75,1);

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(LaspistolImage)
{

   // Basic Item properties
	shapeFile = "Add-Ons/Weapon_WH40k_Imperium/Laspistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = LaspistolItem;
   ammo = " ";
   projectile = LasrifleTracerProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = LaspistolItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 400; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = LasrifleExplosionProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 17; //10
   raycastDirectDamageType = $DamageType::Laspistol;
   raycastSpreadAmt = 0.0018; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = LasrifleTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.00;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= LasriflefireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[2]              = false;
	stateTimeoutValue[4]		= 0.30;
	stateScript[4]                  = "onBounce";
	stateTransitionOnTimeout[4]	= "Ready";

};

function LaspistolImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0036;
		%this.raycastWeaponRange = 400;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0018;
		%this.raycastWeaponRange = 400;
	}

		Parent::onFire(%this,%obj,%slot);
	%obj.playThread(2, shiftAway);	
}

