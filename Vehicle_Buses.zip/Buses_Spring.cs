// buses_spring.cs

datablock WheeledVehicleSpring(busesSpring)
{
   // Wheel suspension properties
   length = 0.4;			 // Suspension travel
   force = 7000; //3000;		 // Spring force
   damping = 600; //600;		 // Spring damping
   antiSwayForce = 6; //6;		 // Lateral anti-sway force
};


