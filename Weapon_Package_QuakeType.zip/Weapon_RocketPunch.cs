//gun.cs


datablock AudioProfile(quakeRocketPunchSound)
{
   filename    = "./rocket_punch_hit.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(quakeRocketPunchFireSound)
{
   filename    = "./rocket_punch_fire.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ExplosionData(quakeRocketPunchExplosion : quakeRocketExplosion)
{
   //explosionShape = "";
	soundProfile = quakeRocketPunchSound;

   impulseRadius = 3;
   impulseForce = 2000;
};


AddDamageType("quakeRocketPunch",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_rocketpunch> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_rocketpunch> %1',0.2,1);
datablock ProjectileData(quakeRocketPunchProjectile : quakeShotgunBlastProjectile)
{
   directDamageType    = $DamageType::quakeRocketPunch;
   radiusDamageType    = $DamageType::quakeRocketPunch;
   projectileShapeName = "";
   directDamage        = 150;
	particleemitter = "";
	explosion = quakeRocketPunchExplosion;
	muzzlevelocity = 200;
	impactimpulse = 2000;
   verticalImpulse	  = 1100;
};

//////////
// item //
//////////
datablock ItemData(quakeRocketPunchItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./rocket_punch.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Rocket Punch";
	iconName = "./rocketpunch";
	doColorShift = true;
	colorShiftColor = "0.85 0.88 0.88 1.000";

	 // Dynamic properties defined by the scripts
	image = quakeRocketPunchImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(quakeRocketPunchImage)
{
   raycastWeaponRange = 8; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = quakeRocketPunchProjectile;
   raycastExplosionBrickSound = rocketPunchHitSound;
   raycastExplosionPlayerSound = rocketPunchHitSound;
   raycastDirectDamage = 150; //10
   raycastDirectDamageType = $DamageType::quakeRocketPunch;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Basic Item properties
	shapeFile = "./rocket_punch.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 -0.05";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = quakeRocketPunchProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 9.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = quakeRocketPunchItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Boltback";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.15;
	stateFire[2]                    = true;
	stateSequence[2]                = "Fire";
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= quakerocketFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= quakeShotgunFireSound;
	stateEjectShell[2]       = true;

	stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.38;
	stateTransitionOnTimeout[3]     = "Boltback";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";

	stateName[5] = "Boltback";
	stateSound[5]					= sawbladeRifleClickSound;
	stateTimeoutValue[5]            = 0.3;
	stateSequence[5]                = "Reload";
	stateTransitionOnTimeout[5]     = "Wait";

	stateName[6] = "Wait";
	stateTimeoutValue[6]            = 0.3;
	stateTransitionOnTimeout[6]     = "Ready";
	stateScript[6]                  = "onBoltback";
};

function quakeRocketPunchImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(0, shiftLeft);
	%obj.playThread(2, shiftRight);	
	
	Parent::onFire(%this,%obj,%slot);
}
