if(!isObject(BossBattlesGUI))
{
	new GuiControlProfile(BBGUI_TextProfile)
	{
		fontColor = "0 0 0 255";
		fontType = "Arial";
		fontSize = "14";
		justify = "Left";
		fontColors[1] = "255 0 0 255";
		fontColors[2] = "0 255 0 255";  
		fontColors[3] = "0 0 255 255"; 
		fontColors[4] = "127 0 0 255"; 
		fontColors[5] = "255 255 0 255";
		fontColors[6] = "255 0 255 255";
		fontColorLink = "255 96 96 255";
		fontColorLinkHL = "0 0 255 255";
	};
	exec("./BBGUI.gui");
}

$BBGUIVersion = 1.0;

//addClass - Registers a class script object for use with the GUI.
function BossBattlesGUI::addClass(%this, %name, %dispName, %descript, %group, %health, %speed, %other, %price, %item1, %item2, %item3, %item4, %item5)
{
	if(!isObject(BossBattlesClassGroup))
	{
		new simGroup(BossBattlesClassGroup);
		ServerConnection.add(BossBattlesClassGroup); //Put it somewhere that I don't have to worry about deleting it later.
	}
	if(isObject(%existing = "BossBattlesClass_" @ %name))
		%existing.delete();
	%playerClass = new ScriptObject("BossBattlesClass_" @ %name)
	{
		realName = %name;
		name = %dispName;
		description = %descript;
		group = %group;
		health = %health;
		speed = %speed;
		price = %price;
		otherString = %other;
		item[1] = %item1;
		item[2] = %item2;
		item[3] = %item3;
		item[4] = %item4;
		item[5] = %item5;
	};
	BossBattlesClassGroup.add(%playerClass);
}

//setBlocker - Helper method for enabling and disabling blockers.
function BossBattlesGUI::setBlocker(%this, %index, %value)
{
	switch(%index)
	{
		case 0:
			%obj = BBGUI_BlockerPlay;
		case 1:
			%obj = BBGUI_BlockerType1;
		case 2:
			%obj = BBGUI_BlockerType2;
		case 3:
			%obj = BBGUI_BlockerType3;
		case 4:
			%obj = BBGUI_BlockerType4;
		//case 5:
		//	%obj = BBGUI_BlockerAkimbo;
		//case 6:
		//	%obj = BBGUI_BlockerLife;
		default:
			return;
	}
	switch(%value)
	{
		case 0: //Enable the button.
			%obj.setVisible(0);
		case 1: //Disable the button.
			%obj.setVisible(1);
			%obj.setColor("200 200 200 200");
		case 2: //Hide the button.
			%obj.setVisible(1);
			%obj.setColor("200 200 200 255");
	}
}

//loadClassGroup - loads all classes from a group into the class list.
function BossBattlesGUI::loadClassGroup(%this, %group)
{
	if(!isObject(BossBattlesClassGroup))
		return;
	BBGUI_ClassList.clear();
	%count = BossBattlesClassGroup.getCount();
	%classCount = 0;
	for(%i = 0; %i < %count; %i++)
	{
		%playerclass = BossBattlesClassGroup.getObject(%i);
		if(%playerclass.group != %group)
			continue;
		BBGUI_ClassList.classObj[%i] = %playerclass; //To easily translate an ID back into a class.
		BBGUI_ClassList.addRow(%i, %playerclass.name);
	}
	BBGUI_ClassList.sort(0, true);
}

//selectClass - Dispalys a class's stats on the GUI.
function BossBattlesGUI::selectClass(%this, %obj)
{
	if(!isObject(%obj))
	{
		BBGUI_ClassName.setText("<font:impact:25>No class");
		BBGUI_ClassDescript.setText("No class has been selected.");
		BBGUI_ClassHealth.setText("Health: ");
		BBGUI_ClassSpeed.setText("Speed: ");
		BBGUI_ClassPrice.setText("");
		BBGUI_ClassItems.setText("Items: ");
		BBGUI_ClassOther.setText("Other: ");
		BBGUI_InfoText.setText(%this.infoString);
		%this.setBlocker(0, 1);
		%this.currClass = 0;
		return;
	}
	switch(%obj.group)
	{
		case 1:
			%groupString = "<color:ffff00>Class";
		case 2:
			%groupString = "<color:EC7000>Miniboss";
		case 3:
			%groupString = "<color:ff0000>Boss";
		case 4:
			%groupString = "<color:ff00ff>Special";
		default:
			%groupString = "<color:000000>Class";
	}
	BBGUI_ClassName.setText("<font:impact:25>" @ %groupString @ "<color:000000>: " @ %obj.name);
	BBGUI_ClassDescript.setText(%obj.description);
	BBGUI_ClassHealth.setText("Health: " @ %obj.health);
	BBGUI_ClassSpeed.setText("Speed: " @ %obj.speed);
	if(%obj.price > 0)
	{
		%priceColor = (%this.currScore < %obj.price) ? "\c1" : "\c0";
		BBGUI_ClassPrice.setText(%priceColor @ "Price: " @ %obj.price);
	}
	else
		BBGUI_ClassPrice.setText("");
	%itemString = "Items: ";
	for(%i = 1; %i <= 5; %i++)
		if(%obj.item[%i] !$= "")
			%itemString = %itemString NL %obj.item[%i];
	BBGUI_ClassItems.setText(%itemString);
	BBGUI_ClassOther.setText("Other: " @ %obj.otherString);
	%this.currClass = %obj;
	%this.updateInfoString();
}

//onSelect - Called upon clicking a class in the list.
function BBGUI_ClassList::onSelect(%this, %id)
{
	//%id = BBGUI_ClassList.getId();
	%this.currClass[BossBattlesGUI.currGroup] = %id;
	if(%id == -1)
		BossBattlesGUI.selectClass(0);
	else
		BossBattlesGUI.selectClass(%this.classObj[%id]);
}

//onPickGroup - Called upon clicking one of the class buttons.
function BossBattlesGUI::onPickGroup(%this, %group)
{
	%this.loadClassGroup(%group);
	%this.currGroup = %group;
	if(BBGUI_ClassList.classObj[BBGUI_ClassList.currClass[%this.currGroup]].group != %group)
		BBGUI_ClassList.onSelect(-1);
	else
		BBGUI_ClassList.setSelectedByID(BBGUI_ClassList.currClass[%this.currGroup]);
}

function BossBattlesGUI::onClickPlay(%this)
{
	%selectedClass = BBGUI_ClassList.classObj[BBGUI_ClassList.currClass[%this.currGroup]];
	if(isObject(%selectedClass))
		commandToServer('SelectClass', %selectedClass.realName);
}

//onWake - Called when the GUI opens.
function BossBattlesGUI::onWake(%this)
{
	if(!%this.currGroup)
		%this.currGroup = 1;
	if(%this.currGroup == 3 && BBGUI_BlockerType3.isVisible() || %this.currGroup == 4 && BBGUI_BlockerType4.isVisible())
		%this.currGroup = 1;
	if(%this.currGroup == 1 && BBGUI_BlockerType1.isVisible() || %this.currGroup == 2 && BBGUI_BlockerType2.isVisible())
		%this.currGroup = 3;
	%this.onPickGroup(%this.currGroup);
}

//newRound - Resets values for a new round.
function BossBattlesGUI::newRound(%this)
{
	%this.minibossFull = 0;
	%count = BossBattlesClassGroup.getCount();
	for(%i = 0; %i < %count; %i++)
	{
		%playerclass = BossBattlesClassGroup.getObject(%i);
		%playerClass.errorFull = 0;
	}
}

//updateInfoString - Sets the info string to an error if there is one, or the given string otherwise.
function BossBattlesGUI::updateInfoString(%this)
{
	%obj = %this.currClass;
	if(isObject(%obj))
	{
		if(%obj.error !$= "")
			%errorString = %obj.error;
		else if(%this.currScore < %obj.price && %obj.price > 0)
			%errorString = "\c1Error: You don't have enough points to afford this class.";
		else if(%obj.errorFull == 1)
			%errorString = "\c1Error: This class has been taken this round.";
		else if(%obj.errorFull > 1)
			%errorString = "\c1Error: This class is full to capacity this round.";
		else if(%this.minibossFull && %obj.group == 2)
			%errorString = "\c1Error: Miniboss capacity reached this round.";
	}
	if(%errorString $= "")
	{
		BBGUI_InfoText.setText(%this.infoString);
		%this.setBlocker(0, 0);
	}
	else
	{
		BBGUI_InfoText.setText(%errorString);
		%this.setBlocker(0, 1);
	}
}

//clientCmdBBGUI - Huge function for all client commands.
function clientCmdBBGUI(%action, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13) //Cramming this all into one function.
{
	%gui = BossBattlesGUI;
	%list = BBGUI_ClassList;
	switch$(%action)
	{
		case "handshake": //So I don't have to package anything to see if it's the Boss Battles server.
			commandToServer('BBGUIHandshake', $BBGUIVersion);
		case "setScore": //Sets the score shown on the points label.
			%gui.currScore = %a1;
			BBGUI_Score.setText("Points: " @ %a1);
			if(%gui.currClass.price > 0)
				%gui.updateInfoString();
		case "wakeGUI": //Opens the GUI.
			canvas.pushDialog(%gui);
			if(newMessageHud.isAwake())
			{
				canvas.popDialog(newMessageHud);
				canvas.pushDialog(newMessageHud);
			}
		case "closeGUI": //Closes the GUI.
			canvas.popDialog(%gui);
		case "addClass":
			%gui.addClass(%a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13);
			if(%gui.isAwake() && %gui.currGroup == %a4)
				%gui.onPickGroup(%gui.currGroup);
		case "setTeam": //Fast way to set the button blockers.
			switch(%a1)
			{
				case 0: //Normals team
					%gui.setBlocker(1, 0);
					%gui.setBlocker(2, 0);
					%gui.setBlocker(3, 1);
					%gui.setBlocker(4, 2);
					%gui.setBlocker(5, 2);
					%gui.setBlocker(6, 2);
					if(%gui.currGroup > 2)
						%gui.currGroup = 1;
				case 1: //Boss team
					%gui.setBlocker(1, 1);
					%gui.setBlocker(2, 1);
					%gui.setBlocker(3, 0);
					%gui.setBlocker(4, 2);
					%gui.setBlocker(5, 2);
					%gui.setBlocker(6, 2);
					%gui.currGroup = 3;
				case 2: //Normals exclusive team
					%gui.setBlocker(1, 0);
					%gui.setBlocker(2, 1);
					%gui.setBlocker(3, 1);
					%gui.setBlocker(4, 2);
					%gui.setBlocker(5, 2);
					%gui.setBlocker(6, 2);
					%gui.currGroup = 1;
				case 3: //Mini-boss exclusive team
					%gui.setBlocker(1, 1);
					%gui.setBlocker(2, 0);
					%gui.setBlocker(3, 1);
					%gui.setBlocker(4, 2);
					%gui.setBlocker(5, 2);
					%gui.setBlocker(6, 2);
					%gui.currGroup = 2;
				case 4: //Debug team
					%gui.setBlocker(1, 0);
					%gui.setBlocker(2, 0);
					%gui.setBlocker(3, 0);
					%gui.setBlocker(4, 0);
					%gui.setBlocker(5, 2);
					%gui.setBlocker(6, 2);
			}
		case "setBlockers": //Manual way to adjust button blockers.
			if(%a3 !$= "")
			{
				%gui.setBlocker(1, %a1);
				%gui.setBlocker(2, %a2);
				%gui.setBlocker(3, %a3);
				%gui.setBlocker(4, %a4);
				%gui.setBlocker(5, %a5);
				%gui.setBlocker(6, %a6);
			}
			else
				%gui.setBlocker(%a1, %a2);
		case "setInfoString": //Sets the message telling who the boss is.
			switch(%a1)
			{
				case 0:
					%gui.infoString = "";
				case 1:
					%gui.bossPlayerName = %a2;
					%gui.bossPlayerClass = %a3;
					%gui.infoString = "Current boss: \c1" @ %a2 @ "\c0 as \c1" @ %a3 @ "\c0.";
				case 2:
					%gui.bossPlayerName = %a2;
					%gui.bossPlayerClass = "";
					%gui.infoString = "Current boss: \c1" @ %a2 @ "\c0 is choosing a class.";
				case 3:
					%gui.infoString = %a2;
			}
			%gui.updateInfoString();
		case "setMinibossFull": //Sets a variable determining if the minibosses are full to capacity.
			%gui.minibossFull = %a1;
			%gui.updateInfoString();
		case "setClassFull": //Sets whether a class is full. Can use a value greater than 1 to display a plural error.
			%classObject = "BossBattlesClass_" @ %a1;
			if(!isObject(%classObject))
				return;
			%classObject.errorFull = %a2;
			%gui.updateInfoString();
		case "setClassError": //Sets a general error for a class.
			%classObject = "BossBattlesClass_" @ %a1;
			if(!isObject(%classObject))
				return;
			%classObject.error = %a2;
			%gui.updateInfoString();
		case "removeClass": //Deletes a class.
			%classObject = "BossBattlesClass_" @ %a1;
			if(!isObject(%classObject))
				return;
			%group = %classObject.group;
			%classObject.delete();
			if(%gui.isAwake() && %gui.currGroup == %group)
				%gui.onPickGroup(%gui.currGroup);
		case "clearClasses": //Drops the current list of classes.
			if(isObject(BossBattlesClassGroup))
				BossBattlesClassGroup.delete();
			if(%gui.isAwake())
				%gui.onPickGroup(%gui.currGroup);
		case "newRound": //Calls the new round method.
			%gui.newRound();
			if(%a1 !$= "")
				clientCmdBBGUI("setTeam", %a1);
		case "setItemPurchase": //Sets the color of the item purchase buttons.
			%button = %a1 ? BBGUI_ButtonLife : BBGUI_ButtonAkimbo;
			%color = %a2 ? "0 255 0 255" : "255 0 0 255";
			%button.setColor(%color);
		default:
			echo("Error: clientCmdBBGUI - Unknown parameter: " @ %action);
	}
}

function createTestBBClasses()
{
	bossbattlesgui.addclass("Test1", "Seymour Butt", "Has anyone even been so far", 1, 100, "Fast", "Not Real", 0, "dick", "hats");
	bossbattlesgui.addclass("Test2", "Bill Fuckyou", "Nice guy once you get to know him.",1, 250, "Slow", "N/A", 0, "Nothing");
	bossbattlesgui.addclass("Test3", "Fred Fucks", "Total asshole once you get to know him.",1, 60, "Average", "One with the force", 0, "ITEM", "Minigun", "Washcloth", "Toothbrush", "Lunchbox");
	bossbattlesgui.addclass("Test4", "Mister Cheese", "Hello my name is hello my name is hello my name is hello my name", 2, 500, "Very Fast", "Wheeee", 300, "Laziness");
	bossbattlesgui.addclass("Test5", "Bbbbbbbbb", "bbbbbbbbbbbbbbbbbbb",2, 10, "Slow", "Alt fire to trip and fall", 58000, "Suicide gun");
	bossbattlesgui.addclass("Test6", "Darth Rude", "DESCRIPTION.",3, "High", "Fast", "OTHER", 0, "STUFF");
	bossbattlesgui.addclass("Test7", "Evil McEvilstein", "Honk honk.", 3, "Low", "Whaaaaaa", "space to jump", 0, "Hyena gun");
}

function createTestBBClasses2()
{
	clientCmdBBGUI("addClass", "Test1", "Seymour Butt", "Has anyone even been so far", 1, 100, "Fast", "Not Real", 0, "dick", "hats");
	clientCmdBBGUI("addClass", "Test2", "Bill Fuckyou", "Nice guy once you get to know him.",1, 250, "Slow", "N/A", 0, "Nothing");
	clientCmdBBGUI("addClass", "Test3", "Fred Fucks", "Total asshole once you get to know him.",1, 60, "Average", "One with the force", 0, "ITEM", "Minigun", "Washcloth", "Toothbrush", "Lunchbox");
	clientCmdBBGUI("addClass", "Test4", "Mister Cheese", "Hello my name is hello my name is hello my name is hello my name", 2, 500, "Very Fast", "Wheeee", 300, "Laziness");
	clientCmdBBGUI("addClass", "Test5", "Bbbbbbbbb", "bbbbbbbbbbbbbbbbbbb",2, 10, "Slow", "Alt fire to trip and fall", 58000, "Suicide gun");
	clientCmdBBGUI("addClass", "Test6", "Darth Rude", "DESCRIPTION.",3, "High", "Fast", "OTHER", 0, "STUFF");
	clientCmdBBGUI("addClass", "Test7", "Evil McEvilstein", "Honk honk.", 3, "Low", "Whaaaaaa", "space to jump", 0, "Hyena gun");
}