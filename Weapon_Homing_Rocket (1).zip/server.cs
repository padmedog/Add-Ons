%errorA = ForceRequiredAddOn("Weapon_Rocket_Launcher");
%errorB = ForceRequiredAddOn("Projectile_GravityRocket");

if(%errorA == $Error::AddOn_Disabled)
   rocketLauncherItem.uiName = "";

else if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Weapon_Homing_Rocket - required add-on Weapon_Rocket_Launcher not found");
else if(%errorB == $Error::AddOn_NotFound)
   error("ERROR: Weapon_Homing_Rocket - required add-on Projectile_GravityRocket not found");
else
   exec("./Weapon_HomingRocket.cs");