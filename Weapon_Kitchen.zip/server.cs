%error = ForceRequiredAddOn("Weapon_Sword"); //for the Kukri and Fire Axe
%error2 = ForceRequiredAddOn("Emote_Critical"); //TF2 Wrench

if(%error == $Error::AddOn_Disabled)
{
   SwordItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_Kitchen - required add-on Weapon_Sword not found");
}
else if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_Kitchen - required add-on Emote_Critical not found");
}
else
{
   exec("./Support_RaycastingWeapons.cs");
   exec("./Support_KitchenMelee.cs");
   exec("./Weapon_Spatula.cs");
   exec("./Weapon_FryingPan.cs");
   exec("./Weapon_Cleaver.cs");
  exec("./Weapon_Pot.cs");
}
