//RPG.cs

//audio
datablock AudioProfile(RPGFireSound)
{
   filename    = "./rpg_launch.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock AudioProfile(PullTriggerSound)
{
   filename    = "./pull_trigger.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(LauncherDiscardSound)
{
   filename    = "./launcher_discard.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(RPGExplodeSound)
{
   filename    = "./grenade_blast_2.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock ParticleData(RPGSmokeParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   =0;
	inheritedVelFactor   = 0;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "0.9 0.9 0.9 0.1";
	colors[1]     = "1.0 0.4 0.08 0.2";
	colors[2]     = "0.5 0.5 0.5 0.1";
	colors[3]     = "0.5 0.5 0.5 0.0";

	sizes[0]      = 2.25;
   sizes[1]      = 0.6;
	sizes[2]      = 0.1;
	sizes[2]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.8;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(RPGSmokeEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  
   particles = "RPGSmokeParticle";
};

datablock ParticleData(RPGExplosionParticle)
{
	dragCoefficient		= 5.0;
	windCoefficient		= 1.0;
	gravityCoefficient	= -0.50;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 3800;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 5.0;
	spinRandomMin		= -5.0;
	spinRandomMax		= 5.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
   colors[0]     = "0.95 0.9 0.8 0.6";
   colors[1]     = "0.1 0.05 0.025 0.4";
   colors[2]     = "0.1 0.05 0.025 0.0";

	sizes[0]	= 55.0;
	sizes[1]	= 15.0;
   sizes[2]	= 19.5;

	times[0]	= 0.0;
	times[1]	= 0.02;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(RPGExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 90;
   overrideAdvance = false;
   particles = "RPGExplosionParticle";
};

datablock ParticleData(RPGExplosionParticle2)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 2000;
	lifetimeVarianceMS	= 1990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
   colors[0]     = "1 0.5 0.0 1";
   colors[1]     = "0.9 0.4 0.0 0.8";
   colors[2]     = "1 1 1 0.0";

	sizes[0]	= 0.2;
	sizes[1]	= 0.2;
   sizes[2]	= 0.2;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(RPGExplosionEmitter2)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   lifetimeMS       = 120;
   ejectionVelocity = 12;
   velocityVariance = 12.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "RPGExplosionParticle2";
};


datablock ParticleData(RPGExplosionRingParticle)
{
   dragCoefficient      = 8;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 10;
   textureName          = "base/data/particles/star1";
   spinSpeed        = 10.0;
   spinRandomMin        = -500.0;
   spinRandomMax        = 500.0;
   colors[0]     = "1.0 1.0 0.6 1";
   colors[1]     = "1.0 1.0 0.6 1";
   sizes[0]      = 19;
   sizes[1]      = 22;

   useInvAlpha = false;
};

datablock ParticleEmitterData(RPGExplosionRingEmitter)
{
   lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "RPGExplosionRingParticle";
};

datablock ExplosionData(RPGExplosion)
{
   //explosionShape = "";
   explosionShape = "add-ons/weapon_rocket_launcher/explosionSphere1.dts";
	soundProfile = RPGExplodeSound;

   lifeTimeMS = 350;

   particleEmitter = RPGExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = RPGExplosionRingEmitter;
   emitter[1] = RPGExplosionEmitter2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 10;
   lightEndRadius = 25;
   lightStartColor = "1 1 1 1";
   lightEndColor = "0 0 0 1";

   damageRadius = 3;
   radiusDamage = 100;

   impulseRadius = 6;
   impulseForce = 4000;
};


AddDamageType("RPGDirect",   '<bitmap:add-ons/Weapon_Package_Explosive2/CI_RPG> %1',    '%2 <bitmap:add-ons/Weapon_Package_Explosive2/CI_RPG> %1',1,1);
datablock ProjectileData(RPGProjectile)
{
   projectileShapeName = "add-ons/weapon_rocket_launcher/RocketProjectile.dts";
   directDamage        = 50;
   directDamageType = $DamageType::RPGDirect;
   radiusDamageType = $DamageType::RPGDirect;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = RPGExplosion;
   particleEmitter     = RPGSmokeEmitter;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 90;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 14000;
   fadeDelay           = 13500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.2;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "Rocket-Propelled Grenade";
};

//////////
// item //
//////////
datablock ItemData(RPGItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./rpg.DTS";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "RPG";
	iconName = "./RPG";
	doColorShift = false;
	colorShiftColor = "0.200 0.200 0.200 1.000";

	 // Dynamic properties defined by the scripts
	image = RPGImage;
	canDrop = true;

	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(RPGImage)
{
   // Basic Item properties
   shapeFile = "./rpg.DTS";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = RPGItem;
   ammo = " ";
   projectile = RPGProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 700;   //minimum time allowed between shots (needed to prevent equip/dequip exploit)

   doColorShift = true;
   colorShiftColor = RPGItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.35;
	stateScript[0]                  = "onActivate";
	stateSequence[0]                = "Reload";
	stateSound[0]					= weaponSwitchSound;
	stateTransitionOnTimeout[0]       = "FireLoadCheckA";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnNoAmmo[1]		= "ReloadStart";
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Delay";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateEmitter[2]			  = shotgunExplosionRingEmitter;
	stateEmitterTime[2]		  = 0.03;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                  = "Fire";
	stateScript[2]                  = "onFire";
	stateSound[2]					= RPGFireSound;
	stateWaitForTimeout[2]			= true;

	stateName[3]			= "Delay";
	stateTransitionOnTimeout[3]     = "ReloadStart";
	stateTimeoutValue[3]            = 0.1;
	stateSequence[3]                  = "Reload";
	stateEmitterTime[3]				= 0.03;
	stateEmitterNode[3]				= "muzzleNode";
	
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 1.5;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.4;
	stateScript[7]				= "onReloadWait";
	stateTransitionOnTimeout[7]		= "Reloaded";
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Ready";
	stateTransitionOnNoAmmo[9]		= "ReloadStart";
	
	stateName[10] 				= "Smoke";
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Halt";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
	
	stateName[12]				= "Reloaded";
	stateTimeoutValue[12]			= 0.4;
	stateScript[12]				= "onReloaded";
	stateTransitionOnTimeout[12]		= "Activate";

	stateName[13]			= "Halt";
	stateTransitionOnTimeout[13]     = "Ready";
	stateTimeoutValue[13]            = 0.9;
	stateEmitterTime[13]				= 0.48;
	stateEmitterNode[13]				= "muzzleNode";
	stateScript[13]                  = "onHalt";

	stateName[14]                     = "ReloadStart";
	stateTransitionOnTimeout[14]  = "ReloadStartB";
	stateTimeoutValue[14]            = 0.1;
	stateAllowImageChange[14]         = false;

	stateName[15]                     = "ReloadStartB";
	stateTransitionOnTimeout[15]  = "LoadCheckA";
	stateAllowImageChange[15]         = true;
};

function RPGImage::onFire(%this, %obj, %slot)
{
	//%obj.playThread(2, plant);
	//%obj.playThread(3, activate);
	//%obj.playThread(4, shiftLeft);
	
	%obj.playThread(2, shiftAway);

	%obj.toolAmmo[%obj.currTool]--;
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	%obj.AmmoSpent[%obj.currTool]++;
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4); 
	}

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
          serverPlay3D(RPGFireSound,%obj.getPosition());
	%projectile = %this.projectile;
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%spread = 0.0001;
	}
	else
	{
		%spread = 0;
	}

	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
	%velocity = MatrixMulVector(%mat, %velocity);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
}

function RPGImage::onReloadStart(%this,%obj,%slot)
{
    if(%obj.client.quantity["rocketrounds"] >= 1)
	{
	
	%obj.playThread(2, shiftdown);
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4); 
	}
}

function RPGImage::onHalt(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4); 
	}
}

function RPGImage::onActivate(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4); 
	}
}

function RPGImage::onReady(%this,%obj,%slot)
{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4);  
	}
}

function RPGImage::onReloadWait(%this,%obj,%slot)
{
    if(%obj.client.quantity["rocketrounds"] >= 1)
	{
		%obj.playThread(2,plant);
            		serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4); 
	}
}

function RPGImage::onReloaded(%this,%obj,%slot)
{
	%this.onLoadCheck(%obj,%slot);
    if(%obj.client.quantity["rocketrounds"] >= 1)
	{
	if($Pref::Server::TTAmmo == 0 || $Pref::Server::TTAmmo == 1)
	{
	commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Rocket-Propelled Grenades <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["rocketrounds"] @ "", 4, 2, 3, 4); 
		%obj.client.quantity["rocketrounds"]--;
	}
		%obj.toolAmmo[%obj.currTool]++;
            		serverPlay3D(block_PlantBrick_Sound,%obj.getPosition());
	}
}
