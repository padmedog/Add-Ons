datablock ParticleData(SmokeGrenadeSmokeParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 15000;
	lifetimeVarianceMS	= 500;
	spinSpeed		= 5.0;
	spinRandomMin		= -5.0;
	spinRandomMax		= 5.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
   colors[0]     = "0.5 0.5 0.5 0.95";
   colors[1]     = "0.5 0.5 0.5 0.8";
   colors[2]     = "0.5 0.5 0.5 0.0";

	sizes[0]	= 6.0;
	sizes[1]	= 11.0;
   sizes[2]	= 13.0;

	times[0]	= 0.0;
	times[1]	= 0.75;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(SmokeGrenadeSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 10;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0; //90
   thetaMax         = 180; //360
   phiReferenceVel  = 0;
   phiVariance      = 360; //180
   overrideAdvance = false;
   particles = "SmokeGrenadeSmokeParticle";
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

datablock ExplosionData(smokegrenadeExplosion)
{
   //explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
   lifeTimeMS = 150;

   soundProfile = SmokeGrenadeSound;
   
   emitter[0] = smokegrenadeSmokeEmitter;
   //emitter[1] = "";
   //emitter[2] = "";
   //emitter[0] = "";


   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 0;
   impulseForce = 0;

   damageRadius = 0;
   radiusDamage = 0;

//	uiName = "Impact Grenade Explosion";
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

AddDamageType("SmokeGrenadeDirect",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_SmokeGrenade> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_SmokeGrenade> %1',1,1);
datablock ProjectileData(SmokeGrenadeProjectile)
{
   projectileShapeName = "./SmokeGrenadeThrown.dts";
   directDamage        = 0;
   directDamageType = $DamageType::SmokeGrenadeDirect;
   radiusDamageType = $DamageType::SmokeGrenadeRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = smokegrenadeExplosion;
//   particleEmitter     = ImpactGrenadeTrailEmitter;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0; //30             
   brickExplosionMaxVolume = 0;  //30         //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 38; //50
   velInheritFactor    = 1.0;
   explodeOnPlayerImpact = false;
   explodeOnDeath        = true;

   armingDelay         = 1500;
   lifetime            = 8000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.3; //0.5
   bounceFriction      = 0.35; //0.2
   isBallistic         = true;
   gravityMod          = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "1 0 0.0";

   uiName = "Smoke Grenade";
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////
// item //
//////////
datablock ItemData(SmokeGrenadeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./SmokeGrenade.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Smoke Grenade";
	iconName = "./icon_SmokeGrenade";
	l4ditemtype = "grenade";

	 // Dynamic properties defined by the scripts
	image = SmokeGrenadeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(SmokeGrenadeImage)
{
   // Basic Item properties
   shapeFile = "./SmokeGrenade.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = SmokeGrenadeItem;
   ammo = " ";
   projectile = SmokeGrenadeProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = false;
   colorShiftColor = "0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state

	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateAllowImageChange[1]	= true;

	stateName[2]			= "SKIPPEDPindrop";
	stateTransitionOnTimeout[2]	= "SKIPPEDPinfallen";
	stateAllowImageChange[2]	= false;
	stateTimeoutValue[2]		= 0.2;
	stateEjectShell[2]       = true;

	stateName[3]			= "SKIPPEDPinfallen";
	stateTransitionOnTriggerDown[3]	= "Charge";
	stateAllowImageChange[3]	= false;
	
	stateName[4]                    = "Charge";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.1;
	stateWaitForTimeout[4]		= false;
	stateTransitionOnTriggerUp[4]	= "AbortCharge";
	stateScript[4]                  = "onCharge";
	stateAllowImageChange[4]        = false;
	
	stateName[5]			= "AbortCharge";
	stateTransitionOnTimeout[5]	= "Ready";
	stateTimeoutValue[5]		= 0.1;
	stateWaitForTimeout[5]		= true;
	stateScript[5]			= "onAbortCharge";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Armed";
	stateScript[6]			= "onArmed";
	stateTransitionOnTriggerUp[6]	= "Fire";
	stateAllowImageChange[6]	= false;

	stateName[7]			= "Fire";
	stateTransitionOnTimeout[7]	= "Done";
	stateTimeoutValue[7]		= 0.5;
	stateFire[7]			= true;
	stateSound[7]				= tierfraggrenadetossSound;
	stateSequence[7]		= "fire";
	stateScript[7]			= "onFire";
	stateWaitForTimeout[7]		= true;
	stateAllowImageChange[7]	= false;

	stateName[8]					= "Done";
	stateScript[8]					= "onDone";
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


package SmokeGrenadePackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "SmokeGrenadeItem" && %col.canPickup)
		{
			for(%i=0;%i<%this.maxTools;%i++)
			{
				%item = %obj.tool[%i];
				if(%item $= 0 || %item $= "")
				{
					%freeSlot = 1;
					break;
				}
			}

			if(%freeSlot)
			{
				%obj.pickup(%col);
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(SmokeGrenadePackage);

function SmokeGrenadeImage::onArmed(%this, %obj, %slot)
{
	%obj.playthread(1, spearready);
	%obj.playthread(2, spearready);
	%obj.playthread(3, activate);
	%obj.lasttierfragslot = %obj.currTool;
}

function SmokeGrenadeImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function SmokeGrenadeImage::onFire(%this, %obj, %slot)
{
	Parent::OnFire(%this, %obj, %slot);

	%currSlot = %obj.lasttierfragslot;
	%obj.tool[%currSlot] = 0;
	%obj.weaponCount--;
	messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
	serverCmdUnUseTool(%obj.client);
	%obj.playThread(1, activate);
	%obj.playThread(2, spearthrow);


}

function SmokeGrenadeImage::onCharge(%this, %obj, %slot)
{
		%obj.playThread(2, jump);
}

//function SmokeGrenadeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
//{
//	serverPlay3D(SmokeGrenadeBounceSound,%obj.getTransform());
//}

function SmokeGrenadeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
