function fxDTSBrick::getEventCount(%brick)
{
	if(!%brick.numEvents)
	{
		return 0;
	}

	return %brick.numEvents;
}

function serverCmdGetEventCount(%client)
{
	serverCmdEventCount(%client);
}

function serverCmdEventCount(%client)
{
	if(!%client.isAdmin)
	{
		return;
	}

	if($Sim::Time - %client.ServerCmdEventCountFlood < 1)
	{
		%client.serverCmdEventCountFlood = $Sim::Time;

		return;
	}

	%client.serverCmdEventCountFlood = $Sim::Time;

	if($Server::EventCount $= "")
	{
		$Server::EventCount = 0;
	}

	if($Server::EventCount == 1)
	{
		messageClient(%client, '', "\c0There is" SPC $Server::EventCount SPC "event in the server.");
	}

	else
	{
		messageClient(%client, '', "\c0There are" SPC $Server::EventCount SPC "events in the server.");
	}
}

package EventCount
{
	function serverCmdAddEvent(%client, %delay, %input, %target, %a, %b, %output, %par1, %par2, %par3, %par4)
	{
		%p = parent::serverCmdAddEvent(%client, %delay, %input, %target, %a, %b, %output, %par1, %par2, %par3, %par4);

		$Server::EventCount++;

		return %p;
	}

	function serverCmdClearEvents(%client)
	{
		if(isObject(%client.wrenchBrick))
		{
			$Server::EventCount -= %client.wrenchBrick.getEventCount();
		}

		parent::serverCmdClearEvents(%client);
	}

	function fxDTSBrick::onRemove(%brick)
	{
		$Server::EventCount -= %brick.getEventCount();

		parent::onRemove(%brick);
	}
};
activatePackage(EventCount);