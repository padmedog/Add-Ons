datablock fxDTSBrickData(brickPrintPineTreeData)
{
	brickFile = "Add-Ons/Brick_PrintPineTree/PrintPineTree.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Pine Tree Print";
	iconName = "Add-Ons/Brick_PrintPineTree/PrintPineTree";
	collisionShapeName = "base/data/shapes/bricks/pinetree.dts";
        hasPrint = 1;
	printAspectRatio = "2x2F";
};
