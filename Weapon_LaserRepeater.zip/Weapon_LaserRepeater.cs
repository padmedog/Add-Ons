//Weapon_LaserRepeater.cs

datablock AudioProfile(LaserRepeaterFireSound)
{
   filename    = "Add-Ons/Projectile_Radio_Wave/radioWaveExplosion.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(LaserRepeaterSpinSound)
{
   filename    = "./spinsound.wav";
   description = AudioClose3d;
   preload = true;
};

//trail
datablock ParticleData(LaserRepeaterTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 75;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= " ";

	// Interpolation variables
	colors[0]	= "0 1 1 1";
	colors[1]	= "0.3 0.5 0.75 0.4";
	sizes[0]	= 0.07;
	sizes[1]	= 0.15;
	//times[0]	= 0.5;
	//times[1]	= 0.5;
};

datablock ParticleEmitterData(LaserRepeaterTrailEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = LaserRepeaterTrailParticle;

   useEmitterColors = true;
   uiName = "";
};

//muzzle flash effects
datablock ParticleData(LaserRepeaterFlashParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 25;
	lifetimeVarianceMS   = 15;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.0 1 1 0.9";
	colors[1]     = "0.0 1 1 0.0";
	sizes[0]      = 0.2;
	sizes[1]      = 0.5;

	useInvAlpha = false;
};
datablock ParticleEmitterData(LaserRepeaterFlashEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "LaserRepeaterFlashParticle";

   uiName = "";
};


datablock ExplosionData(LaserRepeaterExplosion)
{
   //explosionShape = "";
	soundProfile = LaserHitSound;

   lifeTimeMS = 150;

   particleEmitter = LaserExplosionEmitter;
   particleDensity = 9;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 2;
   lightStartColor = "0.0 0.9 0.9";
   lightEndColor = "0 0 0";
};


AddDamageType("LaserRepeater",   '<bitmap:add-ons/Weapon_LaserRepeater/CI_LaserRepeater> %1',    '%2 <bitmap:add-ons/Weapon_LaserRepeater/CI_LaserRepeater> %1',0.2,1);
datablock ProjectileData(LaserRepeaterProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 10;
   directDamageType    = $DamageType::LaserRepeater;
   radiusDamageType    = $DamageType::LaserRepeater;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 2;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 4;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 250;
   verticalImpulse	  = 100;
   explosion           = LaserRepeaterExplosion;
   particleEmitter     = LaserRepeaterTrailEmitter;

   muzzleVelocity      = 80;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = True;
   lightRadius = 3.0;
   lightColor  = "0.0 0.75 0.75";

   uiName = "Laser Repeater Laser";
};

//////////
// item //
//////////
datablock ItemData(LaserRepeaterItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./LaserRepeater.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Laser Repeater";
	iconName = "./icon_LaserRepeater";
	doColorShift = false;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = LaserRepeaterImage;
	canDrop = true;
};


////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(LaserRepeaterImage)
{
   // Basic Item properties
   shapeFile = "./LaserRepeater.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = LaserRepeaterProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   LarmReady = true;

   doColorShift = False;
   colorShiftColor = LaserRepeaterItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]					= weaponSwitchSound;
	
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Spinup";
	stateAllowImageChange[1]        = true;
	stateSequence[1]				= "ready";

	stateName[2]                    = "Spinup";
	stateAllowImageChange[2]        = false;
	stateTransitionOnTimeout[2]     = "Fire";
	stateTimeoutValue[2]            = 1.00;
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= LaserRepeaterSpinSound;
	stateSequence[2]				= "Spin";
	stateTransitionOnTriggerUp[2]   = "Ready";
	//stateSequenceOnTimeout[2]	= "Spin";
	
	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Check";
	stateTimeoutValue[3]            = 0.05;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	//stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]			= true;
	stateEmitter[3]					= LaserRepeaterFlashEmitter;
	stateEmitterTime[3]				= 0.01;
	stateEmitterNode[3]				= "muzzleNode";
	stateSound[3]					= LaserRepeaterFireSound;

	stateName[4]					= "Check";
	stateTransitionOnTriggerUp[4]   = "Slow";
	stateTransitionOnTriggerDown[4] = "Fire";
	
	stateName[5]					= "Slow";
	stateTransitionOnTriggerDown[5] = "Fire";
	stateAllowImageChange[5]        = false;
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 1.00;
	stateWaitForTimeout[5]			= true;

};

function LaserRepeaterImage::onFire(%this,%obj,%slot)
{

	%obj.setVelocity(getword(%obj.getvelocity(),0) * 0.25 SPC getword(%obj.getvelocity(),1) * 0.25 SPC getWord(%obj.getVelocity(),2));

	%projectile = %this.projectile;
	%spread = 0.002;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
