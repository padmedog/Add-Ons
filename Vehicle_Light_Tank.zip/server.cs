%error = ForceRequiredAddOn("Vehicle_Tank");
if(%error == $Error::AddOn_Disabled)
{
	TankVehicle.uiName = "";
}
if(%error == $Error::AddOn_NotFound)
{
	error("ERROR: Vehicle_Light_Tank - required add-on Vehicle_Tank not found");
	return;
}
exec("./shootOnClick.cs");
datablock ParticleData(lightTankEngineParticle)
{
	dragCoefficient = 2.99998;
	windCoefficient = 0;
	gravityCoefficient = 0;
	inheritedVelFactor = 1;
	constantAcceleration = 0;
	lifetimeMS = 130;
	lifetimeVarianceMS = 10;
	spinSpeed = "500";
	spinRandomMin = -150;
	spinRandomMax = 150;
	useInvAlpha = false;
	animateTexture = false;
	framesPerSec = 1;
	textureName = "base/data/particles/cloud";
	animTexName[0] = "base/data/particles/cloud";
	colors[0] = "0.000000 0.000000 1.000000 1.000000";
	colors[1] = "1.000000 0.466667 0.000000 1.000000";
	colors[2] = "1.000000 0.000000 0.000000 0.000000";
	colors[3] = "1.000000 1.000000 1.000000 1.000000";
	sizes[0] = 0.6;
	sizes[1] = 0.6;
	sizes[2] = 1;
	sizes[3] = 2;
	times[0] = 0;
	times[1] = 0.0980392;
	times[2] = 1;
	times[3] = 2;
};
datablock ParticleEmitterData(lightTankEngineEmitter)
{
	ejectionPeriodMS = 6;
	periodVarianceMS = 0;
	ejectionVelocity = 5;
	velocityVariance = 0;
	ejectionOffset = 0;
	thetaMin = 0;
	thetaMax = 0;
	phiReferenceVel = 0;
	phiVariance = 360;
	overrideAdvance = 0;
	orientParticles = 0;
	orientOnVelocity = 1;
	lifetimeMS = 0;
	lifetimeVarianceMS = 0;
	useEmitterSizes = 0;
	useEmitterColors = 0;
	doFalloff = 1;
	doDetail = 1;
	particles = "lightTankEngineParticle";
	uiName = "Light Tank Engine Emitter";
};

datablock ParticleData(lightTankEngineSmokeParticle)
{
	dragCoefficient = 2.99998;
	windCoefficient = 1;
	gravityCoefficient = -1.00366;
	inheritedVelFactor = 0.598826;
	constantAcceleration = false;
	lifetimeMS = 1200;
	lifetimeVarianceMS = 55;
	spinSpeed = 10;
	spinRandomMin = -500;
	spinRandomMax = 500;
	useInvAlpha = true;
	animateTexture = 0;
	framesPerSec = 1;
	textureName = "base/data/particles/cloud";
	animTexName[0] = "base/data/particles/cloud";
	colors[0] = "0.466667 0.466667 0.466667 0.200000";
	colors[1] = "0.466667 0.466667 0.466667 0.000000";
	colors[2] = "1.000000 1.000000 1.000000 1.000000";
	colors[3] = "1.000000 1.000000 1.000000 1.000000";
	sizes[0] = 0.997986;
	sizes[1] = 1.19636;
	sizes[2] = 1;
};
datablock ParticleEmitterData(lightTankEngineSmokeEmitter)
{
	ejectionPeriodMS = 20;
	periodVarianceMS = 5;
	ejectionVelocity = 0.0;
	velocityVariance = 0.0;
	ejectionOffset	= 0.0;
	thetaMin			= 0;
	thetaMax			= 0;
	phiReferenceVel  = 0;
	phiVariance		= 360;
	overrideAdvance = false;
	particles = "lightTankEngineSmokeParticle";
	uiName = "Light Tank Engine Smoke Emitter";
};
datablock ShapeBaseImageData(lightTankEngineImage1)
{
	shapeFile = "./empty.dts";
	emap = false;
	mountPoint = 2;
	rotation = "1 0 0 180";
	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;
	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= lightTankEngineEmitter;
	stateEmitterTime[1]				= 10000;
	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function lightTankEngineImage1::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
datablock ShapeBaseImageData(lightTankEngineImage2)
{
	shapeFile = "./empty.dts";
	emap = false;
	mountPoint = 3;
	rotation = "1 0 0 180";
	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;
	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= lightTankEngineEmitter;
	stateEmitterTime[1]				= 10000;
	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function lightTankEngineImage2::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}
datablock ShapeBaseImageData(lightTankEngineSmokeImage1)
{
	shapeFile = "./empty.dts";
	emap = false;
	mountPoint = 2;
	rotation = "1 0 0 180";
	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;
	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= lightTankEngineSmokeEmitter;
	stateEmitterTime[1]				= 10000;
	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function lightTankEngineSmokeImage1::onMount(%this,%obj,%slot)
{
	%obj.schedule(1000,"unMountImage",%slot);
}
datablock ShapeBaseImageData(lightTankEngineSmokeImage2)
{
	shapeFile = "./empty.dts";
	emap = false;
	mountPoint = 3;
	rotation = "1 0 0 180";
	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;
	stateName[1]					= "FireA";
	stateTransitionOnTimeout[1]		= "Done";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 10000;
	stateEmitter[1]					= lightTankEngineSmokeEmitter;
	stateEmitterTime[1]				= 10000;
	stateName[2]					= "Done";
	stateScript[2]					= "onDone";
};
function lightTankEngineSmokeImage2::onMount(%this,%obj,%slot)
{
	%obj.schedule(1000,"unMountImage",%slot);
}
datablock WheeledVehicleTire(lightTankTire)
{
	shapeFile = "./lightTankwheel.dts";
	mass = 10;
	radius = 1;
	staticFriction = 5;
	kineticFriction = 5;
	restitution = 0.5;	
	lateralForce = 18000;
	lateralDamping = 4000;
	lateralRelaxation = 0.01;
	longitudinalForce = 14000;
	longitudinalDamping = 2000;
	longitudinalRelaxation = 0.01;
};
datablock WheeledVehicleSpring(lightTankSpring)
{
	length = 0.2;
	force = 2000;
	damping = 500;
	antiSwayForce = 3;
};

datablock WheeledVehicleData(lightTankVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./lightTank.dts";
	emap = true;
	minMountDist = 3;
	numMountPoints = 1;
	mountThread[0] = "sit";
	maxDamage = 225;
	destroyedLevel = 300.00;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier	= 0.02;
	massCenter = "0 0 0";
	maxSteeringAngle = 1;
	integration = 4;
	tireEmitter = VehicleTireEmitter;
	cameraRoll = false;
	cameraMaxDist = 9;
	cameraOffset = 5.5;
	cameraLag = 0.0;
	cameraDecay = 0.75;
	cameraTilt = 0.4;
	collisionTol = 0.1;
	contactTol = 0.1;
	useEyePoint = true;	
	defaultTire	= lightTankTire;
	defaultSpring	= lightTankSpring;
	numWheels = 4;
	mass = 300;
	density = 5.0;
	drag = 1.6;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;
	softImpactSpeed = 10;
	hardImpactSpeed = 15;
	groundImpactMinSpeed = 10.0;
	engineTorque = 25000;
	engineBrake = 5000;
	brakeTorque = 50000;
	maxWheelSpeed = 25;
	rollForce = 900;
	yawForce = 600;
	pitchForce = 1000;
	rotationalDrag = 0.2;
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;
	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;	
	hardSplashSoundVelocity = 20.0;	
	exitSplashSoundVelocity = 5.0;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	justcollided = 0;
	uiName = "Light Tank ";
	rideable = true;
	lookUpLimit  = 0.5;
	lookDownLimit = 0.5;
	paintable = true;
	damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;
	damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;
	numDmgEmitterAreas = 1;
	initialExplosionProjectile = tankExplosionProjectile;
	initialExplosionOffset = 1;
	burnTime = 4000;
	finalExplosionProjectile = tankFinalExplosionProjectile;
	finalExplosionOffset = 0.5;
	minRunOverSpeed	 = 4;
	runOverDamageScale = 25;
	runOverPushScale = 1.2;
	protectPassengersBurn	= true;
	protectPassengersRadius = true;
	protectPassengersDirect = true;
	lightTankEngineSpeed = 1;
	shootOnClick = 1;
	shootOnClick_Hold = 0;
	shootOnClick_ShootDelay = 1750;
	shootOnClick_ProjectileCount = 1;
	shootOnClick_RequiredSlot = 0;
	ShootOnClick_Projectile[0] = tankShellProjectile;
	shootOnClick_Position[0] = "5 0 1.2";
	shootOnClick_Velocity[0] = "100 0 0";
	shootOnClick_Scale[0] = "0.8 0.8 0.8";
};
function lightTankVehicle::onAdd(%this,%obj)
{
	for(%i = 0; %i < %this.numWheels; %i++)
	{
		%obj.setWheelTire(%i, %this.defaultTire);
		%obj.setWheelSpring(%i, %this.defaultSpring);
	}
	%obj.setWheelSteering(0,1);
	%obj.setWheelSteering(1,1);
	%obj.setWheelSteering(2,-1);
	%obj.setWheelSteering(3,-1);  
	%obj.setWheelPowered(0,true);
	%obj.setWheelPowered(1,true);
	%obj.setWheelPowered(2,true);
	%obj.setWheelPowered(3,true);
	lightTankEngineCheck(%obj);
}
function lightTankEngineCheck(%obj)
{
	cancel(%obj.lightTankEngineCheck);
	if(!isObject(%obj))
		return;
	%speed = vectorLen(%obj.getVelocity());
	if(isObject(%obj.getMountedObject(0)))
	{
		if(%speed < %obj.dataBlock.lightTankEngineSpeed)
		{
			if(isObject(%obj.getMountedImage(0)))
			{
				%obj.unMountImage(0);
				%obj.mountImage(lightTankEngineSmokeImage2,0);
			}
			if(isObject(%obj.getMountedImage(1)))
			{
				%obj.unMountImage(1);
				%obj.mountImage(lightTankEngineSmokeImage1,1);
			}
		}
		else
		{
			%obj.unMountImage(0);
			if(!isObject(%obj.getMountedImage(0)))
			{
				%obj.mountImage(lightTankEngineImage2,0);
			}
			%obj.unMountImage(1);
			if(!isObject(%obj.getMountedImage(1)))
			{
				%obj.mountImage(lightTankEngineImage1,1);
			}
		}
	}
	else
	{
		if(isObject(%obj.getMountedImage(0)))
		{
			%obj.unMountImage(0);
			%obj.mountImage(lightTankEngineSmokeImage2,0);
		}
		if(isObject(%obj.getMountedImage(1)))
		{
			%obj.unMountImage(1);
			%obj.mountImage(lightTankEngineSmokeImage1,1);
		}
	}
	%obj.lightTankEngineCheck = schedule(2000,0,"lightTankEngineCheck",%obj);
}