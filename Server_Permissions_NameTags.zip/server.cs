package permissionRoleNameTags {
    function serverCmdMessageSent(%cl, %message) {
        if (getSubStr(%message, 0, 1) !$= "@" && getSubStr(%message, 0, 1) !$= "@") {
            %oldClanPrefix = %cl.clanPrefix;
            if (%cl.getRole().name !$= getPermissionManager().getDefaultRole().name)
                %cl.clanPrefix = "[<color:FFFFFF>" @ %cl.getRole().name @ "<color:zzzzzz>]" SPC %cl.clanPrefix;
            parent::serverCmdMessageSent(%cl, %message);
            %cl.clanPrefix = %oldClanPrefix;
        } else
            parent::serverCmdMessageSent(%cl, %message);
    }
};
activatePackage(permissionRoleNameTags);
