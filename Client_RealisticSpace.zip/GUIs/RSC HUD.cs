$RSC::Revision += 1;

if(isObject(RSC_MainHUD))
	RSC_MainHUD.delete();
new GuiSwatchCtrl(RSC_MainHUD)
{
	position = "0 0";
	extent = "72 124";
	color = "0 0 0 0";
	
	new GuiSwatchCtrl()
	{
		position = "0 0";
		extent = "20 100";
		minExtent = "8 1";
		color = "255 255 255 64";
	};
	
	new GuiSwatchCtrl()
	{
		position = "26 0";
		extent = "20 100";
		minExtent = "8 1";
		color = "255 255 255 64";
	};
	
	new GuiSwatchCtrl()
	{
		position = "52 0";
		extent = "20 100";
		minExtent = "8 1";
		color = "255 255 255 64";
	};
	
	new GuiBitmapCtrl()
	{
		position = "0 104";
		extent = "20 20";
		
		bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Oxygen_Icon";
	};
	
	new GuiBitmapCtrl()
	{
		position = "26 104";
		extent = "20 20";
		
		bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Fuel_Icon";
	};
	
	new GuiBitmapCtrl()
	{
		position = "52 104";
		extent = "20 20";
		
		bitmap = "Add-Ons/Client_RealisticSpace/GUIs/Battery_Horiz";
	};
};

function clientcmdRSM_UpdateMainHUD(%base64Data)
{
	%array = new ScriptObject() { class = "ByteArraySO"; };
	%array.FromBase64(%base64Data);
	%oxyData = FromFloat16((%array.byte0 << 8) | %array.byte1);
	%fuelData = FromFloat16((%array.byte2 << 8) | %array.byte3);
	%battData = FromFloat16((%array.byte4 << 8) | %array.byte5);
	RSC_MainHUD.pendingUpdate = 1;
	RSC_MainHUD.currentOxygen = %oxyData;
	RSC_MainHUD.currentFuel = %fuelData;
	RSC_MainHUD.currentBattery = %battData;
}

function RSC_HUDLoop(%prevRes)
{
	if(!isObject(%cl = ServerConnection) || !$RSC::RealSpaceServer ||
		!isObject(%pl = %cl.getControlObject()) || %pl.getClassName() !$= "Player"
		|| %pl.getState() $= "DEAD")
	{
		RSC_MainHUD.setVisible(0);
		$RSC::HUDLoop = schedule(16, 0, "RSC_HUDLoop");
		return;
	}
	if(!PlayGUI.isMember(RSC_MainHUD))
	{
		PlayGUI.add(RSC_MainHUD);
		%prevRes = "";
	}
	RSC_MainHUD.setVisible(1);
	if(RSC_MainHUD.pendingUpdate)
	{
		%oxyData = mCeil(RSC_MainHUD.currentOxygen * 100);
		if(%oxyData <= 0)
		{
			RSC_MainHUD.getObject(0).setVisible(0);
			RSC_MainHUD.getObject(3).setColor("1 0 0 0.25");
		}
		else
		{
			%color = RSC_GetHUDColor(RSC_MainHUD.currentOxygen, 0.25);
			RSC_MainHUD.getObject(0).setVisible(1);
			RSC_MainHUD.getObject(0).resize(0, 100 - %oxyData, 20, %oxyData);
			RSC_MainHUD.getObject(0).setColor(%color);
			RSC_MainHUD.getObject(3).setColor(%color);
		}
		
		%fuelData = mCeil(RSC_MainHUD.currentFuel * 100);
		if(%fuelData <= 0)
		{
			RSC_MainHUD.getObject(1).setVisible(0);
			RSC_MainHUD.getObject(4).setColor("1 0 0 0.25");
		}
		else
		{
			%color = RSC_GetHUDColor(RSC_MainHUD.currentFuel, 0.25);
			RSC_MainHUD.getObject(1).setVisible(1);
			RSC_MainHUD.getObject(1).resize(26, 100 - %fuelData, 20, %fuelData);
			RSC_MainHUD.getObject(1).setColor(%color);
			RSC_MainHUD.getObject(4).setColor(%color);
		}
		
		%battData = mCeil(RSC_MainHUD.currentBattery * 100);
		if(%battData <= 0)
		{
			RSC_MainHUD.getObject(2).setVisible(0);
			RSC_MainHUD.getObject(5).setColor("1 0 0 0.25");
		}
		else
		{
			%color = RSC_GetHUDColor(RSC_MainHUD.currentBattery, 0.25);
			RSC_MainHUD.getObject(2).setVisible(1);
			RSC_MainHUD.getObject(2).resize(52, 100 - %battData, 20, %battData);
			RSC_MainHUD.getObject(2).setColor(%color);
			RSC_MainHUD.getObject(5).setColor(%color);
		}
	}
	%currRes = getRes();
	if(%currRes !$= %prevRes)
	{
		%prevRes = %currRes;
		RSC_MainHUD.resize(getWord(%currRes, 0) - 144, 12, 72, 124);
		RSC_MainHUD.getObject(3).setColor("1 1 1 0.25");
		RSC_MainHUD.getObject(4).setColor("1 1 1 0.25");
		RSC_MainHUD.getObject(5).setColor("1 1 1 0.25");
	}
	$RSC::HUDLoop = schedule(16, 0, "RSC_HUDLoop", %prevRes);
}

function RSC_GetHUDColor(%value, %trans)
{
	if(%value >= 0.5)
	{
		%sub = (%value - 0.5) * 2;
		return (1 - %sub)@" 1 0 "@%trans;
	}
	else
	{
		%sub = %value * 2;
		return "1 "@%sub@" 0 "@%trans;
	}
}