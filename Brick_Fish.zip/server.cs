datablock fxDTSBrickData (BrickHorizFishData)
{
   BrickFile = "./Brick_Fish.blb";
   Category = "Special";
   Subcategory = "Misc";
   UiName = "Horizontal Fish";
   IconName = "Add-Ons/Brick_Fish/Fish";
};
datablock fxDTSBrickData (BrickVertFishData)
{
   BrickFile = "./Brick_FishVert.blb";
   Category = "Special";
   Subcategory = "Misc";
   UiName = "Vertical Fish";
   IconName = "Add-Ons/Brick_Fish/VertFish";
};
datablock fxDTSBrickData (BrickHorizFlatFishData)
{
   BrickFile = "./Brick_FlatFish.blb";
   Category = "Special";
   Subcategory = "Misc";
   UiName = "Horizontal Flat Fish";
   IconName = "Add-Ons/Brick_Fish/FlatFish";
};
datablock fxDTSBrickData (BrickVertFlatFishData)
{
   BrickFile = "./Brick_FlatFishVert.blb";
   Category = "Special";
   Subcategory = "Misc";
   UiName = "Vertical Flat Fish";
   IconName = "Add-Ons/Brick_Fish/VertFlatFish";
};
datablock fxDTSBrickData (BrickFishKnifeData)
{
   BrickFile = "./Brick_FishKnife.blb";
   Category = "Special";
   Subcategory = "Misc";
   UiName = "Fish Butchering Knife";
   IconName = "Add-Ons/Brick_Fish/Knife";
};