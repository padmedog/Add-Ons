if(!$JSSearchAdded)
{
	js_window.getObject(2).position = "550 1";
	%text = new GuiTextEditCtrl(js_searchtext)
	{
		position = "338 4";
		extent = "100 18";
	};
	%button = new GuiBitmapButtonCtrl(js_searchbutton)
	{
		profile = "BlockButtonProfile";
		position = "435 1";
		extent = "100 23";
		text = "Search";
		bitmap = "base/client/ui/button1";
		mColor = "255 255 255 255";
		command = "js_search(js_searchtext.getValue(),js_searchpopup.getSelected());";
	};
	%popup = new GuiPopUpMenuCtrl(js_searchpopup)
	{
		position = "288 4";
		extent = "50 18";
	};
	js_window.add(%text);
	js_window.add(%button);
	js_window.add(%popup);
	js_searchpopup.addFront("Map",2,0);
	js_searchpopup.addFront("Host",1,0);
	js_searchpopup.addFront("Name",0,0);
	$JSSearchAdded = 1;
}
function js_search(%text,%type)
{
	js_serverList.clear();
	if(%text $= "")
	{
		ServerInfoSO_DisplayAll();
	}
	else
	{
		%type = mClamp(%type,0,2);
		for(%i=0;%i<ServerInfoGroup.getCount();%i++)
		{
			%server = ServerInfoGroup.getObject(%i);
			switch(%type)
			{
				case 0:
					if(striPos(%server.name,%text) > -1)
					{
						%server.display();
					}
				case 1:
					%host = strPos(%server.name,"'");
					if(%host > -1)
					{
						%host = getSubStr(%server.name,0,%host);
						if(striPos(%host,%text) > -1)
						{
							%server.display();
						}
					}
				case 2:
					if(striPos(%server.map,%text) > -1)
					{
						%server.display();
					}
			}
		}
	}
}