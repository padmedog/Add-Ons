//########## Melee.cs

//### Sounds

datablock AudioProfile(gc_MeleeSwingSound)
{
  filename = "./swing.wav";
  description = AudioClose3d;
  preload = true;
};

datablock AudioProfile(gc_MeleeHit1Sound : gc_MeleeSwingSound){filename = "./swordhit1.wav";};
datablock AudioProfile(gc_MeleeHit2Sound : gc_MeleeSwingSound){filename = "./swordhit2.wav";};
datablock AudioProfile(gc_MeleeFleshHitSound : gc_MeleeSwingSound){filename = "./swordfleshhit.wav";};

//### Effects

datablock ProjectileData(gc_MeleeProjectile)
{
  uiName = "";
  explosion = hammerProjectile.explosion;
  lifetime = 1;
  fadeDelay = 1;
  explodeOnDeath = true;
};

//### Functions

function gc_MeleeRaycast(%this,%obj)
{
  %raycast = containerRayCast(%obj.getMuzzlePoint(0),VectorAdd(%obj.getMuzzlePoint(0),VectorScale(%obj.getMuzzleVector(0),%this.range)),$TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::ForceFieldObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::fxBrickObjectType | $TypeMasks::StaticObjectType,%obj);
  if(isObject(firstWord(%raycast)))
  {
    %col = firstWord(%raycast);
    %pos = posFromRaycast(%raycast);
    %p = new Projectile()
    {
      dataBlock = %this.projectile;
      initialPosition = %pos;
      initialVelocity = %obj.getMuzzleVector(0);
      sourceObject = %obj;
      sourceSlot = 0;
      client = %obj.client;
    };
    MissionCleanup.add(%p);
    if(%col.getType() & $TypeMasks::PlayerObjectType)
    {
      if(isObject(%col.getMountedImage(0)) && %col.getMountedImage(0).gc_MeleeSystem == 1)
        if(%col.getImageState(0) $= "Block")
        {
          %eyePoint = %obj.getPosition();
          %v = %obj.getEyeVector();
          %mag2 = VectorLen(%V); 
          %x = (getWord(%eyePoint,0) - getWord(%col.getPosition(),0));
          %y = (getWord(%eyePoint,1) - getWord(%col.getPosition(),1));
          %z = (getWord(%eyePoint,2) - getWord(%col.getPosition(),2));
          %u = %x SPC %y SPC %z;
          %mag1 = VectorLen(%u);
          %result = VectorDot(%v,%u) / (%mag1*%mag2);
          %angle = mRadtoDeg(mAcos(%result));
          %angle -= 180;
          if(%angle > -70 && %angle < 70)
          {
            if(%this.gc_MeleeBlock < %col.getMountedImage(0).gc_MeleeBlock)
              %chance = 0;
            else
              %chance = 1;
            if(%chance) %col.setImageAmmo(0,1);
            %rnd = getRandom(1,2);
            if(%rnd == 1) serverPlay3D(gc_MeleeHit1Sound,%obj.getTransform());
            if(%rnd == 2) serverPlay3D(gc_MeleeHit2Sound,%obj.getTransform());
            return;
          }
        }
      serverPlay3D(gc_MeleeFleshHitSound,%obj.getTransform());
      if(getMiniGameFromObject(%col) == -1) return;
      if(miniGameCanDamage(%obj,%col) == 0) return;
      if(%col.isCrouched() == 1) { %col.damage(%obj,%pos,%this.directDamage*2,%this.directDamageType); return; }
      %colscale = getWord(%col.getScale(),2);
      if(getWord(%pos,2) > getWord(%col.getWorldBoxCenter(),2) - 3.3*%colscale) { %col.damage(%obj,%pos,%this.headDamage,%this.directDamageType); return; }
      %col.damage(%obj,%pos,%this.directDamage,%this.directDamageType);
      return;
    }
    %rnd = getRandom(1,2);
    if(%rnd == 1) serverPlay3D(gc_MeleeHit1Sound,%obj.getTransform());
    if(%rnd == 2) serverPlay3D(gc_MeleeHit2Sound,%obj.getTransform());
    if(%col.getType() & $TypeMasks::VehicleObjectType)
    {
      if(getMiniGameFromObject(%col) != -1 && miniGameCanDamage(%obj,%col) != 0) %col.damage(%obj,%pos,%this.vehicleDamage,%this.directDamageType);
    }
  }
}

package gc_MeleePackage
{
  function Armor::onTrigger(%this,%player,%slot,%val)
  {
    if(isObject(%player)) {
    if(%player.getMountedImage(0).gc_MeleeSecondary == 1 && %slot $= 4)
    {
      if(%player.getImageState(0) $= "Ready" && %val) %player.setImageAmmo(0,0);
      if(%player.getImageState(0) $= "Block" && !%val) %player.setImageAmmo(0,1);
    } }
    parent::onTrigger(%this,%player,%slot,%val);
  }
};
activatePackage(gc_MeleePackage);
