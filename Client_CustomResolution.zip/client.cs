exec("./CustomResolutionGUI.gui");

function CustomResolutionGUI::onWake()
{
	%currentwidth = getword($pref::Video::resolution,0);
	%currentheight = getword($pref::Video::resolution,1);
	%resolution = "Current Resolution: " @ %currentwidth SPC "x" SPC %currentheight;
	CustomResCurrent.setvalue(%resolution);
}

function isnumericvalue(%value)
{
     return (%value $= %value*1);
}

function setcustomresolution()
{
	%width = CustomWidthValue.getvalue();
	%height = CustomHeightValue.getvalue();
	if(%width < 640 || %height < 480)
		messageBoxOK("Whoops","You have not entered a valid resolution");
	else if(%width $= "" || %height $= "")
		messageBoxOK("Whoops","You have not entered a valid resolution");
	else if(!isnumericvalue(%width) || !isnumericvalue(%height))
		messageBoxOK("Whoops","You have not entered a valid resolution");
	else
	{
		setres(%width,%height);
		CustomWidthValue.setValue("");
		CustomHeightValue.setValue("");
		canvas.popdialog(CustomResolutionGUI);
	}
}

OptGraphicsPane.add(new GuiBitmapButtonCtrl() 
{
profile = "BlockButtonProfile";
horizSizing = "right";
vertSizing = "bottom";
position = "192 148";
extent = "109 36";
 minExtent = "8 2";
enabled = "1";
visible = "1";
clipToParent = "1";
command = "canvas.pushDialog(CustomResolutionGUI);";
text = "Custom Resolution";
groupNum = "-1";
buttonType = "PushButton";
bitmap = "base/client/ui/button2";
lockAspectRatio = "0";
alignLeft = "0";
overflowImage = "0";
mKeepCached = "0";
mColor = "255 255 255 255";
}
);








