addDamageType("MedSwordsPack",'<bitmap:add-ons/Weapon_Sword/CI_sword> %1','%2 <bitmap:add-ons/Weapon_Sword/CI_sword> %1',0.75,1);
if(!isObject(toolExplosionParticle))
{
datablock ParticleData(toolExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 300;
   textureName          = "base/data/particles/star1.png";
   colors[0]     = "0.7 0.7 0.9 0.9";
   colors[1]     = "0.9 0.9 0.9 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};
}

if(!isObject(toolExplosionEmitter))
{
datablock ParticleEmitterData(toolExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 8;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "toolExplosionParticle";
};
}
if(!isObject(toolExplosion))
{
datablock ExplosionData(toolExplosion)
{
   soundProfile = hammerHitSound;
   lifeTimeMS = 500;
   particleEmitter = toolExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;
   faceViewer     = true;
   explosionScale = "1 1 1";
   shakeCamera = false;
   lightStartRadius = 3;
   lightEndRadius = 0;
   lightStartColor = "00.0 0.2 0.6";
   lightEndColor = "0 0 0";
};
}
if(!isObject(bronzeBattleAxeProjectile))
{
datablock ProjectileData(bronzeBattleAxeProjectile)
{
   directDamage        = 8;
   explosion           = toolExplosion;
   muzzleVelocity      = 50;
   velInheritFactor    = 1;
   armingDelay         = 0.5;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;directDamageType=$DamageType::MedSwordsPack;
};
}
if(!isObject(bronzeBattleAxeItem))
{
datablock ItemData(bronzeBattleAxeItem)
{
        category = "Weapon";  // Mission editor category
        className = "Weapon"; // For inventory system
        shapeFile = "./shapes/BattleAxe.dts";
        mass = 1;
        density = 0.2;
        elasticity = 0.2;
        friction = 0.6;
        emap = true;
        uiName = "Bronze Battleaxe";
        iconName = "";
        doColorShift = true;
        colorShiftColor = "0.4 0.2 0 1";
        image = bronzeBattleAxeImage;
        canDrop = true;
};
}
if(!isObject(bronzeBattleAxeImage))
{
datablock ShapeBaseImageData(bronzeBattleAxeImage)
{
   shapeFile = "./shapes/BattleAxe.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0"; 
   correctMuzzleVector = false;
   eyeOffset = "0 0 0";
   className = "WeaponImage";
   item = bronzeBattleAxeItem;
   ammo = " ";
   projectile = bronzeBattleAxeProjectile;
   projectileType = Projectile;
   MedSwordsPack = true;
   doRetraction = false;
   armReady = true;
   doColorShift = true;
   colorShiftColor = "0.4 0.2 0 1";
        stateName[0]                     = "Activate";
        stateTimeoutValue[0]             = 0.5;
        stateTransitionOnTimeout[0]      = "Ready";

        stateName[1]                     = "Ready";
        stateTransitionOnTriggerDown[1]  = "PreFire";
        stateAllowImageChange[1]         = true;

        stateName[2]                        = "PreFire";
        stateScript[2]                  = "onPreFire";
        stateAllowImageChange[2]        = false;
        stateTimeoutValue[2]            = 0.1;
        stateTransitionOnTimeout[2]     = "Fire";

        stateName[3]                    = "Fire";
        stateTransitionOnTimeout[3]     = "CheckFire";
        stateTimeoutValue[3]            = 0.2;
        stateFire[3]                    = true;
        stateAllowImageChange[3]        = false;
        stateSequence[3]                = "Fire";
        stateScript[3]                  = "onFire";
        stateWaitForTimeout[3]                = true;

        stateName[4]                        = "CheckFire";
        stateTransitionOnTriggerUp[4]        = "StopFire";
        stateTransitionOnTriggerDown[4]        = "Fire";

        
        stateName[5]                    = "StopFire";
        stateTransitionOnTimeout[5]     = "Ready";
        stateTimeoutValue[5]            = 0.2;
        stateAllowImageChange[5]        = false;
        stateWaitForTimeout[5]                = true;
        stateSequence[5]                = "StopFire";
        stateScript[5]                  = "onStopFire";
};
}
function bronzeBattleAxeImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function bronzeBattleAxeImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
}

if(!isObject(steelBattleAxeProjectile))
{
datablock ProjectileData(steelBattleAxeProjectile)
{
   directDamage        = 17;
   explosion           = toolExplosion;
   muzzleVelocity      = 50;
   velInheritFactor    = 1;
   armingDelay         = 0.5;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;directDamageType=$DamageType::MedSwordsPack;
};
}
if(!isObject(steelBattleAxeItem))
{
datablock ItemData(steelBattleAxeItem)
{
        category = "Weapon";  // Mission editor category
        className = "Weapon"; // For inventory system
        shapeFile = "./shapes/BattleAxe.dts";
        mass = 1;
        density = 0.2;
        elasticity = 0.2;
        friction = 0.6;
        emap = true;
        uiName = "steel Battleaxe";
        iconName = "";
        doColorShift = true;
	colorShiftColor = "0.8 0.8 0.8 1";
        image = steelBattleAxeImage;
        canDrop = true;
};
}
if(!isObject(steelBattleAxeImage))
{
datablock ShapeBaseImageData(steelBattleAxeImage)
{
   shapeFile = "./shapes/BattleAxe.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0"; 
   correctMuzzleVector = false;
   eyeOffset = "0 0 0";
   className = "WeaponImage";
   item = steelBattleAxeItem;
   ammo = " ";
   projectile = steelBattleAxeProjectile;
   projectileType = Projectile;
   MedSwordsPack = true;
   doRetraction = false;
   armReady = true;
   doColorShift = true;
   colorShiftColor = "0.8 0.8 0.8 1";
        stateName[0]                     = "Activate";
        stateTimeoutValue[0]             = 0.5;
        stateTransitionOnTimeout[0]      = "Ready";

        stateName[1]                     = "Ready";
        stateTransitionOnTriggerDown[1]  = "PreFire";
        stateAllowImageChange[1]         = true;

        stateName[2]                        = "PreFire";
        stateScript[2]                  = "onPreFire";
        stateAllowImageChange[2]        = false;
        stateTimeoutValue[2]            = 0.1;
        stateTransitionOnTimeout[2]     = "Fire";

        stateName[3]                    = "Fire";
        stateTransitionOnTimeout[3]     = "CheckFire";
        stateTimeoutValue[3]            = 0.2;
        stateFire[3]                    = true;
        stateAllowImageChange[3]        = false;
        stateSequence[3]                = "Fire";
        stateScript[3]                  = "onFire";
        stateWaitForTimeout[3]                = true;

        stateName[4]                        = "CheckFire";
        stateTransitionOnTriggerUp[4]        = "StopFire";
        stateTransitionOnTriggerDown[4]        = "Fire";

        
        stateName[5]                    = "StopFire";
        stateTransitionOnTimeout[5]     = "Ready";
        stateTimeoutValue[5]            = 0.2;
        stateAllowImageChange[5]        = false;
        stateWaitForTimeout[5]                = true;
        stateSequence[5]                = "StopFire";
        stateScript[5]                  = "onStopFire";
};
}
function steelBattleAxeImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function steelBattleAxeImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
}

if(!isObject(ironBattleAxeProjectile))
{
datablock ProjectileData(ironBattleAxeProjectile)
{
   directDamage        = 12;
   explosion           = toolExplosion;
   muzzleVelocity      = 50;
   velInheritFactor    = 1;
   armingDelay         = 0.5;
   lifetime            = 100;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;directDamageType=$DamageType::MedSwordsPack;
};
}
if(!isObject(ironBattleAxeItem))
{
datablock ItemData(ironBattleAxeItem)
{
        category = "Weapon";  // Mission editor category
        className = "Weapon"; // For inventory system
        shapeFile = "./shapes/BattleAxe.dts";
        mass = 1;
        density = 0.2;
        elasticity = 0.2;
        friction = 0.6;
        emap = true;
        uiName = "iron Battleaxe";
        iconName = "";
        doColorShift = true;
	colorShiftColor = "0.73 0.62 0.52 1";
        image = ironBattleAxeImage;
        canDrop = true;
};
}
if(!isObject(ironBattleAxeImage))
{
datablock ShapeBaseImageData(ironBattleAxeImage)
{
   shapeFile = "./shapes/BattleAxe.dts";
   emap = true;
   mountPoint = 0;
   offset = "0 0 0"; 
   correctMuzzleVector = false;
   eyeOffset = "0 0 0";
   className = "WeaponImage";
   item = ironBattleAxeItem;
   ammo = " ";
   projectile = ironBattleAxeProjectile;
   projectileType = Projectile;
   MedSwordsPack = true;
   doRetraction = false;
   armReady = true;
   doColorShift = true;
   colorShiftColor = "0.73 0.62 0.52 1";
        stateName[0]                     = "Activate";
        stateTimeoutValue[0]             = 0.5;
        stateTransitionOnTimeout[0]      = "Ready";

        stateName[1]                     = "Ready";
        stateTransitionOnTriggerDown[1]  = "PreFire";
        stateAllowImageChange[1]         = true;

        stateName[2]                        = "PreFire";
        stateScript[2]                  = "onPreFire";
        stateAllowImageChange[2]        = false;
        stateTimeoutValue[2]            = 0.1;
        stateTransitionOnTimeout[2]     = "Fire";

        stateName[3]                    = "Fire";
        stateTransitionOnTimeout[3]     = "CheckFire";
        stateTimeoutValue[3]            = 0.2;
        stateFire[3]                    = true;
        stateAllowImageChange[3]        = false;
        stateSequence[3]                = "Fire";
        stateScript[3]                  = "onFire";
        stateWaitForTimeout[3]                = true;

        stateName[4]                        = "CheckFire";
        stateTransitionOnTriggerUp[4]        = "StopFire";
        stateTransitionOnTriggerDown[4]        = "Fire";

        
        stateName[5]                    = "StopFire";
        stateTransitionOnTimeout[5]     = "Ready";
        stateTimeoutValue[5]            = 0.2;
        stateAllowImageChange[5]        = false;
        stateWaitForTimeout[5]                = true;
        stateSequence[5]                = "StopFire";
        stateScript[5]                  = "onStopFire";
};
}
function ironBattleAxeImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}
function ironBattleAxeImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
}