//doubleBayonets.cs

datablock AudioProfile(doubleBayonetSound)
{
   filename    = "./doubleBayonet.wav";
   description = AudioClose3d;
   preload = true;
};

AddDamageType("doubleBayonets",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_twinbayonets> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_twinbayonets> %1',0.05,1);
datablock ProjectileData(doubleBayonetsProjectile : gunProjectile)
{
   directDamage        = 12;
   directDamageType    = $DamageType::doubleBayonets;
   radiusDamageType    = $DamageType::doubleBayonets;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 200;
   verticalImpulse	  = 100;
   explosion           = gunExplosion;
   particleEmitter     = nailgunTrailEmitter;

   explodeOnPlayerImpact = true;
   explodeondeath = true;

   muzzleVelocity      = 190;
   velInheritFactor    = 0;

   armingDelay         = 000;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(doubleBayonetsItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./bladed_pistol.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Twin Bayonets";
	iconName = "./twinbayonets";
	doColorShift = true;
	colorShiftColor = "0.4 0.4 0.4 1.000";

	 // Dynamic properties defined by the scripts
	image = doubleBayonetsImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(doubleBayonetsImage)
{
   // Basic Item properties
	shapeFile = "./bladed_pistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = doubleBayonetsProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = doubleBayonetsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.01;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = doubleBayonetSound;
	stateEmitter[2]					= quakeShotgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.17;
	stateEmitter[3]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[3]				= 0.09;
	stateEmitterNode[3]				= "muzzleNode";
	stateTransitionOnTimeout[3]     = "FireAkimbo";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTimeout[4] = "FireAkimbo";
	stateSequence[4] = "ready";

	stateName[5] = "FireAkimbo";
	stateTimeoutValue[5] = 0.18;
	stateScript[5] = "onFireAkimbo";
	stateTransitionOnTimeOut[5] = "ready";
};

function doubleBayonetsImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}

datablock ShapeBaseImageData(LeftHandeddoubleBayonetImage)
{
   // Basic Item properties
	shapeFile = "./bladed_pistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = doubleBayonetsProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = doubleBayonetsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";
   stateSound[0]		= weaponSwitchSound;

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.01;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = doubleBayonetSound;
	stateEmitter[2]					= quakeShotgunFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateEmitter[3]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[3]				= 0.09;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.17;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "Ready";
	stateSequence[4] = "ready";
};

function LeftHandeddoubleBayonetImage::onFire(%this, %obj, %slot)
{
	%projectile = doubleBayonetsProjectile;
	%spread = 0.0005;
	%shellcount = 1;

	%obj.playThread(2, leftrecoil);
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	%obj.spawnExplosion(QuakeLittleRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
			scale = "2 2 2";
		};
		MissionCleanup.add(%p);
	}
}

function doubleBayonetsImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftHandeddoubleBayonetImage, 1);
   //%obj.playThread(0, armreadyboth);
}
function doubleBayonetsImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount lefthanded gun
   %obj.unMountImage(1);
   //%obj.playThread(0, root);
}


function LeftHandeddoubleBayonetImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function LeftHandeddoubleBayonetImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
}

function doubleBayonetsImage::onFire(%this,%obj,%slot)
{
	%projectile = doubleBayonetsProjectile;
	%spread = 0.0016;
	%shellcount = 1;

	%obj.playThread(2, shiftAway);
  %fvec = %obj.getForwardVector();
  %fX = getWord(%fvec,0);
  %fY = getWord(%fvec,1);
  
  %evec = %obj.getEyeVector();
  %eX = getWord(%evec,0);
  %eY = getWord(%evec,1);
  %eZ = getWord(%evec,2);
  
  %eXY = mSqrt(%eX*%eX+%eY*%eY);
  
  %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	%obj.setVelocity(VectorAdd(%obj.getVelocity(),VectorScale(%aimVec,"-1")));
	%obj.spawnExplosion(QuakeLittleRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
			scale = "2 2 2";
		};
		MissionCleanup.add(%p);
	}
   //%obj.setImageTrigger(1,1);
}

datablock ProjectileData(doubleBayonetMeleeProjectile : quakeShotgunBlastProjectile)
{
   projectileShapeName = "";
	particleemitter = "";
   directDamage        = 50;
	muzzlevelocity = 200;
	impactimpulse = 2000;
   verticalImpulse	  = 1100;
};

datablock ShapeBaseImageData(doubleBayonetMeleeImage)
{
   // Basic Item properties
	shapeFile = "./bladed_pistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 -0.05";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = doubleBayonetMeleeProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 9.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = doubleBayonetsItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.01;
	stateTransitionOnTimeout[0]       = "Smoke";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Wait";
	stateTimeoutValue[2]            = 0.08;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= sawTomahawkThrowSound;

	stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.15;
	stateScript[3]                  = "onSwingUp";
	stateTransitionOnTimeout[3]     = "Fire";

	stateName[4] = "Wait";
	stateTimeoutValue[4]            = 0.3;
	stateTransitionOnTimeout[4]     = "Ready";
	stateScript[4]                  = "onDone";
};

function doubleBayonetMeleeImage::onFire(%this,%obj,%slot)
{
	%projectile = doubleBayonetMeleeProjectile;
	%shellcount = 1;
	%obj.playThread(2, shiftDown);

	%obj.spawnExplosion(QuakeLittleRecoilProjectile,"1 1 1");
            		
	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
}

function doubleBayonetMeleeImage::onSwingup(%this,%obj,%slot)
{
	%obj.playThread(2, shiftUp);
}

function doubleBayonetMeleeImage::onDone(%this,%obj,%slot)
{
		  %obj.mountImage(doubleBayonetsImage,0);
}

function doubleBayonetMeleeImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftHandeddoubleBayonetImage, 1);
   //%obj.playThread(0, armreadyboth);
}

function doubleBayonetMeleeImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount lefthanded gun
   %obj.unMountImage(1);
   //%obj.playThread(0, root);
}

package doubleBayonetDualfire
{
  	function Armor::onTrigger(%this, %player, %slot, %val)
	{
		if(%player.getMountedImage(0) $= doubleBayonetsImage.getID() && %slot $= 4 && %val)
		{
		  %player.mountImage(doubleBayonetMeleeImage,0);
		}     
		Parent::onTrigger(%this, %player, %slot, %val);
	}
};	
ActivatePackage(doubleBayonetDualfire);	
