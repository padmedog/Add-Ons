playerNoJet.minImpactSpeed = 12;

$RuinXmas::WaitForPlayers = 2;
$RuinXmas::NoSuicide = 0;

$RuinXmas::Camera0 = "-14.6 -75.5 35.7 -0.000713601 0.00086249 0.999999 1.75917";
$RuinXmas::Camera1 = "-27.5408 -3.18678 48.8218 0.592429 0.136476 -0.793978 0.564779";
$RuinXmas::Camera2 = "64.4455 -41.5163 33.1616 -0.166628 -0.165916 -0.97196 1.59495";
$RuinXmas::Camera3 = "45.389 42.2129 36.0423 -0.0283534 0.0534011 0.99817 2.16691";
$RuinXmas::Camera4 = "40.9538 13.8126 34.6732 -0.0605323 -0.0751458 -0.995334 1.78995";
$RuinXmas::Camera5 = "-45.2749 -66.2297 39.0023 0.121403 -0.0482788 0.991428 0.762931";
$RuinXmas::Cameras = 6;



function serverCmdStart(%client)
{
   if(!%client.isAdmin)
      return;
   if($RuinXmas::Stage !$= "0")
      return;
   if($RuinXmas::WaitForPlayers == 1)
      return;

   messageAll('', "\c3" @ %client.name @ " \c6is starting the next round.");
   $RuinXmas::WaitForPlayers = 1;
   cancel($RuinXmas::Schedule);
   RuinXmas_WaitForPlayers();
}

//EGH: changing $RuinXmas::WaitForPlayers to 1 everywhere ranther than figure this out.  also wtf is this formatting.

function RuinXmas_BeginWaitForPlayers()
{
   $RuinXmas::Stage = 0;
   cancel($RuinXmas::Schedule);
   if($Server::ServerType $= "SinglePlayer")
   {
      $RuinXmas::WaitForPlayers = 1;
   }
   else
   {
      $RuinXmas::WaitForPlayers = mCeil($Pref::Server::MaxPlayers / 2);
      if($RuinXmas::WaitForPlayers > 1)
         $RuinXmas::WaitForPlayers = 1;
      else if($RuinXmas::WaitForPlayers < 2)
         $RuinXmas::WaitForPlayers = 1;
   }
   centerprintall("\c6Waiting for players...");
   RuinXmas_WaitForPlayers();
}


function RuinXmas_WaitForPlayers(%tick)
{
   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
   {
      if(clientgroup.getobject(%i).hasSpawnedOnce)
         %players++;
   }

   if(%players>=$RuinXmas::WaitForPlayers)
   {
      if(!%tick)
         centerprintall("\c6Preparing the next round...",8);

      %tick++;

      if(%tick > 4)
      {
         RuinXmas_RoundPrep();
         return;
      }
   }
   else if(%tick)
      {
      %tick=0;
      centerprintall("\c6Waiting for players...");
   }

   $RuinXmas::Schedule = schedule(1800, 0, RuinXmas_WaitForPlayers, %tick);
}


function RuinXmas_RoundPrep()
{
   $RuinXmas::Stage=1;

   %spawns=Brickgroup_888888.ntObjectCount_presentSpawn;
   for(%i = %spawns - 1; %i > -1; %i--)
      %spawn[%i] = Brickgroup_888888.ntObject_presentSpawn_[%i];

   %presents = $Server::PlayerCount;
   if(%presents < 3)
      %presents = 3;
   else if(%presents > 8)
      %presents = 8;

   %presents = 6 + 3 * %presents;
   while(%presents > 0 && %spawns>0)
   {
      %sp=getrandom(0,%spawns-1);
      %spawn[%sp].setItem("presentItem"@getrandom(0, $presentColors - 1));
      %spawn[%sp] = %spawn[%spawns--];
      %presents--;
   }
 
   $RuinXmas::Camera=getrandom(0, $RuinXmas::Cameras-1);
 
   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
   {
      %cl = clientgroup.getobject(%i);
      %cl.setscore(0);
      %cl.instantRespawn();
   }
   //ServerPlay2D(IncidentalMusic_Piano_Bass);
   schedule(500, 0, ServerPlay3D, IncidentalMusic_Piano_Bass, vectoradd($RuinXmas::Camera[$RuinXmas::Camera], "0 0 3"));
   centerprintall("<font:impact:64>\c2BLOCKHEADS \c0RUIN \c2X\c0M\c2A\c0S", 10);
   $RuinXmas::Schedule = schedule(6600, 0, RuinXmas_RoundIntro);
}


function RuinXmas_RoundIntro()
{
   $RuinXmas::Stage = 2;
 
   %presents = $Server::PlayerCount;

   if(%presents < 3)
      %presents = 3;
   else if(%presents > 8)
      %presents = 8;

   %presents = 14 + 2 * %presents;
   Santa_Spawn(%presents);
 
   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
      clientgroup.getobject(%i).instantrespawn();

   centerprintall("\c6S\c0a\c6n\c0t\c6a \c0C\c6l\c0a\c6u\c0s \c6is coming to town!", 10);
   $RuinXmas::Schedule = schedule(6500, 0, RuinXmas_RoundSpawn);
}


function RuinXmas_RoundSpawn()
{
   $RuinXmas::Stage = 3;
   messageall('', "\c6Round Start.");

   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
      clientgroup.getobject(%i).instantrespawn();

   centerprintall("\c6Destroy the presents to \c0Ruin \c2X\c0m\c2a\c0s\c6!", 8);
}


function RuinXmas_RoundCountdown(%tick)
{
   if(%tick $= "")
   {
      centerprintall("\c6S\c0a\c6n\c0t\c6a \c0C\c6l\c0a\c6u\c0s \c6is leaving!\n\c660 Seconds Remain", 4);
      $RuinXmas::Schedule = schedule(30000, 0, RuinXmas_RoundCountdown, 30);
      return;
   }

   if(%tick == 30)
   {
      centerprintall("\c630 Seconds Remain", 3);
      $RuinXmas::Schedule = schedule(20000, 0, RuinXmas_RoundCountdown, 10);
      return;
   }
   centerprintall("<font:impact:64>\c6" @ %tick, 2);

   if(%tick == 1)
   {
      $RuinXmas::Schedule = schedule(1500, 0, RuinXmas_RoundEnd);
      return;
   }
   $RuinXmas::Schedule = schedule(1000, 0, RuinXmas_RoundCountdown, %tick - 1);
}


function RuinXmas_RoundEnd()
{
   $RuinXmas::Stage = 4;
   clearcenterprintall();
   RuinXmas_CleanUpPresents();
   RuinXmas_CloseAllDoors();

   for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
      clientgroup.getobject(%i).instantrespawn();

   RuinXmas_PresentSpam();

   $RuinXmas::Schedule = schedule(8000, 0, RuinXmas_RoundOutro);
}


function RuinXmas_PresentSpam(%tick)
{
   %data = "presentItem" @ getrandom(0, $presentColors - 1);
   %pos = vectoradd("11 -31.5 80", getrandom(-7, 7) SPC getrandom(-7, 7) SPC 0);

   %i = new Item()
   {
      datablock = %data;
      position = %pos;
   };
   missionCleanup.add(%i);
   %i.setvelocity("0 0 -50");

   if(%tick == 25)
   {
      centerprintall("<font:impact:64>RUINED", 10);
      //ServerPlay2D(beep_denied_sound);
      ServerPlay3D(beep_denied_sound, "-0.7 -19 72");
   }

   if(%tick < 35)
      schedule(200, 0, RuinXmas_PresentSpam, %tick + 1);
}


function RuinXmas_RoundOutro()
{
   $RuinXmas::Stage = 5;
   %clients = clientgroup.getcount();
   %max = -1;
   for(%i = %clients - 1; %i > -1; %i--)
   {
      %cl = clientgroup.getobject(%i);
      %score[%cl] = %cl.score;
      %client[%i] = %cl;
   }
 
   for(%j = 0; %j < 4; %j++)
   {
      %max = -999998;
      %time = 999999;

      for(%i = %clients - 1; %i > -1; %i--)
      {
         if(%score[%client[%i]] == %max)
         {
            if(%client[%i].lastPresent < %time)
            {
               %max = %score[%client[%i]];
               %baby[%j] = %client[%i];
               %time = %client[%i].lastPresent;
            }
         }
         else if(%score[%client[%i]] > %max)
         {
            %max = %score[%client[%i]];
            %baby[%j] = %client[%i];
            %time = %client[%i].lastPresent;
         }
      }

      %score[%baby[%j]] = -999999;
   }
 
 RuinXmas_Babies(%baby0,%baby1,%baby2,%baby3);
}


function RuinXmas_Babies(%winner, %baby1, %baby2, %baby3, %tick)
{
   if(%tick == 0)
   {
      %b = new aiplayer() 
      { 
         datablock = playernojet;
      };
      missionCleanup.add(%b);

      %b.client = %winner;
      %b.name = %winner.name;
      %b.score = %winner.score;
      %pl = %winner.player;
      %winner.player = %b;
      %winner.applybodyparts();
      %winner.applybodycolors();
      %winner.player = %pl;
      %winner = %b;
      %winner.settransform("-24 -104.5 32.8 0 0 -1 1.5708");

      for(%i=1;%i<4;%i++)
      {
         %baby[%i] = RuinXmas_CreateBaby(%baby[%i]);
         %baby[%i].settransform(vectoradd("-25 -106 32.6", (-2*%i) SPC 0 SPC 0) SPC "0 0 -1 0");
         %data = "presentItem" @ (%i * 2 - 2);
         %baby[%i].present = new Item() 
         {
            datablock = %data;
            position = vectoradd("-25.1 -104.5 33", (-2*%i) SPC 0 SPC 0);
         };
         missionCleanup.add(%baby[%i].present);
      }

      $RuinXmas::Schedule = schedule(1000, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 1);
      return;
   }
 
   if(%tick == 1)
   {
      clearcenterprintall();

      for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
         clientgroup.getobject(%i).instantrespawn();

      %winner.setvelocity("-4 0 10");
      $RuinXmas::Schedule = schedule(950, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 2);
   }
 
   if(%tick == 2)
   {
      %pos = %baby1.present.getposition();
      %baby1.present.delete();
      RuinXmas_BabyAddTears(%baby1);

      %p = new projectile()
      { 
         datablock = vehicleExplosionProjectile;
         initialPosition = %pos;
      };
      missionCleanup.add(%p);

      %winner.setvelocity("-2.5 0 10");
      $RuinXmas::Schedule = schedule(950, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 3);
   }
 
   if(%tick==3)
   {
      %pos = %baby2.present.getposition();
      %baby2.present.delete();
      RuinXmas_BabyAddTears(%baby2);

      %p = new projectile() 
      {
         datablock = vehicleExplosionProjectile;
         initialPosition = %pos;
      };
      missionCleanup.add(%p);

      %winner.setvelocity("-2.5 0 10");
      $RuinXmas::Schedule = schedule(950, 0, RuinXmas_Babies, %winner,%baby1, %baby2, %baby3, 4);
   }
 
   if(%tick==4)
   {
      %pos = %baby3.present.getposition();
      %baby3.present.delete();
      RuinXmas_BabyAddTears(%baby3);

      %p = new projectile()
      {
         datablock = vehicleExplosionProjectile;
         initialPosition = %pos;
      };
      missionCleanup.add(%p);

      %winner.setvelocity("-3.5 0 10");
      $RuinXmas::Schedule = schedule(1200, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 4.5);
   }
 
   if(%tick == 4.5)
   {
      %winner.setmovedestination("-34 -106 32.8");
      $RuinXmas::Schedule = schedule(1100, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 5);
   }
 
   if(%tick == 5)
   {
      %winner.stop();
      %winner.settransform("-34 -106 32.8 0 0 1 1.5708");
      %winner.setvelocity("3 0 14");
      $RuinXmas::Schedule = schedule(1100, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 6);
   }
 
   if(%tick == 6)
   {
      RuinXmas_BabyRemoveTears(%baby3);
      %baby3.playdeathanimation();
      %baby3.playdeathcry();
      %baby3.emote(painhighimage);
      %winner.setvelocity("3 0 9");
      $RuinXmas::Schedule = schedule(850, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 7);
   }
 
   if(%tick == 7)
   {
      RuinXmas_BabyRemoveTears(%baby2);
      %baby2.playdeathanimation();
      %baby2.playdeathcry();
      %baby2.emote(painhighimage);
      %winner.setvelocity("3 0 9");
      $RuinXmas::Schedule = schedule(850, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 8);
   }

   if(%tick == 8)
   {
      RuinXmas_BabyRemoveTears(%baby1);
      %baby1.playdeathanimation();
      %baby1.playdeathcry();
      %baby1.emote(painhighimage);
      %winner.setvelocity("5 0 10");
      $RuinXmas::Schedule = schedule(1600, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 9);
   }

   if(%tick == 9)
   {
      %winner.settransform("-24 -104.5 32.8 0 0 -1 1.5708");
      %winner.setmovedestination("-29 -102.5 32.8");
      $RuinXmas::Schedule = schedule(2200, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 10);
   }

   if(%tick == 10)
   {
      %winner.stop();
      %winner.setaimlocation("-29 -100 35");
      //ServerPlay2D(IncidentalMusic_Stress_);
      ServerPlay3D(IncidentalMusic_Stress_,"-29 -100 38");
      centerprintall("<font:impact:64><br><br>\c2" @ strupr(%winner.client.name) @ " \c0RUINED \c2X\c0M\c2A\c0S", 10);
      $RuinXmas::Schedule = schedule(7500, 0, RuinXmas_Babies, %winner, %baby1, %baby2, %baby3, 11);
   }
 
   if(%tick == 11)
   {
      $RuinXmas::Stage = 0;
      messageall('', "\c6Round End. \c0" @ %winner.name @ " \c7wins! (" @ %winner.score @ " points)");

      for(%i = clientgroup.getcount() - 1; %i > -1; %i--)
         clientgroup.getobject(%i).instantrespawn();

      %winner.delete();

      for(%i = 1; %i < 4; %i++)
         %baby[%i].delete();

      RuinXmas_BeginWaitForPlayers();
   }

}



function RuinXmas_CreateBaby(%client)
{
   %b = new aiplayer()
   {
      datablock = playernojet;
   };
   missionCleanup.add(%b);

   if(isobject(%client))
   {
      %face = %client.faceName;
      %skin = %client.headColor;
      %hat = %client.hat;
      %hatColor = %client.hatColor;
      %accent = %client.accent;
      %accentColor = %client.accentColor;
   }
   else
   {
      %face = "smiley";
      %skin = "0.9 0.7 0.5 1";
      //%skin=HSVtoRGB(getrandom(),0.4,1) SPC 1;
   }
 
   %b.hideNode("chest");
   %b.hideNode("lArm");
   %b.hideNode("rArm");
   %b.unhideNode("femChest");
   %b.unhideNode("lArmSlim");
   %b.unhideNode("rArmSlim");

   if(%hat)
   {
      %b.unhideNode($hat[%hat]);
      %b.setnodecolor($hat[%hat], %hatcolor);

      if(%accent)
      {
         if(stripos($accentsAllowed[$hat[%hat]], $accent[%accent]) != -1)
         {
            %b.unhideNode($accent[%accent]);
            %b.setnodecolor($accent[%accent], %accentcolor);
         }
      }
   }
 
   %b.setfacename(%face);
   %b.setnodecolor("headSkin", %skin);
   %b.setnodecolor("femChest", %skin);
   %b.setnodecolor("lArmSlim", %skin);
   %b.setnodecolor("rArmSlim", %skin);
   %b.setnodecolor("lHand", %skin);
   %b.setnodecolor("rHand", %skin);
   %b.setnodecolor("lShoe", %skin);
   %b.setnodecolor("rShoe", %skin);
   %b.setnodecolor("pants", "0.9 0.9 0.9 1");
   %b.setscale("0.8 0.8 0.8");
   %b.playthread(0, sit);
   return(%b);
}



function RuinXmas_BabyAddTears(%baby)
{
   %eye = %baby.geteyetransform();
   %e = new particleemitternode()
   {
    datablock = genericemitternode;
    emitter = crybabyemitter;
   };
   missionCleanup.add(%e);
   %e.settransform(vectoradd(%eye, "0.1 0 0.05") SPC "1 -0.4 0 1");
   %e.setscale("0.01 0.01 0.01");
   %baby.tearsR = %e;

   %e = new particleemitternode()
   {
      datablock = genericemitternode;
      emitter = crybabyemitter;
   };
   missionCleanup.add(%e);
   %e.settransform(vectoradd(%eye, "-0.1 0 0.05") SPC "1 0.4 0 1");
   %e.setscale("0.01 0.01 0.01");
   %baby.tearsL = %e;
}


function RuinXmas_BabyRemoveTears(%baby)
{
   %baby.tearsL.delete();
   %baby.tearsR.delete();
}


function RuinXmas_SetCamera(%cl)
{
   if(!isobject(%cl))
      return;
   if(!isobject(%cl.camera))
      return;
   if($RuinXmas::Stage $= "")
      return;
   if($RuinXmas::Stage == 3)
      return;
   if($RuinXmas::Stage == 2)
   {
      %cl.camera.setmode("Observer");
      %cl.setcontrolobject(%cl.camera);
      %cl.camera.setcontrolobject(%cl.camera);
      %cl.camera.setorbitmode($santa,"",10,20,10,1);
      %cl.player.settransform("75 32.5 0.1");
      return;
   }
 
   switch($RuinXmas::Stage)
   {
      case(0): %tr = "50.1166 6.25717 138.842 -0.22567 -0.536883 0.812914 3.80011";
      case(1): %tr = $RuinXmas::Camera[$RuinXmas::Camera];
      case(4): %tr = "-0.7 -19 69 0.205655 -0.528548 0.823616 2.52134";
      case(5): %tr = "-29 -100 35 0 -0.09 0.995 3.14159";
   }
   %cl.camera.setmode("Observer");
   %cl.camera.settransform(%tr);
   %cl.setcontrolobject(%cl.camera);
   %cl.camera.setcontrolobject(%cl.player);
   %cl.player.settransform("75 32.5 0.1");
}


function RuinXmas_CleanUpPresents()
{
   while($presents)
      $present0.delete();
}


function RuinXmas_CloseAllDoors()
{
   for(%i = brickgroup_888888.ntobjectcount_door - 1; %i > -1; %i--)
      brickgroup_888888.ntobject_door_[%i].door(4);
}


function Player::Stun(%this,%time)
{
   //%time=mFloor(%time);
   if(%time == 0)
   {
      %this.unstun();
      return;
   }
   if(%this.stunned)
      return;

   %this.stunned = 1;
   %this.unmountimage(0);
   %this.playdeathanimation();
   if(%this.snowballPlayerType !$= "")
      %this.setdatablock(%this.snowballPlayerType);
   %this.snowballPlayerType = "";

   if(isobject(%cl = %this.client))
   {
      %cl.setcontrolobject(%cl.camera);
      %cl.camera.setorbitmode(%this, "", 4, 12, 4, 1);
      %cl.camera.setwhiteout(0.7);
   }
 
   if(%time > 0)
      %this.stunSched = %this.schedule(%time*1000, unStun);
}


function Player::UnStun(%this)
{
   if(!%this.stunned)
      return;
   %this.stunned="";
   %this.stunSched="";

   if(!%this.isdisabled())
      %this.playthread(3,root);

   %this.setwhiteout(0);

   if(isobject(%cl=%this.client))
   {
      %cl.camera.setwhiteout(0);
      %cl.setcontrolobject(%this);
      %cl.camera.setflymode();
   }
}


function Player::makeSnowball(%obj,%stage)
{
   if(%obj.stunned)
      return;
   if(%obj.getmountedimage(0))
      return;

   if(%obj.snowballPlayerType!$="")
   {
      if(%stage==1)
         %obj.setdatablock(%obj.snowballPlayerType);
      else
         return;
   }
 
   if(%stage==1)
   {
      %obj.snowballPlayerType="";
      %obj.mountimage(SnowballImage,0);
      %obj.client.play3d(brickRotateSound,vectoradd(%obj.client.player.geteyetransform(),"0 0 5"));
      return;
   }

   if(vectorlen(%obj.getvelocity())>8)
      return;
   if(%obj.snowballPlayerType!$="")
      return;

   %obj.setvelocity("0 0 0");
   %obj.snowballPlayerType = %obj.getdatablock();
   %obj.setdatablock(PlayerCantMove);
   %obj.client.play3d(brickChangeSound, vectoradd(%obj.client.player.geteyetransform(), "0 0 5"));
   %obj.schedule(150, playthread, 0, activate2);
   %obj.schedule(300, playthread, 0, activate2);
   %obj.schedule(450, playthread, 0, activate2);
   %obj.schedule(600, makeSnowball, 1);
}









package RuinXmas
{
 
   function onServerDestroyed()
   {
      cancel($RuinXmas::Schedule);
      deleteVariables("$RuinXmas::*");
      echo("\c2RuinXmas : server destroyed, shutting down");
      parent::onServerDestroyed();
   }
 

   function GameConnection::OnClientEnterGame(%client)
   {
      parent::OnClientEnterGame(%client);

      //when second player joins, reset score so that there's a chance of a real game
      if(clientGroup.getCount() == 2)
      {
         messageAll('', "\c7Resetting scores!");
         for(%i = 0; %i < clientGroup.getCount(); %i++)
         {
            clientGroup.getObject(%i).score = 0;
         }
      }

      if($RuinXmas::Stage $= "0")
      {
         if($Server::ServerType $= "SinglePlayer")
         {
            messageclient(%client, '', "\c0NOTE: \c6Blockheads Ruin Xmas is intended for multiplayer!");
         }
         else if(%client.isAdmin)
         {
            if($RuinXmas::WaitForPlayers > 1)
               messageclient(%client, '', "\c7Currently waiting for \c2" @ $RuinXmas::WaitForPlayers @ " \c7player" @ ($RuinXmas::WaitForPlayers == 1 ? "" : "s") @ ", or type \c6/start \c7to play now.");
         }

         centerprint(%client, "\c6Waiting for players...");
      }
      else if($RuinXmas::Stage == 3)
      {
         centerprint(%this, "\c6Destroy the presents to \c0Ruin \c2X\c0m\c2a\c0s\c6!",8);
      }
   }
 

   function GameConnection::SpawnPlayer(%this)
   {
      parent::SpawnPlayer(%this);
      %this.player.setshapenamedistance(16);
      schedule(12, 0, RuinXmas_SetCamera, %this);
   }
 

   function Player::ActivateStuff(%obj)
   {
      parent::ActivateStuff(%obj);

      %pos = %obj.geteyetransform();
      %t = containerraycast(%pos, vectoradd(%pos, vectorscale(%obj.geteyevector(), 4)), $typemasks::fxbrickobjecttype);
      if(!%t)
         return;

      if(%t.getcolorid() == 15)
         %obj.makeSnowball();
   }


   function PlayerStandardArmor::OnDisabled(%this, %obj, %state)
   {
      if(%obj.hasPresent)
         %obj.unmountimage(0);
      parent::OnDisabled(%this, %obj, %state);
   }
 

   function PlayerNoJet::OnDisabled(%this, %obj, %state)
   {
      if(%obj.hasPresent)
         %obj.unmountimage(0);
      parent::OnDisabled(%this, %obj, %state);
   }
 

   function brickChristmasTreeData::OnPlant(%this, %obj)
   {
      $xmasTree[$xmasTrees++ - 1] = %obj;
      parent::OnPlant(%this, %obj);
   }
 

   function brickChristmasTreeData::OnLoadPlant(%this, %obj)
   {
      $xmasTree[$xmasTrees++ - 1] = %obj;
      parent::OnLoadPlant(%this, %obj);
   }
 

   function brickChristmasTreeData::OnDeath(%this, %obj)
   {
      for(%i = $xmasTrees - 1; %i > -1; %i--)
      {
         if($xmasTree[%i] == %obj)
         {
            $xmasTree[%i] = $xmasTree[$xmasTrees--];
            break;
         }
      }
      parent::OnDeath(%this, %obj);
   }
 

   function brickChristmasTreeData::OnRemove(%this, %obj)
   {
      for(%i = $xmasTrees - 1; %i > -1; %i--)
      {
         if($xmasTree[%i] == %obj)
         {
            $xmasTree[%i] = $xmasTree[$xmasTrees--];
            break;
         }
      }
      parent::OnRemove(%this,%obj);
   }


   function servercmdSuicide(%client)
   {
      if($RuinXmas::Stage !$= "")
         if($RuinXmas::Stage != 3 || $RuinXmas::NoSuicide)
            return;
      parent::servercmdSuicide(%client);
   }
 

   function brick32xWaterData::OnLoadPlant(%this, %obj)
   {
      %fx = %obj.getshapefxid();
      parent::OnLoadPlant(%this, %obj);
      %obj.setshapefx(%fx);
   }


   function PlayerNoJet::OnImpact(%this,%obj,%col,%vec,%force)
   {
      parent::onImpact(%this, %obj, %col, %a, %b, %c);
      if(%force < 12)
         return;
      if(%col.getdatablock() != %this)
         return;
      if(%obj.stunned || %col.stunned)
         return;
      if(vectornormalize(%vec) !$= "0 0 1")
         return;

      %force = mFloor(%force);
      %col.stun(3.5);
      ServerPlay3D(fastimpactsound, %col.getposition());
      bottomprint(%col.client, "<bitmap:base/client/ui/ci/crater> \c0Stomp \c6from \c0" @ %obj.client.name @ " \c6at \c0" @ %force @ " \c6ft/sec.", 4);
      bottomprint(%obj.client, "<bitmap:base/client/ui/ci/crater> \c0Stomp \c6to \c0" @ %col.client.name @ " \c6at \c0" @ %force @ " \c6ft/sec.", 4);
   }
 

   function serverCmdUseHammer(%client)
   {
      return;
   }
 

   function serverCmdUsePrintGun(%client)
   {
      return;
   }

   //egh: replacing present raycast schedule loop with a callback for entering water
   function ItemData::onEnterLiquid(%data, %obj, %coverage, %type)
   {
      //Parent::onEnterLiquid(%data, %obj, %coverage, %type);

      if(strnicmp(%data.getName(), "presentItem", strlen("presentItem")))
         return;
   
      //nasty hack since the streets are covered with a small amount of water
      if(getWord(%obj.getPosition(), 2) > 25)
         return;
   
      %pos = %obj.getposition();
      %cl = %obj.owner;
      %obj.delete();
      %p = new projectile()
      {
         datablock = vehicleFinalExplosionProjectile;
         initialPosition = %pos;
      };
      missionCleanup.add(%p);

      if(!isobject(%cl))
         return;
      %cl.incscore(1);
      %cl.lastPresent = $sim::time;

      if(%cl.score == 1)
         messageall('', "<bitmap:base/client/ui/ci/bomb>\c0" @ %cl.name @ " \c7destroyed a present! (1 point)");
      else
         messageall('', "<bitmap:base/client/ui/ci/bomb>\c0" @ %cl.name @ " \c7destroyed a present! (" @ %cl.score @ " points)");
      
   }

   //egh: players should die in water
   function Armor::onEnterLiquid(%data, %obj, %coverage, %type)
   {
      //Parent::onEnterLiquid(%data, %obj, %coverage, %type);
      %obj.hasShotOnce = true;
      %obj.invulnerable = false;
      
      //fire dead people out of the volcano
      %doBurn = false;
      if(%obj.getDamagePercent() < 1.0)
         %doBurn = true;
      
      %obj.damage(%obj, %obj.getPosition(), 10000, $DamageType::Fire);

      if(%doBurn)
      {
         %obj.burnPlayer(5);
         %obj.setVelocity("0 0 45");

         %p = new projectile()
         {
            datablock = vehicleFinalExplosionProjectile;
            initialPosition = %obj.getPosition();
         };
         missionCleanup.add(%p);

         //burn image gets skipped in player::burn due to water coverage
         %obj.mountImage(PlayerBurnImage, 3);
      }      
   }

};
activatepackage(RuinXmas);