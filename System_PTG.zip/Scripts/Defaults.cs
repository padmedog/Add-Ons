//Basic Options
$Sd = "6257146872";$UseSd=1;   $GSx = 64;$GSy = 0;   $GEx = 128;$GEy = 64;
$BioA = 1;$BioC = 0;$BioD = 0;$BioE = 0;   $SolG = 0;$Cav = 0;$Clo = 0;$Holes = 0;$Bnds = 0;
$LDet = 0;$SDet = 0;$MDet = 0;   $PlaC = 0;$ModTer = 0;$GFill = 0;
$SanL = 10;$WatL = 9;$TerHO = 20;$CloH = 80;$BndsH = 70;   $Norm = 1;$Plai = 0;$FloI = 0;

//Advanced Options
$ChS = 32;$ChBD = 1;$TerSS = 1;$BioSS = 2;$TerHS = 1;$TerHM = 7;
$DetF = 50;$CloL = 15;$FISH = 20;$BioO=5;$BioSH=15;$SCoV = 0.01;

//Basic Colors and Prints
$ColDirt = 0;$PriDirt = 0;
$ColDirtb = 0;$PriDirtb = 0;
$ColSand = 0;$PriSand = 0;
$ColStone = 0;$PriStone = 0;
$ColClouds = 0;$PriClouds = 0;
$ColBounds = 0;$PriBounds = 0;

//Biome Terrain Colors and Prints
$ColBio = 0;$PriBio = 0;
$ColBioc = 0;$PriBioc = 0;
$ColBiod = 0;$PriBiod = 0;
$ColBioe = 0;$PriBioe = 0;

//Biome Dirt Colors and Prints
$ColBioDrt = 0;$PriBioDrt = 0;
$ColBiocDrt = 0;$PriBiocDrt = 0;
$ColBiodDrt = 0;$PriBiodDrt = 0;
$ColBioeDrt = 0;$PriBioeDrt = 0;

//Biome Water Colors and Prints
$ColBioWat = 0;$PriBioWat = 0;
$ColBiocWat = 0;$PriBiocWat = 0;
$ColBiodWat = 0;$PriBiodWat = 0;
$ColBioeWat = 0;$PriBioeWat = 0;

//BiomeA Detail Colors,Bricks and Prints
$ColBioLDet = 0;$BriBioLDet = NA;$PriBioLDet = 0;
$ColBioLDetb = 0;$BriBioLDetb = NA;$PriBioLDetb = 0;
$ColBioLDetc = 0;$BriBioLDetc = NA;$PriBioLDetc = 0;
$ColBioSDet = 0;$BriBioSDet = NA;$PriBioSDet = 0;
$ColBioSDetb = 0;$BriBioSDetb = NA;$PriBioSDetb = 0;
$ColBioSDetc = 0;$BriBioSDetc = NA;$PriBioSDetc = 0;
$ColBioMDet = 0;$BriBioMDet = NA;$PriBioMDet = 0;
$ColBioMDetb = 0;$BriBioMDetb = NA;$PriBioMDetb = 0;
$ColBioMDetc = 0;$BriBioMDetc = NA;$PriBioMDetc = 0;

//BiomeB (Shore) Detail Colors,Bricks and Prints
$ColBiobLDet = 0;$BriBiobLDet = NA;$PriBiobLDet = 0;
$ColBiobLDetb = 0;$BriBiobLDetb = NA;$PriBiobLDetb = 0;
$ColBiobLDetc = 0;$BriBiobLDetc = NA;$PriBiobLDetc = 0;
$ColBiobSDet = 0;$BriBiobSDet = NA;$PriBiobSDet = 0;
$ColBiobSDetb = 0;$BriBiobSDetb = NA;$PriBiobSDetb = 0;
$ColBiobSDetc = 0;$BriBiobSDetc = NA;$PriBiobSDetc = 0;
$ColBiobMDet = 0;$BriBiobMDet = NA;$PriBiobMDet = 0;
$ColBiobMDetb = 0;$BriBiobMDetb = NA;$PriBiobMDetb = 0;
$ColBiobMDetc = 0;$BriBiobMDetc = NA;$PriBiobMDetc = 0;

//BiomeC Detail Colors,Bricks and Prints
$ColBiocLDet = 0;$BriBiocLDet = NA;$PriBiocLDet = 0;
$ColBiocLDetb = 0;$BriBiocLDetb = NA;$PriBiocLDetb = 0;
$ColBiocLDetc = 0;$BriBiocLDetc = NA;$PriBiocLDetc = 0;
$ColBiocSDet = 0;$BriBiocSDet = NA;$PriBiocSDet = 0;
$ColBiocSDetb = 0;$BriBiocSDetb = NA;$PriBiocSDetb = 0;
$ColBiocSDetc = 0;$BriBiocSDetc = NA;$PriBiocSDetc = 0;
$ColBiocMDet = 0;$BriBiocMDet = NA;$PriBiocMDet = 0;
$ColBiocMDetb = 0;$BriBiocMDetb = NA;$PriBiocMDetb = 0;
$ColBiocMDetc = 0;$BriBiocMDetc = NA;$PriBiocMDetc = 0;

//BiomeD Detail Colors,Bricks and Prints
$ColBiodLDet = 0;$BriBiodLDet = NA;$PriBiodLDet = 0;
$ColBiodLDetb = 0;$BriBiodLDetb = NA;$PriBiodLDetb = 0;
$ColBiodLDetc = 0;$BriBiodLDetc = NA;$PriBiodLDetc = 0;
$ColBiodSDet = 0;$BriBiodSDet = NA;$PriBiodSDet = 0;
$ColBiodSDetb = 0;$BriBiodSDetb = NA;$PriBiodSDetb = 0;
$ColBiodSDetc = 0;$BriBiodSDetc = NA;$PriBiodSDetc = 0;
$ColBiodMDet = 0;$BriBiodMDet = NA;$PriBiodMDet = 0;
$ColBiodMDetb = 0;$BriBiodMDetb = NA;$PriBiodMDetb = 0;
$ColBiodMDetc = 0;$BriBiodMDetc = NA;$PriBiodMDetc = 0;

//BiomeE Detail Colors,Bricks and Prints
$ColBioeLDet = 0;$BriBioeLDet = NA;$PriBioeLDet = 0;
$ColBioeLDetb = 0;$BriBioeLDetb = NA;$PriBioeLDetb = 0;
$ColBioeLDetc = 0;$BriBioeLDetc = NA;$PriBioeLDetc = 0;
$ColBioeSDet = 0;$BriBioeSDet = NA;$PriBioeSDet = 0;
$ColBioeSDetb = 0;$BriBioeSDetb = NA;$PriBioeSDetb = 0;
$ColBioeSDetc = 0;$BriBioeSDetc = NA;$PriBioeSDetc = 0;
$ColBioeMDet = 0;$BriBioeMDet = NA;$PriBioeMDet = 0;
$ColBioeMDetb = 0;$BriBioeMDetb = NA;$PriBioeMDetb = 0;
$ColBioeMDetc = 0;$BriBioeMDetc = NA;$PriBioeMDetc = 0;

//BiomeF (Underwater) Detail Colors,Bricks and Prints
$ColBiofLDet = 0;$BriBiofLDet = NA;$PriBiofLDet = 0;
$ColBiofLDetb = 0;$BriBiofLDetb = NA;$PriBiofLDetb = 0;
$ColBiofLDetc = 0;$BriBiofLDetc = NA;$PriBiofLDetc = 0;
$ColBiofSDet = 0;$BriBiofSDet = NA;$PriBiofSDet = 0;
$ColBiofSDetb = 0;$BriBiofSDetb = NA;$PriBiofSDetb = 0;
$ColBiofSDetc = 0;$BriBiofSDetc = NA;$PriBiofSDetc = 0;
$ColBiofMDet = 0;$BriBiofMDet = NA;$PriBiofMDet = 0;
$ColBiofMDetb = 0;$BriBiofMDetb = NA;$PriBiofMDetb = 0;
$ColBiofMDetc = 0;$BriBiofMDetc = NA;$PriBiofMDetc = 0;