datablock AudioProfile(fragGrenadeExplosionSound)
{
   filename    = "./FragExplode.wav";
   description = AudioDefault3d;
   preload = false;
};

datablock AudioProfile(fragGrenadeBounceSound)
{
   filename    = "./fragGrenadeBounce.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(fragGrenadeFireSound)
{
   filename    = "./fragGrenadeFire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock DebrisData(fragGrenadePinDebris)
{
	shapeFile = "./FragGrenadepin.dts";
	lifetime = 5.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ParticleData(fragGrenadeExplosionParticle)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.2;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 4000;
	lifetimeVarianceMS	= 3990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.2 0.2 0.2 1.0";
	colors[1]	= "0.25 0.25 0.25 0.2";
   colors[2]	= "0.4 0.4 0.4 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 10.0;
   sizes[2]	= 13.0;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(fragGrenadeExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 10;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 90;
   overrideAdvance = false;
   particles = "fragGrenadeExplosionParticle";
};

datablock ParticleData(fragGrenadeExplosionParticle2)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 4000;
	lifetimeVarianceMS	= 3990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.2 0.2 0.2 0.0";
	colors[1]	= "0.25 0.25 0.25 0.2";
   colors[2]	= "0.4 0.4 0.4 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 10.0;
   sizes[2]	= 3.0;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(fragGrenadeExplosionEmitter2)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 0;
   lifetimeMS       = 120;
   ejectionVelocity = 15;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 85;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "fragGrenadeExplosionParticle2";
};



datablock ParticleData(fragGrenadeExplosionParticle3)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.2;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 4000;
	lifetimeVarianceMS	= 3990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.2 0.2 0.2 0.0";
	colors[1]	= "0.25 0.25 0.25 0.2";
   colors[2]	= "0.4 0.4 0.4 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 10.0;
   sizes[2]	= 13.0;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(fragGrenadeExplosionEmitter3)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   lifetimeMS       = 150;
   ejectionVelocity = 20;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 85;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "fragGrenadeExplosionParticle3";
};

datablock ParticleData(fragGrenadeExplosionParticle4)
{
	dragCoefficient		= 0.1;
	windCoefficient		= 0.0;
	gravityCoefficient	= 4.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 1000;
	lifetimeVarianceMS	= 500;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/chunk";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.1 0.1 0.1 1.0";
	colors[1]	= "0.2 0.2 0.2 0.0";
	sizes[0]	= 0.5;
	sizes[1]	= 0.13;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(fragGrenadeExplosionEmitter4)
{
   ejectionPeriodMS = 1;
   timeMultiple     = 10;
   periodVarianceMS = 0;
   lifetimeMS       = 15;
   ejectionVelocity = 35;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "fragGrenadeExplosionParticle4";
};

datablock ParticleData(ShrapTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 225;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.9 0.2 0.2 0.4";
	colors[1]     = "0.6 0.4 0.0 0.0";
	sizes[0]      = 0.15;
	sizes[1]      = 0.25;

	useInvAlpha = false;
};
datablock ParticleEmitterData(ShrapTrailEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "ShrapTrailParticle";
};

datablock ExplosionData(ShrapExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 150;

   particleEmitter = gunExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = gunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";

   damageRadius = 0;
   radiusDamage = 100;

   impulseRadius = 0;
   impulseForce = 4000;
};

datablock ExplosionData(fragGrenadeExplosion)
{
   explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
   lifeTimeMS = 150;

   soundProfile = fragGrenadeExplosionSound;
   
   emitter[0] = fragGrenadeExplosionEmitter3;
   emitter[1] = fragGrenadeExplosionEmitter2;
   emitter[2] = fragGrenadeExplosionEmitter4;
   //emitter[1] = "";
   //emitter[2] = "";
   //emitter[0] = "";

   particleEmitter = fragGrenadeExplosionEmitter;
   particleDensity = 10;
//   particleDensity = 0;
   particleRadius = 1.0;

   faceViewer     = true;
   explosionScale = "0.4 0.4 0.4";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 13;
   impulseForce =  1300;

   //radius damage
   damageRadius = 8;
   radiusDamage = 20;

};

//projectile
AddDamageType("fragGrenadeDirect",   '<bitmap:add-ons/Weapon_FragGrenade/ci_fragGrenade> %1',    '%2 <bitmap:add-ons/Weapon_FragGrenade/ci_fragGrenade> %1',1,1);
AddDamageType("fragGrenadeRadius",   '<bitmap:add-ons/Weapon_FragGrenade/ci_fragGrenade> %1',    '%2 <bitmap:add-ons/Weapon_FragGrenade/ci_fragGrenade> %1',1,0);
datablock ProjectileData(fragGrenadeProjectile)
{
   projectileShapeName = "./FragGrenadePROJECTILE.dts";
   directDamage        = 0;
   directDamageType  = $DamageType::fragGrenadeDirect;
   radiusDamageType  = $DamageType::fragGrenadeRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = fragGrenadeExplosion;
   //particleEmitter     = fragGrenadeTrailEmitter;

   brickExplosionRadius = 10;
   brickExplosionImpact = false; //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 30;
   velInheritFactor    = 0;
   explodeOnDeath = true;

   armingDelay         = 4000; //4 second fuse 
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.4;
   bounceFriction      = 0.3;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Frag Grenade";
};

AddDamageType("ShrapDirect",   '<bitmap:add-ons/Weapon_FragGrenade/ci_fragGrenade> %1',    '%2 <bitmap:add-ons/Weapon_FragGrenade/ci_fragGrenade> %1',1,1);
datablock ProjectileData(ShrapProjectile)
{
   projectileShapeName = "./bullet.dts";
   directDamage        = 40;
   directDamageType    = $DamageType::ShrapDirect;
   radiusDamageType    = $DamageType::ShrapDirect;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 5;
   verticalImpulse     = 10;
   explosion           = ShrapExplosion;
   particleEmitter     = ShrapTrailEmitter;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 5000;
   lifetime            = 5000;
   fadeDelay           = 5000;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.6;
   isBallistic         = true;
   gravityMod = 1;
   explodeOnDeath = false;

   hasLight    = true;
   lightRadius = 1.0;
   lightColor  = "0.9 0.3 0.1";
};

datablock ProjectileData(ShrapProjectileCol)
{
   projectileShapeName = "./bullet.dts";
   directDamage        = 20;
   directDamageType    = $DamageType::ShrapDirect;
   radiusDamageType    = $DamageType::ShrapDirect;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 5;
   verticalImpulse     = 10;
   explosion           = ShrapExplosion;
   particleEmitter     = ShrapTrailEmitter;

   muzzleVelocity      = 1;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 1000;
   fadeDelay           = 1000;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.6;
   isBallistic         = true;
   explodeOnDeath      = true;
   gravityMod          = 1; 

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(fragGrenadeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./FragGrenade.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Frag Grenade";
	iconName = "./icon_fragGrenade";
	doColorShift = false;
	colorShiftColor = "0.1 0.196 0.1 1.000";

	 // Dynamic properties defined by the scripts
	image = fragGrenadeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(fragGrenadeImage)
{
   // Basic Item properties
   shapeFile = "./FragGrenade.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = fragGrenadeItem;
   ammo = " ";
   projectile = fragGrenadeProjectile;
   projectileType = Projectile;

   	casing = fragGrenadePinDebris;
	shellExitDir        = "-2.0 1.0 1.5";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = false;
   //colorShiftColor = "0.10 0.196 0.1 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Pindrop";
	stateAllowImageChange[1]	= true;

	stateName[2]			= "Pindrop";
	stateTransitionOnTimeout[2]	= "Pinfallen";
	stateAllowImageChange[2]	= false;
	stateTimeoutValue[2]		= 0.2;
	stateSound[2]				= fragGrenadeFireSound;
	stateSequence[2]                = "Pinpull";
	stateEjectShell[2]       = true;
	stateScript[2] = "onPinDrop";

	stateName[3]			= "Pinfallen";
	stateTransitionOnTriggerDown[3]	= "Charge";
	stateAllowImageChange[3]	= false;
	
	stateName[4]                    = "Charge";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.7;
	stateWaitForTimeout[4]		= false;
	stateTransitionOnTriggerUp[4]	= "AbortCharge";
	stateScript[4]                  = "onCharge";
	stateAllowImageChange[4]        = false;
	
	stateName[5]			= "AbortCharge";
	stateTransitionOnTimeout[5]	= "Pinfallen";
	stateTimeoutValue[5]		= 0.3;
	stateWaitForTimeout[5]		= true;
	stateScript[5]			= "onAbortCharge";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Armed";
	stateTransitionOnTriggerUp[6]	= "Fire";
	stateAllowImageChange[6]	= false;

	stateName[7]			= "Fire";
	stateTransitionOnTimeout[7]	= "Done";
	stateTimeoutValue[7]		= 0.5;
	stateFire[7]			= true;
	stateSequence[7]		= "fire";
	stateScript[7]			= "onFire";
	stateWaitForTimeout[7]		= true;
	stateAllowImageChange[7]	= false;

	stateName[8]					= "Done";
	stateScript[8]					= "onDone";

};

package fragGrenadePackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "fragGrenadeItem" && %col.canPickup)
		{
			for(%i=0;%i<%this.maxTools;%i++)
			{
				%item = %obj.tool[%i];
				if(%item $= 0 || %item $= "")
				{
					%freeSlot = 1;
					break;
				}
			}

			if(%freeSlot)
			{
				%obj.pickup(%col);
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}

	function projectile::onAdd(%obj,%a,%b)
	{
		parent::onAdd(%obj,%a,%b);
		if(%obj.dataBlock $= "fragGrenadeProjectile")
		{
			if(!%obj.isBurned)
			{
		         //%original = %obj.getDatablock().lifetime; Doesn't work for some reason
			 %oldLT = 4000;
		 	 //echo("Original is:" SPC %oldLT);
		 	 %cookTime = %obj.client.player.chargeTime;
		 	 //echo("Cooktime is:" SPC %cookTime);
		 	 %new = %oldLT - %cookTime;
		 	 //echo("Difference is:" SPC %new);
			 %obj.schedule(%new,"explode"); //Makes it so it explodes quicker if you held it longer
			}
		}
	}

};
activatePackage(fragGrenadePackage);

function fragGrenadeImage::onPinDrop(%this, %obj, %slot)
{
   %obj.chargeStart = getSimTime();
   if(!isEventPending(%obj.burnSched))
      %obj.burnSched = schedule(4000,0,"burnedIt",%obj);
}

function fragGrenadeImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
	%obj.lastFragSlot = %obj.currTool;
}

function fragGrenadeImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function fragGrenadeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	serverPlay3D(fragGrenadeBounceSound,%obj.getTransform());
}

function fragGrenadeImage::onFire(%this, %obj, %slot)
{
	cancel(%obj.burnSched);
	%obj.playthread(2, spearThrow);
	%obj.chargeEnd = getSimTime();
	%obj.chargeTime = %obj.chargeEnd - %obj.chargeStart;
	Parent::OnFire(%this, %obj, %slot);

	%currSlot = %obj.lastFragSlot;
	%obj.tool[%currSlot] = 0;
	%obj.weaponCount--;
	messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
	serverCmdUnUseTool(%obj.client);
}

//If they cooked it too long, it explodes in their hands
function burnedIt(%player)
{
      %pos = %player.getPosition();
      %player.tool[%currSlot] = 0;
      %player.weaponCount--;
      %player.unMountImage(%slot);
      serverCmdUnUseTool(%player.client);
      %posx = getWord(%pos,0);
      %posy = getWord(%pos,1);
      %posz = getWord(%pos,2);

      %spawnpoint = %posx SPC %posy SPC %posz + 2;

      %burned = new Projectile()
      {
	 datablock = FragGrenadeProjectile;
	 initialVelocity = 0;
	 initialPosition = %spawnpoint;
	 sourceObject = %player;
	 sourceSlot = %player.lastFragSlot;
	 client = %player.client;
	 isBurned = true;
      };
      missionCleanup.add(%burned);
      %burned.explode();
}

function fragGrenadeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

//-------------
// Shrapnel
//-------------

function fragGrenadeprojectile::onExplode(%this,%obj)
{
   parent::onExplode(%this, %obj);
   //echo("Grenade Explosion");
   %shrapData = ShrapProjectile;
   %position = %obj.getPosition();

   %shards = getRandom(35,45);

   for(%numbar=0; %numbar<%shards; %numbar++)
   {
      %vector = %position;

      %x = (getRandom(-7,7) - 0.5) * 3.141592653;
      %y = (getRandom(-7,7) - 0.5) * 3.141592653;
      %z = (getRandom(-7,7) - 0.5) * 3.141592653;

      //spawn them in random sphere locations.

      if(%z < 0)
      {
	 %z = randNegate(%z); //Randomly Negates Negative Z (Up/Down) Velocities to make it spread more evenly
      }

      %velocity = %x SPC %y SPC %z;

      %shraps = new projectile()
      {
	 dataBlock = %shrapData;
	 initialVelocity = %velocity;
	 initialPosition = %position;
	 sourceObject = %obj;
	 sourceSlot = %obj.client.player.lastFragslot;
	 client = %obj.client;
      };
      MissionCleanup.add(%shraps);
      //echo(%obj.client.getplayername());
      //echo(%obj.client.player.getID());
   }
}

function ShrapProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
	if(%col.getClassName() $= "Player")
		%obj.setDataBlock(ShrapProjectileCol);
	else
	{
		%obj.numBounces++;
		serverPlay3D(hammerHitSound,%obj.getTransform());
		if(vectorDist(%obj.lastBounce,getSimTime()) < 200)
		{
			%obj.schedule(10,"delete");
			return;
		}
		%obj.lastBounce = getSimTime();
	}
	Parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}

function ShrapProjectile::Damage(%this,%obj,%col,%fade,%pos,%norm)
{
	%bounces = %obj.numBounces;
	%velocity = %obj.getVelocity();
	//echo(%velocity);
	%damage = %this.directDamage-(%bounces*3)+mFloor((%velocity/2));	
	//echo(%damage);
	%col.damage(%obj,%pos,%damage,%this.directDamageType);
}

function ShrapProjectileCol::Damage(%this,%obj,%col,%fade,%pos,%norm)
{
	%bounces = %obj.numBounces;
	%velocity = %obj.getVelocity();
	//echo(%velocity);
	%damage = %this.directDamage-(%bounces*3)+mFloor((%velocity/2));
	//echo(%damage);	
	%col.damage(%obj,%pos,%damage,%this.directDamageType);
}

function randNegate(%x)
{
   %rand = getRandom(1,100);
   if(%rand >= 50)
      return %x;

   if(%rand < 50)
   {
      %x = %x * (-1);
      return %x;
   }
}