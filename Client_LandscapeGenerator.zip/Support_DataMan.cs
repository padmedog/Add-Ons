function DATA_Readfile(%f,%output,%doreport)
{
	if(!isFile(%f)) {echo("DataMan- File not found.");return;}
	%FO=new FileObject();
	%FO.openForRead(%f);
	%numCat=%numVal=%numMap=0;
	while(!%FO.isEOF())
	{
		%line=%fo.readline();
		if(getSubStr(%line,0,2)$="//") {continue;}
		if(getSubStr(%line,0,1)$="[")
		{
			%cat=getSubStr(%line,1,strLen(%line)-2);
			call(%output@"_addCAT",%cat);
			%numCat++;
		}
		else if((%pos=strPos(%line,"="))!=-1)
		{
			%var=getSubStr(%line,0,%pos);
			%val=getSubStr(%line,%pos+1,strLen(%line));
			call(%output@"_addVAL",%var,%val);
			%numVal++;
		}
		else if((%pos=strPos(%line,":"))!=-1)
		{
			%var=getSubStr(%line,0,%pos);
			%str="";
			for(%i=0;(%l=%FO.readline())||1!$="End";%i++)
			{
				if(%FO.isEOF()) {break;}
				if(%l$="End") {break;}
				if(%str$="")
				{
					%str=%l;
				}
				else
				{
					%str=%str NL %l;
				}
			}
			call(%output@"_addMAP",%var,%str);
			%numMap++;
		}
	}
	%FO.close();
	%FO.delete();
	if(%doReport)
	{
		call(%output@"_Report",%numCat,%numVal,%numMap);
	}
}