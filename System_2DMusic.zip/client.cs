function clientCmd2dMusicCheck()
{
	commandToServer('2dMusicCheck');
}

if(isFile("Add-ons/Client_AdvancedMusic.zip"))
{
	exec("./client_AdMusic.cs");
	return;
}

new AudioDescription(ClientMusic2D)
{
	is3D = 0;
	isLooping = 1;
	loopcount = -1;
	type = 8;
	volume = 1;
};

function clientCmdPlayMusic(%filename)
{
	clientCmdStopMusic();
	if(isFile("Add-ons/Music/" @ %filename @ ".ogg"))
	{
		$Client::PlayingMusic = alxCreateSource(ClientMusic2D, "Add-ons/Music/" @ %filename @ ".ogg");
		alxPlay($Client::PlayingMusic);
	}
}

function clientCmdStopMusic()
{
	if(alxIsPlaying($Client::PlayingMusic))
		alxStop($Client::PlayingMusic);
	$Client::PlayingMusic = "";
}