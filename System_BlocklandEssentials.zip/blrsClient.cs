//blrs

function openBLRS()
{
	canvas.pushDialog(blrsServerControl);
}

$remapDivision[$remapCount] = "BLRS";
$remapName[$remapCount] = "Open";
$remapCmd[$remapCount] = "openBLRS";
$remapCount++;

$blrs::clientVersion = 1;

if(!$blrsversionGetter)
	exec("./versionGetter.cs");

//end blrs
