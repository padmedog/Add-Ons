datablock fxDTSBrickData(brick1x12archData)
{
	brickFile = "./1x12arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x12 Arch";
	collisionShapeName = "./1x12Arch.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x12arch";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x5halfarchData)
{
	brickFile = "./1x5halfarch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x5 Half-Arch";
	collisionShapeName = "./1x5halfArch.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x5halfarch";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x5halfarchInvData)
{
	brickFile = "./1x5halfarchInv.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x5 Half-Arch Inverted";
	collisionShapeName = "./1x5halfArchInv.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x5halfarchinverted";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x2halfarchcurvedData)
{
	brickFile = "./1x2halfarchCurved.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x2 Half-Arch Curved";
	collisionShapeName = "./1x2halfarchcurved.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x2halfarchcurved";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x3halfarchcurvedData)
{
	brickFile = "./1x3halfarchCurved.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x3 Half-Arch Curved";
	collisionShapeName = "./1x3halfarchcurved.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x3halfarchcurved";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x6halfarchcurvedData)
{
	brickFile = "./1x6halfarchCurved.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x6 Half-Arch Curved";
	collisionShapeName = "./1x6halfarchcurved.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x6halfarchcurved";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x3ArabianData)
{
	brickFile = "./1x3Arabian.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x3 Arabian Arch";
	collisionShapeName = "./1x3Arabian.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x3Arabian";
        orientationFix = 1;
};

datablock fxDTSBrickData(brick1x8x2ArchData)
{
	brickFile = "./1x8x2Arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x8x2 Arch";
	collisionShapeName = "./1x8x2Arch.dts";
	iconName = "Add-Ons/Brick_ExtraArches/1x8x2Arch";
};