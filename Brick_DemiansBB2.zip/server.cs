datablock fxDTSBrickData (brick2x5fData)
{
	brickFile = "./2x5f.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x5F";
	iconName = "Add-Ons/Brick_DemiansBB2/2x5f";
};

datablock fxDTSBrickData (brick2x12fData)
{
	brickFile = "./2x12f.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x12F";
	iconName = "Add-Ons/Brick_DemiansBB2/2x12f";
};

datablock fxDTSBrickData (brick2x14fData)
{
	brickFile = "./2x14f.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x14F";
	iconName = "Add-Ons/Brick_DemiansBB2/2x14f";
};

datablock fxDTSBrickData (brick2x16fData)
{
	brickFile = "./2x16f.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x16F";
	iconName = "Add-Ons/Brick_DemiansBB2/2x16f";
};

datablock fxDTSBrickData (brick2x32fData)
{
	brickFile = "./2x32f.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x32F";
	iconName = "Add-Ons/Brick_DemiansBB2/2x32f";
};

datablock fxDTSBrickData (brick2x5x1Data)
{
	brickFile = "./2x5x1.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x5x1";
	iconName = "Add-Ons/Brick_DemiansBB2/2x5x1";
};

datablock fxDTSBrickData (brick2x12x1Data)
{
	brickFile = "./2x12x1.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x12x1";
	iconName = "Add-Ons/Brick_DemiansBB2/2x12x1";
};

datablock fxDTSBrickData (brick2x14x1Data)
{
	brickFile = "./2x14x1.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x14x1";
	iconName = "Add-Ons/Brick_DemiansBB2/2x14x1";
};

datablock fxDTSBrickData (brick2x16x1Data)
{
	brickFile = "./2x16x1.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x16x1";
	iconName = "Add-Ons/Brick_DemiansBB2/2x16x1";
};

datablock fxDTSBrickData (brick2x32x1Data)
{
	brickFile = "./2x32x1.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x32x1";
	iconName = "Add-Ons/Brick_DemiansBB2/2x32x1";
};

datablock fxDTSBrickData (brick1x1x2Data)
{
	brickFile = "./1x1x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x1x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x1x2";
};

datablock fxDTSBrickData (brick1x2x2Data)
{
	brickFile = "./1x2x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x2x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x2x2";
};

datablock fxDTSBrickData (brick1x3x2Data)
{
	brickFile = "./1x3x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x3x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x3x2";
};

datablock fxDTSBrickData (brick1x4x2Data)
{
	brickFile = "./1x4x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x4x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x4x2";
};

datablock fxDTSBrickData (brick1x5x2Data)
{
	brickFile = "./1x5x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x5x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x5x2";
};

datablock fxDTSBrickData (brick1x6x2Data)
{
	brickFile = "./1x6x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x6x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x6x2";
};

datablock fxDTSBrickData (brick1x8x2Data)
{
	brickFile = "./1x8x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x8x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x8x2";
};

datablock fxDTSBrickData (brick1x10x2Data)
{
	brickFile = "./1x10x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x10x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x10x2";
};

datablock fxDTSBrickData (brick1x12x2Data)
{
	brickFile = "./1x12x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x12x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x12x2";
};

datablock fxDTSBrickData (brick1x14x2Data)
{
	brickFile = "./1x14x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x14x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x14x2";
};

datablock fxDTSBrickData (brick1x16x2Data)
{
	brickFile = "./1x16x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x16x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x16x2";
};

datablock fxDTSBrickData (brick1x32x2Data)
{
	brickFile = "./1x32x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x32x2";
	iconName = "Add-Ons/Brick_DemiansBB2/1x32x2";
};

datablock fxDTSBrickData (brick2x2x2Data)
{
	brickFile = "./2x2x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x2x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x2x2";
};

datablock fxDTSBrickData (brick2x3x2Data)
{
	brickFile = "./2x3x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x3x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x3x2";
};

datablock fxDTSBrickData (brick2x4x2Data)
{
	brickFile = "./2x4x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x4x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x4x2";
};

datablock fxDTSBrickData (brick2x5x2Data)
{
	brickFile = "./2x5x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x5x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x5x2";
};

datablock fxDTSBrickData (brick2x6x2Data)
{
	brickFile = "./2x6x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x6x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x6x2";
};

datablock fxDTSBrickData (brick2x8x2Data)
{
	brickFile = "./2x8x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x8x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x8x2";
};

datablock fxDTSBrickData (brick2x10x2Data)
{
	brickFile = "./2x10x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x10x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x10x2";
};

datablock fxDTSBrickData (brick2x12x2Data)
{
	brickFile = "./2x12x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x12x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x12x2";
};

datablock fxDTSBrickData (brick2x14x2Data)
{
	brickFile = "./2x14x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x14x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x14x2";
};

datablock fxDTSBrickData (brick2x16x2Data)
{
	brickFile = "./2x16x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x16x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x16x2";
};

datablock fxDTSBrickData (brick2x32x2Data)
{
	brickFile = "./2x32x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x32x2";
	iconName = "Add-Ons/Brick_DemiansBB2/2x32x2";
};

datablock fxDTSBrickData (brick2x5x5Data)
{
	brickFile = "./2x5x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x5x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x5x5";
};

datablock fxDTSBrickData (brick2x7x5Data)
{
	brickFile = "./2x7x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x7x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x7x5";
};

datablock fxDTSBrickData (brick2x8x5Data)
{
	brickFile = "./2x8x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x8x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x8x5";
};

datablock fxDTSBrickData (brick2x9x5Data)
{
	brickFile = "./2x9x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x9x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x9x5";
};

datablock fxDTSBrickData (brick2x10x5Data)
{
	brickFile = "./2x10x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x10x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x10x5";
};

datablock fxDTSBrickData (brick2x11x5Data)
{
	brickFile = "./2x11x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x11x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x11x5";
};

datablock fxDTSBrickData (brick2x13x5Data)
{
	brickFile = "./2x13x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x13x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x13x5";
};

datablock fxDTSBrickData (brick2x14x5Data)
{
	brickFile = "./2x14x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x14x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x14x5";
};

datablock fxDTSBrickData (brick2x15x5Data)
{
	brickFile = "./2x15x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x15x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x15x5";
};

datablock fxDTSBrickData (brick2x16x5Data)
{
	brickFile = "./2x16x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x16x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x16x5";
};

datablock fxDTSBrickData (brick2x32x5Data)
{
	brickFile = "./2x32x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x32x5";
	iconName = "Add-Ons/Brick_DemiansBB2/2x32x5";
};