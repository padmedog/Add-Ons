// Renderman AI //

// OUTLINE
// >Rendermen start by finding a "target". #
// >They stalk the targeted player. #
// >Sometimes their target will change #
// >Up to five rendermen can be on the map at the time #
// >Rendermen sometimes try to teleport closer to the target, but can't teleport in front of them.
// >Upon getting very close to the target (Right behind them) they will make a sound. #
// >Looking at a renderman that is very close kills the player #
// >Looking at one that is far away will kill over time #
// >If a renderman loses it's target it ceases to exist. #
// >Suddenly catching sight of a close up renderman will play a jumpscare sound. #
// >Rendermen can't move when they're being observed by players. #
// >Rendermen not visible to the player indoors will play ambient sounds.

function AIPlayer::ShrineCheck(%this)
{
	InitContainerRadiusSearch(%this.getPosition(),20,$TypeMasks::FxBrickObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.getDatablock().getName() $= "brickRenderSafe") {
            return 1;
        }
    }
    return 0;
}

function AIPlayer::getPosInFrontOfRenderman(%this,%dist)
{
    return vectorAdd(%this.getEyePoint(),vectorScale(%this.getEyeVector(),%dist));
}

function Player::getPosInFrontOfPlayer(%this,%dist)
{
    return vectorAdd(%this.getEyePoint(),vectorScale(%this.getEyeVector(),%dist));
}

function AIPlayer::getRendermanTarget(%this) { // this is how rendermen find a "target".
    %pos = %this.getPosition();
    
    InitContainerRadiusSearch(%pos,1200,$TypeMasks::PlayerObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(isObject(%targetObject.client)) { // That IS a player, right? This isn't the time for chasing your friends about.
            return %targetObject; // Set the found player as the target
        }
    }
    return 0;
}   

function AIPlayer::rendermanLoop(%this) {
    // Should we still be around?
    if(%this.RendermanLifetime <= 0) {
        %this.selfdestruct = 1; // we're not going to be around for much longer but we can't just vanish in front of someone
    } else {
        %this.RendermanLifetime = %this.RendermanLifetime-1;
    }
    // Do we have a target? If not get one
    if(%this.RendermanTarget == 0) {
        %this.RendermanTarget = %this.getRendermanTarget();
        
        //find anything?
        if(%this.RendermanTarget == 0) {
            removeRenderman(%this); // can't find a target so despawns
            return "NOTARG";
        }
    }
    // now that we have a target...
    // is he alive/still about?
    if(!isObject(%this.RendermanTarget) || %this.RendermanTarget.safe == 1) {
        serverPlay3D(BotVanish,%this.getPosition());
        removeRenderman(%this); // target is lost so renderman despawns
        return "TLOST";
    }
    
    if(%this.shrineCheck()) { // rendermen cannot go within 20 TUs of a shrine without dying
        serverPlay3D(BotVanish,%this.getPosition());
        removeRenderman(%this);
        return "SHRINE";
    }
        
    %this.setAimObject(%this.RendermanTarget); // face him
    // can anyone see us?
    %pos = %this.getPosition();
    InitContainerRadiusSearch(%pos,9999,$TypeMasks::PlayerObjectType);
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(isObject(%targetObject.client)) {
            if(getWord(%targetObject.canSeeRender,0) $= %this || getWord(%targetObject.canSeeRender,1) $= %this || getWord(%targetObject.canSeeRender,2) $= %this || getWord(%targetObject.canSeeRender,3) $= %this || getWord(%targetObject.canSeeRender,4) $= %this || getWord(%targetObject.canSeeRender,5) $= %this) { // this line is rather long, isn't it?
                // this means they can
                %this.schedule(100,rendermanLoop); // so we wait,
                %this.setAimObject(%targetObject); // and face him
                if(getrandom(1,30) == 3) { //possibly change him to your target for this (If he already is this won't matter)
                    %this.RendermanTarget = %targetObject;
                } // woo unnecisary brackets
                return "INVIEW";
            }
        }
    }
    // nobody sees us.
    // SELF DESTRUCT (If appropriate)
    if(%this.selfdestruct == 1) {
        serverPlay3D(BotVanish,%this.getPosition());
        removeRenderman(%this);
        return "SELFDESTRUCT";
    }
    // time to chase the target.
    
    // are we close enough?
    if(VectorDist(%this.getPosition(),%this.RendermanTarget.getPosition()) <= 7) {
        %this.schedule(200,rendermanLoop);
        if(%this.growled == 0 && %this.RendermanTarget.frozen == 0) {
            serverPlay3D(RenGrowl,%this.getPosition());
            %this.RendermanTarget.prevDatablock = %this.RendermanTarget.getDatablock();
            %this.RendermanTarget.setDatablock(PlayerRenderFrozenArmor); // freeze the target
            %this.RendermanTarget.frozen = 1; // tell their loopcode they froze
            schedule(13000,0,removeRenderman,%this); // start another delete timer - the player can escape by not looking
            // show me your war face.
            if($Pref::Rendermen::Faces == 1) {
                %this.setfacename("rendermanAngry");
            } else {
                %this.setfacename("asciiTerror");
            }
            %this.RendermanTarget.detector = 5; // make their detector go haywire - that'll scare em'
            //echo("Behind you.");
        }
        %this.growled = 1;
        return "CLSENOUGH";
    }
    
    %mf = %this.getPosInFrontOfRenderman(1); // the bot support in BL is terrible, so we'll slowly tp the bot towards the player instead
    %mf = vectorSub(%mf,"0 0 2.880"); // compensate for render trying to be dolan
    
    if(%this.justteleported == 1) { // did we do teleporty?
        if(getWord(%this.RendermanTarget.canSeeRender,0) $= %this || getWord(%this.RendermanTarget.canSeeRender,1) $= %this || getWord(%this.RendermanTarget.canSeeRender,2) $= %this || getWord(%this.RendermanTarget.canSeeRender,3) $= %this || getWord(%this.RendermanTarget.canSeeRender,4) $= %this || getWord(%this.RendermanTarget.canSeeRender,5) $= %this) { // this line is rather long, isn't it?
            // if we teleported somewhere that can be seen by the target,
            %this.RendermanTeleport(); // try again - we'll have a specific function for jumpscaring later on
        }
    }
    
    %this.justteleported = 0;
    %this.setTransform(%mf);
    
    if(getRandom(1,56) == 5) { // do teleporty?
        %this.RendermanTeleport();
        %this.justteleported = 1;
    }
    
    if(getRandom(1,126) == 5) { // teleport right behind the player?
        %this.RendermanSneak();
        %this.justteleported = 1;
    }
    // finally, rerun the AI code
    if(%this.type $= "T") {
       %this.schedule($Pref::Rendermen::Speed / 2,rendermanLoop);  // Type T moves twice as fast
    } else {
        %this.schedule($Pref::Rendermen::Speed,rendermanLoop); // normal renderman
    }
    return "SUCCESS";
}

function AIPlayer::RendermanTeleport(%this) { // teleport a renderman randomly
    %pPos = %this.RendermanTarget.getPosition();
    %tPos = vectorAdd(%pPos, getRandom(-80,80) SPC getRandom(-80,80) SPC 0 );
    %this.setTransform(%tPos);
    serverPlay3D(BotVanish,%tPos);
}

function AIPlayer::RendermanSneak(%this) { // another teleport, but appears right behind the player
    %pPos = %this.RendermanTarget.getPosition();
    %tPos = %this.getPosInFrontOfPlayer(-3); // using a minus number like this gives me a space directly BEHIND the player
    %this.setTransform(%tPos);
    // no sound
}

function FxDTSBrick::RenderHordeRestoreLight(%this) { // bricks with lights will break when the Horde event happens.
    %this.setLight(%this.PrevLight);
}

// brick light check
function FxDTSBrick::RenderCheck(%this)
{
	InitContainerRadiusSearch(%this.getPosition(),70,$TypeMasks::PlayerObjectType);
    %seen = 0;
    while((%targetObject=containerSearchNext()) !$= 0) {
        if(%targetObject.isRenderman == 1) {
            if(%seen == 0) {
                %seen = %targetObject;
            }
        }
    }
    return %seen;
}

// special returns are for debugging with the trace function - type trace(1); in console to see all renderman AI output