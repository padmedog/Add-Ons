datablock AudioDescription(TrainLooping3d)
{
   volume   = 100;
   isLooping= true;

   is3D     = true;
   ReferenceDistance= 10.0;
   MaxDistance= 500.0;
   type     = $SimAudioType;
};

datablock AudioDescription(Train3d)
{
   volume   = 100;
   isLooping= false;

   is3D     = true;
   ReferenceDistance= 10.0;
   MaxDistance= 500.0;
   type     = $SimAudioType;
};

datablock AudioProfile(bell)
{
   filename    = "./sound/bell.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(hornBegin)
{
   filename    = "./sound/K3LA_horn_begin.wav";
   description = Train3d;
   preload = true;
};

datablock AudioProfile(hornMiddle)
{
   filename    = "./sound/K3LA_horn_mid.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(hornEnd)
{
   filename    = "./sound/K3LA_horn_end.wav";
   description = Train3d;
   preload = true;
};


datablock AudioProfile(idleSound)
{
   filename    = "./sound/idle.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(throttle1Sound)
{
   filename    = "./sound/cruise1.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(throttle2Sound)
{
   filename    = "./sound/cruise2.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(throttle3Sound)
{
   filename    = "./sound/cruise3.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(throttle4Sound)
{
   filename    = "./sound/cruise4.wav";
   description = TrainLooping3d;
   preload = true;
};


datablock AudioProfile(throttle5Sound)
{
   filename    = "./sound/cruise5.wav";
   description = TrainLooping3d;
   preload = true;
};