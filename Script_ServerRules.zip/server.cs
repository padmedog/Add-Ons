package ServerRulesPackage
{
	function GameConnection::onClientEnterGame(%c)
	{       
		Parent::onClientEnterGame(%c);
		schedule(2000, 0, showRules, %c); //so they don't go away immediately
	}
};
activatePackage(ServerRulesPackage);

function serverCmdSetRules(%c, %a0, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13, %a14, %a15, %a16, %a17, %a18, %a19, %a20, %a21, %a22, %a23, %a24, %a25, %a26, %a27, %a28, %a29, %a30, %a31, %a32, %a33, %a34, %a35, %a36, %a37, %a38, %a39, %a40, %a41, %a42, %a43, %a44, %a45, %a46, %a47, %a48, %a49, %a50, %a51, %a52, %a53, %a54, %a55, %a56, %a57, %a58, %a59, %a60, %a71, %a72, %a73, %a74, %a75, %a76, %a77, %a78, %a79, %a80, %a81)
{
	if(%c.isSuperAdmin)
	{
		%serverRules = %a1 SPC %a2 SPC %a3 SPC %a4 SPC %a5 SPC %a6 SPC %a7 SPC %a8 SPC %a9 SPC %a10 SPC %a11 SPC %a12 SPC %a13 SPC %a14 SPC %a15 SPC %a16 SPC %a17 SPC %a18 SPC %a19 SPC %a20 SPC %a21 SPC %a22 SPC %a23 SPC %a24 SPC %a25 SPC %a26 SPC %a27 SPC %a28 SPC %a29 SPC %a30 SPC %a31 SPC %a32 SPC %a33 SPC %a34 SPC %a35 SPC %a36 SPC %a37 SPC %a38 SPC %a39 SPC %a40 SPC %a41 SPC %a42 SPC %a43 SPC %a44 SPC %a45 SPC %a46 SPC %a47 SPC %a48 SPC %a49 SPC %a50 SPC %a51 SPC %a52 SPC %a53 SPC %a54 SPC %a55 SPC %a56 SPC %a57 SPC %a58 SPC %a59 SPC %a60 SPC %a71 SPC %a72 SPC %a73 SPC %a74 SPC %a75 SPC %a76 SPC %a77 SPC %a78 SPC %a79 SPC %a80 SPC %a81;
		
		messageAll('MsgAdminForce', "\c3" @ %c.name SPC "\c2changed the server rules");
		echo(%c.name SPC "changed the server rules");

		$Pref::Server::RulesTitle = %a0;
		$Pref::Server::RulesLine1 = %serverRules;
	}
}

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
   if(!$RTB::RTBR_ServerControl_Hook)
      exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	  
   RTB_registerPref("Title", "Server Rules", "$Pref::Server::RulesTitle", "string 20", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 1", "Server Rules", "$Pref::Server::RulesLine1", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 2", "Server Rules", "$Pref::Server::RulesLine2", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 3", "Server Rules", "$Pref::Server::RulesLine3", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 4", "Server Rules", "$Pref::Server::RulesLine4", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 5", "Server Rules", "$Pref::Server::RulesLine5", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 6", "Server Rules", "$Pref::Server::RulesLine6", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 7", "Server Rules", "$Pref::Server::RulesLine7", "string 200", "Script_ServerRules", "", 0, 0);
   RTB_registerPref("Line 8", "Server Rules", "$Pref::Server::RulesLine8", "string 200", "Script_ServerRules", "", 0, 0);
}
	
function serverCmdRules(%c)
{
	showRules(%c);
}

function showRules(%c)
{
	if(!isObject(%c))
		return;

	if($Pref::Server::RulesTitle !$= "") // We don't want to be displaying empty lines
		messageClient(%c, '', "\c2" @ $Pref::Server::RulesTitle @ "\c6:");

	if($Pref::Server::RulesLine1 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine1);
		%rules = $Pref::Server::RulesLine1;
	}

	if($Pref::Server::RulesLine2 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine2);
		%rules = %rules NL $Pref::Server::RulesLine2;
	}

	if($Pref::Server::RulesLine3 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine3);
		%rules = %rules NL $Pref::Server::RulesLine3;
	}

	if($Pref::Server::RulesLine4 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine4);
		%rules = %rules NL $Pref::Server::RulesLine4;
	}

	if($Pref::Server::RulesLine5 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine5);
		%rules = %rules NL $Pref::Server::RulesLine5;
	}

	if($Pref::Server::RulesLine6 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine6);
		%rules = %rules NL $Pref::Server::RulesLine6;
	}

	if($Pref::Server::RulesLine7 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine7);
		%rules = %rules NL $Pref::Server::RulesLine7;
	}

	if($Pref::Server::RulesLine8 !$= "")
	{
		messageClient(%c, '', "\c3" @ $Pref::Server::RulesLine8);
		%rules = %rules NL $Pref::Server::RulesLine8;
	}

	messageClient(%c, '', "\c6Press \c3PageUp \c6if you cannot see all the rules");
	messageClient(%c, '', "\c6Type \c3/rules \c6to display them again");
	commandToClient(%c, 'messageBoxOK', $Pref::Server::RulesTitle,  %rules NL "\c6Type /rules to display them again");
}