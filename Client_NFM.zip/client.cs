//NARG File Manager
//Version 1.3 Beta
//  By Nexus 4833
//=================

//just execute necessary files
exec("./modules/getName/getname.cs");
exec("./modules/zoomImage/zoomimage.cs");

//this module is dependent on the other two
exec("./modules/getFile/getfile.cs");

//in my head it was a cool idea to abstract the specific brick save/load system away from the "prompt file" module
//turns out this adds a lot of unnecessary stuff, oh well.

//package
//----------
package NARGFileManager
{
	function escapeMenu::clickLoadBricks(%this)
	{
		//opens File Manager with 'load' parameter instead
		$nfm_overridedefault = "";
		promptUserFile("", "nfm_uploadsavefile", "loadbls");
	}

	function escapeMenu::clickSaveBricks(%this)
	{
		$nfm_overridedefault = "";
		promptUserFile("", "nfm_savebricks", "savebls");
	}

//	function messageboxyesno(%text, %yes, %no)
//	{
//		if($nfm_overrideprompts)
//		{
//			eval(%yes);
//			nfm_debug("Prompt overwritten.");
//			return;
//		}
//		else
//			return parent::messageboxyesno(%text, %yes, %no);
//	}

	//this is a crappy workaround since baldspot doesn't have a decent api
	function savebricks(%path, %desc)
	{
		parent::savebricks(%path, %desc);

		if($nfm_overridedefault !$= "")
		{
			filecopy(%path, $nfm_overridedefault);
			filedelete(%path);
			filecopy(nfm_trimFileName(%path) @ filebase(%path) @ ".jpg", nfm_trimFileName($nfm_overridedefault) @ filebase($nfm_overridedefault) @ ".jpg");
			filedelete(nfm_trimFileName(%path) @ filebase(%path) @ ".jpg");

			//this isn't just an error check.
			//this forces blockland's file directory to discover these two files and actually add them.
			//for some reason, filecopy() does not do that automatically.

			if(!isfile($nfm_overridedefault) || !isfile(nfm_trimFileName($nfm_overridedefault) @ filebase($nfm_overridedefault) @ ".jpg"))
			{
				//blockland's file system is a buggy piece of shit
				nfm_debug("Save failure:" SPC $nfm_overridedefault);
			}
			savebricksgui.getobject(0).setvisible(1);
			SaveBricks_Window.add(SaveBricks_DownloadWindow);
			$nfm_overridedefault = "";
		}
	}

	//TO DO: redirect auto open gui on becoming admin?
};
activatePackage(NARGFileManager);

function nfm_uploadsavefile(%path)
{
	canvas.popdialog(EscapeMenu);

	if(!isfile(%path) || fileext(%path !$= ".bls"))
	{
		nfm_debug("Warning: File is not a valid blockland save file: " @ %path);
	}
	$LoadingBricks_FileName = %path;

	if($LoadingBricks_ColorMethod $= "")
	{
		$LoadingBricks_ColorMethod = 3;
	}

	if(serverconnection.islocal())
	{
		serverDirectSaveFileLoad($LoadingBricks_FileName, $LoadingBricks_ColorMethod, $LoadingBricks_Silent, $LoadingBricks_Ownership);
	}
	else
	{
		//This is supposed to be used only for dedicated servers, but it seems to work for non dedicated as well.
		//The only side effect that I have found is a line saying that the host cancelled the upload in chat.
		commandtoserver('InitUploadHandshake');

		//I believe all this stuff here is handled automatically, but here it is anyway for future reference.
//		commandtoserver('SetColorMethod', $LoadingBricks_ColorMethod);
//
//		//I actually have no idea what DirName is, but this is how you upload ownership
//		commandtoserver('SetSaveUploadDirName', $LoadingBricks_DirName, $LoadingBricks_Ownership);
	}
}

function nfm_savebricks(%path, %desc)
{
//	canvas.popdialog(EscapeMenu);

	if(!isWriteableFileName(%path))
	{
		messageboxok("Error", "Cannot write to file: " @ %path);
		return;
	}
//	canvas.pushdialog(SavingGui);

	if(serverconnection.islocal())
	{
		schedule(0, 0, "saveBricks", %path, %desc);
	}
	else
	{
		//this is part of a crappy workaround that I can't get around without rewriting the entire saving system
		savebricksgui.getobject(0).setvisible(0);
		saveBricksGui.add(SaveBricks_DownloadWindow);

		//apparently the process for downloading event info is more complicated than I thought, and the easiest way to do it is to just shove data into the default gui and pretend to click the button
		canvas.pushdialog(savebricksgui);

		while(isfile("saves/" @ (%garbage = getrandom()) @ ".bls")){}

		savebricks_filename.setvalue(%garbage);
		savebricks_description.setvalue(%desc);
		savebricks_ownership.setvalue($pref::SaveOwnership);
		savebricks_extendedinfo.setvalue($pref::SaveExtendedBrickInfo);

		$nfm_overridedefault = %path;
		savebricks_save();
	}
}

