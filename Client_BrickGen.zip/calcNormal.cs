//Coded by General (ID: 4878)
//You are free to use this for anything you want, although a litte credit would be appreciated ;p



//Creates a list of multiple vertices to later calculate a mean vector
if(isObject(NCSO))
	NCSO.delete();
new scriptObject(NCSO){};
function NC_addVertices(%ver1,%ver2,%ver3)
{
	NCSO.count++;
	NCSO.ver[NCSO.count,3]=%ver1;
	NCSO.ver[NCSO.count,2]=%ver2;
	NCSO.ver[NCSO.count,1]=%ver3;
}

function NC_calc(%ver1,%ver2,%ver3)
{
	//Use vertices stated in args rather than on list
	if(%ver1 !$= "")
	{
		NCSO.count=1;
		NCSO.ver[1,3]=%ver1;
		NCSO.ver[1,2]=%ver2;
		NCSO.ver[1,1]=%ver3;
	}
	
	//Create vectors
	for(%i=1;%i<=NCSO.count;%i++)
	{
		%xx = %xx + getWord(NCSO.ver[%i,2],0) - getWord(NCSO.ver[%i,1],0);
		%yy = %yy + getWord(NCSO.ver[%i,2],1) - getWord(NCSO.ver[%i,1],1);
		%zz = %zz + getWord(NCSO.ver[%i,2],2)*0.4 - getWord(NCSO.ver[%i,1],2)*0.4;
		
		%xx2 = %xx2 + getWord(NCSO.ver[%i,3],0) - getWord(NCSO.ver[%i,1],0);
		%yy2 = %yy2 + getWord(NCSO.ver[%i,3],1) - getWord(NCSO.ver[%i,1],1);
		%zz2 = %zz2 + getWord(NCSO.ver[%i,3],2)*0.4 - getWord(NCSO.ver[%i,1],2)*0.4;
	}
	
	//Calculate mean
	%xx = %xx/%i;
	%yy = %yy/%i;
	%zz = %zz/%i;
	
	%xx2 = %xx2/%i;
	%yy2 = %yy2/%i;
	%zz2 = %zz2/%i;
	
	//Get cross product
	%cpx = (%yy*%zz2)-(%zz*%yy2);
	%cpy = -((%zz2*%xx)-(%xx2*%zz));
	%cpz = (%xx*%yy2)-(%yy*%xx2);
	
	//Normalization
	%nf = mSqrt(mPow(%cpx,2) + mPow(%cpy,2) + mPow(%cpz,2));
	
	%nx = %cpx/%nf;
	%ny = %cpy/%nf;
	%nz = %cpz/%nf;
	
	//Return results and reset vertex list count
	NCSO.count=0;
	return mFloatLength(%nx,6) SPC mFloatLength(%ny,6) SPC mFloatLength(%nz,6);
}