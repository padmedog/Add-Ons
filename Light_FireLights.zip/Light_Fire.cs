// Fire Lights

datablock fxLightData(RedFireLight)
{
	uiName = "Red Fire Light";

	LightOn = true;
	radius = 15;
	brightness = 20;
	color = "1 0 0 1";

	flareOn = true;
	NearSize	= 2;
	FarSize = 1;
};
datablock fxLightData(OrangeFireLight : RedFireLight)
{
	uiName = "Orange Fire Light";
	color = "1 0.5 0 1";
};
datablock fxLightData(YellowFireLight : RedFireLight)
{
	uiName = "Yellow Fire Light";
	color = "1 1 0 1";
};
datablock fxLightData(GreenFireLight : RedFireLight)
{
	uiName = "Green Fire Light";
	color = "0 1 0 1";
};
datablock fxLightData(CyanFireLight : RedFireLight)
{
	uiName = "Cyan Fire Light";
	color = "0 1 1 1";
};
datablock fxLightData(BlueFireLight : RedFireLight)
{	
	uiName = "Blue Fire Light";
	color = "0 0 1 1";
};
datablock fxLightData(PurpleFireLight : RedFireLight)
{	
	uiName = "Purple Fire Light";
	color = "0.5 0 1 1";
};
datablock fxLightData(WhiteFireLight : RedFireLight)
{
	uiName = "White Fire Light";
	color = "0.5 0.5 0.5 0.5";
};

