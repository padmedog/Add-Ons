datablock itemData( LaptopItem )
{
	category = "Weapon";
	uiName = "Laptop";

	shapeFile = "./Laptop.dts";
	doColorShift = false;

	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	image = LaptopImage;
	canDrop = true;
};

datablock shapeBaseImageData( LaptopImage )
{
	shapeFile = "./Laptop.dts";
	doColorShift = false;
	emap = true;

	rotation = eulerToMatrix( "0 0 90" );

	className = "WeaponImage";

	item = LaptopItem;
	armReady = true;
};