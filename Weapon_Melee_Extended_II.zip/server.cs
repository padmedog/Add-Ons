%error = ForceRequiredAddOn("Weapon_Melee_Extended");
if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_L4BBasicMelee - required add-on Emote_Critical not found");
}
else
{
   exec("./Support_RaycastingWeapons.cs");
   exec("./Support_tf2basicmelee.cs");

   exec("./Weapon_Sledgehammer.cs");
   exec("./Weapon_L4BGuitar.cs");
   exec("./Weapon_L4BFryingPan.cs");
   exec("./Weapon_L4BBaton.cs");
   //exec("./Weapon_L4BKatana.cs");
   //exec("./Weapon_Pipe.cs");
   //exec("./Weapon_Ice_Axe.cs");
   exec("./Weapon_L4BCrowbar.cs");
   exec("./Weapon_L4BSpade.cs");
   exec("./Item_Shield.cs");
}
