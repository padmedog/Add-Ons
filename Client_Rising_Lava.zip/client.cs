//+--------+--------------------+
//| Title  | Rising Lava Client |
//+--------+--------------------+
//| Author | Zapk, BL_ID: 12270 |
//+--------+--------------------+

$RLC::Version = "2.0.1";

exec( "./lib/Support_UpdaterDownload.cs" );
exec( "./lib/tango.cs" );
exec( "./src/profiles.cs" );

if( !isObject( RisingLavaMessage ) ) exec( "./res/gui/message.gui" );
if( !isObject( RisingLavaShop ) ) exec( "./res/gui/shop.gui" );
if( !isObject( RisingLavaVote ) ) exec( "./res/gui/vote.gui" );

exec( "./src/main.cs" );

function RLC_reload()
{
	echo("\c4Reloading Rising Lava Client");
	echo("------------------------");

	exec("./client.cs");

	echo("------------------------");
	echo("\c4Done!");
}

function clientCmdRLCHandshake()
{
	echo("\c4*****************************");
	echo("\c4* Rising Lava server found. *");
	echo("\c4* Responding to handshake.  *");
	echo("\c4*****************************");

	commandToServer('RLCHandshake', $RLC::Version);
}