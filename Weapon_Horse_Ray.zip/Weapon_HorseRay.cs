//HorseRay - shoot someone, they turn into a horse

//audio
//datablock AudioProfile(horseRayFireSound)
//{
//   filename    = "base/data/sound/printFire.wav";
//   description = AudioClose3d;
//   preload = true;
//};
//datablock AudioProfile(horseRayHitSound)
//{
//   filename    = "./horseRayHit.wav";
//   description = AudioClose3d;
//   preload = true;
//};


//explosion
datablock ParticleData(horseRayExplosionParticle)
{
   dragCoefficient      = 10;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 290;
   spinSpeed		= 0.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
   textureName          = "base/data/particles/star1";
   colors[0]     = "0.4 0.9 0.4 0.9";
   colors[1]     = "0.0 1.0 0.0 0.9";
   colors[2]     = "0.0 1.0 0.6 1.0";

   sizes[0]      = 0.0;
   sizes[1]      = 0.7;
   sizes[2]      = 2.0;

   times[0] = 0.0;
   times[1] = 0.9;
   times[2] = 1.0;
};

datablock ParticleEmitterData(horseRayExplosionEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 15;
   velocityVariance = 4.0;
   ejectionOffset   = 1.25;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "horseRayExplosionParticle";

   uiName = "Horse Ray Explosion";
};
datablock ExplosionData(horseRayExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 500;

   emitter[0] = horseRayExplosionEmitter;

   //soundProfile = horseRayHitSound;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "2.0 2.0 2.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 1;
   lightStartColor = "00.0 0.6 0.9";
   lightEndColor = "0 0 0";
};



//muzzle flash effects
datablock ParticleData(horseRayFlashParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 25;
	lifetimeVarianceMS   = 15;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1.0 0.9 0.0 0.9";
	colors[1]     = "0.0 0.5 0.0 0.0";
	sizes[0]      = 1.5;
	sizes[1]      = 2.50;

	useInvAlpha = false;
};
datablock ParticleEmitterData(horseRayFlashEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "horseRayFlashParticle";

   uiName = "Horse Ray Flash";
};

datablock ParticleData(horseRaySmokeParticle)
{
	dragCoefficient      = 1;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 525;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.1 0.9 0.1 0.2";
	colors[1]     = "0.1 0.9 0.1 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(horseRaySmokeEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = -3.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.50;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "horseRaySmokeParticle";

   uiName = "Horse Ray Charge";
};


//bullet trail effects
datablock ParticleData(horseRayTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 300;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/thinRing";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.0 0.9 0.1 0.4";
	colors[1]     = "0.1 0.9 0.0 0.4";
   colors[2]     = "0.1 0.9 0.0 0.0";
   sizes[0]      = 0.0;
	sizes[1]      = 1.0;
	sizes[2]      = 0.0;

   times[0] = 0;
   times[1] = 0.3;
   times[2] = 1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(horseRayTrailEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "horseRayTrailParticle";

   uiName = "Horse Ray Trail";
};


datablock ProjectileData(horseRayProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 30;
   directDamageType    = $DamageType::Default;
   radiusDamageType    = $DamageType::Default;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 000;
   verticalImpulse	  = 100;
   explosion           = horseRayExplosion;
   bloodExplosion        = horseRayExplosion;
   particleEmitter       = horseRayTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 3000;
   lifetime            = 3000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.99;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "Horse Ray";
};

//////////
// item //
//////////
datablock ItemData(horseRayItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "base/data/shapes/printGun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Horse Ray";
	iconName = "base/client/ui/itemIcons/Printer";
	doColorShift = true;
	colorShiftColor = "0.0 0.7 0.0 1.000";

	 // Dynamic properties defined by the scripts
	image = horseRayImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(horseRayImage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/printGun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = horseRayProjectile;
   projectileType = Projectile;

	//casing = horseRayShellDebris;
	//shellExitDir        = "1.0 -1.3 1.0";
	//shellExitOffset     = "0 0 0";
	//shellExitVariance   = 15.0;	
	//shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = horseRayItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.14;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= horseRayFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= printFireSound;
	stateEjectShell[2]       = true;

	stateName[3] = "Smoke";
	stateEmitter[3]					= horseRaySmokeEmitter;
	stateEmitterTime[3]				= 0.4;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.5;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

};

function horseRayImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, shiftAway);
	Parent::onFire(%this,%obj,%slot);	
}

function HorseRayProjectile::Damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.setDataBlock(HorseArmor);

      if(isObject(%col.client))
         %col.client.applyBodyColors();

      if(%col.getObjectMount())
         %col.getDataBlock().doDismount(%col);
   }
}