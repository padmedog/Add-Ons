//context.cs

function neomain::showcontext(%this, %pos, %mctrl)
{
	%mctrl.getgroup().setcolor($neo::pref::buttonColorSelect);
	%this.context_mctrl = %mctrl;
	%command = %mctrl.commandObj;
	%context = promptUserContext();
	%context.addButton("Use", %this @ ".useCommand(" @ %command @ ");");
	%context.addButton("Edit", %this @ ".promptEditCommand(" @ %command @ ");");

	if(!%command.isdefault)
		%context.addButton("Delete", %this @ ".promptdeletecommand(" @ %command @ ");");

	if(%command.modified)
		%context.addButton("Clear Edits", %this @ ".clearEdits(" @ %command @ ");");
	%context.addButton("Cancel", "");
	%context.display(%pos, "neo_closecontext");
}

function neo_closecontext()
{
	neomain.context_mctrl.getgroup().setcolor($neo::pref::buttonColorIdle);
}

function neomain::promptEditCommand(%this, %command)
{
	if(neo_newbuttongui.isawake())
		canvas.popdialog(neo_newbuttongui);
	canvas.pushdialog(neo_newbuttongui);
	neo_newbuttongui.setData(%command);
}

function neomain::promptdeletecommand(%this, %command)
{
	if(%command.isdefault)
		messageboxok("Attention!", "You cannot delete default commands");
	else
		messageboxyesno("Attention!", "Are you sure you want to delete this command?", %this @ ".confirmdelete(" @ %command @ ");", "");
}

function neomain::confirmdelete(%this, %command)
{
	neo_debug("rip");
	%this.removeCommand(%command);
	%this.savedata();
	%this.modified = true;
	%this.draw();
}

function neomain::clearedits(%this, %command)
{
	if(%command.custom)
		messageboxok("Attention!", "Custom commands have no default state to revert to, and therefore cannot have their edits cleared.  Sorry for the inconvenience.");
	else if(!%command.modified)
		messageboxok("Attention!", "This command has no edits to clear.");
	else
	{
		if(%command.isdefault)
		{
			//really shitty system because I didn't really leave myself a good way to do this
			$neo::data::saveModified[%this.commandLookup[%command.name, %command.cmd]] = 0;
			%this.removeCommand(%command);
			%this.loaddefaults();
			%this.maintain();
		}
		else
		{
			//in case a mod initializes $neoCount to 0
			if($neoName0 !$= "")
				%j = 0;
			else
				%j = "";

			for(%j = %j; %j < %this.lastLoaded; %j++)
			{
				if(%command.name $= $neoName[%j] && %command.cmd $= $neoCmd[%j])
				{
					%command.icon = $neoIcon[%j];
					%command.prefclose = $neoPrefClose[%j];
					%command.modified = false;

					if(!isfile(%command.icon))
						%command.icon = $neo::pref::defaulticon;
					%found = true;
				}
			}

			if(!%found)
			{
				neo_debug("error - unable to find original command data for: " @ %command.name);
				messageboxok("Error", "Unable to find default data for this command.");
			}
		}
		%this.saveData();
		%this.maintain();
		%this.forcedraw();
		return;
	}
}

