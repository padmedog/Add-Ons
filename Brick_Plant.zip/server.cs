datablock fxDTSBrickData(brick1x1StemData)
{
	brickFile = "./1x1stem.blb";
	iconName = "Add-Ons/Brick_Plant/1x1stem";
	category = "Special";
	subCategory = "Plants";
	uiName = "1x1 Stem";
	collisionShapeName = "./1x1stem.dts";
};

datablock fxDTSBrickData(brick1x1FlowersData)
{
	brickFile = "./1x1stemFlowers.blb";
	iconName = "Add-Ons/Brick_Plant/1x1flowers";
	category = "Special";
	subCategory = "Plants";
	uiName = "1x1 Flowers";
	collisionShapeName = "./1x1stem.dts";
};

datablock fxDTSBrickData(brick1x1BambooData)
{
	brickFile = "./1x1bamboo.blb";
	iconName = "Add-Ons/Brick_Plant/1x1bamboo";
	category = "Special";
	subCategory = "Plants";
	uiName = "1x1 Bamboo";
	collisionShapeName = "./1x1bamboo.dts";
};

datablock fxDTSBrickData(brick5x6LeavesData)
{
	brickFile = "./5x6leaves.blb";
	iconName = "Add-Ons/Brick_Plant/6x5leaves";
	category = "Special";
	subCategory = "Plants";
	uiName = "6x5 Leaves";
	collisionShapeName = "./6x5plantleaves.dts";
};

datablock fxDTSBrickData(brick4x3LeavesData)
{
	brickFile = "./4x3leaves.blb";
	iconName = "Add-Ons/Brick_Plant/3x4leaves";
	category = "Special";
	subCategory = "Plants";
	uiName = "4x3 Leaves";
	collisionShapeName = "./3x4plantleaves.dts";
};

datablock fxDTSBrickData(brickseagrassData)
{
	brickFile = "./seagrass.blb";
	iconName = "Add-Ons/Brick_Plant/seaweed";
	collisionShapeName = "./seagrass.dts";
	category = "Special";
	subCategory = "Plants";
	uiName = "Sea Grass";
};

datablock fxDTSBrickData(brickseagrassInvData)
{
	brickFile = "./seagrassInv.blb";
	iconName = "Add-Ons/Brick_Plant/seaweedInv";
	collisionShapeName = "./seagrassInv.dts";
	category = "Special";
	subCategory = "Plants";
	uiName = "Sea Grass Inverted";
};

datablock fxDTSBrickData(brickBushData)
{
	brickFile = "./bush.blb";
	iconName = "Add-Ons/Brick_Plant/bush";
	collisionShapeName = "./bush.dts";
	category = "Special";
	subCategory = "Plants";
	uiName = "2x2 Bush";
};

datablock fxDTSBrickData(brick2x2flowerData)
{
	brickFile = "./2x2flower.blb";
	iconName = "Add-Ons/Brick_Plant/2x2flower";
	collisionShapeName = "./2x2flower.dts";
	category = "Special";
	subCategory = "Plants";
	uiName = "2x2 Flower";
};

datablock fxDTSBrickData(brick2x2petalsData)
{
	brickFile = "./2x2petals.blb";
	iconName = "Add-Ons/Brick_Plant/2x2petals";
	collisionShapeName = "./2x2petals.dts";
	category = "Special";
	subCategory = "Plants";
	uiName = "2x2 Petals";
};