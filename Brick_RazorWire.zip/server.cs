datablock fxDTSBrickData(brickRazorWireData)
{
	brickFile = "./RazorWire.blb";
	iconName = "Add-Ons/Brick_RazorWire/RazorWire";
	category = "Special";
	subCategory = "Walls";
	uiName = "Razor Wire Fence";
};

datablock fxDTSBrickData(brickRazorWire2Data)
{
	brickFile = "./RazorWire2.blb";
	iconName = "Add-Ons/Brick_RazorWire/RazorWire2";
	category = "Special";
	subCategory = "Walls";
	uiName = "Razor Wire Fence Footless";
};

package razorWire
{
	function brickRazorWireData::onPlant(%data,%obj)
	{
		parent::onPlant(%data, %obj);
		%obj.addEvent(1,0,"OnPlayerTouch","Player","AddHealth","-10");
		%obj.addEvent(1,0,"OnBotTouch","Bot","AddHealth","-10");
	}

	function brickRazorWire2Data::onPlant(%data,%obj)
	{
		parent::onPlant(%data, %obj);
		%obj.addEvent(1,0,"OnPlayerTouch","Player","AddHealth","-10");
		%obj.addEvent(1,0,"OnBotTouch","Bot","AddHealth","-10");
	}

};
activatepackage(razorWire);