//-----
// Event_Minigame: A set of events that allow you to manipulate minigames
// by Destiny/Zack0Wack0 (zack0wack0.com)
//-----
// Register Events
//-----
registerInputEvent(fxDtsBrick,"onMinigameJoin","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tMinigame Minigame");
registerInputEvent(fxDtsBrick,"onMinigameLeave","Self fxDtsBrick\tClient GameConnection\tMinigame Minigame");
registerInputEvent(fxDtsBrick,"onMinigameKill","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tKillerPlayer Player\tKillerClient GameConnection\tMinigame Minigame");
registerInputEvent(fxDtsBrick,"onMinigameDeath","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tMinigame Minigame");
registerInputEvent(fxDtsBrick,"onMinigameReset","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tMinigame Minigame");
//Set variables to the index of the inputs so we don't have to lag the server up searching every time
$Event_Minigame::onMinigameJoinIndex = inputEvent_GetInputEventIdx("onMinigameJoin");
$Event_Minigame::onMinigameLeaveIndex = inputEvent_GetInputEventIdx("onMinigameLeave");
$Event_Minigame::onMinigameKillIndex = inputEvent_GetInputEventIdx("onMinigameKill");
$Event_Minigame::onMinigameDeathIndex = inputEvent_GetInputEventIdx("onMinigameDeath");
$Event_Minigame::onMinigameResetIndex = inputEvent_GetInputEventIdx("onMinigameReset");
$Event_Minigame::MinigameResetIndex = outputEvent_getOutputEventIdx(Minigame,"Reset");
//-----
// Package & Core Functions
//-----
package Event_Minigame
{
	function MinigameSO::addMember(%mini,%client)
	{
		Parent::addMember(%mini,%client);
		for(%i=0;%i<getWordCount($Event_Minigame::onMinigameJoinList);%i++)
		{
			%brick = getWord($Event_Minigame::onMinigameJoinList,%i);
			if(isObject(%brick))
			{
				if(getMinigameFromObject(getBrickGroupFromObject(%brick)) == %mini)
				{
					if(%mini.useAllPlayersBricks)
					{
						$inputTarget_Self = %brick;
						$inputTarget_Player = %client.player;
						$inputTarget_Client = %client;
						$inputTarget_Minigame = %mini;
						%brick.processInputEvent("onMinigameJoin",%client);
					}
					else if(!%mini.useAllPlayersBricks && getBrickGroupFromObject(%brick) == getBrickGroupFromObject(%client))
					{
						$inputTarget_Self = %brick;
						$inputTarget_Player = %client.player;
						$inputTarget_Client = %client;
						$inputTarget_Minigame = %mini;
						%brick.processInputEvent("onMinigameJoin",%client);
					}
				}
			}
		}
	}
	function MinigameSO::removeMember(%mini,%client)
	{
		Parent::removeMember(%mini,%client);
		for(%i=0;%i<getWordCount($Event_Minigame::onMinigameLeaveList);%i++)
		{
			%brick = getWord($Event_Minigame::onMinigameLeaveList,%i);
			if(isObject(%brick))
			{
				if(getMinigameFromObject(getBrickGroupFromObject(%brick)) == %mini)
				{
					if(%mini.useAllPlayersBricks)
					{
						$inputTarget_Self = %brick;
						$inputTarget_Client = %client;
						$inputTarget_Minigame = %mini;
						%brick.processInputEvent("onMinigameLeave",%client);
					}
					else if(!%mini.useAllPlayersBricks && getBrickGroupFromObject(%brick) == getBrickGroupFromObject(%client))
					{
						$inputTarget_Self = %brick;
						$inputTarget_Client = %client;
						$inputTarget_Minigame = %mini;
						%brick.processInputEvent("onMinigameLeave",%client);
					}
				}
			}
		}
	}
	function MinigameSO::reset(%mini,%client)
	{
		Parent::reset(%mini,%client);
		if(!isObject(%client))
		{
			%client = %mini.owner;
		}
		for(%i=0;%i<getWordCount($Event_Minigame::onMinigameResetList);%i++)
		{
			%brick = getWord($Event_Minigame::onMinigameResetList,%i);
			if(isObject(%brick))
			{
				if(getMinigameFromObject(getBrickGroupFromObject(%brick)) == %mini)
				{
					if(%mini.useAllPlayersBricks)
					{
						$inputTarget_Self = %brick;
						$inputTarget_Player = %client.player;
						$inputTarget_Client = %client;
						$inputTarget_Minigame = %mini;
						%brick.processInputEvent("onMinigameReset",%client);
					}
					else if(!%mini.useAllPlayersBricks && getBrickGroupFromObject(%brick) == getBrickGroupFromObject(%client))
					{
						$inputTarget_Self = %brick;
						$inputTarget_Player = %client.player;
						$inputTarget_Client = %client;
						$inputTarget_Minigame = %mini;
						%brick.processInputEvent("onMinigameReset",%client);
					}
				}
			}
		}
	}
	function gameConnection::onDeath(%client,%obj,%killer,%type,%location)
	{
		Parent::onDeath(%client,%obj,%killer,%type,%location);
		%mini = getMinigameFromObject(%client);
		if(isObject(%mini))
		{
			if(%killer == %client || %obj == 0 || %killer == 0)
			{
				for(%i=0;%i<getWordCount($Event_Minigame::onMinigameDeathList);%i++)
				{
					%brick = getWord($Event_Minigame::onMinigameDeathList,%i);
					if(isObject(%brick))
					{
						if(getMinigameFromObject(getBrickGroupFromObject(%brick)) == %mini)
						{
							if(%mini.useAllPlayersBricks)
							{
								$inputTarget_Self = %brick;
								$inputTarget_Player = %client.player;
								$inputTarget_Client = %client;
								$inputTarget_Minigame = %mini;
								%brick.processInputEvent("onMinigameDeath",%client);
							}
							else if(!%mini.useAllPlayersBricks && getBrickGroupFromObject(%brick) == getBrickGroupFromObject(%client))
							{
								$inputTarget_Self = %brick;
								$inputTarget_Player = %client.player;
								$inputTarget_Client = %client;
								$inputTarget_Minigame = %mini;
								%brick.processInputEvent("onMinigameDeath",%client);
							}
						}
					}
				}
			}
			else
			{
				for(%i=0;%i<getWordCount($Event_Minigame::onMinigameKillList);%i++)
				{
					%brick = getWord($Event_Minigame::onMinigameKillList,%i);
					if(isObject(%brick))
					{
						if(getMinigameFromObject(getBrickGroupFromObject(%brick)) == %mini)
						{
							if(%mini.useAllPlayersBricks)
							{
								$inputTarget_Self = %brick;
								$inputTarget_Player = %client.player;
								$inputTarget_Client = %client;
								$inputTarget_KillerPlayer = %killer.player;
								$inputTarget_KillerClient = %killer;
								$inputTarget_Minigame = %mini;
								%brick.processInputEvent("onMinigameKill",%client);
							}
							else if(!%mini.useAllPlayersBricks && getBrickGroupFromObject(%brick) == getBrickGroupFromObject(%client))
							{
								$inputTarget_Self = %brick;
								$inputTarget_Player = %client.player;
								$inputTarget_Client = %client;
								$inputTarget_KillerPlayer = %killer.player;
								$inputTarget_KillerClient = %killer;
								$inputTarget_Minigame = %mini;
								%brick.processInputEvent("onMinigameKill",%client);
							}
						}
					}
				}
			}
		}
	}
	function serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4)
	{
		if(%input == $Event_Minigame::onMinigameJoinIndex)
		{
			$Event_Minigame::onMinigameJoinList = addItemToList($Event_Minigame::onMinigameJoinList,%client.wrenchBrick);
		}
		if(%input == $Event_Minigame::onMinigameLeaveIndex)
		{
			$Event_Minigame::onMinigameLeaveList = addItemToList($Event_Minigame::onMinigameLeaveList,%client.wrenchBrick);
		}
		if(%input == $Event_Minigame::onMinigameKillIndex)
		{
			$Event_Minigame::onMinigameKillList = addItemToList($Event_Minigame::onMinigameKillList,%client.wrenchBrick);
		}
		if(%input == $Event_Minigame::onMinigameDeathIndex)
		{
			$Event_Minigame::onMinigameDeathList = addItemToList($Event_Minigame::onMinigameDeathList,%client.wrenchBrick);
		}
		if(%input == $Event_Minigame::onMinigameResetIndex)
		{
			if(%output == $Event_Minigame::MinigameResetIndex)
			{
				return;
			}
			$Event_Minigame::onMinigameResetList = addItemToList($Event_Minigame::onMinigameResetList,%client.wrenchBrick);
		}
		return Parent::serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4);
	}
	function serverCmdClearEvents(%client)
	{
		if(hasItemOnList($Event_Minigame::onMinigameJoinList,%client.wrenchBrick))
		{
			$Event_Minigame::onMinigameJoinList = removeItemFromList($Event_Minigame::onMinigameJoinList,%client.wrenchBrick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameLeaveList,%client.wrenchBrick))
		{
			$Event_Minigame::onMinigameLeaveList = removeItemFromList($Event_Minigame::onMinigameLeaveList,%client.wrenchBrick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameKillList,%client.wrenchBrick))
		{
			$Event_Minigame::onMinigameKillList = removeItemFromList($Event_Minigame::onMinigameKillList,%client.wrenchBrick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameDeathList,%client.wrenchBrick))
		{
			$Event_Minigame::onMinigameDeathList = removeItemFromList($Event_Minigame::onMinigameDeathList,%client.wrenchBrick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameResetList,%client.wrenchBrick))
		{
			$Event_Minigame::onMinigameResetList = removeItemFromList($Event_Minigame::onMinigameResetList,%client.wrenchBrick);
		}
		Parent::serverCmdClearEvents(%client);
	}
	function fxDtsBrick::onDeath(%brick)
	{
		if(hasItemOnList($Event_Minigame::onMinigameJoinList,%brick))
		{
			$Event_Minigame::onMinigameJoinList = removeItemFromList($Event_Minigame::onMinigameJoinList,%brick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameLeaveList,%brick))
		{
			$Event_Minigame::onMinigameLeaveList = removeItemFromList($Event_Minigame::onMinigameLeaveList,%brick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameKillList,%brick))
		{
			$Event_Minigame::onMinigameKillList = removeItemFromList($Event_Minigame::onMinigameKillList,%brick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameDeathList,%brick))
		{
			$Event_Minigame::onMinigameDeathList = removeItemFromList($Event_Minigame::onMinigameDeathList,%brick);
		}
		if(hasItemOnList($Event_Minigame::onMinigameResetList,%brick))
		{
			$Event_Minigame::onMinigameResetList = removeItemFromList($Event_Minigame::onMinigameResetList,%brick);
		}
		Parent::onDeath(%brick);
	}
};
activatePackage(Event_Minigame);
//-----
// Misc. & Support Functions
//-----
//addItemToList, hasItemOnList and removeItemFromList by Ephialtes
//Useful functions for manipulating space delimited lists
function addItemToList(%string,%item)
{
	if(hasItemOnList(%string,%item))
		return %string;

	if(%string $= "")
		return %item;
	else
		return %string SPC %item;
}
function hasItemOnList(%string,%item)
{
	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
			return 1;
	}
	return 0;
}
function removeItemFromList(%string,%item)
{
	if(!hasItemOnList(%string,%item))
		return %string;

	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
		{
			if(%i $= 0)
				return getWords(%string,1,getWordCount(%string));
			else if(%i $= getWordCount(%string)-1)
				return getWords(%string,0,%i-1);
			else
				return getWords(%string,0,%i-1) SPC getWords(%string,%i+1,getWordCount(%string));
		}
	}
}