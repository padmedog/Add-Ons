//Adds an add-on to the update queue
//@param	string addon	The name of an add-on w/ an available update, such as Weapon_Gun.
function UpdaterQueueSG::push(%this, %addon)
{
	if(!strLen(%addon.updateFile))
	{
		error("ERROR:" SPC %addon.name SPC "invalid download URL.");
		return;
	}
	%downloadPath = "Add-Ons/" @ %addon.name @ ".zip";
	if(!isWriteableFileName(%downloadPath))
	{
		error("ERROR:" SPC %addon.name SPC "invalid download path.");
		//return; //this will be caught later in the process - at least let the user know there's an update
	}

	%this.add(%addon);

	if($Pref::Updater::SilentUpdates)
	{
		cancel(updater.silentUpdateSched);
		updater.silentUpdateSched = updater.schedule(5000, "doUpdates");
	}
	else
	{
		updaterInterfacePushItem(%addon);
	}

	echo(%addon.name SPC "added to download queue.");
}

//Removes the first object from the queue.
function UpdaterQueueSG::pop(%this)
{
	%download = %this.getObject(0);
	if(!$Pref::Updater::SilentUpdates)
		updaterInterfacePopItem(%download);
	%this.remove(%download);
}

function UpdaterQueueSG::removeAll(%this)
{
	while(%this.getCount() > 0)
		%this.remove(%this.getObject(0));
}

//Advances to the next file and begins downloading it.
function UpdaterQueueSG::downloadNext(%this)
{
	if(%this.getCount() < 1)
	{
		%this.onQueueEmpty();
		return;
	}
	%this.currentDownload = %this.getObject(0);

	//view info
	if(!$Pref::Updater::SilentUpdates)
		updaterInterfaceSelectItem(%this.currentDownload);

	%downloadPath = "Add-Ons/" @ %this.currentDownload.name @ ".zip";
	%this.downloadTCP = connectToURL(
		%this.currentDownload.updateFile,
		"GET",
		%downloadPath,
		UpdaterDownloadTCP
	);
}

//Downloads the change log associated with an object in the queue.
//@param	ScriptObject queueObj	A download object which is currently in the queue.
function UpdaterQueueSG::downloadChangeLog(%this, %queueObj)
{
	%queueObj.changeLogTCP = connectToURL(
		%queueObj.updateChangeLog,
		"GET",
		"",
		UpdaterChangeLogTCP
	);
	%queueObj.changeLogTCP.queueObj = %queueObj;
}

//Handles cleanup tasks after a download has finished.
function UpdaterQueueSG::onDownloadFinished(%this, %error)
{
	%addon = %this.currentDownload;
	if(%error)
	{
		warn("Unable to update" SPC %addon.name @ "! TCPClient error" SPC %error);
		updater.hasErrors = true;
	}
	else
	{
		%callbackFile = "Add-Ons/" @ %addon.name @ "/update.cs";
		%restart = %addon.updateRestartRequired;
		%zip = "Add-Ons/" @ %addon.name @ ".zip";
		discoverFile(%zip);
		$version__[%addon.name] = %addon.updateVersion;
		$versionOld__[%addon.name] = %addon.version;
		$versionRestartRequired__[%addon.name] = %restart;
		if(isFile(%callbackFile))
		{
			echo(%addon.name SPC "running update scripts.");
			exec(%callbackFile);
		}
		if(%restart)
		{
			warn(%addon.name SPC "requires a restart!");
			updater.restartRequired = true;
		}
		else
		{
			echo(%addon.name SPC "update completed!");
			%file = "Add-Ons/" @ %addon.name @ "/server.cs";
			if(isFile(%file) && $Game::Running && $AddOnLoaded__[%addon.name])
				exec(%file);
			%file = "Add-Ons/" @ %addon.name @ "/client.cs";
			if(isFile(%file) && !$Server::Dedicated)
				exec(%file);
		}
	}

	%this.currentDownload = 0;

	%this.pop();
	%this.downloadNext();
}

//Called when all downloads have completed.
function UpdaterQueueSG::onQueueEmpty(%this)
{
	if(!$Pref::Updater::SilentUpdates)
		updaterInterfaceOnQueueEmpty();
	updater.readFileInfo();
}

//Handles cleanup after a file has been downloaded.
function UpdaterDownloadTCP::onDone(%this, %error)
{
	updater.queue.onDownloadFinished(%error);
}

//Sets the progress bar.
//@param	float value	A floating point number from 0 to 1.
function UpdaterDownloadTCP::setProgressBar(%this, %value)
{
	%progressBar = updater.queue.currentDownload.guiSwatch.progress;
	if(isObject(%progressBar))
		%progressBar.setValue(%value);
}

//Displays the change log text.
function UpdaterChangeLogTCP::onDone(%this, %error)
{
	if(updaterDlg.viewItem == %this.queueObj)
	{
		if(%error)
		{
			updaterDlgChangeLogText.setText("<color:ffffff><just:center>\n\n\n\nError occured. Change log unavailable.");
		}
		else
		{
			if(!%this.queueObj.updateChangeLogParsed)
			{
				%this.queueObj.updateChangeLogText = parseCustomTML(
					"<color:ffffff><linkcolor:cccccc>" @ %this.queueObj.updateChangeLogText,
					updaterDlgChangeLogText,
					"updaterChangeLog\tdefault");
				%this.queueObj.updateChangeLogParsed = true;
			}
			updaterDlgChangeLogText.setText(%this.queueObj.updateChangeLogText);
		}
	}
}

//Callback from the TCP library.
function UpdaterChangeLogTCP::handleText(%this, %text)
{
	%this.queueObj.updateChangeLogText = %this.queueObj.updateChangeLogText @ %text;
}

function customTMLParser_updaterChangeLog(%obj,%value0,%value1)
{
	switch$(%value[0])
	{
		case "version":
			return true TAB "<h3>Version" SPC %value[1] @ "</h3>";

		case "/version":
			return true TAB "<br><br>";
	}
	return false;
}