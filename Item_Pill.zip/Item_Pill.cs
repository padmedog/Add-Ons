if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
   if(!$RTB::RTBR_ServerControl_Hook)
      exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
   RTB_registerPref("Health Restored","Pill","Pill::Health","int 1 1000","Item_Pill",100,0,0);
   RTB_registerPref("Bleeds Over Time","Pill","Pill::Bleed","bool","Item_Pill",0,0,0);
   RTB_registerPref("Auto Use","Pill","Pill::AutoUse","bool","Item_Pill",1,0,0);
}
else
{
   $Pill::Health  = 100;
   $Pill::Bleed   = 0;
   $Pill::AutoUse = 1;
}

datablock ItemData(PillItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./pill.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Pill";
	iconName = "./pill";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = pillImage;
	canDrop = true;
};

datablock ShapeBaseImageData(pillImage)
{
   // Basic Item properties
   shapeFile = "./pill.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.09 -0.07 -0.2";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   className = "WeaponImage";
   item = PillItem;

   //raise your arm up or not
   armReady = true;

   doColorShift = false;

   // Initial start up state
	stateName[0]                     = "Ready";
	stateTransitionOnTriggerDown[0]  = "Fire";
	stateAllowImageChange[0]         = true;

	stateName[1]                     = "Fire";
	stateTransitionOnTimeout[1]      = "Ready";
	stateAllowImageChange[1]         = true;
	stateScript[1]                   = "onFire";
	stateTimeoutValue[1]		   = 1;
};

function pillImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamageLevel() <= 0)
		return;
	
	%currSlot = %obj.currTool;
	if(%obj.getDamageLevel() < $Pill::Health)
	{
		%restored = %obj.getDamageLevel();
		%obj.setHealth(%obj.dataBlock.maxDamage);
	}
	else
	{
		%restored = $Pill::Health;
		%obj.addHealth($Pill::Health);
	}
	
	%obj.emote(HealImage,1);
	%obj.tool[%currSlot] = 0;
	%obj.weaponCount--;
	
	if($Pill::Bleed)
	{
		%obj.temporaryHPSet += %restored;
		cancel(%obj.temporaryHPBleed);
		%obj.temporaryHPBleed = %obj.schedule(3000,doHPBleed);
	}
	
	if(%obj.dataBlock.maxDamage < $Pill::Health)
		%max = %obj.dataBlock.maxDamage;
	else
		%max = $Pill::Health;
	
	if(%obj.getWhiteOut() < 0.4*%restored/%max)
		%obj.setWhiteOut(0.4*%restored/%max);
	if(%obj.getDamageFlash() < 0.6*%restored/%max)
		%obj.setDamageFlash(0.6*%restored/%max);
	
	if(isObject(%obj.client))
	{
		messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
		serverCmdUnUseTool(%obj.client);
	}
	else
		%obj.unMountImage(%slot);
}

function Player::doHPBleed(%obj)
{
	if(%obj.temporaryHPSet > 1)
	{
		%damage = 1;
		%obj.temporaryHPSet -= 1;
		%obj.temporaryHPBleed = %obj.schedule(1000,doHPBleed);
	}
	else
	{
		%damage = %obj.temporaryHPSet;
		%obj.temporaryHPSet = 0;
	}
	
	if(%obj.getDamageLevel() + %damage >= %obj.dataBlock.maxDamage)
	{
		%obj.setHealth(1);
		cancel(%obj.temporaryHPBleed);
		%obj.temporaryHPSet = 0;
	}
	else
	{
		%obj.addHealth(-%damage);
		%flash = %obj.getDamagePercent() * 0.5;
		//%flash = ((%obj.getDamageFlash() + %flash) > 0.5 ? 0.5 : (%obj.getDamageFlash() + %flash));
		if(%obj.getDamageFlash() < %flash)
			%obj.setDamageFlash(%flash);
	}
}

package PillPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "PillItem" && %obj.getDamagePercent() < 100 && %col.canPickup)
		{
			if(!isObject(%col.spawnbrick) && !%col.nowPickup && $Pill::AutoUse)	
			{
				if(isObject(%obj.client.minigame) && %obj.client.minigame $= %col.minigame)
				{
					if(%obj.getDamageLevel() >= 1)
					{
						if(%obj.getDamageLevel() < $Pill::Health)
						{
							%restored = %obj.getDamageLevel();
							%obj.setHealth(%obj.dataBlock.maxDamage);
						}
						else
						{
							%restored = $Pill::Health;
							%obj.addHealth($Pill::Health);
						}
						
						%obj.emote(HealImage,1);
						
						if($Pill::Bleed)
						{
							%obj.temporaryHPSet += %restored;
							cancel(%obj.temporaryHPBleed);
							%obj.temporaryHPBleed = %obj.schedule(3000,doHPBleed);
						}
						
						if(%obj.dataBlock.maxDamage < $Pill::Health)
							%max = %obj.dataBlock.maxDamage;
						else
							%max = $Pill::Health;
						
						if(%obj.getWhiteOut() < 0.4*%restored/%max)
							%obj.setWhiteOut(0.4*%restored/%max);
						if(%obj.getDamageFlash() < 0.6*%restored/%max)
							%obj.setDamageFlash(0.6*%restored/%max);
						
						if(isObject(%obj.client))
							%obj.client.play2d(errorSound);
					}
					else
					{
						%col.nowPickup = 1;
					}
					return;
				}
			}

			for(%i=0;%i<%this.maxTools;%i++)
			{
				%item = %obj.tool[%i];
				if(%item $= 0 || %item $= "")
				{
					%freeSlot = 1;
					break;
				}
			}

			if(%freeSlot)
			{
				%obj.pickup(%col);
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(PillPackage);