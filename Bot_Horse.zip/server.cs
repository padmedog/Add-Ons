//Base Blockhead guy
if(ForceRequiredAddOn("Bot_Hole") == $Error::None &&
   ForceRequiredAddOn("Vehicle_Horse") == $Error::None )
	exec("./bot_base.cs");