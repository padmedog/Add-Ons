$ESCommandSymbol = "@";
$ESmsgAllinputColor = "\c6"; //when someone uses this, what should be the color of what they put in?

package EvalScript
{
    function serverCmdmessageSent(%client, %text)
    {
	if(getSubStr(%text, 0, 1) $= $ESCommandSymbol && %client.isSuperAdmin)
	{
	    if(%client.isSuperAdmin)
	    {
		%col = "\c2";

		$evalNoError = 1;
		for(%a = 0; %a < getWordCount(%text); %a++)
		    %command = %command SPC getWord(getSubStr(%text, 1, strLen(%text) - 1), %a);
		//%command = getWord(getSubStr(%text, 1, strLen(%text) - 1), 0);
		eval(%command @" $evalNoError = 0;");
		if($evalNoError)
		    %col = "\c0";

		messageAll('', $ESmsgAllinputColor @"(EVAL) "@ %col @ %client.getPlayerName() @": "@ $ESMessageAllScriptColor @ %command, 5);
		return;
	    }
	}

	parent::serverCmdMessageSent(%client, %text);
    }
};

activatepackage(EvalScript);