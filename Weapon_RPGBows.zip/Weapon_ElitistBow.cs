//elitistbow.cs
//rpgbow and rpgbowarrow weapon stuff

//rpgbowarrow trail
datablock ParticleData(goldbowarrowTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 300;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "./RPGbowimages/goldeneye";
	//animTexName		= "./RPGbowimages/goldeneye";

	// Interpolation variables
	colors[0]	= "1 1 1 0.2";
	colors[1]	= "1 1 1 0.0";
	sizes[0]	= 0.2;
	sizes[1]	= 0.01;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(goldbowarrowTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = goldbowarrowTrailParticle;

   useEmitterColors = true;
   uiName = "Golden Eye";
};

//effects
datablock ParticleData(goldbowarrowStickExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 2.1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.4;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 300;
	textureName          = "./RPGbowimages/flutter";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.6 0.9";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.0;
};
datablock ParticleEmitterData(goldbowarrowStickExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 20;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 80;
   thetaMax         = 80;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "goldbowarrowStickExplosionParticle";

   useEmitterColors = true;
   uiName = "White Arrow Particle";
};
datablock ExplosionData(goldbowarrowStickExplosion)
{
   //explosionShape = "";
	soundProfile = arrowhitSound;

   lifeTimeMS = 50;

   particleEmitter = goldbowarrowStickExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = "";

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "2.0 2.0 2.0";
   camShakeAmp = "0.5 0.5 0.5";
   camShakeDuration = 0.2;
   camShakeRadius = 4.0;

   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 3;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};



datablock ParticleData(goldbowarrowExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -2.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 2.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 400;
	textureName          = "./RPGbowimages/flutter";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.5 0.5 0.5 0.9";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.45;
	sizes[1]      = 0.0;

   useInvAlpha = true;
};
datablock ParticleEmitterData(goldbowarrowExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "goldbowarrowExplosionParticle";

   useEmitterColors = true;
   uiName = "White Arrow Explosion";
};
datablock ExplosionData(goldbowarrowExplosion)
{
   //explosionShape = "";
	soundProfile = "";

   lifeTimeMS = 200;

   emitter[0] = goldbowarrowExplosionEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "2.0 3.0 2.0";
   camShakeAmp = "0.5 0.5 0.5";
   camShakeDuration = 0.2;
   camShakeRadius = 5.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 1;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};


//projectile

datablock ProjectileData(rpgbowarrowProjectile)
{
   projectileShapeName = "./arrows/elitebowarrow.dts";

   directDamage        = 75;
   directDamageType    = $DamageType::rpgbowarrowDirect;

   radiusDamage        = 10;
   damageRadius        = 20;
   radiusDamageType    = $DamageType::rpgbowarrowDirect;

   explosion             = goldbowarrowExplosion;
   stickExplosion        = goldbowarrowStickExplosion;
   bloodExplosion        = goldbowarrowStickExplosion;
   particleEmitter       = goldbowarrowTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = true;  

   armingDelay         = 5000;
   lifetime            = 6000;
   fadeDelay           = 5000;

   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.10;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   muzzleVelocity      = 200;
   velInheritFactor    = 1;

   uiName = "Golden Elitist Arrow";
};


//////////
// item //
//////////
datablock ItemData(elitebowItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./elitistbow.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Elitist Bow";
	iconName = "./icon_elbow";
	doColorShift = true;
	colorShiftColor = "0.400 0.196 0 1.000";

	 // Dynamic properties defined by the scripts
	image = elitebowImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(elitebowImage)
{
   // Basic Item properties
   shapeFile = "./elitistbow.dts";
   emap = true;

   // Specify mount goldeneye & offset for 3rd person, and eye offset
   // for first person rendering.
   mountgoldeneye = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 10" );

   // When firing from a goldeneye offset from the eye, muzzle correction
   // will adjust the muzzle vector to goldeneye to the eye LOS goldeneye.
   // Since this weapon doesn't actually fire from the muzzle goldeneye,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = elitebowItem;
   ammo = " ";
   projectile = rpgbowarrowProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = elitebowItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = swordDrawSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.1;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "StopFire";
	stateTimeoutValue[3]            = 0.2;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;
	
	stateName[4]                    = "StopFire";
	stateTransitionOnTimeout[4]     = "wait";
	stateTimeoutValue[4]            = 0.2;
	stateAllowImageChange[4]        = false;
	stateWaitForTimeout[4]		= true;
	stateSequence[4]                = "StopFire";
	stateScript[4]                  = "onStopFire";

	stateName[5]                    = "wait";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 1.2;
	stateWaitForTimeout[5]		= true;


};


