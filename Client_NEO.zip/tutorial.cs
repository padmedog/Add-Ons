//tutorial.cs

while(isobject(neo_tutorial))
	neo_tutorial.delete();
exec("./tutorial.gui");

function neo_tutorial::next(%this)
{
	if(neo_tutorial_page1.isvisible())
	{
		neo_tutorial_page1.setvisible(0);
		neo_tutorial_page2.setvisible(1);
	}
	else if(neo_tutorial_page2.isvisible())
	{
		neo_tutorial_page2.setvisible(0);
		neo_tutorial_page3.setvisible(1);
	}
	else if(neo_tutorial_page3.isvisible())
	{
		neo_tutorial_page3.setvisible(0);
		neo_tutorial_page4.setvisible(1);
	}
}

function neo_tutorial::prev(%this)
{
	if(neo_tutorial_page2.isvisible())
	{
		neo_tutorial_page1.setvisible(1);
		neo_tutorial_page2.setvisible(0);
	}
	else if(neo_tutorial_page3.isvisible())
	{
		neo_tutorial_page2.setvisible(1);
		neo_tutorial_page3.setvisible(0);
	}
	else if(neo_tutorial_page4.isvisible())
	{
		neo_tutorial_page3.setvisible(1);
		neo_tutorial_page4.setvisible(0);
	}
}

