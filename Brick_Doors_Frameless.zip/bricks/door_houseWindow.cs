datablock fxDTSBrickData ( brickDoorHouseWindowOpenCW_NoFrame )
{
	brickFile = "./door_houseWindow_openCW.blb";
	uiName = "Window Door Frameless";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickDoorHouseWindowCW_NoFrame";
	openCW = "brickDoorHouseWindowOpenCW_NoFrame";
	
	closedCCW = "brickDoorHouseWindowCW_NoFrame";
	openCCW = "brickDoorHouseWindowOpenCCW_NoFrame";
};

datablock fxDTSBrickData ( brickDoorHouseWindowOpenCCW_NoFrame : brickDoorHouseWindowOpenCW_NoFrame )
{
	brickFile = "./door_houseWindow_openCCW.blb";
	
	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoorHouseWindowCW_NoFrame : brickDoorHouseWindowOpenCW_NoFrame )
{
	brickFile = "./door_houseWindow_closed.blb";
	category = "Special";
	subCategory = "Doors";

	iconName = "Add-Ons/Brick_Doors_Frameless/bricks/Window Door";

	isOpen = 0;
	
};