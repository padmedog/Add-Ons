datablock fxDTSBrickData (brick1x1RampFFData)
{
	brickFile = "./1x1RampFF.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Small";
	uiName = "1x1 Ramp FF";
	iconName = "Add-Ons/Brick_SmallR/1x1RFF";
};

datablock fxDTSBrickData (brick1x2RampFFData)
{
	brickFile = "./1x2RampFF.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Small";
	uiName = "1x2 Ramp FF";
	iconName = "Add-Ons/Brick_SmallR/1x2RFF";
};

datablock fxDTSBrickData (brick1x1RampCornerFFData)
{
	brickFile = "./1x1RampCornerFF.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Small";
	uiName = "1x1 Ramp Corner FF";
	iconName = "Add-Ons/Brick_SmallR/1x1RCFF";
};

datablock fxDTSBrickData (brick1x1RampInvCornerFFData)
{
	brickFile = "./1x1RampInvCornerFF.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Small";
	uiName = "1x1 Ramp Inv Corner FF";
	iconName = "Add-Ons/Brick_SmallR/1x1RICFF";
};