datablock fxDTSBrickData ( brickDoorHouseOpenCW_NoFrame )
{
	brickFile = "./door_house_openCW.blb";
	uiName = "House Door Frameless";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoorHouseCW_NoFrame";
	openCW = "brickDoorHouseOpenCW_NoFrame";
	
	closedCCW = "brickDoorHouseCW_NoFrame";
	openCCW = "brickDoorHouseOpenCCW_NoFrame";
};

datablock fxDTSBrickData ( brickDoorHouseOpenCCW_NoFrame : brickDoorHouseOpenCW_NoFrame )
{
	brickFile = "./door_house_openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoorHouseCW_NoFrame : brickDoorHouseOpenCW_NoFrame )
{
	brickFile = "./door_house_closed.blb";
	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Frameless/bricks/House Door";

	isOpen = 0;
};