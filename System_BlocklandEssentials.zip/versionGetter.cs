$blrsversionGetter = 1;
$versionGot = 0;

function getVersion()
{
	if(!isObject(versionGetter))
		new HTTPObject(versionGetter);
	versionGetter.get("syerjchep.org:80","/blrs/version.html");
}

function versionGetter::onLine(%this,%line)
{
	if(getField(%line,0) $= "SERVER")
	{
		$blrs::latestServer = getField(%line,1);
		echo("Latest server version: " @ $blrs::latestServer);
		$versionGot = 1;
	}
	else if(getField(%line,0) $= "CLIENT")
	{
		$blrs::latestClient = getField(%line,1);
		echo("Latest client version: " @ $blrs::latestClient);
		$versionGot = 1;
	}
	else if(getField(%line,0) $= "END" || %line $= "END")
	{
		$versionGot = 1;
		%this.delete();
		return;
	}
}

function versionLoop()
{
	getVersion();
	if(!$versionGot)
		schedule(15000,0,versionLoop);
}

versionLoop();
