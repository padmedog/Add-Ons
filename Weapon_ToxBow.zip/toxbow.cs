//########## Toxix Bow

//### Sounds

datablock AudioProfile(gc_ToxBowFireSound)
{
  filename = "./toxbow.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_ToxBowReloadSound)
{
  filename = "./toxbowreload.wav";
  description = AudioClosest3d;
  preload = true;
};

datablock AudioProfile(gc_ToxBowHitSound)
{
  filename = "./hit.wav";
  description = AudioClosest3d;
  preload = true;
};

//### Effects

datablock ParticleData(gc_ToxBowTrailParticle)
{
  dragCoefficient = 8;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 200;
  textureName = "base/data/particles/ring";
  spinSpeed = 10;
  spinRandomMin = -50;
  spinRandomMax = 50;
  colors[0] = "0.6 1 0 0.2";
  colors[1] = "0.6 1 0 0";
  sizes[0] = 0.1;
  sizes[1] = 0.2;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_ToxBowTrailEmitter)
{
  uiName = "";
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0;
  ejectionOffset = 0;
  thetaMin = 89;
  thetaMax = 90;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = false;
  particles = "gc_ToxBowTrailParticle";
};

datablock ParticleData(gc_ToxBowSmokeParticle)
{
  dragCoefficient = 6;
  gravityCoefficient = 0;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1200;
  lifetimeVarianceMS = 600;
  textureName = "./skull";
  spinSpeed = 0;
  spinRandomMin = 0;
  spinRandomMax = 0;
  colors[0] = "0.5 1 0 1";
  colors[1] = "0.5 1 0 0.3";
  colors[2] = "0.6 0 1 0";
  sizes[0] = 1;
  sizes[1] = 4;
  sizes[2] = 6;
  times[0] = 0;
  times[1] = 0.1;
  times[2] = 1;
  useInvAlpha = false;
};

datablock ParticleEmitterData(gc_ToxBowSmokeEmitter)
{
  uiName = "";
  lifetimeMS = 100;
  ejectionPeriodMS = 4;
  periodVarianceMS = 0;
  ejectionVelocity = 6;
  velocityVariance = 2;
  ejectionOffset = 1;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = true;
  useEmitterColors = false;
  orientParticles = false;
  particles = "gc_ToxBowSmokeParticle";
};

datablock ExplosionData(gc_ToxBowExplosion)
{
  lifeTimeMS = 50;
  emitter[0] = gc_ToxBowSmokeEmitter;
  faceViewer = true;
  explosionScale = "1 1 1";
  soundProfile = gc_ToxBowHitSound;
  shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "1 1 1";
  camShakeDuration = 0.5;
  camShakeRadius = 1;
};


datablock ParticleData(gc_poisoningEffectParticle)
{
  dragCoefficient = 5;
  gravityCoefficient = -0.2;
  inheritedVelFactor = 0;
  constantAcceleration = 0;
  lifetimeMS = 1000;
  lifetimeVarianceMS = 500;
  useInvAlpha = false;
  textureName = "./skull";
  colors[0] = "0.5 1 0 0";
  colors[1] = "0.5 1 0 0.5";
  colors[2] = "0.6 0 1 0";
  sizes[0] = 0.8;
  sizes[1] = 1;
  sizes[2] = 0.8;
  times[0] = 0;
  times[1] = 0.2;
  times[2] = 1;
};

datablock ParticleEmitterData(gc_poisoningEffectEmitter)
{
  uiName = "";
  ejectionPeriodMS = 25;
  periodVarianceMS = 0;
  ejectionVelocity = 0;
  velocityVariance = 0.5;
  ejectionOffset = 1;
  thetaMin = 0;
  thetaMax = 180;
  phiReferenceVel = 0;
  phiVariance = 360;
  overrideAdvance = true;
  useEmitterColors = false;
  orientParticles = false;
  particles = "gc_poisoningEffectParticle";
};

datablock ShapeBaseImageData(gc_poisoningEffectImage)
{
  shapeFile = "base/data/shapes/empty.dts";
  emap = false;
  mountPoint = $HeadSlot;

  stateName[0] = "Ready";
  stateTransitionOnTimeout[0] = "Fire";
  stateTimeoutValue[0] = 0.01;

  stateName[1] = "Fire";
  stateTransitionOnTimeout[1] = "Done";
  stateWaitForTimeout[1] = true;
  stateTimeoutValue[1] = 0.5;
  stateEmitter[1] = gc_poisoningEffectEmitter;
  stateEmitterTime[1] = 0.5;

  stateName[2] = "Done";
  stateScript[2] = "onDone";
};

function gc_poisoningEffectImage::onDone(%this,%obj,%slot) { %obj.unMountImage(%slot); }

//### Projectile

AddDamageType("gc_ToxBow",'<bitmap:Add-ons/Weapon_ToxBow/CI_toxbow> %1','%2 <bitmap:Add-ons/Weapon_ToxBow/CI_toxbow> %1',0.2,1);

datablock ProjectileData(gc_ToxBowProjectile)
{
  uiName = "";
  projectileShapeName = "Add-ons/Weapon_ToxBow/bolt.dts";
  directDamage = 50;
  directDamageType = $DamageType::gc_ToxBow;
  radiusDamageType = $DamageType::gc_ToxBow;
  brickExplosionRadius = 0;
  brickExplosionImpact = false;
  impactImpulse = 500;
  verticalImpulse = 0;
  particleEmitter = gc_ToxBowTrailEmitter;
  explosion = gc_ToxBowExplosion;
//  stickExplosion = gc_ToxBowExplosion;
//  bloodExplosion = gc_ToxBowExplosion;
  muzzleVelocity = 200;
  verInheritFactor = 1;
  lifetime = 5000;
  fadeDelay = 5000;
//  armingDelay = 5000;
  bounceElasticity = 0.5;
  bounceFriction = 0.2;
  isBallistic = true;
  gravityMod = 1;
//  explodeOnPlayerImpact = true;
//  explodeOnDeath = true;
//  bounceAngle = 135;
//  minStickVelocity = 10;
};

//### Item

datablock ItemData(gc_ToxBowItem)
{
  uiName = "ToxBow";
  iconName = "./icon_toxbow";
  image = gc_ToxBowImage;
  category = Weapon;
  className = Weapon;
  shapeFile = "./toxbow.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";
  canDrop = true;
  gc_zoom = 28;
};

//### Item Image

datablock shapeBaseImageData(gc_ToxBowImage)
{
  shapeFile = "./toxbow.dts";
  emap = true;
  correctMuzzleVector = true;
  className = "WeaponImage";
  item = gc_ToxBowItem;
  ammo = "";
  projectile = gc_ToxBowProjectile;
  projectileType = Projectile;
  melee = false;
  doReaction = false;
  armReady = true;
  doColorShift = true;
  colorShiftColor = "1 1 1 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnNoAmmo[0] = "Reload";

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Reload";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateSequence[2] = "Fire";
  stateSound[2] = gc_ToxBowFireSound;
  stateScript[2] = "onFire";

  stateName[3] = "Reload";
  stateTimeoutValue[3] = "1.8";
  stateTransitionOnTimeout[3] = "Wait";
  stateSequence[3] = "Reload";
  stateSound[3] = gc_ToxBowReloadSound;

  stateName[4] = "Wait";
  stateScript[4] = "Reloaded";
  stateTransitionOnAmmo[4] = "PreReady";

  stateName[5] = "PreReady";
  stateTransitionOnTriggerUp[5] = "Ready";
};

datablock shapeBaseImageData(gc_ToxBowImageScoped : gc_ToxBowImage)
{
  eyeOffset = "0 0.17 -0.415";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.2;
  stateTransitionOnNoAmmo[0] = "Reload";

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;
  stateTransitionOnNoAmmo[1] = "Reload";

  stateName[2] = "Fire";
  stateTransitionOnTimeout[2] = "Reload";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = false;
  stateWaitForTimeout[2] = true;
  stateSequence[2] = "Fire";
  stateSound[2] = gc_ToxBowFireSound;
  stateScript[2] = "onFire";

  stateName[3] = "Reload";
  stateTimeoutValue[3] = "1.8";
  stateTransitionOnTimeout[3] = "Wait";
  stateSequence[3] = "Reload";
  stateSound[3] = gc_ToxBowReloadSound;

  stateName[4] = "Wait";
  stateScript[4] = "Reloaded";
  stateTransitionOnAmmo[4] = "PreReady";

  stateName[5] = "PreReady";
  stateTransitionOnTriggerUp[5] = "Ready";
};

function gc_ToxBowImage::onFire(%this,%obj,%slot)
{
  %spread = 0.002;
  if(vectorLen(%obj.getVelocity()) >= 5 && !isObject(%obj.getObjectMount())) %spread += 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
  %obj.setImageAmmo(0,0);
}
function gc_ToxBowImage::onUnMount(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.client.setControlCameraFov(90); }
function gc_ToxBowImage::Reloaded(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.setImageAmmo(0,1); }

function gc_ToxBowImageScoped::onFire(%this,%obj,%slot)
{
  %spread = 0;
  if(vectorLen(%obj.getVelocity()) >= 5 && !isObject(%obj.getObjectMount())) %spread += 0.001;
  %x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
  %p = new Projectile()
  {
    dataBlock = %this.projectile;
    initialVelocity = MatrixMulVector(MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z),VectorScale(%obj.getMuzzleVector(0),%this.projectile.muzzleVelocity));
    initialPosition = %obj.getMuzzlePoint(0);
    sourceObject = %obj;
    sourceSlot = 0;
    client = %obj.client;
  };
  MissionCleanup.add(%p);
  %obj.setImageAmmo(0,0);
}
function gc_ToxBowImageScoped::onUnMount(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.client.setControlCameraFov(90); }
function gc_ToxBowImageScoped::Reloaded(%this,%obj,%slot) { parent::onUnMount(%this,%obj,%slot); %obj.setImageAmmo(0,1); }

function gc_ToxbowProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
  if(%col.getType() & $TypeMasks::PlayerObjectType)
    if(miniGameCanDamage(%obj,%col) == 1)
    {
      gc_poisoning(%col,40);
    }
  parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}

package gc_ScopesPackage
{
  function Armor::onTrigger(%this,%player,%slot,%val)
  {
      if(isObject(%player.getMountedImage(0)))
      {
        %image = %player.getMountedImage(0);
        if(isObject(%player.getObjectMount()))
        {
          %vehicle = %player.getObjectMount();
          for(%i=0;%i<8;%i++)
          {
            if(%vehicle.getMountedObject(%i) == %player) { %vehicleSlot = %i; break; }
          }
        }
        if(%image.item.gc_zoom $= "") { parent::onTrigger(%this,%player,%slot,%val); return; }
        if((%image.item.image $= %image.getName()) && %slot $= 4 && %val)
        {
          %player.mountImage(%image.item.image @ "Scoped",0);
          %player.client.setControlCameraFov(%image.item.gc_zoom);
          if(%vehicle !$= "") Schedule(100,0,gc_remount,%vehicle,%player,%vehicleSlot);
        }
        if(((%image.item.image @ "Scoped") $= %image.getName()) && %slot $= 4 && %val)
        {
          %player.mountImage(%image.item.image,0);
          %player.client.setControlCameraFov(90);
          if(%vehicle !$= "") Schedule(100,0,gc_remount,%vehicle,%player,%vehicleSlot);
        }
        parent::onTrigger(%this,%player,%slot,%val);
      }
      else
        parent::onTrigger(%this,%player,%slot,%val);
  }
};
activatePackage(gc_ScopesPackage);

AddDamageType("gc_poisoning",'<bitmap:Add-ons/Weapon_ToxBow/CI_poisoning> %1','%2 <bitmap:Add-ons/Weapon_ToxBow/CI_poisoning> %1',0.2,1);

function gc_poisoning(%obj,%duration)
{
  if(!isObject(%obj)) return 0;
  if(%duration < 1) return 0;
  if(%obj.getDamageLevel() < 90) %obj.damage(%obj,%obj.getPosition(),5,$DamageType::gc_poisoning);
  %duration--;
  %obj.gc_poisoning = schedule(1500,0,gc_poisoning,%obj,%duration);
  %obj.setDamageFlash(%obj.getDamageFlash()+0.15);
  %obj.emote(gc_poisoningEffectImage);
}
