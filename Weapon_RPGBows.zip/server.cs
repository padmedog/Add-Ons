AddDamageType("rpgbowarrowDirect",   '<bitmap:add-ons/Weapon_RPGBows/CI_normbowdie> %1',    '%2 <bitmap:add-ons/Weapon_RPGBows/CI_normbowdie> %1',0.5,1);

%error = ForceRequiredAddOn("Weapon_Bow");

if(%error == $Error::AddOn_Disabled)
{
   BowItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_RPGBows - required add-on Weapon_Bow not found");
}
else
{
	exec("./weapon_ElitistBow.cs");
	exec("./weapon_SBBow.cs");
	exec("./weapon_LSBow.cs");
	exec("./weapon_LBBow.cs");
	exec("./weapon_SSBow.cs");
}