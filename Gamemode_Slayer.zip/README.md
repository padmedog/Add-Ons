﻿Gamemode_Slayer
===============

Slayer is a game mode for [Blockland][1]. Create teams and battle to the death or use one of Slayer's many game modes to create a custom game.

[Download Slayer][2]

[Modification Discussion][3]

	+-------------------------------------------+
	|  ___   _     _____   __  __  ____   ____  |
	| | __| | |   | /_\ |  \ \/ / | ___| | /\ | |
	| |__ | | |_  |  _  |   \  /  | __|  | \/ / |
	| |___| |___| |_| |_|   |__|  |____| |_| \\ |
	|  Greek2me              Blockland ID 11902 |
	+-------------------------------------------+

File Hierarchy
--------------

	Gamemode_Slayer
	├─client
	│ ├─dependencies
	│ ├─gui
	│ ├─modules
	│ ├─resources
	│ ├─support
	├─common
	│ ├─dependencies
	│ ├─modules
	│ ├─resources
	│ ├─support
	├─server
	  ├─compatibility
	  ├─dependencies
	  ├─gamemodes
	  ├─modules
	  ├─resources
	  ├─support

Class Hierarchy
---------------
	Slayer
	├─Slayer_MinigameHandlerSG
	│ ├─Slayer_MinigameSO
	│ │ ├─Slayer_TeamHandlerSG
	│ │ │ ├─Slayer_TeamSO
	├─Slayer_PrefHandlerSG
	│ ├─Slayer_PrefSO
	├─Slayer_TeamPrefHandlerSG
	  ├─Slayer_TeamPrefSO
	
	(this hierarchy is very incomplete)


[1]: http://blockland.us
[2]: http://mods.greek2me.us/storage/Gamemode_Slayer.zip
[3]: http://forum.blockland.us/index.php?topic=170322.0