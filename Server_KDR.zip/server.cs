if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	RTB_registerPref("Enabled","Kill Death Ratios","$Pref::KDR::Enabled","bool","Server_KDR",1,0,0);
	RTB_registerPref("Save","Kill Death Ratios","$Pref::KDR::Save","bool","Server_KDR",0,0,0);
}
else
{
	$Pref::KDR::Enabled = true; //Toggles the mod
	$Pref::KDR::Save = true; //Toggles saving
}

exec("./ratios.cs");

package KDRVars
{
	function VCE_initServer()
	{
		Parent::VCE_initServer();
		registerSpecialVar(GameConnection,"kills","$Pref::KDR::Save ? %this.kills+0 : %this.kills2+0");
		registerSpecialVar(GameConnection,"deaths","$Pref::KDR::Save ? %this.deaths+0 : %this.deaths2+0");
		registerSpecialVar(GameConnection,"kdr","$Pref::KDR::Save ? mFloatLenth(%this.kills/%this.deaths,2) : mFloatLength(%this.kills2/%this.deaths2,2)");
	}
};
activatePackage(KDRVars);