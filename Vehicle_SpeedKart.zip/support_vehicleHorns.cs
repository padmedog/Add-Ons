//How fast you can beep (please don't make it too low, beeping is fun)
$Support::VehicleHonkTime = 200;
//1,000 = 1 second
//100 = 0.1 second

//exec("add-ons/vehicle_speedKart/support_vehicleHorns.cs");
package vehicleHornSupportPackage
{
	function armor::onTrigger(%db,%obj,%slot,%val)
	{
		if(%obj.getClassName()$="Player")
		{
			if(%slot == 0 && %obj.isMounted())
			{
				if(strStr(strLwr(%obj.getObjectMount().GetDatablock().getName()), "speedkart") != -1)
				{ 
					if(%val)
					{
						if(getSimTime() < (%obj.lastHornClick + $Support::VehicleHonkTime))
						{
							return;
						}
						%obj.playHornNoise();
						return;
					}
				}
			}
		}
		return Parent::onTrigger(%db,%obj,%slot,%val);
	}
};
ActivatePackage(vehicleHornSupportPackage);

function Player::playHornNoise(%player)
{
	%vehicle = %player.getObjectMount();
	
	if(!isObject(%vehicle))
	{
		return;
	}

	%vehicleDatablock = %vehicle.getDatablock();
	
	%mountedObj = %vehicle.getMountNodeObject(0);
	
	if(%mountedObj != %player) 
	{
		return;
	}
	if(isObject(%vehicleDatablock.speedCartHornSound))
	{
		%player.playSound(%vehicleDatablock.speedCartHornSound);	
	}
	else{
		//Otherwise play a default sound.
		if(isObject(SpeedKartHornSound))
		{
			%player.playSound(SpeedKartHornSound);
		}	
	}
	
	%player.lastHornClick = getSimTime();
}