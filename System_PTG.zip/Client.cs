//           ___                     ___     
//  	    /  /\        ___        /  /\    
//         /  /  \      /  /\      /  / /_   
//	  /  / /\ \    /  / /     /  / / /\  
//	 /  / /-/ /   /  / /   __/  / /_/  \ 
//	/__/ / / /   /  /  \  / /__/ /__\/\ \
//     _\  \ \/ /   /__/ /\ \/  \  \ \ /__/ /
//  __/	 \  \  /\   \__\/  \ \   \  \ \  / / 
// /	  \  \ \ \__  /  \  \ \   \  \ \/ /\  
///	   \  \ \   \/    \__\/    \  \  /  \_
//	    \__\/    \	            \__\/     \
//	Made by: [GSF]Ghost (ID: 3195)

////////////////////////////////////////////////////////////////////////////////

exec("Add-Ons/System_PTG/GUI/PTG_MainMenu_GUI.gui"); 
exec("Add-Ons/System_PTG/GUI/PTG_TempMainMenu_GUI.gui");
exec("Add-Ons/System_PTG/GUI/PTG_BiomeOptions_GUI.gui");
exec("Add-Ons/System_PTG/GUI/PTG_ColPriBri_GUI.gui");
exec("Add-Ons/System_PTG/GUI/PTG_Preview_GUI.gui");
exec("Add-Ons/System_PTG/GUI/PTG_MainMenuHelp_GUI.gui");
exec("Add-Ons/System_PTG/GUI/PTG_BiomesHelp_GUI.gui");
exec("Add-Ons/System_PTG/GUI/PTG_CustomHV_GUI.gui");
exec("Add-Ons/System_PTG/GUI/GUIScripts.cs");

////////////////////////////////////////////////////////////////////////////////

if (!$PTGBind)
{
	$remapDivision[$remapCount] = "Procedural Terrain Generator";
	$remapName[$remapCount] = "Toggle PTG GUI";
	$remapCmd[$remapCount] = "Toggle_PTG_MainMenu_GUI";
	$remapCount++;
	$PTGBind=1;
}
function Toggle_PTG_MainMenu_GUI(%toggle)
{
	if(%toggle)
	{
		if(PTG_MainMenu_GUI.isAwake() || PTG_TempMainMenu_GUI.isAwake())
		{
			canvas.popDialog(PTG_MainMenu_GUI);
			canvas.popDialog(PTG_TempMainMenu_GUI);
		}
		else
		{
			if($Start==1)
				canvas.pushDialog(PTG_TempMainMenu_GUI);
			else
				canvas.pushDialog(PTG_MainMenu_GUI);
		}
	}
}
function ClientCmdCl_RestrictionFail()
{
	canvas.popDialog(PTG_MainMenu_GUI);
	canvas.popDialog(PTG_TempMainMenu_GUI);
	canvas.popDialog(PTG_BiomeOptions_GUI);
	canvas.popDialog(PTG_ColPriBri_GUI);
	canvas.popDialog(PTG_Preview_GUI);
	canvas.popDialog(PTG_MainMenuHelp_GUI);
	canvas.popDialog(PTG_BiomesHelp_GUI);
	canvas.popDialog(PTG_CustomHV_GUI);
}

////////////////////////////////////////////////////////////////////////////////

function PTG_MainMenu_GUI::onWake()
{
	commandToServer('PTG_GUI_RestrictionCheck');
}
function PTG_TempMainMenu_GUI::onWake()
{
	commandToServer('PTG_GUI_RestrictionCheck');
}
function PTG_BiomeOptions_GUI::onWake()
{
	commandToServer('PTG_GUI_RestrictionCheck');
}
function PTG_Preview_GUI::onWake()
{
	commandToServer('PTG_GUI_RestrictionCheck');	
}
function PTG_CustomHV_GUI::onWake()
{
	commandToServer('PTG_GUI_RestrictionCheck');	
}
function PTG_ColPriBri_GUI::onWake()
{
	commandToServer('PTG_GUI_RestrictionCheck');

	BrickList.clear();
	BrickList.addRow(-1,"(NO BRICK)");

	//if($Server::Lan) 
	//	%dbg = "datablockGroup";
	//else
	//	%dbg = "serverconnection"; -> Will be implemented when Super Admin access is added

	for(%i=0; %i<datablockGroup.getCount();%i++)
	{
		%obj = datablockGroup.getObject(%i);

		if(%obj.getClassName() $= "fxDTSBrickData" && %obj.uiName !$= "" && (%obj.category $= "Special" || %obj.category $= "rounds" || %obj.category $= "Food"))
			BrickList.addRow(%i,%obj.uiName);
	}
	PrintList.clear();

	for(%i=0;%i<getNumPrintTextures();%i++)
	{
		if(strStr(getPrintTexture(%i),"Letters")==-1)
		{
			%p = filebase(getPrintTexture(%i));
			PrintList.addRow(%i,%p);
		}
	}

	for(%CC=0;%CC<64;%CC++)
	{
		%CBc=getColorIDtable(%CC);
		%CBc=mFloor(getWord(%CBc,0)*255) @ " " @ mFloor(getWord(%CBc,1)*255) @ " " @ mFloor(getWord(%CBc,2)*255) @ " " @ mFloor(getWord(%CBc,3)*255);

		if(%CBc !$= "255 0 255 0")
		{
			eval("Color" @ %CC @ ".color=" @ "\"" @ %CBc @ "\"" @ ";");
			eval("ColorButton" @ %CC @ ".enabled=1;");
		}
		else
			eval("ColorButton" @ %CC @ ".enabled=0;");
	}

	////////////////////////////////////////

	$ColNum=0;
	ColorPreview.setColor="255 0 0 255";
	PrintPreviewCol.setColor="255 0 0 255";
	PrintPreview.setBitmap("Add-Ons/System_PTG/Bricks_Prints/emptyprint.png");
	BrickPreview.setColor="255 0 0 255";
	BrickPreview.setBitmap("base/client/ui/brickicons/Unknown");
}