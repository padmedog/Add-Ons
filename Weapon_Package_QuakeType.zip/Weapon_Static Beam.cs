//gun.cs

datablock AudioProfile(staticBeamChargeSound)
{
   filename    = "./staticchargesound.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(staticBeamFireSound)
{
   filename    = "./static_beam.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(staticBeamFireParticle)
{
    dragCoefficient      = 0;
    gravityCoefficient   = 0;
    inheritedVelFactor   = 0;
    constantAcceleration = 0.0;
    lifetimeMS           = 150;
    lifetimeVarianceMS   = 0;
    textureName          = "base/data/particles/star1";
    spinSpeed        = 9000.0;
    spinRandomMin        = -5000.0;
    spinRandomMax        = 5000.0;

    colors[0]     = "1 1 1 0.02";
    colors[1]     = "0.8 0.8 1 0.07";
    colors[2]     = "0.75 0.75 1 0.05";
    colors[3]     = "0.5 0.5 0.75 0.0";

    sizes[0]      = 0.25;
   sizes[1]      = 2.25;
    sizes[2]      = 0.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;

    useInvAlpha = false;
};
datablock ParticleEmitterData(staticBeamFireEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 190.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 1;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;

   particles = "staticBeamFireParticle";
};

datablock ParticleData(staticBeamFlashParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 35;
	textureName          = "./blastCorona1";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
    colors[0]     = "1 1 1 1";
    colors[1]     = "0.8 0.8 1 0.3";
    colors[2]     = "0.75 0.75 1 0.2";
    colors[3]     = "0.5 0.5 0.75 0.0";

    sizes[0]      = 6.15;
   sizes[1]      = 7.25;
    sizes[2]      = 6.10;
    sizes[3]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.5;
   times[3] = 1.0;


	useInvAlpha = false;
};
datablock ParticleEmitterData(staticBeamFlashEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "staticBeamFlashParticle";

   useEmitterColors = false;
};

datablock ParticleData(staticBeamExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 150;
	lifetimeVarianceMS   = 35;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 1 1 0.0";
	colors[1]     = "0.75 0.75 1 0.08";
	colors[2]     = "0.7 0.7 1 0.0";
	sizes[0]      = 2;
	sizes[1]      = 3;
	sizes[2]      = 3;
   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 1;

	useInvAlpha = false;
};
datablock ParticleEmitterData(staticBeamExplosionRingEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 8;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "staticBeamExplosionRingParticle";

   useEmitterColors = false;
};


datablock ExplosionData(staticBeamExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 150;

   particleEmitter = staticBeamFlashEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = staticBeamExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";

   impulseRadius = 2;
   impulseForce = 1000;
};

AddDamageType("staticBeam",   '<bitmap:add-ons/Weapon_Package_QuakeType/ci_staticbeam> %1',    '%2 <bitmap:add-ons/Weapon_Package_QuakeType/ci_staticbeam> %1',0.2,1);

datablock ProjectileData(RaycastModelBeamProjectile : gunProjectile)
{
   projectileShapeName = "./raycastline_electricity.dts";
   explosion           = staticBeamExplosion;
};

function drawRaylinestaticBeam(%pos1, %pos2)
{
	//should be the dimensions of the model in torque units
	%modelwidth = 0.2 +getRandom(1,10)*0.01;
	%modeldepth = 0.2 +getRandom(1,10)*0.01;
	%modelheight = 1.3 +getRandom(1,10)*0.1;

	//find the point halfway between the two points, this will be our position
	%point = vectorAdd(vectorScale(vectorSub(%pos2, %pos1), 0.5), %pos1);
	
	//rotation
	%xRot = 0;
	
	//mAtan(z/len(x and y))
	%yRot = 90 - mRadToDeg(mAtan(getWord(%pos2, 2) - getWord(%pos1, 2), vectorLen(vectorSub(getWords(%pos2, 0, 1), getWords(%pos1, 0, 1)))));
	//%yRot = 90;
	
	//mAtan(x/y)
	%zRot = mRadToDeg(mAtan(getWord(%pos2, 1) - getWord(%pos1, 1), getWord(%pos2, 0) - getWord(%pos1, 0)));
	
	%rot = eulerToAxis(%xRot SPC %yRot SPC %zRot);
	
	//scaling
	%width = 0.3 / %modelWidth;
	%depth = 0.3 / %modeldepth;
	%height = vectorLen(vectorSub(%pos2, %pos1)) / %modelheight;
	
	
	//create it
	%shape = new TSStatic() {
		shapeName = "add-ons/weapon_package_quaketype/raycastline_electricity.dts";
	};
	
	%shape.setTransform(%point SPC %rot);
	%shape.setScale(%width SPC %depth SPC %height);
	
	$lastShape = %shape;
	
	return %shape;
}


//////////
// item //
//////////
datablock ItemData(staticBeamItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./plasma_darts.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Static Beam";
	iconName = "./staticbeam";
	doColorShift = true;
	colorShiftColor = "0.7 0.7 0.75 1.000";

	 // Dynamic properties defined by the scripts
	image = staticBeamImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(staticBeamImage)
{
   // Basic Item properties
	shapeFile = "./plasma_darts.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = staticBeamItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 20; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = raycastModelBeamProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 16; //10
   raycastDirectDamageType = $DamageType::staticBeam;
   raycastSpreadAmt = 0.0000; //varies
   raycastSpreadCount = 1;
   //raycastSparkProjectile = serviceRifleSparkProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSequence[0]	= "Fire";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Prefire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnTimeout[1]     = "Ready";
	stateWaitForTimeout[1]			= false;
	stateTimeoutValue[1]            = 0.9;
	stateSequence[1]	= "idle";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.066;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= staticBeamFireEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= staticBeamFireSound;

	stateName[3] = "Smoke";
	stateEmitter[3]					= quakeShotgunSmokeEmitter;
	stateEmitterTime[3]				= 0.02;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.38;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerDown[4]     = "Fire";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";

	stateName[5] = "Prefire";
	stateSequence[5]	= "fire";
	stateTimeoutValue[5]            = 0.18;
	stateScript[5]                  = "onBoltback";
	stateTransitionOnTimeout[5]     = "Fire";
	stateTransitionOnTriggerUp[5]     = "Ready";
	stateSound[5]					= staticBeamChargeSound;
};

function staticBeamImage::onBoltback(%this,%obj,%slot)
{
	%obj.playThread(2, shiftleft);	
	%obj.playThread(0, plant);	
}

function staticBeamImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(QuakeRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;	
	%obj.playThread(0, plant);	
	
	Parent::onFire(%this,%obj,%slot);

	////////////////////////////////////////////////////
	%range = %this.raycastWeaponRange;

	%start = %obj.getMuzzlePoint(%slot);
	%end = vectorAdd(%start, vectorScale(%obj.getMuzzleVector(%slot), %range));

	%typemasks = $Typemasks::PlayerObjectType | $Typemasks::FxBrickObjectType | $Typemasks::TerrainObjectType | 
		$TypeMasks::StaticObjectType | $TypeMasks::VehicleObjectType;

	%ray = containerRaycast(%start, %end, %typemasks, %obj);

	if(isObject(%hit = firstWord(%ray)))
	{
		%line = drawRaylinestaticBeam(%start, getWords(%ray, 1, 3));
	}else{
		%line = drawRaylinestaticBeam(%start, %end);
	}
	%line.schedule(66, delete);
}
