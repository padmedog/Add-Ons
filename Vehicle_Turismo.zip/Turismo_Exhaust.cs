datablock ParticleData(TurismoExhaustParticle)
{
   textureName          = "base/data/particles/cloud";
   dragCoefficient      = 0.0;
   windCoefficient      = 0.5;
   gravityCoefficient   = -0.5; 
   inheritedVelFactor   = 0.2;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 0;
   useInvAlpha = true;
   spinRandomMin = 0.0;
   spinRandomMax = 0.0;

   colors[0]     = "0.7 0.5 0.2 0.7";
   colors[1]     = "0.7 0.7 0.7 0.07";
   colors[2]     = "0.75 0.75 0.75 0.0";

   sizes[0]      = 0.20;
   sizes[1]      = 0.25;
   sizes[2]      = 3;

   times[0]      = 0;
   times[1]      = 0.1;
   times[2]      = 1;
};

datablock ParticleEmitterData(TurismoExhaustEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionOffset   = 0.1;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TurismoExhaustParticle";
};

datablock ParticleData(TurismoExhaustTireParticle)
{
   dragCoefficient      = 3;
   windCoefficient     = 0;
   gravityCoefficient   = 1;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 900;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/chunk";
   colors[0]     = "0.1 0.1 0.1 1";
   colors[1]     = "0.1 0.1 0.1 0";
   sizes[0]      = 0.4;
   sizes[1]      = 0.05;
};

datablock ParticleEmitterData(TurismoExhaustTireEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.0;
   ejectionOffset   = 0.1;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TurismoExhaustTireParticle";
};

datablock ShapeBaseImageData(TurismoExhaustImage1)
{
   shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 3;
   rotation = "1 0 0 -90";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateEmitter[1]					= TurismoExhaustEmitter;
	stateEmitterTime[1]				= 10000;

};
datablock ShapeBaseImageData(TurismoExhaustImage2)
{
   	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 4;
   	rotation = "1 0 0 -90";

	stateName[0]					= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]					= "FireA";
	stateEmitter[1]					= TurismoExhaustEmitter;
	stateEmitterTime[1]				= 10000;

};

function TurismoSmokeCheck(%obj)
{
  %obj.mountImage(TurismoExhaustImage1,2);
  %obj.mountImage(TurismoExhaustImage2,3);
}