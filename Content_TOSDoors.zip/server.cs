%error = ForceRequiredAddOn("JVS_Content");
%error2 = ForceRequiredAddOn("sound_STTOS");

if(%error == $Error::AddOn_NotFound)
{
	error("Content_TOSDoors: JVS_Content is missing and is required by this Add-On.");
}
else if(%error2 == $Error::AddOn_NotFound)
{
	error("Content_TOSDoors: sounds_STTOS is missing and is required by this Add-On.");
}
else
{
	ContentTypesSO.addContentType("Add-Ons/Content_TOSDoors/types/TOS1x4Sing.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_TOSDoors/types/TOS1x4Double.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_TOSDoors/types/TOS1x6Double.cs");
	ContentTypesSO.addContentType("Add-Ons/Content_TOSDoors/types/TOS1x3Single.cs");
}