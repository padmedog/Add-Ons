datablock AudioProfile(SpeederLaserFireSound)
{
   filename    = "./Laser_Fire.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock AudioProfile(SpeederLaserHitSound)
{
   filename    = "./Laser_Hit.wav";
   description = AudioDefault3d;
   preload = true;
};

//Explosion

datablock ExplosionData(SpeederLaserExplosion)
{
   //explosionShape = "";
   explosionShape = "Add-Ons/Weapon_Rocket_Launcher/explosionSphere1.dts";
	 soundProfile = SpeederLaserHitSound;

   lifeTimeMS = 150;

   //particleEmitter = SpeederLaserExplosionEmitter;
   //particleDensity = 9;
   //particleRadius = 0.5;

   faceViewer     = true;
   explosionScale = "0.5 0.5 0.5";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "3.0 8.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 15;
   lightStartColor = "1.0 0.6 0.2 1";
   lightEndColor = "0 0 0 0";

   damageRadius = 10;
   radiusDamage = 25;

   impulseRadius = 4;
   impulseForce = 4000;
};

//Projectile

AddDamageType("Missile",   '<bitmap:add-ons/vehicle_Snow_Speeder/CI_SnowSpeeder> %1',    '%2 <bitmap:add-ons/vehicle_Snow_Speeder/CI_SnowSpeeder> %1',0.2,1);

datablock ProjectileData(SpeederLaserProjectile)
{
   projectileShapeName = "./Laser.dts";
   directDamage        = 50;
   directDamageType    = $DamageType::Missile;
   radiusDamageType    = $DamageType::Missile;

   brickExplosionRadius = 6;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground

   //sound = LoopSound;

   impactImpulse	     = 750;
   verticalImpulse	  = 750;
   explosion           = SpeederLaserExplosion;
   //particleEmitter     = SpeederLaserTrailEmitter;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = true;  

   muzzleVelocity      = 150;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 8000;
   fadeDelay           = 7500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = True;
   lightRadius = 15.0;
   lightColor  = "1 0 0 1";

   uiName = "Snow Speeder Projectile";
};
