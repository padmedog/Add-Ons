//we need the tier 1 package for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Rocket_Launcher");
%error2 = ForceRequiredAddOn("Weapon_Package_Tier1");

if(%error2 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_Package_Explosive2 - this is enabled but Weapon_Package_Tier1 isn't here, forcing anyway...");
	exec("add-ons/weapon_package_tier1/server.cs");
}
if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Package_Explosive2 - this is enabled but Weapon_Rocket_Launcher isn't here, forcing anyway...");
	exec("add-ons/weapon_rocket_launcher/server.cs");

   exec("./Weapon_RPG.cs");  
   exec("./Weapon_Grenade_Launcher.cs");  
   exec("./PrjEmit.cs");  
   exec("./Weapon_Calibre_Cannon.cs");  
   //exec("./Weapon_Mortar.cs");  
}
else
{
   exec("./Weapon_RPG.cs");  
   exec("./Weapon_Grenade_Launcher.cs");  
   exec("./PrjEmit.cs");  
   exec("./Weapon_Calibre_Cannon.cs");  
   //exec("./Weapon_Mortar.cs");  
}

