
//bullet trail effects
datablock ParticleData(PayloadLauncherTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 2000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 1.0 0.0 0.4";
	colors[1]     = "1.0 0.2 0.0 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 0.85;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.6;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.3;
   times[3] = 2.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(PayloadLauncherTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PayloadLauncherTrailParticle";

   uiName = "PayloadLauncher Trail";
};

datablock ParticleData(PayloadLauncherSmokeTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.05;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 100;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "0.7 0.45 0.2 0.9";
	colors[1]     = "0.1 0.1 0.1 0.6";
   colors[2]     = "0.1 0.1 0.1 0.2";
   colors[3]     = "0.1 0.1 0.1 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 0.85;
   sizes[2]      = 1;
 	sizes[3]      = 0.75;

   times[0] = 0.0;
   times[1] = 0.25;
   times[2] = 0.4;
   times[3] = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(PayloadLauncherSmokeTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PayloadLauncherSmokeTrailParticle";

   uiName = "PayloadLauncher Smoke Trail";
};


datablock ParticleData(PayloadLauncherExplosionParticle)
{
	dragCoefficient      = 10;
	gravityCoefficient   = -0.25;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 5000;
	lifetimeVarianceMS   = 2000;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.7 0.25 0.02 1";
	colors[1]     = "0.1 0.1 0.1 0.75";
	colors[2]     = "0.1 0.1 0.1 0.0"; 
	sizes[0]      = 5;
	sizes[1]      = 7.5;
	sizes[2]      = 10;
    times[0]      = 0.0;
    times[1]      = 0.05;
	times[2]      = 1.0;

	useInvAlpha = true;
};
datablock ParticleEmitterData(PayloadLauncherExplosionEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 75;
   velocityVariance = 25.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PayloadLauncherExplosionParticle";

   uiName = "PayloadLauncher Explosion Smoke";
   emitterNode = TenthEmitterNode;
};

datablock ParticleData(PayloadLauncherExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 10;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 70.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 0.91 0.59 0.9";
	colors[1]     = "0.7 0.25 0.02 0.9";
	sizes[0]      = 10;
	sizes[1]      = 50;
	times[1]      = 0.0;
	times[2]      = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(PayloadLauncherExplosionRingEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 10.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PayloadLauncherExplosionRingParticle";

   uiName = "PayloadLauncher Explosion Flash";
};

datablock DebrisData(PayloadLauncherDebris)
{
   emitters = "PayloadLauncherSmokeTrailEmitter";

	shapeFile = "base/data/shapes/empty.dts";
	lifetime = 2.25;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 0.01;
	friction = 0.2;
	numBounces = 2;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};


datablock ExplosionData(PayloadLauncherExplosion)
{
   //explosionShape = "";
   explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
	soundProfile = PayloadLauncherExplodeSound;

   lifeTimeMS = 300;

   particleEmitter = PayloadLauncherExplosionRingEmitter;
   particleDensity = 10;
   particleRadius = 6; //0.2

   emitter[0] = PayloadLauncherExplosionEmitter;
   
   debris = PayloadLauncherDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 90; //90 
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 3;
   debrisNumVariance = 2;
   debrisVelocity = 35;
   debrisVelocityVariance = 25;
   
   faceViewer     = true;
   explosionScale = "2 2 2";

   shakeCamera = true;
   camShakeFreq = "3.0 40.0 3.0"; //10.0 11.0 10.0
   camShakeAmp = "15.0 2.0 15.0";
   camShakeDuration = 2;
   camShakeRadius = 12.0;
   camShakeFallOff = 1.0;

   // Dynamic light
   lightStartRadius = 40;
   lightEndRadius = 5;
   lightStartColor = "1 0.5 0.2 1";
   lightEndColor = "0 0 0 0";

   damageRadius = 8;
   radiusDamage = 350;

   impulseRadius = 10;
   impulseForce = 5000;
};

AddDamageType("PayloadLauncherDirect",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_PayloadLauncher> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_PayloadLauncher> %1',1,1);
AddDamageType("PayloadLauncherRadius",   '<bitmap:add-ons/Weapon_Frogs_Weaponry/CI_PayloadLauncherRadius> %1',    '%2 <bitmap:add-ons/Weapon_Frogs_Weaponry/CI_PayloadLauncherRadius> %1',1,0);
datablock ProjectileData(PayloadProjectile)
{
   projectileShapeName = "./Payload.dts";
   directDamage        = 30;
   directDamageType = $DamageType::PayloadLauncherDirect;
   radiusDamageType = $DamageType::PayloadLauncherRadius;
   impactImpulse	   = 4000;
   verticalImpulse	   = 4000;
   explosion           = PayloadLauncherExplosion;
   particleEmitter     = PayloadLauncherTrailEmitter;

   brickExplosionRadius = 6;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 60; //30             
   brickExplosionMaxVolume = 60;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 85;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = PayloadLauncherLoopSound;

   muzzleVelocity      = 65;
   velInheritFactor    = 1.0;

   armingDelay         = 00;
   lifetime            = 8000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod          = 1.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "Payload";
};

//////////
// item //
//////////
datablock ItemData(PayloadLauncherItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./PayloadLauncher.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Payload Launcher";
	iconName = "./icon_PayloadLauncher";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = PayloadLauncherImage;
	canDrop = true;
	
	maxAmmo = 1;
	canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(PayloadLauncherImage)
{
   // Basic Item properties
   shapeFile = "./PayloadLauncher.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = PayloadLauncherItem;
   ammo = " ";
   projectile = PayloadProjectile;
   projectileType = Projectile;

     //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = PayloadLauncherItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 1.5; //0.15
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "ReLoadCheckA";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
	stateTransitionOnNoAmmo[1]	= "ReloadStart";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.025;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= FWRLFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= PayloadLauncherFireSound;
	stateSequence[2]        = "lock";

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= FWRLSmokeEmitter;
	stateEmitterTime[3]		= 0.10;
	stateEmitterNode[3]		= "muzzleNode";
	stateTransitionOnTriggerUp[3] = "Wait";

	stateName[4]			= "Wait";
        stateSequence[4]		= "Flap";
        stateTimeoutValue[4]		= 0.2;
	stateTransitionOnTimeout[4]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "onLoadCheck";
	stateTimeoutValue[5]			= 0.01;
	stateTransitionOnTimeout[5]		= "LoadCheckB";
	
	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNoAmmo[6]		= "ReloadWait";
	
	stateName[7]				= "ReloadWait";
	stateTimeoutValue[7]			= 0.3;
	stateScript[7]				= "";
	stateTransitionOnTimeout[7]		= "ReloadStart";
	stateWaitForTimeout[7]			= true;
	
	stateName[8]				= "ReloadStart";
	stateTimeoutValue[8]			= 3.0;
	stateScript[8]				= "onReloadStart";
	stateTransitionOnTimeout[8]		= "Reloaded";
	stateWaitForTimeout[8]			= true;
	
	stateName[9]				= "Reloaded";
	stateTimeoutValue[9]			= 0.3;
	stateScript[9]				= "onReloaded";
        stateTransitionOnTimeout[9]		= "ReLoadCheckA";
		
    stateName[10]               = "ReadyWeapon";
	stateTimeoutValue[10]       = 0.2;
	stateScript[10]             = "OnReadyWeapon";
	stateSequence[10]           = "Ready";
	stateTransitionOnTimeout[10]= "LoadCheckA";
	
	stateName[11]				= "ReLoadCheckA";
	stateScript[11]				= "onLoadCheck";
	stateTimeoutValue[11]			= 0.01;
	stateTransitionOnTimeout[11]		= "ReLoadCheckB";
	
	stateName[12]				= "ReLoadCheckB";
	stateTransitionOnAmmo[12]		= "ReadyWeapon";
	stateTransitionOnNoAmmo[12]		= "ReloadWait";
};

function PayloadLauncherImage::onReady(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Payloads <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Payload"] @ "", 1, 2, 3, 4); 
}

function PayloadLauncherImage::onFire(%this,%obj,%slot)
{
	%projectile = PayloadProjectile;
        %spread = 0.0001;
	%shellcount = 1;

	%obj.playThread(2, jump);
	%shellcount = 1;
	%obj.toolAmmo[%obj.currTool]--;
	%obj.AmmoSpent[%obj.currTool]++;

	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Payloads <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Payload"] @ "", 4, 2, 3, 4); 

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}
function PayloadLauncherImage::onReloadStart(%this,%obj,%slot)
{
commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Payloads <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Payload"] @ "", 1, 2, 3, 4); 
    if(%obj.client.quantity["Payload"] >= 1)
	{
	%obj.playThread(2, shiftUp);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
	}
}

function PayloadLauncherImage::onReloaded(%this,%obj,%slot)
{
    if(%obj.client.quantity["Payload"] >= %this.item.maxAmmo)
	{
	
        %obj.playThread(2, plant);
        if(%obj.client.quantity["Payload"] > %this.item.maxAmmo)
	{
		%obj.client.quantity["Payload"] -= %obj.AmmoSpent[%obj.currTool];
		%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
		%obj.AmmoSpent[%obj.currTool] = 0;
		serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
                %obj.setImageAmmo(%slot,1);
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Payloads <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Payload"] @ "", 4, 2, 3, 4); 
		return;
	}

        if(%obj.client.quantity["Payload"] <= %this.item.maxAmmo)
	{
		%obj.client.exchangebullets = %obj.client.quantity["Payload"];
		%obj.toolAmmo[%obj.currTool] = %obj.client.exchangebullets;
		%obj.setImageAmmo(%slot,1);
                serverPlay3D(Block_PlantBrick_Sound,%obj.getPosition());
		%obj.client.quantity["Payload"] = 0; // -= 1
            		commandToClient(%obj.client,'bottomPrint',"<just:right><font:impact:24><color:fff000>Payloads <font:impact:34>\c6" @ %obj.toolAmmo[%obj.currTool] @ " / " @ %obj.client.quantity["Payload"] @ "", 4, 2, 3, 4); 
		return;
	}
}
}

function PayloadLauncherImage::onReadyWeapon(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
            serverPlay3D(block_MoveBrick_Sound,%obj.getPosition());
}

function PayloadLauncherImage::onMount(%this,%obj,%slot)
{
   %obj.pushDatablock(SlowedArmor.getID());
}

function PayloadLauncherImage::onUnMount(%this,%obj,%slot)
{
	%obj.popDatablock(SlowedArmor.getID());
}

//statescript onBounce