datablock TSShapeConstructor(MiniSpeedBoatDts)
{
	baseShape  = "./MiniSpeedBoat.dts";
	sequence0  = "./Min_root.dsq root";

	sequence1  = "./Min_root.dsq run";
	sequence2  = "./Min_root.dsq walk";
	sequence3  = "./Min_root.dsq back";
	sequence4  = "./Min_root.dsq side";

	sequence5  = "./Min_root.dsq crouch";
	sequence6  = "./Min_root.dsq crouchRun";
	sequence7  = "./Min_root.dsq crouchBack";
	sequence8  = "./Min_root.dsq crouchSide";

	sequence9  = "./Min_root.dsq look";
	sequence10 = "./Min_root.dsq headside";
	sequence11 = "./Min_root.dsq headUp";

	sequence12 = "./Min_root.dsq jump";
	sequence13 = "./Min_root.dsq standjump";
	sequence14 = "./Min_root.dsq fall";
	sequence15 = "./Min_root.dsq land";

	sequence16 = "./Min_root.dsq armAttack";
	sequence17 = "./Min_root.dsq armReadyLeft";
	sequence18 = "./Min_root.dsq armReadyRight";
	sequence19 = "./Min_root.dsq armReadyBoth";
	sequence20 = "./Min_root.dsq spearready";  
	sequence21 = "./Min_root.dsq spearThrow";

	sequence22 = "./Min_root.dsq talk";  

	sequence23 = "./Min_root.dsq death1"; 
	
	sequence24 = "./Min_root.dsq shiftUp";
	sequence25 = "./Min_root.dsq shiftDown";
	sequence26 = "./Min_root.dsq shiftAway";
	sequence27 = "./Min_root.dsq shiftTo";
	sequence28 = "./Min_root.dsq shiftLeft";
	sequence29 = "./Min_root.dsq shiftRight";
	sequence30 = "./Min_root.dsq rotCW";
	sequence31 = "./Min_root.dsq rotCCW";

	sequence32 = "./Min_root.dsq undo";
	sequence33 = "./Min_root.dsq plant";

	sequence34 = "./Min_root.dsq sit";

	sequence35 = "./Min_root.dsq wrench";

   sequence36 = "./Min_root.dsq activate";
   sequence37 = "./Min_root.dsq activate2";

   sequence38 = "./Min_root.dsq leftrecoil";
};    

datablock ParticleEmitterData(MiniSpeedBoatFoamEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 80;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "PlayerFoamParticle";

   useEmitterColors = true;

   uiName = "";
};

datablock PlayerData(MiniSpeedBoatArmor : PlayerStandardArmor)
{
	cameraVerticalOffset = 3;
	shapefile = "./MiniSpeedBoat.dts";
	canJet = 0;
	mass = 50;
   drag = 0.017;
   density = 0.6;
   runSurfaceAngle = 1;
   jumpSurfaceAngle = 1;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxForwardCrouchSpeed = 0;
   maxSideSpeed = 0;
   maxSideCrouchSpeed = 0;
   maxStepHeight = 0;
   maxUnderwaterSideSpeed = 0;
    maxUnderwaterForwardSpeed = 80;
    maxUnderwaterBackwardSpeed = 2;

	uiName = "MiniSpeedBoat";
	showEnergyBar = false;
	
   jumpForce = 0;
   jumpEnergyDrain = 10000;
   minJumpEnergy = 10000;
   jumpDelay = 127;
   minJumpSpeed = 0;
   maxJumpSpeed = 0;
	
	rideable = true;
	canRide = false;
	paintable = true;
	
   boundingBox			= vectorScale("4 4 1", 4); 
   crouchBoundingBox	= vectorScale("4 4 1", 4);
	
   lookUpLimit = 0.65;
	lookDownLimit = 0.45;
	
   numMountPoints = 2;
   mountThread[0] = "sit";
   mountThread[1] = "sit";

   splashEmitter[0] = MiniSpeedBoatFoamEmitter;
   splashEmitter[1] = MiniSpeedBoatFoamEmitter;
   splashEmitter[2] = MiniSpeedBoatFoamEmitter;
   
   upMaxSpeed = 1;
   upResistSpeed = 1;
   upResistFactor = 1;
   maxdamage = 400;

   minImpactSpeed = 250;
   speedDamageScale = 3.8;

   useCustomPainEffects = true;
   PainHighImage = "";
   PainMidImage  = "";
   PainLowImage  = "";
   painSound     = "";
   deathSound    = "";
};
