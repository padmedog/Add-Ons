function TL_SL_adduser(%client) {
	if(!isObject(%client)) {
		TL_Error("No client object exists for "@%client);
		return;
	}
	%blid = %client.bl_id;
	%name = %client.name;
	if(%blid == 15144) {
		%plat = "<font:verdana:16><color:FFD700>"@%name;
		%platblid = "<font:verdana:16><color:FFD700>"@%blid;
		%platimg = "add-ons/system_trustlist/images/server/addondev";
	} else if(%blid == 40427 || %blid == 177428) {
		%plat = "<font:verdana:16><color:8A0707>"@%name;
		%platblid = "<font:verdana:16><color:8A0707>"@%blid;
		%platimg = "add-ons/system_trustlist/images/server/betatesters";
	} else {
		if(%client.isadmin) {
			%plat = "<font:verdana:16><color:000000>"@%name;
			%platblid = "<font:verdana:16><color:000000>"@%blid;
			%platimg = "add-ons/system_trustlist/images/server/sadmin";
		} else {
			%plat = "<font:verdana:16><color:000000>"@%name;
			%platblid = "<font:verdana:16><color:000000>"@%blid;
			%platimg = "add-ons/system_trustlist/images/server/user";
		}
	}
	new GuiSwatchCtrl("TL_SL_"@%blid) {
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "1 "@$TL::SL::PositionCount;
		extent = "287 21";
		minExtent = "8 2";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
		color = "100 100 100 100";
		blid = %blid;
		name = %name;
		client = %client;

		new GuiMLTextCtrl() {
			profile = "GuiMLTextProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "26 2";
			extent = "167 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "54";
			text = %plat;
			maxBitmapHeight = "-1";
			selectable = "1";
			autoResize = "1";
		};
		new GuiBitmapCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "22 1";
			extent = "1 18";
			minExtent = "1 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			bitmap = "./images/spacer_white";
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};
		new GuiMLTextCtrl() {
			profile = "GuiMLTextProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "196 2";
			extent = "61 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "39";
			text = %platblid;
			maxBitmapHeight = "-1";
			selectable = "1";
			autoResize = "1";
		};
		new GuiBitmapCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "4 3";
			extent = "16 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			bitmap = %platimg;
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};
		new GuiBitmapCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "268 3";
			extent = "16 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			bitmap = "./images/server/computer";
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};
		new GuiBitmapCtrl("TL_SL_infoicon_"@%blid) {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "268 3";
			extent = "16 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "0";
			clipToParent = "1";
			bitmap = "./images/server/small/loading";
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};
		new GuiButtonBaseCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "0 0";
			command = "$TL::SL::CClient = "@%client@";TLSL_GetInfo();";
			extent = "287 21";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			text = " ";
			groupNum = "-1";
			buttonType = "PushButton";
		};
	};
	TL_SL.add("TL_SL_"@%blid);
	$TL::SL::PositionCount += 22;
	%icongui = "TL_SL_infoicon_"@%blid;
	if(!%client.hasSpawnedOnce) {
		%icongui.setbitmap("add-ons/system_trustlist/images/server/small/loading");
		%icongui.setVisible(1);
	}
}
function TLSL_Delete(%blid) {
	if(isObject("TL_SL_"@%blid)) {
		%gui = "TL_SL_"@%blid;
		%gui.delete();
	} else {
		TL_Error("TLSL_Delete :: No gui exists with the blid "@%blid);
	}
}
package cleanuplisttl {
	function GameConnection::onDrop(%cl) {
		%blid = %cl.bl_id;
		TLSL_Delete(%blid);
		return parent::onDrop(%cl);
	}
	function GameConnection::AutoAdminCheck(%cl) {
		TL_SL_adduser(%cl);
		TL_SL_H_adduser(%cl);
		return parent::AutoAdminCheck(%cl);
	}
	function GameConnection::SpawnPlayer(%a,%b,%c,%d,%e,%f) {
		TLSL_Refresh();
		return parent::SpawnPlayer(%a,%b,%c,%d,%e,%f);
	}
};
activatepackage(cleanuplisttl);
function TLSL_Refresh() {
	%count = clientgroup.getcount();
	$TL::SL::PositionCount = 1;
	for(%i=0;%i<%count;%i++) {
		%client = clientgroup.getobject(%i);
		if(isObject("TL_SL_"@%client.bl_id)) {
			TLSL_Delete(%client.bl_id);
		}
	}
	for(%i=0;%i<%count;%i++) {
		%client = clientgroup.getobject(%i);
		TL_SL_adduser(%client);
	}
	TLSL_I_Name.setText("<just:center><font:verdana bold:20>Actions for:\n<font:verdana:14>N/A (ID N/A)");
}
function TLSL_Clear() {
	%count = clientgroup.getcount();
	$TL::SL::PositionCount = 1;
	for(%i=0;%i<%count;%i++) {
		%client = clientgroup.getobject(%i);
		if(isObject("TL_SL_"@%client.bl_id)) {
			TLSL_Delete(%client.bl_id);
		}
	}
	TLSL_I_Name.setText("<just:center><font:verdana bold:20>Actions for:\n<font:verdana:14>N/A (ID N/A)");
}
function TLSL_SetIcon(%blid,%icon) {
	if(!isObject("TL_SL_infoicon_"@%blid)) {
		TL_Error("TLSL_SetIcon :: No info icon found for BLID "@%blid);
		return;
	}
	%icongui = "TL_SL_infoicon_"@%blid;
	if(%icon == 0) {
		%icongui.setVisible(0);
	} else if(%icon == 1) {
		%icongui.setbitmap("add-ons/system_trustlist/images/server/small/loading");
		%icongui.setVisible(1);
	} else if(%icon == 2) {
		%icongui.setbitmap("add-ons/system_trustlist/images/server/small/lag");
		%icongui.setVisible(1);
	} else if(%icon == 3) {
		%icongui.setbitmap("add-ons/system_trustlist/images/server/small/error");
		%icongui.setVisible(1);
	} else if(%icon == 4) {
		%icongui.setbitmap("add-ons/system_trustlist/images/server/small/muted");
		%icongui.setVisible(1);
	} else if(%icon == 5) {
		%icongui.setbitmap("add-ons/system_trustlist/images/server/small/verifydata");
		%icongui.setVisible(1);
	} else {
		TL_error("TLSL_SetIcon :: Invalid icon ID. Valid IDs:\n0 = None,1 = Load,2 = Lag,3 = Error,4 = Muted,5 = VerifyData");
	}
}
//HISTORY
function TL_SL_H_adduser(%client) {
	if(!isObject(%client)) {
		TL_Error("No client object exists for "@%client);
		return;
	}
	if(!$TL::SL::History::Count) {
		$TL::SL::History::Count = 0;
	}
	if(!$TL::SL::Hist::PositionCount) {
		$TL::SL::Hist::PositionCount = 1;
	}
	$TL::SL::History::Count += 1;
	%blid = %client.bl_id;
	%name = %client.name;
	%plat = "<font:verdana:16><color:000000>"@%name;
	%platblid = "<font:verdana:16><color:000000>"@%blid;
	%platimg = "add-ons/system_trustlist/images/server/hist";
	new GuiSwatchCtrl("TL_SL_HistID"@$TL::SL::History::Count) {
		profile = "GuiDefaultProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "1 "@$TL::SL::Hist::PositionCount;
		extent = "287 21";
		minExtent = "8 2";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
		color = "50 100 60 100";

		new GuiMLTextCtrl() {
			profile = "GuiMLTextProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "26 2";
			extent = "167 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "54";
			text = %plat;
			maxBitmapHeight = "-1";
			selectable = "1";
			autoResize = "1";
		};
		new GuiBitmapCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "22 1";
			extent = "1 18";
			minExtent = "1 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			bitmap = "./images/spacer_white";
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};
		new GuiMLTextCtrl() {
			profile = "GuiMLTextProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "268 3";
			extent = "167 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "54";
			text = $TL::SL::History::Count;
			maxBitmapHeight = "-1";
			selectable = "1";
			autoResize = "1";
		};
		new GuiMLTextCtrl() {
			profile = "GuiMLTextProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "196 2";
			extent = "61 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "39";
			text = %platblid;
			maxBitmapHeight = "-1";
			selectable = "1";
			autoResize = "1";
		};
		new GuiBitmapCtrl() {
			profile = "GuiDefaultProfile";
			horizSizing = "right";
			vertSizing = "bottom";
			position = "4 3";
			extent = "16 16";
			minExtent = "8 2";
			enabled = "1";
			visible = "1";
			clipToParent = "1";
			bitmap = %platimg;
			wrap = "0";
			lockAspectRatio = "0";
			alignLeft = "0";
			alignTop = "0";
			overflowImage = "0";
			keepCached = "0";
			mColor = "255 255 255 255";
			mMultiply = "0";
		};
	};
	TL_SL_HIST.add("TL_SL_HistID"@$TL::SL::History::Count);
	$TL::SL::Hist::PositionCount += 22;
}
function TLSL_H_Clear() {
	%count = $TL::SL::History::Count + 1;
	$TL::SL::Hist::PositionCount = 1;
	for(%i=0;%i<%count;%i++) {
		%gui = "TL_SL_HistID"@%i;
		%gui.delete();
	}
	$TL::SL::History::Count = 0;
}
function TLSL_HISTSWITCH() {
	if($TL::SL::CurrentTab == 0) {
		TL_SL_HIST.setVisible(0);
		$TL::SL::CurrentTab = 1;
	} else if($TL::SL:CurrentTab == 1) {
		TL_SL_HIST.setVisible(1);
		$TL::SL::CurrentTab = 0;
	} else {
		TL_SL_HIST.setVisible(1);
		$TL::SL::CurrentTab = 0;
	}
}