datablock fxLightData(flAnablue)
{
	uiName = "Eksi (IMG) - Ana blue";

	LightOn = false;

	flareOn = true;
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicblue";
	ConstantSizeOn = true;
	ConstantSize = 2.5;
	NearSize = 1;
	FarSize = 1;
	Fadetime = 0.03;
};
datablock fxLightData(flAnayel : flAnablue)
{
	uiName = "Eksi (IMG) - Ana yellow";
	flarebitmap = "Add-Ons/Light_Eksi/anamorphicyellow";
};
datablock fxLightData(flBleuhoriz : flAnablue)
{
	uiName = "Eksi (IMG) - Horiz blue";
	flarebitmap = "Add-Ons/Light_Eksi/bleuhorizontal";
};
datablock fxLightData(flBleutonderayons : flAnablue)
{
	uiName = "Eksi (IMG) - Blue-rays";
	flarebitmap = "Add-Ons/Light_Eksi/bleutonderayons";
};
datablock fxLightData(flClassicblue : flAnablue)
{
	uiName = "Eksi (IMG) - Blue 3";
	flarebitmap = "Add-Ons/Light_Eksi/classicblue";
};
datablock fxLightData(flEtoilebleu : flAnablue)
{
	uiName = "Eksi (IMG) - Blue bright";
	flarebitmap = "Add-Ons/Light_Eksi/etoilebleu";
};
datablock fxLightData(flJaunidiagonal : flAnablue)
{
	uiName = "Eksi (IMG) - Diag yellow";
	flarebitmap = "Add-Ons/Light_Eksi/jaunidiagonal";
};
datablock fxLightData(flMultidirectionalcolor : flAnablue)
{
	uiName = "Eksi (IMG) - Teal multi";
	flarebitmap = "Add-Ons/Light_Eksi/multidirectionalcolor";
};
datablock fxLightData(flNeutresunetoile : flAnablue)
{
	uiName = "Eksi (IMG) - Neutral star";
	flarebitmap = "Add-Ons/Light_Eksi/neutresunetoile";
};
datablock fxLightData(flNormal20 : flAnablue)
{
	uiName = "Eksi (IMG) - Normal 20";
	flarebitmap = "Add-Ons/Light_Eksi/normal20";
};
datablock fxLightData(flVertical : flAnablue)
{
	uiName = "Eksi (IMG) - Vert yellow";
	flarebitmap = "Add-Ons/Light_Eksi/vertical";
};
datablock fxLightData(flFlashlight : flAnablue)
{
	uiName = "Eksi (IMG) - White spectrum";
	flarebitmap = "Add-Ons/Light_Eksi/flashlight";
	ConstantSize = 5;
};