function ServerCmdCtDelay(%Client,%Amt)
{
	if(!%Client.isSuperAdmin)
	{
		MessageClient(%Client,'',"\c6This command can only be used by \c3Super Admins");
		return;
	}
		%letter = "a b c d e f g h i j k l m n o p q r s t u v w x y z ! @ # $ % ^ & * ( ) _ - + = [ ] { } \ | ; : , . / ?";
		for(%i=0;%i<getWordCount(%letter);%i++)
   		{
      		%let = getWord(%letter,%i);
      		%Amt = strReplace(%Amt,%let,"");
   		}
	if(%Amt < 6000 || %Amt > 80000)
	{
		MessageClient(%Client,'',"\c6Invalid value");
		return;
	}

	if(%Amt $= " " && %Amt $= "")
	{
		MessageClient(%Client,'',"\c6Invalid value");
		return;
	}

	MessageAll('',"\c3" @ %Client.name @ "\c6 set the clear temp brick delay to \c2" @ %Amt);

	$Swollow::ClearTempBrickTime = %Amt;
}