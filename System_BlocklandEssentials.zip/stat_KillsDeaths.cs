$statOneName = "Kills";
$statTwoName = "Deaths";

function getKills(%client)
{
	return %client.getKills();
}

function getDeaths(%client)
{
	return %client.getDeaths();
}

package killsDeathsUpdate
{
	function GameConnection::onDeath(%this,%obj,%killer,%type,%area)
	{
		%ret = parent::onDeath(%this,%obj,%killer,%type,%area);
		for(%a=0;%a<clientGroup.getCount();%a++)
		{
			%client = clientGroup.getObject(%a);
			updateStatOne(%client,getKills(%client));
			updateStatTwo(%client,getDeaths(%client));
			%client.incScore(0);
		}
		return %ret;
	}
};
activatepackage(killsDeathsUpdate);
