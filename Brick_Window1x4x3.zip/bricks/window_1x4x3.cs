// door_Plain.cs Plain door datablocks

datablock fxDTSBrickData ( brickWindow1x4x3OpenData )
{
	brickFile = "./window1x4x3wo.blb";
	uiName = "Window 1x4x3";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x4x3Data";
	openCW = "brickWindow1x4x3OpenData";
	
	closedCCW = "brickWindow1x4x3Data";
	openCCW = "brickWindow1x4x3OpenData";
	
	orientationFix = 1;
};

datablock fxDTSBrickData ( brickWindow1x4x3Data : brickWindow1x4x3OpenData )
{
	brickFile = "./window1x4x3w.blb";
	category = "special";
	subCategory = "Windows";

	iconName = "Add-Ons/Brick_Window1x4x3/bricks/window1x4x3";
	
	isOpen = 0;
};