///////////////////////////////////
//
//   Add-On: Map Lighting Fix
//
//   ---------------------------
//
//   Author: General
//   BL ID: 4878
//
//   ---------------------------
//
//   File: server.cs
//
//   File version: 4
//   Last updated on: 07/05/2012
//
///////////////////////////////////



//Please excuse my poor coding methods, had little time to complete this
//exec("Add-Ons/Client_MapLightingFix/client.cs"); MLF_GuiFunction(0,1);

//RTB does not execute this correctly... Requires restart.
if(getSimTime())
{
	messageBoxOk("Map Lighting Fix","You must restart Blockland to finish installing the fix.");
	return;
}

package mapLightingFix
{
	//gui
	function MLF_GuiFunction(%enable)
	{
		if(%enable==1)
		{
			$Pref::LightingFix::Enable=2;
			MLF_Blocker.setVisible(0);
		}
		else
		{
			$Pref::LightingFix::Enable=1;
			MLF_Blocker.setVisible(1);
		}
	}
	
	function MLF_O::onWake(%this)
	{
		if($Pref::LightingFix::Enable==1)
		{
			MLF_Enable.setValue(0);
			MLF_Blocker.setVisible(1);
		}
		else
		{
			MLF_Enable.setValue(1);
			MLF_Blocker.setVisible(0);
		}
		if($Pref::LightingFix::Type==1)
			MLF_Radio1.setValue(1);
		else
			MLF_Radio1.setValue(0);
		if($Pref::LightingFix::Type==2)
			MLF_Radio2.setValue(1);
		else
			MLF_Radio2.setValue(0);
	}

	//other
	function MLF_Warn(%this,%this2)
	{
		if($Pref::Gui::IgnoreMLFWarning)
		{
			eval(%this);
			return;
		}
			
		canvas.pushDialog(mapLightingFix_Warning);
		MLF_Warning_No.command=%this2;
		MLF_Warning_Yes.command=%this;
	}
	
	function playGui::onWake(%this)
	{
		parent::onWake(%this);
		if(!$mapLightingFix)
		{	
			if($Pref::LightingFix::Enable == 1)
				return;
			if($Pref::LightingFix::Type == 1)
				mapLightingFixCheck();
			if($Pref::LightingFix::Type == 2)
				mapLightingFixCheck(1);
			$mapLightingFix = 1;
		}
	}
	
	function clientCmdMissionStartPhase3(%a,%map)
	{
		for(%i=findFirstFile(filePath(%map) @ "/*");%i!$="";%i=findNextFile(filePath(%map) @ "/*"))
			if(fileExt(%i) $= ".ml")
				fileDelete(%i);
		parent::clientCmdMissionStartPhase3(%a,%map);
	}
	
	function handleLoadMapPictureMessage(%a,%b,%c)
	{
		parent::handleLoadMapPictureMessage(%a,%b,%c);
		$mapLightingFix = 0;
		$mapLightingFixed=0;
	}
	
	function NMH_Type::send(%this)
	{
		parent::send(%this);
		%good=%this.getValue();
		if(striPos(%good,"/fixLighting") !$= -1 && strLen(%good) == 12)
			mapLightingFixCheck(1,1);
		if(striPos(%good,"/undoLightingFix") !$= -1 && strLen(%good) == 16)
			mapLightingFixUndo();
	}
	
	function mapLightingFixCheck(%do,%note)
	{
		if($mapLightingFixed)
		{
			NewChatHud_AddLine("Map lighting is already fixed.");
			return;
		}
	
		for(%i=0;%i<serverConnection.getCount();%i++)
		{
			%thing = serverConnection.getObject(%i).getClassName();
			if(%thing $= "InteriorInstance")
				%hasInterior=1;
			if(%thing $= "TerrainBlock")
				%hasTerrain=1;
		}
		
		if(!%hasTerrain)
		{
			if(%note)
				NewChatHud_AddLine("Map lighting is not broken.");
			return;
		}
		
		if(!%do && %hasInterior)
			return;
			
		if(%do && !%hasInterior)
			%do=0;
		
		if(%note)
			if(%hasInterior)
				MLF_Warn("mapLightingFix(" @ %do @ "," @ %note @ ");canvas.popDialog(mapLightingFix_Warning);","canvas.popDialog(mapLightingFix_Warning);");
			else
				mapLightingFix(%do,%note);
		else
			mapLightingFix(%do,%note);
			
	}
				
	function mapLightingFix(%do)
	{
		canvas.popDialog(newChatHUD);
		canvas.pushDialog(loadingGUI);
		onPhase3Progress(0);
		LoadingProgressTxt.setText("APPLYING LIGHTING FIX");
		$mapLightingFixed=1;

		schedule(500,0,"mapLightingFix2",%do);
	}
	
	function mapLightingFix2(%do,%time,%amb,%col)
	{
		%a=lightset.getobject(0);
		inspect(%a);
		if(!isObject(InspectStaticcolor0_16))
			InspectFields.toggleGroupScript(%a,Misc_begingroup);
		if(!%time)
		{
			$mapLightingAmb = InspectStaticambient0_16.getValue();
			$mapLightingCol = InspectStaticcolor0_16.getValue();
			
			if(!%do)
			{
				%newamb = getWord($mapLightingAmb,2) SPC getWord($mapLightingAmb,1) SPC getWord($mapLightingAmb,0) SPC getWord($mapLightingAmb,3);
				%newcol = getWord($mapLightingCol,2) SPC getWord($mapLightingCol,1) SPC getWord($mapLightingCol,0) SPC getWord($mapLightingCol,3);
			}
			else
			{
				%meanamb = (getWord($mapLightingAmb,0) + getWord($mapLightingAmb,1) + getWord($mapLightingAmb,2))/3;
				%meancol = (getWord($mapLightingCol,0) + getWord($mapLightingCol,1) + getWord($mapLightingCol,2))/3;
				
				%newamb = %meanamb SPC %meanamb SPC %meanamb SPC "1";
				%newcol = %meancol SPC %meancol SPC %meancol SPC "1";
			}
		
			InspectStaticambient0_16.setText(%newamb);
			InspectStaticcolor0_16.setText(%newcol);
			
			onPhase3Progress(1);
			lightScene('',"Forcealways");
			inspectApply();
			schedule(500,0,"mapLightingFix2",%do,1,$mapLightingAmb,$mapLightingCol);
		}
		else
		{
			if(!%do)
			{
				InspectStaticambient0_16.setText(%amb);
				InspectStaticcolor0_16.setText(%col);
			}
			
			inspectApply();
			onPhase3Progress(0);
			LoadingProgressTxt.setText("WAITING FOR SERVER");
			canvas.popDialog(loadingGUI);
			canvas.pushDialog(newChatHUD);
		}
		canvas.popdialog(inspectDlg);
	}
	
	function mapLightingFixUndo()
	{
		if(!$mapLightingFixed)
		{
			NewChatHud_AddLine("Map lighting is not fixed.");
			return;
		}

		canvas.popDialog(newChatHUD);
		canvas.pushDialog(loadingGUI);
		onPhase3Progress(0);
		LoadingProgressTxt.setText("UNDOING LIGHTING FIX");
		$mapLightingFixed=0;
		schedule(500,0,"mapLightingFixUndo2");
	}
	
	function mapLightingFixUndo2(%do)
	{
		if(!%do)
		{
			%a=lightset.getobject(0);
			inspect(%a);
			if(!isObject(InspectStaticcolor0_16))
				InspectFields.toggleGroupScript(%a,Misc_begingroup);
			InspectStaticambient0_16.setText($mapLightingAmb);
			InspectStaticcolor0_16.setText($mapLightingCol);
			inspectApply();
			canvas.popdialog(inspectDlg);
			lightScene('',"Forcealways");
			schedule(500,0,"mapLightingFixUndo2",1);
			onPhase3Progress(1);
		}
		else
		{
			onPhase3Progress(0);
			LoadingProgressTxt.setText("WAITING FOR SERVER");
			canvas.popDialog(loadingGUI);
			canvas.pushDialog(newChatHUD);
		}
	}
};
deactivatePackage(mapLightingFix);
	activatePackage(mapLightingFix);
	
//important mess
deactivatePackage(SlopesFix);
if(!$Pref::LightingFix::Type)
{
	$Pref::LightingFix::Type = 1;
}
if(!$Pref::LightingFix::Enable)
{
	
	$Pref::LightingFix::Enable = 2;
}
exec("./mapLightingFix_Options.gui");
exec("./mapLightingFix_OptionsButton.gui");
exec("./mapLightingFix_Warning.gui");