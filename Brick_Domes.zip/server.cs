datablock fxDTSBrickData(brickTiniestDomeData)
{
	brickFile = "./1x1x2Dome.blb";
	iconName = "Add-Ons/Brick_Domes/1x1x2Dome";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "1x1x2 Dome";
};

datablock fxDTSBrickData(brickTinyDomeData)
{
	brickFile = "./1x1x3Dome.blb";
	iconName = "Add-Ons/Brick_Domes/1x1x3Dome";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "1x1x3 Dome";
};

datablock fxDTSBrickData(brickDomeShortData)
{
	brickFile = "./2x2x3Dome.blb";
	iconName = "Add-Ons/Brick_Domes/2x2x3Dome";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "2x2x3 Dome";
};

datablock fxDTSBrickData(brickDomeData)
{
	brickFile = "./2x2x5Dome.blb";
	iconName = "Add-Ons/Brick_Domes/2x2x5Dome";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "2x2x5 Dome";
};

datablock fxDTSBrickData(brickBigDomeData)
{
	brickFile = "./4x4x5Dome.blb";
	iconName = "Add-Ons/Brick_Domes/4x4x5Dome";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "4x4x5 Dome";
};

datablock fxDTSBrickData(brickDiscDomeData)
{
	brickFile = "./5x5x2Dome.blb";
	iconName = "Add-Ons/Brick_Domes/5x5x2Dome";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "5x5x2 Dome";
};

datablock fxDTSBrickData(brickTinyInvertedDomeData)
{
	brickFile = "./1x1x3DomeInverted.blb";
	iconName = "Add-Ons/Brick_Domes/1x1x3DomeInverted";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "1x1x3 Dome Inverted";
};

datablock fxDTSBrickData(brickDomeInvertedData)
{
	brickFile = "./2x2x3DomeInverted.blb";
	iconName = "Add-Ons/Brick_Domes/2x2x3DomeInverted";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "2x2x3 Dome Inverted";
};

datablock fxDTSBrickData(brickDomeInvertedBowlData)
{
	brickFile = "./3x3x3DomeInverted.blb";
	iconName = "Add-Ons/Brick_Domes/3x3x3DomeInverted";
	category = "Rounds";
	subCategory = "Domes";
	uiName = "3x3x3 Dome Inverted";
};

