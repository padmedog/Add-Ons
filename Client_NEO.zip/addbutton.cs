//addbutton.cs

while(isobject(neo_newbuttongui))
	neo_newbuttongui.delete();
exec("./addbutton.gui");

function neo_clickadd()
{
//	neo_newbuttongui.clearData();
	canvas.popdialog(neo_newbuttongui);
	canvas.pushdialog(neo_newbuttongui);
}

function neo_newbuttongui::onWake(%this)
{
	%this.clearData();
}

function neo_newbuttongui::clearData(%this)
{
	//load type list
	neo_nbg_typelist.clear();
	neo_nbg_typelist.add("Open a GUI", 0);
	neo_nbg_typelist.add("Run some Code", 1);
	neo_nbg_typelist.add("Execute a Script", 2);
	neo_nbg_typelist.add("Use a Keybind", 3);
	neo_nbg_typelist.setText("No Type Selected");
	%this.setType(-1);

	//load gui list
	//based on gui/mission editor
	neo_nbg_guilist.clear();

	for(%i=0; %i<GuiGroup.getCount(); %i++)
	{
		%obj = GuiGroup.getObject(%i);

		if(%obj.getName() !$= Canvas)
		{
			if(%obj.getName() $= "")
				%name = "(unnamed) - " @ %obj;
			else
				%name = %obj.getName() @ " - " @ %obj;
	
			neo_nbg_guilist.add(%name, %obj);
		}
	}
	neo_nbg_guilist.sort();
	neo_newbuttongui.guiselected = -1;

	//load key list
	neo_nbg_keylist.clear();

	for(%i=0; %i<$remapCount; %i++)
	{
		if($remapDivision[%i] !$= "")
		{
			if(%i > 0)
				neo_nbg_keylist.addRow(-1, "");
			neo_nbg_keylist.addRow(-1, "\c4" @ $remapDivision[%i]);
			neo_nbg_keylist.addRow(-1, "\c4--------------------");
		}
		neo_nbg_keylist.addRow(%i, $remapName[%i]);
	}
	neo_newbuttongui.keyselected = -1;

	//gotta clear old data
	neo_nbg_name.setText("");
	neo_nbg_icon.setText($neo::pref::defaulticon);
	%this.setKeyType(2);
	neo_nbg_eval.setText("");
	neo_nbg_script.setText("");
	neo_nbg_prefclose.setValue(false);
	%this.oldCommand = "";
}

function neo_newbuttongui::setData(%this, %command)
{
	%this.clearData();
	neo_nbg_name.setText(%command.name);
	neo_nbg_icon.setText(%command.icon);
	neo_nbg_prefclose.setValue(%command.prefclose);
	%this.setType(1);
	neo_nbg_typelist.setText("Run some Code");
	neo_nbg_eval.setText(%command.cmd);
	%this.oldCommand = %command;
}

function neo_nbg_typelist::onSelect(%this, %id)
{
	neo_newbuttongui.setType(%id);
}

function neo_nbg_guilist::onSelect(%this, %id)
{
	neo_newbuttongui.guiselected = %id;
}

function neo_nbg_keylist::onSelect(%this, %id)
{
	if(%id == -1)
		%this.clearSelection();
	neo_newbuttongui.keyselected = %id;
}

function neo_newbuttongui::browseicon(%this)
{
	//neo_debug("does this exist: " @ %this);
	promptUserFile("add-ons/client_neo/ui/", "neo_nbg_returnbrowseicon", "load", ".png");
}

function neo_nbg_returnbrowseicon(%path)
{
	neo_nbg_icon.settext(%path);
}

function neo_newbuttongui::browsescript(%this)
{
	promptUserFile("config/", "neo_nbg_returnbrowsescript", "load", ".cs");
}

function neo_nbg_returnbrowsescript(%path)
{
	neo_nbg_script.settext(%path);
}

function neo_newbuttongui::savebutton(%this)
{
	%name = neo_nbg_name.getValue();

	if(%name $= "")
	{
		%name = "Custom Command";
	}
	%icon = neo_nbg_icon.getValue();

	if(!isfile(%icon))
	{
		neo_debug("bad icon: " @ %icon);
		%icon = $neo::pref::defaulticon;
	}
	%prefclose = neo_nbg_prefclose.getValue();

	switch(%this.cmdType)
	{
		case 0:
			if(!isobject(%this.guiselected))
			{
				neo_debug("no gui selected");
				messageboxok("Attention", "Please select a gui from the drop down list, or choose a different command type.");
				return;
			}
			%cmd = "canvas.pushdialog(" @ %this.guiselected @ ");";
		case 1:
			%cmd = neo_nbg_eval.getValue();
		case 2:
			%cmd = "exec(\"" @ neo_nbg_script.getValue() @ "\");";
		case 3:
			if(%this.keySelected == -1)
			{
				neo_debug("no key selected");
				messageboxok("Attention!", "Please select a keybind from the list, or choose a different command type.");
				return;
			}
			if(%this.keyType == 0)
				%cmd = "call(\"" @ $remapCmd[%this.keySelected] @ "\", 1);";
			else if(%this.keyType == 1)
				%cmd = "call(\"" @ $remapCmd[%this.keySelected] @ "\", 0);";
			else
				%cmd = "call(\"" @ $remapCmd[%this.keySelected] @ "\", 1);call(\"" @ $remapCmd[%this.keySelected] @ "\", 0);";
		default:
			neo_debug("no type selected");
			messageboxok("Attention!", "Please choose a command type from the drop down list");
			return;
	}

	if(%this.oldCommand !$= "")
	{
		%index = neomain.commandLookup[%this.oldCommand.name, %this.oldCommand.cmd];

		if(%this.oldCommand.custom)
		{
			if(neomain.commandLookup[%name, %cmd] !$= "" && neomain.commandLookup[%name, %cmd] != %index)
			{
				messageboxok("Attention!", "A different command already exists with the same name and function, please choose something else.");
				return;
			}
			neomain.commandLookup[%this.oldCommand.name, %this.oldCommand.cmd] = "";
			%this.oldCommand.name = %name;
			%this.oldCommand.icon = %icon;
			%this.oldCommand.cmd = %cmd;
			%this.oldCommand.prefClose = %prefclose;
			neomain.commandLookup[%this.oldCommand.name, %this.oldCommand.cmd] = %index;
			neomain.modified = true;
		}
		else
		{
			if(%this.oldCommand.name !$= %name || %this.oldCommand.cmd !$= %cmd)
			{
				messageboxok("Attention!", "You cannot change the name or function of non-custom commands.");
				neo_nbg_name.setValue(%this.oldCommand.name);
				%this.setType(1);
				neo_nbg_typelist.setText("Run some Code");
				neo_nbg_eval.setValue(%this.oldCommand.cmd);
				return;
			}
			else
			{
				if(%this.oldCommand.icon !$= %icon || %this.oldCommand != %prefclose)
				{
					%this.oldCommand.icon = %icon;
					%this.oldCommand.prefClose = %prefclose;
					%this.oldCommand.modified = true;
					neomain.modified = true;
				}
			}
		}
	}
	else
	{
		%command = new scriptobject(neocommand)
		{
			name = %name;
			icon = %icon;
			cmd = %cmd;
			prefClose = %prefclose;
			custom = true;
		};
		neomain.addCommand(%command);
	}
	canvas.popdialog(%this);
	neomain.savedata();
	neomain.maintain();
	neomain.draw();
}

function neo_newbuttongui::setType(%this, %type)
{
	%this.cmdType = %type;
	neo_guiswatch.setvisible(0);
	neo_evalswatch.setvisible(0);
	neo_scriptswatch.setvisible(0);
	neo_keyswatch.setvisible(0);

	//neo_nbg_typelist.add("Open a GUI", 0);
	//neo_nbg_typelist.add("Run some Code", 1);
	//neo_nbg_typelist.add("Execute a Script", 2);
	//neo_nbg_typelist.add("Use a Keybind", 3);
	//neo_nbg_typelist.setText("No Type Selected");
	switch(%type)
	{
		case 0: neo_guiswatch.setvisible(1);
		case 1: neo_evalswatch.setvisible(1);
		case 2: neo_scriptswatch.setvisible(1);
		case 3: neo_keyswatch.setvisible(1);
	}
}

function neo_newbuttongui::setKeyType(%this, %type)
{
	%this.keyType = %type;

	switch(%type)
	{
		case 0:
			neo_nbg_keypress.setvalue(1);
			neo_nbg_keyrelease.setvalue(0);
			neo_nbg_keyboth.setvalue(0);
		case 1:
			neo_nbg_keypress.setvalue(0);
			neo_nbg_keyrelease.setvalue(1);
			neo_nbg_keyboth.setvalue(0);
		case 2:
			neo_nbg_keypress.setvalue(0);
			neo_nbg_keyrelease.setvalue(0);
			neo_nbg_keyboth.setvalue(1);
	}
}

