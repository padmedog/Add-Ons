//force jeep addon to load
%error=ForceRequiredAddOn("Vehicle_Turismo");

if(%error==$Error::AddOn_Disabled){
 TurismoVehicle.uiName="";
}

if(%error==$Error::AddOn_NotFound){
 error("ERROR: Vehicle_GravityTurismo - required add-on Vehicle_Turismo not found");
}else{
 exec("./Vehicle_GravityTurismo.cs");
}