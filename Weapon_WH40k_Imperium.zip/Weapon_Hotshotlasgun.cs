//audio
datablock AudioProfile(HotShotLasgunFireSound)
{
   filename    = "./Hotshot_shot.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(HotShotLasgunTrailParticle)
{
	dragCoefficient		= 0.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0625;
	constantAcceleration	= 0.0;
	lifetimeMS		= 360;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/dot";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "1 0.0 0 1";
	colors[1]	= "1 0.25 0.25 1";
	sizes[0]	= 0.2;
	sizes[1]	= 0.15;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(HotShotLasgunTrailEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = HotShotLasgunTrailParticle;

   useEmitterColors = true;
};

datablock ProjectileData(HotShotLasgunTracerProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 100;
   verticalImpulse	  = 50;
//explosion           = gunExplosion;
   particleEmitter     = "HotShotLasgunTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 1000;
   fadeDelay           = 700;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ParticleData(HotShotLasgunExplosionParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 250;
	lifetimeVarianceMS   = 125;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1.0 0.25 0.25 1";
	colors[1]     = "1.0 0.75 0.75 0.0";
	sizes[0]      = 1;
	sizes[1]      = 0.25;

	useInvAlpha = false;
};
datablock ParticleEmitterData(HotShotLasgunExplosionEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "HotShotLasgunExplosionParticle";

   useEmitterColors = false;
   uiName = "Hot-ShotLasgun Hit Dust";
};

datablock ParticleData(HotShotLasgunExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 50;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1.0 0.25 0.25 1";
	colors[1]     = "1.0 0.5 0.5 0.0";
	sizes[0]      = 1.5;
	sizes[1]      = 3;

	useInvAlpha = false;
};
datablock ParticleEmitterData(HotShotLasgunExplosionRingEmitter)
{
	lifeTimeMS = 200;

   ejectionPeriodMS = 12;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "HotShotLasgunExplosionRingParticle";

   useEmitterColors = true;
   uiName = "Hot-Shot Lasgun Hit Flash";
};

datablock ExplosionData(HotShotLasgunExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 100;

   particleEmitter = HotShotLasgunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = HotShotLasgunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "1.0 1.0 1.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.25;
   camShakeRadius = 1.25;

   // Dynamic light
   lightStartRadius = 4;
   lightEndRadius = 0;
   lightStartColor = "1.0 0.25 0.25";
   lightEndColor = "0 0 0";
};

datablock ProjectileData(HotShotLasgunExplosionProjectile)
{
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 100;
   verticalImpulse	  = 50;
   explosion           = HotShotLasgunExplosion;
   particleEmitter     = "LasrifleTrailEmitter";

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 1000;
   fadeDelay           = 700;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.10;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(HotShotLasgunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "Add-Ons/Weapon_WH40k_Imperium/HotShotLasgun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Hot-shot Lasgun";
	iconName = "./HotshotLasgun";
	doColorShift = false;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = HotShotLasgunImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	maxAmmo = 50;
	canReload = 1;
};

AddDamageType("HotShotLasgun",   '<bitmap:add-ons/Weapon_WH40k_Imperium/CI_HotshotLasgun> %1',    '%2 <bitmap:add-ons/Weapon_WH40k_Imperium/CI_HotshotLasgun> %1',0.75,1);

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(HotShotLasgunImage)
{

   // Basic Item properties
	shapeFile = "Add-Ons/Weapon_WH40k_Imperium/HotShotLasgun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = HotShotLasgunItem;
   ammo = " ";
   projectile = HotShotLasgunTracerProjectile;
   projectileType = Projectile;

   casing = GunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;	
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = HotShotLasgunItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
   raycastWeaponRange = 100; //varies
   raycastWeaponTargets =
                   $TypeMasks::PlayerObjectType |    //AI/Players
                   $TypeMasks::StaticObjectType |    //Static Shapes
                   $TypeMasks::TerrainObjectType |    //Terrain
                   $TypeMasks::VehicleObjectType |    //Terrain
                   $TypeMasks::FXBrickObjectType;    //Bricks
   raycastExplosionProjectile = HotShotLasgunExplosionProjectile;
   raycastExplosionBrickSound = bulletHitSound;
   raycastExplosionPlayerSound = bulletHitSound;
   raycastDirectDamage = 17; //10
   raycastDirectDamageType = $DamageType::HotShotLasgun;
   raycastSpreadAmt = 0.0012; //varies
   raycastSpreadCount = 1;
   raycastTracerProjectile = HotShotLasgunTracerProjectile;
   raycastFromMuzzle = true;

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.05;
	stateSequence[0]		= "Activate";
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]			= weaponSwitchSound;

	stateName[1]                    = "Ready";
 
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateScript[1]                  = "onReady";
	stateSequence[1]			  = "ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.01;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateScript[2]                  = "onFire";
	stateSequence[2]		= "Fire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.1;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= HotShotLasgunfireSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Wait";

	stateName[4]			= "Wait";
	stateEjectShell[2]              = false;
	stateTimeoutValue[4]		= 0.09;
	stateScript[4]                  = "onBounce";
	stateTransitionOnTimeout[4]	= "Ready";

};

function HotShotLasgunImage::onFire(%this,%obj,%slot)
{
	%obj.spawnExplosion(TTRecoilProjectile,"1 1 1");
	if(%obj.getDamagePercent() >= 1.0)
		return;
	
	if(vectorLen(%obj.getVelocity()) > 0.1)
	{
		%this.raycastSpreadAmt = 0.0018;
		%this.raycastWeaponRange = 300;
	}
	else
	{
		%this.raycastSpreadAmt = 0.0018;
		%this.raycastWeaponRange = 300;
	}
	
	%obj.playThread(2, plant);	
	Parent::onFire(%this,%obj,%slot);
}

