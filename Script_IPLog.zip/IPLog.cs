//Constants
$logIPADFile = "config/server/ServerLogs/PlayerIPADs.cs";

//Checks if log already exists, if so, load log.
if(isFile($logIPADFile))
{
    exec($logIPADFile);
}

//Package for automatically logging and saving IP addresses.
package IPLog
{
    function GameConnection::AutoAdminCheck(%client)
    {
       $LoggedIP[%client.BL_ID] = %client.getRawIP();
       export("$LoggedIP*" @ "_ipad", $logIPADFile, false); 
       $LoggedIP[%client.getPlayerName()] = %client.BL_ID;
	   export("$LoggedIP*" @ "_name", $logIPADFile, false);
       return Parent::AutoAdminCheck(%client);
    }
};
activatepackage(IPLog);