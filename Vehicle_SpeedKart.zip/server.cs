//I don't know why this script is so complicated looking. Maybe it just has more functions that it needs or something. I guess
//it must be made to be expandable. Anyways, new script.
//exec("./support_shootonclick.cs");
exec("./support_vehicleHorns.cs");

//we need the Jeep add-on for this, so force it to load
%error = ForceRequiredAddOn("Vehicle_Jeep");

function Player::playSound(%this,%sound)
{
        
 if(!isObject(%sound) || %sound.getClassName() !$= "AudioProfile")
  return;
 
 if(%sound.description.isLooping || !%sound.description.is3D)
  return;
  
 serverplay3d(%sound,%this.getHackPosition() SPC "0 0 1 0");
}


if(%error == $Error::AddOn_Disabled)
{
   //A bit of a hack:
   //  we just forced the -- to load, but the user had it disabled
   //  so lets make it so they can't select it
   JeepVehicle.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   //we don't have the --, so we're screwed
   error("ERROR: Vehicle_SpeedKart - required add-on Vehicle_Jeep not found");
   return;
}

datablock AudioProfile(SpeedKartGoSound)
{
   filename    = "./SpeedKart_go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartIdleSound)
{
   filename    = "./SpeedKart_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHornSound)
{
   filename    = "./SpeedKart_horn.wav";
   description = AudioClose3d;
   preload = true;
};

//HOVER KART SMOKE
///===============================================================
datablock ParticleData(hoverKartSmokeParticle)
{
   dragCoefficient      = 0;
   windCoefficient     = 0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/cloud";
   colors[0]     = "1 1 1 1";
   colors[1]     = "0.2 0.2 1 0";
   sizes[0]      = 0.1;
   sizes[1]      = 0.05;
};

datablock ParticleEmitterData(hoverKartSmokeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "hoverKartSmokeParticle";
};
datablock ShapeBaseImageData(hoverKartSmokeImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;
	mountPoint = 1;
	offset = "0 0 0";
	correctMuzzleVector = false;
 	className = "WeaponImage";
  	item = "";
  	ammo = "";
	armReady = false;
	casing = "";
	doColorShift = false;
	
	stateName[0]					 = "Ready";
	stateTransitionOnTimeout[0]		 = "Emit";
	stateTimeoutValue[0]			 = 0.01;
	stateName[1]					 = "Emit";
	stateEmitter[1]					 = "hoverKartSmokeEmitter";//"KartSmokeEmitter";
	stateEmitterTime[1]				 = 600;
};
datablock ShapeBaseImageData(hoverKartSmokeTwoImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;
	mountPoint = 2;
	offset = "0 0 0";
	correctMuzzleVector = false;
 	className = "WeaponImage";
  	item = "";
  	ammo = "";
	armReady = false;
	casing = "";
	doColorShift = false;
	
	stateName[0]					 = "Ready";
	stateTransitionOnTimeout[0]		 = "Emit";
	stateTimeoutValue[0]			 = 0.01;
	stateName[1]					 = "Emit";
	stateEmitter[1]					 = "hoverKartSmokeEmitter";//"KartSmokeEmitter";
	stateEmitterTime[1]				 = 600;
};
///===============================================================

//SMOKE
///===============================================================
datablock ParticleData(KartSmokeParticle) {
   dragCoefficient = "2.99998";
   windCoefficient = "0";
   gravityCoefficient = "0";
   inheritedVelFactor = "0";
   constantAcceleration = "0";
   lifetimeMS = "300";
   lifetimeVarianceMS = "65";
   spinSpeed = "500";
   spinRandomMin = "-150";
   spinRandomMax = "150";
   useInvAlpha = "1";
   animateTexture = "0";
   framesPerSec = "1";
   textureName = "base/data/particles/cloud";
   animTexName[0] = "base/data/particles/cloud";
   colors[0] = "1.000000 1.000000 1.000000 0.000000";
   colors[1] = "0.466667 0.466667 0.466667 0.200000";
   colors[2] = "0.800000 0.800000 1.000000 0.000000";
   colors[3] = "1.000000 1.000000 1.000000 1.000000";
   sizes[0] = "0.399805";
   sizes[1] = "0.399805";
   sizes[2] = "1.4985";
   sizes[3] = "1";
   times[0] = "0";
   times[1] = "0.298039";
   times[2] = "1";
   times[3] = "2";
};
//Moar smoke things
datablock ParticleEmitterData(KartSmokeEmitter) 
{
   className = "ParticleEmitterData";
   ejectionPeriodMS = "14";
   periodVarianceMS = "0";
   ejectionVelocity = "0";
   velocityVariance = "0";
   ejectionOffset = "0";
   thetaMin = "85";
   thetaMax = "90";
   phiReferenceVel = "0";
   phiVariance = "360";
   overrideAdvance = "0";
   orientParticles = "0";
   orientOnVelocity = "1";
   particles = "KartSmokeParticle";
   lifetimeMS = "0";
   lifetimeVarianceMS = "0";
   useEmitterSizes = "0";
   useEmitterColors = "0";
   uiName = "Kart Smoke";
   doFalloff = "1";
   doDetail = "1";
};
//Smoke
datablock ShapeBaseImageData(KartSmokeImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;
	mountPoint = 1;
	offset = "0 0 0";
	correctMuzzleVector = false;
 	className = "WeaponImage";
  	item = "";
  	ammo = "";
	armReady = false;
	casing = "";
	doColorShift = false;
	
	stateName[0]					 = "Ready";
	stateTransitionOnTimeout[0]		 = "Emit";
	stateTimeoutValue[0]			 = 0.01;
	stateName[1]					 = "Emit";
	stateEmitter[1]					 = "KartSmokeEmitter";//"KartSmokeEmitter";
	stateEmitterTime[1]				 = 600;
};
datablock ShapeBaseImageData(KartSmokeSecondImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;
	mountPoint = 2;
	offset = "0 0 0";
	correctMuzzleVector = false;
 	className = "WeaponImage";
  	item = "";
  	ammo = "";
	armReady = false;
	casing = "";
	doColorShift = false;
	
	stateName[0]					 = "Ready";
	stateTransitionOnTimeout[0]		 = "Emit";
	stateTimeoutValue[0]			 = 0.01;
	stateName[1]					 = "Emit";
	stateEmitter[1]					 = "KartSmokeEmitter";//"KartSmokeEmitter";
	stateEmitterTime[1]				 = 600;
};
//END SMOKE
//==================================================


// SpeedKart_spring.cs

datablock WheeledVehicleSpring(SpeedKartSpring)
{
   // Wheel suspension properties
   length = 0.35;			 // Suspension travel
   force = 4000; //3000;		 // Spring force
   damping = 900; //600;		 // Spring damping
   antiSwayForce = 3; //3;		 // Lateral anti-sway force
};

//This is for the horn, doesn't work without a projectile.
datablock ProjectileData(NoProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 9;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0.0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse     = 0;
//   explosion           = gunExplosion;

   muzzleVelocity      = 0;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 0;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 0.0;
   lightColor  = "0 0 0";
};


// SpeedKart_tire.cs

datablock WheeledVehicleTire(SpeedKartTire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile = "./SpeedKarttire.dts";
   
	
	mass = 10;
   radius = 1;
   staticFriction = 5;
   kineticFriction = 5;
   restitution = 0.5;	

   // Spring that generates lateral tire forces
   lateralForce = 6000;
   lateralDamping = 500;
   lateralRelaxation = 0.3;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 5000;
   longitudinalDamping = 2000;
   longitudinalRelaxation = 0.1;
};

datablock WheeledVehicleTire(SpeedkartBlockoTire : SpeedkartTire)
{
        shapeFile = "./SpeedkartBlockowheel.dts";
};

datablock WheeledVehicleTire(SpeedkartHoverTire : SpeedkartTire)
{
        shapeFile = "./SpeedkartHoverwheel.dts";
};

datablock WheeledVehicleTire(Speedkart64Tire : SpeedkartTire)
{
        shapeFile = "./Speedkart64wheel.dts";
};



// Vehicle //
/////////////
datablock WheeledVehicleData(SpeedKartVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./SpeedKart.dts"; //"~/data/shapes/skivehicle.dts"; //
	emap = true;
	minMountDist = 3;
   
   numMountPoints = 1;
   mountThread[0] = "sit";


	maxDamage = 200.00;
	destroyedLevel = 200.00;
	energyPerDamagePoint = 160;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 -0.3 0.3";
   //massBox = "2 5 1";

	maxSteeringAngle = 0.6;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 6;         // Far distance from vehicle
	cameraOffset = 4;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.3;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

	defaultTire	= SpeedKartTire;
	defaultSpring	= SpeedKartSpring;
	//flatTire	= SpeedKartFlatTire;
	//flatSpring	= SpeedKartFlatSpring;

   numWheels = 4;

	// Rigid Body
	mass = 200;
	density = 5.0;
	drag = 4.5;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 3200; //4000;       // Engine power
	engineBrake = 700;         // Braking when throttle is 0
	brakeTorque = 3200;        // When brakes are applied
	maxWheelSpeed = 45;        // Engine scale by current speed / max speed

	rollForce		= 900;
	yawForce		= 600;
	pitchForce		= 1000;
	rotationalDrag		= 0;

   // Advanced Steering
   steeringAutoReturn = true;
   steeringAutoReturnRate = 1;
   steeringAutoReturnMaxSpeed = 10;
   steeringUseStrafeSteering = true;
   steeringStrafeSteeringRate = 0.08;

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = idleSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "SpeedKart";
	rideable = true;
		lookUpLimit = 0.65;
		lookDownLimit = 0.45;

	paintable = true;
   
   damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

  

   burnTime = 4000;

   

   minRunOverSpeed    = 4;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 8;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed

   //protection for passengers
   protectPassengersBurn   = false;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = false; //protect passengers from direct damage (bullets) ?

	//Instead of checking for each individual speedkart, lets just set a var.
	isSpeedkart = 1;
////////////////////
//Shooting scripts//
////////////////////

//ShootOnClick//

//shootonclickSpeedKart=1;
//	 
//shootonclickSpeedKart_Hold=0;
//shootonclickSpeedKart_ShootDelay=700;
//shootonclickSpeedKart_ReShootDelay=900;
//shootonclickSpeedKart_ProjectileCount=1;
//shootonclickSpeedKart_RequiredSlot=0;
//shootonclickSpeedKart_Sound=SpeedKartHornSound;
//
//shootonclickSpeedKart_Projectile[0]=NoProjectile;
//shootonclickSpeedKart_Position[0]="0.5 0.8 0";
//shootonclickSpeedKart_Velocity[0]="200 0 0";
//shootonclickSpeedKart_Scale[0]="1 1 1";
};
function SpeedKartVehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	//Vehicle sounds
	SpeedKartSpeedCheck(%this, %obj);
	
	//Copy paste these for smoke. If you only have one exhaust, only use the first one. The second one is if you have a second exhaust.
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

package SpeedKartHandPackage
{
	//Old function
//   function armor::onMount(%this,%obj,%col,%slot)
//   {
//      Parent::onMount(%this,%obj,%col,%slot);
//     
//		if(%col.dataBlock.isSpeedkart == 1)
//		{
//		    //%obj.playThread(2, armReadyBoth);
//		   	
//		    //Hand stuff.
//		    %obj.hidenode(lhand);
//		    %obj.hidenode(rhand);
//		    
//		    %obj.hidenode(rhook);
//		    %obj.hidenode(lhook);
//		}
//   }
   //isSpeedkart is the new check for datablocks to see if it's a speedkart
   function armor::onUnMount(%this,%obj,%col,%slot)
   {
      Parent::onUnMount(%this,%obj,%col,%slot);
      if(%col.dataBlock.isSpeedkart == 1)
      {
         %obj.playThread(2, root);
         %obj.playThread(0, root);
         
         //Hand things
		%col.hideNode(lhand);
		%col.hideNode(rhand);
		%col.hideNode(lhook);
		%col.hideNode(rhook);

		 %obj.client.applyBodyParts();
      }
   }
   function armor::onMount(%this,%obj,%col,%slot)
	{
		Parent::onMount(%this,%obj,%col,%slot);
		if(%col.getDatablock().isSpeedkart == 1)
		{
			%obj.playThread(2, armReadyBoth);
			
			%t = %obj.activeThread[1];
			if(!(%t $= "armReadyRight" || %t $= "armReadyBoth"))
			{
				%col.unhideNode($rhand[%obj.client.rhand]);
				%col.setNodeColor($rhand[%obj.client.rhand],%obj.client.rhandcolor);
				%obj.hideNode("rhand");
				%obj.hideNode("rhook");
			}
			if(!(%t $= "armReadyLeft" || %t $= "armReadyBoth"))
			{
				%col.unhideNode($lhand[%obj.client.lhand]);
				%col.setNodeColor($lhand[%obj.client.lhand],%obj.client.lhandcolor);
				%obj.hideNode("lhand");
				%obj.hideNode("lhook");
			}
		}
	}
	function GameConnection::applyBodyParts(%this)
	{
		Parent::applyBodyParts(%this);
		%player = %this.player;
		if(isObject(%player) && isObject(%veh = %player.getObjectMount()) && %veh.getDatablock().isSpeedkart == 1)
		{
			%player.hideNode("lhand");
			%player.hideNode("rhand");
			%player.hideNode("lhook");
			%player.hideNode("rhook");
			%veh.hideNode("lhand");
			%veh.hideNode("rhand");
			%veh.hideNode("lhook");
			%veh.hideNode("rhook");
			%veh.unhideNode($lhand[%this.lhand]);
			%veh.unhideNode($rhand[%this.rhand]);
			%veh.setNodeColor($lhand[%this.lhand],%this.lhandColor);
			%veh.setNodeColor($rhand[%this.rhand],%this.rhandColor);
		}
	}
	function Player::playThread(%player,%slot,%thread)
	{
		Parent::playThread(%player,%slot,%thread);
		%veh = %player.getObjectMount();
		%player.activeThread[%slot] = %thread;
		if(isObject(%veh) && %veh.getDatablock().isSpeedkart == 1)
		{
			if(%slot == 1)
			{
				if(%thread $= "armReadyRight")
				{
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					%player.unHideNode($rhand[%player.client.rhand]);
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.setNodeColor($lhand[%player.client.lhand],%player.client.lhandColor);
					%player.hideNode("lhand");
					%player.hideNode("lhook");
				} else if(%thread $= "armReadyLeft")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					%player.unHideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($rhand[%player.client.rhand],%player.client.rhandColor);
					%player.hideNode("rhand");
					%player.hideNode("rhook");
				} else if(%thread $= "armReadyBoth")
				{
					%veh.hideNode("lhand");
					%veh.hideNode("lhook");
					%player.unHideNode($lhand[%player.client.lhand]);
					%veh.hideNode("rhand");
					%veh.hideNode("rhook");
					%player.unHideNode($rhand[%player.client.rhand]);
				} else if(%thread $= "root")
				{
					%player.hideNode("lhand");
					%player.hideNode("rhand");
					%player.hideNode("lhook");
					%player.hideNode("rhook");
					%veh.unhideNode($lhand[%player.client.lhand]);
					%veh.unhideNode($rhand[%player.client.rhand]);
					%veh.setNodeColor($lhand[%player.client.lhand],%player.client.lhandColor);
					%veh.setNodeColor($rhand[%player.client.rhand],%player.client.rhandColor);
				}
			}
		}
	}
};
activatepackage(SpeedKartHandPackage);

//exec("add-ons/vehicle_speedkart/server.cs");

function SpeedKartSpeedCheck(%this, %obj)
{
	if(!isObject(%obj))
		return;

	%vehicle = %obj;
	%datablock = %vehicle.getDatablock();
%slot = 0; //Play the sound in the driver's spot
	%speed = vectorLen(%obj.getVelocity());

	if(%speed < 0) //Keeps throwing random negative numbers when train is at dead stop
	    %speed = 0;

	if(%speed < 10)
	{
	    if(%datablock.speedCartIdleSound !$= "")
		{
			%vehicle.playAudio(%slot, %datablock.speedCartIdleSound);
		} 
		else{
			if(isObject(SpeedKartIdleSound))
			{
				%vehicle.playAudio(%slot, SpeedKartIdleSound);	
			}	
		}  
	}
	else{
		if(%datablock.speedCartIdleSound !$= "")
		{
			%vehicle.playAudio(%slot, %datablock.speedCartDriveSound);
		}
		else{
			if(isObject(SpeedKartGoSound))
			{
				%vehicle.playAudio(%slot, SpeedKartGoSound);	
			}	
		}
	}


	schedule(500,0,"SpeedKartSpeedCheck",%this,%obj);
}

function SpeedKartformulavehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Formula sounds
datablock AudioProfile(SpeedKartFormulaDriveSound)
{
   filename    = "./SpeedKartHyperion_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartFormulaIdleSound)
{
   filename    = "./SpeedKartHyperion_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartFormulaHornSound)
{
   filename    = "./SpeedKartFormula_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartformulaVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartformula.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Formula";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartFormulaIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartFormulaDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartFormulaHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartClassicvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");

	SpeedKartSpeedCheck(%this, %obj);	
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

datablock WheeledVehicleData(SpeedKartClassicVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartClassic.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Classic";
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKart64vehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

datablock WheeledVehicleData(SpeedKart64Vehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKart64.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart 64";
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
	defaultTire	= SpeedKart64Tire;
};


function SpeedKartBlockovehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

datablock WheeledVehicleData(SpeedKartBlockoVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartBlocko.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Blocko";
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
	defaultTire	= SpeedKartBlockoTire; //You need to specify the wheel datablock here if it is any different from the regular speedkart's ~Barna
}; //a semi colon was missing here ~Barna


function SpeedKart7vehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

datablock WheeledVehicleData(SpeedKart7Vehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKart7.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart 7";
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartLeMansvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}

datablock WheeledVehicleData(SpeedKartLeMansVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartLeMans.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart LeMans";
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};

function SpeedKartHovervehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("hoverKartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("hoverKartSmokeTwoImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Hover sounds
datablock AudioProfile(SpeedKartHoverDriveSound)
{
   filename    = "./SpeedKartHover_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHoverIdleSound)
{
   filename    = "./SpeedKartHover_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHoverHornSound)
{
   filename    = "./SpeedKartHover_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartHoverVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartHover.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Hover";
	
	//Tire emitter
	tireEmitter = "KartSmokeEmitter";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartHoverIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartHoverDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartHoverHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
	defaultTire	= SpeedKartHoverTire;
};

function SpeedKartMusclevehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Muscle sounds
datablock AudioProfile(SpeedKartMuscleDriveSound)
{
   filename    = "./SpeedKartMuscle_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartMuscleIdleSound)
{
   filename    = "./SpeedKartMuscle_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartMuscleHornSound)
{
   filename    = "./SpeedKartMuscle_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartMuscleVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartMuscle.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Muscle";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartMuscleIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartMuscleDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartMuscleHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartHyperionvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Hyperion sounds
datablock AudioProfile(SpeedKartHyperionDriveSound)
{
   filename    = "./SpeedKartHyperion_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHyperionIdleSound)
{
   filename    = "./SpeedKartHyperion_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHyperionHornSound)
{
   filename    = "./SpeedKartHyperion_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartHyperionVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartHyperion.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Hyperion";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartHyperionIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartHyperionDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartHyperionHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartHotRodvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//HotRod sounds
datablock AudioProfile(SpeedKartHotRodDriveSound)
{
   filename    = "./SpeedKartHotRod_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHotRodIdleSound)
{
   filename    = "./SpeedKartHotRod_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartHotRodHornSound)
{
   filename    = "./SpeedKartHotRod_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartHotRodVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartHotRod.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart HotRod";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartHotRodIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartHotRodDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartHotRodHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};

function SpeedKartBuggyvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Buggy sounds
datablock AudioProfile(SpeedKartBuggyDriveSound)
{
   filename    = "./SpeedKart_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartBuggyIdleSound)
{
   filename    = "./SpeedKart_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartBuggyHornSound)
{
   filename    = "./SpeedKartBuggy_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartBuggyVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartBuggy.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Buggy";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartBuggyIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartBuggyDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartBuggyHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};

function SpeedKartLeMansvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//LeMans sounds
datablock AudioProfile(SpeedKartLeMansDriveSound)
{
   filename    = "./SpeedKartLeMans_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartLeMansIdleSound)
{
   filename    = "./SpeedKartLeMans_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartLeMansHornSound)
{
   filename    = "./SpeedKartLeMans_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartLeMansVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartLeMans.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart LeMans";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartLeMansIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartLeMansDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartLeMansHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartClassicGTvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//ClassicGT sounds
datablock AudioProfile(SpeedKartClassicGTDriveSound)
{
   filename    = "./SpeedKartClassicGT_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartClassicGTIdleSound)
{
   filename    = "./SpeedKartClassicGT_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartClassicGTHornSound)
{
   filename    = "./SpeedKartClassicGT_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartClassicGTVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartClassicGT.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart ClassicGT";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartClassicGTIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartClassicGTDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartClassicGTHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartVintagevehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	//%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Vintage sounds
datablock AudioProfile(SpeedKartVintageDriveSound)
{
   filename    = "./SpeedKartVintage_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartVintageIdleSound)
{
   filename    = "./SpeedKartVintage_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartVintageHornSound)
{
   filename    = "./SpeedKartVintage_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartVintageVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartVintage.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Vintage";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartVintageIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartVintageDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartVintageHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};


function SpeedKartJeepvehicle::onadd(%this,%obj)
{ 
	parent::onadd(%this,%obj);
	   %obj.playthread(0,"propslow");
	
	SpeedKartSpeedCheck(%this, %obj);
	
	//Smoke
	%obj.mountImage("KartSmokeImage", 0, true, "");
	
	//Only keep this if there are two exhausts.
	//%obj.mountImage("KartSmokeSecondImage", 1, true, "");
	
	//Hand things
	%obj.hideNode(lhand);
	%obj.hideNode(rhand);
	%obj.hideNode(lhook);
	%obj.hideNode(rhook);
}
//========================
//========================
//INSTRUCTIONS
//========================
//========================

//Jeep sounds
datablock AudioProfile(SpeedKartJeepDriveSound)
{
   filename    = "./SpeedKart_Go.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartJeepIdleSound)
{
   filename    = "./SpeedKart_idle.wav";
   description = AudioCloseLooping3d;
   preload = true;
};

datablock AudioProfile(SpeedKartJeepHornSound)
{
   filename    = "./SpeedKartJeep_horn.wav";
   description = AudioClose3d;
   preload = true;
};

datablock WheeledVehicleData(SpeedKartJeepVehicle : SpeedKartVehicle)
{
	category = "Vehicles";
	//- Render -
	shapeFile = "./SpeedKartJeep.dts";
	emap = true;
	//- Vehicle Data -
	uiName = "SpeedKart Jeep";
	
	//IDLE SOUND
	speedCartIdleSound = SpeedKartJeepIdleSound;
	
	//DRIVING SOUND
	speedCartDriveSound = SpeedKartJeepDriveSound;
	
	//HORN SOUND
	speedCartHornSound = SpeedKartJeepHornSound;
	
	//Just add the datablock variables above to any kart with the appropriate sound. It will then play that sound when that kart is used
	finalExplosionProjectile = SpeedKartFinalExplosionProjectile;
};