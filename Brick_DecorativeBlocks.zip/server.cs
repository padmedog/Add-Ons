datablock fxDTSBrickData(brick1x2BlockData)
{
	brickFile = "./1x2Block.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "1x2 Cement";
	iconName = "Add-Ons/Brick_DecorativeBlocks/1x2Block";
};

datablock fxDTSBrickData(brick1x1BlockData)
{
	brickFile = "./1x1Block.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "1x1 Cement";
	iconName = "Add-Ons/Brick_DecorativeBlocks/1x1Block";
};

datablock fxDTSBrickData(brick1x2FBlockData)
{
	brickFile = "./1x2FBlock.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "1x2F Cement";
	iconName = "Add-Ons/Brick_DecorativeBlocks/1x2FBlock";
};

datablock fxDTSBrickData(brick1x1FBlockData)
{
	brickFile = "./1x1FBlock.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "1x1F Cement";
	iconName = "Add-Ons/Brick_DecorativeBlocks/1x1FBlock";
};

datablock fxDTSBrickData(brick2x2PictureFrameData)
{
	brickFile = "./2x2PictureFrame.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "2x2 Picture Frame";
	iconName = "Add-Ons/Brick_DecorativeBlocks/2x2PictureFrame";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick16x16FRoadData)
{
	brickFile = "./16x16FRoad.blb";
	category = "Baseplates";
	subCategory = "Road";
	uiName = "16x16F Road";
	iconName = "add-ons/Brick_DecorativeBlocks/16x16FRoad";
};

datablock fxDTSBrickData(brick3x3x2binlidData)
{
	brickFile = "./3x3x2binlid.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "3x3x2 Lid";
	iconName = "add-ons/Brick_DecorativeBlocks/3x3x2binlid";
                   collisionShapeName = "./3x3x2binlid.dts";
                   Orientationfix=1;
};

datablock fxDTSBrickData(brick3x3x6binData)
{
	brickFile = "./3x3x6bin.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "3x3x6 Bin";
	iconName = "add-ons/Brick_DecorativeBlocks/3x3x6bin";
                   collisionShapeName = "./3x3x6bin.dts";
};

datablock fxDTSBrickData(brick3x4x5VendingMachineData)
{
	brickFile = "./3x4x5VendingMachine.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "3x4x5 Pop Machine";
	iconName = "add-ons/Brick_DecorativeBlocks/VendingMachine";

                   hasPrint = 1;
	printAspectRatio = "2x2f";
                   Orientationfix=1;
};

datablock fxDTSBrickData(brick1x1CupData)
{
	brickFile = "./1x1Cup.blb";
	category = "Special";
	subCategory = "Decorative";
	uiName = "1x1 Cup";
	iconName = "add-ons/Brick_DecorativeBlocks/1x1Cup";
                  collisionshapename="base/data/shapes/bricks/1x1Round.dts";
};