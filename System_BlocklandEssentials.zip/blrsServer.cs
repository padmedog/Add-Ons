$blrs::pref::port = 28000;
$blrs::pref::maxclients = 15;
$blrs::pref::password = "";

$blrs::serverVersion = 1;

if(!isObject(blrsServer))
{
        new TCPObject(blrsServer);
	blrsServer.listen($blrs::pref::port);
}

function servercmdblrsport(%client,%port)
{
	if(%client.isAdmin || %client.isSuperAdmin)
	{
		if(isObject(blrsServer))
			blrsServer.delete();
		$blrs::pref::port = %port;
		new TCPObject(blrsServer);
		blrsServer.listen($blrs::pref::port);
		talk("BLRS port changed to: " @ $blrs::pref::port);
	}
	else
		messageclient(%client,'',"You need to be admin!");
}

function blrsServer::onConnectRequest(%this,%address,%id)
{
	echo("CONREQ " @ %address SPC %id);
        %client = new TCPObject(blrsClient,%id).getID();
	for(%a=0; %a<$blrs::pref::maxclients; %a++)
	{
		if(!isObject($blrs::client[%a]))
		{
			$blrs::client[%a] = %client;
			$blrs::client[%a].send("VERSION" TAB $blrs::serverVersion @ "\n");
			return;
		}
	}
}

function blrscmdNEXTTRACK(%sender)
{
	if(isFunction("SK_NextTrack"))
	{
		SK_NextTrack();
		messageall('',"<color:FFFF00>BLRS has changed the track!");
		%sender.send("WORKED\t\n");
	}
	else
		%sender.send("WRONG\t\n");
}

function blrscmdCLEARBOTS(%sender)
{
	if(!isObject(mainHoleBotSet))
		return;

	for(%a = mainHoleBotBrickSet.getCount()-1; %a >= 0; %a--)
	{
		%obj = mainHoleBotBrickSet.getObject(%a);
		cancel(%obj.hModS);
	        %obj.hModS = 0;
		if(isObject(%obj.hBot))
		{
			%obj.hBot.delete();
        		%obj.hBot = 0;
		}
	        if(!%obj.hBotType.hManualSpawn)
   			%obj.spawnHoleBot();
	}

	%sender.send("WORKED\t\n");
	messageall('',"<color:FFFF00>BLRS has reset all bots!");
}

function blrscmdCAB(%sender,%arg1)
{
	messageall('',"<color:FFFF00>BLRS has cleared all bricks!");
	for(%a=0;%a<mainBrickGroup.getCount();%a++)
	{
		%brickGroup = mainBrickGroup.getObject(%a);
		if(isObject(%brickGroup))
		{
			if(%brickGroup.getCount() > 0)
			{
				for(%b=0;%b<%brickGroup.getCount();%b++)
				{
					%brick = %brickGroup.getObject(%b);
					if(isObject(%brick))
						%brick.delete();
				}
			}
		}
	}
	
	%sender.send("WORKED\n");
}

function blrscmdDEADMIN(%sender,%arg1)
{
	%client = findclientbybl_id(%arg1);
	if(!isObject(%client))
	{
		%sender.send("NOTFOUND\n");
		return;
	}

	%client.isAdmin = 0;
	messageall('',"<color:FFFF00>BLRS has made <color:00FF00>" @ %client.name @ "<color:FFFF00> no longer an admin."); 

	%sender.send("WORKED\n");
}

function blrscmdADMIN(%sender,%arg1)
{
	%client = findclientbybl_id(%arg1);
	if(!isObject(%client))
	{
		%sender.send("NOTFOUND\n");
		return;
	}

	%client.isAdmin = 1;
	commandtoclient(%client,'adminsuccess');
	commandtoclient(%client,'setAdminLevel',1);	
	messageall('MsgAdminForce',"<color:FFFF00>BLRS has made <color:00FF00>" @ %client.name @ "<color:FFFF00> an admin."); 

	%sender.send("WORKED\n");
}

function blrscmdCPB(%sender,%arg1,%arg2)
{
	%client = findclientbybl_id(%arg1);
	if(!isObject(%client))
	{
		%sender.send("NOTFOUND\n");
		return;
	}

	messageall('',"<color:FFAA00>BLRS has forced <color:00FF00>" @ %client.name @ "<color:FFAA00> to clear their own bricks!");
	servercmdclearbricks(%client);
	%sender.send("WORKED\n");
}


function blrscmdBAN(%sender,%arg1,%arg2)
{
	%client = findclientbybl_id(%arg1);
	if(!isObject(%client))
	{
		%sender.send("NOTFOUND\n");
		return;
	}

	banBLID(%client.bl_id,%arg2,"BLRS");
	messageall('',"<color:FFAA00>BLRS has banned <color:00FF00>" @ %client.name);
	%sender.send("WORKED\n");
}

function blrscmdMUTE(%sender,%arg1)
{
	%client = findclientbybl_id(%arg1);
	if(!isObject(%client))
	{
		%sender.send("NOTFOUND\n");
		return;
	}

	%client.muted = true;
	messageall('',"<color:FFAA00>BLRS has muted <color:00FF00>" @ %client.name);
	%sender.send("WORKED\n");
}

function blrscmdUNMUTE(%sender,%arg1)
{
	%client = findclientbybl_id(%arg1);
	if(!isObject(%client))
	{
		%sender.send("NOTFOUND\n");
		return;
	}

	%client.muted = false;
	messageall('',"<color:FFAA00>BLRS has unmuted <color:00FF00>" @ %client.name);
	%sender.send("WORKED\n");
}

function BLRS_AuthCommand(%sender,%command,%arg1,%arg2,%arg3)
{
	if(isFunction("blrscmd" @ %command))
	{
		call("blrscmd" @ %command,%sender,%arg1,%arg2,%arg3);
	}
		//old bad way of doing it
		//eval("blrscmd" @ %command @ "(" @ %sender @ ",\"" @ %arg1 @ "\",\"" @ %arg2 @ "\",\"" @ %arg3 @ "\");");	
}

function blrsClient::onLine(%this,%line)
{
	%id = -1;
	for(%a=0; %a<$blrs::pref::maxclients; %a++)
	{
		if($blrs::client[%a] == %this)
		{
			%id = %a;
			break;
		}
	}

	if(%id == -1)
	{
		echo("Invalid socket, returning!");
		return;
	}

	if(getField(%line,0) $= "PASS")
	{
		if($blrs::pref::password $= "")
		{
			%this.send("PASS\tNONE\n");
			echo("(blrs) No password set.");
			return;
		}
		else if(getField(%line,1) $= $blrs::pref::password)
		{
			%this.send("PASS\tOKAY\n");
			echo("(blrs) Password correct!");
			$blrs::auth[%id] = true;
		}
		else
		{
			%this.send("PASS\tBAD\n");
			echo("(blrs) Password incorrect!");
			return;
		}
	}

	else if(getField(%line,0) $= "PLAYERS")
	{
		if($blrs::version[%id] < 0.7)
		{
		%str = "PLAYERS" TAB clientGroup.getCount();
		for(%a=0;%a<clientGroup.getCount();%a++)
		{
			%client = clientGroup.getObject(%a);
			%colorname = %client.name;
			if(%client.isAdmin || %client.isSuperAdmin)
				%colorname = "\c5" @ %colorname;
			%str = %str TAB %colorname TAB %client.bl_id;
			%player = %client.player;
			if(isObject(%player))
			{
				%str = %str TAB %player.position TAB 100-%player.getDamageLevel() TAB %player.tool[%player.currTool].uiName;
			}
			else
			{
				%str = %str TAB "DEAD" TAB "DEAD" TAB "DEAD";
			}
		}
		%str = %str @ "\n";
		%this.send(%str);
		}
		else
		{
		%str = "PLAYERS" TAB clientGroup.getCount();
		for(%a=0;%a<clientGroup.getCount();%a++)
		{
			%client = clientGroup.getObject(%a);
			%colorname = %client.name;
			if(%client.isAdmin || %client.isSuperAdmin)
				%colorname = "\c5" @ %colorname;
			%str = %str TAB %colorname TAB %client.bl_id;
			%player = %client.player;
			if(isObject(%player))
			{
				%str = %str TAB %player.position TAB 100-%player.getDamageLevel() TAB %player.tool[%player.currTool].uiName TAB %client.brickGroup.getCount();
			}
			else
			{
				%str = %str TAB "DEAD" TAB "DEAD" TAB "DEAD" TAB %client.brickGroup.getCount();
			}
		}
		%str = %str @ "\n";
		%this.send(%str);
		}
	}

	else if(getField(%line,0) $= "VERSION")
	{
		$blrs::version[%id] = getField(%line,1);
		%theirs = getField(%line,1);
		%latest = $blrs::latestClient;
		if(%theirs < %latest)
			%this.send("MSG\tYou are running an old version of BLRS client, please update to " @ $blrs::latestClient @ "\t\n");
	}

	else if(getField(%line,0) $= "SHOUT")
	{
		if($blrs::auth[%id])
		{
			messageall('',"<color:FFAA00>BLRS: " @ getField(%line,1));
			%this.send("WORKED\n");
		}
		else
		{
			%this.send("NEEDAUTH\n");
		}
	}

	else if(getField(%line,0) $= "WARN")
	{
		if($blrs::auth[%id])
		{
			%blid = getField(%line,1);
			%client = findClientbybl_id(%blid);
			if(isObject(%client))
			{
				messageclient(%client,'',"<color:FFAA00>BLRS Private: " @ getField(%line,2));
				%this.send("WORKED\n");
			}
			else
			{
				%this.send("NOTFOUND\n");
			}
		}
		else
		{
			%this.send("NEEDAUTH\n");
		}
	}

	else if(getField(%line,0) $= "KICK")
	{
		if($blrs::auth[%id])
		{
			%playername = getField(%line,1);
			%client = findclientbybl_id(%playername);
			if(!isObject(%client))
			{
				%this.send("NOTFOUND\n");
				return;
			}
			else
			{
				messageall('',"<color:00FF00>" @ %client.name SPC "<color:FFFF00>was kicked by remote admin.");
				%client.delete("Kicked by remote admin.");
				%this.send("WORKED\n");
			}
		}
		else
		{
			%this.send("NEEDAUTH\n");
		}
	}

	else if(getField(%line,0) $= "KILL")
	{
		if($blrs::auth[%id])
		{
			%playername = getField(%line,1);
			%client = findclientbybl_id(%playername);
			if(!isObject(%client))
			{
				%this.send("NOTFOUND\n");
				return;
			}
			else
			{
				%player = %client.player;
				if(isObject(%player))
					%player.kill();	
				%this.send("WORKED\n");
			}
		}
		else
		{
			%this.send("NEEDAUTH\n");
		}
	}

	else if($blrs::auth[%id])
		BLRS_AuthCommand(%this,getField(%line,0),getField(%line,1),getField(%line,2),getField(%line,3));
	else
		%this.send("NEEDAUTH\n");
}

function blrsClient::onDisconnect(%this)
{
	for(%a=0; %a<$blrs::pref::maxclients; %a++)
	{
		if($blrs::client[%a] == %this)
		{
			$blrs::client[%a] = -1;
			$blrs::auth[%a] = false;
			$blrs::version[%a] = 0.4;
		}
	}
	%this.delete();
}

function sendPacket(%this)
{
	for(%a=0; %a<$blrs::pref::maxclients; %a++)
		if(isObject($blrs::client[%a]))
			$blrs::client[%a].send(%this @ "\n");
}

package blrsMain
{
	function servercmdmessagesent(%client,%message)
	{
		if(%client.muted)
		{
			messageclient(%client,'',"You are muted and can not talk!");
			return;
		}
		parent::servercmdmessagesent(%client,%message);
		sendPacket("CHAT" TAB %client.name TAB %message);
	}
	function GameConnection::OnDeath(%client, %killerPlayer, %killer, %damageType, %damageLoc)
	{
		parent::OnDeath(%client, %killerPlayer, %killer, %damageType, %damageLoc);
		sendPacket("DEAD" TAB %client.name);
	}
	function servercmdclearbricks(%client)
	{
		parent::servercmdclearbricks(%client);
		sendPacket("CLEARBRICKS" TAB %client.name);
	}
	function servercmdclearallbricks(%client)
	{
		parent::servercmdclearallbricks(%client);
		sendPacket("CLEARALLBRICKS" TAB %client.name);
	}
	function gameConnection::autoAdminCheck(%client)
	{
		sendPacket("JOIN" TAB %client.name);
		return parent::autoAdminCheck(%client);
	}
	function gameConnection::onClientLeaveGame(%client)
	{
		sendPacket("LEAVE" TAB %client.name);
		parent::onClientLeaveGame(%client);
	}
};
activatepackage(blrsMain);


function servercmdblrspassword(%client,%password)
{
	if(%client.isSuperAdmin)
	{
		$blrs::pref::password = %password;
		messageall('',"<color:FFFF00>The BLRS password has been changed.");	
	}
	else
		messageclient(%client,'',"You must be super admin to do that!");
}

if(!$blrsversionGetter)
	exec("./versionGetter.cs");
