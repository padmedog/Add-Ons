$pref::Zombies::Difficulty = 1;
//AddDamageType("zombiebite",   '<bitmap:add-ons/gamemode_zombie/ZombieCi> %1',    '%2 <bitmap:add-ons/gamemode_zombie/ZombieCi> %1',0.2,1);
function ZombieDefault::onCollision(%this, %obj, %col, %fade, %pos, %norm)
{
	if(%obj.getclassname() $= "Player")
	{
		return;
	}
	//%col.iszombie || 
	if(isobject(%obj) && %obj.getclassname() $= "AiPlayer" && %obj.isGoodGuy && %col.getclassname() $= "Player" && %col.isdowned && %obj.lasttimehelper+5000 < getsimtime() && %obj.getdatablock().doNotSavePlayer != 1 && %obj.spawnbrick.getgroup().client.tdmTeam == %col.client.tdmTeam)
	{
		%col.isdowned = 0;
		%col.changedatablock(%col.lastknowndatablock);
		%col.sethealth(100);
		%col.temporaryHPSet = 75;
		%col.doHPBleed();
		%col.playthread(0,root);
		%col.unmountimage(2);

		%col.client.centerprint("<color:AAFFAA>You were saved by " @ %obj.name,5);
		cancel(%col.energydeath);
		%col.mountimage(LoveImage,2);
		%obj.lasttimehelper = getsimtime();
	}
	if(MinigameIncludesPlayerBricks(%obj) == 0 || %obj.spawnbrick.getgroup().client.minigame.EnableZombies == 0 || $pref::Server::ZombiesEnabled == 0)
	{
		return;
	}
	if(%col.getclassname() $= "player" || %col.getclassname() $= "AiPlayer")
	{
		if(%obj.getstate() !$= "Dead" && %col.getstate() !$= "Dead" && %obj.ZTeam !$= %col.ZTeam)
		{
			if(IsInMinigame(%obj) && IsInSameMinigame(%col,%obj))
			{
				if(%obj.isgoodguy == 1 && %col.getclassname() $= "Player" && %obj.spawnbrick.getgroup().client.tdmTeam == %col.client.tdmTeam) return;
				if(%obj.isgoodguy == 1 && %col.isgoodguy == 1 && %obj.spawnbrick.getgroup().client.tdmTeam == %col.spawnbrick.getgroup().client.tdmTeam) return;

				%col.downer = %obj;
				//%obj.minigame = %obj.spawnbrick.getgroup().client.minigame;
				%obj.playthread(2,activate2);
				%obj.playaudio(1,ZombieAttackSound);
				%obj.addhealth(%obj.getdatablock().attackpower/2);
				%fdam = %obj.getdatablock().attackpower;
				if(%obj.minigame.zombieDifficulty $= "Easy")
				{
					%fdam = %obj.getdatablock().attackpower/3;
				}
				if(%obj.minigame.zombieDifficulty $= "Hard")
				{
					%fdam = %obj.getdatablock().attackpower*2;
				}
				%col.damage(%obj,0,%fdam,$DamageType::zombiebite);
				//%color = %obj.getdatablock().skincolor;
				if(%obj.getdatablock().NoBloodyHands != 1)
				{
					%color = "0.8 0 0 1";
					%obj.setNodecolor($rhand[0], %color);
					%obj.setNodecolor($lhand[0], %color);
					cancel(%obj.handcolorsc);
					%obj.handcolorsc = schedule(5000,0,delayhandcolors,%obj);
				}
				//chatmessageteam(%col.client,'fakeblah',"WOAH WOAH WOAH");
				if(%col.client != 0)
				{
					%obj.cols = %col.client;
				}
				if(%col.isdowned == 1)
				{
					//%col.downer = %obj;
					//echo("WOoooooooooooooo");
					//chatMessageTeam(%col.client,'fakedeathmessage',"Zombie" SPC %obj.name SPC "Downed <bitmapk:add-ons/gamemode_zombie/zombieci>" SPC %obj.name);
				}
				if(%col.getstate() $= "Dead" && !%col.displayeddeath && %col.getclassname() !$= "AiPlayer")
				{
					%col.displayeddeath = 1;
					//echo(%col.client);
					//messageall('fakedeathmessage',%obj.getdatablock().uiname SPC %obj.name SPC "<bitmapk:add-ons/gamemode_zombie/zombieci>" SPC %col.client.name);
					if(getword(getdatetime(),0) $= "09/19/09")//arrrgg
					{
						chatMessageTeam(%obj.cols,'fakedeathmessage',"Pirate" SPC %obj.name SPC "<bitmapk:add-ons/gamemode_zombie/zombieci>" SPC %obj.cols.name);
						return;
					}
					chatMessageTeam(%obj.cols,'fakedeathmessage',"Zombie" SPC %obj.name SPC "<bitmapk:add-ons/gamemode_zombie/zombieci>" SPC %obj.cols.name);
					//schedule(1000,0,IsuckAtFixing,%obj,%col);
					
				}
			}
		}
	}
	if(%col.getclassname() $= "wheeledvehicle" && %obj.getstate() !$= "Dead" && minigamecandamage(%obj,%col) == 1)
	{
		%obj.playthread(2,activate2);
		%col.damage(%zomname,0,%obj.getdatablock().attackpower,$DamageType::zombiebite);
	}
	if(%col.getclassname() $= "AiPlayer" && %obj.getstate() !$= "Dead" && minigamecandamage(%obj,%col) == 1 && %col.iszombie != 1)
	{
		%obj.playthread(2,activate2);
		%col.damage(%zomname,0,%obj.getdatablock().attackpower,$DamageType::zombiebite);
	}
}
function BotShootMode(%this)
{
	if(isobject(%this) && %this.getstate() !$= "Dead")
	{
		%this.setimagetrigger(0,1);
		%this.setimagetrigger(0,0);
	}
}
function AiPlayer::SpecialAttack(%this,%onshot)
{
	%n = %this.getdatablock().getname(); 
	eval(%n @ "::SpecialAttack(%this,%onshot);");
}
function ZombieDefault::onMount(%a,%player,%vehicle,%d,%e,%f)
{
		%player.StopPlayerSearch();
		zombiedriveloop(%player);
		%player.setmovey(1);
}
function ZombieDefault::onUnMount(%a,%player,%vehicle,%d,%e,%f)
{
		%player.StartPlayerSearch();
		cancel(%player.drivesched);
		%player.clearmovex();
		%player.clearmovey();
}
function ZombieDefault::onAdd(%this,%obj)
{	
	%sdam = %obj.getdatablock().maxdamage;
	//%obj.setdamagelevel(%sdam/$pref::Zombies::Difficulty);
	//%obj.setdamagelevel(%sdam/2);
	%obj.isGoodGuy = %obj.getdatablock().isGoodGuy;
	%obj.ZTeam = %obj.getdatablock().ZombieTeam;
	//%obj.goodGuyFollow = %obj.getdatablock().goodGuyFollow;
	if(%obj.ZTeam $= "")
	{
		%obj.ZTeam = "Zombie";
	}
	%obj.iszombie = 1;
	if(%obj.getdatablock().ZNojump != 1)
	{
		%obj.mountimage(ZombieJumpImage,2);
	}
	%obj.mountimage(ZombieCrouchImage,3);
	%obj.player = %obj;
	randomidprefz(%obj);
	schedule(10,0,Zombify,%obj);
	
	
}
function ZombieDefault::ondisabled(%this,%obj)
{
	if(%obj.getclassname() $= "Player")
	{
		return;
	}
	%c = %obj.RLastA.client;

	if(%c $= "")%c = %obj.spawnbrick.getgroup().client;

	%obj.spawnbrick.onZombieDeath(%c);
	%obj.playaudio(0,zombiedeathsound);
	if(%obj.getdatablock().zDeathSound !$= "")
	{
		%obj.playaudio(0,%obj.getdatablock().zDeathSound);
	}
	%obj.stopplayersearch();
	if(%obj.minigame.zombieDirectorEnabled)
	{
		%obj.delscheds = schedule(%obj.minigame.vehiclerespawntime-500,0,ZombieSetVehicleDelay,%obj);
	}
		//cancel(%obj.delscheds);
		//%obj.spawnbrick.getgroup().client.minigame.NumZombies--;
		//%obj.spawnbrick.schedule(2000,setvehicle,"None");
		//%obj.delscheds = schedule(2000,0,ZombieSetVehicleDelay,%obj);
}
function ZombieSetVehicleDelay(%obj)
{
	if(isobject(%obj))
	{
		//%obj.spawnbrick.getgroup().client.minigame.NumZombies--;
		%obj.spawnbrick.setvehicle("None");
	}
	else
	{
		return;
	}
}
function delayhandcolors(%obj)
{
	if(isobject(%obj))
	{
	%color = %obj.getdatablock().skincolor;
	%obj.setNodecolor($rhand[0], %color);
	%obj.setNodecolor($lhand[0], %color);
	}
}
function hacktoavoiderrorsrot(%obj)
{
	if(isobject(%obj))
	{
		if(MinigameIncludesPlayerBricks(%obj) != 1 ||  %obj.spawnbrick.getgroup().client.minigame.EnableZombies == 0 || $pref::Server::ZombiesEnabled == 0)
		{	
			return;
		}
		%obj.schedule(500,StartPlayerSearch);
	}
}
function randomidprefz(%client)
{
	%localchance = getrandom(0,10);
	if(%localchance == 10)
	{
		%count = clientgroup.getcount();
		%fin = getrandom(1,%count);
		localApToClient(%client,clientgroup.getobject(%fin-1));
		return;
	}
	%rand = getRandom($ZombAP::apfinder::idcount);
	idpreftoclient(%client,$ZombAP::apfinder::ids[getRandom(%rand- 1)]);
	
}

function idpreftoclient(%client, %id)
{
	eval("%prefexist = $ZombAP::apfinder::" @ %id @ ";");
	if (isObject(%client) && %prefexist)
	{
		eval("%prefroot = \"$ZombAP::apfinder::" @ %id @ "::\";");
		eval("%client.llegColor = " @ %prefroot @ "llegColor;");
		eval("%client.secondPackColor = " @ %prefroot @ "secondPackColor;");
		eval("%client.lhand = " @ %prefroot @ "lhand;");
		eval("%client.hip = " @ %prefroot @ "hip;");
		eval("%client.faceName = " @ %prefroot @ "faceName;");
		eval("%client.gender = " @ %prefroot @ "gender;");
		eval("%client.rarmColor = " @ %prefroot @ "rarmColor;");
		eval("%client.hatColor = " @ %prefroot @ "hatColor;");
		eval("%client.hipColor = " @ %prefroot @ "hipColor;");
		eval("%client.chest = " @ %prefroot @ "chest;");
		eval("%client.rarm = " @ %prefroot @ "rarm;");
		eval("%client.packColor = " @ %prefroot @ "packColor;");
		eval("%client.pack = " @ %prefroot @ "pack;");
		eval("%client.clanPrefix = " @ %prefroot @ "clanPrefix;");
		eval("%client.clanSuffix = " @ %prefroot @ "clanSuffix;");
		eval("%client.decalName = " @ %prefroot @ "decalName;");
		eval("%client.larmColor = " @ %prefroot @ "larmColor;");
		eval("%client.secondPack = " @ %prefroot @ "secondPack;");
		eval("%client.larm = " @ %prefroot @ "larm;");
		eval("%client.chestColor = " @ %prefroot @ "chestColor;");
		eval("%client.name = " @ %prefroot @ "name;");
		eval("%client.accentColor = " @ %prefroot @ "accentColor;");
		eval("%client.rhandColor = " @ %prefroot @ "rhandColor;");
		eval("%client.rleg = " @ %prefroot @ "rleg;");
		eval("%client.rlegColor = " @ %prefroot @ "rlegColor;");
		eval("%client.accent = " @ %prefroot @ "accent;");
		eval("%client.headColor = " @ %prefroot @ "headColor;");
		eval("%client.rhand = " @ %prefroot @ "rhand;");
		eval("%client.lleg = " @ %prefroot @ "lleg;");
		eval("%client.lhandColor = " @ %prefroot @ "lhandColor;");
		eval("%client.hat = " @ %prefroot @ "hat;");
		if(getword(getdatetime(),0) $= "09/19/09")//arrrgg
		{
			%client.hat = 5;
			%arghh = getrandom(0,2);
			switch(%arghh)
			{
				case 0:
				%client.faceName = "smileyPirate1";
				case 1:
				%client.faceName = "smileyPirate2";
				case 2:
				%client.faceName = "smileyPirate3";
			}
			return;
		}
	}
}
function localApToClient(%client, %target)
{
		%client.llegColor =  %target.llegColor;
		%client.secondPackColor =  %target.secondPackColor;
		%client.lhand =  %target.lhand;
		%client.hip =  %target.hip;
		%client.faceName =  %target.faceName;
		%client.gender =  %target.gender;
		%client.rarmColor =  %target.rarmColor;
		%client.hatColor =  %target.hatColor;
		%client.hipColor =  %target.hipColor;
		%client.chest =  %target.chest;
		%client.rarm =  %target.rarm;
		%client.packColor =  %target.packColor;
		%client.pack =  %target.pack;
		%client.clanPrefix =  %target.clanPrefix;
		%client.clanSuffix =  %target.clanSuffix;
		%client.decalName =  %target.decalName;
		%client.larmColor =  %target.larmColor;
		%client.secondPack =  %target.secondPack;
		%client.larm =  %target.larm;
		%client.chestColor =  %target.chestColor;
		%client.name =  %target.name;
		%client.accentColor =  %target.accentColor;
		%client.rhandColor =  %target.rhandColor;
		%client.rleg =  %target.rleg;
		%client.rlegColor =  %target.rlegColor;
		%client.accent =  %target.accent;
		%client.headColor =  %target.headColor;
		%client.rhand =  %target.rhand;
		%client.lleg =  %target.lleg;
		%client.lhandColor =  %target.lhandColor;
		%client.hat =  %target.hat;
}
function Zombify(%obj)
{
	if(isobject(%obj))
	{
		hacktoavoiderrorsrot(%obj);
		if(%obj.getdatablock().DoNotZombify != 1)
		{
			GameConnection::ApplyBodyParts(%obj);
			GameConnection::ApplyBodyColors(%obj);
			%color = %obj.getdatablock().skincolor;
			%obj.setNodecolor($rhand[0], %color);
			%obj.setNodecolor($lhand[0], %color);
			%obj.setNodecolor("headskin", %color);
		}

		//new SimGroup (%obj.) {};
		%foo = "ZombieGroup::" @ %obj.spawnbrick.client;
		if(!isobject(%foo))
		{
			%zg = new SimSet (%foo)
			{
				
			};
			MissionCleanup.add(%zg);
		}
		%foo.add(%obj);

		%obj.tdmTeam =  %obj.spawnbrick.getgroup().client.tdmTeam;
		%obj.minigame = %obj.spawnbrick.getgroup().client.minigame;
		if(%obj.minigame.zombieDifficulty $= "Easy")
		{
			%obj.setdamagelevel(%obj.getdatablock().maxdamage/2);
		}
		if(%obj.minigame.zombieDirectorEnabled)
		{
			%obj.minigame.zombieSimSet.add(%obj);
			if(%obj.getdatablock().getname() $= "RotTankZombie" || %obj.getdatablock().getname() $= "RotWitchZombie")
			{
				%obj.delscheds = schedule($pref::Zombies::DirectorTick*1000*4,0,zombiedeletecheck,%obj,%obj.minigame);
				return;
			}
			%obj.delscheds = schedule($pref::Zombies::DirectorTick*1000,0,zombiedeletecheck,%obj,%obj.minigame);
		}
	}
}
datablock AudioProfile(ZombieAttackSound)
{
	filename = "./ZombieAttack.wav";
	description = AudioClosest3d;
	preload = true;
};
datablock AudioProfile(ZombieDeathSound)
{
	filename = "./ZombieDeath.wav";
	description = AudioClosest3d;
	preload = true;
};
datablock AudioProfile(ZombiePainSound)
{
	filename = "./ZombiePain.wav";
	description = AudioClosest3d;
	preload = true;
};
datablock AudioProfile(ZombieJumpSound)
{
	filename = "./DirectorSounds1/Silence.wav";
	description = AudioClosest3d;
	preload = true;
};
datablock AudioProfile(HelpMeSound)
{
	filename = "./HelpMe.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(HordeIncoming1Sound)
{
	filename = "./DirectorSounds1/HordeIncoming1.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(HordeIncoming2Sound)
{
	filename = "./DirectorSounds1/HordeIncoming2.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(HordeIncoming3Sound)
{
	filename = "./DirectorSounds1/HordeIncoming3.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(HordeIncoming4Sound)
{
	filename = "./DirectorSounds1/HordeIncoming4.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchCry1sound)
{
	filename = "./DirectorSounds1/witch_cry_1.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchCry2sound)
{
	filename = "./DirectorSounds1/witch_cry_2.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchCry3sound)
{
	filename = "./DirectorSounds1/witch_cry_3.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchCry4sound)
{
	filename = "./DirectorSounds1/witch_cry_4.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(DirectorGameOversound)
{
	filename = "./DirectorSounds1/GameOver.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(ZTankDiesound)
{
	filename = "./DirectorSounds1/tank_die.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(ZTankPunchsound)
{
	filename = "./DirectorSounds1/Tank_Punch.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchDeathsound)
{
	filename = "./DirectorSounds1/witch_death.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchAttack1sound)
{
	filename = "./DirectorSounds1/witch_attack_1.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(WitchAttack2sound)
{
	filename = "./DirectorSounds1/witch_attack_2.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(TankIdle1sound)
{
	filename = "./DirectorSounds1/tank_idle_1.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(TankIdle2sound)
{
	filename = "./DirectorSounds1/tank_idle_2.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(TankIdle3sound)
{
	filename = "./DirectorSounds1/tank_idle_3.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(TankIdle4sound)
{
	filename = "./DirectorSounds1/tank_idle_4.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile(TankYellsound)
{
	filename = "./DirectorSounds1/tank_yell.wav";
	description = AudioClose3d;
	preload = true;
};

datablock ExplosionData(ZBKMediumExplosion)
{
	explosionShape = "";
	soundProfile = "";

	lifeTimeMS = 1;

	particleEmitter = "";
	particleDensity = 10;
	particleRadius = 0.2;

	emitter[0] = "";

	faceViewer     = true;
	explosionScale = "1 1 1";

	shakeCamera = true;
	camShakeFreq = "6 6 6";
	camShakeAmp = "2.0 8.0 2.0";
	camShakeDuration = 0.5;
	camShakeRadius = 10.0;

	// Dynamic light
	lightStartRadius = "";
	lightEndRadius = "";
	lightStartColor = "";
	lightEndColor = "";

	damageRadius = "";
	radiusDamage = "";

	impulseRadius = 6;
	impulseForce = 1000;
};
datablock ProjectileData(ZBKMediumProjectile)
{
   projectileShapeName = "./emptymodel.dts";
   directDamage        = 0;
   directDamageType = "";
   radiusDamageType = "";
   impactImpulse	   = 0;
   verticalImpulse	   = 0;
   explosion           = ZBKMediumExplosion;
   particleEmitter     = "";
   explodeOnDeath		= 1;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 20;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 1;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 1;
   fadeDelay           = 2;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "MedTest";
};

datablock ExplosionData(ZBKSmallExplosion)
{
	explosionShape = "";
	soundProfile = "";

	lifeTimeMS = 1;

	particleEmitter = "";
	particleDensity = 10;
	particleRadius = 0.2;

	emitter[0] = "";

	faceViewer     = true;
	explosionScale = "1 1 1";

	shakeCamera = true;
	camShakeFreq = "3 3 3";
	camShakeAmp = "1 5 1";
	camShakeDuration = 0.5;
	camShakeRadius = 10.0;

	// Dynamic light
	lightStartRadius = "";
	lightEndRadius = "";
	lightStartColor = "";
	lightEndColor = "";

	damageRadius = "";
	radiusDamage = "";

	impulseRadius = 6;
	impulseForce = 1000;
};
datablock ProjectileData(ZBKSmallProjectile)
{
   projectileShapeName = "./emptymodel.dts";
   directDamage        = 0;
   directDamageType = "";
   radiusDamageType = "";
   impactImpulse	   = 0;
   verticalImpulse	   = 0;
   explosion           = ZBKSmallExplosion;
   particleEmitter     = "";
   explodeOnDeath		= 1;

   brickExplosionRadius = 2;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;             
   brickExplosionMaxVolume = 20;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 40;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 1;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 1;
   fadeDelay           = 2;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "LowTest";
};
datablock ExplosionData(ZBKLargeExplosion)
{
	explosionShape = "";
	soundProfile = "";

	lifeTimeMS = 1;

	particleEmitter = "";
	particleDensity = 10;
	particleRadius = 0.2;

	emitter[0] = "";

	faceViewer     = true;
	explosionScale = "1 1 1";

	shakeCamera = true;
	camShakeFreq = "8 8 8";
	camShakeAmp = "2.0 8.0 2.0";
	camShakeDuration = 0.5;
	camShakeRadius = 15.0;

	// Dynamic light
	lightStartRadius = "";
	lightEndRadius = "";
	lightStartColor = "";
	lightEndColor = "";

	damageRadius = "";
	radiusDamage = "";

	impulseRadius = 6;
	impulseForce = 1000;
};
datablock ProjectileData(ZBKLargeProjectile)
{
   projectileShapeName = "./emptymodel.dts";
   directDamage        = 0;
   directDamageType = "";
   radiusDamageType = "";
   impactImpulse	   = 0;
   verticalImpulse	   = 0;
   explosion           = ZBKLargeExplosion;
   particleEmitter     = "";
   explodeOnDeath		= 1;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 90;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 180;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 1;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 1;
   fadeDelay           = 2;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   uiName = "LargeTest";
};