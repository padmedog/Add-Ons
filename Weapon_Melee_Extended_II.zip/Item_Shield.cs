exec("./Support_SpecialKills.cs");

if(isFile("Add-Ons/Script_Push_Broom_Reflector/ci_reflectkill.png"))
{
   addSpecialDamageMsg("Reflected","%2 <bitmap:Add-Ons/weapon_melee_extended_II/ci_reflectKill>%3%1","<bitmap:Add-Ons/weapon_melee_extended_II/ci_reflectKill> %3%1");
   
   datablock DecalData(reflectCIcon)
   {
      textureName = "Add-Ons/Script_Push_Broom_Reflector/CI_reflectkill";
   };
}
else
{
   addSpecialDamageMsg("Reflected","%2 <bitmap:Add-Ons/weapon_melee_extended_II/ci_reflectKill>%3%1","<bitmap:Add-Ons/weapon_melee_extended_II/ci_reflectKill> %3%1");
   
   datablock DecalData(reflectCIcon)
   {
      textureName = "./CI_reflectkill";
   };
}

function isSpecialKill_Reflected(%this,%sourceObject,%sourceClient,%mini)
{
   return (%sourceObject.reflectTime > 0);
}

datablock AudioProfile(ShieldBreakSound)
{
   filename    = "./snap.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ShieldHit1Sound)
{
   filename    = "./shield_twang.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ShieldHit2Sound)
{
   filename    = "./shield_bing.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ExplosionData(shieldRiotHitTTExplosion : hammerExplosion)
{
   soundProfile = meleeHammerSound;
   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.1;
   camShakeRadius = 6.0;
};

datablock DebrisData(shieldRiotTTDebris)
{
    shapeFile = "./riot_shield.dts";
    lifetime = 4.0;
    minSpinSpeed = -1600.0;
    maxSpinSpeed = 1200.0;
    spinSpeed        = 1100.0;
    elasticity = 0.5;
    friction = 0.2;
    numBounces = 8;
    staticOnMaxBounce = true;
    snapOnMaxBounce = false;
    fade = true;

    gravModifier = 6;
};

//projectile
datablock ProjectileData(shieldRiotTTBashProjectile)
{
   //projectileShapeName = "~/data/shapes/arrow.dts";
   directDamage        = 70;
   impactImpulse       = 2300;
   verticalImpulse     = 300;
   explosion           = shieldRiotHitTTExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 120;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 66;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "T+T Riot Shield Bash";
};


datablock ExplosionData(shieldRiotTTExplosion)
{
   explosionShape = "";
   soundProfile = shieldBreakSound;

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   debris = shieldRiotTTDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 180;
   debrisVelocity = 30;
   debrisVelocityVariance = 8;

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.1;
   camShakeRadius = 6.0;

   damageRadius = 1;
   radiusDamage = 0;
};

datablock ProjectileData(shieldRiotTTProjectile)
{
   //projectileShapeName = "~/data/shapes/arrow.dts";
   directDamage        = 10;
   impactImpulse       = 2300;
   verticalImpulse     = 300;
   explosion           = shieldRiotTTExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 66;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ShapeBaseImageData(ShieldRiotTTImage)
{
   // Basic Item properties
   shapeFile = "./Riot_shield.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = ""; //"-0.03 0.4 -0.8"; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );
   eyeRotation = "";
   scale = "1 1 1";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this Weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = " ";
   ammo = " ";
   projectile = shieldRiotTTBashProjectile;
   projectileType = "Projectile";

   casing = "";
   //shellExitDir        = "1.0 -1.3 1.0";
   //shellExitOffset     = "0 0 0";
   //shellExitVariance   = 15.0;   
   //shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = false;
   colorShiftColor = "0.5 0.5 0.5 1";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
   stateName[0]                     = "Activate";
   stateTimeoutValue[0]             = 0.3;
   stateScript[0]                  = "onActivate";
   stateTransitionOnTimeout[0]       = "Ready";
   stateSound[0]               = WeaponSwitchSound;

   stateName[1]                     = "Ready";
   stateSequence[1]                 = "Ready";
   stateTransitionOnTriggerDown[1]  = "PreFire";
   stateAllowImageChange[1]         = true;
   
   stateName[2]			= "PreFire";
   stateScript[2]                  = "onPreFire";
   stateAllowImageChange[2]        = false;
   stateTimeoutValue[2]            = 0.1;
   stateTransitionOnTimeout[2]     = "Fire";
   
   stateName[3]                    = "Fire";
   stateTransitionOnTimeout[3]     = "CheckFire";
   stateTimeoutValue[3]            = 0.3;
   stateFire[3]                    = true;
   stateSound[3]			= tf2MeleeSwingSound;
   stateAllowImageChange[3]        = false;
   stateSequence[3]                = "Fire";
   stateScript[3]                  = "onFire";
   stateWaitForTimeout[3]		= true;
   
   stateName[4]			= "CheckFire";
   stateTransitionOnTriggerDown[4]	= "PreFire";
   stateTransitionOnTriggerUp[4]	= "Ready";
};

function ShieldRiotTTImage::onActivate(%this,%obj,%slot)
{
	%obj.playthread(2, armReadyBoth);
}

function shieldRiotTTImage::onUnMount(%this,%obj,%slot)
{
   Parent::onUnMount(%this, %obj, %slot);
		%obj.playThread(2, root);
}

function ShieldRiotTTImage::onPrefire(%this,%obj,%slot)
{
	%obj.playthread(2, shiftUp);
}

function ShieldRiotTTImage::onFire(%this,%obj,%slot)
{
	Parent::onfire(%this,%obj,%slot);
	%obj.playthread(2, shiftDown);
}

datablock ItemData(RiotTTShieldItem)
{
   category = "Weapon";  // Mission editor category
   className = "Weapon"; // For inventory system
   
    // Basic Item Properties
   shapeFile = "./Riot_shield.dts";
   rotate = false;
   mass = 1;
   density = 0.2;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;
   
   //gui stuff
   uiName = "Riot Shield";
   iconName = "./Riotshield";
   doColorShift = false;
   colorShiftColor = "0.5 0.5 0.5 1.000";
   
    // Dynamic properties defined by the scripts
   image = shieldRiotTTImage;
   canDrop = true;
};

package Shield
{
   function ProjectileData::damage(%this,%obj,%col,%fade,%pos,%normal) 
   {
      %shielded = 0;
      if(%col.getType() & $TypeMasks::PlayerObjectType)
      {
         %image0 = %col.getMountedImage(0);
         %image1 = %col.getMountedImage(1);
         %image2 = %col.getMountedImage(2);
         %state0 = %col.getImageState(0);
         
         %scale = getWord(%col.getScale(),2);
         
         %fvec = %col.getForwardVector();
         %fX = getWord(%fvec,0);
         %fY = getWord(%fvec,1);
         
         %evec = %col.getEyeVector();
         %eX = getWord(%evec,0);
         %eY = getWord(%evec,1);
         %eZ = getWord(%evec,2);
         
         %eXY = mSqrt(%eX*%eX+%eY*%eY);
         
         %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
         
         if(%image0 == shieldRiotTTImage.getID() && %state0 $= "Ready")
         {
            if(%eZ > 0.75)
               %shielded = (getword(%pos, 2) > getword(%col.getWorldBoxCenter(),2) - 3.3*%scale);
            else if(%ez < -0.75)
               %shielded = (getword(%pos, 2) < getword(%col.getWorldBoxCenter(),2) - 4.4*%scale);
            else
               %shielded = (vectorDot(vectorNormalize(%obj.getVelocity()),%aimVec) < 0);
            
            %damageScale = 0.05;
            %reflect = 1;
            %reflectVector = %aimVec;
            %reflectPoint = vectorAdd(%col.getHackPosition(),vectorScale(%reflectVector,vectorLen(%col.getVelocity())/5+1));
            %impulseScale = 0.3;
            if(%shielded)
               %col.spawnExplosion(hammerProjectile,getWord(%col.getScale(),2));
         }
      }
      
      if(getSimTime() - %obj.reflectTime < 500) %reflect = 0;
      
      if(%shielded)
      {
 if(!%col.shieldset){
    %col.shieldset=1;
    %col.shieldhp = 20;
 }
 %col.shieldhp--;
 echo(%col.shieldhp);
 if(%col.shieldhp<=0){
    %col.shieldset=0;
            %i=0;
    while(%i<%col.getDatablock().maxTools){
       %t = %col.tool[%i].getID();
       if(%t == nametoid("RiotTTShieldItem")){
          %col.tool[%i]="";
          messageclient(%col.client,'MsgItemPickup','',%i,"");
          if(%col.currtool==%i){
             %col.unmountImage(0);
             %col.spawnExplosion(shieldRiotTTProjectile,getWord(%col.getScale(),2));
             %col.updateArm(0);
          }
          break;
       }
       %i++;
    }
 }

         //cancel radius damage on %obj
         %obj.damageCancel[%col] = 1;
         %obj.impulseScale[%col] = %impulseScale;
	%sound = getRandom(1,3);
	switch(%sound)
{
	case 1:
            serverPlay3D(shieldHit2Sound,%pos);
	case 2:
            serverPlay3D(shieldHit1Sound,%pos);
	case 3:
            serverPlay3D(shieldHit1Sound,%pos);
	default:
		echo("Invalid Sound");
}
         
         if(%reflect)
         {
            %scaleFactor = getWord(%obj.getScale(), 2);
            %pos = %reflectPoint;
            %vec = vectorScale(%reflectVector,vectorLen(%obj.getVelocity()));
            %vel = vectorAdd(%vec,vectorScale(%col.getVelocity(),%obj.dataBlock.velInheritFactor));
            %p = new Projectile()
            {
               dataBlock = %obj.dataBlock;
               initialPosition = %pos;
               initialVelocity = %vel;
               sourceObject = %obj;
               client = %col.client;
               sourceSlot = 0;
               originPoint = %pos;
               reflectTime = getSimTime();
            };
            MissionCleanup.add(%p);
            %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
         }
         
         %obj.schedule(10,delete);
         
         //Special effect weapons like the Horse Ray will still affect you from the back
         if(%damageScale > 0)
         {
            %this.directDamage *= %damageScale;
            %ret = Parent::damage(%this,%obj,%col,%fade,%pos,%normal);
            %this.directDamage /= %damageScale;
         }
         
         return %ret;
      }
      else
      {
         return Parent::damage(%this,%obj,%col,%fade,%pos,%normal);
      }
   }
   
   function ProjectileData::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt)
   {
      if(%obj.damageCancel[%col])
         return;
      
      return Parent::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt);
   }
   
   function ProjectileData::radiusImpulse(%this, %obj, %col, %a, %pos, %b, %c)
   {
      if(%obj.damageCancel[%col])
      {
         %b = %b * %obj.impulseScale[%col];
      }
      
      return Parent::radiusImpulse(%this, %obj, %col, %a, %pos, %b, %c);
   }
   
   function ProjectileData::impactImpulse(%this, %obj, %col, %a)
   {
      if(%obj.damageCancel[%col])
      {
         %this.impactImpulse *= %obj.impulseScale[%col];
         %val = Parent::impactImpulse(%this, %obj, %col, %a);
         %this.impactImpulse /= %obj.impulseScale[%col];
         return %val;
      }
      
      return Parent::impactImpulse(%this, %obj, %col, %a);
   }
   
   function ShapeBase::damage(%this, %sourceObject, %pos, %directDamage, %damageType)
   {
      %image0 = %this.getMountedImage(0);
      %image1 = %this.getMountedImage(1);
      %image2 = %this.getMountedImage(2);
      %state0 = %this.getImageState(0);
      
      %fvec = %this.getForwardVector();
      %fX = getWord(%fvec,0);
      %fY = getWord(%fvec,1);
      
      %evec = %this.getEyeVector();
      %eX = getWord(%evec,0);
      %eY = getWord(%evec,1);
      %eZ = getWord(%evec,2);
      
      %eXY = mSqrt(%eX*%eX+%eY*%eY);
      
      %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
      
      if(%damageType == $DamageType::Fall || %damageType == $DamageType::Impact)
      {
         %quit = 1;
         
         if(%damageType == $DamageType::Fall)
            %attackvec = "0 0 -1";
         else
            %attackvec = vectorNormalize(vectorSub(%this.getHackPosition(),%pos));
         
         %fvec = %this.getForwardVector();
         %fX = getWord(%fvec,0);
         %fY = getWord(%fvec,1);
         
         %evec = %this.getEyeVector();
         %eX = getWord(%evec,0);
         %eY = getWord(%evec,1);
         %eZ = getWord(%evec,2);
         
         %eXY = mSqrt(%eX*%eX+%eY*%eY);
         
         %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
         if(%image0 == shieldRiotTTImage.getID() && %state0 $= "Ready")
            %shielded = (vectorDot(%attackVec,%aimVec) > 0);
         
         if(%shielded && $Shield::RiotTTCancelFalling)
         {
            %this.spawnExplosion(hammerProjectile,getWord(%this.getScale(),2)*2);
            %directDamage = %directDamage/8;
         }
      }
      else if(!%quit && (%this.getType() & $TypeMasks::PlayerObjectType) && !%sourceObject.damageCancel[%obj])
      {
         %scale = getWord(%this.getScale(),2);
         
         %attackvec = vectorNormalize(vectorSub(%this.getHackPosition(),%pos));
         
         if(%image0 == shieldRiotTTImage.getID() && %state0 $= "Ready")
         {
            if(%eZ > 0.75)
               %shielded = (getword(%pos, 2) > getword(%this.getWorldBoxCenter(),2) - 3.3*%scale);
            else if(%ez < -0.75)
               %shielded = (getword(%pos, 2) < getword(%this.getWorldBoxCenter(),2) - 4.4*%scale);
            else
               %shielded = (vectorDot(%attackvec,%aimVec) < 0);
            
            %damageScale = 0.2;
            if(vectorDist(%pos,"0 0 0") < 0.1) %shielded = 0;
            if(vectorDist(%pos,%this.getPosition()) < 0.1) %shielded = 0;
            if(%directDamage > 5000) %shielded = 0;
            
            if(%shielded)
               %this.spawnExplosion(hammerProjectile,getWord(%this.getScale(),2));
         }
         if(%shielded)
            %directDamage = %directDamage * %damageScale;
      }
      return Parent::damage(%this, %sourceObject, %pos, %directDamage, %damageType);
   }
};activatepackage(Shield);
