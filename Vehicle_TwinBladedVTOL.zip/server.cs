%errorA = ForceRequiredAddOn("Weapon_Gun");
%errorB = ForceRequiredAddOn("Weapon_Rocket_Launcher");
%errorC = ForceRequiredAddOn("Vehicle_Jeep");

if(%errorA == $Error::AddOn_Disabled)
   GunItem.uiName = "";
if(%errorB == $Error::AddOn_Disabled)
   rocketLauncherItem.uiName = "";
if(%errorC == $Error::AddOn_Disabled)
   jeepVehicle.uiName = "";

if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_TwinBladedVTOL - required add-on Weapon_Gun not found");
else if(%errorB == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_TwinBladedVTOL - required add-on Weapon_Rocket_Launcher not found");
else if(%errorC == $Error::AddOn_NotFound)
   error("ERROR: Vehicle_TwinBladedVTOL - required add-on Vehicle_jeep not found");
else
    exec("./VTOL.cs");
    exec("./VTOLMinigun.cs");
    exec("./VTOLRocket.cs");
    exec("./Support_shootOnClick.cs");